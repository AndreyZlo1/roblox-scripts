-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-roblox@17.1.0.react-roblox.client.roblox.RobloxComponentProps
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
local l__CollectionService__2 = game:GetService("CollectionService");
local v1 = require(script.Parent.Parent.Parent.Parent:WaitForChild("luau-polyfill"));
local l__Object__3 = v1.Object;
local l__Set__4 = v1.Set;
local l__String__5 = v1.String;
local l__inspect__6 = v1.util.inspect;
local l__console__7 = require(script.Parent.Parent.Parent.Parent:WaitForChild("shared")).console;
local l__react__8 = require(script.Parent.Parent.Parent.Parent:WaitForChild("react"));
local l__ReactSymbols__9 = require(script.Parent.Parent.Parent.Parent:WaitForChild("shared")).ReactSymbols;
local l__SingleEventManager__10 = require(script.Parent:WaitForChild("SingleEventManager"));
local l__Type__11 = require(script.Parent.Parent.Parent.Parent:WaitForChild("shared")).Type;
local l__getDefaultInstanceProperty__12 = require(script.Parent:WaitForChild("getDefaultInstanceProperty"));
require(script.Parent.Parent:WaitForChild("ReactRobloxHostTypes.roblox"));
local l__Tag__13 = require(script.Parent.Parent.Parent.Parent:WaitForChild("react")).Tag;
local u2 = {};
local u3 = {};
local function u4(...) --[[ Line: 71 ]]
    return ...;
end;
local function u9(p5, p6, p7) --[[ Line: 75 ]]
    -- upvalues: l__getDefaultInstanceProperty__12 (copy)
    if p7 == nil then
        local v8;
        v8, p7 = l__getDefaultInstanceProperty__12(p5.ClassName, p6);
    end;
    p5[p6] = p7;
end;
local function u19(u10, u11, u12) --[[ Line: 95 ]]
    -- upvalues: u9 (copy), u4 (copy), l__console__7 (copy), u3 (copy), l__react__8 (copy)
    local function v18(p13) --[[ Line: 96 ]]
        -- upvalues: u9 (ref), u4 (ref), u10 (copy), u11 (copy), u12 (copy), l__console__7 (ref)
        local v14, v15 = xpcall(u9, u4, u10, u11, p13);
        if not v14 then
            local v16 = u12._source or "<enable DEV mode for stack>";
            local v17 = string.format("Error updating binding or ref assigned to key %s of \'%s\' (%s).\n\nUpdated value:\n  %s\n\nError:\n  %s\n\n%s\n", u11, u10.Name, u10.ClassName, tostring(p13), v15, v16);
            l__console__7.error(v17);
            error(v17, 0);
        end;
    end;
    if u3[u10] == nil then
        u3[u10] = {};
    end;
    u3[u10][u11] = l__react__8.__subscribeToBinding(u12, v18);
    v18(u12:getValue());
end;
local function u27(p20, p21, p22) --[[ Line: 128 ]]
    -- upvalues: l____DEV____1 (copy), l__console__7 (copy), l__inspect__6 (copy), l__Set__4 (copy), l__String__5 (copy), l__CollectionService__2 (copy)
    if l____DEV____1 and (p22 ~= nil and typeof(p22) ~= "string") then
        l__console__7.error("Type provided for ReactRoblox.Tag is invalid - tags should be specified as a single string, with individual tags delimited by spaces. Instead received:\n%s", l__inspect__6(p22));
    else
        local v23 = l__Set__4.new(l__String__5.split(p21 or "", " "));
        local v24 = l__Set__4.new(l__String__5.split(p22 or "", " "));
        for _, v25 in v23 do
            if not v24:has(v25) then
                l__CollectionService__2:RemoveTag(p20, v25);
            end;
        end;
        for _, v26 in v24 do
            if not v23:has(v26) then
                l__CollectionService__2:AddTag(p20, v26);
            end;
        end;
    end;
end;
local function u38(p28, p29, p30, p31) --[[ Line: 162 ]]
    -- upvalues: l__Type__11 (copy), u2 (copy), l__SingleEventManager__10 (copy), l__ReactSymbols__9 (copy), u3 (copy), u19 (copy), l__Tag__13 (copy), u27 (copy), l__getDefaultInstanceProperty__12 (copy)
    local v32 = l__Type__11.of(p29);
    if v32 == l__Type__11.HostEvent or v32 == l__Type__11.HostChangeEvent then
        local v33 = u2[p28];
        if v33 == nil then
            v33 = l__SingleEventManager__10.new(p28);
            u2[p28] = v33;
        end;
        local l__name__14 = p29.name;
        if v32 == l__Type__11.HostChangeEvent then
            v33:connectPropertyChange(l__name__14, p30);
        else
            v33:connectEvent(l__name__14, p30);
        end;
    else
        local v34;
        if typeof(p30) == "table" then
            v34 = p30["$$typeof"] == l__ReactSymbols__9.REACT_BINDING_TYPE;
        else
            v34 = false;
        end;
        local v35;
        if p31 == nil or typeof(p31) ~= "table" then
            v35 = false;
        else
            v35 = p31["$$typeof"] == l__ReactSymbols__9.REACT_BINDING_TYPE;
        end;
        if v35 then
            local v36 = u3[p28];
            if v36 ~= nil then
                v36[p29]();
                v36[p29] = nil;
            end;
        end;
        if v34 then
            u19(p28, p29, p30);
        elseif p29 == l__Tag__13 then
            u27(p28, p31, p30);
        else
            if p30 == nil then
                local v37;
                v37, p30 = l__getDefaultInstanceProperty__12(p28.ClassName, p29);
            end;
            p28[p29] = p30;
        end;
    end;
end;
local function u43(p39, p40) --[[ Line: 207 ]]
    -- upvalues: u38 (copy)
    for v41, v42 in p40 do
        if v41 ~= "ref" and v41 ~= "children" then
            u38(p39, v41, v42);
        end;
    end;
end;
local function u50(p44, p45, p46) --[[ Line: 247 ]]
    -- upvalues: l__Object__3 (copy), u38 (copy)
    for v47 = 1, #p45, 2 do
        local v48 = p45[v47];
        local v49 = p45[v47 + 1];
        if v49 == l__Object__3.None then
            v49 = nil;
        end;
        if v48 ~= "ref" and v48 ~= "children" then
            u38(p44, v48, v49, p46[v48]);
        end;
    end;
end;
return {
    setInitialProperties = function(p51, _, p52, _) --[[ Name: setInitialProperties, Line 218 ]]
        -- upvalues: u43 (copy), u4 (copy), l__console__7 (copy), u2 (copy)
        local v53, v54 = xpcall(u43, u4, p51, p52);
        if not v53 then
            local v55 = string.format("Error applying initial props to Roblox Instance \'%s\' (%s):\n  %s\n", p51.Name, p51.ClassName, v54);
            l__console__7.error(v55);
            error(v55, 0);
        end;
        if u2[p51] ~= nil then
            u2[p51]:resume();
        end;
    end,
    updateProperties = function(p56, p57, p58) --[[ Name: updateProperties, Line 266 ]]
        -- upvalues: u2 (copy), u50 (copy), u4 (copy), l__console__7 (copy)
        if u2[p56] ~= nil then
            u2[p56]:suspend();
        end;
        local v59, v60 = xpcall(u50, u4, p56, p57, p58);
        if not v59 then
            local v61 = string.format("Error updating props on Roblox Instance \'%s\' (%s):\n  %s\n", p56.Name, p56.ClassName, v60);
            l__console__7.error(v61);
            error(v61, 0);
        end;
        if u2[p56] ~= nil then
            u2[p56]:resume();
        end;
    end,
    cleanupHostComponent = function(p62) --[[ Name: cleanupHostComponent, Line 302 ]]
        -- upvalues: u2 (copy), u3 (copy), l__CollectionService__2 (copy)
        if u2[p62] ~= nil then
            u2[p62] = nil;
        end;
        if u3[p62] ~= nil then
            u3[p62] = nil;
        end;
        if typeof(p62) == "Instance" then
            for _, v63 in l__CollectionService__2:GetTags(p62) do
                l__CollectionService__2:RemoveTag(p62, v63);
            end;
            for _, v64 in p62:GetDescendants() do
                if u2[v64] ~= nil then
                    u2[v64] = nil;
                end;
                if u3[v64] ~= nil then
                    u3[v64] = nil;
                end;
                for _, v65 in l__CollectionService__2:GetTags(p62) do
                    l__CollectionService__2:RemoveTag(p62, v65);
                end;
            end;
        end;
    end,
    _instanceToEventManager = u2,
    _instanceToBindings = u3
};