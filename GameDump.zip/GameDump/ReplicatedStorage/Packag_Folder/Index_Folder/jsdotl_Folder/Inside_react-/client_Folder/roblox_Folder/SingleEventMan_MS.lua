-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-roblox@17.1.0.react-roblox.client.roblox.SingleEventManager
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__console__1 = require(script.Parent.Parent.Parent.Parent:WaitForChild("shared")).console;
local u1 = {};
u1.__index = u1;
function u1.new(p2) --[[ Line: 47 ]]
    -- upvalues: u1 (copy)
    return setmetatable({
        _status = "Disabled",
        _isResuming = false,
        _suspendedEventQueue = {},
        _connections = {},
        _listeners = {},
        _instance = p2
    }, u1);
end;
function u1.connectEvent(p3, p4, p5) --[[ Line: 75 ]]
    p3:_connect(p4, p3._instance[p4], p5);
end;
function u1.connectPropertyChange(p6, p7, p8) --[[ Line: 79 ]]
    local v9, v10 = pcall(p6._instance.GetPropertyChangedSignal, p6._instance, p7);
    if not v9 then
        error(string.format("Cannot get changed signal on property %q: %s", tostring(p7), v10), 0);
    end;
    p6:_connect("Change." .. p7, v10, p8);
end;
function u1._connect(u11, u12, p13, p14) --[[ Line: 97 ]]
    if p14 == nil then
        if u11._connections[u12] ~= nil then
            u11._connections[u12]:Disconnect();
            u11._connections[u12] = nil;
        end;
        u11._listeners[u12] = nil;
    else
        if u11._connections[u12] == nil then
            u11._connections[u12] = p13:Connect(function(...) --[[ Line: 108 ]]
                -- upvalues: u11 (copy), u12 (copy)
                if u11._status == "Enabled" then
                    u11._listeners[u12](u11._instance, ...);
                else
                    if u11._status == "Suspended" then
                        local v15 = { u12, select("#", ...), ... };
                        table.insert(u11._suspendedEventQueue, v15);
                    end;
                end;
            end);
        end;
        u11._listeners[u12] = p14;
    end;
end;
function u1.suspend(p16) --[[ Line: 128 ]]
    p16._status = "Suspended";
end;
function u1.resume(p17) --[[ Line: 132 ]]
    -- upvalues: l__console__1 (copy)
    if p17._isResuming then
    else
        p17._isResuming = true;
        for _, v18 in p17._suspendedEventQueue do
            local v19 = p17._listeners[v18[1]];
            local v20 = v18[2];
            if v19 ~= nil then
                local v21 = coroutine.create(v19);
                local v22, v23 = coroutine.resume(v21, p17._instance, unpack(v18, 3, 2 + v20));
                if not v22 then
                    l__console__1.warn("%s", v23);
                end;
            end;
        end;
        p17._isResuming = false;
        p17._status = "Enabled";
        table.clear(p17._suspendedEventQueue);
    end;
end;
return u1;