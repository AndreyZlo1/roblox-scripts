-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-roblox@17.1.0.react-roblox.client.roblox.getDefaultInstanceProperty
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = require(script.Parent.Parent.Parent.Parent:WaitForChild("shared")).Symbol.named("Nil");
local u2 = {};
local function u5(p3, p4) --[[ Line: 32 ]]
    return p3[p4];
end;
return function(p6, p7) --[[ Name: getDefaultInstanceProperty, Line 36 ]]
    -- upvalues: u2 (copy), u1 (copy), u5 (copy)
    local v8 = u2[p6];
    if v8 then
        local v9 = v8[p7];
        if v9 == u1 then
            return true, nil;
        end;
        if v9 ~= nil then
            return true, v9;
        end;
    else
        v8 = {};
        u2[p6] = v8;
    end;
    local v10 = Instance.new(p6);
    local v11, v12 = pcall(u5, v10, p7);
    v10:Destroy();
    if v11 then
        if v12 == nil then
            v8[p7] = u1;
            return v11, v12;
        end;
        v8[p7] = v12;
    end;
    return v11, v12;
end;