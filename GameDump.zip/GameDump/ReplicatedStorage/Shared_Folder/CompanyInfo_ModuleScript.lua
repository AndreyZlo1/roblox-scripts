-- Roblox: ReplicatedStorage.Shared.CompanyInfo
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Departments = {
        Main = {
            Name = "Airbase",
            Icon = 16191609576
        },
        Overview = {
            Name = "Overview",
            Icon = 16191609576
        },
        Barracks = {
            Name = "Barracks",
            Icon = 16191609730
        },
        Logistics = {
            Name = "Logistics",
            Icon = 16191609853,
            Skill = { "Logistics" }
        },
        Operations = {
            Name = "Operations",
            Icon = 16191610155,
            Skill = { "Combat" }
        },
        Training = {
            Name = "Training",
            Icon = 16191610671
        },
        Command = {
            Name = "Command",
            Icon = 16191610023,
            Skill = { "Command" }
        },
        Mechanics = {
            Name = "Mechanics",
            Icon = 16191610311,
            Skill = { "Mechanics" }
        },
        Construction = {
            Name = "Construction",
            Icon = 16235940598
        },
        Deliveries = {
            Name = "Deliveries",
            Icon = 16191610464,
            Skill = { "Deliveries" }
        },
        HeliHangers = {
            Name = "Helicopter Hangar",
            Icon = 89811360504438
        },
        PlaneHangers = {
            Name = "Plane Hangar",
            Icon = 130280747557028
        },
        Garage = {
            Name = "Garage",
            Icon = 83228079647765
        },
        WeaponShop = {
            Name = "Gunsmith",
            Icon = 133672177304600
        },
        Research = {
            Name = "Research Lab",
            Icon = 85113291827486,
            Skill = { "Logistics", "Mechanics", "Medical" }
        },
        Defenses = {
            Name = "Defenses",
            Icon = 124023239124712,
            Skill = { "Combat" }
        },
        Infirmary = {
            Name = "Infirmary",
            Icon = 92347778607419,
            Skill = { "Medical" }
        }
    },
    Skills = {
        Logistics = {
            Icon = 16191609853
        },
        Combat = {
            Icon = 107497991613070
        },
        Command = {
            Icon = 16191610023
        },
        Mechanics = {
            Icon = 16191610311
        },
        Deliveries = {
            Icon = 16191610464
        },
        Medical = {
            Icon = 92347778607419
        }
    },
    Resources = {
        Material = {
            Name = "Construction Materials",
            Icon = "rbxassetid://16235940598",
            Color = Color3.fromRGB(255, 170, 0)
        },
        Metal = {
            Name = "Precious Metals",
            Icon = "rbxassetid://16563081759",
            Color = Color3.fromRGB(0, 170, 255)
        },
        Fuel = {
            Name = "Fuel",
            Icon = "rbxassetid://16563081369",
            Color = Color3.fromRGB(255, 80, 80)
        },
        Equipment = {
            Name = "Equipment",
            Icon = "rbxassetid://16563081240",
            Color = Color3.fromRGB(127, 208, 98)
        }
    }
};