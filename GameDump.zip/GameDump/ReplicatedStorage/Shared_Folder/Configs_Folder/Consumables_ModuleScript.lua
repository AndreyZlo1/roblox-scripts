-- Roblox: ReplicatedStorage.Shared.Configs.Consumables
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    GravBrew = {
        Thirst = 0.0625,
        Hunger = 0,
        Weight = 350,
        WeightBare = 25,
        Name = "Grav Brew",
        Description = "Grav Brew Classic flavor. Ingredients vary by locality.",
        Model = "Soda",
        IsFizzy = true,
        Uses = 4,
        Size = Vector2.new(1, 2),
        Texture = {
            Can = "rbxassetid://12245504279"
        }
    },
    Chips = {
        Thirst = -0.0125,
        Hunger = 0.0625,
        Weight = 150,
        WeightBare = 60,
        Name = "Chips",
        Description = "Potato chips.",
        Model = "Chips",
        IsFizzy = false,
        Uses = 6,
        Size = Vector2.new(1, 2),
        Texture = {
            Inside = "rbxassetid://137018569009358",
            Paper = "rbxassetid://137018569009358",
            Can = "rbxassetid://137018569009358"
        }
    },
    ChipsSour = {
        Thirst = -0.0125,
        Hunger = 0.065,
        Weight = 150,
        WeightBare = 60,
        Name = "Chips",
        Description = "Sour cream and onion flavored potato chips.",
        Model = "Chips",
        IsFizzy = false,
        Uses = 6,
        Size = Vector2.new(1, 2),
        Texture = {
            Inside = "rbxassetid://76059061514921",
            Paper = "rbxassetid://76059061514921",
            Can = "rbxassetid://76059061514921"
        }
    },
    CatFood = {
        Thirst = 0.025,
        Hunger = 0.05,
        Weight = 150,
        WeightBare = 25,
        Name = "Cat Food",
        Description = "Food. For a cat. You can eat it too, I guess.",
        Model = "CanSmall",
        IsFizzy = false,
        Uses = 4,
        Size = Vector2.new(1, 1),
        Texture = {
            Base = "rbxassetid://124581726688222",
            Inside = "rbxassetid://124581726688222",
            Popper = "rbxassetid://124581726688222",
            Top = "rbxassetid://124581726688222"
        }
    },
    TunaCan = {
        Thirst = 0.025,
        Hunger = 0.1,
        Weight = 340,
        WeightBare = 25,
        Name = "Canned Tuna",
        Description = "A can of tuna fish. Still good to eat.",
        Model = "CanSmall",
        IsFizzy = false,
        Uses = 4,
        Size = Vector2.new(1, 1),
        Texture = {
            Base = "rbxassetid://124581726688222",
            Inside = "rbxassetid://124581726688222",
            Popper = "rbxassetid://124581726688222",
            Top = "rbxassetid://124581726688222"
        }
    },
    PeasCan = {
        Thirst = 0,
        Hunger = 0.04,
        Weight = 450,
        WeightBare = 25,
        Name = "Canned Peas",
        Description = "A can of peas. Still good to eat.",
        Model = "CanLarge",
        IsFizzy = false,
        Uses = 7,
        Size = Vector2.new(1, 2),
        Texture = {
            Base = "rbxassetid://124581726688222",
            Inside = "rbxassetid://124581726688222",
            Popper = "rbxassetid://124581726688222",
            Top = "rbxassetid://124581726688222"
        }
    },
    NutsCan = {
        Thirst = -0.0125,
        Hunger = 0.075,
        Weight = 150,
        WeightBare = 25,
        Name = "Canned Peanuts",
        Description = "A can of fresh-enough peanuts.",
        Model = "CanSmall",
        IsFizzy = false,
        Uses = 5,
        Size = Vector2.new(1, 1),
        Texture = {
            Base = "rbxassetid://111591186115164",
            Inside = "rbxassetid://111591186115164",
            Popper = "rbxassetid://111591186115164",
            Top = "rbxassetid://111591186115164"
        }
    },
    PeachesCan = {
        Thirst = 0.05,
        Hunger = 0.05,
        Weight = 450,
        WeightBare = 25,
        Name = "Canned Peaches",
        Description = "A can of fresh peaches. Delicious.",
        Model = "CanLarge",
        IsFizzy = false,
        Uses = 8,
        Size = Vector2.new(1, 2),
        Texture = {
            Base = "rbxassetid://111591186115164",
            Inside = "rbxassetid://111591186115164",
            Popper = "rbxassetid://111591186115164",
            Top = "rbxassetid://111591186115164"
        }
    },
    BeefCan = {
        Thirst = 0,
        Hunger = 0.075,
        Weight = 150,
        WeightBare = 25,
        Name = "Canned Beef Stew",
        Description = "A can of beef stew. Still good to eat.",
        Model = "CanSmall",
        IsFizzy = false,
        Timer = 1.7,
        Uses = 8,
        Size = Vector2.new(1, 1),
        Texture = {
            Base = "rbxassetid://75697642326456",
            Inside = "rbxassetid://75697642326456",
            Popper = "rbxassetid://75697642326456",
            Top = "rbxassetid://75697642326456"
        }
    },
    CornCan = {
        Thirst = 0.02,
        Hunger = 0.05,
        Weight = 450,
        WeightBare = 25,
        Name = "Canned Corn",
        Description = "A can of corn. Still good to eat.",
        Model = "CanLarge",
        IsFizzy = false,
        Uses = 8,
        Size = Vector2.new(1, 2),
        Texture = {
            Base = "rbxassetid://75697642326456",
            Inside = "rbxassetid://75697642326456",
            Popper = "rbxassetid://75697642326456",
            Top = "rbxassetid://75697642326456"
        }
    },
    ChickenCan = {
        Thirst = 0,
        Hunger = 0.1,
        Weight = 150,
        WeightBare = 25,
        Name = "Canned Chicken Slices",
        Description = "A can of chicken slices. Still good to eat.",
        Model = "CanSmall",
        IsFizzy = false,
        Uses = 4,
        Size = Vector2.new(1, 1),
        Texture = {
            Base = "rbxassetid://93619579976367",
            Inside = "rbxassetid://93619579976367",
            Popper = "rbxassetid://93619579976367",
            Top = "rbxassetid://93619579976367"
        }
    },
    TomatoCan = {
        Thirst = 0.0375,
        Hunger = 0.05,
        Weight = 450,
        WeightBare = 25,
        Name = "Canned Tomato Soup",
        Description = "A can of tomato soup. Still good to eat.",
        Model = "CanLarge",
        IsFizzy = false,
        Uses = 7,
        Size = Vector2.new(1, 2),
        Texture = {
            Base = "rbxassetid://93619579976367",
            Inside = "rbxassetid://93619579976367",
            Popper = "rbxassetid://93619579976367",
            Top = "rbxassetid://93619579976367"
        }
    },
    TunaCanRot = {
        Thirst = -0.05,
        Hunger = 0.05,
        Weight = 150,
        WeightBare = 25,
        Name = "Rotten Tuna",
        Description = "An opened can of tuna, left out far too long. Technically edible with a tradeoff in hydration.",
        Model = "CanSmall",
        IsFizzy = false,
        Uses = 4,
        Size = Vector2.new(1, 1),
        Texture = {
            Base = "rbxassetid://76550072257820",
            Inside = "rbxassetid://76550072257820",
            Popper = "rbxassetid://76550072257820",
            Top = "rbxassetid://76550072257820"
        }
    },
    PeasCanRot = {
        Thirst = -0.1,
        Hunger = 0.1,
        Weight = 150,
        WeightBare = 25,
        Name = "Rotten Peas",
        Description = "An opened can of peas, left out far too long. Technically edible with a tradeoff in hydration.",
        Model = "CanLarge",
        IsFizzy = false,
        Uses = 5,
        Size = Vector2.new(1, 2),
        Texture = {
            Base = "rbxassetid://76550072257820",
            Inside = "rbxassetid://76550072257820",
            Popper = "rbxassetid://76550072257820",
            Top = "rbxassetid://76550072257820"
        }
    },
    CornCanRot = {
        Thirst = -0.2,
        Hunger = 0.1,
        Weight = 450,
        WeightBare = 25,
        Name = "Rotten Corn",
        Description = "An opened can of corn, left out far too long. Technically edible with a tradeoff in hydration.",
        Model = "CanLarge",
        IsFizzy = false,
        Uses = 5,
        Size = Vector2.new(1, 2),
        Texture = {
            Base = "rbxassetid://75552495582460",
            Inside = "rbxassetid://75552495582460",
            Popper = "rbxassetid://75552495582460",
            Top = "rbxassetid://75552495582460"
        }
    },
    PeachesCanRot = {
        Thirst = -0.1,
        Hunger = 0.1,
        Weight = 450,
        WeightBare = 25,
        Name = "Rotten Peaches",
        Description = "An opened can of peaches, left out far too long. Technically edible with a tradeoff in hydration.",
        Model = "CanLarge",
        IsFizzy = false,
        Uses = 5,
        Size = Vector2.new(1, 2),
        Texture = {
            Base = "rbxassetid://102344002279948",
            Inside = "rbxassetid://102344002279948",
            Popper = "rbxassetid://102344002279948",
            Top = "rbxassetid://102344002279948"
        }
    },
    BeefCanRot = {
        Thirst = -0.1,
        Hunger = 0.12,
        Weight = 300,
        WeightBare = 25,
        Name = "Rotten Beef Stew",
        Description = "An opened can of beef stew, left out far too long. Technically edible with a tradeoff in hydration.",
        Model = "CanSmall",
        IsFizzy = false,
        Timer = 1.7,
        Uses = 7,
        Size = Vector2.new(1, 1),
        Texture = {
            Base = "rbxassetid://75552495582460",
            Inside = "rbxassetid://75552495582460",
            Popper = "rbxassetid://75552495582460",
            Top = "rbxassetid://75552495582460"
        }
    },
    ChickenCanRot = {
        Thirst = -0.1,
        Hunger = 0.1,
        Weight = 300,
        WeightBare = 25,
        Name = "Rotten Chicken Slices",
        Description = "An opened can of chicken, left out far too long. Technically edible with a tradeoff in hydration.",
        Model = "CanSmall",
        IsFizzy = false,
        Uses = 4,
        Size = Vector2.new(1, 1),
        Texture = {
            Base = "rbxassetid://78367400878169",
            Inside = "rbxassetid://78367400878169",
            Popper = "rbxassetid://78367400878169",
            Top = "rbxassetid://78367400878169"
        }
    },
    TomatoCanRot = {
        Thirst = -0.1,
        Hunger = 0.05,
        Weight = 450,
        WeightBare = 25,
        Name = "Rotten Tomato Soup",
        Description = "An opened can of tomato soup, left out far too long. Technically edible with a tradeoff in hydration.",
        Model = "CanLarge",
        IsFizzy = false,
        Uses = 7,
        Size = Vector2.new(1, 2),
        Texture = {
            Base = "rbxassetid://78367400878169",
            Inside = "rbxassetid://78367400878169",
            Popper = "rbxassetid://78367400878169",
            Top = "rbxassetid://78367400878169"
        }
    },
    WaterBottleRot = {
        Thirst = 0.15,
        Hunger = -0.15,
        Weight = 350,
        WeightBare = 25,
        Name = "Dirty Water",
        Description = "An opened bottle of water, filled with murky liquid. Maybe you can drink it?",
        Model = "WaterBottle",
        IsFizzy = true,
        Uses = 4,
        Size = Vector2.new(1, 2),
        Fluid = Color3.fromRGB(106, 57, 9),
        Texture = {
            Label = "rbxassetid://100183383819837",
            Cap = "rbxassetid://100183383819837"
        }
    },
    WaterBottle = {
        Thirst = 0.2,
        Hunger = 0,
        Weight = 500,
        WeightBare = 50,
        Name = "Water Bottle",
        Description = "A bottle of clean water.",
        Model = "WaterBottle",
        IsFizzy = false,
        Uses = 4,
        Size = Vector2.new(1, 2),
        Fluid = Color3.fromRGB(31, 126, 170),
        Texture = {
            Label = "rbxassetid://100183383819837",
            Cap = "rbxassetid://100183383819837"
        }
    },
    EnergyDrink = {
        Thirst = 0.25,
        Hunger = 0.1,
        Weight = 500,
        WeightBare = 50,
        Name = "Energy Drink",
        Description = "A \'Grav Brew Extreme\'. Long-term use not advised.",
        Model = "Soda",
        IsFizzy = true,
        Uses = 2,
        Size = Vector2.new(1, 2),
        Texture = {
            Can = "rbxassetid://103109622841165"
        }
    },
    SodaBottleCola = {
        Thirst = 0.05,
        Hunger = 0,
        Weight = 2000,
        WeightBare = 50,
        Name = "Cola Soda Bottle",
        Description = "A 2L bottle of Rono-Cola.",
        Model = "SodaBottle",
        IsFizzy = true,
        Uses = 40,
        Size = Vector2.new(2, 3),
        Fluid = Color3.fromRGB(17, 17, 17),
        Texture = {
            Label = "rbxassetid://100183383819837",
            Cap = "rbxassetid://100183383819837"
        }
    },
    SodaBottleLime = {
        Thirst = 0.05,
        Hunger = 0,
        Weight = 2000,
        WeightBare = 50,
        Name = "Lime Soda Bottle",
        Description = "A 2L bottle of caffeine-free lime soda.",
        Model = "SodaBottle",
        IsFizzy = true,
        Uses = 40,
        Size = Vector2.new(2, 3),
        Fluid = Color3.fromRGB(255, 233, 65),
        Texture = {
            Label = "rbxassetid://100614213899248",
            Cap = "rbxassetid://100614213899248"
        }
    }
};