-- Roblox: ReplicatedStorage.Shared.Configs.Environment.SkyboxPresets
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Default = {
        MoonAngularSize = 6,
        SunAngularSize = 10,
        StarCount = 2000,
        SkyboxBk = "rbxassetid://91458024",
        SkyboxDn = "rbxassetid://91457980",
        SkyboxFt = "rbxassetid://91458024",
        SkyboxLf = "rbxassetid://91458024",
        SkyboxRt = "rbxassetid://91458024",
        SkyboxUp = "rbxassetid://91458002"
    },
    Blank = {
        MoonAngularSize = 6,
        SunAngularSize = 16,
        StarCount = 2000,
        SkyboxBk = "rbxassetid://91458024",
        SkyboxDn = "rbxassetid://91457980",
        SkyboxFt = "rbxassetid://91458024",
        SkyboxLf = "rbxassetid://91458024",
        SkyboxRt = "rbxassetid://91458024",
        SkyboxUp = "rbxassetid://91458002"
    },
    Seychelles = {
        MoonAngularSize = 6,
        SunAngularSize = 16,
        StarCount = 2000,
        SkyboxBk = "rbxassetid://6444884337",
        SkyboxDn = "rbxassetid://6444884785",
        SkyboxFt = "rbxassetid://6444884337",
        SkyboxLf = "rbxassetid://6444884337",
        SkyboxRt = "rbxassetid://6444884337",
        SkyboxUp = "rbxassetid://6412503613"
    },
    Tokyo = {
        MoonAngularSize = 11,
        SunAngularSize = 21,
        StarCount = 3000,
        SkyboxBk = "rbxassetid://679786546",
        SkyboxDn = "rbxassetid://680029379",
        SkyboxFt = "rbxassetid://679786832",
        SkyboxLf = "rbxassetid://679786679",
        SkyboxRt = "rbxassetid://679786411",
        SkyboxUp = "rbxassetid://679787023"
    },
    Coast = {
        MoonAngularSize = 11,
        SunAngularSize = 21,
        StarCount = 1500,
        SkyboxBk = "rbxassetid://91458024",
        SkyboxDn = "rbxassetid://91457980",
        SkyboxFt = "rbxassetid://91458024",
        SkyboxLf = "rbxassetid://91458024",
        SkyboxRt = "rbxassetid://91458024",
        SkyboxUp = "rbxassetid://91458002"
    },
    Favela = {
        MoonAngularSize = 6,
        SunAngularSize = 16,
        StarCount = 3000,
        SkyboxBk = "rbxassetid://11832250366",
        SkyboxDn = "rbxassetid://11832250656",
        SkyboxFt = "rbxassetid://11832250915",
        SkyboxLf = "rbxassetid://11832250090",
        SkyboxRt = "rbxassetid://11832249798",
        SkyboxUp = "rbxassetid://11832257515"
    },
    NYC = {
        MoonAngularSize = 6,
        SunAngularSize = 9,
        StarCount = 500,
        SkyboxBk = "rbxassetid://15063412549",
        SkyboxDn = "rbxassetid://15063341496",
        SkyboxFt = "rbxassetid://15063442046",
        SkyboxLf = "rbxassetid://15063367382",
        SkyboxRt = "rbxassetid://15063435355",
        SkyboxUp = "rbxassetid://15063353447"
    },
    Office = {
        MoonAngularSize = 11,
        SunAngularSize = 21,
        StarCount = 100,
        SkyboxBk = "rbxassetid://91458024",
        SkyboxDn = "rbxassetid://91457980",
        SkyboxFt = "rbxassetid://91458024",
        SkyboxLf = "rbxassetid://91458024",
        SkyboxRt = "rbxassetid://91458024",
        SkyboxUp = "rbxassetid://91458002"
    },
    Maya = {
        MoonAngularSize = 11,
        SunAngularSize = 21,
        StarCount = 3500,
        SkyboxBk = "rbxassetid://18703245834",
        SkyboxDn = "rbxassetid://18703243349",
        SkyboxFt = "rbxassetid://18703240532",
        SkyboxLf = "rbxassetid://18703237556",
        SkyboxRt = "rbxassetid://18703235430",
        SkyboxUp = "rbxassetid://18703232671"
    },
    Lookout = {
        MoonAngularSize = 11,
        SunAngularSize = 21,
        StarCount = 1500,
        SkyboxBk = "rbxassetid://91458024",
        SkyboxDn = "rbxassetid://91457980",
        SkyboxFt = "rbxassetid://91458024",
        SkyboxLf = "rbxassetid://91458024",
        SkyboxRt = "rbxassetid://91458024",
        SkyboxUp = "rbxassetid://91458002"
    },
    NYCZombies = {
        MoonAngularSize = 6,
        SunAngularSize = 16,
        StarCount = 500,
        SkyboxBk = "rbxassetid://321136141",
        SkyboxDn = "rbxassetid://321136141",
        SkyboxFt = "rbxassetid://321136141",
        SkyboxLf = "rbxassetid://321136141",
        SkyboxRt = "rbxassetid://321136141",
        SkyboxUp = "rbxassetid://321136141"
    },
    ElChara = {
        MoonAngularSize = 11,
        SunAngularSize = 11,
        StarCount = 5000,
        SkyboxBk = "rbxassetid://91458024",
        SkyboxDn = "rbxassetid://91457980",
        SkyboxFt = "rbxassetid://91458024",
        SkyboxLf = "rbxassetid://91458024",
        SkyboxRt = "rbxassetid://91458024",
        SkyboxUp = "rbxassetid://91458002"
    },
    Palace = {
        MoonAngularSize = 11,
        SunAngularSize = 11,
        StarCount = 5000,
        SkyboxBk = "rbxassetid://91458024",
        SkyboxDn = "rbxassetid://91457980",
        SkyboxFt = "rbxassetid://91458024",
        SkyboxLf = "rbxassetid://91458024",
        SkyboxRt = "rbxassetid://91458024",
        SkyboxUp = "rbxassetid://91458002"
    },
    ArcticBase = {
        MoonAngularSize = 11,
        SunAngularSize = 21,
        StarCount = 1500,
        SkyboxBk = "rbxassetid://91458024",
        SkyboxDn = "rbxassetid://91457980",
        SkyboxFt = "rbxassetid://91458024",
        SkyboxLf = "rbxassetid://91458024",
        SkyboxRt = "rbxassetid://91458024",
        SkyboxUp = "rbxassetid://91458002"
    },
    PowerPlant = {
        MoonAngularSize = 11,
        SunAngularSize = 21,
        StarCount = 3500,
        SkyboxBk = "rbxassetid://18703245834",
        SkyboxDn = "rbxassetid://18703243349",
        SkyboxFt = "rbxassetid://18703240532",
        SkyboxLf = "rbxassetid://18703237556",
        SkyboxRt = "rbxassetid://18703235430",
        SkyboxUp = "rbxassetid://18703232671"
    },
    Intro = {
        MoonAngularSize = 0,
        SunAngularSize = 0,
        StarCount = 0,
        SkyboxBk = "rbxassetid://14839555",
        SkyboxDn = "rbxassetid://14839555",
        SkyboxFt = "rbxassetid://14839555",
        SkyboxLf = "rbxassetid://14839555",
        SkyboxRt = "rbxassetid://14839555",
        SkyboxUp = "rbxassetid://14839555"
    }
};