-- Roblox: ReplicatedStorage.Shared.Configs.Environment.WeatherPresets
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    ClearSky = {
        Name = "Clear Sky",
        FogDensity = 0,
        RainDensity = 0,
        WindStrength = 200,
        GustIntensity = 100,
        CloudDensity = 0.2,
        CloudCover = 0.2,
        LightingFrequency = nil,
        LightingIntensity = 0,
        GustFrequency = { 60, 180 }
    },
    RonoClearSky = {
        Name = "Clear Sky",
        FogDensity = 0.5,
        RainDensity = 0,
        WindStrength = 200,
        GustIntensity = 50,
        CloudDensity = 0.5,
        CloudCover = 0.65,
        LightingFrequency = nil,
        LightingIntensity = 0,
        GustFrequency = { 40, 160 }
    },
    Overcast1 = {
        Name = "Overcast (Light)",
        FogDensity = 1,
        RainDensity = 0,
        WindStrength = 200,
        GustIntensity = 70,
        CloudDensity = 0.6,
        CloudCover = 0.7,
        LightingFrequency = nil,
        LightingIntensity = 0,
        GustFrequency = { 40, 140 }
    },
    Overcast2 = {
        Name = "Overcast (Moderate)",
        FogDensity = 1.5,
        RainDensity = 0,
        WindStrength = 200,
        GustIntensity = 80,
        CloudDensity = 0.7,
        CloudCover = 0.8,
        LightingFrequency = nil,
        LightingIntensity = 0,
        GustFrequency = { 40, 120 }
    },
    Overcast3 = {
        Name = "Overcast (Heavy)",
        FogDensity = 2,
        RainDensity = 0,
        WindStrength = 200,
        GustIntensity = 100,
        CloudDensity = 0.8,
        CloudCover = 0.8,
        LightingFrequency = nil,
        LightingIntensity = 0,
        GustFrequency = { 40, 90 }
    },
    Fog1 = {
        Name = "Fog (Light)",
        FogDensity = 4,
        RainDensity = 0,
        WindStrength = 200,
        GustIntensity = 100,
        CloudDensity = 0.8,
        CloudCover = 0.8,
        LightingFrequency = nil,
        LightingIntensity = 0,
        GustFrequency = { 30, 90 }
    },
    Fog2 = {
        Name = "Fog (Moderate)",
        FogDensity = 6,
        RainDensity = 0,
        WindStrength = 200,
        GustIntensity = 100,
        CloudDensity = 0.85,
        CloudCover = 0.8,
        LightingFrequency = nil,
        LightingIntensity = 0,
        GustFrequency = { 30, 90 }
    },
    Fog3 = {
        Name = "Fog (Heavy)",
        FogDensity = 8,
        RainDensity = 0,
        WindStrength = 200,
        GustIntensity = 100,
        CloudDensity = 0.9,
        CloudCover = 0.85,
        LightingFrequency = nil,
        LightingIntensity = 0,
        GustFrequency = { 40, 180 }
    },
    Rain1 = {
        Name = "Rain (Light)",
        FogDensity = 3,
        RainDensity = 1,
        WindStrength = 200,
        GustIntensity = 100,
        CloudDensity = 0.8,
        CloudCover = 0.8,
        LightingFrequency = nil,
        LightingIntensity = 0,
        GustFrequency = { 40, 100 }
    },
    Rain2 = {
        Name = "Rain (Moderate)",
        FogDensity = 4,
        RainDensity = 2,
        WindStrength = 220,
        GustIntensity = 100,
        CloudDensity = 0.85,
        CloudCover = 0.8,
        LightingFrequency = nil,
        LightingIntensity = 0,
        GustFrequency = { 40, 80 }
    },
    Rain3 = {
        Name = "Rain (Heavy)",
        FogDensity = 5,
        RainDensity = 5,
        WindStrength = 250,
        GustIntensity = 100,
        CloudDensity = 0.9,
        CloudCover = 0.85,
        LightingFrequency = nil,
        LightingIntensity = 0,
        GustFrequency = { 40, 60 }
    },
    Storm1 = {
        Name = "Thunderstorm (Moderate)",
        FogDensity = 6,
        RainDensity = 8,
        WindStrength = 300,
        GustIntensity = 120,
        CloudDensity = 0.8,
        CloudCover = 0.9,
        LightingIntensity = 1,
        GustFrequency = { 30, 60 },
        LightingFrequency = { 15, 25 }
    },
    Storm2 = {
        Name = "Thunderstorm (Heavy)",
        FogDensity = 8,
        RainDensity = 9,
        WindStrength = 350,
        GustIntensity = 150,
        CloudDensity = 0.9,
        CloudCover = 0.9,
        LightingIntensity = 2,
        GustFrequency = { 30, 50 },
        LightingFrequency = { 10, 20 }
    },
    Storm3 = {
        Name = "Thunderstorm (Intense)",
        FogDensity = 10,
        RainDensity = 10,
        WindStrength = 400,
        GustIntensity = 200,
        CloudDensity = 1,
        CloudCover = 1,
        LightingIntensity = 3,
        GustFrequency = { 10, 20 },
        LightingFrequency = { 6, 10 }
    },
    NYCClearSky1 = {
        Name = "Clear Sky",
        FogDensity = 0,
        RainDensity = 0,
        WindStrength = 300,
        GustIntensity = 100,
        CloudDensity = 0.145,
        CloudCover = 0.8,
        LightingFrequency = nil,
        LightingIntensity = 0,
        GustFrequency = { 30, 90 }
    },
    NYCFog1 = {
        Name = "Fog (Light)",
        FogDensity = 3,
        RainDensity = 0,
        WindStrength = 300,
        GustIntensity = 100,
        CloudDensity = 1,
        CloudCover = 0.8,
        LightingFrequency = nil,
        LightingIntensity = 0,
        GustFrequency = { 30, 90 }
    },
    NYCFog2 = {
        Name = "Fog (Moderate)",
        FogDensity = 5,
        RainDensity = 0,
        WindStrength = 300,
        GustIntensity = 100,
        CloudDensity = 1,
        CloudCover = 0.8,
        LightingFrequency = nil,
        LightingIntensity = 0,
        GustFrequency = { 30, 90 }
    },
    NYCFog3 = {
        Name = "Fog (Heavy)",
        FogDensity = 7,
        RainDensity = 0,
        WindStrength = 300,
        GustIntensity = 100,
        CloudDensity = 1,
        CloudCover = 0.8,
        LightingFrequency = nil,
        LightingIntensity = 0,
        GustFrequency = { 30, 90 }
    }
};