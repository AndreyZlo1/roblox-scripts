-- Roblox: ReplicatedStorage.Shared.Configs.Environment.LensFlares
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    {
        Transparency = 0.8,
        Size = 0.7,
        Distance = 1.7,
        Colour = Color3.new(0.419607, 0.360784, 0.768627),
        Fade = Color3.new(0.694117, 0.447058, 0.768627)
    },
    {
        Transparency = 0.7,
        Size = 0.2,
        Distance = 0.3,
        Colour = Color3.new(0.607843, 0.878431, 0.92549),
        Fade = Color3.new(0.709803, 0.92549, 0.607843)
    },
    {
        Transparency = 0.85,
        Size = 1.2,
        Distance = -0.3,
        Colour = Color3.new(0.494117, 0.815686, 1),
        Fade = Color3.new(1, 0.678431, 0.82745)
    },
    {
        Transparency = 0.8,
        Size = 0.45,
        Distance = -0.9,
        Colour = Color3.new(0.968627, 0.878431, 0.6901961),
        Fade = Color3.new(0.690196, 0.741176, 0.968627)
    }
};