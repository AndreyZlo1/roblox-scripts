-- Roblox: ReplicatedStorage.Shared.Configs.Environment.AtmospherePresets
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Default = {
        Density = 0.2,
        Offset = 0,
        Glare = 0,
        Haze = 0,
        Night = { 40, 40, 40 },
        Color = { 255, 255, 255 },
        Decay = { 255, 255, 255 }
    },
    Lobby = {
        Density = 0.292,
        Offset = 0,
        Glare = 0,
        Haze = 0,
        Night = { 243, 109, 0 },
        Color = { 243, 109, 0 },
        Decay = { 0, 43, 143 },
        ColorCorrection = {
            Contrast = 0.3,
            Brightness = 0.1,
            Saturation = 0,
            TintColor = Color3.fromRGB(186, 192, 229)
        }
    },
    Loadout = {
        Density = 0.516,
        Offset = 0,
        Glare = 2.8,
        Haze = 1.867,
        Night = { 0, 0, 0 },
        Color = { 0, 0, 0 },
        Decay = { 26, 23, 15 },
        ColorCorrection = {
            Contrast = 0.1,
            Brightness = -0.05,
            Saturation = 0,
            TintColor = Color3.new(1, 1, 1)
        }
    },
    Seychelles = {
        Density = 0.2,
        Offset = 0.25,
        Glare = 0.62,
        Haze = 0,
        Brightness = 0.5,
        Night = { 40, 40, 40 },
        Color = { 112, 145, 171 },
        Decay = { 218, 212, 227 },
        ColorShift = Color3.fromRGB(232, 217, 135),
        OutdoorAmbient = Color3.fromRGB(168, 150, 49)
    },
    Ronograd = {
        Density = 0.2,
        Offset = 0,
        Glare = 0,
        Haze = 2,
        Night = { 40, 40, 40 },
        Color = { 255, 255, 255 },
        Decay = { 255, 255, 255 },
        ColorCorrection = {
            Contrast = 0,
            Brightness = 0.02,
            Saturation = -0.1,
            TintColor = Color3.fromRGB(254, 255, 234)
        }
    },
    Snow = {
        Density = 0.381,
        Offset = 0.227,
        Glare = 0.83,
        Haze = 1.86,
        Night = { 214, 214, 214 },
        Color = { 214, 214, 214 },
        Decay = { 143, 143, 143 },
        ColorCorrection = {
            Contrast = 0.1,
            Brightness = 0.1,
            Saturation = -0.3,
            TintColor = Color3.fromRGB(255, 255, 255)
        }
    },
    Desert = {
        Density = 0.3,
        Offset = 1,
        Glare = 1,
        Haze = 1.98,
        Night = { 255, 253, 169 },
        Color = { 255, 253, 169 },
        Decay = { 191, 161, 118 }
    },
    Tokyo = {
        Density = 0.2,
        Offset = 0,
        Glare = 1.5,
        Haze = 2.2,
        Brightness = -0.5,
        GeographicLatitude = 175,
        Night = { 100, 84, 73 },
        Color = { 255, 197, 158 },
        Decay = { 0, 170, 255 },
        Ambient = Color3.fromRGB(65, 65, 63),
        ColorShift = Color3.fromRGB(0, 0, 0),
        OutdoorAmbient = Color3.fromRGB(94, 94, 91),
        ColorCorrection = {
            Brightness = 0.05,
            Contrast = 0.2,
            Saturation = 0,
            TintColor = Color3.fromRGB(244, 229, 229)
        }
    },
    Coast = {
        Density = 0.25,
        Offset = 0,
        Glare = 0.76,
        Haze = 2.1,
        Brightness = 0.5,
        GeographicLatitude = 0,
        Night = { 116, 84, 83 },
        Color = { 220, 179, 179 },
        Decay = { 255, 246, 219 },
        Ambient = Color3.fromRGB(0, 0, 0),
        ColorShift = Color3.fromRGB(0, 0, 0),
        OutdoorAmbient = Color3.fromRGB(70, 69, 63),
        ColorCorrection = {
            Brightness = 0.1,
            Contrast = 0.3,
            Saturation = 0,
            TintColor = Color3.fromRGB(212, 199, 199)
        }
    },
    Favela = {
        Density = 0.2,
        Offset = 0.25,
        Glare = 0.8,
        Haze = 2.2,
        Brightness = 0.5,
        GeographicLatitude = 23,
        Night = { 86, 97, 109 },
        Color = { 255, 255, 255 },
        Decay = { 230, 184, 153 },
        Ambient = Color3.fromRGB(0, 0, 0),
        ColorShift = Color3.fromRGB(0, 0, 0),
        OutdoorAmbient = Color3.fromRGB(81, 79, 70),
        ColorCorrection = {
            Brightness = 0.1,
            Contrast = 0.3,
            Saturation = 0,
            TintColor = Color3.fromRGB(212, 202, 195)
        }
    },
    NYC = {
        Density = 0.225,
        Offset = 0,
        Glare = 0.76,
        Haze = 2.5,
        GeographicLatitude = 52,
        Night = { 21, 29, 48 },
        Color = { 192, 212, 221 },
        Decay = { 255, 241, 198 }
    },
    Office = {
        Density = 0.4,
        Offset = 0.45,
        Glare = 0.7,
        Haze = 2.15,
        Night = { 21, 29, 48 },
        Color = { 147, 111, 111 },
        Decay = { 195, 191, 185 },
        ColorCorrection = {
            Contrast = 0.04,
            Brightness = 0,
            Saturation = 0,
            TintColor = Color3.fromRGB(255, 246, 231)
        }
    },
    Maya = {
        Density = 0.35,
        Offset = 0,
        Glare = 1.5,
        Haze = 2.2,
        Brightness = -0.5,
        Night = { 212, 233, 255 },
        Color = { 255, 203, 204 },
        Decay = { 184, 216, 255 },
        Ambient = Color3.fromRGB(94, 94, 91),
        ColorShift = Color3.fromRGB(0, 0, 0),
        OutdoorAmbient = Color3.fromRGB(94, 94, 91),
        ColorCorrection = {
            Brightness = 0.1,
            Contrast = 0.3,
            Saturation = 0,
            TintColor = Color3.fromRGB(212, 203, 207)
        }
    },
    Lookout = {
        Density = 0.35,
        Offset = 0,
        Glare = 1.5,
        Haze = 2.3,
        Brightness = -0.5,
        Night = { 80, 90, 125 },
        Color = { 255, 183, 176 },
        Decay = { 144, 172, 200 },
        Ambient = Color3.fromRGB(67, 67, 67),
        ColorShift = Color3.fromRGB(0, 0, 0),
        OutdoorAmbient = Color3.fromRGB(70, 70, 70),
        ColorCorrection = {
            Brightness = 0.1,
            Contrast = 0.3,
            Saturation = 0,
            TintColor = Color3.fromRGB(255, 240, 220)
        }
    },
    NYCZombies = {
        Density = 0.235,
        Offset = 0,
        Glare = 0.76,
        Haze = 3.16,
        Night = { 37, 48, 59 },
        Color = { 191, 148, 130 },
        Decay = { 231, 231, 195 },
        ColorCorrection = {
            Contrast = 0,
            Brightness = 0.03,
            Saturation = 0,
            TintColor = Color3.fromRGB(208, 212, 203)
        }
    },
    NYCZombiesSnow = {
        Density = 0.35,
        Offset = 0,
        Glare = 0.76,
        Haze = 3.16,
        Night = { 37, 48, 59 },
        Color = { 169, 192, 209 },
        Decay = { 203, 223, 231 },
        ColorCorrection = {
            Contrast = 0,
            Brightness = 0.03,
            Saturation = -0.25,
            TintColor = Color3.fromRGB(184, 192, 198)
        }
    },
    Sawang = {
        Density = 0.2,
        Offset = 0.25,
        Glare = 0.62,
        Haze = 0,
        Brightness = 3,
        Night = { 40, 40, 40 },
        Color = { 112, 145, 171 },
        Decay = { 218, 212, 227 },
        ColorShift = Color3.fromRGB(232, 217, 135),
        OutdoorAmbient = Color3.fromRGB(168, 150, 49),
        Ambient = Color3.fromRGB(152, 147, 118)
    },
    ElChara = {
        Density = 0.3,
        Offset = 0,
        Glare = 1.5,
        Haze = 2.25,
        Brightness = 0.5,
        GeographicLatitude = 56.65,
        Night = { 52, 53, 67 },
        Color = { 85, 95, 152 },
        Decay = { 190, 176, 166 },
        Ambient = Color3.fromRGB(65, 65, 63),
        ColorShift = Color3.fromRGB(0, 0, 0),
        OutdoorAmbient = Color3.fromRGB(94, 94, 91),
        ColorCorrection = {
            Brightness = 0.1,
            Contrast = 0.3,
            Saturation = 0,
            TintColor = Color3.fromRGB(255, 244, 239)
        }
    },
    Palace = {
        Density = 0.25,
        Offset = 0,
        Glare = 1.5,
        Haze = 2.2,
        Brightness = 0.5,
        GeographicLatitude = 0,
        Night = { 11, 104, 104 },
        Color = { 0, 217, 134 },
        Decay = { 222, 173, 152 },
        Ambient = Color3.fromRGB(65, 65, 63),
        ColorShift = Color3.fromRGB(0, 0, 0),
        OutdoorAmbient = Color3.fromRGB(94, 94, 91),
        ColorCorrection = {
            Brightness = 0.1,
            Contrast = 0.15,
            Saturation = 0,
            TintColor = Color3.fromRGB(255, 236, 231)
        }
    },
    ArcticBase = {
        Density = 0.425,
        Offset = 0,
        Glare = 1.5,
        Haze = 2.3,
        Brightness = -0.5,
        GeographicLatitude = 0,
        Night = { 110, 116, 122 },
        Color = { 200, 181, 202 },
        Decay = { 129, 118, 106 },
        Ambient = Color3.fromRGB(67, 67, 67),
        ColorShift = Color3.fromRGB(0, 0, 0),
        OutdoorAmbient = Color3.fromRGB(70, 70, 70),
        ColorCorrection = {
            Brightness = 0.1,
            Contrast = 0.3,
            Saturation = 0,
            TintColor = Color3.fromRGB(248, 255, 250)
        }
    },
    PowerPlant = {
        Density = 0.3,
        Offset = 0,
        Glare = 2.5,
        Haze = 2.05,
        Brightness = 0,
        GeographicLatitude = 0,
        Night = { 99, 117, 114 },
        Color = { 93, 118, 170 },
        Decay = { 150, 148, 145 },
        Ambient = Color3.fromRGB(94, 94, 91),
        ColorShift = Color3.fromRGB(0, 0, 0),
        OutdoorAmbient = Color3.fromRGB(94, 94, 91),
        ColorCorrection = {
            Brightness = 0.1,
            Contrast = 0.25,
            Saturation = 0,
            TintColor = Color3.fromRGB(242, 255, 255)
        }
    },
    TESTDONOTCHANGE = {
        Density = 0.6,
        Offset = 0,
        Glare = 0,
        Haze = 2.1,
        OutdoorAmbient = Color3.fromRGB(200, 200, 200),
        Night = { 0, 0, 0 },
        Color = { 0, 0, 0 },
        Decay = { 0, 0, 0 },
        ColorCorrection = {
            Contrast = 0.05,
            Brightness = 0,
            Saturation = 0,
            TintColor = Color3.new(1, 1, 1)
        }
    }
};