-- Roblox: ReplicatedStorage.Shared.Configs.Environment.TimeOfDay
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Menu = { 12 },
    Seychelles = { 7 },
    Tokyo = {
        10,
        14,
        12,
        12,
        12,
        12,
        0
    },
    Metro = { 8 },
    Coast = {
        10,
        14,
        12,
        12,
        12,
        12,
        0
    },
    Office = {
        5,
        12,
        12,
        12,
        17
    },
    Favela = {
        10,
        14,
        12,
        12,
        12,
        12,
        0
    },
    Maya = {
        10,
        14,
        12,
        12,
        12,
        12,
        0
    },
    Lookout = {
        10,
        14,
        12,
        12,
        12,
        12,
        0
    },
    NYC = {
        0,
        1,
        4,
        5,
        5.75,
        7,
        9,
        10,
        11,
        11.75,
        12,
        13,
        15.5,
        18,
        19,
        21,
        23
    },
    ElChara = {
        10,
        14,
        12,
        12,
        0
    },
    Palace = {
        10,
        14,
        12,
        12,
        0
    },
    ArcticBase = {
        10,
        12,
        12,
        12,
        0
    },
    PowerPlant = {
        10,
        11,
        12,
        12,
        13,
        0,
        0
    },
    Blank = { 7 },
    Default = { 7 }
};