-- Roblox: ReplicatedStorage.Shared.Configs.Environment.LunarPhases
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    { 12720439926, 0.1 },
    { 12720439779, 0.3 },
    { 12720439602, 0.5 },
    { 12720439459, 0.75 },
    { 12720439184, 1 },
    { 12720438990, 0.75 },
    { 12720438803, 0.5 },
    { 12720438656, 0.3 }
};