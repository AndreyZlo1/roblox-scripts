-- Roblox: ReplicatedStorage.Shared.Configs.AmmoCost
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    [".300 Winchester Magnum"] = {
        Price = 0,
        Max = 60,
        Timer = 5
    },
    [".338 Lapua Magnum"] = {
        Price = 0,
        Max = 60,
        Timer = 5
    },
    [".44 Millington Magnum"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    [".45 Auto"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    ["12-gauge"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    ["12.7×108mm (linked)"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    ["12.7×99mm NATO (linked)"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    ["12.7×99mm NATO"] = {
        Price = 0,
        Max = 40,
        Timer = 5
    },
    ["4.6×30mm"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    ["5.45×39mm"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    ["5.56×45mm NATO"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    [".300 SRC Knockout"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    ["5.7×28mm"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    ["6.5×48mm Fidelis"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    ["7.62×39mm"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    ["7.62×51mm NATO (linked)"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    ["7.62×51mm NATO"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    ["7.62×54mmR (linked)"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    ["7.62×54mmR"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    ["9×18mm Makarov"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    ["9×19mm Parabellum"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    ["9×21mm Gyurza"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    },
    ["9×39mm"] = {
        Price = 0,
        Max = 200,
        Timer = 5
    }
};