-- Roblox: ReplicatedStorage.Shared.Configs.CasingMaterials
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    [Enum.Material.Grass] = "Dirt",
    [Enum.Material.LeafyGrass] = "Dirt",
    [Enum.Material.Ground] = "Dirt",
    [Enum.Material.Mud] = "Dirt",
    [Enum.Material.Sand] = "Dirt",
    [Enum.Material.Limestone] = "Concrete",
    [Enum.Material.Sandstone] = "Concrete",
    [Enum.Material.Plastic] = "Concrete",
    [Enum.Material.SmoothPlastic] = "Concrete",
    [Enum.Material.Brick] = "Concrete",
    [Enum.Material.Pebble] = "Concrete",
    [Enum.Material.Pavement] = "Concrete",
    [Enum.Material.Concrete] = "Concrete",
    [Enum.Material.Foil] = "Concrete",
    [Enum.Material.Cobblestone] = "Concrete",
    [Enum.Material.Wood] = "Wood",
    [Enum.Material.WoodPlanks] = "Wood",
    [Enum.Material.Slate] = "Concrete",
    [Enum.Material.Basalt] = "Concrete",
    [Enum.Material.Asphalt] = "Concrete",
    [Enum.Material.Rock] = "Concrete",
    [Enum.Material.CrackedLava] = "Concrete",
    [Enum.Material.Granite] = "Concrete",
    [Enum.Material.Snow] = "Dirt",
    [Enum.Material.Salt] = "Dirt",
    [Enum.Material.Glacier] = "Concrete",
    [Enum.Material.Fabric] = "Dirt",
    [Enum.Material.Glass] = "Dirt",
    [Enum.Material.Ice] = "Concrete",
    [Enum.Material.Metal] = "Metal",
    [Enum.Material.Marble] = "Concrete",
    [Enum.Material.CorrodedMetal] = "Metal",
    [Enum.Material.DiamondPlate] = "Metal"
};