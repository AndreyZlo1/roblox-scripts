-- Roblox: ReplicatedStorage.Shared.Configs.Animation.Animations.VehicleAnimation
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Ground = {
        Humvee = {
            Startup = {
                _animation = 15346370004
            }
        }
    }
};