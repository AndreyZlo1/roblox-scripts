-- Roblox: ReplicatedStorage.Shared.Configs.Animation.Animations.MeleeAnimations
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Hooligan = {
        FP = {
            Equip = {
                _animation = 12139593948
            },
            Sprint = {
                _animation = 132119370933005
            },
            Idle = {
                _animation = 12139595681
            },
            Hit1 = {
                _animation = 12139597272
            },
            Hit2 = {
                _animation = 12139598710
            },
            Hit3 = {
                _animation = 12139601301
            }
        },
        TP = {
            Equip = {
                _animation = 12139580358
            },
            Idle = {
                _animation = 12139582530
            },
            Hit1 = {
                _animation = 12139584370
            },
            Hit2 = {
                _animation = 12139585845
            },
            Hit3 = {
                _animation = 12139588677
            },
            BreachLeft = {
                _animation = 114300832266249
            },
            BreachRight = {
                _animation = 133199405882251
            }
        }
    },
    Crowbar = {
        FP = {
            Equip = {
                _animation = 12361584863
            },
            Sprint = {
                _animation = 132119370933005
            },
            Idle = {
                _animation = 12361586137
            },
            Hit1 = {
                _animation = 12361587592
            },
            Hit2 = {
                _animation = 12361588771
            },
            Hit3 = {
                _animation = 12361595151
            }
        },
        TP = {
            Equip = {
                _animation = 12139580358
            },
            Idle = {
                _animation = 12139582530
            },
            Hit1 = {
                _animation = 12139584370
            },
            Hit2 = {
                _animation = 12139585845
            },
            Hit3 = {
                _animation = 12139588677
            }
        }
    },
    CrowbarRed = {
        FP = {
            Equip = {
                _animation = 12361584863
            },
            Sprint = {
                _animation = 132119370933005
            },
            Idle = {
                _animation = 12361586137
            },
            Hit1 = {
                _animation = 12361587592
            },
            Hit2 = {
                _animation = 12361588771
            },
            Hit3 = {
                _animation = 12361595151
            }
        },
        TP = {
            Equip = {
                _animation = 12139580358
            },
            Idle = {
                _animation = 12139582530
            },
            Hit1 = {
                _animation = 12139584370
            },
            Hit2 = {
                _animation = 12139585845
            },
            Hit3 = {
                _animation = 12139588677
            }
        }
    },
    CrowbarBlue = {
        FP = {
            Equip = {
                _animation = 12361584863
            },
            Sprint = {
                _animation = 132119370933005
            },
            Idle = {
                _animation = 12361586137
            },
            Hit1 = {
                _animation = 12361587592
            },
            Hit2 = {
                _animation = 12361588771
            },
            Hit3 = {
                _animation = 12361595151
            }
        },
        TP = {
            Equip = {
                _animation = 12139580358
            },
            Idle = {
                _animation = 12139582530
            },
            Hit1 = {
                _animation = 12139584370
            },
            Hit2 = {
                _animation = 12139585845
            },
            Hit3 = {
                _animation = 12139588677
            }
        }
    },
    Bat = {
        FP = {
            Equip = {
                _animation = 12361584863
            },
            Sprint = {
                _animation = 132119370933005
            },
            Idle = {
                _animation = 12361586137
            },
            Hit1 = {
                _animation = 12361587592
            },
            Hit2 = {
                _animation = 12361588771
            },
            Hit3 = {
                _animation = 12361595151
            }
        },
        TP = {
            Equip = {
                _animation = 12139580358
            },
            Idle = {
                _animation = 12139582530
            },
            Hit1 = {
                _animation = 12139584370
            },
            Hit2 = {
                _animation = 12139585845
            },
            Hit3 = {
                _animation = 12139588677
            }
        }
    },
    BatGrip = {
        FP = {
            Equip = {
                _animation = 12361584863
            },
            Sprint = {
                _animation = 132119370933005
            },
            Idle = {
                _animation = 12361586137
            },
            Hit1 = {
                _animation = 12361587592
            },
            Hit2 = {
                _animation = 12361588771
            },
            Hit3 = {
                _animation = 12361595151
            }
        },
        TP = {
            Equip = {
                _animation = 12139580358
            },
            Idle = {
                _animation = 12139582530
            },
            Hit1 = {
                _animation = 12139584370
            },
            Hit2 = {
                _animation = 12139585845
            },
            Hit3 = {
                _animation = 12139588677
            }
        }
    },
    NailBat = {
        FP = {
            Equip = {
                _animation = 12361584863
            },
            Sprint = {
                _animation = 132119370933005
            },
            Idle = {
                _animation = 12361586137
            },
            Hit1 = {
                _animation = 12361587592
            },
            Hit2 = {
                _animation = 12361588771
            },
            Hit3 = {
                _animation = 12361595151
            }
        },
        TP = {
            Equip = {
                _animation = 12139580358
            },
            Idle = {
                _animation = 12139582530
            },
            Hit1 = {
                _animation = 12139584370
            },
            Hit2 = {
                _animation = 12139585845
            },
            Hit3 = {
                _animation = 12139588677
            }
        }
    },
    MetalBat = {
        FP = {
            Equip = {
                _animation = 12361584863
            },
            Sprint = {
                _animation = 132119370933005
            },
            Idle = {
                _animation = 12361586137
            },
            Hit1 = {
                _animation = 12361587592
            },
            Hit2 = {
                _animation = 12361588771
            },
            Hit3 = {
                _animation = 12361595151
            }
        },
        TP = {
            Equip = {
                _animation = 12139580358
            },
            Idle = {
                _animation = 12139582530
            },
            Hit1 = {
                _animation = 12139584370
            },
            Hit2 = {
                _animation = 12139585845
            },
            Hit3 = {
                _animation = 12139588677
            }
        }
    },
    Plank = {
        FP = {
            Equip = {
                _animation = 12361584863
            },
            Sprint = {
                _animation = 132119370933005
            },
            Idle = {
                _animation = 12361586137
            },
            Hit1 = {
                _animation = 12361587592
            },
            Hit2 = {
                _animation = 12361588771
            },
            Hit3 = {
                _animation = 12361595151
            }
        },
        TP = {
            Equip = {
                _animation = 12139580358
            },
            Idle = {
                _animation = 12139582530
            },
            Hit1 = {
                _animation = 12139584370
            },
            Hit2 = {
                _animation = 12139585845
            },
            Hit3 = {
                _animation = 12139588677
            }
        }
    },
    Tomahawk = {
        FP = {
            Equip = {
                _animation = 12361584863
            },
            Sprint = {
                _animation = 132119370933005
            },
            Idle = {
                _animation = 12361586137
            },
            Hit1 = {
                _animation = 12361587592
            },
            Hit2 = {
                _animation = 12361588771
            },
            Hit3 = {
                _animation = 12361595151
            }
        },
        TP = {
            Equip = {
                _animation = 12139580358
            },
            Idle = {
                _animation = 12139582530
            },
            Hit1 = {
                _animation = 12139584370
            },
            Hit2 = {
                _animation = 12139585845
            },
            Hit3 = {
                _animation = 12139588677
            }
        }
    },
    Pipe = {
        FP = {
            Equip = {
                _animation = 12139641273
            },
            Sprint = {
                _animation = 74199700687732
            },
            Idle = {
                _animation = 12139642834
            },
            Hit1 = {
                _animation = 12139644615
            },
            Hit2 = {
                _animation = 12139646144
            },
            Hit3 = {
                _animation = 12139649404
            }
        },
        TP = {
            Equip = {
                _animation = 12361599804
            },
            Idle = {
                _animation = 12139631748
            },
            Hit1 = {
                _animation = 12139634491
            },
            Hit2 = {
                _animation = 12139636642
            },
            Hit3 = {
                _animation = 12139639181
            }
        }
    },
    PipeWrench = {
        FP = {
            Equip = {
                _animation = 12361607497
            },
            Sprint = {
                _animation = 74199700687732
            },
            Idle = {
                _animation = 12361606531
            },
            Hit1 = {
                _animation = 12361608393
            },
            Hit2 = {
                _animation = 12361609032
            },
            Hit3 = {
                _animation = 12361610845
            }
        },
        TP = {
            Equip = {
                _animation = 12139604480
            },
            Idle = {
                _animation = 12139631748
            },
            Hit1 = {
                _animation = 12139634491
            },
            Hit2 = {
                _animation = 12139636642
            },
            Hit3 = {
                _animation = 12139639181
            }
        }
    },
    Hatchet = {
        FP = {
            Equip = {
                _animation = 12361607497
            },
            Sprint = {
                _animation = 74199700687732
            },
            Idle = {
                _animation = 12361606531
            },
            Hit1 = {
                _animation = 12361608393
            },
            Hit2 = {
                _animation = 12361609032
            },
            Hit3 = {
                _animation = 12361610845
            }
        },
        TP = {
            Equip = {
                _animation = 12139604480
            },
            Idle = {
                _animation = 12139631748
            },
            Hit1 = {
                _animation = 12139634491
            },
            Hit2 = {
                _animation = 12139636642
            },
            Hit3 = {
                _animation = 12139639181
            }
        }
    },
    M9_Bayonet = {
        FP = {
            Equip = {
                _animation = 12139613233
            },
            Sprint = {
                _animation = 74199700687732
            },
            Idle = {
                _animation = 12139615801
            },
            Hit1 = {
                _animation = 12139617261
            },
            Hit2 = {
                _animation = 12139619485
            },
            Hit3 = {
                _animation = 12139622290
            }
        },
        TP = {
            Equip = {
                _animation = 12139604480
            },
            Idle = {
                _animation = 12139606382
            },
            Hit1 = {
                _animation = 12139607914
            },
            Hit2 = {
                _animation = 12139609417
            },
            Hit3 = {
                _animation = 12139611101
            }
        }
    },
    Machete = {
        FP = {
            Equip = {
                _animation = 12139641273
            },
            Sprint = {
                _animation = 74199700687732
            },
            Idle = {
                _animation = 12139642834
            },
            Hit1 = {
                _animation = 12139644615
            },
            Hit2 = {
                _animation = 12139646144
            },
            Hit3 = {
                _animation = 12139649404
            }
        },
        TP = {
            Equip = {
                _animation = 12361599804
            },
            Idle = {
                _animation = 12139631748
            },
            Hit1 = {
                _animation = 12139634491
            },
            Hit2 = {
                _animation = 12139636642
            },
            Hit3 = {
                _animation = 12139639181
            }
        }
    },
    Taiga = {
        FP = {
            Equip = {
                _animation = 12361607497
            },
            Sprint = {
                _animation = 74199700687732
            },
            Idle = {
                _animation = 12361606531
            },
            Hit1 = {
                _animation = 12361608393
            },
            Hit2 = {
                _animation = 12361609032
            },
            Hit3 = {
                _animation = 12361610845
            }
        },
        TP = {
            Equip = {
                _animation = 12139604480
            },
            Idle = {
                _animation = 12139631748
            },
            Hit1 = {
                _animation = 12139634491
            },
            Hit2 = {
                _animation = 12139636642
            },
            Hit3 = {
                _animation = 12139639181
            }
        }
    },
    SOCP = {
        FP = {
            Equip = {
                _animation = 12361599804
            },
            Sprint = {
                _animation = 74199700687732
            },
            Idle = {
                _animation = 12361598219
            },
            Hit1 = {
                _animation = 12361600849
            },
            Hit2 = {
                _animation = 12361601663
            },
            Hit3 = {
                _animation = 12361603257
            }
        },
        TP = {
            Equip = {
                _animation = 12139604480
            },
            Idle = {
                _animation = 12139606382
            },
            Hit1 = {
                _animation = 12139607914
            },
            Hit2 = {
                _animation = 12139609417
            },
            Hit3 = {
                _animation = 12139611101
            }
        }
    },
    MI211 = {
        FP = {
            Equip = {
                _animation = 12139613233
            },
            Sprint = {
                _animation = 74199700687732
            },
            Idle = {
                _animation = 12139615801
            },
            Hit1 = {
                _animation = 12139617261
            },
            Hit2 = {
                _animation = 12139619485
            },
            Hit3 = {
                _animation = 12139622290
            }
        },
        TP = {
            Equip = {
                _animation = 12139604480
            },
            Idle = {
                _animation = 12139606382
            },
            Hit1 = {
                _animation = 12139607914
            },
            Hit2 = {
                _animation = 12139609417
            },
            Hit3 = {
                _animation = 12139611101
            }
        }
    },
    SealPup = {
        FP = {
            Equip = {
                _animation = 12139613233
            },
            Sprint = {
                _animation = 74199700687732
            },
            Idle = {
                _animation = 12139615801
            },
            Hit1 = {
                _animation = 12139617261
            },
            Hit2 = {
                _animation = 12139619485
            },
            Hit3 = {
                _animation = 12139622290
            }
        },
        TP = {
            Equip = {
                _animation = 12139604480
            },
            Idle = {
                _animation = 12139606382
            },
            Hit1 = {
                _animation = 12139607914
            },
            Hit2 = {
                _animation = 12139609417
            },
            Hit3 = {
                _animation = 12139611101
            }
        }
    },
    KitchenKnife = {
        FP = {
            Equip = {
                _animation = 12139613233
            },
            Sprint = {
                _animation = 74199700687732
            },
            Idle = {
                _animation = 12139615801
            },
            Hit1 = {
                _animation = 12139617261
            },
            Hit2 = {
                _animation = 12139619485
            },
            Hit3 = {
                _animation = 12139622290
            }
        },
        TP = {
            Equip = {
                _animation = 12139604480
            },
            Idle = {
                _animation = 12139606382
            },
            Hit1 = {
                _animation = 12139607914
            },
            Hit2 = {
                _animation = 12139609417
            },
            Hit3 = {
                _animation = 12139611101
            }
        }
    },
    KitchenKnifeLong = {
        FP = {
            Equip = {
                _animation = 12139613233
            },
            Sprint = {
                _animation = 74199700687732
            },
            Idle = {
                _animation = 12139615801
            },
            Hit1 = {
                _animation = 12139617261
            },
            Hit2 = {
                _animation = 12139619485
            },
            Hit3 = {
                _animation = 12139622290
            }
        },
        TP = {
            Equip = {
                _animation = 12139604480
            },
            Idle = {
                _animation = 12139606382
            },
            Hit1 = {
                _animation = 12139607914
            },
            Hit2 = {
                _animation = 12139609417
            },
            Hit3 = {
                _animation = 12139611101
            }
        }
    },
    KitchenCleaver = {
        FP = {
            Equip = {
                _animation = 12139641273
            },
            Sprint = {
                _animation = 74199700687732
            },
            Idle = {
                _animation = 12139642834
            },
            Hit1 = {
                _animation = 12139644615
            },
            Hit2 = {
                _animation = 12139646144
            },
            Hit3 = {
                _animation = 12139649404
            }
        },
        TP = {
            Equip = {
                _animation = 12361599804
            },
            Idle = {
                _animation = 12139631748
            },
            Hit1 = {
                _animation = 12139634491
            },
            Hit2 = {
                _animation = 12139636642
            },
            Hit3 = {
                _animation = 12139639181
            }
        }
    },
    KitchenKnifeWood = {
        FP = {
            Equip = {
                _animation = 12139613233
            },
            Sprint = {
                _animation = 74199700687732
            },
            Idle = {
                _animation = 12139615801
            },
            Hit1 = {
                _animation = 12139617261
            },
            Hit2 = {
                _animation = 12139619485
            },
            Hit3 = {
                _animation = 12139622290
            }
        },
        TP = {
            Equip = {
                _animation = 12139604480
            },
            Idle = {
                _animation = 12139606382
            },
            Hit1 = {
                _animation = 12139607914
            },
            Hit2 = {
                _animation = 12139609417
            },
            Hit3 = {
                _animation = 12139611101
            }
        }
    },
    KitchenKnifeLongWood = {
        FP = {
            Equip = {
                _animation = 12139613233
            },
            Sprint = {
                _animation = 74199700687732
            },
            Idle = {
                _animation = 12139615801
            },
            Hit1 = {
                _animation = 12139617261
            },
            Hit2 = {
                _animation = 12139619485
            },
            Hit3 = {
                _animation = 12139622290
            }
        },
        TP = {
            Equip = {
                _animation = 12139604480
            },
            Idle = {
                _animation = 12139606382
            },
            Hit1 = {
                _animation = 12139607914
            },
            Hit2 = {
                _animation = 12139609417
            },
            Hit3 = {
                _animation = 12139611101
            }
        }
    },
    KitchenCleaverWood = {
        FP = {
            Equip = {
                _animation = 12139641273
            },
            Sprint = {
                _animation = 74199700687732
            },
            Idle = {
                _animation = 12139642834
            },
            Hit1 = {
                _animation = 12139644615
            },
            Hit2 = {
                _animation = 12139646144
            },
            Hit3 = {
                _animation = 12139649404
            }
        },
        TP = {
            Equip = {
                _animation = 12361599804
            },
            Idle = {
                _animation = 12139631748
            },
            Hit1 = {
                _animation = 12139634491
            },
            Hit2 = {
                _animation = 12139636642
            },
            Hit3 = {
                _animation = 12139639181
            }
        }
    }
};