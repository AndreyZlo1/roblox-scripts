-- Roblox: ReplicatedStorage.Shared.Configs.Animation.Animations.ZombiePacks
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    SprinterAlerted = {
        Idle = {
            Standing = {
                _animation = 116657455917578
            },
            Prone = {
                _animation = 15766503964,
                Length = 0.6,
                Is360 = true
            }
        },
        Walk = {
            N = {
                _animation = 137045309735522,
                Duration = 0.5333333333333333,
                Speed = 16
            },
            NE = {
                _animation = 129990725668072
            },
            NW = {
                _animation = 131633225623925
            }
        },
        Prone = {
            N = {
                _animation = 15766669099,
                Duration = 0.8,
                Speed = 5
            },
            NE = {
                _animation = 15766893356
            },
            E = {
                _animation = 15766672504
            },
            SE = {
                _animation = 15766894488
            },
            S = {
                _animation = 15766674118
            },
            SW = {
                _animation = 15766896110
            },
            W = {
                _animation = 15766675627
            },
            NW = {
                _animation = 15766897461
            }
        }
    },
    SprinterIdle = {
        Idle = {
            Standing = {
                _animation = 116657455917578
            },
            Prone = {
                _animation = 15766503964,
                Length = 0.6,
                Is360 = true
            }
        },
        Walk = {
            N = {
                _animation = 137045309735522,
                Duration = 0.5333333333333333,
                Speed = 16
            },
            NE = {
                _animation = 129990725668072
            },
            NW = {
                _animation = 131633225623925
            }
        },
        Prone = {
            N = {
                _animation = 15766669099,
                Duration = 0.8,
                Speed = 5
            },
            NE = {
                _animation = 15766893356
            },
            E = {
                _animation = 15766672504
            },
            SE = {
                _animation = 15766894488
            },
            S = {
                _animation = 15766674118
            },
            SW = {
                _animation = 15766896110
            },
            W = {
                _animation = 15766675627
            },
            NW = {
                _animation = 15766897461
            }
        }
    },
    NormalAlerted = {
        Idle = {
            Standing = {
                _animation = 108979680978601
            },
            Prone = {
                _animation = 15766503964,
                Length = 0.6,
                Is360 = true
            }
        },
        Walk = {
            N = {
                _animation = 138692815082878,
                Duration = 0.7333333333333333,
                Speed = 12
            },
            NE = {
                _animation = 121427267934441
            },
            NW = {
                _animation = 126708158224927
            }
        },
        Prone = {
            N = {
                _animation = 15766669099,
                Duration = 0.8,
                Speed = 5
            },
            NE = {
                _animation = 15766893356
            },
            E = {
                _animation = 15766672504
            },
            SE = {
                _animation = 15766894488
            },
            S = {
                _animation = 15766674118
            },
            SW = {
                _animation = 15766896110
            },
            W = {
                _animation = 15766675627
            },
            NW = {
                _animation = 15766897461
            }
        }
    },
    NormalIdle = {
        Idle = {
            Standing = {
                _animation = 108979680978601
            },
            Prone = {
                _animation = 15766503964,
                Length = 0.6,
                Is360 = true
            }
        },
        Walk = {
            N = {
                _animation = 138692815082878,
                Duration = 0.7333333333333333,
                Speed = 12
            },
            NE = {
                _animation = 121427267934441
            },
            NW = {
                _animation = 126708158224927
            }
        },
        Prone = {
            N = {
                _animation = 15766669099,
                Duration = 0.8,
                Speed = 5
            },
            NE = {
                _animation = 15766893356
            },
            E = {
                _animation = 15766672504
            },
            SE = {
                _animation = 15766894488
            },
            S = {
                _animation = 15766674118
            },
            SW = {
                _animation = 15766896110
            },
            W = {
                _animation = 15766675627
            },
            NW = {
                _animation = 15766897461
            }
        }
    },
    SlowAlerted = {
        Idle = {
            Standing = {
                _animation = 129463159939379
            },
            Prone = {
                _animation = 15766503964,
                Length = 0.6,
                Is360 = true
            }
        },
        Walk = {
            N = {
                _animation = 119722196612665,
                Duration = 1.1,
                Speed = 6
            },
            NE = {
                _animation = 129523167416417
            },
            NW = {
                _animation = 116505541432658
            }
        },
        Prone = {
            N = {
                _animation = 15766669099,
                Duration = 0.8,
                Speed = 5
            },
            NE = {
                _animation = 15766893356
            },
            E = {
                _animation = 15766672504
            },
            SE = {
                _animation = 15766894488
            },
            S = {
                _animation = 15766674118
            },
            SW = {
                _animation = 15766896110
            },
            W = {
                _animation = 15766675627
            },
            NW = {
                _animation = 15766897461
            }
        }
    },
    SlowIdle = {
        Idle = {
            Standing = {
                _animation = 129463159939379
            },
            Prone = {
                _animation = 15766503964,
                Length = 0.6,
                Is360 = true
            }
        },
        Walk = {
            N = {
                _animation = 119722196612665,
                Duration = 1.1,
                Speed = 6
            },
            NE = {
                _animation = 129523167416417
            },
            NW = {
                _animation = 116505541432658
            }
        },
        Prone = {
            N = {
                _animation = 15766669099,
                Duration = 0.8,
                Speed = 5
            },
            NE = {
                _animation = 15766893356
            },
            E = {
                _animation = 15766672504
            },
            SE = {
                _animation = 15766894488
            },
            S = {
                _animation = 15766674118
            },
            SW = {
                _animation = 15766896110
            },
            W = {
                _animation = 15766675627
            },
            NW = {
                _animation = 15766897461
            }
        }
    },
    CrippledAlerted = {
        Idle = {
            Standing = {
                _animation = 138463221349557
            },
            Prone = {
                _animation = 15766503964,
                Length = 0.6,
                Is360 = true
            }
        },
        Walk = {
            N = {
                _animation = 134472010421884,
                Duration = 2.433333333333333,
                Speed = 3
            },
            NE = {
                _animation = 128794601063308
            },
            NW = {
                _animation = 109386097934564
            }
        },
        Prone = {
            N = {
                _animation = 15766669099,
                Duration = 0.8,
                Speed = 5
            },
            NE = {
                _animation = 15766893356
            },
            E = {
                _animation = 15766672504
            },
            SE = {
                _animation = 15766894488
            },
            S = {
                _animation = 15766674118
            },
            SW = {
                _animation = 15766896110
            },
            W = {
                _animation = 15766675627
            },
            NW = {
                _animation = 15766897461
            }
        }
    },
    CrippledIdle = {
        Idle = {
            Standing = {
                _animation = 138463221349557
            },
            Prone = {
                _animation = 15766503964,
                Length = 0.6,
                Is360 = true
            }
        },
        Walk = {
            N = {
                _animation = 134472010421884,
                Duration = 2.433333333333333,
                Speed = 3
            },
            NE = {
                _animation = 128794601063308
            },
            NW = {
                _animation = 109386097934564
            }
        },
        Prone = {
            N = {
                _animation = 15766669099,
                Duration = 0.8,
                Speed = 5
            },
            NE = {
                _animation = 15766893356
            },
            E = {
                _animation = 15766672504
            },
            SE = {
                _animation = 15766894488
            },
            S = {
                _animation = 15766674118
            },
            SW = {
                _animation = 15766896110
            },
            W = {
                _animation = 15766675627
            },
            NW = {
                _animation = 15766897461
            }
        }
    }
};