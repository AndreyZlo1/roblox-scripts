-- Roblox: ReplicatedStorage.Shared.Configs.Animation.Animations.ZombieAnimations
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Flinch = {
        RightArm = {
            _animation = 82546137126782
        },
        LeftArm = {
            _animation = 108761172522197
        },
        Torso = {
            _animation = 117837168044284
        }
    },
    Fall = {
        Right = {
            _animation = 130207501411653
        },
        Left = {
            _animation = 117363613498849
        }
    }
};