-- Roblox: ReplicatedStorage.Shared.Configs.Animation.Animations.CharacterPacks
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Unequipped = {
        Idle = {
            Standing = {
                _animation = 15605227537
            },
            Crouch = {
                _animation = 15678776301
            },
            Prone = {
                _animation = 15766503964,
                Length = 0.6,
                Is360 = true
            },
            Slide = {
                _animation = 15678829757
            },
            IdleToProne = {
                _animation = 15766795748
            },
            ProneToIdle = {
                _animation = 15766804000
            },
            CrouchToProne = {
                _animation = 15766805980
            },
            ProneToCrouch = {
                _animation = 15766808994
            }
        },
        Sprint = {
            N = {
                _animation = 15636356678,
                Duration = 0.5333333333333333,
                Speed = 16
            },
            NE = {
                _animation = 15636363279
            },
            NW = {
                _animation = 15636365170
            }
        },
        Jog = {
            N = {
                _animation = 15543456284,
                Duration = 0.6666666666666666,
                Speed = 12
            },
            NE = {
                _animation = 15566222846
            },
            E = {
                _animation = 15543467513
            },
            SE = {
                _animation = 15566221023
            },
            S = {
                _animation = 15543470157
            },
            SW = {
                _animation = 15566219691
            },
            W = {
                _animation = 15543472156
            },
            NW = {
                _animation = 15566221937
            }
        },
        Crouch = {
            N = {
                _animation = 15678763009,
                Duration = 0.6666666666666666,
                Speed = 10
            },
            NE = {
                _animation = 15678767314
            },
            E = {
                _animation = 15678769609
            },
            SE = {
                _animation = 15678770969
            },
            S = {
                _animation = 15678773616
            },
            SW = {
                _animation = 15678772642
            },
            W = {
                _animation = 15678775148
            },
            NW = {
                _animation = 15678768732
            }
        },
        Prone = {
            N = {
                _animation = 15766669099,
                Duration = 0.8,
                Speed = 5
            },
            NE = {
                _animation = 15766893356
            },
            E = {
                _animation = 15766672504
            },
            SE = {
                _animation = 15766894488
            },
            S = {
                _animation = 15766674118
            },
            SW = {
                _animation = 15766896110
            },
            W = {
                _animation = 15766675627
            },
            NW = {
                _animation = 15766897461
            }
        }
    },
    LongGun = {
        Idle = {
            CQB = {
                _animation = 18955704526
            },
            Standing = {
                _animation = 16432564425
            },
            Crouch = {
                _animation = 18857139929
            },
            Prone = {
                _animation = 16432544187,
                Length = 0.6,
                Is360 = true
            },
            Slide = {
                _animation = 101805125657355
            },
            IdleToProne = {
                _animation = 15766795748
            },
            ProneToIdle = {
                _animation = 15766804000
            },
            CrouchToProne = {
                _animation = 15766805980
            },
            ProneToCrouch = {
                _animation = 15766808994
            }
        },
        Sprint = {
            N = {
                _animation = 18856652349,
                Duration = 0.5333333333333333,
                Speed = 16
            },
            NE = {
                _animation = 18856653779
            },
            NW = {
                _animation = 18856655219
            }
        },
        Jog = {
            N = {
                _animation = 18856638934,
                Duration = 0.6666666666666666,
                Speed = 12
            },
            NE = {
                _animation = 18856650141
            },
            E = {
                _animation = 18856640313
            },
            SE = {
                _animation = 18856643919
            },
            S = {
                _animation = 18856648129
            },
            SW = {
                _animation = 18856642520
            },
            W = {
                _animation = 18856641227
            },
            NW = {
                _animation = 18856645731
            }
        },
        Crouch = {
            N = {
                _animation = 17141882329,
                Duration = 0.6666666666666666,
                Speed = 10
            },
            NE = {
                _animation = 17141879512
            },
            E = {
                _animation = 17141866684
            },
            SE = {
                _animation = 17141868514
            },
            S = {
                _animation = 17141873157
            },
            SW = {
                _animation = 17141870875
            },
            W = {
                _animation = 17141864099
            },
            NW = {
                _animation = 17141876883
            }
        },
        Prone = {
            N = {
                _animation = 15766669099,
                Duration = 0.8,
                Speed = 5
            },
            NE = {
                _animation = 15766893356
            },
            E = {
                _animation = 15766672504
            },
            SE = {
                _animation = 15766894488
            },
            S = {
                _animation = 15766674118
            },
            SW = {
                _animation = 15766896110
            },
            W = {
                _animation = 15766675627
            },
            NW = {
                _animation = 15766897461
            }
        }
    },
    Pistol = {
        Idle = {
            CQB = {
                _animation = 93867799830963
            },
            Standing = {
                _animation = 17140649197
            },
            Crouch = {
                _animation = 17140651870
            },
            Prone = {
                _animation = 17140657852,
                Length = 0.6,
                Is360 = true
            },
            Slide = {
                _animation = 101805125657355
            },
            IdleToProne = {
                _animation = 17140665981
            },
            ProneToIdle = {
                _animation = 17140669332
            },
            CrouchToProne = {
                _animation = 17140684605
            },
            ProneToCrouch = {
                _animation = 17140673730
            }
        },
        Sprint = {
            N = {
                _animation = 18856682364,
                Duration = 0.5333333333333333,
                Speed = 16
            },
            NE = {
                _animation = 18856684901
            },
            NW = {
                _animation = 18856686125
            }
        },
        Jog = {
            N = {
                _animation = 17140693566,
                Duration = 0.6666666666666666,
                Speed = 12
            },
            NE = {
                _animation = 17140696649
            },
            E = {
                _animation = 17140702504
            },
            SE = {
                _animation = 17140706258
            },
            S = {
                _animation = 17140715648
            },
            SW = {
                _animation = 17140739530
            },
            W = {
                _animation = 116321792627897
            },
            NW = {
                _animation = 17140752138
            }
        },
        Crouch = {
            N = {
                _animation = 17140756931,
                Duration = 0.6666666666666666,
                Speed = 10
            },
            NE = {
                _animation = 17140758835
            },
            E = {
                _animation = 17140762088
            },
            SE = {
                _animation = 17140764469
            },
            S = {
                _animation = 17140766525
            },
            SW = {
                _animation = 17140774577
            },
            W = {
                _animation = 17140778194
            },
            NW = {
                _animation = 17140781565
            }
        },
        Prone = {
            N = {
                _animation = 17140783826,
                Duration = 0.8,
                Speed = 5
            },
            NE = {
                _animation = 73859358871747
            },
            E = {
                _animation = 17140792582
            },
            SE = {
                _animation = 136148296357466
            },
            S = {
                _animation = 17140794020
            },
            SW = {
                _animation = 71176747912217
            },
            W = {
                _animation = 17140796263
            },
            NW = {
                _animation = 123984342818293
            }
        }
    },
    LongGunAiming = {
        Idle = {
            CQB = {
                _animation = 18955704526
            },
            Standing = {
                _animation = 99912466598377
            },
            Crouch = {
                _animation = 122614642061462
            },
            Prone = {
                _animation = 16432544187,
                Length = 0.6,
                Is360 = true
            },
            Slide = {
                _animation = 101805125657355
            },
            IdleToProne = {
                _animation = 15766795748
            },
            ProneToIdle = {
                _animation = 15766804000
            },
            CrouchToProne = {
                _animation = 15766805980
            },
            ProneToCrouch = {
                _animation = 15766808994
            }
        },
        Sprint = {
            N = {
                _animation = 18856652349,
                Duration = 0.5333333333333333,
                Speed = 16
            },
            NE = {
                _animation = 18856653779
            },
            NW = {
                _animation = 18856655219
            }
        },
        Jog = {
            N = {
                _animation = 125748049615128,
                Duration = 0.6666666666666666,
                Speed = 12
            },
            NE = {
                _animation = 95946664147724
            },
            E = {
                _animation = 101652909195213
            },
            SE = {
                _animation = 126204832943850
            },
            S = {
                _animation = 106853455268416
            },
            SW = {
                _animation = 132401327984417
            },
            W = {
                _animation = 100286051850449
            },
            NW = {
                _animation = 132517044994268
            }
        },
        Crouch = {
            N = {
                _animation = 113121855549743,
                Duration = 0.6666666666666666,
                Speed = 10
            },
            NE = {
                _animation = 140225585421658
            },
            E = {
                _animation = 77981652847358
            },
            SE = {
                _animation = 140446488687915
            },
            S = {
                _animation = 109744549982278
            },
            SW = {
                _animation = 85003615740937
            },
            W = {
                _animation = 17141864099
            },
            NW = {
                _animation = 137315469681350
            }
        },
        Prone = {
            N = {
                _animation = 15766669099,
                Duration = 0.8,
                Speed = 5
            },
            NE = {
                _animation = 15766893356
            },
            E = {
                _animation = 15766672504
            },
            SE = {
                _animation = 15766894488
            },
            S = {
                _animation = 15766674118
            },
            SW = {
                _animation = 15766896110
            },
            W = {
                _animation = 15766675627
            },
            NW = {
                _animation = 15766897461
            }
        }
    },
    PistolAiming = {
        Idle = {
            CQB = {
                _animation = 93867799830963
            },
            Standing = {
                _animation = 75291837115801
            },
            Crouch = {
                _animation = 125808817078012
            },
            Prone = {
                _animation = 17140657852,
                Length = 0.6,
                Is360 = true
            },
            Slide = {
                _animation = 101805125657355
            },
            IdleToProne = {
                _animation = 17140665981
            },
            ProneToIdle = {
                _animation = 17140669332
            },
            CrouchToProne = {
                _animation = 17140684605
            },
            ProneToCrouch = {
                _animation = 17140673730
            }
        },
        Sprint = {
            N = {
                _animation = 18856682364,
                Duration = 0.5333333333333333,
                Speed = 16
            },
            NE = {
                _animation = 18856684901
            },
            NW = {
                _animation = 18856686125
            }
        },
        Jog = {
            N = {
                _animation = 107579249394188,
                Duration = 0.6666666666666666,
                Speed = 12
            },
            NE = {
                _animation = 136035437452586
            },
            E = {
                _animation = 89506641955228
            },
            SE = {
                _animation = 117744146929638
            },
            S = {
                _animation = 118256892241161
            },
            SW = {
                _animation = 126888527743057
            },
            W = {
                _animation = 85396944289627
            },
            NW = {
                _animation = 134148037833652
            }
        },
        Crouch = {
            N = {
                _animation = 131547819541496,
                Duration = 0.6666666666666666,
                Speed = 10
            },
            NE = {
                _animation = 129097472596364
            },
            E = {
                _animation = 93042874763833
            },
            SE = {
                _animation = 88470990579334
            },
            S = {
                _animation = 98781137165617
            },
            SW = {
                _animation = 82085331310028
            },
            W = {
                _animation = 137676683515417
            },
            NW = {
                _animation = 112178793120849
            }
        },
        Prone = {
            N = {
                _animation = 17140783826,
                Duration = 0.8,
                Speed = 5
            },
            NE = {
                _animation = 73859358871747
            },
            E = {
                _animation = 17140792582
            },
            SE = {
                _animation = 136148296357466
            },
            S = {
                _animation = 17140794020
            },
            SW = {
                _animation = 71176747912217
            },
            W = {
                _animation = 17140796263
            },
            NW = {
                _animation = 123984342818293
            }
        }
    }
};