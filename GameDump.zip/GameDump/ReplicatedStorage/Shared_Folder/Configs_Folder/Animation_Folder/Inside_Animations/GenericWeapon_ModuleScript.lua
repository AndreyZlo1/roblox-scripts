-- Roblox: ReplicatedStorage.Shared.Configs.Animation.Animations.GenericWeapon
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Draw = {
        _animation = 94141577765855
    },
    Draw_Low = {
        _animation = 17155097226
    },
    Smoker = {
        _animation = 9286214003
    }
};