-- Roblox: ReplicatedStorage.Shared.Configs.Animation.Animations.GearAnimations
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Binoculars = {
        TP = {
            Zoom = {
                _animation = 126805782235325
            },
            ZoomLoop = {
                _animation = 128092111754701
            }
        },
        FP = {
            Equip = {
                _animation = 74006321037980
            },
            Idle = {
                _animation = 92578816628270
            },
            Sprint = {
                _animation = 127725982689821
            }
        }
    },
    CSEL = {
        TP = {
            Use = {
                _animation = 138137619232000
            }
        },
        FP = {
            Use = {
                _animation = 70972685576752
            },
            Equip = {
                _animation = 140594672351334
            },
            Idle = {
                _animation = 89549028818675
            },
            Sprint = {
                _animation = 78449856369941
            }
        }
    },
    RangeFinder = {
        TP = {
            Zoom = {
                _animation = 126805782235325
            },
            ZoomLoop = {
                _animation = 128092111754701
            }
        },
        FP = {
            Equip = {
                _animation = 74006321037980
            },
            Idle = {
                _animation = 92578816628270
            },
            Sprint = {
                _animation = 127725982689821
            }
        }
    },
    Helix = {
        TP = {
            Zoom = {
                _animation = 126805782235325
            },
            ZoomLoop = {
                _animation = 128092111754701
            }
        },
        FP = {
            Equip = {
                _animation = 74006321037980
            },
            Idle = {
                _animation = 92578816628270
            },
            Sprint = {
                _animation = 127725982689821
            }
        }
    },
    M81 = {
        FP = {
            Equip = {
                _animation = 80105574154259
            },
            Idle = {
                _animation = 100998258953539
            },
            Sprint = {
                _animation = 88187870428910
            }
        },
        TP = {
            Equip = {
                _animation = 77164058035445
            },
            Idle = {
                _animation = 73286879602518
            },
            Place = {
                _animation = 98981877513476
            }
        }
    },
    M81Ignitor = {
        FP = {
            Equip = {
                _animation = 116630858377137
            },
            Idle = {
                _animation = 84262104829543
            },
            Use = {
                _animation = 134371761661687
            }
        },
        TP = {
            Equip = {
                _animation = 134220955881379
            },
            Idle = {
                _animation = 109319808202521
            },
            Use = {
                _animation = 117201982470343
            }
        }
    },
    Ravic2 = {
        FP = {
            DroneEquip = {
                _animation = 79521827320784
            },
            DroneIdle = {
                _animation = 113424144121773
            },
            DroneSprint = {
                _animation = 103227352844388
            },
            ControllerEquip = {
                _animation = 132942890062106
            },
            ControllerIdle = {
                _animation = 71751635604767
            },
            ControllerSprint = {
                _animation = 104238789153301
            }
        },
        TP = {
            DroneEquip = {
                _animation = 117044039423776
            },
            DroneIdle = {
                _animation = 103780760937767
            },
            ControllerEquip = {
                _animation = 110517493088767
            },
            ControllerIdle = {
                _animation = 108465055383149
            }
        }
    }
};