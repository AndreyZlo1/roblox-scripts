-- Roblox: ReplicatedStorage.Shared.Configs.Animation.Animations.Cutscenes
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Mission1 = {
        _animation = 0,
        IncludePlayers = true,
        Rigs = 1,
        CFrame = CFrame.new(-63.5856438, 7.49010658, 65.294838, -1, 0, 0, 0, 1, 0, 0, 0, -1)
    }
};