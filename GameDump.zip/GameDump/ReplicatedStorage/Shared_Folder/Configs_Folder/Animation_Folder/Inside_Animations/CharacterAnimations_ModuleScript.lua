-- Roblox: ReplicatedStorage.Shared.Configs.Animation.Animations.CharacterAnimations
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    ATAK = {
        TP = {
            _animation = 15605156463
        }
    },
    LockPick = {
        TP = {
            _animation = 15852574606
        }
    },
    Climb = {
        TP = {
            _animation = 16218792980,
            Length = 0.8
        }
    },
    PTT = {
        TP = {
            _animation = 138495336987755
        }
    },
    KickDoor = {
        TP = {
            Fail = {
                _animation = 18808584263
            },
            Success = {
                _animation = 18808586212
            }
        }
    },
    TakePicture = {
        TP = {
            _animation = 10954481667
        },
        FP = {
            _animation = 10963005121
        }
    },
    UseGeiger = {
        TP = {
            _animation = 75896748558005
        }
    },
    WeldManhole = {
        TP = {
            _animation = 127148136854811
        }
    },
    OpenDoor = {
        TP = {
            _animation = 8692750560
        },
        FP = {
            _animation = 8692759896
        }
    },
    KnockBack = {
        Front = {
            _animation = 18854099338
        },
        Back = {
            _animation = 18854097275
        },
        Left = {
            _animation = 18854101318
        },
        Right = {
            _animation = 18854108977
        }
    },
    Grenade = {
        TP = {
            Equip = {
                _animation = 15708978593
            },
            Idle = {
                _animation = 16056812361
            },
            Low_Idle = {
                _animation = 16056823414
            },
            Low_Prepare = {
                _animation = 16056833317
            },
            Low_Throw = {
                _animation = 16056828796
            },
            High_Idle = {
                _animation = 16056821254
            },
            High_Prepare = {
                _animation = 16056836038
            },
            High_Throw = {
                _animation = 16056826007
            }
        },
        FP = {
            Equip = {
                _animation = 7467031382
            },
            Idle = {
                _animation = 16081422535
            },
            Low_Idle = {
                _animation = 16081420362
            },
            Low_Prepare = {
                _animation = 16081417970
            },
            Low_Throw = {
                _animation = 16081414680
            },
            High_Idle = {
                _animation = 16081425097
            },
            High_Prepare = {
                _animation = 16073783475
            },
            High_Throw = {
                _animation = 16081349648
            }
        }
    },
    Vault = {
        High = {
            _animation = 18760316160,
            Timer = 2,
            Height = 7
        },
        Mid = {
            _animation = 18760331680,
            Timer = 1.5,
            Height = 5.5
        },
        Low = {
            _animation = 18760334846,
            Timer = 1,
            Height = 4
        }
    },
    Medical = {
        TP = {
            Bandage = {
                _animation = 11160425546,
                Part = "LeftLowerArm",
                Time = 1.8
            },
            Dressing = {
                _animation = 11160455957,
                Part = "LeftHand",
                Time = 2.4
            },
            Vitamins = {
                _animation = 11160445287,
                Part = "RightHand",
                Time = 2.4
            }
        },
        FP = {
            Bandage = {
                _animation = 11218126872
            },
            Dressing = {
                _animation = 11160457531
            },
            Vitamins = {
                _animation = 11160447876
            }
        }
    },
    NVG = {
        TP = {
            Down = {
                _animation = 100137107475237
            },
            Up = {
                _animation = 139375175172685
            }
        },
        FP = {
            Down = {
                _animation = 127176012711625
            },
            Up = {
                _animation = 75307634800882
            }
        }
    },
    Radio = {
        Start = {
            _animation = 18954201456
        },
        Idle = {
            _animation = 18954203830
        },
        End = {
            _animation = 18954207397
        }
    },
    Downed = {
        Loop = {
            _animation = 119021069941801
        },
        Start = {
            _animation = 82907421764325
        }
    },
    Parachute = {
        Idle = {
            _animation = 115191545922755
        },
        Right = {
            _animation = 115545917070433
        },
        Left = {
            _animation = 79156297825274
        }
    },
    Rappel = {
        Start = {
            _animation = 71735743154720
        },
        Loop = {
            _animation = 131351663235860
        },
        End = {
            _animation = 85675229203966
        }
    },
    Mortar = {
        Fire = {
            _animation = 103719258664868
        }
    },
    BodyBag = {
        FP = {
            _animation = 76813657535777
        },
        TP = {
            _animation = 136683588304088
        }
    },
    MortarDismantle = {
        FP = {
            _animation = 76813657535777
        },
        TP = {
            _animation = 136683588304088
        }
    },
    Flashed = {
        TP = {
            _animation = 134486202812474
        },
        FP = {
            _animation = 128646303398131
        }
    },
    Cough = {
        TP = {
            _animation = 119226801180736
        },
        TP_Mask = {
            _animation = 122395943368247
        },
        FP = {
            _animation = 131303421782459
        }
    },
    TakeDown = {
        TakeDown1 = {
            Executor = {
                Duration = 1.3333333333333333,
                _animation = 77505418521613
            },
            Victim = {
                _animation = 126062613053191
            }
        },
        TakeDown2 = {
            Executor = {
                Duration = 1.6666666666666667,
                _animation = 139133888384087
            },
            Victim = {
                _animation = 140484409824492
            }
        }
    },
    Cutscenes = {
        Wetwork4 = {
            Intro = {
                _animation = 87058208957006,
                Duration = 100,
                AudioSync = "Wetwork4Intro"
            },
            Ending = {
                _animation = 137950211908643,
                Duration = 100,
                AudioSync = "Wetwork4Ending"
            }
        }
    },
    Swipe = {
        Head = {
            _animation = 131976125252913
        },
        Right = {
            _animation = 137016543592222
        },
        Left = {
            _animation = 82275062881140
        }
    }
};