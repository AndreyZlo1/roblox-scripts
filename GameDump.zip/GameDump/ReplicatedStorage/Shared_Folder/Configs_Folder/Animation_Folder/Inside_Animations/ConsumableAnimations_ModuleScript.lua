-- Roblox: ReplicatedStorage.Shared.Configs.Animation.Animations.ConsumableAnimations
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Soda = {
        TP = {
            IdleOpen = {
                _animation = 130326937314779
            },
            Open = {
                _animation = 129463699238582
            },
            Use = {
                _animation = 94038475594758,
                Timer = 2
            }
        },
        FP = {
            Equip = {
                _animation = 129362905569516
            },
            Idle = {
                _animation = 96923618243633
            },
            IdleOpen = {
                _animation = 119008165745387
            },
            Open = {
                _animation = 104890054579462
            },
            Use = {
                _animation = 136155831840748
            },
            Sprint = {
                _animation = 85444495446994
            }
        }
    },
    WaterBottle = {
        TP = {
            IdleOpen = {
                _animation = 79326611247001
            },
            Open = {
                _animation = 80735189900614
            },
            Use = {
                _animation = 104104792729454,
                Timer = 2
            }
        },
        FP = {
            Equip = {
                _animation = 92618738461823
            },
            Idle = {
                _animation = 124894667259004
            },
            IdleOpen = {
                _animation = 131793323559432
            },
            Open = {
                _animation = 90569154698607
            },
            Use = {
                _animation = 88631767556679
            },
            Sprint = {
                _animation = 85444495446994
            }
        }
    },
    SodaBottle = {
        TP = {
            IdleOpen = {
                _animation = 128224911606603
            },
            Open = {
                _animation = 77125076648520
            },
            Use = {
                _animation = 89382824961395,
                Timer = 2
            }
        },
        FP = {
            Equip = {
                _animation = 130232480197661
            },
            Idle = {
                _animation = 133834331358581
            },
            IdleOpen = {
                _animation = 72587648994524
            },
            Open = {
                _animation = 87602883667442
            },
            Use = {
                _animation = 133749086857403
            },
            Sprint = {
                _animation = 85444495446994
            }
        }
    },
    Chips = {
        TP = {
            IdleOpen = {
                _animation = 118532055762707
            },
            Open = {
                _animation = 94447713839145
            },
            Use = {
                _animation = 116389628740067,
                Timer = 1.8,
                Transform = {
                    Inside = {
                        From = CFrame.new(0, 0, 0),
                        To = CFrame.new(0, 0.7, 0)
                    }
                }
            }
        },
        FP = {
            Equip = {
                _animation = 94447713839145
            },
            Idle = {
                _animation = 96175334106480
            },
            IdleOpen = {
                _animation = 126849616969956
            },
            Open = {
                _animation = 115916836135976
            },
            Use = {
                _animation = 110145786156096
            },
            Sprint = {
                _animation = 85444495446994
            }
        }
    },
    CanLarge = {
        TP = {
            IdleOpen = {
                _animation = 87588193493256
            },
            Open = {
                _animation = 94200231754148
            },
            Use = {
                _animation = 114540321938208,
                Timer = 1.7,
                Zoom = 2,
                Offset = CFrame.new(0, -0.3, 0) * CFrame.Angles(0, -1.5707963267948966, 0),
                Transform = {
                    Inside = {
                        From = CFrame.new(0, -0.465, 0),
                        To = CFrame.new(0, -0.11, 0)
                    }
                }
            }
        },
        FP = {
            Equip = {
                _animation = 122901830913455
            },
            Idle = {
                _animation = 94581740982074
            },
            IdleOpen = {
                _animation = 94450356938892
            },
            Open = {
                _animation = 73490658167134
            },
            Use = {
                _animation = 118864622510677
            },
            Sprint = {
                _animation = 132609529216036
            }
        }
    },
    CanSmall = {
        TP = {
            IdleOpen = {
                _animation = 87588193493256
            },
            Open = {
                _animation = 94200231754148
            },
            Use = {
                _animation = 114540321938208,
                Timer = 1.7,
                Zoom = 1,
                Offset = CFrame.new(0, -0.4, 0) * CFrame.Angles(0, -1.5707963267948966, 0),
                Transform = {
                    Inside = {
                        From = CFrame.new(0, -0.465, 0),
                        To = CFrame.new(0, -0.285, 0)
                    }
                }
            }
        },
        FP = {
            Equip = {
                _animation = 122901830913455
            },
            Idle = {
                _animation = 94581740982074
            },
            IdleOpen = {
                _animation = 94450356938892
            },
            Open = {
                _animation = 73490658167134
            },
            Use = {
                _animation = 118864622510677
            },
            Sprint = {
                _animation = 132609529216036
            }
        }
    }
};