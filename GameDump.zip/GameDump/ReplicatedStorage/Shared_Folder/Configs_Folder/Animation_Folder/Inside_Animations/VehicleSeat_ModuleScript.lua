-- Roblox: ReplicatedStorage.Shared.Configs.Animation.Animations.VehicleSeat
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    BasicCenter = {
        Enter = {
            _animation = 106152670519752,
            Time = 1,
            Offset = CFrame.new(0, 1.057, -2.435)
        },
        Exit = {
            _animation = 83557141251907,
            Time = 0.5
        },
        Sit = {
            _animation = 97376476774954
        }
    },
    BasicCenterInside = {
        Enter = {
            _animation = 106152670519752,
            Time = 1,
            Offset = CFrame.new(0, 1.057, -2.435)
        },
        Exit = {
            _animation = 83557141251907,
            Time = 0.5
        },
        Sit = {
            _animation = 133534260093102
        }
    },
    BasicCenterLow = {
        Enter = {
            _animation = 106152670519752,
            Time = 1,
            Offset = CFrame.new(0, 1.569, -2.147)
        },
        Exit = {
            _animation = 83557141251907,
            Time = 0.5
        },
        Sit = {
            _animation = 97376476774954
        }
    },
    BasicLeft = {
        Enter = {
            _animation = 15258119527,
            Time = 2,
            Offset = CFrame.new(-4.64293718, -0.000158309937, 1.48817778),
            Door = { 0.5, 1.5 }
        },
        Exit = {
            _animation = 15258122151,
            Time = 1.5,
            Door = { 0.1, 1 }
        },
        Sit = {
            _animation = 15258129733
        }
    },
    BasicRight = {
        Enter = {
            _animation = 15258124774,
            Time = 2,
            Offset = CFrame.new(4.69416809, -0.000158786774, 1.48817801),
            Door = { 0.5, 1.5 }
        },
        Exit = {
            _animation = 15258128377,
            Time = 1.5,
            Door = { 0.1, 1 }
        },
        Sit = {
            _animation = 15258129733
        }
    },
    BasicLeftDriver = {
        Enter = {
            _animation = 15258119527,
            Time = 2,
            Offset = CFrame.new(-4.64293718, -0.000158309937, 1.48817778),
            Door = { 0.5, 1.5 }
        },
        Exit = {
            _animation = 15258122151,
            Time = 1.5,
            Door = { 0.1, 1 }
        },
        Sit = {
            _animation = 15346410739
        }
    },
    NoDoorLeft = {
        Enter = {
            _animation = 101957668305823,
            Time = 2,
            Offset = CFrame.new(-4.211, -0.115, 0.864)
        },
        Exit = {
            _animation = 84303707780310,
            Time = 1.5
        },
        Sit = {
            _animation = 134694829560040
        }
    },
    NoDoorRight = {
        Enter = {
            _animation = 111607494118866,
            Time = 2,
            Offset = CFrame.new(4.211, -0.115, 0.864)
        },
        Exit = {
            _animation = 102951718973656,
            Time = 1.5
        },
        Sit = {
            _animation = 134694829560040
        }
    },
    SrtvPassangerLeft = {
        Enter = {
            _animation = 86202785112580,
            Time = 2,
            Offset = CFrame.new(4.605, -0.879, -3.71) * CFrame.Angles(0, 3.141592653589793, 0),
            Door = { 0.08, 1.23 }
        },
        Exit = {
            _animation = 131264801140584,
            Time = 1.2,
            Door = { 0, 1.1 }
        },
        Sit = {
            _animation = 99969517785043
        }
    },
    SrtvPassangerRight = {
        Enter = {
            _animation = 116998709556404,
            Time = 2,
            Offset = CFrame.new(-4.605, -0.879, -3.71) * CFrame.Angles(0, 3.141592653589793, 0),
            Door = { 0.08, 1.23 }
        },
        Exit = {
            _animation = 138866545056250,
            Time = 1.2,
            Door = { 0, 1.1 }
        },
        Sit = {
            _animation = 90707438531680
        }
    },
    SrtvDriver = {
        Enter = {
            _animation = 135935334668861,
            Time = 2,
            Offset = CFrame.new(-0, 4.725, -4.759) * CFrame.Angles(0, 3.141592653589793, 0)
        },
        Exit = {
            _animation = 70904045893569,
            Time = 1.5
        },
        Sit = {
            _animation = 128655626220976
        }
    },
    FmtvRight = {
        Enter = {
            _animation = 121939711098782,
            Time = 2.27,
            Offset = CFrame.new(-5.283, -3.63, -3.44),
            Door = { 0.3, 2.2 }
        },
        Exit = {
            _animation = 110024815690800,
            Time = 3,
            Door = { 0.3, 2.3 }
        },
        Sit = {
            _animation = 125109937882775
        }
    },
    FmtvLeftDriver = {
        Enter = {
            _animation = 101242260792102,
            Offset = CFrame.new(5.283, -3.63, -3.44),
            Time = 2,
            27,
            Door = { 0.3, 2.2 }
        },
        Exit = {
            _animation = 75356428824720,
            Time = 3,
            Door = { 0.3, 2.3 }
        },
        Sit = {
            _animation = 125109937882775
        }
    },
    FmtvLeftDriverM = {
        Enter = {
            _animation = 101242260792102,
            Offset = CFrame.new(7.283, -3.63, -2.44),
            Time = 2,
            27,
            Door = { 0.3, 2.2 }
        },
        Exit = {
            _animation = 75356428824720,
            Time = 3,
            Door = { 0.3, 2.3 }
        },
        Sit = {
            _animation = 125109937882775
        }
    },
    StrykerDriver = {
        Enter = {
            _animation = 103466565535334,
            Time = 2,
            Offset = CFrame.new(0.109, 2.248, 6.866)
        },
        Exit = {
            _animation = 96532207973891,
            Time = 1.5
        },
        Sit = {
            _animation = 80152611530614
        }
    },
    VabDriver = {
        Enter = {
            _animation = 74915659161216,
            Time = 2,
            Offset = CFrame.new(-5.782, -1.927, 2.286),
            Door = { 0.1, 1 }
        },
        Exit = {
            _animation = 73770090239507,
            Time = 1.5,
            Door = { 0.1, 1 }
        },
        Sit = {
            _animation = 85053469030046
        }
    },
    VabRight = {
        Enter = {
            _animation = 97087729243899,
            Time = 2.17,
            Offset = CFrame.new(5.782, -1.927, 1.286),
            Door = { 0.12, 2 }
        },
        Exit = {
            _animation = 131555567124580,
            Time = 2.15,
            Door = { 0.1, 2 }
        },
        Sit = {
            _animation = 122360658450490
        }
    },
    TurretTopEnter = {
        Enter = {
            _animation = 115081283492229,
            Time = 1,
            Offset = CFrame.new(-3.235, 2.988, -4.018)
        },
        Exit = {
            _animation = 92587205667589,
            Time = 2
        },
        Sit = {
            _animation = 134961854478065
        }
    },
    TurretTopEnterGriffon = {
        Enter = {
            _animation = 115081283492229,
            Time = 1,
            Offset = CFrame.new(-0.698, 2.988, -0.012)
        },
        Exit = {
            _animation = 92587205667589,
            Time = 2
        },
        Sit = {
            _animation = 134961854478065
        }
    },
    UH60SideSeatLeft = {
        Enter = {
            _animation = 136103562207279,
            Time = 1,
            Offset = CFrame.new(-0.008, 3.005, 1.067)
        },
        Exit = {
            _animation = 109514290902909,
            Time = 0.5
        },
        Sit = {
            _animation = 76280559388725
        }
    },
    UH60SideSeatRight = {
        Enter = {
            _animation = 136103562207279,
            Time = 1,
            Offset = CFrame.new(0.008, 3.005, 1.067)
        },
        Exit = {
            _animation = 109514290902909,
            Time = 0.5
        },
        Sit = {
            _animation = 76280559388725
        }
    },
    UH60Pilot = {
        Enter = {
            _animation = 76511914115661,
            Time = 1,
            Offset = CFrame.new(5.895, -1.814, 1.08),
            Door = { 0.3, 2 }
        },
        Exit = {
            _animation = 123911396883194,
            Time = 2,
            Door = { 0.1, 1.3 }
        },
        Sit = {
            _animation = 92469212248547
        }
    },
    UH60CoPilot = {
        Enter = {
            _animation = 112871626013310,
            Time = 1,
            Offset = CFrame.new(-5.895, -1.814, 1.08),
            Door = { 0.3, 2 }
        },
        Exit = {
            _animation = 110362687234353,
            Time = 2,
            Door = { 0.1, 1.3 }
        },
        Sit = {
            _animation = 92469212248547
        }
    },
    UH60TurretLeft = {
        Enter = {
            _animation = 124477989986074,
            Time = 2.27,
            Offset = CFrame.new(-2.574, 0.006, 1.516),
            Door = { 0.12, 2 }
        },
        Exit = {
            _animation = 70554757178227,
            Time = 1.25,
            Door = { 0.02, 1.07 }
        },
        Sit = {
            _animation = 119496734381673
        }
    },
    UH60TurretRight = {
        Enter = {
            _animation = 93780522572130,
            Time = 2.27,
            Offset = CFrame.new(2.574, 0.006, 1.516),
            Door = { 0.12, 2 }
        },
        Exit = {
            _animation = 118546343224815,
            Time = 1.25,
            Door = { 0.02, 1.07 }
        },
        Sit = {
            _animation = 119496734381673
        }
    },
    ChinookPilotLeft = {
        Enter = {
            _animation = 115476486763761,
            Time = 1,
            Offset = CFrame.new(2.696, 1.141, 4.014)
        },
        Exit = {
            _animation = 128700145671798,
            Time = 2
        },
        Sit = {
            _animation = 87486521361295
        }
    },
    ChinookPilotRight = {
        Enter = {
            _animation = 99906017769836,
            Time = 1,
            Offset = CFrame.new(-2.696, 1.141, 4.014)
        },
        Exit = {
            _animation = 89043557134756,
            Time = 2
        },
        Sit = {
            _animation = 87486521361295
        }
    },
    MI8PilotRight = {
        Enter = {
            _animation = 115476486763761,
            Time = 1,
            Offset = CFrame.new(-1.342, 0.873, 3.862)
        },
        Exit = {
            _animation = 128700145671798,
            Time = 2
        },
        Sit = {
            _animation = 87486521361295
        }
    },
    MI8PilotLeft = {
        Enter = {
            _animation = 99906017769836,
            Time = 1,
            Offset = CFrame.new(1.342, 0.873, 3.862)
        },
        Exit = {
            _animation = 89043557134756,
            Time = 2
        },
        Sit = {
            _animation = 87486521361295
        }
    },
    MD500Left = {
        Enter = {
            _animation = 116335083678512,
            Time = 1,
            Offset = CFrame.new(-4.381, -1.89, -1.085)
        },
        Exit = {
            _animation = 85004652295180,
            Time = 1
        },
        Sit = {
            _animation = 117403280367665
        }
    },
    MD500Right = {
        Enter = {
            _animation = 97740065627545,
            Time = 1,
            Offset = CFrame.new(4.381, -1.89, -1.085)
        },
        Exit = {
            _animation = 74690769302204,
            Time = 1
        },
        Sit = {
            _animation = 117403280367665
        }
    },
    MD500Passanger = {
        Enter = {
            _animation = 107284552534419,
            Time = 1,
            Offset = CFrame.new(0, 0, -1.687)
        },
        Exit = {
            _animation = 77945527165837,
            Time = 0.5
        },
        Sit = {
            _animation = 76949758464948
        }
    },
    StandingTurret = {
        Enter = {
            _animation = 132079251142280,
            Time = 1,
            Offset = CFrame.new(0, 0, 0.826)
        },
        Exit = {
            _animation = 112719398967965,
            Time = 0.5
        },
        Sit = {
            _animation = 74017052023500
        }
    },
    TruckLeft = {
        Enter = {
            _animation = 70414968549306,
            Time = 2.18,
            Offset = CFrame.new(-5.487, -2.381, 1.532),
            Door = { 0.14, 2.08 }
        },
        Exit = {
            _animation = 106871574948242,
            Time = 2.18,
            Door = { 0.6, 2.1 }
        },
        Sit = {
            _animation = 133534260093102
        }
    },
    TruckRight = {
        Enter = {
            _animation = 121336107921653,
            Time = 2.18,
            Offset = CFrame.new(5.487, -2.381, 1.532),
            Door = { 0.14, 2.08 }
        },
        Exit = {
            _animation = 97475593522552,
            Time = 2.18,
            Door = { 0.6, 2.1 }
        },
        Sit = {
            _animation = 133534260093102
        }
    }
};