-- Roblox: ReplicatedStorage.Shared.Configs.Animation.Animations.Emotes
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Halt = {
        Start = {
            TP = {
                CanEquip = true,
                FirstPerson = true,
                Public = true,
                Duration = 2,
                _animation = 5128706829
            },
            FP = {
                _animation = 103668707866987
            }
        }
    },
    Forward = {
        Start = {
            TP = {
                CanEquip = true,
                FirstPerson = true,
                Public = true,
                Duration = 2,
                _animation = 5128709510
            },
            FP = {
                _animation = 102822863577724
            }
        }
    },
    Regroup = {
        Start = {
            TP = {
                CanEquip = true,
                FirstPerson = true,
                Public = true,
                Duration = 2,
                _animation = 5128708517
            },
            FP = {
                _animation = 93164882215096
            }
        }
    },
    Crossed = {
        Start = {
            TP = {
                Public = true,
                Duration = 0.5,
                _animation = 5473267759
            }
        },
        Idle = {
            TP = {
                _animation = 5473269783
            }
        },
        End = {
            TP = {
                _animation = 5473271653
            }
        }
    },
    AtEase = {
        Start = {
            TP = {
                Public = true,
                Duration = 0.5,
                _animation = 5473949266
            }
        },
        Idle = {
            TP = {
                _animation = 5473955384
            }
        },
        End = {
            TP = {
                _animation = 5473956951
            }
        }
    },
    Salute = {
        Start = {
            TP = {
                Public = true,
                Duration = 0.5,
                _animation = 5473961856
            }
        },
        Idle = {
            TP = {
                _animation = 5473963529
            }
        },
        End = {
            TP = {
                _animation = 5473983724
            }
        }
    },
    Sleep = {
        Start = {
            TP = {
                Public = true,
                Duration = 1.2,
                _animation = 89529371889484
            }
        },
        Idle = {
            TP = {
                _animation = 115315700480491
            }
        },
        End = {
            TP = {
                _animation = 98357630046963
            }
        }
    },
    Sit = {
        Start = {
            TP = {
                Public = true,
                Duration = 1.2,
                _animation = 71526642348137
            }
        },
        Idle = {
            TP = {
                _animation = 80438467734192
            }
        },
        End = {
            TP = {
                _animation = 132899323759466
            }
        }
    },
    Belt = {
        Start = {
            TP = {
                Public = true,
                Duration = 0.5,
                _animation = 5474093530
            }
        },
        Idle = {
            TP = {
                _animation = 5474095200
            }
        },
        End = {
            TP = {
                _animation = 5474096328
            }
        }
    },
    Right_Peek = {
        Start = {
            TP = {
                Duration = 0.43,
                Last = "Right_Hide",
                _animation = 18613324170
            }
        },
        Idle = {
            TP = {
                _animation = 18613317678
            }
        }
    },
    Right_Hide = {
        Start = {
            TP = {
                Duration = 0.43,
                _animation = 18613326510
            }
        },
        Idle = {
            TP = {
                _animation = 18613313855
            }
        }
    },
    Left_Peek = {
        Start = {
            TP = {
                Duration = 0.43,
                Last = "Left_Hide",
                _animation = 18613332264
            }
        },
        Idle = {
            TP = {
                _animation = 18615274256
            }
        }
    },
    Left_Hide = {
        Start = {
            TP = {
                Duration = 0.43,
                _animation = 18613339890
            }
        },
        Idle = {
            TP = {
                _animation = 18613329920
            }
        }
    },
    Crouch_Peek = {
        Start = {
            TP = {
                Duration = 0.43,
                Last = "Crouch_Hide",
                _animation = 18613478113
            }
        },
        Idle = {
            TP = {
                _animation = 18613475787
            }
        }
    },
    Crouch_Hide = {
        Start = {
            TP = {
                Duration = 0.43,
                _animation = 18613852296
            }
        },
        Idle = {
            TP = {
                _animation = 18613349917
            }
        }
    },
    Center_Peek = {
        Start = {
            TP = {
                Duration = 0.8,
                Last = "Center_Hide",
                _animation = 18716985718
            }
        },
        Idle = {
            TP = {
                _animation = 18716994599
            }
        }
    },
    Center_Hide = {
        Start = {
            TP = {
                Duration = 0.43,
                _animation = 18716980081
            }
        },
        Idle = {
            TP = {
                _animation = 18613349917
            }
        }
    },
    AI_Downed = {
        Idle = {
            TP = {
                _animation = 119021069941801
            }
        },
        Start = {
            TP = {
                _animation = 82907421764325
            }
        }
    },
    AI_KickGround = {
        Start = {
            TP = {
                Duration = 2,
                _animation = 18940813276
            }
        },
        Idle = {
            TP = {
                _animation = 18940809586
            }
        }
    },
    AI_Mortar = {
        Start = {
            TP = {
                _animation = 139865928774068
            }
        },
        Idle = {
            TP = {
                _animation = 139865928774068
            }
        }
    },
    AI_Surrender = {
        Start = {
            TP = {
                _animation = 4168259720
            }
        },
        Idle = {
            TP = {
                _animation = 4168259720
            }
        }
    },
    AI_Scared = {
        Start = {
            TP = {
                _animation = 4507048152
            }
        },
        Idle = {
            TP = {
                _animation = 4507048152
            }
        }
    },
    AI_Shovel = {
        Start = {
            TP = {
                _animation = 9225092150
            }
        },
        Idle = {
            TP = {
                _animation = 9225092150
            }
        }
    },
    AI_Pickaxe = {
        Start = {
            TP = {
                _animation = 9225230037
            }
        },
        Idle = {
            TP = {
                _animation = 9225230037
            }
        }
    },
    AI_Sorting = {
        Start = {
            TP = {
                _animation = 9225243217
            }
        },
        Idle = {
            TP = {
                _animation = 9225243217
            }
        }
    },
    AI_Crate = {
        Start = {
            TP = {
                _animation = 9225244675
            }
        },
        Idle = {
            TP = {
                _animation = 9225244675
            }
        }
    },
    AI_Type = {
        Start = {
            TP = {
                Duration = 2.67,
                _animation = 83971999788300
            }
        },
        Idle = {
            TP = {
                _animation = 83971999788300
            }
        }
    },
    AI_Tinker = {
        Start = {
            TP = {
                Dureation = 7.33,
                _animation = 126532983828231
            }
        },
        Idle = {
            TP = {
                _animation = 126532983828231
            }
        }
    },
    AI_Think = {
        Start = {
            TP = {
                Dureation = 3,
                _animation = 111555216569088
            }
        },
        Idle = {
            TP = {
                _animation = 111555216569088
            }
        }
    },
    AI_Talk5 = {
        Start = {
            TP = {
                Dureation = 2.33,
                _animation = 81565311681667
            }
        },
        Idle = {
            TP = {
                _animation = 81565311681667
            }
        }
    },
    AI_Talk4 = {
        Start = {
            TP = {
                Dureation = 1.53,
                _animation = 103700732334392
            }
        },
        Idle = {
            TP = {
                _animation = 103700732334392
            }
        }
    },
    AI_Talk3 = {
        Start = {
            TP = {
                Dureation = 1.9,
                _animation = 137872054661302
            }
        },
        Idle = {
            TP = {
                _animation = 137872054661302
            }
        }
    }
};