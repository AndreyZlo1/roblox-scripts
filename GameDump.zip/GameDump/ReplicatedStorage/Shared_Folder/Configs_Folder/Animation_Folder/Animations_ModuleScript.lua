-- Roblox: ReplicatedStorage.Shared.Configs.Animation.Animations
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
for _, v2 in script:GetChildren() do
    local v3 = require(v2);
    v1[v2.Name] = v3;
end;
return v1;