-- Roblox: ReplicatedStorage.Shared.Configs.Character.Belt.CivilianBeltSlot.Belt.Belt.SwatBelt
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Storage = "SwatBelt",
    Size = Vector2.new(2, 3),
    Compatible = {
        Rail_1 = {
            "MOLLEPouch_Short",
            "MOLLEPouch_Mid",
            "MOLLEPouch_Tall",
            "BeltSlidePouch",
            "BeltLoop_1.75",
            "none",
            "BeltLoop_2"
        },
        Rail_2 = {
            "MOLLEPouch_Short",
            "MOLLEPouch_Mid",
            "MOLLEPouch_Tall",
            "BeltSlidePouch",
            "BeltLoop_1.75",
            "none"
        },
        Rail_3 = {
            "MOLLEPouch_Short",
            "MOLLEPouch_Mid",
            "MOLLEPouch_Tall",
            "BeltSlidePouch",
            "BeltLoop_1.75",
            "none"
        },
        Rail_11 = {
            "MOLLEPouch_Short",
            "MOLLEPouch_Mid",
            "MOLLEPouch_Tall",
            "BeltSlidePouch",
            "BeltLoop_1.75",
            "none"
        },
        Rail_12 = {
            "MOLLEPouch_Short",
            "MOLLEPouch_Mid",
            "MOLLEPouch_Tall",
            "BeltSlidePouch",
            "BeltLoop_1.75",
            "none"
        }
    },
    RailSpace = {
        Rail_1 = 6,
        Rail_2 = 11,
        Rail_3 = 6,
        Rail_11 = 2,
        Rail_12 = 1
    },
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = "rbxassetid://72863892915888",
        Black = "rbxassetid://101296676968259",
        Coyote498 = "rbxassetid://131364858671311",
        RangerGreen = "rbxassetid://118861646056354"
    }
};