-- Roblox: ReplicatedStorage.Shared.Configs.Character.Belt.CivilianBeltSlot.Belt.Belt.PoliceBelt
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Storage = "PoliceBelt",
    Size = Vector2.new(2, 2),
    Compatible = {
        Rail_1 = { "BeltLoop_2", "BeltLoop_1.75", "none" },
        Rail_2 = { "BeltLoop_1.75", "none" },
        Rail_3 = { "BeltLoop_1.75", "none" }
    },
    RailSpace = {
        Rail_1 = 5,
        Rail_2 = 11,
        Rail_3 = 6
    },
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = "rbxassetid://18929084480",
        Coyote498 = "rbxassetid://128484893602231",
        OliveDrabGreen = "rbxassetid://114319615935613",
        Black = "rbxassetid://126775413249693"
    }
};