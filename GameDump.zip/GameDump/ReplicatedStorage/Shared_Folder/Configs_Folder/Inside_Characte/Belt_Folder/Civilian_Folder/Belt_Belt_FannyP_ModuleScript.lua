-- Roblox: ReplicatedStorage.Shared.Configs.Character.Belt.CivilianBeltSlot.Belt.Belt.FannyPack
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Storage = "FannyPack",
    Size = Vector2.new(2, 2),
    Compatible = {},
    RailSpace = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = "rbxassetid://116797306597369",
        Blue = "rbxassetid://93643630356407",
        Red = "rbxassetid://136198513632135",
        Brown = "rbxassetid://137207949406862"
    }
};