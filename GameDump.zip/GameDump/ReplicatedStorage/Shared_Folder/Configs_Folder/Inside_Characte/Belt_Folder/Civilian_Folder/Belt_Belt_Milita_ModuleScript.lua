-- Roblox: ReplicatedStorage.Shared.Configs.Character.Belt.CivilianBeltSlot.Belt.Belt.MilitaryBattleBelt
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Storage = "MilitaryBattleBelt",
    Size = Vector2.new(3, 3),
    Compatible = {
        Rail_1 = {
            "none",
            "MOLLEPouch_Mid",
            "MOLLEPouch_Tall",
            "BeltLoop_2"
        },
        Rail_2 = { "none", "MOLLEPouch_Mid", "MOLLEPouch_Tall" },
        Rail_3 = { "none", "MOLLEPouch_Mid", "MOLLEPouch_Tall" },
        Rail_11 = { "none", "MOLLEPouch_Mid", "MOLLEPouch_Tall" },
        Rail_12 = { "none", "MOLLEPouch_Mid", "MOLLEPouch_Tall" }
    },
    RailSpace = {
        Rail_1 = 5,
        Rail_2 = 8,
        Rail_3 = 5,
        Rail_11 = 2,
        Rail_12 = 2
    },
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = "rbxassetid://126029654873554",
        Coyote498 = "rbxassetid://132715839968548",
        RangerGreen = "rbxassetid://138421398584549",
        Black = "rbxassetid://93885398287785"
    }
};