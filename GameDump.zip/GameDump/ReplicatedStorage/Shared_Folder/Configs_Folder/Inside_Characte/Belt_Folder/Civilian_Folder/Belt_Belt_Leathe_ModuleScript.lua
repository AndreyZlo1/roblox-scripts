-- Roblox: ReplicatedStorage.Shared.Configs.Character.Belt.CivilianBeltSlot.Belt.Belt.LeatherBelt
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Size = Vector2.new(2, 1),
    Compatible = {},
    RailSpace = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = "rbxassetid://126775413249693"
    }
};