-- Roblox: ReplicatedStorage.Shared.Configs.Character.Belt.BeltPouch.Belt.BeltPouchConfiguration.TSSI_Lanyard_CQB_HighTape
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = "rbxassetid://94753485766682"
    }
};