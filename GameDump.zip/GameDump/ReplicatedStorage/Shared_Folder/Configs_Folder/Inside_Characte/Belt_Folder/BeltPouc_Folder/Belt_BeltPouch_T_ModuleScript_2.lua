-- Roblox: ReplicatedStorage.Shared.Configs.Character.Belt.BeltPouch.Belt.BeltPouch.TSSI_Lanyard_Ronin
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {
        BeltExtraConfiguration = { "TSSI_Lanyard_TF_High", "TSSI_Lanyard_TF_HighTape" }
    },
    Default = {
        BeltExtraConfiguration = "TSSI_Lanyard_TF_High"
    },
    Config = {
        Tune = {}
    },
    Textures = {}
};