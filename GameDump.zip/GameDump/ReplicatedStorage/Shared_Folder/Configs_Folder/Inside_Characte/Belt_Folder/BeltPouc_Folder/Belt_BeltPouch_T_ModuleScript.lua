-- Roblox: ReplicatedStorage.Shared.Configs.Character.Belt.BeltPouch.Belt.BeltPouch.TSSI_Lanyard_CQB
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {
        BeltExtraConfiguration = { "TSSI_Lanyard_CQB_High", "TSSI_Lanyard_CQB_HighTape" }
    },
    Default = {
        BeltExtraConfiguration = "TSSI_Lanyard_CQB_High"
    },
    Config = {
        Tune = {}
    },
    Textures = {}
};