-- Roblox: ReplicatedStorage.Shared.Configs.Character.Belt.BeltPouch.Belt.BeltPouch.EAGLE_M9_HOLSTER
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = "rbxassetid://18929084269",
        MilesJacksonKhaki = "rbxassetid://91889449773852",
        RangerGreen = "rbxassetid://72322935142692",
        Black = "rbxassetid://124654558504613"
    }
};