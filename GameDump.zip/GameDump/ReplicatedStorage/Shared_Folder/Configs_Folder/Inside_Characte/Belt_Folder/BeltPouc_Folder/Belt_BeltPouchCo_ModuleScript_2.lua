-- Roblox: ReplicatedStorage.Shared.Configs.Character.Belt.BeltPouch.Belt.BeltPouchConfiguration.SL6345DO_Low
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = {
            primary = "rbxassetid://79560207474282",
            secondary = "rbxassetid://79560207474282"
        },
        RangerGreen = {
            primary = "rbxassetid://113144118102924",
            secondary = "rbxassetid://113144118102924"
        },
        Coyote498 = {
            primary = "rbxassetid://76479261707167",
            secondary = "rbxassetid://76479261707167"
        },
        VaricamBlk = {
            primary = "rbxassetid://137198407377405",
            secondary = "rbxassetid://137198407377405"
        },
        Black = {
            primary = "rbxassetid://73780258330687",
            secondary = "rbxassetid://73780258330687"
        }
    }
};