-- Roblox: ReplicatedStorage.Shared.Configs.Character.Belt.BeltPouch.Belt.BeltPouch.SL6345DO
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {
        BeltPouchConfiguration = { "SL6345DO_Mid", "SL6345DO_Low", "SL6345DO_High" }
    },
    Default = {
        BeltPouchConfiguration = "SL6345DO_Mid"
    },
    Config = {
        Tune = {}
    },
    Textures = {}
};