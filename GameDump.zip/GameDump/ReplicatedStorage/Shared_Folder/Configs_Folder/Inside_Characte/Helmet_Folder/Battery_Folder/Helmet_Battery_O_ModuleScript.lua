-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.Battery.Helmet.Battery.OPSCORE_CounterWeight
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {},
    Textures = {}
};