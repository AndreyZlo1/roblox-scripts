-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.Event Helmet.Helmet.Harness.ChristmasHat_Default
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = "rbxassetid://130194602813338"
    }
};