-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.Device Velcro.Helmet.DeviceVelcro.HGU56P_ANVIS
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {
        HelmetVelcro = { "Headgear_LoopLeft_MICH", "none" },
        Battery = { "HGU56P_ANVIS" }
    },
    Default = {
        HelmetVelcro = "",
        Battery = "HGU56P_ANVIS"
    },
    Config = {},
    Textures = {
        Default = "rbxassetid://132196855611936"
    }
};