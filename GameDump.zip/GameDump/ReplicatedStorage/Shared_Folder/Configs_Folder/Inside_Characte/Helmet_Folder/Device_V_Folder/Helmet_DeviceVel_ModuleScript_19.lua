-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.Device Velcro.Helmet.DeviceVelcro.Vlite_Helmet_CurveA_IR
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {
        Strobe = { "Vlite" }
    },
    Default = {
        Strobe = "Vlite"
    },
    Attachments = {
        Strobe = {
            {
                Name = "NIR flash",
                IsIR = true,
                StrobeSpeed = 0.75,
                StrobeBlink = 0.25,
                Color = Color3.new(1, 1, 1)
            },
            {
                Name = "NIR steady",
                IsIR = true,
                Color = Color3.new(1, 1, 1)
            }
        }
    },
    Config = {
        Tune = {}
    },
    Textures = {
        Default = {
            primary = "rbxassetid://113126666216805"
        },
        Black = {
            primary = "rbxassetid://100306295744432"
        }
    }
};