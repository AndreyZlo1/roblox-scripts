-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.Device Velcro.Helmet.DeviceVelcro.BNVD_Default
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {
        Battery = { "BNVD" }
    },
    Default = {
        Battery = "BNVD"
    },
    Config = {},
    Textures = {
        Default = "rbxassetid://71963571259675",
        SemiAridSpray = "rbxassetid://99102628650513",
        AridSpray = "rbxassetid://92756999424384",
        TanSpray = "rbxassetid://89810367100042",
        GreenSpray = "rbxassetid://70577928704513",
        LightAridSpray = "rbxassetid://136221273762582",
        WhiteSpray = "rbxassetid://116725066172011",
        AlpineSpray = "rbxassetid://118467083914305"
    }
};