-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.Device Velcro.Helmet.DeviceVelcro.MOHOC
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {
        Strobe = { "MOHOC" }
    },
    Default = {
        Strobe = "MOHOC"
    },
    Config = {},
    Textures = {
        Default = "rbxassetid://73567480086510",
        AridSpray = "rbxassetid://91700222307829",
        GunAridSpray = "rbxassetid://74951618739255",
        WhiteSpray = "rbxassetid://118977804967841",
        TanSpray = "rbxassetid://98820836598804",
        AlpineSpray = "rbxassetid://120678465852093"
    }
};