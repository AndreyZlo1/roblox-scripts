-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.Device Velcro.Helmet.DeviceVelcro.OPSCORE_CounterWeight_OpscoreCover
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {
        Battery = { "OPSCORE_CounterWeight" }
    },
    Default = {
        Battery = "OPSCORE_CounterWeight"
    },
    Config = {},
    Textures = {
        Default = "rbxassetid://92055622176124",
        Black = "rbxassetid://136546245893433",
        FoliageGreen = "rbxassetid://101750772767441",
        SemiAridSpray = "rbxassetid://77967695116853",
        AridSpray = "rbxassetid://87753693122857",
        WhiteSpray = "rbxassetid://133936902113054",
        AlpineSpray = "rbxassetid://131285811579658",
        DarkSemiAridSpray = "rbxassetid://112031957740589"
    }
};