-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.Device Velcro.Helmet.DeviceVelcro.SDU39
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {
        Strobe = { "SDU39" }
    },
    Default = {
        Strobe = "SDU39"
    },
    Attachments = {
        Strobe = {
            {
                Name = "NIR flash",
                IsIR = true,
                StrobeSpeed = 0.95,
                StrobeBlink = 0.05,
                Color = Color3.new(1, 1, 1)
            },
            {
                Name = "white flash",
                IsIR = false,
                StrobeSpeed = 0.95,
                StrobeBlink = 0.05,
                Color = Color3.new(1, 1, 1)
            }
        }
    },
    Config = {
        Tune = {}
    },
    Textures = {
        Default = {
            primary = "rbxassetid://75209374963731"
        }
    }
};