-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.Device Velcro.Helmet.DeviceVelcro.Vlite_Helmet_CurveBatt_Green
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {
        Strobe = { "Vlite" }
    },
    Default = {
        Strobe = "Vlite"
    },
    Attachments = {
        Strobe = {
            {
                Name = "green steady",
                IsIR = false,
                Brightness = 0.3,
                Transparency = 0.5,
                Color = Color3.new(0.588235, 0.811764, 0.588235)
            },
            {
                Name = "green flash",
                IsIR = false,
                StrobeSpeed = 0.95,
                StrobeBlink = 0.05,
                Color = Color3.new(0.592156, 1, 0.592156)
            },
            {
                Name = "blue steady",
                IsIR = false,
                Brightness = 0.3,
                Transparency = 0.5,
                Color = Color3.new(0.490196, 0.654901, 0.768627)
            },
            {
                Name = "blue flash",
                IsIR = false,
                StrobeSpeed = 0.95,
                StrobeBlink = 0.05,
                Color = Color3.new(0.588235, 0.721568, 0.811764)
            },
            {
                Name = "red steady",
                IsIR = false,
                Brightness = 0.3,
                Transparency = 0.5,
                Color = Color3.new(0.780392, 0.45098, 0.45098)
            },
            {
                Name = "red flash",
                IsIR = false,
                StrobeSpeed = 0.95,
                StrobeBlink = 0.05,
                Color = Color3.new(0.913725, 0.435294, 0.435294)
            }
        }
    },
    Config = {
        Tune = {}
    },
    Textures = {
        Default = {
            primary = "rbxassetid://113126666216805"
        },
        Black = {
            primary = "rbxassetid://100306295744432"
        }
    }
};