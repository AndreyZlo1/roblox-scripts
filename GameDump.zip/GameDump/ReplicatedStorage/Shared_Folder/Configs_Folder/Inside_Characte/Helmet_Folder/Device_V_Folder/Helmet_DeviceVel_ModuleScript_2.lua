-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.Device Velcro.Helmet.DeviceVelcro.HELLSTAR6
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {
        Strobe = { "HELLSTAR6" }
    },
    Default = {
        Strobe = "HELLSTAR6"
    },
    Attachments = {
        Strobe = {
            {
                Name = "green steady",
                IsIR = false,
                Brightness = 0.5,
                Transparency = 0.5,
                Color = Color3.new(0.592156, 1, 0.592156)
            },
            {
                Name = "green steady-dim + white flash",
                IsIR = false,
                StrobeSpeed = 0.95,
                StrobeBlink = 0.05,
                Color = Color3.new(0.592156, 1, 0.592156)
            },
            {
                Name = "NIR flash",
                IsIR = true,
                StrobeSpeed = 0.75,
                StrobeBlink = 0.25,
                Color = Color3.new(1, 1, 1)
            },
            {
                Name = "NIR steady",
                IsIR = true,
                Color = Color3.new(1, 1, 1)
            }
        }
    },
    Config = {
        Tune = {}
    },
    Textures = {
        Default = {
            primary = "rbxassetid://97966935696325"
        },
        Black = {
            primary = "rbxassetid://83425034129027"
        }
    }
};