-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.CivilianHelmetSlot.Helmet.Helmet.HardHat
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = "rbxassetid://137713151080702",
        White = "rbxassetid://90432378071421",
        Yellow = "rbxassetid://128622238509100",
        Red = "rbxassetid://104399128813346",
        Blue = "rbxassetid://72561225958245"
    }
};