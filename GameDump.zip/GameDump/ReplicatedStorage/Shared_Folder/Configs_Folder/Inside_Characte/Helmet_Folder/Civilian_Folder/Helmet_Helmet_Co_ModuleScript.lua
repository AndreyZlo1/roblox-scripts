-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.CivilianHelmetSlot.Helmet.Helmet.CowboyHat
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = "rbxassetid://95408362956505"
    }
};