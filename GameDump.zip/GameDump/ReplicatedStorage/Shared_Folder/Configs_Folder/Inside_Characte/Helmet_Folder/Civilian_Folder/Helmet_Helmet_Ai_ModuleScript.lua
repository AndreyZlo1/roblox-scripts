-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.CivilianHelmetSlot.Helmet.Helmet.AirsoftHelmet
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = {
            main = "rbxassetid://102671881724129",
            padding = "rbxassetid://82142008243578",
            harness = "rbxassetid://130194602813338",
            rails = "rbxassetid://98801008780325",
            velcro = "rbxassetid://98801008780325",
            mount = "rbxassetid://80809079287847"
        }
    }
};