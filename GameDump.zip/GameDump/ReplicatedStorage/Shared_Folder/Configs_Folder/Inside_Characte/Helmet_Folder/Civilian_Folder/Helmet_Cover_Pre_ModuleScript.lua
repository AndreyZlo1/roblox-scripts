-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.CivilianHelmetSlot.Helmet.Cover.PressHelmet
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = "rbxassetid://138683294081552"
    }
};