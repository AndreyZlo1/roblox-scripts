-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.CivilianHelmetSlot.Helmet.Helmet.SwatHelmet
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {
        Shroud = { "shroud_AEGISMT_3hole" },
        Cover = { "helmetcover_AEGISSHC", "helmetcover_AEGISMT" },
        PeripheralType = { "FASTMT_Empty", "FASTMT_FastMT" },
        Harness = { "headharness_AEGISMT" },
        SubWear = { "none", "SubBeanie" },
        Mount = { "none", "ESS_OPSCORE_MT" }
    },
    Default = {
        Shroud = "FASTMT_Comm_Skeleton",
        PeripheralType = "FASTMT_Empty",
        Cover = "FASTMT_Comm_VELCRO",
        Harness = "FASTMT_Comm_Default",
        Mount = ""
    },
    Config = {
        Tune = {},
        Alter = {}
    },
    Textures = {
        Default = "rbxassetid://123826531723243",
        Black = "rbxassetid://97077399327688",
        FoliageGreen = "rbxassetid://92717733053664"
    }
};