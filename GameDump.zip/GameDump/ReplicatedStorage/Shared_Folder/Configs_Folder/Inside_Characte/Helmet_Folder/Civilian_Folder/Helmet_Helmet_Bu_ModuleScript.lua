-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.CivilianHelmetSlot.Helmet.Helmet.BucketHat
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = "rbxassetid://131146485385940",
        MilesJacksonKhaki = "rbxassetid://82207561899369",
        NavyBlue = "rbxassetid://114978648360215",
        OliveDrabGreen = "rbxassetid://118055263913615"
    }
};