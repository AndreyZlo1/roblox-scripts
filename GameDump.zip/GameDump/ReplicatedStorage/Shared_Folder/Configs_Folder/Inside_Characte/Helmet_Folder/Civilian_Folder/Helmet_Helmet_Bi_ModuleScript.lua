-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.CivilianHelmetSlot.Helmet.Helmet.BikeHelmet
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = {
            main = "rbxassetid://139358232975730",
            padding = "rbxassetid://82142008243578",
            harness = "rbxassetid://130194602813338"
        },
        NavyBlue = {
            main = "rbxassetid://139358232975730",
            padding = "rbxassetid://82142008243578",
            harness = "rbxassetid://130194602813338"
        },
        Black = {
            main = "rbxassetid://94256258952397",
            padding = "rbxassetid://82142008243578",
            harness = "rbxassetid://130194602813338"
        }
    }
};