-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.CivilianHelmetSlot.Helmet.Helmet.MilitaryHelmet
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {
        Lightcustom = { "none", "SUREFIREHC1" },
        Cover = { "none", "helmetcover_ACH" },
        Shroud = { "none", "shroud_ACH_1hole" },
        Harness = { "headharness_ACH" }
    },
    Default = {
        Harness = "ACH_Default"
    },
    Config = {
        Tune = {}
    },
    Textures = {
        Default = "rbxassetid://104130982413501"
    }
};