-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.CivilianHelmetSlot.Helmet.Helmet.PoliceHelmet
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = {
            main = "rbxassetid://91351919537393",
            harness = "rbxassetid://138683294081552"
        }
    }
};