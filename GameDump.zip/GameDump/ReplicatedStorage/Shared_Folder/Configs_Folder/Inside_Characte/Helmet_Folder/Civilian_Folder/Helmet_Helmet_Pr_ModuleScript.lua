-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.CivilianHelmetSlot.Helmet.Helmet.PressHelmet
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {
        Cover = { "none", "PressHelmet" }
    },
    Default = {
        Cover = "PressHelmet"
    },
    Config = {
        Tune = {}
    },
    Textures = {
        Default = {
            main = "rbxassetid://84870750163589",
            harness = "rbxassetid://138683294081552"
        }
    }
};