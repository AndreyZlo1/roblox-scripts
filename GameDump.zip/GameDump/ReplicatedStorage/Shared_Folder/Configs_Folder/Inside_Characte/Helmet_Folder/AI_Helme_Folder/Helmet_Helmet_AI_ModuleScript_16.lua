-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.AI_Helmet.Helmet.Helmet.AI_FASTXP_RiflemanD
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = {
            main = "rbxassetid://110756674470536",
            gear = "rbxassetid://76246408655237"
        },
        Gray = {
            main = "rbxassetid://113594517785746",
            gear = "rbxassetid://76246408655237"
        },
        Insolon = {
            main = "rbxassetid://121857355683073",
            gear = "rbxassetid://76246408655237"
        }
    }
};