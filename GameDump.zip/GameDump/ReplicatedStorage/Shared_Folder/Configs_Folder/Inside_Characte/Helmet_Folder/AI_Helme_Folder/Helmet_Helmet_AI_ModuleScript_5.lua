-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.AI_Helmet.Helmet.Helmet.AI_Altyn
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures_Low = {
        Default = "rbxassetid://72020446043660"
    },
    Textures = {
        Default = "rbxassetid://72020446043660"
    }
};