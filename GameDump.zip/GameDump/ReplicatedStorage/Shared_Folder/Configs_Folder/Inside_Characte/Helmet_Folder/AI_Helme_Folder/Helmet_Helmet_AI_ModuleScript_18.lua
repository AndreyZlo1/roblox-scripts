-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.AI_Helmet.Helmet.Helmet.AI_FieldCap
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {},
    Textures_Low = {
        Default = "rbxassetid://134859124918667",
        Desert = "rbxassetid://107354789850302"
    },
    Textures = {
        Default = "rbxassetid://134859124918667",
        Desert = "rbxassetid://107354789850302"
    }
};