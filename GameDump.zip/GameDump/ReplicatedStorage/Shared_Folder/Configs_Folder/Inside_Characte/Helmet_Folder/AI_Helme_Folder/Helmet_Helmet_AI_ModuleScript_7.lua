-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.AI_Helmet.Helmet.Helmet.AI_Beanie2
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Tan499 = "rbxassetid://81684570181121",
        RangerGreen = "rbxassetid://126808148756614",
        OliveDrabGreen = "rbxassetid://127049006917605",
        Red = "rbxassetid://128209170852847",
        NavyBlue = "rbxassetid://72766505344216",
        Gray = "rbxassetid://88873490844527",
        Black = "rbxassetid://84766820343197",
        Default = {
            "rbxassetid://123538387614453",
            "rbxassetid://81684570181121",
            "rbxassetid://126808148756614",
            "rbxassetid://128209170852847",
            "rbxassetid://72766505344216",
            "rbxassetid://84766820343197"
        }
    }
};