-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.AI_Helmet.Helmet.Helmet.AI_CapF
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = {
            "rbxassetid://105138207115630",
            "rbxassetid://85745832754964",
            "rbxassetid://78043048687210",
            "rbxassetid://107771258029064"
        }
    }
};