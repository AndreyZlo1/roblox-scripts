-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.AI_Helmet.Helmet.Helmet.AI_6B26
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = "rbxassetid://134859124918667",
        Desert = "rbxassetid://107354789850302"
    }
};