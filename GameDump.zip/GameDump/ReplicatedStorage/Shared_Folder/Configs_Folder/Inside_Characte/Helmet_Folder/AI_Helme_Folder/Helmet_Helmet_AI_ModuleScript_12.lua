-- Roblox: ReplicatedStorage.Shared.Configs.Character.Helmet.AI_Helmet.Helmet.Helmet.AI_FASTXP
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {
        Tune = {}
    },
    Textures = {
        Default = "rbxassetid://110756674470536"
    }
};