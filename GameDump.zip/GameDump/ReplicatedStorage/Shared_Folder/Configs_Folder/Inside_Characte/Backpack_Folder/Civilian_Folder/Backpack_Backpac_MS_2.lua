-- Roblox: ReplicatedStorage.Shared.Configs.Character.Backpack.CivilianBackpackSlot.Backpack.Backpack.HikingBag
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    EquipPoint = "UpperTorso",
    Storage = "HikingBag",
    Size = Vector2.new(5, 6),
    Compatible = {},
    Default = {},
    Config = {
        Tune = {
            Weight = 1950
        }
    },
    Textures = {
        Default = "rbxassetid://93100827103123",
        OliveDrabGreen = "rbxassetid://106113108258890",
        Orange = "rbxassetid://74301620814096",
        Green = "rbxassetid://81311572686021",
        NavyBlue = "rbxassetid://113815774910688"
    }
};