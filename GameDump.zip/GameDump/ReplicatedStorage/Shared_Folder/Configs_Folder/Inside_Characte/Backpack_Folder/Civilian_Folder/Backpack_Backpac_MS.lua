-- Roblox: ReplicatedStorage.Shared.Configs.Character.Backpack.CivilianBackpackSlot.Backpack.Backpack.DuffleBag
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    EquipPoint = "UpperTorso",
    Storage = "DuffleBag",
    Size = Vector2.new(4, 3),
    Compatible = {},
    Default = {},
    Config = {
        Tune = {
            Weight = 650
        }
    },
    Textures = {
        Default = "rbxassetid://86778759361744",
        OliveDrabGreen = "rbxassetid://127430782416009",
        Orange = "rbxassetid://99490120782143",
        Green = "rbxassetid://74869407005541",
        NavyBlue = "rbxassetid://96736942829257"
    }
};