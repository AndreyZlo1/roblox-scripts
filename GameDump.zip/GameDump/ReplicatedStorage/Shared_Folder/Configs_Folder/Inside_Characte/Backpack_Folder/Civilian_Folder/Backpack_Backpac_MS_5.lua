-- Roblox: ReplicatedStorage.Shared.Configs.Character.Backpack.CivilianBackpackSlot.Backpack.Backpack.SchoolBag
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    EquipPoint = "UpperTorso",
    Storage = "SchoolBag",
    Size = Vector2.new(4, 4),
    Compatible = {},
    Default = {},
    Config = {
        Tune = {
            Weight = 550
        }
    },
    Textures = {
        Default = "rbxassetid://103789306346348",
        OliveDrabGreen = "rbxassetid://84968759034364",
        Orange = "rbxassetid://72154672900495",
        Green = "rbxassetid://121788498959504",
        NavyBlue = "rbxassetid://73364708403791"
    }
};