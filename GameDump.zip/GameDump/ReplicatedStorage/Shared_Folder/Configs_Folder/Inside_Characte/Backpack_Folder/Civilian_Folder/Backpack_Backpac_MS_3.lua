-- Roblox: ReplicatedStorage.Shared.Configs.Character.Backpack.CivilianBackpackSlot.Backpack.Backpack.MedicalDuffleBag
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    EquipPoint = "UpperTorso",
    Storage = "DuffleBag",
    Size = Vector2.new(4, 3),
    Compatible = {},
    Default = {},
    Config = {
        Tune = {
            Weight = 650
        }
    },
    Textures = {
        Default = "rbxassetid://91219033702214",
        Red = "rbxassetid://85473009125897"
    }
};