-- Roblox: ReplicatedStorage.Shared.Configs.Character.Eyewear.Glass.Eyewear.Glass.Oakley_Holbrook_TintedYellow
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Compatible = {},
    Default = {},
    Config = {},
    Textures = {
        Default = ""
    }
};