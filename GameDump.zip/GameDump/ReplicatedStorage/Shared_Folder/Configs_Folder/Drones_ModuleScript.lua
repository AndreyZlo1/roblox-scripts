-- Roblox: ReplicatedStorage.Shared.Configs.Drones
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Ravic2 = {
        Range = 1200,
        SpotDistance = 300,
        SpotMax = 10,
        SpotTime = 2,
        BatterySeconds = 300,
        Overlay = "Ravic2",
        Speed = 60,
        Hitbox = 0.5,
        Equip = 3,
        Offset = CFrame.Angles(0, 3.141592653589793, 0)
    }
};