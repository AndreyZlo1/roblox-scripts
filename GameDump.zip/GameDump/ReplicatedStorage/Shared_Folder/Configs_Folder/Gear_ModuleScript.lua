-- Roblox: ReplicatedStorage.Shared.Configs.Gear
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = shared.import("Enum");
return {
    Binoculars = {
        Name = "Binoculars",
        Weight = 560,
        Rarity = 2,
        Model = "Binoculars",
        Overlay = "Binoculars",
        Zoom = 1.5,
        Size = Vector2.new(2, 1),
        Type = v1.GearType.Binoculars,
        Magnify = { 30, 65 }
    },
    RangeFinder = {
        Name = "Range finder",
        Weight = 350,
        Rarity = 2,
        Model = "RangeFinder",
        Overlay = "RangeFinder",
        Zoom = 1.5,
        Range = 3900,
        Size = Vector2.new(2, 1),
        Type = v1.GearType.RangeFinder,
        Magnify = { 60, 60 }
    },
    Helix = {
        Name = "Cobra HD 3000",
        Rarity = 3,
        Weight = 240,
        Model = "Helix",
        Overlay = "Helix",
        Zoom = 1.5,
        Range = 7000,
        Size = Vector2.new(1, 1),
        Type = v1.GearType.RangeFinder,
        Magnify = { 65, 65 }
    },
    CSEL = {
        Name = "CSEL",
        Description = "Use to call an EXFIL",
        Rarity = 4,
        Weight = 1088,
        Model = "CSEL",
        Zoom = 2.5,
        Size = Vector2.new(1, 2),
        Type = v1.GearType.CSEL
    }
};