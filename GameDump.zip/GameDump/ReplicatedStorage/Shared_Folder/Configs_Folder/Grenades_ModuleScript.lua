-- Roblox: ReplicatedStorage.Shared.Configs.Grenades
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = shared.import("Enum");
return {
    RGD5 = {
        Weight = 310,
        Name = "RGD-5",
        Model = "RGD5",
        Description = "A robust fragmentation grenade of Soviet origin. ~3.6-second fuze length.",
        Fuze = 3.6,
        Size = Vector2.new(1, 1),
        GrenadeType = v1.GrenadeType.Explosive
    },
    F1 = {
        Weight = 600,
        Name = "F-1",
        Model = "F1",
        Description = "A Russian-made fragmentation grenade, derived from the successful French F-1 design. ~3.5-second fuze length.",
        Fuze = 3.5,
        Size = Vector2.new(1, 1),
        GrenadeType = v1.GrenadeType.Explosive
    },
    VOG25 = {
        Name = "VOG-25 \'Khattabka\'",
        Model = "VOG25",
        Description = "A modified VOG-25 fragmentation grenade designed to be thrown by hand. ~2-second fuze length.",
        Fuze = 2,
        Weight = 250,
        Size = Vector2.new(1, 1),
        GrenadeType = v1.GrenadeType.Explosive
    },
    RGD2White = {
        Weight = 600,
        Name = "RGD-2 (white)",
        Model = "RGD2White",
        Description = "A rudimentary Soviet-era smoke grenade with a simple ignition mechanism.",
        Size = Vector2.new(1, 1),
        GrenadeType = v1.GrenadeType.Smoke
    },
    RGDMWhite = {
        Weight = 500,
        Name = "RGD-M (white)",
        Model = "RGDMWhite",
        Description = "A purpose-built Russian smoke grenade, useful for concealing movement.",
        Size = Vector2.new(1, 1),
        GrenadeType = v1.GrenadeType.Smoke
    },
    M67 = {
        Weight = 390,
        Name = "M67",
        Model = "M67",
        Sounds = "M67",
        Description = "An American fragmentation hand grenade with an updated safety mechanism. ~5.2-second fuze length.",
        Fuze = 5.3,
        Size = Vector2.new(1, 1),
        GrenadeType = v1.GrenadeType.Explosive
    },
    M67Training = {
        Weight = 230,
        Name = "M69",
        Model = "M67Training",
        Description = "Designed for training use, the M69 simulates the weight and feel of a typical M67. ~5.2-second fuze length.",
        Size = Vector2.new(1, 1),
        GrenadeType = v1.GrenadeType.Dummy
    },
    M18Red = {
        Weight = 530,
        Name = "M18 (red)",
        Model = "M18Red",
        Description = "Available in several colors, the M18 produces a distinct smoke plume for signaling and concealment use.",
        Size = Vector2.new(1, 1),
        GrenadeType = v1.GrenadeType.Smoke
    },
    M18Yellow = {
        Weight = 530,
        Name = "M18 (yellow)",
        Model = "M18Yellow",
        Description = "Available in several colors, the M18 produces a distinct smoke plume for signaling and concealment use.",
        Size = Vector2.new(1, 1),
        GrenadeType = v1.GrenadeType.Smoke
    },
    M18Green = {
        Weight = 530,
        Name = "M18 (green)",
        Model = "M18Green",
        Description = "Available in several colors, the M18 produces a distinct smoke plume for signaling and concealment use.",
        Size = Vector2.new(1, 1),
        GrenadeType = v1.GrenadeType.Smoke
    },
    M83 = {
        Weight = 530,
        Name = "AN/M83 (white)",
        Model = "M83",
        Description = "A TA-based smoke grenade designed to provide expedient and effective screening for movement.",
        Size = Vector2.new(1, 1),
        GrenadeType = v1.GrenadeType.Smoke
    },
    M84 = {
        Weight = 370,
        Name = "M84",
        Model = "M84",
        Description = "A distinctive stun grenade, useful for gaining an advantage in close-quarters battle. ~1.9-second fuze length.",
        Fuze = 1.9,
        Size = Vector2.new(1, 1),
        GrenadeType = v1.GrenadeType.Flash
    },
    Flare = {
        Name = "Road flare",
        Model = "Flare",
        Description = "A simple road flare. Produces bright illumination and smoke for signaling use.",
        Size = Vector2.new(1, 1),
        GrenadeType = v1.GrenadeType.Flare
    },
    GlowStickRed = {
        Name = "Glow stick (red)",
        Model = "GlowStickRed",
        Description = "A military-grade chemical light for various signaling applications. Produces bright and long-lasting illumination in an area.",
        Size = Vector2.new(1, 1),
        GrenadeType = v1.GrenadeType.Glowstick
    },
    GlowStickGreen = {
        Name = "Glow stick (green)",
        Model = "GlowStickGreen",
        Description = "A military-grade chemical light for various signaling applications. Produces bright and long-lasting illumination in an area.",
        Size = Vector2.new(1, 1),
        GrenadeType = v1.GrenadeType.Glowstick
    },
    GlowStickYellow = {
        Name = "Glow stick (yellow)",
        Model = "GlowStickYellow",
        Description = "A military-grade chemical light for various signaling applications. Produces bright and long-lasting illumination in an area.",
        Size = Vector2.new(1, 1),
        GrenadeType = v1.GrenadeType.Glowstick
    },
    GlowStickBlue = {
        Name = "Glow stick (blue)",
        Model = "GlowStickBlue",
        Description = "A military-grade chemical light for various signaling applications. Produces bright and long-lasting illumination in an area.",
        Size = Vector2.new(1, 1),
        GrenadeType = v1.GrenadeType.Glowstick
    }
};