-- Roblox: ReplicatedStorage.Shared.Configs.Character
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
for _, v2 in script:GetDescendants() do
    if v2:IsA("ModuleScript") then
        local v3 = v2.Name:split(".");
        local v4 = v1;
        v1 = v4;
        for v5 = 1, #v3 do
            local v6 = v3[v5];
            if v5 < #v3 then
                if v1[v6] then
                    v1 = v1[v6];
                    v4 = v1;
                else
                    v1[v6] = {};
                    v1 = v1[v6];
                    v4 = v1;
                end;
            else
                v1[v6] = require(v2);
                v1[v6].__IsLast = true;
                v4 = v1;
            end;
            v1 = v4;
        end;
    end;
end;
return v1;