-- Roblox: ReplicatedStorage.Shared.Configs.Bots.FearPresets
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Militia = {
        MinimumFearInvestigate = 0.4,
        FearDamper = 1,
        FearRunout = 2,
        ForgetTimer = 5
    },
    RLF = {
        MinimumFearInvestigate = 0.4,
        FearDamper = 1,
        FearRunout = 2,
        ForgetTimer = 5
    },
    RLFSniper = {
        MinimumFearInvestigate = 0.9,
        FearDamper = 0.5,
        FearRunout = 4,
        ForgetTimer = 8
    },
    RLFVIP = {
        MinimumFearInvestigate = 0.4,
        FearDamper = 0.5,
        FearRunout = 4,
        ForgetTimer = 8
    },
    POD = {
        MinimumFearInvestigate = 0.125,
        FearDamper = 1.2,
        FearRunout = 7,
        ForgetTimer = 15
    },
    Spec = {
        MinimumFearInvestigate = 0.1,
        FearDamper = 2,
        FearRunout = 10,
        ForgetTimer = 20
    },
    Bandit = {
        MinimumFearInvestigate = 0.4,
        FearDamper = 0.5,
        FearRunout = 5,
        ForgetTimer = 15
    },
    Sheepdog = {
        MinimumFearInvestigate = 0.2,
        FearDamper = 0.5,
        FearRunout = 5,
        ForgetTimer = 20
    },
    Kismet = {
        MinimumFearInvestigate = 0.2,
        FearDamper = 0.5,
        FearRunout = 5,
        ForgetTimer = 20
    },
    MercLow = {
        MinimumFearInvestigate = 0.2,
        FearDamper = 0.5,
        FearRunout = 5,
        ForgetTimer = 20
    },
    MercHigh = {
        MinimumFearInvestigate = 0,
        FearDamper = 0.5,
        FearRunout = 2,
        ForgetTimer = 30
    },
    Zombie = {
        MinimumFearInvestigate = 0,
        FearDamper = 0.33,
        FearRunout = 3,
        ForgetTimer = 10
    }
};