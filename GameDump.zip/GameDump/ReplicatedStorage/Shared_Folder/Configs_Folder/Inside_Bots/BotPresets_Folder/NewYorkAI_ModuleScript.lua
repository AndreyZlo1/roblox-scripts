-- Roblox: ReplicatedStorage.Shared.Configs.Bots.BotPresets.NewYorkAI
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Bandit_Pistol_Low = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        Hidden = false,
        RadioTime = 7,
        EquipTimer = 0.1,
        NoPrimary = true,
        Fear = "Bandit",
        Appearance = "Bandit_Rifleman",
        SecondaryDistance = 600,
        MeleeDistance = 1,
        Health = 50,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 30, 40 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Secondary = {
            { "AI_Glock17G3" },
            { "AI_M9Berretta" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 100, 1 },
            { 600, 4 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 10, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 4
        },
        RateOfFireSecondary = {
            {
                0,
                2,
                3,
                0.1,
                0.05,
                0.35
            },
            {
                50,
                1,
                2,
                0.1,
                0.1,
                0.5
            },
            {
                150,
                1,
                1,
                0.1,
                0.3,
                0.75
            },
            {
                299,
                1,
                1,
                0.1,
                0.4,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 6, 0.4 },
        WeaponAccuracy = {
            { 0, 5 },
            { 20, 6 },
            { 300, 12 }
        }
    },
    Bandit_Shotgun_Low = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        Hidden = false,
        RadioTime = 7,
        EquipTimer = 0.1,
        NoSecondary = true,
        Fear = "Bandit",
        Appearance = "Bandit_Rifleman",
        Health = 50,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 30, 40 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_DB" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 100, 1 },
            { 600, 4 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 10, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 4
        },
        RateOfFire = {
            {
                0,
                1,
                2,
                0.1,
                0.25,
                2
            },
            {
                40,
                1,
                2,
                0.1,
                0.5,
                2
            },
            {
                41,
                1,
                1,
                0.1,
                0.5,
                1
            },
            {
                249,
                1,
                1,
                0.1,
                0.75,
                1.5
            },
            {
                250,
                0,
                0,
                0.4
            }
        },
        WeaponAccuracyDamper = { 4, 0.5 },
        WeaponAccuracy = {
            { 0, 4.5 },
            { 300, 10 }
        }
    },
    Bandit_Sniper_Low = {
        Behaviour = "Combat",
        Hidden = false,
        IsFriendly = false,
        UseMG = true,
        UseMotar = true,
        UseCover = true,
        RadioTime = 5,
        NoSecondary = true,
        Appearance = "Bandit_Rifleman",
        Fear = "Bandit",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Health = 50,
        ProneMultiplier = 1,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.01,
        DetectionTargetKnownMultiplier = 0.01,
        Rewards = {
            Base = { 40, 50 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_R700" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.4,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 100, 1 },
            { 600, 4 }
        },
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 100, 300 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 13,
            Idle = 3.5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                3,
                0.5,
                2
            },
            {
                300,
                1,
                1,
                3,
                1,
                2
            },
            {
                600,
                1,
                1,
                3,
                5,
                10
            }
        },
        WeaponAccuracyDamper = { 5, 0.75 },
        WeaponAccuracy = {
            { 0, 6 },
            { 600, 12 }
        }
    },
    Bandit_Smg = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.1,
        Hidden = false,
        NoSecondary = true,
        Appearance = "Bandit_Rifleman",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 35, 45 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_MP5" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 20, 0.25 },
            { 75, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                2,
                4,
                0.06,
                0.15,
                0.5
            },
            {
                100,
                2,
                3,
                0.06,
                0.35,
                0.6
            },
            {
                150,
                1,
                2,
                0.06,
                0.35,
                1
            },
            {
                390,
                1,
                1,
                0.06,
                1,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.45 },
        WeaponAccuracy = {
            { 0, 7 },
            { 15, 5 },
            { 50, 7 },
            { 150, 8 }
        }
    },
    Bandit_Pistol = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        Hidden = false,
        RadioTime = 7,
        EquipTimer = 0.1,
        NoPrimary = true,
        Fear = "Bandit",
        Appearance = "Bandit_Rifleman",
        SecondaryDistance = 600,
        Health = 50,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 35, 45 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Secondary = {
            { "AI_Glock17G3" },
            { "AI_M9Berretta" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 100, 1 },
            { 600, 4 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 10, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 4
        },
        RateOfFireSecondary = {
            {
                0,
                2,
                3,
                0.1,
                0.05,
                0.35
            },
            {
                50,
                1,
                2,
                0.1,
                0.1,
                0.5
            },
            {
                150,
                1,
                1,
                0.1,
                0.3,
                0.75
            },
            {
                299,
                1,
                1,
                0.1,
                0.4,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 6, 0.4 },
        WeaponAccuracy = {
            { 0, 5 },
            { 20, 6 },
            { 300, 12 }
        }
    },
    Bandit_Shotgun = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        Hidden = false,
        RadioTime = 7,
        EquipTimer = 0.1,
        NoSecondary = true,
        MeleeDistance = 1,
        Fear = "Bandit",
        Appearance = "Bandit_Rifleman",
        Health = 90,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 2,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 35, 45 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_DB" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 100, 1 },
            { 600, 4 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 10, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 4
        },
        RateOfFire = {
            {
                0,
                1,
                2,
                0.1,
                0.25,
                2
            },
            {
                40,
                1,
                2,
                0.1,
                0.5,
                2
            },
            {
                41,
                1,
                1,
                0.1,
                0.5,
                1
            },
            {
                249,
                1,
                1,
                0.1,
                0.75,
                1.5
            },
            {
                250,
                0,
                0,
                0.4
            }
        },
        WeaponAccuracyDamper = { 4, 0.5 },
        WeaponAccuracy = {
            { 0, 4.5 },
            { 300, 15 }
        }
    },
    Bandit_Marksman = {
        Behaviour = "Combat",
        Hidden = false,
        IsFriendly = false,
        UseMG = true,
        UseMotar = true,
        UseCover = true,
        RadioTime = 5,
        NoSecondary = true,
        Appearance = "Bandit_Rifleman",
        Fear = "Bandit",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Health = 90,
        ProneMultiplier = 1,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.01,
        DetectionTargetKnownMultiplier = 0.01,
        Rewards = {
            Base = { 50, 60 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_AR15" }
        },
        ViewDistance = {
            Day = { 500, 800 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.4,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 100, 1 },
            { 600, 4 }
        },
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 100, 300 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 13,
            Idle = 3.5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                0.1,
                0.05,
                0.25
            },
            {
                100,
                1,
                1,
                0.1,
                0.2,
                0.35
            },
            {
                200,
                1,
                1,
                0.1,
                0.2,
                0.5
            },
            {
                600,
                1,
                1,
                0.1,
                0.3,
                1
            }
        },
        WeaponAccuracyDamper = { 5, 0.75 },
        WeaponAccuracy = {
            { 0, 6 },
            { 600, 12 }
        }
    },
    Bandit_Smg_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.1,
        Hidden = false,
        NoSecondary = true,
        Appearance = "Bandit_Rifleman",
        Fear = "Bandit",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 45, 50 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_UMP45" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 20, 0.25 },
            { 75, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                4,
                8,
                0.06,
                0.15,
                0.5
            },
            {
                100,
                2,
                3,
                0.06,
                0.35,
                0.6
            },
            {
                150,
                1,
                2,
                0.06,
                0.35,
                1
            },
            {
                390,
                1,
                1,
                0.06,
                1,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.65 },
        WeaponAccuracy = {
            { 0, 10 },
            { 5, 4 },
            { 50, 4 },
            { 150, 8 }
        }
    },
    Bandit_Rifleman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        MeleeRange = 10,
        NoSecondary = true,
        Appearance = "Bandit_Rifleman",
        Fear = "Bandit",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 35, 45 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_AR15" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 100, 1 },
            { 600, 4 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                1,
                0.08,
                0.25,
                0.5
            },
            {
                100,
                1,
                1,
                0.08,
                0.35,
                0.6
            },
            {
                200,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.65 },
        WeaponAccuracy = {
            { 0, 7 },
            { 50, 6 },
            { 400, 8 }
        }
    },
    Bandit_Shotgun_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        Hidden = false,
        RadioTime = 7,
        EquipTimer = 0.1,
        NoSecondary = true,
        Fear = "Bandit",
        Appearance = "Bandit_Rifleman",
        Health = 90,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 45, 50 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M590" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 100, 1 },
            { 600, 4 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 10, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 4
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                1,
                0.35,
                2
            },
            {
                40,
                1,
                1,
                1,
                0.5,
                2
            },
            {
                41,
                1,
                1,
                1,
                0.5,
                2
            },
            {
                249,
                1,
                1,
                1,
                0.75,
                3
            },
            {
                250,
                0,
                0,
                0.4
            }
        },
        WeaponAccuracyDamper = { 4, 0.5 },
        WeaponAccuracy = {
            { 0, 4.5 },
            { 300, 15 }
        }
    },
    Bandit_Sniper_Heavy = {
        Behaviour = "Combat",
        Hidden = false,
        IsFriendly = false,
        UseMG = true,
        UseMotar = true,
        UseCover = true,
        RadioTime = 5,
        NoSecondary = true,
        Appearance = "Bandit_Rifleman",
        Fear = "Bandit",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Health = 90,
        ProneMultiplier = 1,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.01,
        DetectionTargetKnownMultiplier = 0.01,
        Rewards = {
            Base = { 50, 60 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_R700" }
        },
        ViewDistance = {
            Day = { 600, 800 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.4,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 100, 1 },
            { 600, 4 }
        },
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 100, 300 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 13,
            Idle = 3.5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                1,
                0.25,
                0.5
            },
            {
                100,
                1,
                1,
                1,
                0.25,
                0.5
            },
            {
                200,
                1,
                1,
                1,
                0.2,
                0.5
            },
            {
                600,
                1,
                1,
                1,
                0.3,
                1
            }
        },
        WeaponAccuracyDamper = { 5, 0.75 },
        WeaponAccuracy = {
            { 0, 6 },
            { 600, 12 }
        }
    },
    Bandit_Rifleman_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        MeleeRange = 10,
        Appearance = "Bandit_Rifleman",
        Fear = "Bandit",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 45, 50 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_AR15" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 100, 1 },
            { 600, 4 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                1,
                0.08,
                0.25,
                0.5
            },
            {
                100,
                1,
                1,
                0.08,
                0.35,
                0.6
            },
            {
                200,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 10, 0.65 },
        WeaponAccuracy = {
            { 0, 7 },
            { 50, 6 },
            { 400, 8 }
        }
    },
    Sheepdog_Pistol_Low = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        Hidden = false,
        RadioTime = 7,
        EquipTimer = 0.1,
        NoPrimary = true,
        Fear = "Sheepdog",
        Appearance = "Sheepdog_Low",
        SecondaryDistance = 600,
        Health = 50,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 40, 50 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Secondary = {
            { "AI_Glock17G3" },
            { "AI_M9Berretta" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 100, 1 },
            { 600, 4 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 10, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 4
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                4,
                0.1,
                0.05,
                0.25
            },
            {
                50,
                1,
                3,
                0.1,
                0.1,
                0.5
            },
            {
                150,
                1,
                1,
                0.1,
                0.3,
                0.75
            },
            {
                299,
                1,
                1,
                0.1,
                0.4,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 6, 0.5 },
        WeaponAccuracy = {
            { 0, 3 },
            { 20, 4 },
            { 300, 12 }
        }
    },
    Sheepdog_Smg_Low = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMotar = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "Sheepdog_Low",
        Fear = "Sheepdog",
        Health = 50,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 40, 50 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_MP5" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                5,
                8,
                0.075,
                1,
                2
            },
            {
                50,
                5,
                8,
                0.075,
                0.25,
                0.5
            },
            {
                150,
                2,
                3,
                0.08,
                0.35,
                0.6
            },
            {
                200,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.5 },
        WeaponAccuracy = {
            { 0, 6 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Sheepdog_Shotgun_Low = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "Sheepdog_Low",
        Fear = "Sheepdog",
        Health = 50,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 40, 50 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M590" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                1,
                1,
                0.25,
                1
            },
            {
                200,
                1,
                1,
                1,
                0.5,
                4
            },
            {
                399,
                1,
                1,
                1,
                5,
                10
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.75 },
        WeaponAccuracy = {
            { 0, 6 },
            { 50, 9 },
            { 400, 12 }
        }
    },
    Sheepdog_Pistol = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        Hidden = false,
        RadioTime = 7,
        EquipTimer = 0.1,
        NoPrimary = true,
        Fear = "Sheepdog",
        Appearance = "Sheepdog_Pistol",
        SecondaryDistance = 600,
        Health = 90,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 45, 55 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Secondary = {
            { "AI_Glock17G3" },
            { "AI_M9Berretta" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 100, 1 },
            { 600, 4 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 10, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 4
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                4,
                0.1,
                0.05,
                0.25
            },
            {
                50,
                1,
                3,
                0.1,
                0.1,
                0.5
            },
            {
                150,
                1,
                1,
                0.1,
                0.3,
                0.75
            },
            {
                299,
                1,
                1,
                0.1,
                0.4,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 3, 0.5 },
        WeaponAccuracy = {
            { 0, 3 },
            { 20, 4 },
            { 300, 12 }
        }
    },
    Sheepdog_Smg = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "Sheepdog_Smg",
        Fear = "Sheepdog",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 45, 55 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_MP5" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                5,
                8,
                0.075,
                1,
                2
            },
            {
                50,
                5,
                8,
                0.075,
                0.25,
                0.5
            },
            {
                150,
                2,
                3,
                0.08,
                0.35,
                0.6
            },
            {
                200,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.5 },
        WeaponAccuracy = {
            { 0, 6 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Sheepdog_Shotgun = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "Sheepdog_Smg",
        Fear = "Sheepdog",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 45, 55 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M590" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                1,
                1,
                0.25,
                0.5
            },
            {
                200,
                1,
                1,
                1,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.25,
                1,
                4
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 4, 0.66 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Sheepdog_Marksman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "Sheepdog_Rifleman",
        Fear = "Sheepdog",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 55, 65 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_SR15" }
        },
        ViewDistance = {
            Day = { 600, 800 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                1,
                0.08,
                0.1,
                0.35
            },
            {
                200,
                1,
                1,
                0.08,
                0.2,
                0.6
            },
            {
                700,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                700,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 10, 0.66 },
        WeaponAccuracy = {
            { 0, 8 },
            { 400, 16 }
        }
    },
    Sheepdog_Sniper = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "Sheepdog_Smg",
        Fear = "Sheepdog",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 55, 65 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_R700" }
        },
        ViewDistance = {
            Day = { 600, 800 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                1,
                2,
                0.25,
                0.5
            },
            {
                799,
                1,
                1,
                2,
                1.5,
                3
            },
            {
                800,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 4, 0.9 },
        WeaponAccuracy = {
            { 0, 5 },
            { 400, 10 }
        }
    },
    Sheepdog_Rifleman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "Sheepdog_Rifleman",
        Fear = "Sheepdog",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 45, 55 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M4A1" },
            { "AI_SCARL" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                5,
                10,
                0.08,
                0.25,
                0.5
            },
            {
                20,
                2,
                5,
                0.08,
                0.25,
                0.5
            },
            {
                100,
                2,
                3,
                0.08,
                0.35,
                0.6
            },
            {
                200,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.6 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Sheepdog_Smg_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "Sheepdog_Smg",
        Fear = "Sheepdog",
        Health = 130,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 55, 65 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_UMP45" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                5,
                8,
                0.1,
                1,
                2
            },
            {
                50,
                5,
                8,
                0.1,
                0.25,
                0.5
            },
            {
                150,
                2,
                3,
                0.1,
                0.35,
                0.6
            },
            {
                200,
                1,
                1,
                0.1,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.1,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.5 },
        WeaponAccuracy = {
            { 0, 6 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Sheepdog_Shotgun_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "Sheepdog_Smg",
        Fear = "Sheepdog",
        Health = 130,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 55, 65 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M590" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                1,
                1,
                0.25,
                0.5
            },
            {
                100,
                1,
                1,
                1,
                0.35,
                0.6
            },
            {
                200,
                1,
                1,
                1,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                1,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 4, 0.4 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Sheepdog_Marksman_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "Sheepdog_Smg",
        Fear = "Sheepdog",
        Health = 140,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 65, 75 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_SR15" }
        },
        ViewDistance = {
            Day = { 600, 800 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.35,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                2,
                3,
                0.15,
                0.25,
                0.5
            },
            {
                100,
                1,
                1,
                0.15,
                0.35,
                0.6
            },
            {
                300,
                1,
                1,
                0.15,
                0.5,
                1
            },
            {
                500,
                1,
                1,
                0.15,
                0.5,
                2
            },
            {
                600,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 10, 0.8 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Sheepdog_Rifleman_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "Sheepdog_Smg",
        Fear = "Sheepdog",
        Health = 140,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 55, 65 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M4A1" },
            { "AI_SR15" },
            { "AI_SCARL" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                5,
                8,
                0.08,
                0.25,
                0.5
            },
            {
                100,
                2,
                3,
                0.08,
                0.35,
                0.6
            },
            {
                200,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 10, 0.4 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Sheepdog_Lmg = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "Sheepdog_Smg",
        Fear = "Sheepdog",
        Health = 140,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 70, 80 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M4A1" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                3,
                6,
                0.08,
                0.25,
                0.5
            },
            {
                100,
                2,
                3,
                0.08,
                0.35,
                0.6
            },
            {
                400,
                2,
                3,
                0.08,
                0.5,
                1
            },
            {
                600,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                700,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.6 },
        WeaponAccuracy = {
            { 0, 6 },
            { 400, 9 }
        }
    },
    Sheepdog_MG = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        Hidden = false,
        RadioTime = 7,
        EquipTimer = 0.1,
        NoPrimary = true,
        Fear = "Sheepdog",
        Appearance = "Sheepdog_Pistol",
        SecondaryDistance = 600,
        Health = 90,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1,
        DetectionFearMultiplier = 0.2,
        DetectionAlertedMultiplier = 0.05,
        DetectionTargetKnownMultiplier = 0.01,
        Rewards = {
            Base = { 70, 80 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Secondary = {
            { "AI_Glock17G3" },
            { "AI_M9Berretta" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.01 },
            { 300, 0.5 },
            { 600, 1 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 10, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 4
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.05,
                0.25
            },
            {
                50,
                1,
                1,
                0.1,
                0.1,
                0.5
            },
            {
                150,
                1,
                1,
                0.1,
                0.3,
                0.5
            },
            {
                299,
                1,
                1,
                0.1,
                0.4,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 4, 0.5 },
        WeaponAccuracy = {
            { 0, 6 },
            { 20, 8 },
            { 300, 10 }
        }
    },
    Sheepdog_VIP = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        Hidden = false,
        RadioTime = 7,
        EquipTimer = 0.1,
        HighPriority = true,
        NoPrimary = true,
        Fear = "Sheepdog",
        Appearance = "Sheepdog_Pistol",
        SecondaryDistance = 600,
        Health = 90,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 250, 300 },
            Headshot = { 5, 5 },
            Stealth = { 50, 50 }
        },
        Secondary = {
            { "AI_Glock17G3" },
            { "AI_M9Berretta" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 100, 1 },
            { 600, 4 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 10, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 4
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.05,
                0.25
            },
            {
                50,
                1,
                1,
                0.1,
                0.1,
                0.5
            },
            {
                150,
                1,
                1,
                0.1,
                0.3,
                0.5
            },
            {
                299,
                1,
                1,
                0.1,
                0.4,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 4, 0.5 },
        WeaponAccuracy = {
            { 0, 6 },
            { 20, 8 },
            { 300, 10 }
        }
    },
    Kismet_Rifleman_Low = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.2,
        Hidden = false,
        Appearance = "Kismet_HQ",
        Fear = "Kismet",
        Health = 120,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1,
        SprintCancel = 40,
        Rewards = {
            Base = { 70, 80 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M4A1" }
        },
        ViewDistance = {
            Day = { 500, 500 },
            Night = { 400, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                5,
                8,
                0.08,
                0.25,
                0.5
            },
            {
                100,
                2,
                3,
                0.08,
                0.35,
                0.6
            },
            {
                200,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                499,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                500,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.65 },
        WeaponAccuracy = {
            { 0, 4 },
            { 50, 6 },
            { 400, 8 }
        }
    },
    Kismet_Rifleman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.2,
        Hidden = false,
        Appearance = "Kismet_Rifleman",
        Fear = "Kismet",
        Health = 120,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1,
        SprintCancel = 40,
        Rewards = {
            Base = { 70, 80 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M4A1" }
        },
        ViewDistance = {
            Day = { 500, 500 },
            Night = { 400, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                5,
                8,
                0.08,
                0.25,
                0.5
            },
            {
                200,
                2,
                3,
                0.08,
                0.35,
                0.6
            },
            {
                300,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                499,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                500,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.65 },
        WeaponAccuracy = {
            { 0, 4 },
            { 50, 6 },
            { 400, 8 }
        }
    },
    Kismet_SMG = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        EquipTimer = 0.2,
        Hidden = false,
        NoSecondary = true,
        MeleeDistance = 4,
        Appearance = "Kismet_Smg",
        Rewards = {
            Base = { 35, 20 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Fear = "Kismet",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Health = 100,
        Weapon = {
            { "AI_UMP45" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 70 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        SprintCancel = 15,
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 3.75
        },
        RateOfFire = {
            {
                0,
                10,
                15,
                0.085,
                0.25,
                0.75
            },
            {
                60,
                5,
                6,
                0.085,
                0.25,
                0.75
            },
            {
                100,
                2,
                4,
                0.085,
                0.25,
                0.75
            },
            {
                250,
                2,
                3,
                0.085,
                0.375,
                1
            },
            {
                251,
                1,
                1,
                0.1,
                0.375,
                1
            },
            {
                349,
                1,
                1,
                0.1,
                0.5,
                2
            },
            {
                350,
                0,
                0,
                1,
                0.5,
                1
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 8 },
            { 100, 7 },
            { 350, 8 }
        }
    },
    Kismet_Shotgun = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = false,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        Hidden = false,
        NoSecondary = true,
        Fear = "Kismet",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Appearance = "Kismet_Shotgun",
        Health = 100,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 35, 25 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_SAIGA" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 11,
            Aware = 10,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                2,
                3,
                0.1,
                0.2,
                1
            },
            {
                100,
                2,
                3,
                0.1,
                0.25,
                1
            },
            {
                199,
                1,
                1,
                0.1,
                0.3,
                3
            },
            {
                200,
                0,
                0,
                0.5,
                0.05,
                0.5
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 3 },
            { 200, 10 }
        }
    },
    Kismet_Sniper = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        RadioTime = 5,
        Hidden = false,
        EquipTimer = 2,
        MeleeDistance = 2,
        SecondaryDistance = 25,
        Appearance = "Kismet_Sniper",
        Fear = "Kismet",
        Health = 100,
        ProneMultiplier = 0.25,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.45,
        DetectionTargetKnownMultiplier = 0.2,
        Rewards = {
            Base = { 50, 40 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M2010" }
        },
        Secondary = {
            { "AI_APS" }
        },
        ViewDistance = {
            Day = { 1500, 2000 },
            Night = { 100, 300 }
        },
        FieldOfView = {
            Day = {
                { 40, 90 },
                { 40, 90 }
            },
            Night = {
                { 40, 80 },
                { 30, 80 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 20, 1 },
            { 1500, 10 }
        },
        FogMultiplier = {
            ViewDistance = 0.125,
            FieldOfView = 0.5
        },
        ShotDetectionRange = { 30, 1500, 130 },
        PathableDistance = { 300, 10000 },
        TargetCooldown = {
            SearchLastSeen = 180,
            ReturnHome = 320
        },
        Walkspeed = {
            Sprint = 6,
            Alerted = 5,
            Aware = 4,
            Idle = 2.25
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                1,
                1.5,
                3
            },
            {
                2000,
                1,
                1,
                1,
                2,
                6
            }
        },
        RateOfFireSecondary = {
            {
                0,
                4,
                7,
                0.08,
                0.5,
                1
            },
            {
                80,
                4,
                5,
                0.08,
                0.5,
                1
            },
            {
                300,
                1,
                1,
                0.25
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.65 },
        WeaponAccuracy = {
            { 0, 1.5 },
            { 1000, 4 },
            { 1500, 6 }
        }
    },
    Kismet_Lmg = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        RadioTime = 5,
        Hidden = false,
        MeleeDistance = 5,
        SecondaryDistance = 10,
        Appearance = "Kismet_Lmg",
        Fear = "Kismet",
        Health = 200,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 50, 40 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M249" }
        },
        Secondary = {
            { "AI_MAKAROV" }
        },
        ViewDistance = {
            Day = { 400, 800 },
            Night = { 60, 700 }
        },
        FogMultiplier = {
            ViewDistance = 0.35,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = {
            30,
            1400,
            130,
            500
        },
        PathableDistance = { 100, 600 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 14,
            Alerted = 10,
            Aware = 6,
            Idle = 2.25
        },
        RateOfFire = {
            {
                0,
                30,
                40,
                0.08,
                2,
                3
            },
            {
                80,
                10,
                15,
                0.08,
                1,
                2
            },
            {
                200,
                5,
                10,
                0.08,
                0.45,
                2
            },
            {
                301,
                3,
                5,
                0.08,
                0.5,
                3
            },
            {
                800,
                2,
                3,
                0.08,
                0.75,
                3
            }
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 10, 0.65 },
        WeaponAccuracy = {
            { 0, 15 },
            { 80, 5 },
            { 800, 10 }
        }
    },
    Kismet_RPG = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        NoProne = true,
        UseMotar = false,
        Hidden = false,
        RadioTime = 5,
        EquipTimer = 1,
        SecondaryDistance = 80,
        MeleeDistance = 30,
        Appearance = "Kismet_RPG",
        Fear = "Kismet",
        Rewards = {
            Base = { 60, 30 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Secondary = {
            { "AI_APS" }
        },
        Health = 100,
        Rocket = "rpg7v2",
        ViewDistance = {
            Day = { 400, 1200 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 150, 700 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        SprintCancel = 1000,
        Walkspeed = {
            Sprint = 13,
            Alerted = 9,
            Aware = 4,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                15
            },
            {
                1300,
                1,
                1,
                20
            }
        },
        RateOfFireSecondary = {
            {
                0,
                4,
                7,
                0.08,
                0.5,
                1
            },
            {
                80,
                4,
                5,
                0.08,
                0.5,
                1
            },
            {
                300,
                1,
                1,
                0.25
            }
        },
        WeaponAccuracyDamper = { 14, 0.2 },
        WeaponAccuracy = {
            { 0, 1 },
            { 600, 20 },
            { 1200, 30 }
        }
    },
    Kismet_VIP = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.2,
        Hidden = false,
        HighPriority = true,
        NoPrimary = true,
        Appearance = "Kismet_VIP",
        Fear = "Kismet",
        Health = 120,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1,
        SprintCancel = 40,
        Rewards = {
            Base = { 70, 80 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_Glock17G3" }
        },
        ViewDistance = {
            Day = { 500, 500 },
            Night = { 400, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                1,
                0.08,
                0.05,
                0.5
            },
            {
                100,
                1,
                1,
                0.08,
                0.35,
                0.6
            },
            {
                200,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                499,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                500,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.65 },
        WeaponAccuracy = {
            { 0, 4 },
            { 50, 6 },
            { 400, 8 }
        }
    },
    Kismet_Smoker = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        EquipTimer = 0.2,
        Hidden = false,
        NoSecondary = true,
        MeleeDistance = 4,
        Appearance = "Kismet_Smg_Haz",
        Rewards = {
            Base = { 35, 20 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Fear = "Kismet",
        SmokerGrenade = 100,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Health = 100,
        Weapon = {
            { "AI_UMP45" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 70 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        SprintCancel = 15,
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 3.75
        },
        RateOfFire = {
            {
                0,
                10,
                15,
                0.085,
                0.25,
                0.75
            },
            {
                60,
                5,
                6,
                0.085,
                0.25,
                0.75
            },
            {
                100,
                2,
                4,
                0.085,
                0.25,
                0.75
            },
            {
                250,
                2,
                3,
                0.085,
                0.375,
                1
            },
            {
                251,
                1,
                1,
                0.1,
                0.375,
                1
            },
            {
                349,
                1,
                1,
                0.1,
                0.5,
                2
            },
            {
                350,
                0,
                0,
                1,
                0.5,
                1
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 8 },
            { 100, 7 },
            { 350, 8 }
        }
    },
    Kismet_Rifleman_Haz = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.2,
        Hidden = false,
        Appearance = "Kismet_Rifleman_Haz",
        Fear = "Kismet",
        Health = 120,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1,
        SprintCancel = 40,
        Rewards = {
            Base = { 70, 80 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M4A1" }
        },
        ViewDistance = {
            Day = { 500, 500 },
            Night = { 400, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                5,
                8,
                0.08,
                0.25,
                0.5
            },
            {
                200,
                2,
                3,
                0.08,
                0.35,
                0.6
            },
            {
                300,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                499,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                500,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.65 },
        WeaponAccuracy = {
            { 0, 4 },
            { 50, 6 },
            { 400, 8 }
        }
    },
    Kismet_Smg_Haz = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        EquipTimer = 0.2,
        Hidden = false,
        NoSecondary = true,
        MeleeDistance = 4,
        Appearance = "Kismet_Smg_Haz",
        Rewards = {
            Base = { 35, 20 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Fear = "Kismet",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Health = 100,
        Weapon = {
            { "AI_UMP45" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 70 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        SprintCancel = 15,
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 3.75
        },
        RateOfFire = {
            {
                0,
                10,
                15,
                0.085,
                0.25,
                0.75
            },
            {
                60,
                5,
                6,
                0.085,
                0.25,
                0.75
            },
            {
                100,
                2,
                4,
                0.085,
                0.25,
                0.75
            },
            {
                250,
                2,
                3,
                0.085,
                0.375,
                1
            },
            {
                251,
                1,
                1,
                0.1,
                0.375,
                1
            },
            {
                349,
                1,
                1,
                0.1,
                0.5,
                2
            },
            {
                350,
                0,
                0,
                1,
                0.5,
                1
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 8 },
            { 100, 7 },
            { 350, 8 }
        }
    },
    Kismet_Shotgun_Haz = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = false,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        Hidden = false,
        NoSecondary = true,
        Fear = "Kismet",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Appearance = "Kismet_Shotgun_Haz",
        Health = 100,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 35, 25 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_SAIGA" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 11,
            Aware = 10,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                2,
                3,
                0.1,
                0.2,
                1
            },
            {
                100,
                2,
                3,
                0.1,
                0.25,
                1
            },
            {
                199,
                1,
                1,
                0.1,
                0.3,
                3
            },
            {
                200,
                0,
                0,
                0.5,
                0.05,
                0.5
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 3 },
            { 200, 10 }
        }
    },
    Kismet_Lmg_Haz = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        RadioTime = 5,
        Hidden = false,
        MeleeDistance = 5,
        SecondaryDistance = 10,
        Appearance = "Kismet_Lmg_Haz",
        Fear = "Kismet",
        Health = 200,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 50, 40 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M249" }
        },
        Secondary = {
            { "AI_MAKAROV" }
        },
        ViewDistance = {
            Day = { 400, 800 },
            Night = { 60, 700 }
        },
        FogMultiplier = {
            ViewDistance = 0.35,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = {
            30,
            1400,
            130,
            500
        },
        PathableDistance = { 100, 600 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 14,
            Alerted = 10,
            Aware = 6,
            Idle = 2.25
        },
        RateOfFire = {
            {
                0,
                30,
                40,
                0.08,
                2,
                3
            },
            {
                80,
                10,
                15,
                0.08,
                1,
                2
            },
            {
                200,
                5,
                10,
                0.08,
                0.45,
                2
            },
            {
                301,
                3,
                5,
                0.08,
                0.5,
                3
            },
            {
                800,
                2,
                3,
                0.08,
                0.75,
                3
            }
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 10, 0.65 },
        WeaponAccuracy = {
            { 0, 15 },
            { 80, 5 },
            { 800, 10 }
        }
    }
};