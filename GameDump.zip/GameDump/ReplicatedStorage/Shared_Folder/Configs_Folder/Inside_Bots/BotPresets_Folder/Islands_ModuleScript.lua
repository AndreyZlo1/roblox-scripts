-- Roblox: ReplicatedStorage.Shared.Configs.Bots.BotPresets.Islands
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Militia_RPG = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        UseMotar = false,
        NoProne = true,
        RadioTime = 7,
        EquipTimer = 3,
        Fear = "Militia",
        Hidden = true,
        Appearance = "Militia_Rpg",
        Rewards = {
            Base = { 30, 30 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Health = 75,
        Rocket = "rpg7v2",
        Secondary = {
            { "AI_MAKAROV" }
        },
        SecondaryDistance = 80,
        MeleeDistance = 30,
        ViewDistance = {
            Day = { 500, 1200 },
            Night = { 70, 500 }
        },
        FogMultiplier = {
            ViewDistance = 0.33,
            FieldOfView = 0.75
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 150, 700 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 10,
            Alerted = 9,
            Aware = 8,
            Idle = 5
        },
        SprintCancel = 150,
        RateOfFire = {
            {
                0,
                1,
                1,
                20
            },
            {
                1300,
                1,
                1,
                30
            }
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 20, 0.75 },
        WeaponAccuracy = {
            { 0, 5 },
            { 100, 15 },
            { 1200, 60 }
        }
    },
    Militia_Pistol = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 7,
        EquipTimer = 0.15,
        NoPrimary = true,
        Fear = "Militia",
        Hidden = true,
        Appearance = "Militia_Smg",
        SecondaryDistance = 600,
        Health = 75,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 15, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Secondary = {
            { "AI_MAKAROV" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 10, 100 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 4
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 5, 0.25 },
        WeaponAccuracy = {
            { 0, 5 },
            { 20, 6 },
            { 300, 15 }
        }
    },
    Militia_VIP = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        RadioTime = 7,
        NoPrimary = true,
        Appearance = "Militia_Commander",
        Fear = "Militia",
        Hidden = true,
        SecondaryDistance = 600,
        Health = 75,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        SprintCancel = 10,
        Rewards = {
            Base = { 100, 50 },
            Headshot = { 10, 5 },
            Stealth = { 25, 20 }
        },
        Secondary = {
            { "AI_APS" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 20, 100000 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 12,
            Idle = 5
        },
        RateOfFireSecondary = {
            {
                2,
                0,
                0,
                0.066,
                0.1,
                0.25
            },
            {
                3,
                15,
                20,
                0.066,
                0.1,
                0.25
            },
            {
                80,
                15,
                20,
                0.066,
                0.1,
                0.25
            },
            {
                150,
                1,
                1,
                0.25,
                0.1,
                0.1
            },
            {
                300,
                1,
                1,
                0.25,
                0.1,
                0.25
            }
        },
        WeaponAccuracyDamper = { 1, 0.9 },
        WeaponAccuracy = {
            { 0, 1 },
            { 30, 10 },
            { 300, 25 }
        }
    },
    Militia_SMG = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 7,
        EquipTimer = 0.35,
        NoSecondary = true,
        UseMotar = true,
        Appearance = "Militia_Smg",
        Fear = "Militia",
        Hidden = true,
        Health = 75,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        SprintCancel = 50,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 10, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_PPSH" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 20, 150 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 13,
            Idle = 6
        },
        RateOfFire = {
            {
                0,
                5,
                20,
                0.05,
                0.25,
                0.5
            },
            {
                50,
                5,
                10,
                0.05,
                0.25,
                1
            },
            {
                99,
                2,
                4,
                0.05,
                0.45,
                1
            },
            {
                150,
                1,
                1,
                0.1,
                0.25,
                1
            },
            {
                600,
                1,
                1,
                0.1,
                0.3,
                1.5
            }
        },
        WeaponAccuracyDamper = { 4, 0.4 },
        WeaponAccuracy = {
            { 0, 15 },
            { 100, 8 },
            { 300, 15 }
        }
    },
    Militia_SMG2 = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 7,
        EquipTimer = 0.35,
        NoSecondary = true,
        UseMotar = true,
        Appearance = "Militia_Smg",
        Fear = "Militia",
        Hidden = true,
        Health = 75,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        SprintCancel = 20,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 10, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_VZ" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 20, 150 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 13,
            Idle = 6
        },
        RateOfFire = {
            {
                0,
                5,
                10,
                0.072,
                0.25,
                0.5
            },
            {
                50,
                3,
                6,
                0.072,
                0.25,
                1
            },
            {
                100,
                1,
                3,
                0.072,
                0.25,
                1
            },
            {
                151,
                1,
                1,
                0.1,
                0.25,
                0.5
            },
            {
                600,
                1,
                1,
                0.1,
                0.3,
                1
            }
        },
        WeaponAccuracyDamper = { 5, 0.4 },
        WeaponAccuracy = {
            { 0, 10 },
            { 100, 8 },
            { 300, 9 }
        }
    },
    Militia_Rifleman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 7,
        EquipTimer = 0.35,
        NoSecondary = true,
        Appearance = "Militia_Rifleman",
        Fear = "Militia",
        Hidden = true,
        Health = 100,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_AK" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 40, 400 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 12,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                3,
                15,
                0.09375,
                0.25,
                1
            },
            {
                30,
                3,
                15,
                0.09375,
                0.25,
                1
            },
            {
                199,
                2,
                6,
                0.09375,
                0.15,
                0.66
            },
            {
                200,
                1,
                1,
                0.09375,
                0.25,
                1
            },
            {
                600,
                1,
                1,
                0.1,
                0.1,
                0.5
            }
        },
        WeaponAccuracyDamper = { 2, 0.375 },
        WeaponAccuracy = {
            { 0, 13 },
            { 30, 13 },
            { 100, 6 },
            { 600, 10 }
        }
    },
    Militia_AutoRifleman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        UseMotar = true,
        RadioTime = 7,
        EquipTimer = 1.5,
        NoSecondary = true,
        Appearance = "Militia_RiflemanHeavy",
        Fear = "Militia",
        Hidden = true,
        Health = 110,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        SprintCancel = 50,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_RPK" }
        },
        ViewDistance = {
            Day = { 400, 800 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 300, 700 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                10,
                15,
                0.1,
                0.5,
                1
            },
            {
                50,
                10,
                15,
                0.1,
                0.25,
                0.75
            },
            {
                199,
                4,
                8,
                0.1,
                0.25,
                0.5
            },
            {
                200,
                2,
                3,
                0.1,
                0.375,
                1
            },
            {
                500,
                1,
                2,
                0.1,
                0.375,
                1
            }
        },
        WeaponAccuracyDamper = { 7, 0.5 },
        WeaponAccuracy = {
            { 0, 1 },
            { 50, 7.5 },
            { 500, 15 },
            { 800, 30 }
        }
    },
    Militia_HeavyAuto = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        RadioTime = 7,
        EquipTimer = 1.5,
        MeleeDistance = 5,
        SecondaryDistance = 20,
        Appearance = "Militia_Heavy",
        Fear = "Militia",
        Hidden = true,
        Health = 130,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        SprintCancel = 30,
        Rewards = {
            Base = { 25, 15 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_RPD" }
        },
        ViewDistance = {
            Day = { 400, 800 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 60, 70 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 40 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 40, 400 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 12,
            Alerted = 8,
            Aware = 5,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                5,
                25,
                0.066,
                1,
                3
            },
            {
                100,
                5,
                25,
                0.066,
                1,
                3
            },
            {
                101,
                2,
                3,
                0.066,
                0.33,
                0.5
            },
            {
                800,
                1,
                2,
                0.066,
                0.5,
                2
            }
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 6, 0.3 },
        WeaponAccuracy = {
            { 0, 10 },
            { 100, 15 },
            { 101, 7.5 },
            { 800, 12.5 }
        }
    },
    Militia_Shotgun = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 7,
        NoSecondary = true,
        MeleeDistance = 3,
        Appearance = "Militia_Rifleman",
        Fear = "Militia",
        Hidden = true,
        Health = 100,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        SprintCancel = 40,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_DB" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 10, 70 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 12,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                0.1,
                0.25,
                2
            },
            {
                40,
                1,
                1,
                0.1,
                0.5,
                2
            },
            {
                41,
                1,
                1,
                0.1,
                0.5,
                1
            },
            {
                249,
                1,
                1,
                0.1,
                0.75,
                1.5
            }
        },
        WeaponAccuracy = {
            { 0, 4.5 },
            { 300, 10 }
        }
    },
    Militia_Rifleman_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 7,
        MeleeDistance = 3,
        SecondaryDistance = 15,
        Appearance = "Militia_RiflemanHeavy",
        Fear = "Militia",
        Hidden = true,
        Health = 110,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        SprintCancel = 100,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_AK" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 50, 300 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 12,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                3,
                15,
                0.09375,
                0.25,
                1
            },
            {
                50,
                3,
                15,
                0.09375,
                0.25,
                1
            },
            {
                100,
                2,
                6,
                0.09375,
                0.15,
                0.66
            },
            {
                200,
                1,
                1,
                0.09375,
                0.25,
                1
            },
            {
                600,
                1,
                1,
                0.1,
                0.1,
                0.5
            }
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 5, 0.7 },
        WeaponAccuracy = {
            { 0, 13 },
            { 50, 15 },
            { 100, 5 },
            { 600, 10 }
        }
    },
    Militia_Melee = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = false,
        RadioTime = 7,
        MeleeOnly = true,
        Appearance = "Militia_Rifleman",
        Fear = "Militia",
        Hidden = true,
        MeleeDistance = 500,
        Health = 100,
        Weapon = "Machete",
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 15, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 0, 500 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 10,
            Idle = 4
        },
        RateOfFire = {
            {
                40,
                1,
                1,
                0
            },
            {
                100,
                2,
                4,
                0.15
            },
            {
                200,
                1,
                3,
                0.1
            }
        },
        WeaponAccuracy = {
            { 100, 2 },
            { 300, 10 }
        }
    },
    Militia_Sniper = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        Hidden = true,
        RadioTime = 5,
        EquipTimer = 2,
        MeleeDistance = 3,
        SecondaryDistance = 30,
        Appearance = "Militia_Sniper",
        Fear = "Militia",
        Health = 100,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.2,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_MOSIN" }
        },
        ViewDistance = {
            Day = { 800, 1000 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.33,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 40 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 },
            { 1000, 15 }
        },
        ShotDetectionRange = {
            30,
            1400,
            130,
            500
        },
        PathableDistance = { 100, 2000 },
        TargetCooldown = {
            SearchLastSeen = 120,
            ReturnHome = 240
        },
        Walkspeed = {
            Sprint = 10,
            Alerted = 5,
            Aware = 4,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                1,
                2,
                4
            },
            {
                1000,
                1,
                1,
                1,
                3,
                7
            }
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 10, 0.9 },
        WeaponAccuracy = {
            { 0, 10 },
            { 100, 6 },
            { 300, 7.5 },
            { 1500, 15 }
        }
    },
    Militia_Marksman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        RadioTime = 5,
        EquipTimer = 2,
        MeleeDistance = 5,
        SecondaryDistance = 25,
        Appearance = "Militia_Sniper",
        Fear = "Militia",
        Hidden = true,
        Health = 100,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.2,
        SprintCancel = 5,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_SVD" }
        },
        ViewDistance = {
            Day = { 800, 1000 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.33,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 40 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 },
            { 1000, 15 }
        },
        ShotDetectionRange = {
            30,
            1400,
            130,
            500
        },
        PathableDistance = { 100, 2000 },
        TargetCooldown = {
            SearchLastSeen = 120,
            ReturnHome = 240
        },
        Walkspeed = {
            Sprint = 10,
            Alerted = 5,
            Aware = 4,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                0.1,
                0.5,
                3
            },
            {
                1000,
                1,
                1,
                0.1,
                1,
                5
            }
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 5, 0.675 },
        WeaponAccuracy = {
            { 0, 4 },
            { 300, 12.5 },
            { 1500, 15 }
        }
    },
    Militia_HeliGunner = {
        Behaviour = "Combat",
        Hidden = true,
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 7,
        MeleeDistance = 3,
        SecondaryDistance = 15,
        Appearance = "Militia_RiflemanHeavy",
        Fear = "Militia",
        Health = 110,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        SprintCancel = 100,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_AK" }
        },
        ViewDistance = {
            Day = { 300, 700 },
            Night = { 100, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.3,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 50, 300 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 12,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                6,
                15,
                0.09375,
                0.25,
                2
            },
            {
                50,
                3,
                6,
                0.09375,
                0.25,
                1
            },
            {
                200,
                2,
                4,
                0.09375,
                0.2,
                0.5
            },
            {
                300,
                2,
                4,
                0.09375,
                0.2,
                0.45
            },
            {
                600,
                1,
                1,
                0.5,
                0.2,
                0.6
            }
        },
        RateOfFireSecondary = {
            {
                0,
                4,
                5,
                0.25,
                0.25,
                0.6
            },
            {
                50,
                4,
                5,
                0.25,
                0.25,
                0.6
            },
            {
                150,
                1,
                1,
                1,
                0.25,
                0.6
            },
            {
                400,
                1,
                1,
                1,
                0.25,
                0.6
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.6
            }
        },
        WeaponAccuracyDamper = { 10, 0.25 },
        WeaponAccuracy = {
            { 0, 1 },
            { 50, 7 },
            { 600, 15 }
        }
    },
    I_Merc_Smg_Low = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMotar = true,
        UseMG = true,
        RadioTime = 5,
        EquipTimer = 0.3,
        Hidden = true,
        Appearance = "Sheepdog_Low",
        Fear = "Sheepdog",
        Health = 50,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 40, 50 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_MP5" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                5,
                8,
                0.075,
                1,
                2
            },
            {
                50,
                5,
                8,
                0.075,
                0.25,
                0.5
            },
            {
                150,
                2,
                3,
                0.08,
                0.35,
                0.6
            },
            {
                200,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.5 },
        WeaponAccuracy = {
            { 0, 6 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    I_Merc_Shotgun_Low = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        EquipTimer = 0.3,
        Hidden = true,
        Appearance = "Sheepdog_Low",
        Fear = "Sheepdog",
        Health = 50,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 40, 50 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M590" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                1,
                1,
                0.25,
                1
            },
            {
                200,
                1,
                1,
                1,
                0.5,
                4
            },
            {
                399,
                1,
                1,
                1,
                5,
                10
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.75 },
        WeaponAccuracy = {
            { 0, 6 },
            { 50, 9 },
            { 400, 12 }
        }
    },
    I_Merc_Rifleman_Low = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        EquipTimer = 0.3,
        Hidden = true,
        Appearance = "Sheepdog_Low",
        Fear = "MercLow",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 45, 55 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M4A1" }
        },
        ViewDistance = {
            Day = { 200, 450 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 600, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                5,
                8,
                0.08,
                0.25,
                0.5
            },
            {
                100,
                2,
                3,
                0.08,
                0.35,
                0.6
            },
            {
                200,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 10, 0.4 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    I__Merc_Rpg = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        NoProne = true,
        UseMotar = false,
        RadioTime = 5,
        Hidden = true,
        EquipTimer = 1,
        SecondaryDistance = 80,
        MeleeDistance = 30,
        Appearance = "MercenaryT1_Rpg",
        Fear = "MercLow",
        Rewards = {
            Base = { 100, 100 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Secondary = {
            { "AI_APS" }
        },
        Health = 100,
        Rocket = "rpg7v2",
        ViewDistance = {
            Day = { 200, 450 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 150, 700 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        SprintCancel = 1000,
        Walkspeed = {
            Sprint = 13,
            Alerted = 9,
            Aware = 4,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                15
            },
            {
                1300,
                1,
                1,
                20
            }
        },
        RateOfFireSecondary = {
            {
                0,
                4,
                7,
                0.08,
                0.5,
                1
            },
            {
                80,
                4,
                5,
                0.08,
                0.5,
                1
            },
            {
                300,
                1,
                1,
                0.25
            }
        },
        WeaponAccuracyDamper = { 14, 0.2 },
        WeaponAccuracy = {
            { 0, 1 },
            { 600, 20 },
            { 1200, 30 }
        }
    },
    I_Merc_Smg = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        EquipTimer = 0.2,
        NoSecondary = true,
        MeleeDistance = 4,
        Hidden = true,
        Appearance = "MercenaryT1_Smg",
        Rewards = {
            Base = { 45, 55 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Fear = "MercLow",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Health = 100,
        Weapon = {
            { "AI_MP5" }
        },
        ViewDistance = {
            Day = { 200, 450 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 70 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        SprintCancel = 15,
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 3.75
        },
        RateOfFire = {
            {
                0,
                6,
                8,
                0.085,
                0.25,
                0.75
            },
            {
                60,
                3,
                8,
                0.085,
                0.25,
                0.75
            },
            {
                100,
                2,
                4,
                0.085,
                0.25,
                0.75
            },
            {
                250,
                2,
                3,
                0.085,
                0.375,
                1
            },
            {
                251,
                1,
                1,
                0.1,
                0.375,
                1
            },
            {
                349,
                1,
                1,
                0.1,
                0.5,
                2
            },
            {
                350,
                0,
                0,
                1,
                0.5,
                1
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 8 },
            { 100, 7 },
            { 350, 8 }
        }
    },
    I_Merc_Shotgun = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = false,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        NoSecondary = true,
        Hidden = true,
        Fear = "MercLow",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Appearance = "MercenaryT1_Shotgun",
        Health = 100,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 45, 55 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M590" }
        },
        ViewDistance = {
            Day = { 200, 450 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 11,
            Aware = 10,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                1,
                0.2,
                1
            },
            {
                100,
                1,
                1,
                1,
                0.25,
                1
            },
            {
                199,
                1,
                1,
                1,
                0.3,
                3
            },
            {
                200,
                0,
                0,
                0.5,
                0.05,
                0.5
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 3 },
            { 200, 10 }
        }
    },
    I_Merc_Marksman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        EquipTimer = 0.3,
        Hidden = true,
        Appearance = "MercenaryT1_Sniper",
        Fear = "MercLow",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 65, 75 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_SR15" }
        },
        ViewDistance = {
            Day = { 200, 450 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 600, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                2,
                0.08,
                0.25,
                0.5
            },
            {
                100,
                1,
                1,
                0.08,
                0.35,
                0.6
            },
            {
                200,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 6, 0.66 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    I_Merc_Sniper = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 5,
        EquipTimer = 0.3,
        Hidden = true,
        Appearance = "MercenaryT1_Sniper",
        Fear = "MercLow",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 65, 75 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M2010" },
            { "AI_R700" }
        },
        ViewDistance = {
            Day = { 600, 800 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 600, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                1,
                1,
                0.25,
                0.5
            },
            {
                100,
                1,
                1,
                1,
                0.35,
                0.6
            },
            {
                600,
                1,
                1,
                1,
                0.5,
                2
            },
            {
                800,
                0,
                0,
                1
            }
        },
        WeaponAccuracyDamper = { 10, 0.6 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    I_Merc_Rifleman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        EquipTimer = 0.3,
        Hidden = true,
        Appearance = "MercenaryT1_Rifleman",
        Fear = "MercLow",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 45, 55 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M4A1" }
        },
        ViewDistance = {
            Day = { 200, 450 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 600, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                5,
                8,
                0.08,
                0.25,
                0.5
            },
            {
                100,
                2,
                3,
                0.08,
                0.35,
                0.6
            },
            {
                200,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 10, 0.4 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    I_Merc_Smg_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        Hidden = true,
        EquipTimer = 0.2,
        NoSecondary = true,
        MeleeDistance = 4,
        Appearance = "MercenaryT1_Smg_Heavy",
        Rewards = {
            Base = { 55, 65 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Fear = "MercLow",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Health = 100,
        Weapon = {
            { "AI_UMP45" }
        },
        ViewDistance = {
            Day = { 200, 450 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 70 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        SprintCancel = 15,
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 3.75
        },
        RateOfFire = {
            {
                0,
                10,
                15,
                0.09,
                0.25,
                0.75
            },
            {
                60,
                5,
                6,
                0.09,
                0.25,
                0.75
            },
            {
                100,
                2,
                4,
                0.09,
                0.25,
                0.75
            },
            {
                250,
                2,
                3,
                0.09,
                0.375,
                1
            },
            {
                251,
                1,
                1,
                0.1,
                0.375,
                1
            },
            {
                349,
                1,
                1,
                0.1,
                0.5,
                2
            },
            {
                350,
                0,
                0,
                1,
                0.5,
                1
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 8 },
            { 100, 7 },
            { 350, 8 }
        }
    },
    I_Merc_Shotgun_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = false,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        Hidden = true,
        NoSecondary = true,
        Fear = "MercLow",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Appearance = "MercenaryT1_Shotgun_Heavy",
        Health = 100,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 55, 65 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M590" }
        },
        ViewDistance = {
            Day = { 200, 450 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 11,
            Aware = 10,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                1,
                0.2,
                1
            },
            {
                100,
                1,
                1,
                1,
                0.25,
                1
            },
            {
                199,
                1,
                1,
                1,
                0.3,
                3
            },
            {
                200,
                0,
                0,
                1,
                0.05,
                0.5
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 3 },
            { 200, 10 }
        }
    },
    I_Merc_Rifleman_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        EquipTimer = 0.3,
        Hidden = true,
        Appearance = "MercenaryT1_Rifleman_Heavy",
        Fear = "MercLow",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 55, 65 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M4A1" },
            { "AI_G36" },
            { "AI_SR15" },
            { "AI_SCARL" }
        },
        ViewDistance = {
            Day = { 200, 450 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 600, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                3,
                4,
                0.08,
                0.25,
                0.5
            },
            {
                200,
                2,
                3,
                0.08,
                0.35,
                0.6
            },
            {
                300,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 10, 0.4 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    I_Merc_LMG_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 5,
        EquipTimer = 0.3,
        UseMotar = true,
        Hidden = true,
        Appearance = "MercenaryT1_Lmg",
        Fear = "MercLow",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 70, 80 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M4A1" }
        },
        ViewDistance = {
            Day = { 200, 450 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 600, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                5,
                10,
                0.08,
                0.25,
                0.5
            },
            {
                200,
                3,
                6,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 10, 0.4 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    I_Merc2_Marksman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 5,
        EquipTimer = 0.3,
        Hidden = true,
        HighPriority = true,
        Appearance = "MercenaryT2_Marksman",
        Fear = "MercHigh",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 30, 40 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M2010" },
            { "AI_M107A1" }
        },
        ViewDistance = {
            Day = { 500, 700 },
            Night = { 500, 700 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 600, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                1,
                1,
                0.5,
                2
            },
            {
                600,
                1,
                1,
                1,
                0.5,
                3
            },
            {
                800,
                1,
                1,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.95 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 800, 12 }
        }
    },
    I_Merc2_Rifleman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 5,
        EquipTimer = 0.125,
        Hidden = true,
        Appearance = "MercenaryT2_Rifleman",
        HighPriority = true,
        Fear = "MercHigh",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 30, 40 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M4A1" },
            { "AI_HK416A5" }
        },
        ViewDistance = {
            Day = { 250, 650 },
            Night = { 250, 650 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 600, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                2,
                3,
                0.08,
                0.25,
                0.5
            },
            {
                299,
                2,
                3,
                0.08,
                0.35,
                0.6
            },
            {
                300,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.4 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    I_RoyalSniper = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        Hidden = true,
        RadioTime = 5,
        EquipTimer = 2,
        MeleeDistance = 2,
        SecondaryDistance = 30,
        Appearance = "POD_Sniper",
        Fear = "Spec",
        Health = 100,
        ProneMultiplier = 0.25,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.45,
        DetectionTargetKnownMultiplier = 0.2,
        Rewards = {
            Base = { 50, 40 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_KSVK" }
        },
        Secondary = {
            { "AI_APS" }
        },
        ViewDistance = {
            Day = { 2000, 1500 },
            Night = { 1000, 1500 }
        },
        FieldOfView = {
            Day = {
                { 40, 90 },
                { 40, 90 }
            },
            Night = {
                { 40, 80 },
                { 30, 80 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 20, 1 },
            { 1500, 10 }
        },
        FogMultiplier = {
            ViewDistance = 0.125,
            FieldOfView = 0.5
        },
        ShotDetectionRange = { 30, 1500, 130 },
        PathableDistance = { 300, 10000 },
        TargetCooldown = {
            SearchLastSeen = 180,
            ReturnHome = 320
        },
        Walkspeed = {
            Sprint = 6,
            Alerted = 5,
            Aware = 4,
            Idle = 2.25
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                1,
                3,
                5
            },
            {
                2000,
                1,
                1,
                1,
                3,
                7
            }
        },
        RateOfFireSecondary = {
            {
                0,
                4,
                7,
                0.08,
                0.5,
                1
            },
            {
                80,
                4,
                5,
                0.08,
                0.5,
                1
            },
            {
                300,
                1,
                1,
                0.25
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.8 },
        WeaponAccuracy = {
            { 0, 1 },
            { 50, 4 },
            { 1000, 3 },
            { 1500, 4.5 }
        }
    },
    I_RoyalGunner = {
        Behaviour = "Combat",
        Hidden = true,
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 1,
        EquipTimer = 0.2,
        MeleeDistance = 3,
        SecondaryDistance = 15,
        Appearance = "POD_Spec",
        Rewards = {
            Base = { 60, 60 },
            Headshot = { 5, 5 },
            Stealth = { 10, 20 }
        },
        Fear = "Spec",
        Health = 100,
        Weapon = {
            { "AI_AK" }
        },
        Secondary = {
            { "Glock17G3" }
        },
        ViewDistance = {
            Day = { 1800, 1800 },
            Night = { 1800, 1800 }
        },
        FogMultiplier = {
            ViewDistance = 0.15,
            FieldOfView = 0.5
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 90, 90 },
                { 90, 90 }
            },
            Night = {
                { 90, 90 },
                { 90, 90 }
            }
        },
        DetectionTimeMultiplier = 1,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 2 },
            { 500, 3 },
            { 1800, 3 }
        },
        DetectionFearMultiplier = 0.25,
        DetectionAlertedMultiplier = 0.1,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = { 30, 1600, 0 },
        PathableDistance = { 100, 300 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 9,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                2,
                3,
                0.09375,
                0.15,
                0.45
            },
            {
                200,
                2,
                3,
                0.09375,
                0.2,
                0.6
            },
            {
                399,
                2,
                3,
                0.09375,
                0.3,
                0.75
            },
            {
                400,
                1,
                1,
                0.09375,
                0.33,
                1
            }
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 10, 0.5 },
        WeaponAccuracy = {
            { 0, 5 },
            { 50, 6 },
            { 1800, 6 }
        }
    },
    I_Informant = {
        Behaviour = "Combat",
        IsFriendly = true,
        UseCover = true,
        UseMG = true,
        Hidden = true,
        RadioTime = 7,
        EquipTimer = 0.1,
        NoPrimary = true,
        Fear = "Bandit",
        Appearance = "Bandit_Low",
        SecondaryDistance = 600,
        MeleeDistance = 1,
        Health = 400,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 30, 40 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Secondary = {
            { "AI_Glock17G3" },
            { "AI_M9Berretta" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 100, 1 },
            { 600, 4 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 10, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 4
        },
        RateOfFireSecondary = {
            {
                0,
                2,
                3,
                0.1,
                0.05,
                0.35
            },
            {
                50,
                1,
                2,
                0.1,
                0.1,
                0.5
            },
            {
                150,
                1,
                1,
                0.1,
                0.3,
                0.75
            },
            {
                299,
                1,
                1,
                0.1,
                0.4,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 6, 0.4 },
        WeaponAccuracy = {
            { 0, 5 },
            { 20, 6 },
            { 300, 12 }
        }
    }
};