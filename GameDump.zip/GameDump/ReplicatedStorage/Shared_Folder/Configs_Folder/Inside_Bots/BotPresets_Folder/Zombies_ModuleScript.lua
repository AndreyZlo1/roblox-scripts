-- Roblox: ReplicatedStorage.Shared.Configs.Bots.BotPresets.Zombies
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Zombie_Basic = {
        Hidden = true,
        Behaviour = "Zombie",
        Fear = "Zombie",
        Appearance = "Zombie_Civilian",
        LocalTalkRadius = 100,
        DetectionSuspiciousTurnSpeed = 0.4,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.5,
        DetectionTargetKnownMultiplier = 0.5,
        DetectionTimeMultiplier = 1.25,
        ProneMultiplier = 0.33,
        InvestigationRadius = { 100, 700 },
        DetectionCalloutTime = {
            { 0, 0 },
            { 10, 0.5 },
            { 100, 1 },
            { 300, 3 }
        },
        DetectionTime = {
            { 10, 0 },
            { 50, 1 },
            { 100, 2 }
        },
        ShotDetectionRange = { 30, 700, 300 },
        ViewDistance = {
            Day = { 200, 600 },
            Night = { 30, 100 }
        },
        FogMultiplier = {
            ViewDistance = 0.75,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 60, 80 }
            },
            Night = {
                { 40, 70 }
            }
        },
        TargetCooldown = {
            SearchLastSeen = 15,
            ReturnHome = 25,
            AlertTarget = 3
        },
        Walkspeed = {
            Sprinter = 17,
            Normal = 13.5,
            Slow = 8,
            Crippled = 6,
            Crawling = 4,
            Idle = 3
        }
    },
    Zombie_Military = {
        Hidden = true,
        Behaviour = "Zombie",
        Fear = "Zombie",
        Appearance = "Zombie_Military",
        LocalTalkRadius = 100,
        DetectionSuspiciousTurnSpeed = 0.4,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.5,
        DetectionTargetKnownMultiplier = 0.5,
        DetectionTimeMultiplier = 1.25,
        ProneMultiplier = 0.33,
        InvestigationRadius = { 100, 700 },
        DetectionCalloutTime = {
            { 0, 0 },
            { 10, 0.5 }
        },
        DetectionTime = {
            { 10, 0 },
            { 50, 1 },
            { 100, 2 }
        },
        ShotDetectionRange = { 30, 700, 300 },
        ViewDistance = {
            Day = { 200, 600 },
            Night = { 30, 100 }
        },
        FogMultiplier = {
            ViewDistance = 0.75,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 }
            },
            Night = {
                { 40, 70 }
            }
        },
        TargetCooldown = {
            SearchLastSeen = 15,
            ReturnHome = 25,
            AlertTarget = 3
        },
        Walkspeed = {
            Sprinter = 18,
            Normal = 14.5,
            Slow = 9,
            Crippled = 6,
            Crawling = 4,
            Idle = 3
        }
    },
    Zombie_Survivor = {
        Hidden = true,
        Behaviour = "Zombie",
        Fear = "Zombie",
        Appearance = "Zombie_Survivor",
        LocalTalkRadius = 100,
        DetectionSuspiciousTurnSpeed = 0.4,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.5,
        DetectionTargetKnownMultiplier = 0.5,
        DetectionTimeMultiplier = 1.25,
        ProneMultiplier = 0.33,
        InvestigationRadius = { 100, 700 },
        DetectionCalloutTime = {
            { 0, 0 },
            { 10, 0.5 },
            { 100, 1 },
            { 300, 3 }
        },
        DetectionTime = {
            { 10, 0 },
            { 50, 1 },
            { 100, 2 }
        },
        ShotDetectionRange = { 30, 700, 300 },
        ViewDistance = {
            Day = { 200, 600 },
            Night = { 30, 100 }
        },
        FogMultiplier = {
            ViewDistance = 0.75,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 60, 80 }
            },
            Night = {
                { 40, 70 }
            }
        },
        TargetCooldown = {
            SearchLastSeen = 15,
            ReturnHome = 25,
            AlertTarget = 3
        },
        Walkspeed = {
            Sprinter = 17,
            Normal = 13.5,
            Slow = 8,
            Crippled = 6,
            Crawling = 4,
            Idle = 3
        }
    },
    Zombie_Construction = {
        Hidden = true,
        Behaviour = "Zombie",
        Fear = "Zombie",
        Appearance = "Zombie_Construction",
        LocalTalkRadius = 100,
        DetectionSuspiciousTurnSpeed = 0.4,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.5,
        DetectionTargetKnownMultiplier = 0.5,
        DetectionTimeMultiplier = 1.25,
        ProneMultiplier = 0.33,
        InvestigationRadius = { 100, 700 },
        DetectionCalloutTime = {
            { 0, 0 },
            { 10, 0.5 },
            { 100, 1 },
            { 300, 3 }
        },
        DetectionTime = {
            { 10, 0 },
            { 50, 1 },
            { 100, 2 }
        },
        ShotDetectionRange = { 30, 700, 300 },
        ViewDistance = {
            Day = { 200, 600 },
            Night = { 30, 100 }
        },
        FogMultiplier = {
            ViewDistance = 0.75,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 60, 80 }
            },
            Night = {
                { 40, 70 }
            }
        },
        TargetCooldown = {
            SearchLastSeen = 15,
            ReturnHome = 25,
            AlertTarget = 3
        },
        Walkspeed = {
            Sprinter = 17,
            Normal = 13.5,
            Slow = 8,
            Crippled = 6,
            Crawling = 4,
            Idle = 3
        }
    },
    Zombie_Paramedic = {
        Hidden = true,
        Behaviour = "Zombie",
        Fear = "Zombie",
        Appearance = "Zombie_Paramedic",
        LocalTalkRadius = 100,
        DetectionSuspiciousTurnSpeed = 0.4,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.5,
        DetectionTargetKnownMultiplier = 0.5,
        DetectionTimeMultiplier = 1.25,
        ProneMultiplier = 0.33,
        InvestigationRadius = { 100, 700 },
        DetectionCalloutTime = {
            { 0, 0 },
            { 10, 0.5 },
            { 100, 1 },
            { 300, 3 }
        },
        DetectionTime = {
            { 10, 0 },
            { 50, 1 },
            { 100, 2 }
        },
        ShotDetectionRange = { 30, 700, 300 },
        ViewDistance = {
            Day = { 200, 600 },
            Night = { 30, 100 }
        },
        FogMultiplier = {
            ViewDistance = 0.75,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 60, 80 }
            },
            Night = {
                { 40, 70 }
            }
        },
        TargetCooldown = {
            SearchLastSeen = 15,
            ReturnHome = 25,
            AlertTarget = 3
        },
        Walkspeed = {
            Sprinter = 17,
            Normal = 13.5,
            Slow = 8,
            Crippled = 6,
            Crawling = 4,
            Idle = 3
        }
    },
    Zombie_Police = {
        Hidden = true,
        Behaviour = "Zombie",
        Fear = "Zombie",
        Appearance = "Zombie_Police",
        LocalTalkRadius = 100,
        DetectionSuspiciousTurnSpeed = 0.4,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.5,
        DetectionTargetKnownMultiplier = 0.5,
        DetectionTimeMultiplier = 1.25,
        ProneMultiplier = 0.33,
        InvestigationRadius = { 100, 700 },
        DetectionCalloutTime = {
            { 0, 0 },
            { 10, 0.5 },
            { 100, 1 },
            { 300, 3 }
        },
        DetectionTime = {
            { 10, 0 },
            { 50, 1 },
            { 100, 2 }
        },
        ShotDetectionRange = { 30, 700, 300 },
        ViewDistance = {
            Day = { 200, 600 },
            Night = { 30, 100 }
        },
        FogMultiplier = {
            ViewDistance = 0.75,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 60, 80 }
            },
            Night = {
                { 40, 70 }
            }
        },
        TargetCooldown = {
            SearchLastSeen = 15,
            ReturnHome = 25,
            AlertTarget = 3
        },
        Walkspeed = {
            Sprinter = 17,
            Normal = 13.5,
            Slow = 8,
            Crippled = 6,
            Crawling = 4,
            Idle = 3
        }
    },
    Zombie_Bandit = {
        Hidden = true,
        Behaviour = "Zombie",
        Fear = "Zombie",
        Appearance = "Zombie_Bandit",
        LocalTalkRadius = 100,
        DetectionSuspiciousTurnSpeed = 0.4,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.5,
        DetectionTargetKnownMultiplier = 0.5,
        DetectionTimeMultiplier = 1.25,
        ProneMultiplier = 0.33,
        InvestigationRadius = { 100, 700 },
        DetectionCalloutTime = {
            { 0, 0 },
            { 10, 0.5 },
            { 100, 1 },
            { 300, 3 }
        },
        DetectionTime = {
            { 10, 0 },
            { 50, 1 },
            { 100, 2 }
        },
        ShotDetectionRange = { 30, 700, 300 },
        ViewDistance = {
            Day = { 200, 600 },
            Night = { 30, 100 }
        },
        FogMultiplier = {
            ViewDistance = 0.75,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 60, 80 }
            },
            Night = {
                { 40, 70 }
            }
        },
        TargetCooldown = {
            SearchLastSeen = 15,
            ReturnHome = 25,
            AlertTarget = 3
        },
        Walkspeed = {
            Sprinter = 17,
            Normal = 13.5,
            Slow = 8,
            Crippled = 6,
            Crawling = 4,
            Idle = 3
        }
    },
    Zombie_Sheepdog = {
        Hidden = true,
        Behaviour = "Zombie",
        Fear = "Zombie",
        Appearance = "Zombie_Sheepdog",
        LocalTalkRadius = 100,
        DetectionSuspiciousTurnSpeed = 0.4,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.5,
        DetectionTargetKnownMultiplier = 0.5,
        DetectionTimeMultiplier = 1.25,
        ProneMultiplier = 0.33,
        InvestigationRadius = { 100, 700 },
        DetectionCalloutTime = {
            { 0, 0 },
            { 10, 0.5 },
            { 100, 1 },
            { 300, 3 }
        },
        DetectionTime = {
            { 10, 0 },
            { 50, 1 },
            { 100, 2 }
        },
        ShotDetectionRange = { 30, 700, 300 },
        ViewDistance = {
            Day = { 200, 600 },
            Night = { 30, 100 }
        },
        FogMultiplier = {
            ViewDistance = 0.75,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 60, 80 }
            },
            Night = {
                { 40, 70 }
            }
        },
        TargetCooldown = {
            SearchLastSeen = 15,
            ReturnHome = 25,
            AlertTarget = 3
        },
        Walkspeed = {
            Sprinter = 17,
            Normal = 13.5,
            Slow = 8,
            Crippled = 6,
            Crawling = 4,
            Idle = 3
        }
    }
};