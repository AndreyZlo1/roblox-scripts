-- Roblox: ReplicatedStorage.Shared.Configs.Bots.BotPresets.SpecialAI
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    SP_NickPines = {
        Behaviour = "Combat",
        IsFriendly = true,
        UseCover = true,
        UseMG = false,
        Hidden = true,
        RadioTime = 7,
        EquipTimer = 0.1,
        NoPrimary = true,
        NoMelee = true,
        Fear = "Bandit",
        Appearance = "NickPines_Wetwork4",
        SecondaryDistance = 600,
        MeleeDistance = 1,
        Health = 50,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 0, 0 },
            Headshot = { 0, 0 },
            Stealth = { 0, 0 }
        },
        Secondary = {
            { "ColtPython" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 120, 120 },
                { 50, 50 }
            },
            Night = {
                { 120, 120 },
                { 50, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 100, 1 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 10, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 12,
            Alerted = 12,
            Aware = 12,
            Idle = 12
        },
        RateOfFireSecondary = {
            {
                0,
                2,
                3,
                0.3,
                0.05,
                0.35
            },
            {
                50,
                1,
                2,
                0.3,
                0.1,
                0.5
            },
            {
                150,
                1,
                1,
                0.3,
                0.3,
                0.75
            },
            {
                299,
                1,
                1,
                0.4,
                0.4,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 6, 0.4 },
        WeaponAccuracy = {
            { 0, 0 },
            { 20, 0 }
        }
    },
    Kazimir = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        Hidden = true,
        RadioTime = 7,
        EquipTimer = 0,
        NoSecondary = true,
        Appearance = "RLF_Rifleman",
        Fear = "RLF",
        Health = 700,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 100, 100 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "MP5" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.1 },
            { 1000, 0.1 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 40, 400 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 12,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                3,
                15,
                0.09375,
                0.25,
                1
            },
            {
                100,
                3,
                15,
                0.09375,
                0.25,
                1
            },
            {
                199,
                2,
                6,
                0.09375,
                0.15,
                0.66
            },
            {
                200,
                1,
                1,
                0.09375,
                0.25,
                1
            },
            {
                600,
                1,
                1,
                0.1,
                0.1,
                0.5
            }
        },
        WeaponAccuracyDamper = { 2, 0.375 },
        WeaponAccuracy = {
            { 0, 1 },
            { 1000, 2 }
        }
    },
    SP_VanessaMunez = {
        Behaviour = "Combat",
        IsFriendly = true,
        UseCover = true,
        UseMG = true,
        RadioTime = 5,
        EquipTimer = 0.2,
        Hidden = true,
        NoPrimary = true,
        NoMelee = true,
        Appearance = "VanessaMunez",
        Fear = "POD",
        Health = 99999999999999,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        SprintCancel = 15,
        Rewards = {
            Base = { 35, 20 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Secondary = {
            { "M9Berretta" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 2000, 75 },
        PathableDistance = { 15, 70, 200 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 13,
            Idle = 3
        },
        RateOfFire = {
            {
                3,
                0,
                0,
                0.075
            },
            {
                4,
                5,
                6,
                0.075
            },
            {
                100,
                2,
                3,
                0.15
            },
            {
                200,
                2,
                3,
                0.2
            },
            {
                201,
                1,
                1,
                0.25
            },
            {
                349,
                1,
                1,
                0.5
            },
            {
                100,
                1,
                1,
                0.15,
                0.1,
                0.25
            },
            {
                200,
                1,
                1,
                0.2,
                0.25,
                0.5
            },
            {
                201,
                1,
                1,
                0.2,
                0.5,
                1
            },
            {
                349,
                1,
                1,
                0.2,
                1,
                2
            },
            {
                350,
                0,
                0,
                1
            }
        },
        RateOfFireSecondary = {
            {
                3,
                0,
                0,
                0.075
            },
            {
                4,
                5,
                6,
                0.075
            },
            {
                100,
                2,
                3,
                0.15
            },
            {
                200,
                2,
                3,
                0.2
            },
            {
                201,
                1,
                1,
                0.25
            },
            {
                349,
                1,
                1,
                0.5
            },
            {
                100,
                1,
                1,
                0.15,
                0.1,
                0.25
            },
            {
                200,
                1,
                1,
                0.2,
                0.25,
                0.5
            },
            {
                201,
                1,
                1,
                0.2,
                0.5,
                1
            },
            {
                349,
                1,
                1,
                0.2,
                1,
                2
            },
            {
                350,
                0,
                0,
                1
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 1 },
            { 5, 4 },
            { 100, 8 },
            { 350, 10 }
        }
    }
};