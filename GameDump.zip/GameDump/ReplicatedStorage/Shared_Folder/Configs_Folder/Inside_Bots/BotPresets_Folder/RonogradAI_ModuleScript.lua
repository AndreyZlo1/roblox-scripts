-- Roblox: ReplicatedStorage.Shared.Configs.Bots.BotPresets.RonogradAI
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    RLF_RPG = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        UseMotar = false,
        NoProne = true,
        RadioTime = 7,
        EquipTimer = 3,
        Fear = "RLF",
        Appearance = "RLF_Rpg",
        Rewards = {
            Base = { 30, 30 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Health = 75,
        Rocket = "rpg7v2",
        Secondary = {
            { "AI_MAKAROV" }
        },
        SecondaryDistance = 80,
        MeleeDistance = 30,
        ViewDistance = {
            Day = { 500, 1200 },
            Night = { 70, 500 }
        },
        FogMultiplier = {
            ViewDistance = 0.33,
            FieldOfView = 0.75
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 150, 700 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 10,
            Alerted = 9,
            Aware = 8,
            Idle = 5
        },
        SprintCancel = 150,
        RateOfFire = {
            {
                0,
                1,
                1,
                20
            },
            {
                1300,
                1,
                1,
                30
            }
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 20, 0.75 },
        WeaponAccuracy = {
            { 0, 5 },
            { 100, 15 },
            { 1200, 60 }
        }
    },
    RLF_Pistol = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 7,
        EquipTimer = 0.15,
        NoPrimary = true,
        Fear = "RLF",
        Appearance = "RLF_Smg",
        SecondaryDistance = 600,
        Health = 75,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 15, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Secondary = {
            { "AI_MAKAROV" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 10, 100 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 4
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 5, 0.25 },
        WeaponAccuracy = {
            { 0, 5 },
            { 20, 6 },
            { 300, 15 }
        }
    },
    RLF_VIP = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        RadioTime = 7,
        NoPrimary = true,
        Appearance = "RLF_Commander",
        Fear = "RLFVIP",
        SecondaryDistance = 600,
        Health = 75,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        SprintCancel = 10,
        Rewards = {
            Base = { 100, 50 },
            Headshot = { 10, 5 },
            Stealth = { 25, 20 }
        },
        Secondary = {
            { "AI_APS" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 20, 100000 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 12,
            Idle = 5
        },
        RateOfFireSecondary = {
            {
                2,
                0,
                0,
                0.066,
                0.1,
                0.25
            },
            {
                3,
                15,
                20,
                0.066,
                0.1,
                0.25
            },
            {
                80,
                15,
                20,
                0.066,
                0.1,
                0.25
            },
            {
                150,
                1,
                1,
                0.25,
                0.1,
                0.1
            },
            {
                300,
                1,
                1,
                0.25,
                0.1,
                0.25
            }
        },
        WeaponAccuracyDamper = { 1, 0.9 },
        WeaponAccuracy = {
            { 0, 1 },
            { 30, 10 },
            { 300, 25 }
        }
    },
    RLF_SMG = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 7,
        EquipTimer = 0.35,
        NoSecondary = true,
        UseMotar = true,
        Appearance = "RLF_Smg",
        Fear = "RLF",
        Health = 75,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        SprintCancel = 50,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 10, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_PPSH" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 20, 150 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 13,
            Idle = 6
        },
        RateOfFire = {
            {
                0,
                5,
                20,
                0.05,
                0.25,
                0.5
            },
            {
                50,
                5,
                10,
                0.05,
                0.25,
                1
            },
            {
                99,
                2,
                4,
                0.05,
                0.45,
                1
            },
            {
                150,
                1,
                1,
                0.1,
                0.25,
                1
            },
            {
                600,
                1,
                1,
                0.1,
                0.3,
                1.5
            }
        },
        WeaponAccuracyDamper = { 4, 0.4 },
        WeaponAccuracy = {
            { 0, 15 },
            { 100, 8 },
            { 300, 15 }
        }
    },
    RLF_SMG2 = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 7,
        EquipTimer = 0.35,
        NoSecondary = true,
        UseMotar = true,
        Appearance = "RLF_Smg",
        Fear = "RLF",
        Health = 75,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        SprintCancel = 20,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 10, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_VZ" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 20, 150 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 13,
            Idle = 6
        },
        RateOfFire = {
            {
                0,
                5,
                10,
                0.072,
                0.25,
                0.5
            },
            {
                50,
                3,
                6,
                0.072,
                0.25,
                1
            },
            {
                100,
                1,
                3,
                0.072,
                0.25,
                1
            },
            {
                151,
                1,
                1,
                0.1,
                0.25,
                0.5
            },
            {
                600,
                1,
                1,
                0.1,
                0.3,
                1
            }
        },
        WeaponAccuracyDamper = { 5, 0.4 },
        WeaponAccuracy = {
            { 0, 10 },
            { 100, 8 },
            { 300, 9 }
        }
    },
    RLF_Rifleman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 7,
        EquipTimer = 0.35,
        NoSecondary = true,
        Appearance = "RLF_Rifleman",
        Fear = "RLF",
        Health = 100,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_AK" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 40, 400 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 12,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                3,
                15,
                0.09375,
                0.25,
                1
            },
            {
                30,
                3,
                15,
                0.09375,
                0.25,
                1
            },
            {
                199,
                2,
                6,
                0.09375,
                0.15,
                0.66
            },
            {
                200,
                1,
                1,
                0.09375,
                0.25,
                1
            },
            {
                600,
                1,
                1,
                0.1,
                0.1,
                0.5
            }
        },
        WeaponAccuracyDamper = { 2, 0.375 },
        WeaponAccuracy = {
            { 0, 13 },
            { 30, 13 },
            { 100, 6 },
            { 600, 10 }
        }
    },
    RLF_AutoRifleman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        UseMotar = true,
        RadioTime = 7,
        EquipTimer = 1.5,
        NoSecondary = true,
        Appearance = "RLF_RiflemanHeavy",
        Fear = "RLF",
        Health = 110,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        SprintCancel = 50,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_RPK" }
        },
        ViewDistance = {
            Day = { 400, 800 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 300, 700 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                10,
                15,
                0.1,
                0.5,
                1
            },
            {
                50,
                10,
                15,
                0.1,
                0.25,
                0.75
            },
            {
                199,
                4,
                8,
                0.1,
                0.25,
                0.5
            },
            {
                200,
                2,
                3,
                0.1,
                0.375,
                1
            },
            {
                500,
                1,
                2,
                0.1,
                0.375,
                1
            }
        },
        WeaponAccuracyDamper = { 7, 0.5 },
        WeaponAccuracy = {
            { 0, 1 },
            { 50, 7.5 },
            { 500, 15 },
            { 800, 30 }
        }
    },
    RLF_HeavyAuto = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        RadioTime = 7,
        EquipTimer = 1.5,
        MeleeDistance = 5,
        SecondaryDistance = 20,
        Appearance = "RLF_Heavy",
        Fear = "RLF",
        Health = 130,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        SprintCancel = 30,
        Rewards = {
            Base = { 25, 15 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_RPD" }
        },
        ViewDistance = {
            Day = { 400, 800 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 60, 70 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 40 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 40, 400 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 12,
            Alerted = 8,
            Aware = 5,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                5,
                25,
                0.066,
                1,
                3
            },
            {
                100,
                5,
                25,
                0.066,
                1,
                3
            },
            {
                101,
                2,
                3,
                0.066,
                0.33,
                0.5
            },
            {
                800,
                1,
                2,
                0.066,
                0.5,
                2
            }
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 6, 0.3 },
        WeaponAccuracy = {
            { 0, 10 },
            { 100, 15 },
            { 101, 7.5 },
            { 800, 12.5 }
        }
    },
    RLF_Shotgun = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 7,
        NoSecondary = true,
        MeleeDistance = 3,
        Appearance = "RLF_Rifleman",
        Fear = "RLF",
        Health = 100,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        SprintCancel = 40,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_DB" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 10, 70 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 12,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                0.1,
                0.25,
                2
            },
            {
                40,
                1,
                1,
                0.1,
                0.5,
                2
            },
            {
                41,
                1,
                1,
                0.1,
                0.5,
                1
            },
            {
                249,
                1,
                1,
                0.1,
                0.75,
                1.5
            }
        },
        WeaponAccuracy = {
            { 0, 4.5 },
            { 300, 10 }
        }
    },
    RLF_Rifleman_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 7,
        MeleeDistance = 3,
        SecondaryDistance = 15,
        Appearance = "RLF_RiflemanHeavy",
        Fear = "RLF",
        Health = 110,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        SprintCancel = 100,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_AK" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 50, 300 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 12,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                3,
                15,
                0.09375,
                0.25,
                1
            },
            {
                50,
                3,
                15,
                0.09375,
                0.25,
                1
            },
            {
                100,
                2,
                6,
                0.09375,
                0.15,
                0.66
            },
            {
                200,
                1,
                1,
                0.09375,
                0.25,
                1
            },
            {
                600,
                1,
                1,
                0.1,
                0.1,
                0.5
            }
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 5, 0.7 },
        WeaponAccuracy = {
            { 0, 13 },
            { 50, 15 },
            { 100, 5 },
            { 600, 10 }
        }
    },
    RLF_Melee = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = false,
        RadioTime = 7,
        MeleeOnly = true,
        Appearance = "RLF_Rifleman",
        Fear = "RLF",
        MeleeDistance = 500,
        Health = 100,
        Weapon = "Machete",
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 15, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 0, 500 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 10,
            Idle = 4
        },
        RateOfFire = {
            {
                40,
                1,
                1,
                0
            },
            {
                100,
                2,
                4,
                0.15
            },
            {
                200,
                1,
                3,
                0.1
            }
        },
        WeaponAccuracy = {
            { 100, 2 },
            { 300, 10 }
        }
    },
    RLF_Sniper = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        RadioTime = 5,
        EquipTimer = 2,
        MeleeDistance = 3,
        SecondaryDistance = 30,
        Appearance = "RLF_Sniper",
        Fear = "RLFSniper",
        Health = 100,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.2,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_MOSIN" }
        },
        ViewDistance = {
            Day = { 800, 1000 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.33,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 40 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 },
            { 1000, 15 }
        },
        ShotDetectionRange = {
            30,
            1400,
            130,
            500
        },
        PathableDistance = { 100, 2000 },
        TargetCooldown = {
            SearchLastSeen = 120,
            ReturnHome = 240
        },
        Walkspeed = {
            Sprint = 10,
            Alerted = 5,
            Aware = 4,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                1,
                2,
                4
            },
            {
                1000,
                1,
                1,
                1,
                3,
                7
            }
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 10, 0.9 },
        WeaponAccuracy = {
            { 0, 10 },
            { 100, 6 },
            { 300, 7.5 },
            { 1500, 15 }
        }
    },
    RLF_Marksman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        RadioTime = 5,
        EquipTimer = 2,
        MeleeDistance = 5,
        SecondaryDistance = 25,
        Appearance = "RLF_Sniper",
        Fear = "RLFSniper",
        Health = 100,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.2,
        SprintCancel = 5,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_SVD" }
        },
        ViewDistance = {
            Day = { 800, 1000 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.33,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 40 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 },
            { 1000, 15 }
        },
        ShotDetectionRange = {
            30,
            1400,
            130,
            500
        },
        PathableDistance = { 100, 2000 },
        TargetCooldown = {
            SearchLastSeen = 120,
            ReturnHome = 240
        },
        Walkspeed = {
            Sprint = 10,
            Alerted = 5,
            Aware = 4,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                0.1,
                0.5,
                3
            },
            {
                1000,
                1,
                1,
                0.1,
                1,
                5
            }
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 5, 0.675 },
        WeaponAccuracy = {
            { 0, 4 },
            { 300, 12.5 },
            { 1500, 15 }
        }
    },
    RLF_HeliGunner = {
        Behaviour = "Combat",
        Hidden = true,
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 7,
        MeleeDistance = 3,
        SecondaryDistance = 15,
        Appearance = "RLF_RiflemanHeavy",
        Fear = "RLF",
        Health = 110,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        SprintCancel = 100,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_AK" }
        },
        ViewDistance = {
            Day = { 1000, 1000 },
            Night = { 100, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.3,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 50, 300 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 12,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                6,
                15,
                0.09375,
                0.25,
                2
            },
            {
                50,
                3,
                6,
                0.09375,
                0.25,
                1
            },
            {
                200,
                2,
                4,
                0.09375,
                0.2,
                0.5
            },
            {
                300,
                2,
                4,
                0.09375,
                0.2,
                0.45
            },
            {
                600,
                1,
                1,
                0.5,
                0.2,
                0.6
            }
        },
        RateOfFireSecondary = {
            {
                0,
                4,
                5,
                0.25,
                0.25,
                0.6
            },
            {
                50,
                4,
                5,
                0.25,
                0.25,
                0.6
            },
            {
                150,
                1,
                1,
                1,
                0.25,
                0.6
            },
            {
                400,
                1,
                1,
                1,
                0.25,
                0.6
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.6
            }
        },
        WeaponAccuracyDamper = { 10, 0.25 },
        WeaponAccuracy = {
            { 0, 1 },
            { 50, 7 },
            { 600, 15 }
        }
    },
    POD_Pilot = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 5,
        EquipTimer = 0.2,
        Hidden = true,
        Appearance = "POD_Pilot",
        Fear = "POD",
        Health = 100,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        SprintCancel = 15,
        Rewards = {
            Base = { 35, 20 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_PP19" },
            { "AI_VZ" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 2000, 75 },
        PathableDistance = { 15, 70 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 13,
            Idle = 5
        },
        RateOfFire = {
            {
                3,
                0,
                0,
                0.075
            },
            {
                4,
                5,
                6,
                0.075
            },
            {
                100,
                2,
                4,
                0.075
            },
            {
                200,
                2,
                3,
                0.075
            },
            {
                201,
                1,
                1,
                0.1
            },
            {
                349,
                1,
                1,
                0.2
            },
            {
                350,
                0,
                0,
                1
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 1 },
            { 5, 4 },
            { 100, 8 },
            { 350, 10 }
        }
    },
    POD_SMG = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        EquipTimer = 0.2,
        NoSecondary = true,
        MeleeDistance = 4,
        Appearance = "POD_Smg",
        Rewards = {
            Base = { 35, 20 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Fear = "POD",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Health = 100,
        Weapon = {
            { "AI_PP19" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 70 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        SprintCancel = 15,
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 3.75
        },
        RateOfFire = {
            {
                0,
                10,
                15,
                0.085,
                0.25,
                0.75
            },
            {
                60,
                5,
                6,
                0.085,
                0.25,
                0.75
            },
            {
                100,
                2,
                4,
                0.085,
                0.25,
                0.75
            },
            {
                250,
                2,
                3,
                0.085,
                0.375,
                1
            },
            {
                251,
                1,
                1,
                0.1,
                0.375,
                1
            },
            {
                349,
                1,
                1,
                0.1,
                0.5,
                2
            },
            {
                350,
                0,
                0,
                1,
                0.5,
                1
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 8 },
            { 100, 7 },
            { 350, 8 }
        }
    },
    POD_RPG = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        NoProne = true,
        UseMotar = false,
        RadioTime = 5,
        EquipTimer = 1,
        SecondaryDistance = 80,
        MeleeDistance = 30,
        Appearance = "POD_Rpg",
        Fear = "POD",
        Rewards = {
            Base = { 60, 30 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Secondary = {
            { "AI_APS" }
        },
        Health = 100,
        Rocket = "rpg7v2",
        ViewDistance = {
            Day = { 400, 1200 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 150, 700 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        SprintCancel = 1000,
        Walkspeed = {
            Sprint = 13,
            Alerted = 9,
            Aware = 4,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                15
            },
            {
                1300,
                1,
                1,
                20
            }
        },
        RateOfFireSecondary = {
            {
                0,
                4,
                7,
                0.08,
                0.5,
                1
            },
            {
                80,
                4,
                5,
                0.08,
                0.5,
                1
            },
            {
                300,
                1,
                1,
                0.25
            }
        },
        WeaponAccuracyDamper = { 14, 0.2 },
        WeaponAccuracy = {
            { 0, 1 },
            { 600, 20 },
            { 1200, 30 }
        }
    },
    POD_Rifleman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseMG = true,
        UseMotar = true,
        UseCover = true,
        RadioTime = 5,
        NoSecondary = true,
        Appearance = "POD_Rifleman",
        Fear = "POD",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Health = 110,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 35, 25 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_AK" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 100, 300 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 13,
            Idle = 6
        },
        RateOfFire = {
            {
                0,
                3,
                5,
                0.09375,
                0.2,
                0.66
            },
            {
                250,
                2,
                3,
                0.09375,
                0.3,
                1
            },
            {
                600,
                1,
                1,
                0.1,
                0.3,
                1.5
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.75 },
        WeaponAccuracy = {
            { 0, 6 },
            { 600, 10 }
        }
    },
    POD_Rifleman_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        MeleeDistance = 5,
        SecondaryDistance = 20,
        Appearance = "POD_RiflemanHeavy",
        Rewards = {
            Base = { 35, 25 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Fear = "POD",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Health = 115,
        Weapon = {
            { "AI_RPK" }
        },
        Secondary = {
            { "AI_MAKAROV" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 100, 300 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 13,
            Aware = 10,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                5,
                8,
                0.09375,
                0.2,
                0.66
            },
            {
                200,
                4,
                6,
                0.09375,
                0.2,
                0.875
            },
            {
                600,
                2,
                3,
                0.09375,
                0.25,
                1
            }
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.25 },
        WeaponAccuracy = {
            { 0, 4 },
            { 600, 10 }
        }
    },
    POD_Shotgun = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = false,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        NoSecondary = true,
        Fear = "POD",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Appearance = "POD_Rifleman",
        Health = 100,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 35, 25 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_SAIGA" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 11,
            Aware = 10,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                2,
                3,
                0.1,
                0.2,
                1
            },
            {
                100,
                2,
                3,
                0.1,
                0.25,
                1
            },
            {
                199,
                1,
                1,
                0.1,
                0.3,
                3
            },
            {
                200,
                0,
                0,
                0.5,
                0.05,
                0.5
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 3 },
            { 200, 10 }
        }
    },
    POD_Spec_Shotgun = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = false,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        EquipTimer = 0.3,
        NoSecondary = true,
        Appearance = "POD_Spec",
        Fear = "Spec",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 170,
        Health = 150,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1,
        DetectionFearMultiplier = 0.25,
        DetectionAlertedMultiplier = 0.1,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 50, 40 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_SAIGA" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 400, 600 }
        },
        FogMultiplier = {
            ViewDistance = 0.45,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 30, 30 },
                { 50, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 700, 170 },
        PathableDistance = { 30, 100 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 9,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                4,
                5,
                0.1,
                0.2,
                0.5
            },
            {
                199,
                1,
                1,
                0.3,
                0.2,
                0.65
            },
            {
                200,
                0,
                0,
                0.5,
                0.2,
                0.75
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 2 },
            { 200, 7 }
        }
    },
    POD_VIP = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        RadioTime = 4,
        EquipTimer = 1,
        NoPrimary = true,
        Appearance = "POD_Commander",
        Fear = "POD",
        SecondaryDistance = 600,
        Health = 125,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        SprintCancel = 15,
        Rewards = {
            Base = { 100, 50 },
            Headshot = { 10, 5 },
            Stealth = { 50, 255 }
        },
        Secondary = {
            { "Deagle" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 50, 1000 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 8,
            Idle = 4
        },
        RateOfFire = {
            {
                0,
                2,
                5,
                0.25,
                0.35,
                0.5
            },
            {
                150,
                1,
                1,
                1,
                0.35,
                0.5
            },
            {
                299,
                1,
                1,
                1,
                0.35,
                0.5
            },
            {
                300,
                0,
                0,
                1,
                0.35,
                0.5
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 1 },
            { 5, 4 },
            { 50, 8 },
            { 350, 10 }
        }
    },
    POD_Sniper = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        RadioTime = 5,
        EquipTimer = 2,
        MeleeDistance = 2,
        SecondaryDistance = 30,
        Appearance = "POD_Sniper",
        Fear = "Spec",
        Health = 100,
        ProneMultiplier = 0.25,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.45,
        DetectionTargetKnownMultiplier = 0.2,
        Rewards = {
            Base = { 50, 40 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_KSVK" }
        },
        Secondary = {
            { "AI_APS" }
        },
        ViewDistance = {
            Day = { 2000, 1500 },
            Night = { 1000, 1500 }
        },
        FieldOfView = {
            Day = {
                { 40, 90 },
                { 40, 90 }
            },
            Night = {
                { 40, 80 },
                { 30, 80 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 20, 1 },
            { 1500, 10 }
        },
        FogMultiplier = {
            ViewDistance = 0.125,
            FieldOfView = 0.5
        },
        ShotDetectionRange = { 30, 1500, 130 },
        PathableDistance = { 300, 10000 },
        TargetCooldown = {
            SearchLastSeen = 180,
            ReturnHome = 320
        },
        Walkspeed = {
            Sprint = 6,
            Alerted = 5,
            Aware = 4,
            Idle = 2.25
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                1,
                3,
                5
            },
            {
                2000,
                1,
                1,
                1,
                3,
                7
            }
        },
        RateOfFireSecondary = {
            {
                0,
                4,
                7,
                0.08,
                0.5,
                1
            },
            {
                80,
                4,
                5,
                0.08,
                0.5,
                1
            },
            {
                300,
                1,
                1,
                0.25
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.8 },
        WeaponAccuracy = {
            { 0, 1 },
            { 50, 4 },
            { 1000, 3 },
            { 1500, 4.5 }
        }
    },
    POD_AutoRifleman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        UseMotar = true,
        RadioTime = 5,
        MeleeDistance = 5,
        SecondaryDistance = 10,
        Appearance = "POD_Heavy",
        Fear = "POD",
        Health = 110,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 40, 30 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_RPD" }
        },
        ViewDistance = {
            Day = { 400, 800 },
            Night = { 60, 700 }
        },
        FogMultiplier = {
            ViewDistance = 0.35,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = {
            30,
            1400,
            130,
            500
        },
        PathableDistance = { 100, 600 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 14,
            Alerted = 10,
            Aware = 6,
            Idle = 2.25
        },
        RateOfFire = {
            {
                0,
                15,
                30,
                0.09375,
                0.15,
                0.66
            },
            {
                40,
                5,
                8,
                0.09375,
                0.15,
                0.66
            },
            {
                400,
                2,
                3,
                0.09375,
                0.15,
                1
            },
            {
                800,
                2,
                3,
                0.09375,
                0.375,
                1.5
            }
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.35 },
        WeaponAccuracy = {
            { 0, 15 },
            { 50, 6 },
            { 800, 10 }
        }
    },
    POD_HeavyAuto = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        RadioTime = 5,
        MeleeDistance = 5,
        SecondaryDistance = 10,
        Appearance = "POD_Heavy",
        Fear = "POD",
        Health = 200,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 50, 40 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_PKM" }
        },
        Secondary = {
            { "AI_MAKAROV" }
        },
        ViewDistance = {
            Day = { 400, 800 },
            Night = { 60, 700 }
        },
        FogMultiplier = {
            ViewDistance = 0.35,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = {
            30,
            1400,
            130,
            500
        },
        PathableDistance = { 100, 600 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 14,
            Alerted = 10,
            Aware = 6,
            Idle = 2.25
        },
        RateOfFire = {
            {
                0,
                30,
                40,
                0.09375,
                2,
                3
            },
            {
                80,
                10,
                15,
                0.09375,
                1,
                2
            },
            {
                200,
                5,
                10,
                0.09375,
                0.45,
                2
            },
            {
                301,
                3,
                5,
                0.09375,
                0.5,
                3
            },
            {
                800,
                2,
                3,
                0.09375,
                0.75,
                3
            }
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.35 },
        WeaponAccuracy = {
            { 0, 15 },
            { 80, 5 },
            { 800, 10 }
        }
    },
    POD_Spec = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        EquipTimer = 0.2,
        MeleeDistance = 3,
        NoSecondary = true,
        Appearance = "POD_Spec",
        Fear = "Spec",
        Health = 150,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1,
        DetectionFearMultiplier = 0.25,
        DetectionAlertedMultiplier = 0.1,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 60, 40 },
            Headshot = { 5, 5 },
            Stealth = { 10, 10 }
        },
        Weapon = {
            { "AI_AK" }
        },
        ViewDistance = {
            Day = { 500, 750 },
            Night = { 500, 600 }
        },
        FogMultiplier = {
            ViewDistance = 0.45,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 70, 60 },
                { 50, 50 }
            },
            Night = {
                { 30, 30 },
                { 50, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 800, 130 },
        PathableDistance = { 100, 300 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 9,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                2,
                3,
                0.09375,
                0.15,
                0.45
            },
            {
                200,
                2,
                3,
                0.09375,
                0.2,
                0.6
            },
            {
                399,
                2,
                3,
                0.09375,
                0.3,
                0.75
            },
            {
                400,
                1,
                1,
                0.09375,
                0.33,
                1
            }
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.675 },
        WeaponAccuracy = {
            { 0, 5 },
            { 150, 6 },
            { 151, 4 },
            { 600, 6 }
        }
    },
    POD_HeliGunner = {
        Behaviour = "Combat",
        Hidden = true,
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        EquipTimer = 0.2,
        MeleeDistance = 3,
        SecondaryDistance = 15,
        Appearance = "POD_Spec",
        Rewards = {
            Base = { 60, 60 },
            Headshot = { 5, 5 },
            Stealth = { 10, 20 }
        },
        Fear = "Spec",
        Health = 150,
        Weapon = {
            { "AI_AK" }
        },
        Secondary = {
            { "Glock17G3" }
        },
        ViewDistance = {
            Day = { 1000, 1500 },
            Night = { 1000, 1500 }
        },
        FogMultiplier = {
            ViewDistance = 0.15,
            FieldOfView = 0.5
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 60 },
                { 50, 50 }
            },
            Night = {
                { 30, 30 },
                { 50, 50 }
            }
        },
        DetectionTimeMultiplier = 1,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        DetectionFearMultiplier = 0.25,
        DetectionAlertedMultiplier = 0.1,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = { 30, 800, 130 },
        PathableDistance = { 100, 300 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 9,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                2,
                3,
                0.09375,
                0.15,
                0.45
            },
            {
                200,
                2,
                3,
                0.09375,
                0.2,
                0.6
            },
            {
                399,
                2,
                3,
                0.09375,
                0.3,
                0.75
            },
            {
                400,
                1,
                1,
                0.09375,
                0.33,
                1
            }
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.1,
                0.25
            },
            {
                50,
                1,
                1,
                0.35,
                0.25,
                0.5
            },
            {
                150,
                1,
                1,
                0.45,
                0.25,
                0.5
            },
            {
                299,
                1,
                1,
                0.6,
                0.25,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 10, 0.5 },
        WeaponAccuracy = {
            { 0, 5 },
            { 50, 6 },
            { 600, 12 }
        }
    },
    POD_Marksman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        RadioTime = 5,
        EquipTimer = 2,
        MeleeDistance = 2,
        SecondaryDistance = 25,
        Appearance = "POD_Marksman",
        Fear = "Spec",
        Health = 100,
        ProneMultiplier = 0.25,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.45,
        DetectionTargetKnownMultiplier = 0.2,
        Rewards = {
            Base = { 50, 40 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_SVD" }
        },
        Secondary = {
            { "AI_APS" }
        },
        ViewDistance = {
            Day = { 1500, 2000 },
            Night = { 100, 300 }
        },
        FieldOfView = {
            Day = {
                { 40, 90 },
                { 40, 90 }
            },
            Night = {
                { 40, 80 },
                { 30, 80 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 20, 1 },
            { 1500, 10 }
        },
        FogMultiplier = {
            ViewDistance = 0.125,
            FieldOfView = 0.5
        },
        ShotDetectionRange = { 30, 1500, 130 },
        PathableDistance = { 300, 10000 },
        TargetCooldown = {
            SearchLastSeen = 180,
            ReturnHome = 320
        },
        Walkspeed = {
            Sprint = 6,
            Alerted = 5,
            Aware = 4,
            Idle = 2.25
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                1,
                1.5,
                3
            },
            {
                2000,
                1,
                1,
                1,
                2,
                6
            }
        },
        RateOfFireSecondary = {
            {
                0,
                4,
                7,
                0.08,
                0.5,
                1
            },
            {
                80,
                4,
                5,
                0.08,
                0.5,
                1
            },
            {
                300,
                1,
                1,
                0.25
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.65 },
        WeaponAccuracy = {
            { 0, 1.5 },
            { 1000, 4 },
            { 1500, 6 }
        }
    },
    POD_Smoker_Light = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = false,
        RadioTime = 5,
        Fear = "POD",
        SmokerGrenade = 50,
        Appearance = "POD_Smoker",
        Health = 110,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 40, 15 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_PP19" }
        },
        ViewDistance = {
            Day = { 50, 200 },
            Night = { 50, 200 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 50, 50 },
                { 50, 50 }
            },
            Night = {
                { 40, 40 },
                { 40, 40 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 75, 3 },
            { 200, 5 },
            { 900, 10 }
        },
        ShotDetectionRange = { 20, 400, 80 },
        PathableDistance = { 0, 3 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 5,
            Idle = 5
        },
        RateOfFire = {
            {
                3,
                0,
                0,
                0.25
            },
            {
                4,
                1,
                1,
                0.25
            },
            {
                150,
                1,
                1,
                0.5
            },
            {
                200,
                0,
                0,
                5
            }
        },
        WeaponAccuracy = {
            { 0, 1 },
            { 10, 5 },
            { 300, 15 }
        }
    },
    POD_Smoker = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = false,
        Fear = "POD",
        SmokerGrenade = 50,
        Appearance = "POD_Smoker",
        Health = 130,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 40, 30 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_PP19" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 150, 200 }
        },
        FogMultiplier = {
            ViewDistance = 0.25,
            FieldOfView = 0.8
        },
        FieldOfView = {
            Day = {
                { 50, 50 },
                { 50, 50 }
            },
            Night = {
                { 40, 40 },
                { 40, 40 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 600, 10 }
        },
        ShotDetectionRange = { 30, 400, 80 },
        PathableDistance = { 0, 3 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 5,
            Idle = 5
        },
        RateOfFire = {
            {
                3,
                0,
                0,
                0.075
            },
            {
                4,
                5,
                6,
                0.075
            },
            {
                150,
                2,
                4,
                0.075
            },
            {
                151,
                0,
                0,
                1
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.1 },
        WeaponAccuracy = {
            { 0, 1 },
            { 5, 4 },
            { 100, 8 },
            { 350, 10 }
        }
    },
    POD_Smoker_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = false,
        Fear = "POD",
        SmokerGrenade = 50,
        Appearance = "POD_Smoker",
        Health = 200,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 60, 40 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_SAIGA" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 150, 200 }
        },
        FogMultiplier = {
            ViewDistance = 0.25,
            FieldOfView = 0.8
        },
        FieldOfView = {
            Day = {
                { 40, 40 },
                { 30, 30 }
            },
            Night = {
                { 30, 30 },
                { 30, 30 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 20, 0.25 },
            { 75, 3 },
            { 200, 5 },
            { 900, 10 }
        },
        ShotDetectionRange = { 30, 400, 80 },
        PathableDistance = { 0, 3 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 14,
            Alerted = 13,
            Aware = 5,
            Idle = 5
        },
        RateOfFire = {
            {
                5,
                0,
                0,
                0.1
            },
            {
                6,
                4,
                5,
                0.1
            },
            {
                100,
                1,
                1,
                0.1
            },
            {
                101,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 1 },
            { 5, 3 },
            { 200, 12.5 }
        }
    },
    Hostage_Rifleman = {
        Behaviour = "Civilian",
        Hidden = true,
        IsFriendly = true,
        UseCover = true,
        UseMG = true,
        RadioTime = 5,
        Appearance = "FAI_Rifleman",
        Health = 130,
        DetectionTimeMultiplier = 1.25,
        Rewards = {
            Base = { -200, 0 },
            Headshot = { -100, 0 },
            Stealth = { 0, 0 }
        },
        ViewDistance = {
            Day = { 100, 0 },
            Night = { 50, 300 }
        },
        FieldOfView = {
            Day = {
                { 30, 30 },
                { 30, 30 }
            },
            Night = {
                { 20, 20 },
                { 20, 20 }
            }
        },
        DetectionTime = {
            { 1, 0.25 },
            { 25, 3 },
            { 100, 5 },
            { 1000, 10 }
        },
        ShotDetectionRange = { 30, 2000, 50 },
        PathableDistance = { 40, 70 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 80
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 12,
            Aware = 9,
            Idle = 5
        },
        RateOfFire = {
            {
                20,
                3,
                5,
                0.09375
            },
            {
                30,
                2,
                4,
                0.09375
            },
            {
                100,
                2,
                3,
                0.25
            },
            {
                200,
                1,
                1,
                0
            }
        },
        WeaponAccuracy = {
            { 1, 20 },
            { 40, 2 },
            { 100, 3 },
            { 600, 7 }
        }
    },
    Hostage_Rono = {
        Behaviour = "Civilian",
        IsCivilian = true,
        IsFriendly = true,
        Hidden = true,
        Appearance = "Hostage_Civilian",
        Health = 75,
        ViewDistance = {
            Day = { 10, 10 },
            Night = { 10, 10 }
        },
        Rewards = {
            Base = { -200, 0 },
            Headshot = { -100, 0 },
            Stealth = { 0, 0 }
        },
        FieldOfView = {
            Day = {
                { 10, 10 },
                { 10, 10 }
            },
            Night = {
                { 10, 10 },
                { 10, 10 }
            }
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 12,
            Aware = 9,
            Idle = 5
        }
    },
    Hostage_Rono_VIP = {
        Behaviour = "Civilian",
        IsHostage = true,
        IsFriendly = true,
        Hidden = true,
        Appearance = "Hostage_VIP",
        Health = 75,
        DetectionTimeMultiplier = 1.25,
        Rewards = {
            Base = { -2000, 0 },
            Headshot = { -1000, 0 },
            Stealth = { 0, 0 }
        },
        ViewDistance = {
            Day = { 10, 10 },
            Night = { 10, 10 }
        },
        FieldOfView = {
            Day = {
                { 10, 10 },
                { 10, 10 }
            },
            Night = {
                { 10, 10 },
                { 10, 10 }
            }
        },
        DetectionTime = {
            { 10, 100 },
            { 1, 2 }
        },
        PathableDistance = { 15, 25 },
        TargetCooldown = {
            SearchLastSeen = 10,
            ReturnHome = 20
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 13,
            Idle = 5
        }
    },
    Special_Creature = {
        Behaviour = "Combat",
        IsFriendly = false,
        Hidden = true,
        UseCover = false,
        RadioTime = 5,
        MeleeOnly = true,
        Fear = "RLF",
        Appearance = "POD_Commander",
        Health = 8000,
        Weapon = "Machete",
        DetectionTimeMultiplier = 0.5,
        Rewards = {
            Base = { 200, 100 },
            Headshot = { 50, 5 },
            Stealth = { 10, 5 }
        },
        ViewDistance = {
            Day = { 600, 600 },
            Night = { 1000, 1000 }
        },
        FieldOfView = {
            Day = {
                { 180, 180 },
                { 90, 160 }
            },
            Night = {
                { 180, 180 },
                { 60, 150 }
            }
        },
        DetectionTime = {
            { 1, 0.25 },
            { 1000, 0.5 }
        },
        ShotDetectionRange = { 300, 500 },
        PathableDistance = { 0, 1 },
        TargetCooldown = {
            SearchLastSeen = 1,
            ReturnHome = 2
        },
        Walkspeed = {
            Sprint = 50,
            Alerted = 20,
            Aware = 50,
            Idle = 50
        },
        RateOfFire = {
            {
                40,
                1,
                1,
                0.1
            },
            {
                100,
                2,
                4,
                0.1
            },
            {
                200,
                1,
                3,
                0.1
            }
        },
        WeaponAccuracy = {
            { 100, 1 },
            { 300, 1 }
        }
    },
    Special_Naval_VIP_Office = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        Hidden = true,
        NoSecondary = true,
        Appearance = "POD_Commander",
        Health = 100,
        DetectionTimeMultiplier = 1.25,
        Rewards = {
            Base = { 150, 75 },
            Headshot = { 5, 5 },
            Stealth = { 400, 500 }
        },
        Weapon = {
            { "AI_SAIGA" }
        },
        ViewDistance = {
            Day = { 100, 200 },
            Night = { 50, 300 }
        },
        FieldOfView = {
            Day = {
                { 50, 50 },
                { 40, 40 }
            },
            Night = {
                { 40, 40 },
                { 30, 30 }
            }
        },
        DetectionTime = {
            { 0, 0.01 },
            { 20, 0.05 },
            { 75, 0.25 },
            { 400, 4 },
            { 1000, 7 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 15, 2000 },
        TargetCooldown = {
            SearchLastSeen = 10,
            ReturnHome = 20
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 13,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                5,
                15,
                0.1
            },
            {
                149,
                5,
                15,
                0.1
            },
            {
                150,
                1,
                1,
                0.1
            },
            {
                200,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracy = {
            { 0, 2 },
            { 100, 5 }
        }
    },
    Special_VIP_BigMan = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        EquipTimer = 0.01,
        NoSecondary = true,
        Hiddden = true,
        Appearance = "POD_Commander",
        Health = 100,
        DetectionTimeMultiplier = 1.25,
        Rewards = {
            Base = { 200, 100 },
            Headshot = { 5, 5 },
            Stealth = { 1000, 1000 }
        },
        Weapon = {
            { "Groza" }
        },
        ViewDistance = {
            Day = { 100, 200 },
            Night = { 200, 200 }
        },
        FieldOfView = {
            Day = {
                { 50, 50 },
                { 50, 50 }
            },
            Night = {
                { 50, 50 },
                { 50, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.01 },
            { 20, 0.01 },
            { 75, 0.1 },
            { 400, 4 },
            { 1000, 7 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 15, 2000 },
        TargetCooldown = {
            SearchLastSeen = 200,
            ReturnHome = 200
        },
        Walkspeed = {
            Sprint = 25,
            Alerted = 20,
            Aware = 20,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                5,
                15,
                0.08
            },
            {
                100,
                5,
                10,
                0.08
            },
            {
                150,
                1,
                1,
                0.1
            },
            {
                200,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracy = {
            { 0, 125 },
            { 100, 5 }
        }
    },
    Special_Fort_Spec_Bigman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 5,
        EquipTimer = 0.1,
        NoSecondary = true,
        Hidden = true,
        Appearance = "POD_Spec",
        Health = 110,
        DetectionTimeMultiplier = 1,
        Rewards = {
            Base = { 75, 40 },
            Headshot = { 5, 5 },
            Stealth = { 50, 50 }
        },
        Weapon = {
            { "AI_AK" }
        },
        ViewDistance = {
            Day = { 200, 400 },
            Night = { 60, 400 }
        },
        FieldOfView = {
            Day = {
                { 50, 50 },
                { 50, 50 }
            },
            Night = {
                { 30, 30 },
                { 30, 30 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 75, 0.25 },
            { 600, 1 },
            { 1000, 5 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 50, 100 },
        TargetCooldown = {
            SearchLastSeen = 80,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 13,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                4,
                5,
                0.08
            },
            {
                20,
                5,
                10,
                0.08
            },
            {
                40,
                2,
                3,
                0.08
            },
            {
                1300,
                1,
                1,
                0.3
            }
        },
        WeaponAccuracy = {
            { 0, 10 },
            { 100, 15 }
        }
    },
    Special_Bunker_PODCommander = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        Hidden = true,
        EquipTimer = 0.01,
        NoSecondary = true,
        Appearance = "POD_Commander",
        Health = 110,
        DetectionTimeMultiplier = 1.25,
        Rewards = {
            Base = { 400, 200 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "HK416A5" }
        },
        ViewDistance = {
            Day = { 200, 200 },
            Night = { 200, 200 }
        },
        FieldOfView = {
            Day = {
                { 100, 100 },
                { 100, 100 }
            },
            Night = {
                { 100, 100 },
                { 100, 100 }
            }
        },
        DetectionTime = {
            { 0, 0.01 },
            { 20, 0.01 },
            { 75, 0.01 },
            { 400, 4 },
            { 1000, 7 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 15, 2000 },
        TargetCooldown = {
            SearchLastSeen = 200,
            ReturnHome = 200
        },
        Walkspeed = {
            Sprint = 25,
            Alerted = 20,
            Aware = 20,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                5,
                10,
                0.075
            },
            {
                1000,
                5,
                10,
                0.075
            }
        },
        WeaponAccuracy = {
            { 0, 4 },
            { 100, 8 }
        }
    },
    Special_Naval_VIP_Smoker = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = false,
        NoSecondary = true,
        SmokerGrenade = 40,
        Appearance = "POD_Smoker",
        Hidden = true,
        Health = 300,
        DetectionTimeMultiplier = 1.25,
        Rewards = {
            Base = { 125, 125 },
            Headshot = { 5, 5 },
            Stealth = { 250, 250 }
        },
        Weapon = {
            { "AI_PKM" }
        },
        ViewDistance = {
            Day = { 200, 200 },
            Night = { 50, 200 }
        },
        FieldOfView = {
            Day = {
                { 40, 40 },
                { 30, 30 }
            },
            Night = {
                { 30, 30 },
                { 20, 20 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 20, 0.25 },
            { 75, 0.25 },
            { 400, 4 },
            { 1000, 7 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 0, 3 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 15,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                50,
                50,
                0.08
            },
            {
                200,
                50,
                50,
                0.08
            },
            {
                201,
                5,
                10,
                0.1
            },
            {
                1500,
                4,
                6,
                0.1
            }
        },
        WeaponAccuracy = {
            { 0, 5 },
            { 50, 4 },
            { 100, 6 },
            { 1500, 15 }
        }
    },
    Special_Bunker_Spec = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 5,
        EquipTimer = 0.1,
        NoSecondary = true,
        Appearance = "POD_Spec",
        Hidden = true,
        Health = 100,
        DetectionTimeMultiplier = 1,
        Rewards = {
            Base = { 70, 35 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_RPD" }
        },
        ViewDistance = {
            Day = { 100, 200 },
            Night = { 100, 200 }
        },
        FieldOfView = {
            Day = {
                { 60, 60 },
                { 60, 60 }
            },
            Night = {
                { 60, 60 },
                { 60, 60 }
            }
        },
        DetectionTime = {
            { 0, 0.01 },
            { 100, 0.01 },
            { 600, 1 },
            { 1000, 5 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 5, 30 },
        TargetCooldown = {
            SearchLastSeen = 80,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 13,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                5,
                10,
                0.1
            },
            {
                50,
                5,
                10,
                0.1
            },
            {
                150,
                2,
                3,
                0.1
            },
            {
                1300,
                1,
                1,
                0.3
            }
        },
        WeaponAccuracy = {
            { 0, 5 },
            { 100, 15 }
        }
    },
    Special_POD_Sniper = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        RadioTime = 5,
        EquipTimer = 2,
        MeleeDistance = 2,
        SecondaryDistance = 30,
        Appearance = "POD_Sniper",
        Fear = "Spec",
        Health = 140,
        ProneMultiplier = 0.25,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.45,
        DetectionTargetKnownMultiplier = 0.2,
        Rewards = {
            Base = { 50, 40 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_KSVK" }
        },
        Secondary = {
            { "AI_APS" }
        },
        ViewDistance = {
            Day = { 2000, 1500 },
            Night = { 1000, 1500 }
        },
        FieldOfView = {
            Day = {
                { 40, 90 },
                { 40, 90 }
            },
            Night = {
                { 40, 80 },
                { 30, 80 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 20, 1 },
            { 1500, 3 }
        },
        FogMultiplier = {
            ViewDistance = 0.35,
            FieldOfView = 0.5
        },
        ShotDetectionRange = { 30, 1500, 130 },
        PathableDistance = { 300, 10000 },
        TargetCooldown = {
            SearchLastSeen = 180,
            ReturnHome = 320
        },
        Walkspeed = {
            Sprint = 6,
            Alerted = 5,
            Aware = 4,
            Idle = 2.25
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                1,
                3,
                5
            },
            {
                2000,
                1,
                1,
                1,
                3,
                6
            }
        },
        RateOfFireSecondary = {
            {
                0,
                4,
                7,
                0.08,
                0.5,
                1
            },
            {
                80,
                4,
                5,
                0.08,
                0.5,
                1
            },
            {
                300,
                1,
                1,
                0.25
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.9 },
        WeaponAccuracy = {
            { 0, 1.5 },
            { 1000, 1 },
            { 1500, 2 }
        }
    },
    POD_Liason = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        RadioTime = 4,
        EquipTimer = 1,
        Appearance = "Insolon_VIP",
        Fear = "POD",
        Health = 125,
        Hidden = true,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        SprintCancel = 15,
        Rewards = {
            Base = { 100, 50 },
            Headshot = { 10, 5 },
            Stealth = { 50, 255 }
        },
        Weapon = {
            { "Groza" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 50, 1000 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 8,
            Idle = 4
        },
        RateOfFire = {
            {
                0,
                8,
                15,
                0.08,
                0.35,
                0.5
            },
            {
                20,
                5,
                10,
                0.08,
                0.35,
                0.5
            },
            {
                100,
                2,
                3,
                0.08,
                0.35,
                0.5
            },
            {
                300,
                1,
                2,
                0.08,
                0.35,
                0.5
            },
            {
                301,
                0,
                0,
                1,
                0.35,
                0.5
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.25 },
        WeaponAccuracy = {
            { 0, 6 },
            { 20, 4 },
            { 50, 8 },
            { 350, 10 }
        }
    }
};