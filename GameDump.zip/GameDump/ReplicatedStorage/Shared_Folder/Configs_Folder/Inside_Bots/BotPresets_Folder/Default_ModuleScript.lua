-- Roblox: ReplicatedStorage.Shared.Configs.Bots.BotPresets.Default
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    PL5_Rifleman = {
        Behaviour = "Combat",
        IsFriendly = true,
        UseCover = true,
        UseMG = true,
        RadioTime = 5,
        Appearance = "FAI_Rifleman",
        Health = 130,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 5, 5 },
            Stealth = { 10, 5 }
        },
        Weapon = {
            { "M4A1" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 2000, 75 },
        PathableDistance = { 100, 300 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 13,
            Idle = 3
        },
        RateOfFire = {
            {
                5,
                0,
                0,
                0.063
            },
            {
                6,
                3,
                5,
                0.063
            },
            {
                150,
                2,
                3,
                0.063
            },
            {
                600,
                1,
                1,
                0.2
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 1 },
            { 50, 4 },
            { 600, 10 }
        }
    },
    PL5_HeliGunner = {
        Hidden = true,
        Behaviour = "Combat",
        IsFriendly = true,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 7,
        MeleeDistance = 3,
        SecondaryDistance = 15,
        NoPrimary = true,
        Appearance = "UNIDB_HeliCrew",
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Fear = "RLF",
        Health = 200,
        Secondary = {
            { "M9Berretta" }
        },
        ViewDistance = {
            Day = { 100, 200 },
            Night = { 100, 200 }
        },
        FogMultiplier = {
            ViewDistance = 1,
            FieldOfView = 1
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 80, 180 },
                { 80, 180 }
            },
            Night = {
                { 80, 180 },
                { 80, 180 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 4 },
            { 300, 7.5 },
            { 600, 10 }
        },
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.1,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 50, 300 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 12,
            Idle = 3
        },
        SprintCancel = 100,
        RateOfFire = {
            {
                0,
                6,
                15,
                0.09375,
                0.2,
                0.25
            },
            {
                50,
                3,
                6,
                0.09375,
                0.2,
                0.25
            },
            {
                200,
                2,
                4,
                0.09375,
                0.2,
                0.5
            },
            {
                300,
                2,
                4,
                0.09375,
                0.2,
                0.45
            },
            {
                600,
                1,
                1,
                0.5,
                0.2,
                0.6
            }
        },
        RateOfFireSecondary = {
            {
                0,
                4,
                5,
                0.25,
                0.25,
                0.6
            },
            {
                50,
                4,
                5,
                0.25,
                0.25,
                0.6
            },
            {
                150,
                1,
                1,
                1,
                0.25,
                0.6
            },
            {
                400,
                1,
                1,
                1,
                0.25,
                0.6
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.6
            }
        },
        WeaponAccuracyDamper = { 10, 0.5 },
        WeaponAccuracy = {
            { 0, 1.25 },
            { 100, 1.25 },
            { 300, 3 },
            { 600, 9 }
        }
    },
    PL5_Pilot = {
        Behaviour = "Combat",
        IsFriendly = true,
        UseCover = true,
        UseMG = true,
        RadioTime = 5,
        EquipTimer = 0.2,
        Hidden = true,
        NoPrimary = true,
        NoMelee = true,
        Appearance = "UNIDB_HeliCrew",
        Fear = "POD",
        Health = 99999999999999,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        SprintCancel = 15,
        Rewards = {
            Base = { 35, 20 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Secondary = {
            { "M9Berretta" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 2000, 75 },
        PathableDistance = { 15, 70, 200 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 13,
            Idle = 3
        },
        RateOfFire = {
            {
                3,
                0,
                0,
                0.075
            },
            {
                4,
                5,
                6,
                0.075
            },
            {
                100,
                2,
                3,
                0.15
            },
            {
                200,
                2,
                3,
                0.2
            },
            {
                201,
                1,
                1,
                0.25
            },
            {
                349,
                1,
                1,
                0.5
            },
            {
                100,
                1,
                1,
                0.15,
                0.1,
                0.25
            },
            {
                200,
                1,
                1,
                0.2,
                0.25,
                0.5
            },
            {
                201,
                1,
                1,
                0.2,
                0.5,
                1
            },
            {
                349,
                1,
                1,
                0.2,
                1,
                2
            },
            {
                350,
                0,
                0,
                1
            }
        },
        RateOfFireSecondary = {
            {
                3,
                0,
                0,
                0.075
            },
            {
                4,
                5,
                6,
                0.075
            },
            {
                100,
                2,
                3,
                0.15
            },
            {
                200,
                2,
                3,
                0.2
            },
            {
                201,
                1,
                1,
                0.25
            },
            {
                349,
                1,
                1,
                0.5
            },
            {
                100,
                1,
                1,
                0.15,
                0.1,
                0.25
            },
            {
                200,
                1,
                1,
                0.2,
                0.25,
                0.5
            },
            {
                201,
                1,
                1,
                0.2,
                0.5,
                1
            },
            {
                349,
                1,
                1,
                0.2,
                1,
                2
            },
            {
                350,
                0,
                0,
                1
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 1 },
            { 5, 4 },
            { 100, 8 },
            { 350, 10 }
        }
    },
    PL5_Sniper = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        RadioTime = 5,
        EquipTimer = 2,
        Hidden = true,
        MeleeDistance = 2,
        NoSecondary = true,
        Appearance = "POD_Sniper",
        Fear = "POD",
        Health = 100,
        ProneMultiplier = 1,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.45,
        DetectionTargetKnownMultiplier = 0.2,
        Rewards = {
            Base = { 50, 40 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "Hecate" }
        },
        ViewDistance = {
            Day = { 2000, 2000 },
            Night = { 2000, 2000 }
        },
        FieldOfView = {
            Day = {
                { 50, 50 },
                { 50, 50 }
            },
            Night = {
                { 50, 50 },
                { 50, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 2000, 5 }
        },
        FogMultiplier = {
            ViewDistance = 1,
            FieldOfView = 1
        },
        ShotDetectionRange = { 30, 2000, 130 },
        PathableDistance = { 300, 10000 },
        TargetCooldown = {
            SearchLastSeen = 180,
            ReturnHome = 320
        },
        Walkspeed = {
            Sprint = 6,
            Alerted = 5,
            Aware = 4,
            Idle = 2.25
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                1,
                3,
                5
            },
            {
                2000,
                1,
                1,
                1,
                3,
                7
            }
        },
        RateOfFireSecondary = {
            {
                0,
                4,
                7,
                0.08,
                0.5,
                1
            },
            {
                80,
                4,
                5,
                0.08,
                0.5,
                1
            },
            {
                300,
                1,
                1,
                0.25
            }
        },
        WeaponAccuracyDamper = { 4, 0.8 },
        WeaponAccuracy = {
            { 0, 0 },
            { 2000, 4 }
        }
    },
    PL5_Operator = {
        Behaviour = "Combat",
        IsFriendly = true,
        UseCover = true,
        UseMG = true,
        RadioTime = 5,
        Hidden = true,
        Appearance = "FAI_Rifleman",
        Health = 300,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        Rewards = {
            Base = { 20, 10 },
            Headshot = { 5, 5 },
            Stealth = { 10, 5 }
        },
        Weapon = {
            { "M4A1" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 },
            { 100, 0.25 },
            { 300, 0.25 },
            { 600, 0.25 }
        },
        ShotDetectionRange = { 30, 2000, 75 },
        PathableDistance = { 100, 10, 300 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 13,
            Idle = 3
        },
        RateOfFire = {
            {
                5,
                0,
                0,
                0.063
            },
            {
                6,
                3,
                5,
                0.063
            },
            {
                150,
                2,
                3,
                0.063
            },
            {
                0,
                3,
                5,
                0.063,
                0.1,
                0.25
            },
            {
                150,
                2,
                3,
                0.063,
                0.1,
                0.4
            },
            {
                599,
                1,
                3,
                0.063,
                0.3,
                0.4
            },
            {
                600,
                1,
                1,
                0.2
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 1 },
            { 50, 4 },
            { 600, 10 },
            { 50, 2 },
            { 600, 6 }
        }
    },
    Dummy_Blind = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 10,
        Hidden = true,
        Appearance = "RLF_Rifleman",
        Health = 100,
        ProneMultiplier = 0.4,
        DetectionTimeMultiplier = 3,
        Rewards = {
            Base = { 0, 0 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_AK" },
            { "AI_AK" }
        },
        ViewDistance = {
            Day = { 0, 700 },
            Night = { 0, 600 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 20, 0.25 },
            { 75, 5 },
            { 200, 6 },
            { 600, 7 }
        },
        ShotDetectionRange = { 0, 0, 0 },
        PathableDistance = { 40, 200 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 12,
            Aware = 12,
            Idle = 6
        },
        RateOfFire = {
            {
                4,
                0,
                0,
                0.09375
            },
            {
                5,
                5,
                10,
                0.09375
            },
            {
                200,
                5,
                10,
                0.09375
            },
            {
                250,
                2,
                3,
                0.25
            },
            {
                1000,
                1,
                1,
                0.5
            }
        },
        WeaponAccuracy = {
            { 0, 7 },
            { 250, 7 },
            { 700, 15 }
        }
    },
    Dummy_Rifleman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 5,
        Hidden = true,
        Appearance = "RLF_Rifleman",
        Health = 100,
        ProneMultiplier = 0.4,
        DetectionTimeMultiplier = 1.25,
        Rewards = {
            Base = { 0, 10 },
            Headshot = { 0, 5 },
            Stealth = { 0, 5 }
        },
        Weapon = {
            { "AI_AK" }
        },
        ViewDistance = {
            Day = { 500, 700 },
            Night = { 100, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 80, 80 },
                { 50, 70 }
            },
            Night = {
                { 60, 70 },
                { 50, 60 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 20, 0.25 },
            { 150, 2 },
            { 500, 8 }
        },
        ShotDetectionRange = { 10, 1000, 300 },
        PathableDistance = { 40, 250 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 14,
            Aware = 12,
            Idle = 5
        },
        RateOfFire = {
            {
                1,
                5,
                10,
                0.09375
            },
            {
                100,
                5,
                10,
                0.09375
            },
            {
                105,
                2,
                3,
                0.25
            },
            {
                600,
                2,
                3,
                0.5
            }
        },
        WeaponAccuracy = {
            { 0, 8 },
            { 100, 15 },
            { 105, 6 },
            { 600, 8 }
        }
    },
    Dummy_CivvyDemo = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        RadioTime = 10,
        Hidden = true,
        NoPrimary = true,
        NoSecondary = true,
        MeleeOnly = true,
        MeleeDistance = 5,
        Appearance = "Hostage_Civilian",
        Health = 100,
        ProneMultiplier = 0.4,
        DetectionTimeMultiplier = 3,
        Rewards = {
            Base = { -100, 0 },
            Headshot = { 0, 0 },
            Stealth = { 0, 0 }
        },
        ViewDistance = {
            Day = { 100, 100 },
            Night = { 100, 100 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 20, 0.25 },
            { 75, 5 },
            { 200, 6 },
            { 600, 7 }
        },
        ShotDetectionRange = { 30, 500, 100 },
        PathableDistance = { 1000, 1000 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 16,
            Aware = 16,
            Idle = 6
        },
        RateOfFire = {
            {
                4,
                0,
                0,
                0.09375
            },
            {
                5,
                5,
                10,
                0.09375
            },
            {
                200,
                5,
                10,
                0.09375
            },
            {
                250,
                2,
                3,
                0.25
            },
            {
                1000,
                1,
                1,
                0.5
            }
        },
        WeaponAccuracy = {
            { 0, 7 },
            { 250, 7 },
            { 700, 15 }
        }
    },
    M1_SMG = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 10,
        EquipTimer = 0.05,
        Hidden = true,
        Appearance = "Hostage_Civilian",
        NoSecondary = true,
        NoMelee = true,
        Health = 75,
        ProneMultiplier = 1,
        DetectionTimeMultiplier = 1.25,
        SprintCancel = 100,
        Rewards = {
            Base = { 15, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "MP5" }
        },
        ViewDistance = {
            Day = { 300, 400 },
            Night = { 200, 300 }
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 80, 80 },
                { 80, 80 }
            }
        },
        DetectionTime = {
            { 0, 0.01 },
            { 100, 0.1 }
        },
        ShotDetectionRange = { 30, 2000, 50 },
        PathableDistance = { 5, 10 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                5,
                10,
                0.075,
                0.5,
                1
            },
            {
                100,
                3,
                6,
                0.075,
                0.5,
                1
            }
        },
        WeaponAccuracyDamper = { 6, 0.25 },
        WeaponAccuracy = {
            { 0, 15 },
            { 100, 25 }
        }
    },
    M1_SMG2 = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 10,
        EquipTimer = 0.05,
        Hidden = true,
        Appearance = "Hostage_Civilian",
        NoSecondary = true,
        NoMelee = true,
        Health = 75,
        ProneMultiplier = 1,
        DetectionTimeMultiplier = 1.25,
        SprintCancel = 30,
        Rewards = {
            Base = { 15, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_VZ" }
        },
        ViewDistance = {
            Day = { 300, 400 },
            Night = { 200, 300 }
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 80, 80 },
                { 80, 80 }
            }
        },
        DetectionTime = {
            { 0, 0.01 },
            { 100, 0.1 }
        },
        ShotDetectionRange = { 30, 2000, 50 },
        PathableDistance = { 5, 10 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                3,
                15,
                0.065,
                0.1,
                0.5
            },
            {
                60,
                1,
                10,
                0.065,
                0.1,
                0.5
            }
        },
        WeaponAccuracyDamper = { 2, 0.5 },
        WeaponAccuracy = {
            { 0, 7 },
            { 100, 15 }
        }
    },
    M1_AK = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 10,
        EquipTimer = 0.05,
        Hidden = true,
        Appearance = "Hostage_Civilian",
        NoSecondary = true,
        NoMelee = true,
        Health = 75,
        ProneMultiplier = 1,
        DetectionTimeMultiplier = 1.25,
        SprintCancel = 100,
        Rewards = {
            Base = { 15, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M4A1" }
        },
        ViewDistance = {
            Day = { 300, 400 },
            Night = { 200, 300 }
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 80, 80 },
                { 80, 80 }
            }
        },
        DetectionTime = {
            { 0, 0.01 },
            { 100, 0.1 }
        },
        ShotDetectionRange = { 30, 2000, 50 },
        PathableDistance = { 5, 10 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                5,
                10,
                0.08,
                0.25,
                0.5
            },
            {
                100,
                3,
                7,
                0.08,
                0.25,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.6 },
        WeaponAccuracy = {
            { 0, 10 },
            { 100, 20 }
        }
    },
    M1_AK2 = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 10,
        EquipTimer = 0.05,
        Hidden = true,
        Appearance = "Hostage_Civilian",
        NoSecondary = true,
        NoMelee = true,
        Health = 75,
        ProneMultiplier = 1,
        DetectionTimeMultiplier = 1.25,
        SprintCancel = 100,
        Rewards = {
            Base = { 15, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_AK" }
        },
        ViewDistance = {
            Day = { 300, 400 },
            Night = { 200, 300 }
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 80, 80 },
                { 80, 80 }
            }
        },
        DetectionTime = {
            { 0, 0.01 },
            { 100, 0.1 }
        },
        ShotDetectionRange = { 30, 2000, 50 },
        PathableDistance = { 5, 10 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                10,
                15,
                0.09375,
                0.1,
                0.5
            },
            {
                100,
                3,
                6,
                0.09375,
                0.1,
                0.5
            }
        },
        WeaponAccuracyDamper = { 10, 0.7 },
        WeaponAccuracy = {
            { 0, 8 },
            { 150, 15 }
        }
    },
    M1_PKM = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 10,
        EquipTimer = 0.05,
        Hidden = true,
        Appearance = "RLF_Heavy",
        NoSecondary = true,
        NoMelee = true,
        Health = 150,
        ProneMultiplier = 1,
        DetectionTimeMultiplier = 1.25,
        SprintCancel = 100,
        Rewards = {
            Base = { 15, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_PKM" }
        },
        ViewDistance = {
            Day = { 300, 400 },
            Night = { 200, 500 }
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 80, 80 },
                { 80, 80 }
            }
        },
        DetectionTime = {
            { 0, 0.01 },
            { 100, 0.1 }
        },
        ShotDetectionRange = { 30, 2000, 50 },
        PathableDistance = { 50, 200 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                3,
                8,
                0.1,
                0.2,
                0.5
            },
            {
                100,
                3,
                8,
                0.1,
                0.2,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.75 },
        WeaponAccuracy = {
            { 0, 10 },
            { 150, 20 }
        }
    },
    M1_Sniper = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 10,
        EquipTimer = 0.05,
        Hidden = true,
        Appearance = "Hostage_Civilian",
        NoSecondary = true,
        NoMelee = true,
        Health = 75,
        ProneMultiplier = 1,
        DetectionTimeMultiplier = 1.25,
        SprintCancel = 100,
        Rewards = {
            Base = { 15, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "SVDS" }
        },
        ViewDistance = {
            Day = { 300, 400 },
            Night = { 500, 700 }
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 80, 80 },
                { 80, 80 }
            }
        },
        DetectionTime = {
            { 0, 0.01 },
            { 100, 0.1 }
        },
        ShotDetectionRange = { 30, 2000, 50 },
        PathableDistance = { 150, 500 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                1,
                0.2,
                0.05,
                0.3
            },
            {
                100,
                1,
                1,
                0.2,
                0.05,
                0.3
            }
        },
        WeaponAccuracyDamper = { 1, 1 },
        WeaponAccuracy = {
            { 0, 1 },
            { 300, 2.5 }
        }
    },
    M1_Friendly = {
        Behaviour = "Combat",
        IsFriendly = true,
        UseCover = true,
        UseMG = true,
        RadioTime = 10,
        EquipTimer = 0.05,
        Hidden = true,
        Appearance = "M1_Friendly",
        Health = 100,
        ProneMultiplier = 1,
        DetectionTimeMultiplier = 1.25,
        SprintCancel = 100,
        Rewards = {
            Base = { 15, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            {
                "G36",
                {
                    { "Weapon", "Receiver", "G36" },
                    {},
                    {
                        Topmount = {
                            ["1"] = {
                                { "Weapon", "Topmount", "G36_RailCarryhandle" },
                                {},
                                {
                                    Rail_1 = {
                                        ["1"] = {
                                            { "Weapon", "Device", "EOTechXPS3" },
                                            {
                                                Lerp = 0.23
                                            },
                                            {}
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        ViewDistance = {
            Day = { 300, 400 },
            Night = { 200, 300 }
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 80, 80 },
                { 80, 80 }
            }
        },
        DetectionTime = {
            { 0, 0.01 },
            { 100, 0.1 }
        },
        ShotDetectionRange = { 30, 2000, 50 },
        PathableDistance = { 50, 150 },
        TargetCooldown = {
            SearchLastSeen = 5,
            ReturnHome = 15
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                5,
                10,
                0.08,
                0.1,
                0.5
            },
            {
                200,
                2,
                3,
                0.08,
                0.2,
                0.5
            }
        },
        WeaponAccuracyDamper = { 7, 0.75 },
        WeaponAccuracy = {
            { 0, 9 },
            { 150, 14 }
        }
    },
    M1_Suspect = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        RadioTime = 5,
        Hidden = true,
        Appearance = "M1_Suspect",
        MeleeOnly = true,
        Health = 1,
        Weapon = "Machete",
        ProneMultiplier = 0.5,
        DetectionTimeMultiplier = 1.25,
        Rewards = {
            Base = { 15, 10 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        ViewDistance = {
            Day = { 200, 400 },
            Night = { 100, 200 }
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 20, 0.25 },
            { 75, 5 },
            { 200, 7 },
            { 600, 10 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.8
        },
        ShotDetectionRange = { 30, 2000, 50 },
        PathableDistance = { 0, 1 },
        TargetCooldown = {
            SearchLastSeen = 60,
            ReturnHome = 120
        },
        Walkspeed = {
            Sprint = 20,
            Alerted = 20,
            Aware = 20,
            Idle = 3
        },
        RateOfFire = {
            {
                40,
                1,
                1,
                0
            },
            {
                100,
                2,
                4,
                0.15
            },
            {
                200,
                1,
                3,
                0.1
            }
        },
        WeaponAccuracy = {
            { 100, 2 },
            { 300, 10 }
        }
    },
    HS_Basic = {
        Hidden = true,
        Behaviour = "Civilian",
        IsFriendly = true,
        Appearance = "Hostage_VIP",
        Health = 75,
        Rewards = {
            Base = { -2000, 0 },
            Headshot = { -1000, 0 },
            Stealth = { 0, 0 }
        },
        ViewDistance = {
            Day = { 10, 10 },
            Night = { 10, 10 }
        },
        FieldOfView = {
            Day = {
                { 10, 10 },
                { 10, 10 }
            },
            Night = {
                { 10, 10 },
                { 10, 10 }
            }
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 13,
            Idle = 3
        }
    },
    Z_ChefLecter = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        Hidden = true,
        RadioTime = 7,
        EquipTimer = 0.1,
        NoPrimary = true,
        HighPriority = true,
        Fear = "Bandit",
        Appearance = "ChefLecter",
        SecondaryDistance = 600,
        Health = 90,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 150, 150 },
            Headshot = { 5, 5 },
            Stealth = { 50, 50 }
        },
        Secondary = {
            { "AI_Glock17G3" },
            { "AI_M9Berretta" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 100, 1 },
            { 600, 4 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 10, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 4
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.05,
                0.25
            },
            {
                50,
                1,
                1,
                0.1,
                0.1,
                0.5
            },
            {
                150,
                1,
                1,
                0.1,
                0.3,
                0.5
            },
            {
                299,
                1,
                1,
                0.1,
                0.4,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 4, 0.5 },
        WeaponAccuracy = {
            { 0, 6 },
            { 20, 8 },
            { 300, 10 }
        }
    },
    Z_FixerSniper = {
        Behaviour = "Combat",
        IsFriendly = true,
        UseCover = true,
        RadioTime = 5,
        EquipTimer = 2,
        Hidden = true,
        MeleeDistance = 2,
        NoSecondary = true,
        Appearance = "POD_Sniper",
        Fear = "Kismet",
        Health = 100000,
        ProneMultiplier = 1,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.45,
        DetectionTargetKnownMultiplier = 0.2,
        Rewards = {
            Base = { 50, 40 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M107A1" }
        },
        ViewDistance = {
            Day = { 1000, 1000 },
            Night = { 1000, 1000 }
        },
        FieldOfView = {
            Day = {
                { 100, 100 },
                { 100, 100 }
            },
            Night = {
                { 100, 100 },
                { 100, 100 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 2000, 5 }
        },
        FogMultiplier = {
            ViewDistance = 1,
            FieldOfView = 1
        },
        ShotDetectionRange = { 30, 2000, 130 },
        PathableDistance = { 300, 10000 },
        TargetCooldown = {
            SearchLastSeen = 180,
            ReturnHome = 320
        },
        Walkspeed = {
            Sprint = 6,
            Alerted = 5,
            Aware = 4,
            Idle = 2.25
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                1,
                1,
                2
            },
            {
                2000,
                1,
                1,
                1,
                1,
                2
            }
        },
        RateOfFireSecondary = {
            {
                0,
                4,
                7,
                0.08,
                0.5,
                1
            },
            {
                80,
                4,
                5,
                0.08,
                0.5,
                1
            },
            {
                300,
                1,
                1,
                0.25
            }
        },
        WeaponAccuracyDamper = { 4, 0.95 },
        WeaponAccuracy = {
            { 0, 0 },
            { 2000, 1.5 }
        }
    },
    Z_DefectedResearcher = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        Hidden = true,
        HighPriority = true,
        RadioTime = 7,
        EquipTimer = 0.1,
        NoPrimary = true,
        Fear = "Bandit",
        Appearance = "RLF_Smg",
        SecondaryDistance = 600,
        Health = 90,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 200, 200 },
            Headshot = { 5, 5 },
            Stealth = { 50, 50 }
        },
        Secondary = {
            { "AI_Glock17G3" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 100, 1 },
            { 600, 4 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 10, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 4
        },
        RateOfFireSecondary = {
            {
                0,
                1,
                1,
                0.1,
                0.05,
                0.25
            },
            {
                50,
                1,
                1,
                0.1,
                0.1,
                0.5
            },
            {
                150,
                1,
                1,
                0.1,
                0.3,
                0.5
            },
            {
                299,
                1,
                1,
                0.1,
                0.4,
                0.75
            },
            {
                300,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 4, 0.5 },
        WeaponAccuracy = {
            { 0, 6 },
            { 20, 8 },
            { 300, 10 }
        }
    },
    Z_Pierrat = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        Hidden = true,
        HighPriority = true,
        RadioTime = 7,
        EquipTimer = 0.1,
        NoPrimary = false,
        Fear = "Bandit",
        Appearance = "SergeantPierrat",
        Health = 200,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.5,
        DetectionFearMultiplier = 0.5,
        DetectionAlertedMultiplier = 0.25,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 200, 200 },
            Headshot = { 50, 50 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_HK416A5" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 350 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.5 },
            { 100, 1 },
            { 600, 4 }
        },
        ShotDetectionRange = {
            30,
            800,
            130,
            350
        },
        PathableDistance = { 10, 600 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 4
        },
        RateOfFire = {
            {
                0,
                3,
                6,
                0.08,
                0.05,
                0.5
            },
            {
                300,
                2,
                3,
                0.08,
                0.1,
                0.25
            },
            {
                499,
                1,
                2,
                0.08,
                0.25,
                0.5
            },
            {
                500,
                0,
                0,
                1,
                0.25,
                0.25
            }
        },
        WeaponAccuracyDamper = { 3, 0.75 },
        WeaponAccuracy = {
            { 0, 3 },
            { 100, 4 },
            { 500, 6 }
        }
    }
};