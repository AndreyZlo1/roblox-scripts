-- Roblox: ReplicatedStorage.Shared.Configs.Bots.BotPresets.Mercenaries
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

game:GetService("MemoryStoreService");
return {
    Merc1_Rpg = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        NoProne = true,
        UseMotar = false,
        RadioTime = 5,
        Hidden = false,
        EquipTimer = 1,
        SecondaryDistance = 80,
        MeleeDistance = 30,
        Appearance = "MercenaryT1_Rpg",
        Fear = "MercLow",
        Rewards = {
            Base = { 100, 100 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Secondary = {
            { "AI_APS" }
        },
        Health = 100,
        Rocket = "rpg7v2",
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 150, 700 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        SprintCancel = 1000,
        Walkspeed = {
            Sprint = 13,
            Alerted = 9,
            Aware = 4,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                15
            },
            {
                1300,
                1,
                1,
                20
            }
        },
        RateOfFireSecondary = {
            {
                0,
                4,
                7,
                0.08,
                0.5,
                1
            },
            {
                80,
                4,
                5,
                0.08,
                0.5,
                1
            },
            {
                300,
                1,
                1,
                0.25
            }
        },
        WeaponAccuracyDamper = { 14, 0.2 },
        WeaponAccuracy = {
            { 0, 1 },
            { 600, 20 },
            { 1200, 30 }
        }
    },
    Merc1_Smg = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        EquipTimer = 0.2,
        NoSecondary = true,
        MeleeDistance = 4,
        Hidden = false,
        Appearance = "MercenaryT1_Smg",
        Rewards = {
            Base = { 45, 55 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Fear = "MercLow",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Health = 100,
        Weapon = {
            { "AI_MP5" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 70 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        SprintCancel = 15,
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 3.75
        },
        RateOfFire = {
            {
                0,
                6,
                8,
                0.085,
                0.25,
                0.75
            },
            {
                60,
                3,
                8,
                0.085,
                0.25,
                0.75
            },
            {
                100,
                2,
                4,
                0.085,
                0.25,
                0.75
            },
            {
                250,
                2,
                3,
                0.085,
                0.375,
                1
            },
            {
                251,
                1,
                1,
                0.1,
                0.375,
                1
            },
            {
                349,
                1,
                1,
                0.1,
                0.5,
                2
            },
            {
                350,
                0,
                0,
                1,
                0.5,
                1
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 8 },
            { 100, 7 },
            { 350, 8 }
        }
    },
    Merc1_Shotgun = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = false,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        NoSecondary = true,
        Hidden = false,
        Fear = "MercLow",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Appearance = "MercenaryT1_Shotgun",
        Health = 100,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 45, 55 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M590" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 11,
            Aware = 10,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                1,
                0.2,
                1
            },
            {
                100,
                1,
                1,
                1,
                0.25,
                1
            },
            {
                199,
                1,
                1,
                1,
                0.3,
                3
            },
            {
                200,
                0,
                0,
                0.5,
                0.05,
                0.5
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 3 },
            { 200, 10 }
        }
    },
    Merc1_Marksman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "MercenaryT1_Sniper",
        Fear = "MercLow",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 65, 75 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_SR15" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                2,
                0.08,
                0.25,
                0.5
            },
            {
                100,
                1,
                1,
                0.08,
                0.35,
                0.6
            },
            {
                200,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 6, 0.66 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Merc1_Sniper = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "MercenaryT1_Sniper",
        Fear = "MercLow",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 65, 75 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M2010" },
            { "AI_R700" }
        },
        ViewDistance = {
            Day = { 600, 800 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                1,
                1,
                0.25,
                0.5
            },
            {
                100,
                1,
                1,
                1,
                0.35,
                0.6
            },
            {
                600,
                1,
                1,
                1,
                0.5,
                2
            },
            {
                800,
                0,
                0,
                1
            }
        },
        WeaponAccuracyDamper = { 10, 0.6 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Merc1_Rifleman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "MercenaryT1_Rifleman",
        Fear = "MercLow",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 45, 55 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M4A1" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                5,
                8,
                0.08,
                0.25,
                0.5
            },
            {
                100,
                2,
                3,
                0.08,
                0.35,
                0.6
            },
            {
                200,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 10, 0.4 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Merc1_Smg_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        Hidden = false,
        EquipTimer = 0.2,
        NoSecondary = true,
        MeleeDistance = 4,
        Appearance = "MercenaryT1_Smg_Heavy",
        Rewards = {
            Base = { 55, 65 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Fear = "MercLow",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Health = 100,
        Weapon = {
            { "AI_UMP45" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 70 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        SprintCancel = 15,
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 3.75
        },
        RateOfFire = {
            {
                0,
                10,
                15,
                0.09,
                0.25,
                0.75
            },
            {
                60,
                5,
                6,
                0.09,
                0.25,
                0.75
            },
            {
                100,
                2,
                4,
                0.09,
                0.25,
                0.75
            },
            {
                250,
                2,
                3,
                0.09,
                0.375,
                1
            },
            {
                251,
                1,
                1,
                0.1,
                0.375,
                1
            },
            {
                349,
                1,
                1,
                0.1,
                0.5,
                2
            },
            {
                350,
                0,
                0,
                1,
                0.5,
                1
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 8 },
            { 100, 7 },
            { 350, 8 }
        }
    },
    Merc1_Shotgun_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = false,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        Hidden = false,
        NoSecondary = true,
        Fear = "MercLow",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Appearance = "MercenaryT1_Shotgun_Heavy",
        Health = 100,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 55, 65 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_SAIGA" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 11,
            Aware = 10,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                2,
                3,
                0.2,
                0.2,
                1
            },
            {
                100,
                1,
                1,
                0.2,
                0.25,
                1
            },
            {
                199,
                1,
                1,
                0.2,
                0.3,
                3
            },
            {
                200,
                0,
                0,
                0.2,
                0.05,
                0.5
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 3 },
            { 200, 10 }
        }
    },
    Merc1_Marksman_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "MercenaryT1_Sniper_Heavy",
        Fear = "MercLow",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 75, 80 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_SR15" }
        },
        ViewDistance = {
            Day = { 600, 800 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                1,
                0.08,
                0.25,
                0.5
            },
            {
                100,
                1,
                1,
                0.08,
                0.35,
                0.6
            },
            {
                200,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 7, 0.75 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Merc1_Sniper_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "MercenaryT1_Sniper_Heavy",
        Fear = "MercLow",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 75, 80 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_SVD" }
        },
        ViewDistance = {
            Day = { 600, 800 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                1,
                0.33,
                0.01,
                0.8
            },
            {
                400,
                1,
                1,
                0.33,
                0.5,
                1
            },
            {
                600,
                1,
                1,
                0.33,
                0.5,
                2
            }
        },
        WeaponAccuracyDamper = { 10, 0.4 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Merc1_Rifleman_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "MercenaryT1_Rifleman_Heavy",
        Fear = "MercLow",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 55, 65 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M4A1" },
            { "AI_G36" },
            { "AI_SR15" },
            { "AI_SCARL" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                3,
                4,
                0.08,
                0.25,
                0.5
            },
            {
                200,
                2,
                3,
                0.08,
                0.35,
                0.6
            },
            {
                300,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 10, 0.4 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Merc1_LMG_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "MercenaryT1_Lmg",
        Fear = "MercLow",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 70, 80 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M249" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                10,
                15,
                0.08,
                0.25,
                0.5
            },
            {
                200,
                3,
                6,
                0.08,
                0.5,
                1
            },
            {
                399,
                3,
                6,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 10, 0.4 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Merc3_Rifleman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "MercenaryT1_Rifleman_Heavy_Haz",
        Fear = "MercLow",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 55, 65 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M4A1" },
            { "AI_G36" },
            { "AI_SR15" },
            { "AI_SCARL" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                3,
                4,
                0.08,
                0.25,
                0.5
            },
            {
                200,
                2,
                3,
                0.08,
                0.35,
                0.6
            },
            {
                300,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 10, 0.4 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Merc3_Smg = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        Hidden = false,
        EquipTimer = 0.2,
        NoSecondary = true,
        MeleeDistance = 4,
        Appearance = "MercenaryT1_Smg_Heavy_Haz",
        Rewards = {
            Base = { 55, 65 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Fear = "MercLow",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Health = 100,
        Weapon = {
            { "AI_UMP45" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 70 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        SprintCancel = 15,
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 3.75
        },
        RateOfFire = {
            {
                0,
                10,
                15,
                0.09,
                0.25,
                0.75
            },
            {
                60,
                5,
                6,
                0.09,
                0.25,
                0.75
            },
            {
                100,
                2,
                4,
                0.09,
                0.25,
                0.75
            },
            {
                250,
                2,
                3,
                0.09,
                0.375,
                1
            },
            {
                251,
                1,
                1,
                0.1,
                0.375,
                1
            },
            {
                349,
                1,
                1,
                0.1,
                0.5,
                2
            },
            {
                350,
                0,
                0,
                1,
                0.5,
                1
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 8 },
            { 100, 7 },
            { 350, 8 }
        }
    },
    Merc3_Shotgun_Heavy = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = false,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        Hidden = false,
        NoSecondary = true,
        Fear = "MercLow",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Appearance = "MercenaryT1_Shotgun_Heavy_Haz",
        Health = 100,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 55, 65 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M590" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 11,
            Aware = 10,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                1,
                0.2,
                1
            },
            {
                100,
                1,
                1,
                1,
                0.25,
                1
            },
            {
                199,
                1,
                1,
                1,
                0.3,
                3
            },
            {
                200,
                0,
                0,
                1,
                0.05,
                0.5
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 3 },
            { 200, 10 }
        }
    },
    Merc2_Marksman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        HighPriority = true,
        Appearance = "MercenaryT2_Marksman",
        Fear = "MercHigh",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 30, 40 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M2010" },
            { "AI_M107A1" }
        },
        ViewDistance = {
            Day = { 300, 500 },
            Night = { 50, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                1,
                1,
                0.5,
                2
            },
            {
                600,
                1,
                1,
                1,
                0.5,
                3
            },
            {
                800,
                1,
                1,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.95 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 800, 12 }
        }
    },
    Merc2_Rifleman = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "MercenaryT2_Rifleman",
        HighPriority = true,
        Fear = "MercHigh",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 30, 40 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M4A1" },
            { "AI_HK416A5" }
        },
        ViewDistance = {
            Day = { 300, 500 },
            Night = { 50, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                2,
                3,
                0.08,
                0.25,
                0.5
            },
            {
                299,
                2,
                3,
                0.08,
                0.35,
                0.6
            },
            {
                300,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.4 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Merc2_Rifleman_Haz = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = false,
        Appearance = "MercenaryT2_Rifleman_Haz",
        HighPriority = true,
        Fear = "MercHigh",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 30, 40 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M4A1" },
            { "AI_HK416A5" }
        },
        ViewDistance = {
            Day = { 300, 500 },
            Night = { 50, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                2,
                3,
                0.08,
                0.25,
                0.5
            },
            {
                299,
                2,
                3,
                0.08,
                0.35,
                0.6
            },
            {
                300,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.4 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Insolon_Rpg_Low = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = false,
        NoProne = true,
        UseMotar = false,
        RadioTime = 5,
        Hidden = true,
        EquipTimer = 1,
        SecondaryDistance = 80,
        MeleeDistance = 30,
        Appearance = "Insolon_Low",
        Fear = "MercLow",
        Rewards = {
            Base = { 100, 100 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Secondary = {
            { "AI_APS" }
        },
        Health = 100,
        Rocket = "rpg7v2",
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 150, 700 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        SprintCancel = 1000,
        Walkspeed = {
            Sprint = 13,
            Alerted = 9,
            Aware = 4,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                15
            },
            {
                1300,
                1,
                1,
                20
            }
        },
        RateOfFireSecondary = {
            {
                0,
                4,
                7,
                0.08,
                0.5,
                1
            },
            {
                80,
                4,
                5,
                0.08,
                0.5,
                1
            },
            {
                300,
                1,
                1,
                0.25
            }
        },
        WeaponAccuracyDamper = { 14, 0.2 },
        WeaponAccuracy = {
            { 0, 1 },
            { 600, 20 },
            { 1200, 30 }
        }
    },
    Insolon_Smg_Low = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        EquipTimer = 0.2,
        NoSecondary = true,
        MeleeDistance = 4,
        Hidden = true,
        Appearance = "Insolon_Low",
        Rewards = {
            Base = { 45, 55 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Fear = "MercLow",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Health = 100,
        Weapon = {
            { "AI_PP19" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        ProneMultiplier = 0.33,
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTimeMultiplier = 1.25,
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 70 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        SprintCancel = 15,
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 12,
            Idle = 3.75
        },
        RateOfFire = {
            {
                0,
                10,
                15,
                0.085,
                0.25,
                0.75
            },
            {
                60,
                5,
                6,
                0.085,
                0.25,
                0.75
            },
            {
                100,
                2,
                4,
                0.085,
                0.25,
                0.75
            },
            {
                250,
                2,
                3,
                0.085,
                0.375,
                1
            },
            {
                251,
                1,
                1,
                0.1,
                0.375,
                1
            },
            {
                349,
                1,
                1,
                0.1,
                0.5,
                2
            },
            {
                350,
                0,
                0,
                1,
                0.5,
                1
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 8 },
            { 100, 7 },
            { 350, 8 }
        }
    },
    Insolon_Shotgun_Low = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = false,
        UseMG = true,
        UseMotar = true,
        RadioTime = 5,
        NoSecondary = true,
        Hidden = true,
        Fear = "MercLow",
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        Appearance = "Insolon_Low",
        Health = 100,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        DetectionFearMultiplier = 0.35,
        DetectionAlertedMultiplier = 0.2,
        DetectionTargetKnownMultiplier = 0.1,
        Rewards = {
            Base = { 45, 55 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M590" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 16,
            Alerted = 11,
            Aware = 10,
            Idle = 5
        },
        RateOfFire = {
            {
                0,
                1,
                1,
                1,
                0.2,
                1
            },
            {
                100,
                1,
                1,
                1,
                0.25,
                1
            },
            {
                199,
                1,
                1,
                1,
                0.3,
                3
            },
            {
                200,
                0,
                0,
                0.5,
                0.05,
                0.5
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.5 },
        WeaponAccuracy = {
            { 0, 3 },
            { 200, 10 }
        }
    },
    Insolon_Marksman_Low = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = true,
        Appearance = "Insolon_Low",
        Fear = "MercLow",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 65, 75 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_SR15" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                2,
                0.08,
                0.25,
                0.5
            },
            {
                100,
                1,
                1,
                0.08,
                0.35,
                0.6
            },
            {
                200,
                1,
                1,
                0.08,
                0.5,
                1
            },
            {
                399,
                1,
                1,
                0.08,
                0.5,
                2
            },
            {
                400,
                0,
                0,
                0.5
            }
        },
        WeaponAccuracyDamper = { 6, 0.66 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Insolon_Sniper_Low = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = true,
        Appearance = "Insolon_Low",
        Fear = "MercLow",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 1.5,
        SprintCancel = 40,
        Rewards = {
            Base = { 65, 75 },
            Headshot = { 10, 10 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_M2010" },
            { "AI_R700" }
        },
        ViewDistance = {
            Day = { 600, 800 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                1,
                1,
                1,
                1,
                0.25,
                0.5
            },
            {
                100,
                1,
                1,
                1,
                0.35,
                0.6
            },
            {
                600,
                1,
                1,
                1,
                0.5,
                2
            },
            {
                800,
                0,
                0,
                1
            }
        },
        WeaponAccuracyDamper = { 10, 0.6 },
        WeaponAccuracy = {
            { 0, 12 },
            { 50, 10 },
            { 400, 12 }
        }
    },
    Insolon_Rifleman_Low = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        UseMG = true,
        RadioTime = 3,
        EquipTimer = 0.3,
        Hidden = true,
        Appearance = "Insolon_Low",
        Fear = "MercLow",
        Health = 90,
        ProneMultiplier = 0.9,
        RadioRadius = 200,
        LocalTalkRadius = 50,
        InvestigationRadius = 130,
        DetectionTimeMultiplier = 2,
        SprintCancel = 100,
        Rewards = {
            Base = { 45, 55 },
            Headshot = { 5, 5 },
            Stealth = { 5, 5 }
        },
        Weapon = {
            { "AI_AK" }
        },
        ViewDistance = {
            Day = { 300, 600 },
            Night = { 50, 150 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.5
        },
        FieldOfView = {
            Day = {
                { 60, 80 },
                { 50, 70 }
            },
            Night = {
                { 40, 70 },
                { 30, 60 }
            }
        },
        DetectionTime = {
            { 0, 1 },
            { 200, 4 },
            { 600, 6 }
        },
        ShotDetectionRange = { 30, 250, 150 },
        PathableDistance = { 15, 100 },
        TargetCooldown = {
            SearchLastSeen = 30,
            ReturnHome = 45
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 18,
            Aware = 12,
            Idle = 3
        },
        RateOfFire = {
            {
                0,
                3,
                15,
                0.09375,
                0.25,
                1
            },
            {
                50,
                3,
                15,
                0.09375,
                0.25,
                1
            },
            {
                100,
                2,
                6,
                0.09375,
                0.15,
                0.66
            },
            {
                200,
                1,
                1,
                0.09375,
                0.25,
                1
            },
            {
                400,
                1,
                1,
                0.1,
                0.1,
                0.5
            }
        },
        WeaponAccuracyDamper = { 5, 0.7 },
        WeaponAccuracy = {
            { 0, 13 },
            { 50, 15 },
            { 100, 5 },
            { 600, 10 }
        }
    },
    Insolon_VIP = {
        Behaviour = "Combat",
        IsFriendly = false,
        UseCover = true,
        RadioTime = 4,
        EquipTimer = 1,
        Appearance = "Insolon_VIP",
        Fear = "POD",
        SecondaryDistance = 600,
        Health = 125,
        Hidden = true,
        ProneMultiplier = 0.33,
        DetectionTimeMultiplier = 1.25,
        SprintCancel = 15,
        Rewards = {
            Base = { 100, 50 },
            Headshot = { 10, 5 },
            Stealth = { 50, 255 }
        },
        Weapon = {
            { "AI_SCARL" }
        },
        ViewDistance = {
            Day = { 400, 600 },
            Night = { 60, 400 }
        },
        FogMultiplier = {
            ViewDistance = 0.5,
            FieldOfView = 0.75
        },
        FieldOfView = {
            Day = {
                { 70, 80 },
                { 50, 50 }
            },
            Night = {
                { 60, 60 },
                { 40, 50 }
            }
        },
        DetectionTime = {
            { 0, 0.25 },
            { 100, 3 },
            { 300, 6 },
            { 600, 8 }
        },
        ShotDetectionRange = { 30, 700, 130 },
        PathableDistance = { 50, 1000 },
        TargetCooldown = {
            SearchLastSeen = 90,
            ReturnHome = 160
        },
        Walkspeed = {
            Sprint = 17,
            Alerted = 14,
            Aware = 8,
            Idle = 4
        },
        RateOfFire = {
            {
                0,
                8,
                15,
                0.08,
                0.35,
                0.5
            },
            {
                20,
                5,
                10,
                0.08,
                0.35,
                0.5
            },
            {
                100,
                2,
                3,
                0.08,
                0.35,
                0.5
            },
            {
                300,
                1,
                2,
                0.08,
                0.35,
                0.5
            },
            {
                301,
                0,
                0,
                1,
                0.35,
                0.5
            }
        },
        WeaponAccuracyDamper = { 7.5, 0.25 },
        WeaponAccuracy = {
            { 0, 6 },
            { 20, 4 },
            { 50, 8 },
            { 350, 10 }
        }
    }
};