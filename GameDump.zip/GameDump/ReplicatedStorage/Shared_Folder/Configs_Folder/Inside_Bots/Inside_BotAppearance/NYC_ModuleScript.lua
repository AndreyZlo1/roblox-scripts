-- Roblox: ReplicatedStorage.Shared.Configs.Bots.BotAppearance.NYC
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Bandit_Low = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIPoloRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack"
                        },
                        Pants = {
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsGreen",
                            "AIPantsLightGrey"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Bandit_Pistol = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIPoloRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack"
                        },
                        Pants = {
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsGreen",
                            "AIPantsLightGrey"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Bandit_Sniper = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIPoloRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack"
                        },
                        Pants = {
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsGreen",
                            "AIPantsLightGrey"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Bandit_Smg = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIPoloRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack"
                        },
                        Pants = {
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsGreen",
                            "AIPantsLightGrey"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Bandit_Rifleman = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "Bandit_JacketBlack",
                            "Bandit_JacketRed",
                            "Bandit_JacketGreen",
                            "Bandit_JacketGrey",
                            "Bandit_JacketOrange",
                            "Bandit_JacketBlack",
                            "Bandit_PufferGrey",
                            "Bandit_PufferGreen",
                            "Bandit_PufferRed",
                            "Bandit_PufferBlue",
                            "Bandit_PufferBlueDark",
                            "Bandit_PufferBlack"
                        },
                        Pants = {
                            "Bandit_Jeans1",
                            "Bandit_Jeans2",
                            "Bandit_Trouser1",
                            "Bandit_Trouser2",
                            "Bandit_Trouser3",
                            "Bandit_Trouser4",
                            "Bandit_Trouser5",
                            "Bandit_Trouser6"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Beanie2"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Beanie2"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_CapF"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditB"
                            },
                            {
                                Camo = "White"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_CapF"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Backpack = {
                            {
                                "Character",
                                "Backpack",
                                "Backpack",
                                "AI_8005"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Bandit_Shotgun = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "Bandit_ShirtButton1",
                            "Bandit_ShirtButton2",
                            "Bandit_ShirtButton3",
                            "Bandit_ShirtButton4",
                            "Bandit_Shirt1",
                            "Bandit_Shirt2",
                            "Bandit_Shirt3",
                            "Bandit_Shirt4",
                            "Bandit_Shirt5"
                        },
                        Pants = {
                            "Bandit_Jeans1",
                            "Bandit_Jeans2",
                            "Bandit_Trouser1",
                            "Bandit_Trouser2",
                            "Bandit_Trouser3",
                            "Bandit_Trouser4",
                            "Bandit_Trouser5",
                            "Bandit_Trouser6"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Bandit_Sniper_Heavy = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIPoloRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack"
                        },
                        Pants = {
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsGreen",
                            "AIPantsLightGrey"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Bandit_Smg_Heavy = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIPoloRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack"
                        },
                        Pants = {
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsGreen",
                            "AIPantsLightGrey"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Bandit_Rifleman_Heavy = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIPoloRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack"
                        },
                        Pants = {
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsGreen",
                            "AIPantsLightGrey"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Bandit_Shotgun_Heavy = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIPoloRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack"
                        },
                        Pants = {
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsGreen",
                            "AIPantsLightGrey"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Sheepdog_Low = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    },
                    {
                        Shirt = { "BattleDressUniform_NavyBlue" },
                        Pants = { "501OriginalFit_StoneWashedDenimGrayDyed", "501OriginalFit_StoneWashedDenim" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Sheepdog_Pistol = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    },
                    {
                        Shirt = { "BattleDressUniform_NavyBlue" },
                        Pants = { "501OriginalFit_StoneWashedDenimGrayDyed", "501OriginalFit_StoneWashedDenim" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC"
                            },
                            {
                                Camo = "Varicam"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Sheepdog_Rifleman = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    },
                    {
                        Shirt = { "G3Field_VariCam", "G3Combat_VariCam", "ACU2004_UCP" },
                        Pants = { "G3Field_VariCam", "G3Combat_VariCam" }
                    },
                    {
                        Shirt = { "BattleDressUniform_NavyBlue" },
                        Pants = { "501OriginalFit_StoneWashedDenimGrayDyed", "501OriginalFit_StoneWashedDenim" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_SD_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Beanie2"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_SD_RiflemanA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_CapF"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterHigh"
                            },
                            {
                                Camo = "Tan"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Sheepdog_Smg = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    },
                    {
                        Shirt = { "G3Field_VariCam", "G3Combat_VariCam", "ACU2004_UCP" },
                        Pants = { "G3Field_VariCam", "G3Combat_VariCam" }
                    },
                    {
                        Shirt = { "BattleDressUniform_NavyBlue" },
                        Pants = { "501OriginalFit_StoneWashedDenimGrayDyed", "501OriginalFit_StoneWashedDenim" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_Flap"
                            },
                            {
                                Camo = "Varicam"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_CapF"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_Flap"
                            },
                            {
                                Camo = "Varicam"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Beanie2"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Sheepdog_Shotgun = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    },
                    {
                        Shirt = { "G3Field_VariCam", "G3Combat_VariCam", "ACU2004_UCP" },
                        Pants = { "G3Field_VariCam", "G3Combat_VariCam" }
                    },
                    {
                        Shirt = { "BattleDressUniform_NavyBlue" },
                        Pants = { "501OriginalFit_StoneWashedDenimGrayDyed", "501OriginalFit_StoneWashedDenim" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Sheepdog_Sniper = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    },
                    {
                        Shirt = { "G3Field_VariCam", "G3Combat_VariCam" },
                        Pants = { "G3Field_VariCam", "G3Combat_VariCam" }
                    },
                    {
                        Shirt = { "BattleDressUniform_NavyBlue" },
                        Pants = { "501OriginalFit_StoneWashedDenimGrayDyed", "501OriginalFit_StoneWashedDenim" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Sheepdog_Rifleman_Heavy = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    },
                    {
                        Shirt = { "G3Field_VariCam", "G3Combat_VariCam" },
                        Pants = { "G3Field_VariCam", "G3Combat_VariCam" }
                    },
                    {
                        Shirt = { "BattleDressUniform_NavyBlue" },
                        Pants = { "501OriginalFit_StoneWashedDenimGrayDyed", "501OriginalFit_StoneWashedDenim" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Sheepdog_Smg_Heavy = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    },
                    {
                        Shirt = { "G3Field_VariCam", "G3Combat_VariCam" },
                        Pants = { "G3Field_VariCam", "G3Combat_VariCam" }
                    },
                    {
                        Shirt = { "BattleDressUniform_NavyBlue" },
                        Pants = { "501OriginalFit_StoneWashedDenimGrayDyed", "501OriginalFit_StoneWashedDenim" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Sheepdog_Shotgun_Heavy = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    },
                    {
                        Shirt = { "G3Field_VariCam", "G3Combat_VariCam" },
                        Pants = { "G3Field_VariCam", "G3Combat_VariCam" }
                    },
                    {
                        Shirt = { "BattleDressUniform_NavyBlue" },
                        Pants = { "501OriginalFit_StoneWashedDenimGrayDyed", "501OriginalFit_StoneWashedDenim" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Sheepdog_Sniper_Heavy = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    },
                    {
                        Shirt = { "G3Field_VariCam", "G3Combat_VariCam" },
                        Pants = { "G3Field_VariCam", "G3Combat_VariCam" }
                    },
                    {
                        Shirt = { "BattleDressUniform_NavyBlue" },
                        Pants = { "501OriginalFit_StoneWashedDenimGrayDyed", "501OriginalFit_StoneWashedDenim" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Sheepdog_Lmg = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    },
                    {
                        Shirt = { "G3Field_VariCam", "G3Combat_VariCam" },
                        Pants = { "G3Field_VariCam", "G3Combat_VariCam" }
                    },
                    {
                        Shirt = { "BattleDressUniform_NavyBlue" },
                        Pants = { "501OriginalFit_StoneWashedDenimGrayDyed", "501OriginalFit_StoneWashedDenim" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Kismet_HQ = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "APCRapidLongSleeveShirt_Storm" },
                        Pants = { "APCCargoPant_Storm" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Kismet_VIP = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "PACERugbyLongSleeve_WolfGrey" },
                        Pants = { "501OriginalFit_StoneWashedDenim", "501OriginalFit_StoneWashedDenimGrayDyed", "501OriginalFit_StoneWashedDenimGreenDyed" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC"
                            },
                            {
                                Camo = "Black"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "Beret"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Eyewear = {
                            {
                                "Character",
                                "Eyewear",
                                "Eyewear",
                                "Aviators"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Kismet_Rifleman = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "APCRapidLongSleeveShirt_Storm" },
                        Pants = { "APCCargoPant_Storm" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Kismet_Shotgun = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "APCRapidLongSleeveShirt_Storm" },
                        Pants = { "APCCargoPant_Storm" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Kismet_Smg = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "APCRapidLongSleeveShirt_Storm" },
                        Pants = { "APCCargoPant_Storm" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Kismet_Sniper = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "APCRapidLongSleeveShirt_Storm" },
                        Pants = { "APCCargoPant_Storm" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Kismet_Lmg = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "APCRapidLongSleeveShirt_Storm" },
                        Pants = { "APCCargoPant_Storm" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Kismet_Rpg = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "APCRapidLongSleeveShirt_Storm" },
                        Pants = { "APCCargoPant_Storm" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Kismet_Rifleman_Haz = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72),
                    Color3.fromRGB(102, 68, 52)
                },
                Clothes = {
                    {
                        Shirt = { "APCRapidLongSleeveShirt_Storm" },
                        Pants = { "APCCargoPant_Storm" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Kismet_Shotgun_Haz = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "APCRapidLongSleeveShirt_Storm" },
                        Pants = { "APCCargoPant_Storm" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Kismet_Smg_Haz = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "APCRapidLongSleeveShirt_Storm" },
                        Pants = { "APCCargoPant_Storm" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Kismet_Lmg_Haz = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "APCRapidLongSleeveShirt_Storm" },
                        Pants = { "APCCargoPant_Storm" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Gray"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Zombie_Civilian = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = { "ZombieWheeze" },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack",
                            "AIButtonUpShirtBlack",
                            "AIButtonUpShirtBlue",
                            "AIButtonUpShirtNavyBlue",
                            "AIButtonUpShirtGrey",
                            "AIButtonUpShirtRed",
                            "AIButtonUpShirtGreen"
                        },
                        Pants = {
                            "AIPantsKhaki",
                            "AIPantsBlack",
                            "AIPantsGrey",
                            "AIPantsLightGrey",
                            "AIPantsBlue",
                            "AIPantsGreen",
                            "AIJeansBlueWorn",
                            "AIJeansBlue",
                            "AIJeansDarkBlueWorn",
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansDarkGrey",
                            "AIJeansBlack"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(177, 142, 78)
                    },
                    Boots = {
                        { "Character", "Boots", "Generic" },
                        {},
                        {}
                    }
                }
            }
        }
    },
    Zombie_Survivor = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = { "ZombieWheeze" },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack",
                            "AIButtonUpShirtBlack",
                            "AIButtonUpShirtBlue",
                            "AIButtonUpShirtNavyBlue",
                            "AIButtonUpShirtGrey",
                            "AIButtonUpShirtRed",
                            "AIButtonUpShirtGreen"
                        },
                        Pants = {
                            "AIPantsKhaki",
                            "AIPantsBlack",
                            "AIPantsGrey",
                            "AIPantsLightGrey",
                            "AIPantsBlue",
                            "AIPantsGreen",
                            "AIJeansBlueWorn",
                            "AIJeansBlue",
                            "AIJeansDarkBlueWorn",
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansDarkGrey",
                            "AIJeansBlack"
                        }
                    }
                },
                Gear = {
                    {
                        {
                            Hair = "Default",
                            HairColor = Color3.fromRGB(177, 142, 78)
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Zombie_Construction = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = { "ZombieWheeze" },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack",
                            "AIButtonUpShirtBlack",
                            "AIButtonUpShirtBlue",
                            "AIButtonUpShirtNavyBlue",
                            "AIButtonUpShirtGrey",
                            "AIButtonUpShirtRed",
                            "AIButtonUpShirtGreen"
                        },
                        Pants = {
                            "AIPantsKhaki",
                            "AIPantsBlack",
                            "AIPantsGrey",
                            "AIPantsLightGrey",
                            "AIPantsBlue",
                            "AIPantsGreen",
                            "AIJeansBlueWorn",
                            "AIJeansBlue",
                            "AIJeansDarkBlueWorn",
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansDarkGrey",
                            "AIJeansBlack"
                        }
                    }
                },
                Gear = {
                    {
                        {
                            Hair = "Default",
                            HairColor = Color3.fromRGB(177, 142, 78)
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "HighVisVest"
                            },
                            {
                                Camo = "Green"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Beanie2"
                            },
                            {
                                Camo = "Default"
                            }
                        }
                    },
                    {
                        {
                            Hair = "Default",
                            HairColor = Color3.fromRGB(177, 142, 78)
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "HardHat"
                            },
                            {
                                Camo = "Yellow"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "HighVisVest"
                            },
                            {
                                Camo = "Yellow"
                            }
                        }
                    },
                    {
                        {
                            Hair = "Default",
                            HairColor = Color3.fromRGB(177, 142, 78)
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "HardHat"
                            },
                            {
                                Camo = "White"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "HighVisVest"
                            },
                            {
                                Camo = "Default"
                            }
                        }
                    },
                    {
                        {
                            Hair = "Default",
                            HairColor = Color3.fromRGB(177, 142, 78)
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "HardHat"
                            },
                            {
                                Camo = "Blue"
                            }
                        }
                    }
                }
            }
        }
    },
    Zombie_Paramedic = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = { "ZombieWheeze" },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack",
                            "AIButtonUpShirtBlack",
                            "AIButtonUpShirtBlue",
                            "AIButtonUpShirtNavyBlue",
                            "AIButtonUpShirtGrey",
                            "AIButtonUpShirtRed",
                            "AIButtonUpShirtGreen"
                        },
                        Pants = {
                            "AIPantsKhaki",
                            "AIPantsBlack",
                            "AIPantsGrey",
                            "AIPantsLightGrey",
                            "AIPantsBlue",
                            "AIPantsGreen",
                            "AIJeansBlueWorn",
                            "AIJeansBlue",
                            "AIJeansDarkBlueWorn",
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansDarkGrey",
                            "AIJeansBlack"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(177, 142, 78)
                    },
                    Boots = {
                        { "Character", "Boots", "Generic" },
                        {},
                        {}
                    }
                }
            }
        }
    },
    Zombie_Police = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = { "ZombieWheeze" },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "APCRapidLongSleeveShirt_DarkNavy" },
                        Pants = { "APCCargoPant_DarkNavy" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(177, 142, 78)
                    },
                    Boots = {
                        { "Character", "Boots", "Generic" },
                        {},
                        {}
                    },
                    Helmet = {
                        {
                            "Character",
                            "Helmet",
                            "Helmet",
                            "PoliceCap"
                        }
                    },
                    Vest = {
                        {
                            "Character",
                            "Vest",
                            "Vest",
                            "PoliceLowVisVest"
                        },
                        {
                            Camo = "Default"
                        }
                    }
                }
            }
        }
    },
    Zombie_Bandit = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = { "ZombieWheeze" },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "Bandit_JacketBlack",
                            "Bandit_JacketRed",
                            "Bandit_JacketGreen",
                            "Bandit_JacketGrey",
                            "Bandit_JacketOrange",
                            "Bandit_JacketBlack",
                            "Bandit_PufferGrey",
                            "Bandit_PufferGreen",
                            "Bandit_PufferRed",
                            "Bandit_PufferBlue",
                            "Bandit_PufferBlueDark",
                            "Bandit_PufferBlack"
                        },
                        Pants = {
                            "Bandit_Jeans1",
                            "Bandit_Jeans2",
                            "Bandit_Trouser1",
                            "Bandit_Trouser2",
                            "Bandit_Trouser3",
                            "Bandit_Trouser4",
                            "Bandit_Trouser5",
                            "Bandit_Trouser6"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Beanie2"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Beanie2"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_CapF"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditB"
                            },
                            {
                                Camo = "White"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_CapF"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Backpack = {
                            {
                                "Character",
                                "Backpack",
                                "Backpack",
                                "AI_8005"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Zombie_Sheepdog = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = { "ZombieWheeze" },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal",
                            "BattleDressUniform_Khaki",
                            "G3Field_VariCam",
                            "PACERugbyLongSleeve_VariCam"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_SD_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Beanie2"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_SD_RiflemanA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_CapF"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterHigh"
                            },
                            {
                                Camo = "Tan"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Zombie_Military = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = { "ZombieWheeze" },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "BattleDressUniform_USWoodland" },
                        Pants = { "BattleDressUniform_USWoodland" }
                    },
                    {
                        Shirt = { "G3Field_VariCam" },
                        Pants = { "G3Field_VariCam" }
                    },
                    {
                        Shirt = { "G3Combat_USWoodland" },
                        Pants = { "G3Combat_USWoodland" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC"
                            },
                            {
                                Camo = "Varicam"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Beanie2"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_Flap"
                            },
                            {
                                Camo = "Varicam"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    UNIDB_HeliCrew = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "G3Field_RangerGreen",
                            "PACERugbyLongSleeve_WolfGrey",
                            "PACERugbyLongSleeve_CoyoteBrown",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = { "G3Combat_RangerGreen", "G3Field_RangerGreen" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        FacialHair = "BeardNarrow2",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "HGU56P"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "RangerGreen"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "Nomex_Flight" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        FacialHair = "BeardNarrow2",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "HGU56P"
                            },
                            {
                                Camo = "FoliageGreen504"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "RangerGreen"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "GG_GunGlove" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "HGU56P"
                            },
                            {
                                Camo = "FoliageGreen504"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_AVS"
                            },
                            {
                                Camo = "RangerGreen"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "SDK_PigAlpha" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    }
};