-- Roblox: ReplicatedStorage.Shared.Configs.Bots.BotAppearance.Islands
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Militia_Rifleman = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIPoloRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack"
                        },
                        Pants = {
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsGreen",
                            "AIPantsLightGrey"
                        }
                    },
                    {
                        Shirt = {
                            "AIButtonUpShirtNavyBlue",
                            "AIShirtRed",
                            "AIShirtWhite",
                            "AIButtonUpShirtGrey",
                            "AIButtonUpShirtBlue",
                            "AIButtonUpShirtBlack",
                            "AIShirtBlack",
                            "AIFlannelGray",
                            "AIFlannelRed"
                        },
                        Pants = {
                            "AIJeansDarkGrey",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsKhaki",
                            "AIPantsGrey",
                            "AIPantsLightGrey",
                            "AIPantsGreen"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(177, 142, 78),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_Chicom"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Beanie"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FaceCover"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_SuspenderLight"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FaceCover"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_Chicom"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FaceCover"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(196, 167, 113),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_Chicom"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FaceCover"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {
                                Camo = "Tan"
                            },
                            {}
                        }
                    }
                }
            }
        }
    },
    Militia_RiflemanHeavy = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIPoloRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack"
                        },
                        Pants = {
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsGreen",
                            "AIPantsLightGrey"
                        }
                    },
                    {
                        Shirt = {
                            "AIButtonUpShirtNavyBlue",
                            "AIShirtRed",
                            "AIShirtWhite",
                            "AIButtonUpShirtGrey",
                            "AIButtonUpShirtBlue",
                            "AIButtonUpShirtBlack",
                            "AIShirtBlack",
                            "AIFlannelGray",
                            "AIFlannelRed"
                        },
                        Pants = {
                            "AIJeansDarkGrey",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsKhaki",
                            "AIPantsGrey",
                            "AIPantsLightGrey",
                            "AIPantsGreen"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(196, 167, 113),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B2"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_6B26"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FaceCover"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B2"
                            },
                            {
                                Camo = "Woodland"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Ssh68"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FaceCover"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {
                                Camo = "Tan"
                            },
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(196, 167, 113),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B3"
                            },
                            {
                                Camo = "Woodland"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Ssh68"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FaceCover"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Militia_Smg = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIPoloRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack"
                        },
                        Pants = {
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsGreen",
                            "AIPantsLightGrey"
                        }
                    },
                    {
                        Shirt = {
                            "AIButtonUpShirtNavyBlue",
                            "AIShirtRed",
                            "AIShirtWhite",
                            "AIButtonUpShirtGrey",
                            "AIButtonUpShirtBlue",
                            "AIButtonUpShirtBlack",
                            "AIShirtBlack",
                            "AIFlannelGray",
                            "AIFlannelRed"
                        },
                        Pants = {
                            "AIJeansDarkGrey",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsKhaki",
                            "AIPantsGrey",
                            "AIPantsLightGrey",
                            "AIPantsGreen"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_SuspenderHeavy"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Beanie"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FaceCover"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_Chicom"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FaceCover"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {
                                Camo = "Tan"
                            },
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(196, 167, 113),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B2M"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Beanie"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "Vkbo"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(196, 167, 113),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_Chicom"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FaceCover"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Militia_Sniper = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack"
                        },
                        Pants = {
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsGreen",
                            "AIPantsLightGrey"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_Chicom"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Boonie"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FaceCover"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {
                                Camo = "Tan"
                            },
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_SuspenderSniper"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Boonie"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "Vkbo"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Militia_Commander = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIPoloRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack"
                        },
                        Pants = {
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsGreen",
                            "AIPantsLightGrey"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_SuspenderCommander"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FieldCap"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_SuspenderCommander"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FieldCap"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Militia_Rpg = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIPoloRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack"
                        },
                        Pants = {
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsGreen",
                            "AIPantsLightGrey"
                        }
                    },
                    {
                        Shirt = {
                            "AIButtonUpShirtNavyBlue",
                            "AIShirtRed",
                            "AIShirtWhite",
                            "AIButtonUpShirtGrey",
                            "AIButtonUpShirtBlue",
                            "AIButtonUpShirtBlack",
                            "AIShirtBlack",
                            "AIFlannelGray",
                            "AIFlannelRed"
                        },
                        Pants = {
                            "AIJeansDarkGrey",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsKhaki",
                            "AIPantsGrey",
                            "AIPantsLightGrey",
                            "AIPantsGreen"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B3_Rpg"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Beanie"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "Vkbo"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B3_Rpg"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FaceCover"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {
                                Camo = "Tan"
                            },
                            {}
                        }
                    }
                }
            }
        }
    },
    Militia_Heavy = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIPoloRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack"
                        },
                        Pants = {
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsGreen",
                            "AIPantsLightGrey"
                        }
                    },
                    {
                        Shirt = {
                            "AIButtonUpShirtNavyBlue",
                            "AIShirtRed",
                            "AIShirtWhite",
                            "AIButtonUpShirtGrey",
                            "AIButtonUpShirtBlue",
                            "AIButtonUpShirtBlack",
                            "AIShirtBlack",
                            "AIFlannelGray",
                            "AIFlannelRed"
                        },
                        Pants = {
                            "AIJeansDarkGrey",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsKhaki",
                            "AIPantsGrey",
                            "AIPantsLightGrey",
                            "AIPantsGreen"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B3M"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_6B26"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "Vkbo"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {
                                Camo = "Tan"
                            },
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B2M"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_6B27"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FaceCover"
                            },
                            {
                                Camo = "Desert"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B3M"
                            },
                            {
                                Camo = "Woodland"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_6B26"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FaceCover"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    }
};