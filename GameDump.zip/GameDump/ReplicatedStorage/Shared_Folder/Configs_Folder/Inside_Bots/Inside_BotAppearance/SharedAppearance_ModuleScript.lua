-- Roblox: ReplicatedStorage.Shared.Configs.Bots.BotAppearance.SharedAppearance
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    FAI_Rifleman = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "G3Field_VariCam",
                            "PACERugby_RangerGreen",
                            "PACERugby_CoyoteBrown",
                            "PACERugbyLongSleeve_EarthTan"
                        },
                        Pants = {
                            "G3Combat_VariCam",
                            "G3Field_VariCam",
                            "G3Field_RangerGreen",
                            "BattleDressUniform_Khaki"
                        }
                    },
                    {
                        Shirt = {
                            "G3Combat_VariCam",
                            "PACERugby_RangerGreen",
                            "PACERugby_CoyoteBrown",
                            "PACERugbyLongSleeve_EarthTan"
                        },
                        Pants = { "G3Combat_VariCam", "G3Field_VariCam", "BattleDressUniform_Khaki" }
                    },
                    {
                        Shirt = { "G3Combat_USWoodland", "BattleDressUniform_USWoodland" },
                        Pants = {
                            "G3Combat_USWoodland",
                            "BattleDressUniform_USWoodland",
                            "501OriginalFit_StoneWashedDenimGreenDyed",
                            "SpecterAWGen2_BrownGrey"
                        }
                    },
                    {
                        Shirt = { "G3Combat_USWoodland" },
                        Pants = { "G3Combat_USWoodland", "G3Field_RangerGreen" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        FacialHair = "BeardNarrow2",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "ACH"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "MICH2000"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        }
                    }
                }
            }
        }
    },
    FAI_Pilot = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "G3Field_VariCam",
                            "PACERugby_RangerGreen",
                            "PACERugby_CoyoteBrown",
                            "PACERugbyLongSleeve_EarthTan"
                        },
                        Pants = {
                            "G3Combat_VariCam",
                            "G3Field_VariCam",
                            "G3Field_RangerGreen",
                            "BattleDressUniform_Khaki"
                        }
                    },
                    {
                        Shirt = {
                            "G3Combat_VariCam",
                            "PACERugby_RangerGreen",
                            "PACERugby_CoyoteBrown",
                            "PACERugbyLongSleeve_EarthTan"
                        },
                        Pants = { "G3Combat_VariCam", "G3Field_VariCam", "BattleDressUniform_Khaki" }
                    },
                    {
                        Shirt = { "G3Combat_USWoodland", "BattleDressUniform_USWoodland" },
                        Pants = {
                            "G3Combat_USWoodland",
                            "BattleDressUniform_USWoodland",
                            "501OriginalFit_StoneWashedDenimGreenDyed",
                            "SpecterAWGen2_BrownGrey"
                        }
                    },
                    {
                        Shirt = { "G3Combat_USWoodland" },
                        Pants = { "G3Combat_USWoodland", "G3Field_RangerGreen" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        FacialHair = "BeardNarrow2",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        FacialHair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "ACH"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "MICH2000"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        }
                    }
                }
            }
        }
    },
    FAI_Gunner = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "G3Field_VariCam",
                            "PACERugby_RangerGreen",
                            "PACERugby_CoyoteBrown",
                            "PACERugbyLongSleeve_EarthTan"
                        },
                        Pants = {
                            "G3Combat_VariCam",
                            "G3Field_VariCam",
                            "G3Field_RangerGreen",
                            "BattleDressUniform_Khaki"
                        }
                    },
                    {
                        Shirt = {
                            "G3Combat_VariCam",
                            "PACERugby_RangerGreen",
                            "PACERugby_CoyoteBrown",
                            "PACERugbyLongSleeve_EarthTan"
                        },
                        Pants = { "G3Combat_VariCam", "G3Field_VariCam", "BattleDressUniform_Khaki" }
                    },
                    {
                        Shirt = { "G3Combat_USWoodland", "BattleDressUniform_USWoodland" },
                        Pants = {
                            "G3Combat_USWoodland",
                            "BattleDressUniform_USWoodland",
                            "501OriginalFit_StoneWashedDenimGreenDyed",
                            "SpecterAWGen2_BrownGrey"
                        }
                    },
                    {
                        Shirt = { "G3Combat_USWoodland" },
                        Pants = { "G3Combat_USWoodland", "G3Field_RangerGreen" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        FacialHair = "BeardNarrow2",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        FacialHair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "ACH"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "MICH2000"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        }
                    }
                }
            }
        }
    },
    FAI_CrewChief = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "G3Field_VariCam",
                            "PACERugby_RangerGreen",
                            "PACERugby_CoyoteBrown",
                            "PACERugbyLongSleeve_EarthTan"
                        },
                        Pants = {
                            "G3Combat_VariCam",
                            "G3Field_VariCam",
                            "G3Field_RangerGreen",
                            "BattleDressUniform_Khaki"
                        }
                    },
                    {
                        Shirt = {
                            "G3Combat_VariCam",
                            "PACERugby_RangerGreen",
                            "PACERugby_CoyoteBrown",
                            "PACERugbyLongSleeve_EarthTan"
                        },
                        Pants = { "G3Combat_VariCam", "G3Field_VariCam", "BattleDressUniform_Khaki" }
                    },
                    {
                        Shirt = { "G3Combat_USWoodland", "BattleDressUniform_USWoodland" },
                        Pants = {
                            "G3Combat_USWoodland",
                            "BattleDressUniform_USWoodland",
                            "501OriginalFit_StoneWashedDenimGreenDyed",
                            "SpecterAWGen2_BrownGrey"
                        }
                    },
                    {
                        Shirt = { "G3Combat_USWoodland" },
                        Pants = { "G3Combat_USWoodland", "G3Field_RangerGreen" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        FacialHair = "BeardNarrow2",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        FacialHair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "ACH"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "MICH2000"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        }
                    }
                }
            }
        }
    },
    FAI_HQ = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = { "AU_Darcy", "AU_J" },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "G3Field_VariCam", "G3Combat_VariCam", "PACERugbyLongSleeve_CoyoteBrown" },
                        Pants = { "G3Combat_VariCam", "G3Field_VariCam", "SpecterAWGen2_CoyoteBrown" }
                    },
                    {
                        Shirt = { "G3Combat_VariCam", "G3Field_VariCam", "PACERugby_CoyoteBrown" },
                        Pants = { "G3Combat_VariCam", "G3Field_VariCam", "BattleDressUniform_Khaki" }
                    },
                    {
                        Shirt = { "G3Combat_USWoodland", "BattleDressUniform_USWoodland" },
                        Pants = { "G3Combat_USWoodland", "SpecterAWGen2_CoyoteBrown", "BattleDressUniform_OliveDrabGreen" }
                    },
                    {
                        Shirt = { "G3Combat_USWoodland", "PACERugby_CoyoteBrown" },
                        Pants = { "G3Combat_USWoodland", "SpecterAWGen2_CoyoteBrown", "BattleDressUniform_OliveDrabGreen" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        FacialHair = "BeardNarrow1",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "CapFabric"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(133, 86, 62),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "Beanie"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "CapFabric"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(133, 86, 62),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "Beanie"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(31, 22, 18),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "CapFabricReverse"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        FacialHair = "Mustache4",
                        HairColor = Color3.fromRGB(70, 47, 37),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "CapFabricReverse"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(31, 22, 18),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "CapFabricReverse"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    FAI_Service = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "BattleDressUniform_USWoodland" },
                        Pants = { "BattleDressUniform_USWoodland" }
                    },
                    {
                        Shirt = { "BattleDressUniform_DesertCamouflagePattern" },
                        Pants = { "BattleDressUniform_DesertCamouflagePattern" }
                    },
                    {
                        Shirt = { "BattleDressUniform_Khaki" },
                        Pants = { "BattleDressUniform_Khaki" }
                    },
                    {
                        Shirt = { "BattleDressUniform_OliveDrabGreen" },
                        Pants = { "BattleDressUniform_OliveDrabGreen" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Beanie"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "CapFabric"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "CapFabricReverse"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(118, 119, 50),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "DefaultHigh",
                        HairColor = Color3.fromRGB(118, 119, 50),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FlatTop",
                        HairColor = Color3.fromRGB(118, 119, 50),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    FAI_Incap = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "BattleDressUniform_USWoodland" },
                        Pants = { "BattleDressUniform_USWoodland" }
                    },
                    {
                        Shirt = { "BattleDressUniform_DesertCamouflagePattern" },
                        Pants = { "BattleDressUniform_DesertCamouflagePattern" }
                    },
                    {
                        Shirt = { "BattleDressUniform_Khaki" },
                        Pants = { "BattleDressUniform_Khaki" }
                    },
                    {
                        Shirt = { "BattleDressUniform_OliveDrabGreen" },
                        Pants = { "BattleDressUniform_OliveDrabGreen" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(118, 119, 50),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "DefaultHigh",
                        HairColor = Color3.fromRGB(118, 119, 50),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FlatTop",
                        HairColor = Color3.fromRGB(118, 119, 50),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    HQ_CombatHigh = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "G3Combat_RangerGreen", "G3Field_RangerGreen", "PACERugbyLongSleeve_RangerGreen" },
                        Pants = { "G3Combat_VariCamTropic" }
                    },
                    {
                        Shirt = { "G3Combat_VariCamTropic" },
                        Pants = { "G4Field_RangerGreen", "G3Combat_RangerGreen", "G3Field_RangerGreen" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        FacialHair = "BeardNarrow2",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    HQ_CombatLow = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_RangerGreen",
                            "G3Combat_RangerGreen",
                            "G3Field_RangerGreen",
                            "PACERugbyLongSleeve_RangerGreen"
                        },
                        Pants = { "BattleDressUniform_USWoodland" }
                    },
                    {
                        Shirt = { "BattleDressUniform_USWoodland", "G3Combat_USWoodland" },
                        Pants = { "BattleDressUniform_OliveDrabGreen", "G4Field_RangerGreen" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        FacialHair = "BeardNarrow2",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "ACH"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "MICH2000"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        }
                    }
                }
            }
        }
    },
    HQ_Staff = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = { "AU_Darcy", "AU_J" },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "PACERugbyLongSleeve_RangerGreen", "G4Combat_RangerGreen" },
                        Pants = {
                            "501OriginalFit_StoneWashedDenim",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "SpecterAWGen2_BrownGrey",
                            "BattleDressUniform_Charcoal",
                            "BattleDressUniform_Black"
                        }
                    },
                    {
                        Shirt = { "PACERugbyLongSleeve_RangerGreen" },
                        Pants = {
                            "501OriginalFit_StoneWashedDenim",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "SpecterAWGen2_BrownGrey",
                            "BattleDressUniform_Charcoal",
                            "BattleDressUniform_Black"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        FacialHair = "BeardNarrow1",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(133, 86, 62),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(133, 86, 62),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(31, 22, 18),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        FacialHair = "Mustache4",
                        HairColor = Color3.fromRGB(70, 47, 37),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(31, 22, 18),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    HQ_Doc = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = { Color3.fromRGB(234, 184, 146), Color3.fromRGB(255, 204, 153) },
                Clothes = {
                    {
                        Shirt = { "PACERugby_WolfGrey", "PACERugbyLongSleeve_WolfGrey" },
                        Pants = { "501OriginalFit_StoneWashedDenimGrayDyed", "501OriginalFit_StoneWashedDenim" }
                    }
                },
                Gear = {
                    {
                        Hair = "FemaleA_BunLow",
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "DefaultHigh",
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    HQ_Patient = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = { "AU_Darcy", "AU_J" },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_RangerGreen",
                            "G3Combat_RangerGreen",
                            "G3Field_RangerGreen",
                            "PACERugbyLongSleeve_RangerGreen"
                        },
                        Pants = { "BattleDressUniform_USWoodland" }
                    },
                    {
                        Shirt = { "BattleDressUniform_USWoodland", "G3Combat_USWoodland" },
                        Pants = { "BattleDressUniform_OliveDrabGreen", "G4Field_RangerGreen" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        FacialHair = "BeardNarrow1",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(133, 86, 62),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(133, 86, 62),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(31, 22, 18),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        FacialHair = "Mustache4",
                        HairColor = Color3.fromRGB(70, 47, 37),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(31, 22, 18),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    HQ_CombatHigh_Female = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Female",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "G3Combat_RangerGreen", "G3Field_RangerGreen", "PACERugbyLongSleeve_RangerGreen" },
                        Pants = { "G3Combat_VariCamTropic" }
                    },
                    {
                        Shirt = { "G3Combat_VariCamTropic" },
                        Pants = { "G4Field_RangerGreen", "G3Combat_RangerGreen", "G3Field_RangerGreen" }
                    }
                },
                Gear = {
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    HQ_CombatLow_Female = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Female",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_RangerGreen",
                            "G3Combat_RangerGreen",
                            "G3Field_RangerGreen",
                            "PACERugbyLongSleeve_RangerGreen"
                        },
                        Pants = { "BattleDressUniform_USWoodland" }
                    },
                    {
                        Shirt = { "BattleDressUniform_USWoodland", "G3Combat_USWoodland" },
                        Pants = { "BattleDressUniform_OliveDrabGreen", "G4Field_RangerGreen" }
                    }
                },
                Gear = {
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {}
                        }
                    },
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "ACH"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        }
                    },
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "MICH2000"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        }
                    }
                }
            }
        }
    },
    HQ_Staff_Female = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Female",
                Voice = { "AU_Darcy", "AU_J" },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "PACERugbyLongSleeve_RangerGreen", "G4Combat_RangerGreen" },
                        Pants = {
                            "501OriginalFit_StoneWashedDenim",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "SpecterAWGen2_BrownGrey",
                            "BattleDressUniform_Charcoal",
                            "BattleDressUniform_Black"
                        }
                    },
                    {
                        Shirt = { "PACERugbyLongSleeve_RangerGreen" },
                        Pants = {
                            "501OriginalFit_StoneWashedDenim",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "SpecterAWGen2_BrownGrey",
                            "BattleDressUniform_Charcoal",
                            "BattleDressUniform_Black"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(133, 86, 62),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(133, 86, 62),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(31, 22, 18),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(70, 47, 37),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(31, 22, 18),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    HQ_Doc_Female = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Female",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = { Color3.fromRGB(234, 184, 146), Color3.fromRGB(255, 204, 153) },
                Clothes = {
                    {
                        Shirt = { "PACERugby_WolfGrey", "PACERugbyLongSleeve_WolfGrey" },
                        Pants = { "501OriginalFit_StoneWashedDenimGrayDyed", "501OriginalFit_StoneWashedDenim" }
                    }
                },
                Gear = {
                    {
                        Hair = "FemaleA_BunLow",
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "DefaultHigh",
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    HQ_Patient_Female = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Female",
                Voice = { "AU_Darcy", "AU_J" },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_RangerGreen",
                            "G3Combat_RangerGreen",
                            "G3Field_RangerGreen",
                            "PACERugbyLongSleeve_RangerGreen"
                        },
                        Pants = { "BattleDressUniform_USWoodland" }
                    },
                    {
                        Shirt = { "BattleDressUniform_USWoodland", "G3Combat_USWoodland" },
                        Pants = { "BattleDressUniform_OliveDrabGreen", "G4Field_RangerGreen" }
                    }
                },
                Gear = {
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(133, 86, 62),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(133, 86, 62),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(31, 22, 18),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(70, 47, 37),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FemaleA_BunLow",
                        HairColor = Color3.fromRGB(31, 22, 18),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Hostage_Civilian = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIButtonUpKhaki",
                            "AIFlannelGray",
                            "AIFlannelGreen",
                            "AIFlannelRed",
                            "AIFlannelYellow",
                            "AIPoloGray",
                            "AIPoloRed",
                            "AIPoloYellow",
                            "AITshirtBrown",
                            "AITshirtTan"
                        },
                        Pants = {
                            "AIJeansKhaki",
                            "AIJeansKhaki2",
                            "AITrousersBoots",
                            "AITrousersShoes"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "DefaultHigh",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FlatTop",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FlatTop",
                        HairColor = Color3.fromRGB(177, 142, 78),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FlatTop",
                        HairColor = Color3.fromRGB(34, 34, 34),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Hostage_VIP = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "Pilot" },
                        Pants = { "Pilot" }
                    },
                    {
                        Shirt = { "PCU" },
                        Pants = { "PCU" }
                    },
                    {
                        Shirt = { "Floral" },
                        Pants = { "AIJeansKhaki2", "AIJeansKhaki" }
                    }
                },
                Gear = {
                    {
                        Hair = "DefaultHigh",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {},
                        Helmet = {},
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FlatTop",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {},
                        Helmet = {},
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FlatTop",
                        HairColor = Color3.fromRGB(177, 142, 78),
                        Vest = {},
                        Helmet = {},
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "FlatTop",
                        HairColor = Color3.fromRGB(34, 34, 34),
                        Vest = {},
                        Helmet = {},
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    M1_Suspect = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = { Color3.fromRGB(204, 142, 105) },
                Clothes = {
                    {
                        Shirt = { "Floral" },
                        Pants = { "AIJeansKhaki2", "AIJeansKhaki" }
                    }
                },
                Gear = {
                    {
                        Hair = "FlatTop",
                        HairColor = Color3.fromRGB(34, 34, 34),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    M1_Friendly = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "BattleDressUniform_NavyBlue" },
                        Pants = { "BattleDressUniform_Black" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(177, 142, 78),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Black"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAP"
                                        },
                                        {
                                            Camo = "Black"
                                        },
                                        {
                                            Rail_1 = {}
                                        }
                                    }
                                },
                                Rail_2 = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "MollePouch",
                                            "Eagle_MBITR_Elastic"
                                        },
                                        {
                                            Camo = "Black",
                                            Lerp = 0.44
                                        },
                                        {
                                            Radio = {}
                                        }
                                    }
                                },
                                Rail_3 = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "MollePouch",
                                            "Kywi_556_Mid_Upright_Bare"
                                        },
                                        {
                                            Camo = "Black",
                                            Lerp = 0.86
                                        },
                                        {
                                            Mag = {}
                                        }
                                    }
                                },
                                VelcroHardpointFront = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Patch",
                                            "Vest_Patch_NIR_2x35_Flat"
                                        },
                                        {
                                            Camo = "UK"
                                        },
                                        {}
                                    }
                                }
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "WENDY_EXFIL3"
                            },
                            {
                                Camo = "Black"
                            },
                            {
                                Cover = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Helmet",
                                            "Cover",
                                            "EXFIL3_Velcro"
                                        },
                                        {
                                            Camo = "Black"
                                        },
                                        {}
                                    }
                                }
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            },
                            {
                                Camo = "OliveDrabGreen"
                            }
                        },
                        Eyewear = {
                            {
                                "Character",
                                "Eyewear",
                                "Eyewear",
                                "Oakley3"
                            },
                            {}
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        }
                    }
                }
            }
        }
    },
    Demo = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIButtonUpKhaki",
                            "AIFlannelGray",
                            "AIFlannelGreen",
                            "AIFlannelRed",
                            "AIFlannelYellow",
                            "AIPoloGray",
                            "AIPoloRed",
                            "AIPoloYellow",
                            "AITshirtBrown",
                            "AITshirtTan"
                        },
                        Pants = {
                            "AIJeansKhaki",
                            "AIJeansKhaki2",
                            "AITrousersBoots",
                            "AITrousersShoes"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(0, 0, 0),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B45_Heavy"
                            },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    }
};