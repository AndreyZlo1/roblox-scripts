-- Roblox: ReplicatedStorage.Shared.Configs.Bots.BotAppearance.SpecialAppearance
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    NickPines_Wetwork4 = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = { "AU_Darcy" },
                Skin = { Color3.fromRGB(234, 184, 146) },
                Clothes = {
                    {
                        Shirt = { "PCU" },
                        Pants = { "AIPantsKhaki" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        FacialHair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "SheriffHat"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    ChefLecter = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIShirtRed",
                            "AIPoloRed",
                            "AIShirtWhite",
                            "AIShirtGreen",
                            "AIShirtBlue",
                            "AIShirtTan",
                            "AIShirtGrey",
                            "AIShirtBlack"
                        },
                        Pants = {
                            "AIJeansDarkBlue",
                            "AIJeansGrey",
                            "AIJeansBlueWorn",
                            "AIPantsGreen",
                            "AIPantsLightGrey"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "CapFabricRed"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    DefectedResearcher = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIButtonUpKhaki",
                            "AIFlannelGray",
                            "AIFlannelGreen",
                            "AIFlannelRed",
                            "AIFlannelYellow",
                            "AIPoloGray",
                            "AIPoloRed",
                            "AIPoloYellow",
                            "AITshirtBrown",
                            "AITshirtTan"
                        },
                        Pants = {
                            "AIJeansKhaki",
                            "AIJeansKhaki2",
                            "AITrousersBoots",
                            "AITrousersShoes"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(0, 0, 0),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B45_Heavy"
                            },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    SergeantPierrat = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "G3Field_VariCam",
                            "PACERugby_RangerGreen",
                            "PACERugby_CoyoteBrown",
                            "PACERugbyLongSleeve_EarthTan"
                        },
                        Pants = {
                            "G3Combat_VariCam",
                            "G3Field_VariCam",
                            "G3Field_RangerGreen",
                            "BattleDressUniform_Khaki"
                        }
                    },
                    {
                        Shirt = {
                            "G3Combat_VariCam",
                            "PACERugby_RangerGreen",
                            "PACERugby_CoyoteBrown",
                            "PACERugbyLongSleeve_EarthTan"
                        },
                        Pants = { "G3Combat_VariCam", "G3Field_VariCam", "BattleDressUniform_Khaki" }
                    },
                    {
                        Shirt = { "G3Combat_USWoodland", "BattleDressUniform_USWoodland" },
                        Pants = {
                            "G3Combat_USWoodland",
                            "BattleDressUniform_USWoodland",
                            "501OriginalFit_StoneWashedDenimGreenDyed",
                            "SpecterAWGen2_BrownGrey"
                        }
                    },
                    {
                        Shirt = { "G3Combat_USWoodland" },
                        Pants = { "G3Combat_USWoodland", "G3Field_RangerGreen" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        FacialHair = "BeardNarrow2",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        FacialHair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "ACH"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "OPSCORE_FASTMT"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "MICH2000"
                            }
                        },
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "CRYE_JPC"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Flap = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Vest",
                                            "Flap",
                                            "CRYE_FLAPM4FLAT"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "OR_IRONSIGHT" },
                            {
                                Camo = "Black"
                            },
                            {}
                        },
                        Earwear = {
                            {
                                "Character",
                                "Earwear",
                                "Earwear",
                                "COMTAC3"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        }
                    }
                }
            }
        }
    },
    DoctorWeiss = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIButtonUpKhaki",
                            "AIFlannelGray",
                            "AIFlannelGreen",
                            "AIFlannelRed",
                            "AIFlannelYellow",
                            "AIPoloGray",
                            "AIPoloRed",
                            "AIPoloYellow",
                            "AITshirtBrown",
                            "AITshirtTan"
                        },
                        Pants = {
                            "AIJeansKhaki",
                            "AIJeansKhaki2",
                            "AITrousersBoots",
                            "AITrousersShoes"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(0, 0, 0),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B45_Heavy"
                            },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    QuartermasterLuzhkov = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIButtonUpKhaki",
                            "AIFlannelGray",
                            "AIFlannelGreen",
                            "AIFlannelRed",
                            "AIFlannelYellow",
                            "AIPoloGray",
                            "AIPoloRed",
                            "AIPoloYellow",
                            "AITshirtBrown",
                            "AITshirtTan"
                        },
                        Pants = {
                            "AIJeansKhaki",
                            "AIJeansKhaki2",
                            "AITrousersBoots",
                            "AITrousersShoes"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(0, 0, 0),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B45_Heavy"
                            },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    LcdrBergher = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIButtonUpKhaki",
                            "AIFlannelGray",
                            "AIFlannelGreen",
                            "AIFlannelRed",
                            "AIFlannelYellow",
                            "AIPoloGray",
                            "AIPoloRed",
                            "AIPoloYellow",
                            "AITshirtBrown",
                            "AITshirtTan"
                        },
                        Pants = {
                            "AIJeansKhaki",
                            "AIJeansKhaki2",
                            "AITrousersBoots",
                            "AITrousersShoes"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(0, 0, 0),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B45_Heavy"
                            },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    ChefAgbayani = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIButtonUpKhaki",
                            "AIFlannelGray",
                            "AIFlannelGreen",
                            "AIFlannelRed",
                            "AIFlannelYellow",
                            "AIPoloGray",
                            "AIPoloRed",
                            "AIPoloYellow",
                            "AITshirtBrown",
                            "AITshirtTan"
                        },
                        Pants = {
                            "AIJeansKhaki",
                            "AIJeansKhaki2",
                            "AITrousersBoots",
                            "AITrousersShoes"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(0, 0, 0),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B45_Heavy"
                            },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    NurseNajjar = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIButtonUpKhaki",
                            "AIFlannelGray",
                            "AIFlannelGreen",
                            "AIFlannelRed",
                            "AIFlannelYellow",
                            "AIPoloGray",
                            "AIPoloRed",
                            "AIPoloYellow",
                            "AITshirtBrown",
                            "AITshirtTan"
                        },
                        Pants = {
                            "AIJeansKhaki",
                            "AIJeansKhaki2",
                            "AITrousersBoots",
                            "AITrousersShoes"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(0, 0, 0),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B45_Heavy"
                            },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    JohnDoe = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIButtonUpKhaki",
                            "AIFlannelGray",
                            "AIFlannelGreen",
                            "AIFlannelRed",
                            "AIFlannelYellow",
                            "AIPoloGray",
                            "AIPoloRed",
                            "AIPoloYellow",
                            "AITshirtBrown",
                            "AITshirtTan"
                        },
                        Pants = {
                            "AIJeansKhaki",
                            "AIJeansKhaki2",
                            "AITrousersBoots",
                            "AITrousersShoes"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(0, 0, 0),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B45_Heavy"
                            },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    MisterFixer = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIButtonUpKhaki",
                            "AIFlannelGray",
                            "AIFlannelGreen",
                            "AIFlannelRed",
                            "AIFlannelYellow",
                            "AIPoloGray",
                            "AIPoloRed",
                            "AIPoloYellow",
                            "AITshirtBrown",
                            "AITshirtTan"
                        },
                        Pants = {
                            "AIJeansKhaki",
                            "AIJeansKhaki2",
                            "AITrousersBoots",
                            "AITrousersShoes"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(0, 0, 0),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B45_Heavy"
                            },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    DrLakewell = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = { Color3.fromRGB(204, 142, 105) },
                Clothes = {
                    {
                        Shirt = { "Scrub_Lakewell" },
                        Pants = { "Scrub_Lakewell" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(94, 70, 49),
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "M50"
                            },
                            {
                                Camo = "Default"
                            },
                            {
                                Hood = {
                                    ["1"] = {
                                        {
                                            "Character",
                                            "Facewear",
                                            "Hood",
                                            "M50_Hood"
                                        },
                                        {
                                            Camo = "Default"
                                        }
                                    }
                                }
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "Nitrile_Med" },
                            {
                                Camo = "Purple"
                            },
                            {}
                        }
                    }
                }
            }
        }
    },
    VanessaMunez = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = { Color3.fromRGB(173, 113, 84) },
                Clothes = {
                    {
                        Shirt = { "AIFlannelGray" },
                        Pants = { "AIJeansKhaki2" }
                    }
                },
                Gear = {
                    {
                        Hair = "Female_Bangs_PonyHigh",
                        HairColor = Color3.fromRGB(0, 0, 0),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "PressVest"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "CapFabric"
                            },
                            {
                                Camo = "NavyBlue"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    DirectorDulles = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "AIButtonUpKhaki",
                            "AIFlannelGray",
                            "AIFlannelGreen",
                            "AIFlannelRed",
                            "AIFlannelYellow",
                            "AIPoloGray",
                            "AIPoloRed",
                            "AIPoloYellow",
                            "AITshirtBrown",
                            "AITshirtTan"
                        },
                        Pants = {
                            "AIJeansKhaki",
                            "AIJeansKhaki2",
                            "AITrousersBoots",
                            "AITrousersShoes"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(0, 0, 0),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_6B45_Heavy"
                            },
                            {
                                Camo = "Default"
                            },
                            {}
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    }
};