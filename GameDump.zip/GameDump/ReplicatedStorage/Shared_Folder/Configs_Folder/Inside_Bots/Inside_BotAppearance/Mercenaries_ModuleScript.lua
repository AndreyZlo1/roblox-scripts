-- Roblox: ReplicatedStorage.Shared.Configs.Bots.BotAppearance.Mercenaries
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    MercenaryT1_Rifleman = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    MercenaryT1_Smg = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    MercenaryT1_Shotgun = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    MercenaryT1_Sniper = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    MercenaryT1_Rpg = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    MercenaryT1_Rifleman_Heavy = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    MercenaryT1_Smg_Heavy = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    MercenaryT1_Shotgun_Heavy = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    MercenaryT1_Sniper_Heavy = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    MercenaryT1_Lmg = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    MercenaryT1_Rifleman_Heavy_Haz = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12B"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12B"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12B"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    MercenaryT1_Smg_Heavy_Haz = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12B"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12B"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12B"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    MercenaryT1_Shotgun_Heavy_Haz = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12B"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanB"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB_Bag"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanC"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    MercenaryT2_Rifleman = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "G3Combat_VariCamBlack", "APCRapidLongSleeveShirt_Black", "PACERugby_Black" },
                        Pants = { "G3Combat_VariCamBlack" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA_Bag"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanE"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC_Bag"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanE"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB_Bag"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanE"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    MercenaryT2_Rifleman_Haz = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "G3Combat_VariCamBlack", "APCRapidLongSleeveShirt_Black", "PACERugby_Black" },
                        Pants = { "G3Combat_VariCamBlack" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA_Bag"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanE"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12B"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC_Bag"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanE"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12B"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB_Bag"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanE"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_FM12B"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    MercenaryT2_Marksman = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = { "G3Combat_VariCamBlack", "APCRapidLongSleeveShirt_Black", "PACERugby_Black" },
                        Pants = { "G3Combat_VariCamBlack" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanA_Bag"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanE"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanC_Bag"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanE"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC_RiflemanB_Bag"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_FASTXP_RiflemanE"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "AI_BanditA"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Insolon_Low = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugby_WolfGrey",
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "BattleDressUniform_Charcoal",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    },
                    {
                        Shirt = { "G3Field_VariCam", "G3Combat_VariCam", "ACU2004_UCP" },
                        Pants = { "G3Field_VariCam", "G3Combat_VariCam" }
                    },
                    {
                        Shirt = { "BattleDressUniform_NavyBlue" },
                        Pants = { "501OriginalFit_StoneWashedDenimGrayDyed", "501OriginalFit_StoneWashedDenim" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Beanie2"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_CapF"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterHigh"
                            },
                            {
                                Camo = "Tan"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterHigh"
                            },
                            {
                                Camo = "Tan"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    },
    Insolon_VIP = {
        Bias = { 1 },
        Appearance = {
            {
                Gender = "Male",
                Voice = {
                    "AU_Darcy",
                    "AU_J",
                    "AU_Alex",
                    "AU_Kelvin"
                },
                Skin = {
                    Color3.fromRGB(204, 142, 105),
                    Color3.fromRGB(234, 184, 146),
                    Color3.fromRGB(255, 204, 153),
                    Color3.fromRGB(173, 113, 84),
                    Color3.fromRGB(145, 95, 72)
                },
                Clothes = {
                    {
                        Shirt = {
                            "PACERugbyLongSleeve_EarthTan",
                            "PACERugbyLongSleeve_RangerGreen",
                            "BattleDressUniform_NavyBlue",
                            "BattleDressUniform_Charcoal"
                        },
                        Pants = {
                            "SpecterAWGen2_CoyoteBrown",
                            "SpecterAWGen2_BrownGrey",
                            "SpecterHW_BrownGrey",
                            "501OriginalFit_StoneWashedDenimGrayDyed",
                            "501OriginalFit_StoneWashedDenim",
                            "G3Field_VariCam",
                            "G3Combat_VariCam"
                        }
                    },
                    {
                        Shirt = { "G3Field_VariCam", "G3Combat_VariCam", "ACU2004_UCP" },
                        Pants = { "G3Field_VariCam", "G3Combat_VariCam" }
                    }
                },
                Gear = {
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_Beanie2"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterLow"
                            },
                            {
                                Camo = "Tan"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    },
                    {
                        Hair = "Default",
                        HairColor = Color3.fromRGB(105, 70, 52),
                        Vest = {
                            {
                                "Character",
                                "Vest",
                                "Vest",
                                "AI_JPC"
                            },
                            {
                                Camo = "Insolon"
                            }
                        },
                        Gloves = {
                            { "Character", "Gloves", "AI_Glove" },
                            {},
                            {}
                        },
                        Helmet = {
                            {
                                "Character",
                                "Helmet",
                                "Helmet",
                                "AI_CapF"
                            },
                            {
                                Camo = "Default"
                            }
                        },
                        Facewear = {
                            {
                                "Character",
                                "Facewear",
                                "Facewear",
                                "GaiterHigh"
                            },
                            {
                                Camo = "Tan"
                            }
                        },
                        Boots = {
                            { "Character", "Boots", "Generic" },
                            {},
                            {}
                        }
                    }
                }
            }
        }
    }
};