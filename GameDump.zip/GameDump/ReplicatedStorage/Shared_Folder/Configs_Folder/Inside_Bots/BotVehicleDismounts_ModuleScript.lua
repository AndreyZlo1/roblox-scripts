-- Roblox: ReplicatedStorage.Shared.Configs.Bots.BotVehicleDismounts
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Humvee_Rear = { "RR", "RL" },
    Humvee_Full = {
        "RR",
        "RL",
        "FR",
        "FL"
    },
    M998AI_Rear2 = { "RR3", "RL3" },
    M998AI_Rear4 = {
        "RR3",
        "RR2",
        "RL3",
        "RL2"
    },
    M998AI_Rear6 = {
        "RR3",
        "RR2",
        "RL3",
        "RL2",
        "RL1",
        "RR1"
    },
    M998AI_Full = {
        "RR3",
        "RR2",
        "RL3",
        "RL2",
        "RL1",
        "RR1",
        "FL",
        "FR"
    },
    M998AI_Turret = {
        "RR3",
        "RR2",
        "RL3",
        "RL2",
        "RL1",
        "RR1",
        "FR"
    },
    Demo2_Rear2 = { "RR6", "RL6" },
    Demo2_Rear6 = {
        "RR6",
        "RR5",
        "RL4",
        "RL6",
        "RL5",
        "RR4"
    },
    Demo2_Full = {
        "RR6",
        "RR5",
        "RL4",
        "RL6",
        "RL5",
        "RR4",
        "RR3",
        "RR2",
        "RL3",
        "RL2",
        "RL1",
        "RR1",
        "FL",
        "FR"
    },
    Demo3_Dropoff = {
        "SR1",
        "SR2",
        "SL1",
        "SL2"
    },
    UralAI_Rear2 = { "RR5", "RL5" },
    UralAI_Rear4 = {
        "RR5",
        "RR4",
        "RL5",
        "RL4"
    },
    UralAI_Rear6 = {
        "RR5",
        "RR4",
        "RL5",
        "RL4",
        "RR3",
        "RL3"
    },
    UralAI_Rear8 = {
        "RR5",
        "RR4",
        "RL5",
        "RL4",
        "RR3",
        "RR2",
        "RL3",
        "RL2"
    },
    UralAI_Rear10 = {
        "RR5",
        "RR4",
        "RL5",
        "RL4",
        "RR3",
        "RR2",
        "RL3",
        "RL2",
        "RR1",
        "RL1"
    },
    UralAI_Full = {
        "RR5",
        "RR4",
        "RL5",
        "RL4",
        "RR3",
        "RR2",
        "RL3",
        "RL2",
        "RR1",
        "RL1",
        "FL",
        "FR"
    },
    UralAI_Turret = {
        "RR5",
        "RR4",
        "RL5",
        "RL4",
        "RR3",
        "RR2",
        "RL3",
        "RL2",
        "RR1",
        "RL1",
        "FR"
    },
    MI8AI_Rear1 = { "RL6" },
    MI8AI_Rear2 = { "RR6", "RL6" },
    MI8AI_Rear4 = {
        "RR6",
        "RR5",
        "RL5",
        "RL6"
    },
    MI8AI_Rear6 = {
        "RR6",
        "RR5",
        "RL4",
        "RL6",
        "RL5",
        "RR4"
    },
    MI8AI_Rear8 = {
        "RR6",
        "RR5",
        "RL4",
        "RL6",
        "RL5",
        "RR4",
        "RR3",
        "RL3"
    },
    MI8AI_Rear10 = {
        "RR6",
        "RR5",
        "RL4",
        "RL6",
        "RL5",
        "RR4",
        "RR3",
        "RR2",
        "RL3",
        "RL2"
    },
    MI8AI_Rear12 = {
        "RR6",
        "RR5",
        "RL4",
        "RL6",
        "RL5",
        "RR4",
        "RR3",
        "RR2",
        "RL3",
        "RL2",
        "RL1",
        "RR1"
    },
    MI8AI_Full = {
        "RR6",
        "RR5",
        "RL4",
        "RL6",
        "RL5",
        "RR4",
        "RR3",
        "RR2",
        "RL3",
        "RL2",
        "RL1",
        "RR1",
        "FR"
    },
    UH60_Qt = {
        "RF3",
        "RF4",
        "RFE1",
        "RFE2",
        "RFE3"
    },
    UH60_Half = {
        "RF3",
        "RF4",
        "RFE1",
        "RFE2",
        "RFE3",
        "RR3",
        "RR4",
        "SR2",
        "SL2"
    },
    UH60_Full = {
        "RF1",
        "RF2",
        "RF3",
        "RF4",
        "RFE1",
        "RFE2",
        "RFE3",
        "RR1",
        "RR2",
        "RR3",
        "RR4",
        "SR1",
        "SR2",
        "SL1",
        "SL2"
    }
};