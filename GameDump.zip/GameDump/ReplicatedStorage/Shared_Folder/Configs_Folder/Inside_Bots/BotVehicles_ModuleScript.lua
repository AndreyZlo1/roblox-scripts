-- Roblox: ReplicatedStorage.Shared.Configs.Bots.BotVehicles
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Demo = {
        Type = "Ground",
        Name = "Humvee",
        Health = 1000,
        Config = {
            Armor = "Default",
            Turrets = {
                Roof = "HeavyTurret"
            }
        },
        Seats = {
            FL = "RLF_SMG",
            FR = "RLF_Shotgun",
            Roof = "RLF_Rifleman_Heavy"
        }
    },
    Demo2 = {
        Type = "Ground",
        Name = "FMTV",
        Health = 3000,
        Config = {
            Armor = "Default"
        },
        Seats = {
            FL = "RLF_Rifleman",
            FR = "RLF_SMG",
            RL1 = "RLF_Rifleman",
            RL2 = "RLF_SMG",
            RL3 = "RLF_Shotgun",
            RL4 = "RLF_AutoRifleman",
            RL5 = "RLF_Rifleman",
            RL6 = "RLF_HeavyAuto",
            RR1 = "RLF_Rifleman",
            RR2 = "RLF_Shotgun",
            RR3 = "RLF_SMG",
            RR4 = "RLF_Rifleman",
            RR5 = "RLF_Rifleman_Heavy",
            RR6 = "RLF_Sniper"
        }
    },
    Demo3 = {
        Type = "Helicopter",
        Name = "UH60",
        Health = 3000,
        Config = {
            Armor = "Heavy",
            Turrets = {
                GunLeft = "LightTurret",
                GunRight = "LightTurret"
            }
        },
        Seats = {
            FR = "POD_Pilot",
            SR1 = "POD_HeavyAuto",
            SR2 = "POD_Rifleman_Heavy",
            SL1 = "POD_HeavyAuto",
            SL2 = "POD_Rifleman_Heavy",
            Gunleft = "POD_Spec",
            GunRight = "POD_Spec"
        }
    },
    Stealable_Fuel = {
        Type = "Ground",
        Name = "Ural4320AI",
        Health = 5000,
        Config = {
            Armor = "Default",
            Turrets = {
                Back = "NoTurret",
                Rear = "Door",
                Cargo = "Fuel"
            }
        },
        Resources = {
            Money = 100,
            Material = { 0, 0 },
            Metal = { 0, 0 },
            Fuel = { 12, 12 },
            Equipment = { 0, 0 }
        }
    },
    Stealable_Material = {
        Type = "Ground",
        Name = "Ural4320AI",
        Health = 5000,
        Config = {
            Armor = "Default",
            Turrets = {
                Back = "NoTurret",
                Rear = "Door",
                Cargo = "Construction"
            }
        },
        Resources = {
            Money = 500,
            Material = { 10, 10 },
            Metal = { 0, 0 },
            Fuel = { 0, 0 },
            Equipment = { 0, 0 }
        }
    },
    Stealable_Metal = {
        Type = "Ground",
        Name = "M998AI",
        Health = 1400,
        Config = {
            Armor = "Heavy",
            Turrets = {
                Back = "NoTurret",
                Rear = "Door",
                Cargo = "Metal"
            }
        },
        Resources = {
            Money = 200,
            Material = { 0, 0 },
            Metal = { 3, 3 },
            Fuel = { 0, 0 },
            Equipment = { 0, 0 }
        }
    },
    Stealable_Equip = {
        Type = "Ground",
        Name = "M998AI",
        Health = 1400,
        Config = {
            Armor = "Heavy",
            Turrets = {
                Back = "NoTurret",
                Rear = "Door",
                Cargo = "Equipment"
            }
        },
        Resources = {
            Money = 500,
            Material = { 0, 0 },
            Metal = { 0, 0 },
            Fuel = { 0, 0 },
            Equipment = { 5, 5 }
        }
    },
    RLF_M998_Light = {
        Type = "Ground",
        Name = "M998AI",
        Health = 10000,
        Config = {
            Armor = "Heavy"
        },
        Seats = {
            FL = "RLF_SMG",
            FR = "RLF_SMG",
            RL1 = "RLF_Shotgun",
            RL2 = "RLF_Shotgun",
            RL3 = "RLF_Sniper",
            RR1 = "RLF_SMG",
            RR2 = "RLF_Melee",
            RR3 = "RLF_Rifleman"
        }
    },
    RLF_M998_Med = {
        Type = "Ground",
        Name = "M998AI",
        Health = 10000,
        Config = {
            Armor = "Heavy"
        },
        Seats = {
            FL = "RLF_Rifleman",
            FR = "RLF_Shotgun",
            RL1 = "RLF_Rifleman_Heavy",
            RL2 = "RLF_Rifleman",
            RL3 = "RLF_AutoRifleman",
            RR1 = "RLF_Rifleman_Heavy",
            RR2 = "RLF_Rifleman",
            RR3 = "RLF_Marksman"
        }
    },
    RLF_M998_Heavy = {
        Type = "Ground",
        Name = "M998AI",
        Health = 10000,
        Config = {
            Armor = "Heavy"
        },
        Seats = {
            FL = "RLF_Rifleman",
            FR = "RLF_Rifleman_Heavy",
            RL1 = "RLF_Rifleman_Heavy",
            RL2 = "RLF_Rifleman_Heavy",
            RL3 = "RLF_HeavyAuto",
            RR1 = "RLF_Rifleman_Heavy",
            RR2 = "RLF_AutoRifleman",
            RR3 = "RLF_RPG"
        }
    },
    RLF_M998_MedTurret = {
        Type = "Ground",
        Name = "M998AI",
        Health = 10000,
        Config = {
            Armor = "Heavy",
            Turrets = {
                Back = "LightTurret"
            }
        },
        Seats = {
            FL = "RLF_Rifleman",
            FR = "RLF_Shotgun",
            RL1 = "RLF_Rifleman_Heavy",
            RL2 = "RLF_Rifleman",
            RL3 = "RLF_AutoRifleman",
            RR1 = "RLF_Rifleman_Heavy",
            RR2 = "RLF_Rifleman",
            RR3 = "RLF_Marksman",
            Back = "RLF_Rifleman_Heavy"
        }
    },
    RLF_M998_Defense = {
        Type = "Ground",
        Name = "M998AI",
        Health = 10000,
        Config = {
            Armor = "Heavy",
            Turrets = {
                Back = "LightTurret"
            }
        },
        Seats = {
            Back = "RLF_Rifleman_Heavy"
        }
    },
    RLF_M998_HeavyTurret = {
        Type = "Ground",
        Name = "M998AI",
        Health = 10000,
        Config = {
            Armor = "Heavy",
            Turrets = {
                Back = "LightTurret"
            }
        },
        Seats = {
            FL = "RLF_Rifleman",
            FR = "RLF_Rifleman_Heavy",
            RL1 = "RLF_Rifleman_Heavy",
            RL2 = "RLF_Rifleman_Heavy",
            RL3 = "RLF_HeavyAuto",
            RR1 = "RLF_Rifleman_Heavy",
            RR2 = "RLF_AutoRifleman",
            RR3 = "RLF_RPG",
            Back = "RLF_Rifleman_Heavy"
        }
    },
    POD_M998_LightTurret = {
        Type = "Ground",
        Name = "M998AI",
        Health = 10000,
        Config = {
            Armor = "Heavy",
            Turrets = {
                Back = "LightTurret"
            }
        },
        Seats = {
            FL = "POD_SMG",
            FR = "POD_SMG",
            RL1 = "POD_Shotgun",
            RL2 = "POD_Shotgun",
            RL3 = "POD_Rifleman",
            RR1 = "POD_SMG",
            RR2 = "POD_Smoker_Light",
            RR3 = "POD_Rifleman",
            Back = "POD_Rifleman_Heavy"
        }
    },
    POD_M998_SpecTurret = {
        Type = "Ground",
        Name = "M998AI",
        Health = 10000,
        Config = {
            Armor = "Heavy",
            Turrets = {
                Back = "LightTurret"
            }
        },
        Seats = {
            FL = "POD_Spec",
            FR = "POD_HeavyAuto",
            RL1 = "POD_Rifleman_Heavy",
            RL2 = "POD_Spec",
            RL3 = "POD_Spec",
            RR1 = "POD_AutoRifleman",
            RR2 = "POD_Spec",
            RR3 = "POD_Spec",
            Back = "POD_Spec"
        }
    },
    RLF_Ural_Light = {
        Type = "Ground",
        Name = "Ural4320AI",
        Health = 10000,
        Config = {
            Armor = "Default"
        },
        Seats = {
            FL = "RLF_Pistol",
            FR = "RLF_Rifleman",
            RL1 = "RLF_Pistol",
            RL2 = "RLF_Shotgun",
            RL3 = "RLF_Melee",
            RL4 = "RLF_AutoRifleman",
            RL5 = "RLF_SMG",
            RR1 = "RLF_Pistol",
            RR2 = "RLF_SMG",
            RR3 = "RLF_Rifleman",
            RR4 = "RLF_Sniper",
            RR5 = "RLF_Rifleman"
        }
    },
    RLF_Ural_Med = {
        Type = "Ground",
        Name = "Ural4320AI",
        Health = 10000,
        Config = {
            Armor = "Default"
        },
        Seats = {
            FL = "RLF_Rifleman_Heavy",
            FR = "RLF_Rifleman_Heavy",
            RL1 = "RLF_Rifleman",
            RL2 = "RLF_Shotgun",
            RL3 = "RLF_SMG",
            RL4 = "RLF_Marksman",
            RL5 = "RLF_AutoRifleman",
            RR1 = "RLF_Rifleman",
            RR2 = "RLF_SMG",
            RR3 = "RLF_Rifleman",
            RR4 = "RLF_Sniper",
            RR5 = "RLF_AutoRifleman"
        }
    },
    RLF_Ural_Heavy = {
        Type = "Ground",
        Name = "Ural4320AI",
        Health = 10000,
        Config = {
            Armor = "Default"
        },
        Seats = {
            FL = "RLF_Rifleman_Heavy",
            FR = "RLF_Rifleman_Heavy",
            RL1 = "RLF_Rifleman_Heavy",
            RL2 = "RLF_AutoRifleman",
            RL3 = "RLF_AutoRifleman",
            RL4 = "RLF_AutoRifleman",
            RL5 = "RLF_RPG",
            RR1 = "RLF_Rifleman",
            RR2 = "RLF_AutoRifleman",
            RR3 = "RLF_Rifleman_Heavy",
            RR4 = "RLF_AutoRifleman",
            RR5 = "RLF_HeavyAuto"
        }
    },
    RLF_Ural_Med_Turret = {
        Type = "Ground",
        Name = "Ural4320AI",
        Health = 10000,
        Config = {
            Armor = "Default",
            Turrets = {
                Back = "LightTurret"
            }
        },
        Seats = {
            FL = "RLF_Rifleman_Heavy",
            FR = "RLF_Rifleman_Heavy",
            RL1 = "RLF_Rifleman",
            RL2 = "RLF_Shotgun",
            RL3 = "RLF_SMG",
            RL4 = "RLF_SMG",
            RL5 = "RLF_AutoRifleman",
            RR1 = "RLF_Rifleman",
            RR2 = "RLF_SMG",
            RR3 = "RLF_Rifleman",
            RR4 = "RLF_Rifleman_Heavy",
            RR5 = "RLF_AutoRifleman",
            Back = "RLF_Rifleman_Heavy"
        }
    },
    RLF_Ural_Heavy_Turret = {
        Type = "Ground",
        Name = "Ural4320AI",
        Health = 10000,
        Config = {
            Armor = "Default",
            Turrets = {
                Back = "LightTurret"
            }
        },
        Seats = {
            FL = "RLF_Rifleman_Heavy",
            FR = "RLF_Rifleman_Heavy",
            RL1 = "RLF_Rifleman_Heavy",
            RL2 = "RLF_AutoRifleman",
            RL3 = "RLF_AutoRifleman",
            RL4 = "RLF_AutoRifleman",
            RL5 = "RLF_RPG",
            RR1 = "RLF_Rifleman",
            RR2 = "RLF_AutoRifleman",
            RR3 = "RLF_Rifleman_Heavy",
            RR4 = "RLF_AutoRifleman",
            RR5 = "RLF_HeavyAuto",
            Back = "RLF_Rifleman_Heavy"
        }
    },
    POD_Ural_Heavy_Turret = {
        Type = "Ground",
        Name = "Ural4320AI",
        Health = 10000,
        Config = {
            Armor = "Default",
            Turrets = {
                Back = "LightTurret"
            }
        },
        Seats = {
            FL = "POD_Rifleman_Heavy",
            FR = "POD_Rifleman_Heavy",
            RL1 = "POD_Rifleman_Heavy",
            RL2 = "POD_AutoRifleman",
            RL3 = "POD_AutoRifleman",
            RL4 = "POD_AutoRifleman",
            RL5 = "POD_RPG",
            RR1 = "POD_Rifleman",
            RR2 = "POD_AutoRifleman",
            RR3 = "POD_Smoker",
            RR4 = "POD_AutoRifleman",
            RR5 = "POD_HeavyAuto",
            Back = "POD_Rifleman_Heavy"
        }
    },
    RLF_MI8_Turret = {
        Type = "Helicopter",
        Name = "MI8AI",
        Health = 15000,
        Config = {
            Armor = "Default",
            Turrets = {
                Back = "LightTurret",
                Side = "LightTurret"
            }
        },
        Seats = {
            FR = "POD_Pilot",
            FL = "POD_Pilot",
            Back = "RLF_HeliGunner",
            Side = "RLF_HeliGunner"
        }
    },
    RLF_MI8_Light = {
        Type = "Helicopter",
        Name = "MI8AI",
        Health = 15000,
        Config = {
            Armor = "Default",
            Turrets = {
                Back = "LightTurret",
                Side = "LightTurret"
            }
        },
        Seats = {
            FR = "RLF_Rifleman",
            FL = "POD_Pilot",
            RR1 = "RLF_Rifleman",
            RR2 = "RLF_Shotgun",
            RR3 = "RLF_SMG",
            RR4 = "RLF_Rifleman",
            RR5 = "RLF_SMG",
            RR6 = "RLF_Rifleman",
            RL1 = "RLF_SMG",
            RL2 = "RLF_Shotgun",
            RL3 = "RLF_Pistol",
            RL4 = "RLF_SMG",
            RL5 = "RLF_Rifleman",
            RL6 = "RLF_Marksman"
        }
    },
    RLF_MI8_Med = {
        Type = "Helicopter",
        Name = "MI8AI",
        Health = 15000,
        Config = {
            Armor = "Default",
            Turrets = {
                Back = "LightTurret",
                Side = "LightTurret"
            }
        },
        Seats = {
            FR = "RLF_Rifleman",
            FL = "POD_Pilot",
            RR1 = "RLF_Rifleman",
            RR2 = "RLF_Rifleman_Heavy",
            RR3 = "RLF_SMG",
            RR4 = "RLF_Rifleman",
            RR5 = "RLF_Shotgun",
            RR6 = "RLF_AutoRifleman",
            RL1 = "RLF_Rifleman",
            RL2 = "RLF_Rifleman",
            RL3 = "RLF_Rifleman",
            RL4 = "RLF_Rifleman_Heavy",
            RL5 = "RLF_Rifleman",
            RL6 = "RLF_AutoRifleman"
        }
    },
    RLF_MI8_Heavy = {
        Type = "Helicopter",
        Name = "MI8AI",
        Health = 15000,
        Config = {
            Armor = "Default",
            Turrets = {
                Back = "LightTurret",
                Side = "LightTurret"
            }
        },
        Seats = {
            FR = "RLF_Rifleman",
            FL = "POD_Pilot",
            RR1 = "RLF_Rifleman_Heavy",
            RR2 = "RLF_Rifleman_Heavy",
            RR3 = "RLF_HeavyAuto",
            RR4 = "RLF_Rifleman_Heavy",
            RR5 = "RLF_Rifleman",
            RR6 = "RLF_AutoRifleman",
            RL1 = "RLF_Rifleman",
            RL2 = "RLF_Rifleman_Heavy",
            RL3 = "RLF_RPG",
            RL4 = "RLF_Rifleman_Heavy",
            RL5 = "RLF_Rifleman_Heavy",
            RL6 = "RLF_HeavyAuto"
        }
    },
    RLF_MI8_MedTurret = {
        Type = "Helicopter",
        Name = "MI8AI",
        Health = 15000,
        Config = {
            Armor = "Default",
            Turrets = {
                Back = "LightTurret",
                Side = "LightTurret"
            }
        },
        Seats = {
            FR = "RLF_Rifleman",
            FL = "POD_Pilot",
            RR1 = "RLF_Rifleman",
            RR2 = "RLF_Rifleman_Heavy",
            RR3 = "RLF_Rifleman",
            RR4 = "RLF_Rifleman",
            RR5 = "RLF_Shotgun",
            RR6 = "RLF_AutoRifleman",
            RL1 = "RLF_Rifleman",
            RL2 = "RLF_Rifleman",
            RL3 = "RLF_Rifleman",
            RL4 = "RLF_Rifleman_Heavy",
            RL5 = "RLF_Rifleman",
            RL6 = "RLF_AutoRifleman",
            Back = "RLF_HeliGunner",
            Side = "RLF_HeliGunner"
        }
    },
    RLF_MI8_HeavyTurret = {
        Type = "Helicopter",
        Name = "MI8AI",
        Health = 3000,
        Config = {
            Armor = "Default",
            Turrets = {
                Back = "LightTurret",
                Side = "LightTurret"
            }
        },
        Seats = {
            FR = "RLF_Rifleman",
            FL = "POD_Pilot",
            RR1 = "RLF_Rifleman_Heavy",
            RR2 = "RLF_Rifleman_Heavy",
            RR3 = "RLF_HeavyAuto",
            RR4 = "RLF_Rifleman_Heavy",
            RR5 = "RLF_Rifleman",
            RR6 = "RLF_AutoRifleman",
            RL1 = "RLF_Rifleman",
            RL2 = "RLF_Rifleman_Heavy",
            RL3 = "RLF_RPG",
            RL4 = "RLF_Rifleman_Heavy",
            RL5 = "RLF_Rifleman_Heavy",
            RL6 = "RLF_HeavyAuto",
            Back = "RLF_HeliGunner",
            Side = "RLF_HeliGunner"
        }
    },
    POD_MI8_Turret = {
        Type = "Helicopter",
        Name = "MI8AI",
        Health = 6000,
        Config = {
            Armor = "Default",
            Turrets = {
                Back = "LightTurret",
                Side = "LightTurret"
            }
        },
        Seats = {
            FR = "POD_Pilot",
            FL = "POD_Pilot",
            Back = "POD_HeliGunner",
            Side = "POD_HeliGunner"
        }
    },
    POD_MI8_Bunker4 = {
        Type = "Helicopter",
        Name = "MI8AI",
        Health = 6000,
        Config = {
            Armor = "Default",
            Turrets = {
                Back = "LightTurret",
                Side = "LightTurret"
            }
        },
        Seats = {
            FR = "POD_Rifleman",
            FL = "POD_Pilot",
            RR1 = "POD_SMG",
            RR2 = "POD_Rifleman",
            RR3 = "POD_Smoker",
            RR4 = "POD_Rifleman",
            RR5 = "POD_Shotgun",
            RR6 = "POD_SMG",
            RL1 = "POD_Shotgun",
            RL2 = "POD_Shotgun",
            RL3 = "POD_SMG",
            RL4 = "POD_SMG",
            RL5 = "POD_Smoker",
            RL6 = "POD_AutoRifleman",
            Back = "POD_HeliGunner",
            Side = "POD_HeliGunner"
        }
    },
    POD_MI8_LightTurret = {
        Type = "Helicopter",
        Name = "MI8AI",
        Health = 6000,
        Config = {
            Armor = "Default",
            Turrets = {
                Back = "LightTurret",
                Side = "LightTurret"
            }
        },
        Seats = {
            FR = "POD_Rifleman",
            FL = "POD_Pilot",
            RR1 = "POD_SMG",
            RR2 = "POD_Rifleman",
            RR3 = "POD_Smoker_Light",
            RR4 = "POD_Rifleman",
            RR5 = "POD_Shotgun",
            RR6 = "POD_Marksman",
            RL1 = "POD_Shotgun",
            RL2 = "POD_Shotgun",
            RL3 = "POD_SMG",
            RL4 = "POD_SMG",
            RL5 = "POD_Rifleman",
            RL6 = "POD_AutoRifleman",
            Back = "POD_HeliGunner",
            Side = "POD_HeliGunner"
        }
    },
    POD_MI8_MedTurret = {
        Type = "Helicopter",
        Name = "MI8AI",
        Health = 6000,
        Config = {
            Armor = "Default",
            Turrets = {
                Back = "LightTurret",
                Side = "LightTurret"
            }
        },
        Seats = {
            FR = "POD_Rifleman",
            FL = "POD_Pilot",
            RR1 = "POD_Rifleman_Heavy",
            RR2 = "POD_Rifleman_Heavy",
            RR3 = "POD_HeavyAuto",
            RR4 = "POD_Rifleman_Heavy",
            RR5 = "POD_Shotgun",
            RR6 = "POD_AutoRifleman",
            RL1 = "POD_Rifleman_Heavy",
            RL2 = "POD_Rifleman_Heavy",
            RL3 = "POD_RPG",
            RL4 = "POD_Rifleman_Heavy",
            RL5 = "POD_Rifleman_Heavy",
            RL6 = "POD_HeavyAuto",
            Back = "POD_HeliGunner",
            Side = "POD_HeliGunner"
        }
    },
    POD_MI8_SpecTurret = {
        Type = "Helicopter",
        Name = "MI8AI",
        Health = 6000,
        Config = {
            Armor = "Default",
            Turrets = {
                Back = "LightTurret",
                Side = "LightTurret"
            }
        },
        Seats = {
            FR = "POD_Spec",
            FL = "POD_Pilot",
            RR1 = "POD_Spec_Shotgun",
            RR2 = "POD_Spec",
            RR3 = "POD_Spec",
            RR4 = "POD_Spec",
            RR5 = "POD_Spec_Shotgun",
            RR6 = "POD_HeavyAuto",
            RL1 = "POD_Spec",
            RL2 = "POD_Spec_Shotgun",
            RL3 = "POD_Spec",
            RL4 = "POD_Spec",
            RL5 = "POD_Smoker",
            RL6 = "POD_HeavyAuto",
            Back = "POD_HeliGunner",
            Side = "POD_HeliGunner"
        }
    },
    POD_MI8_FortSpecial = {
        Type = "Helicopter",
        Name = "MI8AI",
        Health = 6000,
        Config = {
            Armor = "Default",
            Turrets = {
                Back = "LightTurret",
                Side = "LightTurret"
            }
        },
        Seats = {
            FR = "POD_Pilot",
            FL = "POD_Pilot",
            RR1 = "RLF_AutoRifleman",
            RR2 = "RLF_VIP",
            RR3 = "POD_Spec",
            RR4 = "RLF_HeavyAuto",
            RR5 = "RLF_Rifleman_Heavy",
            RR6 = "POD_Sniper",
            RL1 = "POD_Spec",
            RL2 = "RLF_VIP",
            RL3 = "POD_Spec",
            RL4 = "RLF_Rifleman_Heavy",
            RL5 = "POD_Smoker",
            RL6 = "POD_Sniper",
            Back = "POD_HeliGunner",
            Side = "POD_HeliGunner"
        }
    },
    Dummy_M998_LightTurret = {
        Type = "Ground",
        Name = "M998AI",
        Health = 10000,
        Config = {
            Armor = "Heavy",
            Turrets = {
                Back = "LightTurret"
            }
        },
        Seats = {
            FL = "POD_SMG",
            FR = "POD_SMG",
            RL1 = "POD_Shotgun",
            RL2 = "POD_Shotgun",
            RL3 = "POD_Rifleman",
            RR1 = "POD_SMG",
            RR2 = "POD_Smoker_Light",
            RR3 = "POD_Rifleman",
            Back = "POD_Rifleman_Heavy"
        }
    },
    Zombies_DemoBlackhawk = {
        Type = "Helicopter",
        Name = "MH60S",
        Health = 10000,
        Config = {
            Armor = "Heavy",
            Turrets = {
                GunLeft = "LightTurret",
                GunRight = "LightTurret",
                DoorRight = "DoorOpen",
                DoorLeft = "DoorOpen"
            }
        },
        Seats = {
            FR = "PL5_Pilot",
            FL = "PL5_Pilot",
            GunLeft = "PL5_HeliGunner",
            GunRight = "PL5_HeliGunner"
        }
    },
    Islands_DemoBlackhawk = {
        Type = "Helicopter",
        Name = "MH60S",
        Health = 10000,
        Config = {
            Armor = "Heavy",
            Turrets = {
                GunLeft = "LightTurret",
                GunRight = "LightTurret",
                DoorRight = "DoorOpen",
                DoorLeft = "DoorOpen"
            }
        },
        Seats = {
            FR = "POD_Pilot",
            FL = "POD_Pilot",
            GunLeft = "Z_Sheepdog_MG",
            GunRight = "Z_Sheepdog_MG"
        }
    },
    Islands_DemoBlackhawk2 = {
        Type = "Helicopter",
        Name = "UH60",
        Health = 3000,
        Config = {
            Armor = "Heavy",
            Turrets = {
                GunLeft = "LightTurret",
                GunRight = "LightTurret",
                DoorRight = "DoorOpen",
                DoorLeft = "DoorOpen"
            }
        },
        Seats = {
            FR = "POD_Pilot",
            RF1 = "I_Merc2_Rifleman",
            RF2 = "I_Merc2_Rifleman",
            RF3 = "I_Merc2_Rifleman",
            RF4 = "I_Merc2_Rifleman",
            SR1 = "I_Merc2_Rifleman",
            SR2 = "I_Merc2_Rifleman",
            RL1 = "I_Merc2_Rifleman",
            RL2 = "I_Merc2_Marksman",
            Gunleft = "Z_Sheepdog_MG",
            GunRight = "Z_Sheepdog_MG"
        }
    },
    Zombies_Raid1Blackhawk = {
        Type = "Helicopter",
        Name = "UH60",
        Health = 10000,
        Config = {
            Armor = "Heavy",
            Turrets = {
                GunLeft = "LightTurret",
                GunRight = "LightTurret",
                DoorRight = "DoorOpen",
                DoorLeft = "DoorOpen"
            }
        },
        Seats = {
            FR = "PL5_Pilot",
            FL = "PL5_Pilot",
            GunLeft = "Z_Sheepdog_MG",
            GunRight = "Z_Sheepdog_MG"
        }
    },
    Islands_DemoStryker = {
        Type = "Ground",
        Name = "Stryker",
        Health = 10000,
        Config = {
            Armor = "Heavy",
            Camo = "Desert",
            Turrets = {
                Roof = "Turret",
                Engine = "EngineCover"
            }
        },
        Seats = {
            Turret = "I_Merc_Smg"
        }
    }
};