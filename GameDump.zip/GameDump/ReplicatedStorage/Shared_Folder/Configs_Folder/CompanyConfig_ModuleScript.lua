-- Roblox: ReplicatedStorage.Shared.Configs.CompanyConfig
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Capacity = {
        Barracks = {
            15,
            30,
            60,
            90
        },
        Logistics = {
            4,
            8,
            10,
            15
        },
        Operations = { 3, 6, 8 },
        Training = { 0, 6, 12 },
        Command = { 2, 5, 10 },
        Deliveries = { 2, 4, 6 },
        Garage = { 2, 6 },
        PlaneHangers = { 3, 6 },
        HeliHangers = { 2, 6, 10 },
        Research = { 0, 10 },
        Defenses = {
            3,
            6,
            10,
            15,
            20
        },
        Infirmary = { 5, 8, 12 }
    },
    DefenseProtection = {
        0.2,
        0.15,
        0.1,
        0.05,
        0.01
    },
    MaterialValue = {
        Material = 100,
        Metal = 750,
        Fuel = 150,
        Equipment = 300
    },
    Destinations = {
        {
            Name = "Brisbane, Australia",
            Position = Vector2.new(0.91, 0.684)
        },
        {
            Name = "Tokyo, Japan",
            Position = Vector2.new(0.883, 0.42)
        },
        {
            Name = "New York, U.S.",
            Position = Vector2.new(0.269, 0.413)
        },
        {
            Name = "Los Angeles, U.S.",
            Position = Vector2.new(0.165, 0.437)
        },
        {
            Name = "Seoul, South Korea",
            Position = Vector2.new(0.851, 0.423)
        },
        {
            Name = "London, U.K.",
            Position = Vector2.new(0.482, 0.342)
        },
        {
            Name = "Paris, France",
            Position = Vector2.new(0.5, 0.37)
        },
        {
            Name = "Chicago, U.S.",
            Position = Vector2.new(0.251, 0.342)
        },
        {
            Name = "Manila, Philippines",
            Position = Vector2.new(0.837, 0.522)
        }
    },
    VehicleSlots = {
        Ground = { 6, 9 },
        Helicopter = { 3, 6, 10 },
        Plane = { 4, 6 }
    },
    LoadoutSlots = { 4, 6, 8 },
    Upgradeables = {
        {
            ID = "Main",
            Name = "Airbase",
            Levels = {
                {
                    Image = "rbxassetid://76621790311396",
                    Description = "<stroke color=\"rgb(255,0,0)\" thickness=\".25\" transparency=\"0\">Overgrown Airstrip</stroke>\n\n<b>Cleanup required to upgrade base facilities.</b>\n\n<font transparency=\"0.5\"><i>Nature has reclaimed much of the airstrip since its abandonment. It is unuseable for major operational purposes.</i></font>",
                    Cost = 0,
                    Resources = {
                        Material = 0,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 0
                    }
                },
                {
                    Image = "rbxassetid://136596565914706",
                    Description = "<stroke color=\"rgb(255,255,0)\" thickness=\".25\" transparency=\"0\">Restored Airstrip</stroke>\n\n<b>Bare minimum for a functional airbase.</b>\n\n<font transparency=\"0.5\"><i>Runway area clear cut and packed down. We can work with this.</i></font>\n",
                    Cost = 5000,
                    Resources = {
                        Material = 5,
                        Metal = 0,
                        Fuel = 10,
                        Equipment = 0
                    }
                },
                {
                    Image = "rbxassetid://74422964427387",
                    Description = "<stroke color=\"rgb(0,255,0)\" thickness=\".25\" transparency=\"0\">Renovated Airbase</stroke>\n\n<b>Required for high-tier upgrades.</b>\n\n<font transparency=\"0.5\"><i>Paved runway and roads give us easier access to, from and around the airbase. Rusty metal barriers polished to reduce risk of tetanus.</i></font>",
                    Cost = 30000,
                    Resources = {
                        Material = 30,
                        Metal = 5,
                        Fuel = 40,
                        Equipment = 5
                    }
                }
            }
        },
        {
            ID = "Barracks",
            Name = "Barracks",
            Levels = {
                {
                    Image = "rbxassetid://102259969614691",
                    Description = "<stroke color=\"rgb(255,0,0)\" thickness=\".25\" transparency=\"0\">Ruined barracks</stroke>\n\n<b>15</b> total HQ staff capacity\n\n<font transparency=\"0.5\"><i>These buildings have been abandoned a long time. It\'ll take some work to get them fixed up.</i></font>",
                    Cost = 0,
                    Resources = {
                        Material = 0,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 0
                    }
                },
                {
                    Image = "rbxassetid://127428037402076",
                    Description = "<stroke color=\"rgb(255,255,0)\" thickness=\".25\" transparency=\"0\">Repaired barracks</stroke>\n\n<b>30</b> total HQ staff capacity\n\n<font transparency=\"0.5\"><i>Brought back to habitability with some supplies and grit. Not comfortable, but good enough.</i></font><i>\nRequires airbase level 2</i>",
                    Cost = 1000,
                    Requires = {
                        Main = 2
                    },
                    Resources = {
                        Material = 5,
                        Metal = 0,
                        Fuel = 5,
                        Equipment = 1
                    }
                },
                {
                    Image = "rbxassetid://90611961761800",
                    Description = "<stroke color=\"rgb(0,255,0)\" thickness=\".25\" transparency=\"0\">Renovated barracks</stroke>\n\n<b>60</b> total HQ staff capacity\n\n<font transparency=\"0.5\"><i>A modern and comfortable living space for the full HQ staff.</i></font><i>\nRequires airbase level 3</i>",
                    Cost = 10000,
                    Requires = {
                        Main = 3
                    },
                    Resources = {
                        Material = 5,
                        Metal = 2,
                        Fuel = 10,
                        Equipment = 10
                    }
                },
                {
                    Image = "rbxassetid://72303642617854",
                    Description = "<stroke color=\"rgb(0,255,0)\" thickness=\".25\" transparency=\"0\">Additional Buildings</stroke>\n\n<b>90</b> total HQ staff capacity\n\n<font transparency=\"0.5\"><i>Clear-cutting the forest next to Operations gives us space for another two barracks buildings.</i></font><i>\nRequires airbase level 3</i>",
                    Cost = 20000,
                    Requires = {
                        Main = 3
                    },
                    Resources = {
                        Material = 40,
                        Metal = 0,
                        Fuel = 10,
                        Equipment = 10
                    }
                }
            }
        },
        {
            ID = "Logistics",
            Name = "Logistics and Storage",
            Levels = {
                {
                    Image = "rbxassetid://87546028113205",
                    Description = "<stroke color=\"rgb(255,0,0)\" thickness=\".25\" transparency=\"0\">Empty Lot</stroke>\n\n<b>4</b> staff capacity\n\n<font transparency=\"0.5\"><i>An empty lot covered in debris. Can be cleaned up and used as our logistics depot.</i></font>",
                    Cost = 0,
                    Resources = {
                        Material = 0,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 0
                    }
                },
                {
                    Image = "rbxassetid://71763217816593",
                    Description = "<stroke color=\"rgb(255,100,0)\" thickness=\".25\" transparency=\"0\">Basic Depot</stroke>\n\n<b>8</b> staff capacity\n\n<font transparency=\"0.5\"><i>An empty plot of land where we can store resources.<i>\nRequires airbase level 2</i></i></font>",
                    Cost = 1000,
                    Requires = {
                        Main = 2
                    },
                    Resources = {
                        Material = 5,
                        Metal = 0,
                        Fuel = 5,
                        Equipment = 0
                    }
                },
                {
                    Image = "rbxassetid://75688950647504",
                    Description = "<stroke color=\"rgb(255,255,0)\" thickness=\".25\" transparency=\"0\">Upgraded Depot</stroke>\n\n<b>10</b> staff capacity\n\n<font transparency=\"0.5\"><i>Minor capacity improvements to the temporary depot.</i></font><i>\nRequires airbase level 2</i>",
                    Cost = 7500,
                    Requires = {
                        Main = 2
                    },
                    Resources = {
                        Material = 10,
                        Metal = 0,
                        Fuel = 10,
                        Equipment = 3
                    }
                },
                {
                    Image = "rbxassetid://116625009454736",
                    Description = "<stroke color=\"rgb(0,255,0)\" thickness=\".25\" transparency=\"0\">Logistics Warehouse</stroke>\n\n<b>15</b> staff capacity\n\n<font transparency=\"0.5\"><i>A proper warehouse constructed to fit a large amount of resources and logistics personnel.</i></font><i>\nRequires airbase level 3</i>",
                    Cost = 10000,
                    Requires = {
                        Main = 3
                    },
                    Resources = {
                        Material = 20,
                        Metal = 2,
                        Fuel = 20,
                        Equipment = 3
                    }
                }
            }
        },
        {
            ID = "Garage",
            Name = "Ground Mechanics",
            Levels = {
                {
                    Image = "rbxassetid://118430413073700",
                    Description = "<stroke color=\"rgb(255,255,0)\" thickness=\".25\" transparency=\"0\">Basic Mechanics</stroke>\n\n<b>2</b> staff capacity\n<b>6</b> vehicle slots\n\n<font transparency=\"0.5\"><i>Temporary station for our ground vehicle mechanics. Enough to get by, though working out of the heat would be preferable.</i></font>",
                    Cost = 0,
                    Resources = {
                        Material = 0,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 0
                    }
                },
                {
                    Image = "rbxassetid://72080205351115",
                    Description = "<stroke color=\"rgb(0,255,0)\" thickness=\".25\" transparency=\"0\">Mechanics Workshop</stroke>\n\n<b>6</b> staff capacity\n<b>9</b> vehicle slots\n\n<font transparency=\"0.5\"><i>Constructed garage fit for our mechanics to work in comfort.</i></font><i>\nRequires airbase level 3</i>",
                    Cost = 7500,
                    Requires = {
                        Main = 3
                    },
                    Resources = {
                        Material = 40,
                        Metal = 5,
                        Fuel = 60,
                        Equipment = 4
                    }
                }
            }
        },
        {
            ID = "Deliveries",
            Name = "Deliveries",
            Levels = {
                {
                    Image = "rbxassetid://102300772435703",
                    Description = "<stroke color=\"rgb(255,0,0)\" thickness=\".25\" transparency=\"0\">Dilapidated Hangars</stroke>\n\n<b>2</b> staff capacity\n\n<font transparency=\"0.5\"><i>Old jet shelters are more of a hinderance than a help for our delivery unit.</i></font>",
                    Cost = 0,
                    Resources = {
                        Material = 0,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 0
                    }
                },
                {
                    Image = "rbxassetid://129146417907296",
                    Description = "<stroke color=\"rgb(255,255,0)\" thickness=\".25\" transparency=\"0\">Basic Delivery Bay</stroke>\n\n<b>4</b> staff capacity\n\n<font transparency=\"0.5\"><i>Some cleared space gives our delivery unit some room to breathe and load cargo into their aircraft.</i></font><i>\nRequires airbase level 2</i>",
                    Cost = 3500,
                    Requires = {
                        Main = 2
                    },
                    Resources = {
                        Material = 5,
                        Metal = 0,
                        Fuel = 10,
                        Equipment = 1
                    }
                },
                {
                    Image = "rbxassetid://85106845953645",
                    Description = "<stroke color=\"rgb(0,255,0)\" thickness=\".25\" transparency=\"0\">Second Delivery Bay</stroke>\n\n<b>6</b> staff capacity\n\n<font transparency=\"0.5\"><i>More cleared space gives our delivery unit another area to load cargo.</i></font><i>\nRequires airbase level 2</i>",
                    Cost = 8000,
                    Requires = {
                        Main = 2
                    },
                    Resources = {
                        Material = 10,
                        Metal = 5,
                        Fuel = 30,
                        Equipment = 5
                    }
                }
            }
        },
        {
            ID = "Operations",
            Name = "Operations Centre",
            Levels = {
                {
                    Image = "rbxassetid://132600663570993",
                    Description = "<stroke color=\"rgb(255,0,0)\" thickness=\".25\" transparency=\"0\">Ruined Operations Center</stroke>\n\n<b>3</b> staff capacity\n\n<font transparency=\"0.5\"><i>Another abandoned building on the airbase. Operators can plan and control resource gathering from here.</i></font>",
                    Cost = 0,
                    Resources = {
                        Material = 0,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 0
                    }
                },
                {
                    Image = "rbxassetid://138786874479196",
                    Description = "<stroke color=\"rgb(255,255,0)\" thickness=\".25\" transparency=\"0\">Additional Equipment</stroke>\n\n<b>6</b> staff capacity\n\n<font transparency=\"0.5\"><i>Providing our operators a larger pool of supplies and equipment will give them more options on how to approach their assignments.</i></font><i>\nRequires airbase level 2, command level 2</i>",
                    Cost = 2500,
                    Requires = {
                        Main = 2,
                        Command = 2
                    },
                    Resources = {
                        Material = 10,
                        Metal = 0,
                        Fuel = 10,
                        Equipment = 1
                    }
                },
                {
                    Image = "rbxassetid://134978047490544",
                    Description = "<stroke color=\"rgb(0,255,0)\" thickness=\".25\" transparency=\"0\">Renovated Operations Center</stroke>\n\n<b>8</b> staff capacity\n\n<font transparency=\"0.5\"><i>Refurbished building, giving our operators a more comfortable space to work out of.</i></font><i>\nRequires airbase level 3, command level 2</i>",
                    Cost = 7500,
                    Requires = {
                        Main = 3,
                        Command = 2
                    },
                    Resources = {
                        Material = 20,
                        Metal = 0,
                        Fuel = 30,
                        Equipment = 4
                    }
                }
            }
        },
        {
            ID = "Training",
            Name = "Training Centre",
            Levels = {
                {
                    Image = "rbxassetid://135130273337654",
                    Description = "<stroke color=\"rgb(225,255,0)\" thickness=\".25\" transparency=\"0\">Overgrown Lot</stroke>\n\n<b>0</b> staff capacity\n\n<font transparency=\"0.5\"><i>We could use this as a shooting range if we clear the overgrowth.</i></font>",
                    Cost = 0,
                    Resources = {
                        Material = 0,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 0
                    }
                },
                {
                    Image = "rbxassetid://99173173802724",
                    Description = "<stroke color=\"rgb(225,255,0)\" thickness=\".25\" transparency=\"0\">Shooting Range</stroke>\n\n<b>6</b> staff capacity\n\n<font transparency=\"0.5\"><i>A simple shooting range where staff can learn from other staff to increase their skills.</i></font><i>\nRequires airbase level 2</i>",
                    Cost = 5000,
                    Requires = {
                        Main = 2
                    },
                    Resources = {
                        Material = 0,
                        Metal = 0,
                        Fuel = 10,
                        Equipment = 1
                    }
                },
                {
                    Image = "rbxassetid://78728855800862",
                    Description = "<stroke color=\"rgb(0,255,0)\" thickness=\".25\" transparency=\"0\">Major Renovation</stroke>\n\n<b>12</b> staff capacity\n\n<font transparency=\"0.5\"><i>Upgraded shooting range and additional shoothouse training course.</i></font><i>\nRequires airbase level 3</i>",
                    Cost = 10000,
                    Requires = {
                        Main = 3
                    },
                    Resources = {
                        Material = 30,
                        Metal = 0,
                        Fuel = 10,
                        Equipment = 4
                    }
                }
            }
        },
        {
            ID = "HeliHangers",
            Name = "Helicopter Mechanics",
            Levels = {
                {
                    Image = "rbxassetid://83325748162910",
                    Description = "<stroke color=\"rgb(255,0,0)\" thickness=\".25\" transparency=\"0\">Abandoned Helicopter Hangars</stroke>\n\n<b>2</b> staff capacity\n<b>3</b> helicopter slots\n\n<font transparency=\"0.5\"><i>Makeshift helipad and hangar. Minimal space for stored helicopters. Poorly equipped for maintenance.</i></font>",
                    Cost = 0,
                    Resources = {
                        Material = 0,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 0
                    }
                },
                {
                    Image = "rbxassetid://95552994433360",
                    Description = "<stroke color=\"rgb(255,255,0)\" thickness=\".25\" transparency=\"0\">Improved Helicopter Hangars</stroke>\n\n<b>6</b> staff capacity\n<b>6</b> helicopter slots\n\n<font transparency=\"0.5\"><i>Opened second hangar and cleared helipad. Enough to get by and get more work done.</i></font><i>\nRequires airbase level 2</i>",
                    Cost = 5000,
                    Requires = {
                        Main = 2,
                        Command = 2
                    },
                    Resources = {
                        Material = 0,
                        Metal = 0,
                        Fuel = 20,
                        Equipment = 3
                    }
                },
                {
                    Image = "rbxassetid://111330007348375",
                    Description = "<stroke color=\"rgb(0,255,0)\" thickness=\".25\" transparency=\"0\">Renovated Helicopter Hangars</stroke>\n\n<b>10</b> staff capacity\n<b>10</b> helicopter slots\n\n<font transparency=\"0.5\"><i>Repaired buildings, paved helipads, and extra equipment.</i></font><i>\nRequires airbase level 3</i>",
                    Cost = 15000,
                    Requires = {
                        Main = 3
                    },
                    Resources = {
                        Material = 40,
                        Metal = 2,
                        Fuel = 40,
                        Equipment = 5
                    }
                }
            }
        },
        {
            ID = "Command",
            Name = "Airbase Management",
            Levels = {
                {
                    Image = "rbxassetid://108301267212425",
                    Description = "<stroke color=\"rgb(255,0,0)\" thickness=\".25\" transparency=\"0\">Basic Command Center</stroke>\n\n<b>2</b> staff capacity\n\n<font transparency=\"0.5\"><i>HQ main office, the beating heart of our operation. Not yet comfortable enough to support a full command staff.</i></font>",
                    Cost = 0,
                    Resources = {
                        Material = 0,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 0
                    }
                },
                {
                    Image = "rbxassetid://71096359230257",
                    Description = "<stroke color=\"rgb(255,255,0)\" thickness=\".25\" transparency=\"0\">Finished First Floor</stroke>\n\n<b>5</b> staff capacity\n\n<font transparency=\"0.5\"><i>Completed renovations of the ground floor. Command staff can now feel confident hiring new personnel.</i></font><i>\nRequires airbase level 2</i>",
                    Cost = 2500,
                    Requires = {
                        Main = 2
                    },
                    Resources = {
                        Material = 15,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 2
                    }
                },
                {
                    Image = "rbxassetid://98986320040869",
                    Description = "<stroke color=\"rgb(0,255,0)\" thickness=\".25\" transparency=\"0\">Renovated Second Floor</stroke>\n\n<b>10</b> staff capacity\n\n<font transparency=\"0.5\"><i>Furnishing our second floor with more workstations and tech gives our staff all the space needed for large-scale recruitment campaigns.</i></font><i>\nRequires airbase level 3</i>",
                    Cost = 10000,
                    Requires = {
                        Main = 3
                    },
                    Resources = {
                        Material = 10,
                        Metal = 2,
                        Fuel = 0,
                        Equipment = 5
                    }
                }
            }
        },
        {
            ID = "WeaponShop",
            Name = "Gunsmith",
            Levels = {
                {
                    Image = "rbxassetid://90200877573897",
                    Description = "<stroke color=\"rgb(255,0,0)\" thickness=\".25\" transparency=\"0\">Unfinished Gunsmith</stroke>\n\n<b>4</b> loadout slots\n\n<font transparency=\"0.5\"><i>We\'ll need some more supplies to get the workshop functional.</i></font>",
                    Cost = 0,
                    Resources = {
                        Material = 0,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 0
                    }
                },
                {
                    Image = "rbxassetid://90200877573897",
                    Description = "<stroke color=\"rgb(255,255,0)\" thickness=\".25\" transparency=\"0\">Further renovations</stroke>\n\n<b>6</b> loadout slots\n\n<font transparency=\"0.5\"><i>Additional tools, equipment, and furnishings. Ventilation installed to comply with international shop safety standards.</i></font><i>\nRequires airbase level 2</i>",
                    Cost = 7500,
                    Requires = {
                        Main = 2
                    },
                    Resources = {
                        Material = 5,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 2
                    }
                },
                {
                    Image = "rbxassetid://83927859911237",
                    Description = "<stroke color=\"rgb(0,255,0)\" thickness=\".25\" transparency=\"0\">Complete Gunsmith</stroke>\n\n<b>8</b> loadout slots\n\n<font transparency=\"0.5\"><i>Fully renovated and equipped with machines to maintain our weapons and gear.</i></font><i>\nRequires airbase level 3</i>",
                    Cost = 10000,
                    Requires = {
                        Main = 3
                    },
                    Resources = {
                        Material = 15,
                        Metal = 3,
                        Fuel = 0,
                        Equipment = 6
                    }
                }
            }
        },
        {
            ID = "Infirmary",
            Name = "Infirmary",
            Levels = {
                {
                    Image = "rbxassetid://133288043948094",
                    Description = "<stroke color=\"rgb(255,255,0)\" thickness=\".25\" transparency=\"0\">Basic Infirmary</stroke>\n\n<b>5</b> staff slots\n\n<font transparency=\"0.5\"><i>A barebones medical department set up in an abandoned shack.</i></font>",
                    Cost = 0,
                    Resources = {
                        Material = 0,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 0
                    }
                },
                {
                    Image = "rbxassetid://126855177170716",
                    Description = "<stroke color=\"rgb(255,255,0)\" thickness=\".25\" transparency=\"0\">Renovated Building</stroke>\n\n<b>8</b> staff slots\n\n<font transparency=\"0.5\"><i>Re-built walls and ventilation allow for a more sterile environment. Additional equipment allows for more patient care.</i></font><i>\nRequires airbase level 2</i>",
                    Cost = 8000,
                    Requires = {
                        Main = 2
                    },
                    Resources = {
                        Material = 8,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 3
                    }
                },
                {
                    Image = "rbxassetid://73476090177335",
                    Description = "<stroke color=\"rgb(255,255,0)\" thickness=\".25\" transparency=\"0\">Equipment Investment</stroke>\n\n<b>12</b> staff slots\n\n<font transparency=\"0.5\"><i>Hospital beds, cabinetry, and other equipment allow multiple doctors to give high-quality care.</i></font><i>\nRequires airbase level 2</i>",
                    Cost = 30000,
                    Requires = {
                        Main = 2
                    },
                    Resources = {
                        Material = 0,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 6
                    }
                }
            }
        },
        {
            ID = "Defenses",
            Name = "Defenses",
            Levels = {
                {
                    Image = "rbxassetid://118362186763738",
                    Description = "<stroke color=\"rgb(255,0,0)\" thickness=\".25\" transparency=\"0\">Aged defenses</stroke>\n\n<b>3</b> defender capacity\n\n<font transparency=\"0.5\"><i>Time hasn\'t been kind to the airbase\'s old defenses.</i></font>",
                    Cost = 0,
                    Resources = {
                        Material = 0,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 0
                    }
                },
                {
                    Image = "rbxassetid://128260807214136",
                    Description = "<stroke color=\"rgb(255,255,0)\" thickness=\".25\" transparency=\"0\">Basic Defenses</stroke>\n\n<b>6</b> defender capacity\n\n<font transparency=\"0.5\"><i>Fortifying the gate entrance will give us an advantage against ground assaults. </i></font><i>\nRequires airbase level 2</i>",
                    Cost = 4000,
                    Requires = {
                        Main = 1
                    },
                    Resources = {
                        Material = 7,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 0
                    }
                },
                {
                    Image = "rbxassetid://107786237922684",
                    Description = "<stroke color=\"rgb(255,255,0)\" thickness=\".25\" transparency=\"0\">Mortar Post</stroke>\n\n<b>10</b> defender capacity\n\n<font transparency=\"0.5\"><i>Setting up a mortar and defensive command center will provide a massive advantage.</i></font><i>\nRequires airbase level 2</i>",
                    Cost = 7500,
                    Requires = {
                        Main = 2
                    },
                    Resources = {
                        Material = 0,
                        Metal = 0,
                        Fuel = 5,
                        Equipment = 5
                    }
                },
                {
                    Image = "rbxassetid://114391573954362",
                    Description = "<stroke color=\"rgb(255,255,0)\" thickness=\".25\" transparency=\"0\">Watchtowers</stroke>\n\n<b>15</b> defender capacity\n\n<font transparency=\"0.5\"><i>Building a few watchtowers will give us eyes over nearly the whole island, and we can improve the gear of our defenders.</i></font><i>\nRequires airbase level 2</i>",
                    Cost = 20000,
                    Requires = {
                        Main = 2
                    },
                    Resources = {
                        Material = 15,
                        Metal = 0,
                        Fuel = 5,
                        Equipment = 7
                    }
                },
                {
                    Image = "rbxassetid://118965266265529",
                    Description = "<stroke color=\"rgb(255,255,0)\" thickness=\".25\" transparency=\"0\">Heavy Utilities</stroke>\n\n<b>20</b> defender capacity\n\n<font transparency=\"0.5\"><i>We\'ve found a line on purchasing some radar, artillery, and anti-air trailers.</i></font><i>\nRequires airbase level 2</i>",
                    Cost = 40000,
                    Requires = {
                        Main = 3
                    },
                    Resources = {
                        Material = 0,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 10
                    }
                }
            }
        },
        {
            ID = "Research",
            Name = "Research",
            Levels = {
                {
                    Image = "rbxassetid://80989367047679",
                    Description = "<stroke color=\"rgb(255,0,0)\" thickness=\".25\" transparency=\"0\">Empty lot</stroke>\n\n\n\n<font transparency=\"0.5\"><i>We\'ll have to clear-cut this area to build something new.</i></font>",
                    Cost = 0,
                    Resources = {
                        Material = 0,
                        Metal = 0,
                        Fuel = 0,
                        Equipment = 0
                    }
                },
                {
                    Image = "rbxassetid://72460481285453",
                    Description = "<stroke color=\"rgb(255,255,0)\" thickness=\".25\" transparency=\"0\">Basic R&D department</stroke>\n\n\n\n<font transparency=\"0.5\"><i>A site for technicians to research new technologies.</i></font><i>\nRequires airbase level 3</i>",
                    Cost = 30000,
                    Requires = {
                        Main = 3
                    },
                    Resources = {
                        Material = 25,
                        Metal = 5,
                        Fuel = 10,
                        Equipment = 5
                    }
                }
            }
        }
    }
};