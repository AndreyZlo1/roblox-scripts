-- Roblox: ReplicatedStorage.Shared.Configs.FootstepMaterials
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    [Enum.Material.Grass] = "Grass",
    [Enum.Material.LeafyGrass] = "Grass",
    [Enum.Material.Mud] = "Dirt",
    [Enum.Material.Ground] = "Gravel",
    [Enum.Material.Cobblestone] = "Gravel",
    [Enum.Material.Pebble] = "Gravel",
    [Enum.Material.Sand] = "Sand",
    [Enum.Material.Limestone] = "Sand",
    [Enum.Material.Sandstone] = "Sand",
    [Enum.Material.Plastic] = "Concrete",
    [Enum.Material.SmoothPlastic] = "Concrete",
    [Enum.Material.Brick] = "Concrete",
    [Enum.Material.Pebble] = "Concrete",
    [Enum.Material.Pavement] = "Concrete",
    [Enum.Material.Concrete] = "Concrete",
    [Enum.Material.Foil] = "Concrete",
    [Enum.Material.Marble] = "Concrete",
    [Enum.Material.Snow] = "Snow",
    [Enum.Material.Salt] = "Snow",
    [Enum.Material.Glacier] = "Snow",
    [Enum.Material.Wood] = "Wood1",
    [Enum.Material.WoodPlanks] = "Wood2",
    [Enum.Material.Metal] = "Metal",
    [Enum.Material.CorrodedMetal] = "Metal",
    [Enum.Material.DiamondPlate] = "Metal",
    [Enum.Material.Leather] = "Goop",
    asphalt_snow_paint = "SnowyConcrete",
    asphalt_snow = "SnowyConcrete",
    asphalt_snow2 = "SnowyConcrete",
    concrete_tile2_snow = "SnowyConcrete",
    concrete_tile5_snow2 = "SnowyConcrete",
    concrete_tile5_snow = "SnowyConcrete",
    concrete_worn4_snow = "SnowyConcrete",
    plastic_trash = "Trash",
    plastic_trashbags = "Trash"
};