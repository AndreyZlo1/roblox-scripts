-- Roblox: ReplicatedStorage.Shared.Configs.Boxes
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    shotgun_12gauge = {
        Capacity = 5,
        Name = "Ammunition box (12-gauge)",
        FamilyName = "12-gauge",
        Size = Vector2.new(1, 1)
    },
    pistol_9x18mmMakarov = {
        Capacity = 50,
        Name = "Ammunition box (9×18mm Makarov)",
        FamilyName = "9×18mm Makarov",
        Size = Vector2.new(2, 1)
    },
    pistol_9x19mmParabellum = {
        Capacity = 50,
        Name = "Ammunition box (9×19mm Parabellum)",
        FamilyName = "9×19mm Parabellum",
        Size = Vector2.new(2, 1)
    },
    pistol_9x21Gyurza = {
        Capacity = 50,
        Name = "Ammunition box (9×21mm Gyurza)",
        FamilyName = "9×21mm Gyurza",
        Size = Vector2.new(2, 1)
    },
    pistol_45Auto = {
        Capacity = 50,
        Name = "Ammunition box (.45 Auto)",
        FamilyName = ".45 Auto",
        Size = Vector2.new(2, 1)
    },
    pistol_44MillingtonMagnum = {
        Capacity = 50,
        Name = "Ammunition box (.44 Millington Magnum)",
        FamilyName = ".44 Millington Magnum",
        Size = Vector2.new(2, 1)
    },
    pistol_357MillingtonMagnum = {
        Capacity = 50,
        Name = "Ammunition box (.357 Millington Magnum)",
        FamilyName = ".357 Millington Magnum",
        Size = Vector2.new(2, 1)
    },
    personaldefenseweapon_46x30mm = {
        Capacity = 50,
        Name = "Ammunition box (4.6×30mm)",
        FamilyName = "4.6×30mm",
        Size = Vector2.new(2, 1)
    },
    personaldefenseweapon_57x28mm = {
        Capacity = 50,
        Name = "Ammunition box (5.7×28mm)",
        FamilyName = "5.7×28mm",
        Size = Vector2.new(2, 1)
    },
    intermediaterifle_545x39mm = {
        Capacity = 30,
        Name = "Ammunition box (5.45×39mm)",
        FamilyName = "5.45×39mm",
        Size = Vector2.new(2, 1)
    },
    intermediaterifle_556x45mmNATO = {
        Capacity = 20,
        Name = "Ammunition box (5.56×45mm NATO)",
        FamilyName = "5.56×45mm NATO",
        Size = Vector2.new(1, 1)
    },
    intermediaterifle_300SRCKnockout = {
        Capacity = 20,
        Name = "Ammunition box (.300 SRC Knockout)",
        FamilyName = ".300 SRC Knockout",
        Size = Vector2.new(1, 1)
    },
    intermediaterifle_9x39mm = {
        Capacity = 20,
        Name = "Ammunition box (9×39mm)",
        FamilyName = "9×39mm",
        Size = Vector2.new(1, 1)
    },
    intermediaterifle_762x39mm = {
        Capacity = 20,
        Name = "Ammunition box (7.62×39mm)",
        FamilyName = "7.62×39mm",
        Size = Vector2.new(2, 1)
    },
    fullpowerrifle_762x54mmR = {
        Capacity = 20,
        Name = "Ammunition box (7.62×54mmR)",
        FamilyName = "7.62×54mmR",
        Size = Vector2.new(2, 1)
    },
    fullpowerrifle_762x51mmNATO = {
        Capacity = 20,
        Name = "Ammunition box (7.62×51mm NATO)",
        FamilyName = "7.62×51mm NATO",
        Size = Vector2.new(2, 1)
    },
    fullpowerrifle_65x48mmFidelis = {
        Capacity = 20,
        Name = "Ammunition box (6.5×48mm Fidelis)",
        FamilyName = "6.5×48mm Fidelis",
        Size = Vector2.new(2, 1)
    },
    fullpowerrifle_300WinchesterMagnum = {
        Capacity = 20,
        Name = "Ammunition box (.300 Winchester Magnum)",
        FamilyName = ".300 Winchester Magnum",
        Size = Vector2.new(2, 1)
    },
    fullpowerrifle_338LapuaMagnum = {
        Capacity = 20,
        Name = "Ammunition box (.338 Lapua Magnum)",
        FamilyName = ".338 Lapua Magnum",
        Size = Vector2.new(2, 1)
    },
    fullpowerrifle_127x99mmNATO = {
        Capacity = 10,
        Name = "Ammunition box (12.7×99mm NATO)",
        FamilyName = "12.7×99mm NATO",
        Size = Vector2.new(2, 2)
    },
    fullpowerrifle_127x108mm = {
        Capacity = 10,
        Name = "Ammunition box (12.7×108mm)",
        FamilyName = "12.7×108mm",
        Size = Vector2.new(2, 2)
    },
    Z12gauge = {
        Capacity = 20,
        Name = "Ammunition box (12-gauge)",
        FamilyName = "12-gauge",
        Size = Vector2.new(2, 2)
    },
    fullpowerrifle_762x51mmNATO_canister = {
        Capacity = 200,
        Name = "Ammunition box (7.62×51mm NATO)",
        FamilyName = "7.62×51mm NATO",
        Size = Vector2.new(5, 5)
    },
    intermediaterifle_556x45mmNATO_canister = {
        Capacity = 840,
        Name = "Ammunition case (5.56×45mm NATO)",
        FamilyName = "5.56×45mm NATO",
        Size = Vector2.new(5, 5)
    },
    pistol_9x19mmParabellum_canister = {
        Capacity = 2000,
        Name = "Ammunition case (9×19mm Parabellum)",
        FamilyName = "9×19mm Parabellum",
        Size = Vector2.new(5, 5)
    },
    pistol_45Auto_canister = {
        Capacity = 1000,
        Name = "Ammunition box (.45 Auto)",
        FamilyName = ".45 Auto",
        Size = Vector2.new(5, 5)
    },
    fullpowerrifle_127x99mmNATO_canister = {
        Capacity = 100,
        Name = "Ammunition box (12.7×99mm NATO)",
        FamilyName = "12.7×99mm NATO",
        Size = Vector2.new(5, 5)
    }
};