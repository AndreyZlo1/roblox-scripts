-- Roblox: ReplicatedStorage.Shared.Configs.Extraction.ExtractionGrades
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    {
        "S",
        "rbxassetid://121202623628370",
        Color3.new(0.615686, 0.035294, 1),
        100000
    },
    {
        "A",
        "rbxassetid://77745584808899",
        Color3.new(0.035294, 1, 0),
        50000
    },
    {
        "B",
        "rbxassetid://107346726183955",
        Color3.new(0.709803, 1, 0.168627),
        20000
    },
    {
        "C",
        "rbxassetid://105806166596134",
        Color3.new(1, 0.913725, 0.137254),
        10000
    },
    {
        "D",
        "rbxassetid://134828571593649",
        Color3.new(1, 0.62745, 0.203921),
        5000
    },
    {
        "E",
        "rbxassetid://79252035965448",
        Color3.new(1, 0.349019, 0.149019),
        0
    },
    { "F", "rbxassetid://83823417562219", Color3.new(1, 0, 0) }
};