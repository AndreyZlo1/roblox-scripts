-- Roblox: ReplicatedStorage.Shared.Configs.Extraction.ExtractionConfig
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Values = {
        KillsZombies = 40,
        KillsHPCombatants = 1000,
        KillsLPCombatants = 150,
        DistanceTravelled = 0.33,
        TimeSurvived = 100,
        HealingDone = 20,
        DamageTaken = 7.5
    }
};