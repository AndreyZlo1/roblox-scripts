-- Roblox: ReplicatedStorage.Shared.Configs.ImpactMaterials
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    [Enum.Material.Grass] = "Grass",
    [Enum.Material.LeafyGrass] = "Grass",
    [Enum.Material.Ground] = "Dirt",
    [Enum.Material.Mud] = "Dirt",
    [Enum.Material.Sand] = "Sand",
    [Enum.Material.Limestone] = "Sand",
    [Enum.Material.Sandstone] = "Sand",
    [Enum.Material.Plastic] = "Concrete",
    [Enum.Material.SmoothPlastic] = "Concrete",
    [Enum.Material.Brick] = "Concrete",
    [Enum.Material.Pebble] = "Concrete",
    [Enum.Material.Pavement] = "Concrete",
    [Enum.Material.Concrete] = "Concrete",
    [Enum.Material.Foil] = "Concrete",
    [Enum.Material.Cobblestone] = "Concrete",
    [Enum.Material.Wood] = "Wood",
    [Enum.Material.WoodPlanks] = "Wood",
    [Enum.Material.Slate] = "Rock",
    [Enum.Material.Basalt] = "Rock",
    [Enum.Material.Asphalt] = "Rock",
    [Enum.Material.Rock] = "Rock",
    [Enum.Material.CrackedLava] = "Rock",
    [Enum.Material.Granite] = "Rock",
    [Enum.Material.Snow] = "Snow",
    [Enum.Material.Salt] = "Snow",
    [Enum.Material.Glacier] = "Snow",
    [Enum.Material.Fabric] = "Fabric",
    [Enum.Material.Glass] = "Glass",
    [Enum.Material.Ice] = "Glass",
    [Enum.Material.Metal] = "Metal",
    [Enum.Material.Marble] = "Metal",
    [Enum.Material.CorrodedMetal] = "AutomotiveMetal",
    [Enum.Material.DiamondPlate] = "Metal",
    glass_broken = "AutomotiveGlass",
    wood_log = "Plywood"
};