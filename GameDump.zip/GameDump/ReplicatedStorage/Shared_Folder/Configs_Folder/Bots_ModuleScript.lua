-- Roblox: ReplicatedStorage.Shared.Configs.Bots
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
for _, v2 in script:WaitForChild("BotPresets"):GetChildren() do
    for v3, v4 in require(v2) do
        v1[v3] = v4;
    end;
end;
return v1;