-- Roblox: ReplicatedStorage.Shared.AttachmentIcons
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    NVG = "rbxassetid://107264073780157",
    Flashlight = "rbxassetid://94671277300288",
    Laser = "rbxassetid://80869371694404",
    Multi = "rbxassetid://84888679083683",
    Tube = "rbxassetid://85634564687013",
    Gear = "rbxassetid://135554724887859",
    Strobe = "rbxassetid://85998215295545"
};