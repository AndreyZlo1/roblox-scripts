-- Roblox: ReplicatedStorage.LocalAssets.Worlds.Default.Water
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Height = -400,
    Depth = -500,
    Enabled = false,
    Ignore = {}
};