-- Roblox: ReplicatedStorage.LocalAssets.Worlds.Default.Chunk
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return "//";