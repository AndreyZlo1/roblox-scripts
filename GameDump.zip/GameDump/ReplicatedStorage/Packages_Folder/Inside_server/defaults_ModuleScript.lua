-- Roblox: ReplicatedStorage.Packages.server.defaults
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    FREEZE_PLAYERS = false,
    IS_PVP = false,
    CAN_PARACHUTE = true,
    ALLOW_SQUAD_CHANGING = true,
    TIME_ENABLED = true,
    SPAWNING_ENABLED = false,
    COMPOUNDS_ENABLED = true,
    FRIENDLY_FIRE = 0,
    CHEATS_ENABLED = false,
    VEHICLE_GRAVITY = -32,
    AIR_DENSITY = 1,
    WATER_DENSITY = 800,
    WHEEL_HEALTH = 100,
    ROTOR_HEALTH = 500,
    ENGINE_HEALTH = 1000
};