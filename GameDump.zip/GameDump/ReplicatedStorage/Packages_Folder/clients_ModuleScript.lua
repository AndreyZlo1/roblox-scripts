-- Roblox: ReplicatedStorage.Packages.clients
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Players__1 = game:GetService("Players");
local u1 = {};
u1.__index = u1;
function u1.new() --[[ Line: 25 ]]
    -- upvalues: u1 (copy)
    return setmetatable({
        Clients = {}
    }, u1);
end;
function u1.GetClients(p2) --[[ Line: 35 ]]
    local v3 = {};
    for _, v4 in p2.Clients do
        if v4.HasInitialized then
            v3[#v3 + 1] = v4;
        end;
    end;
    return v3;
end;
function u1.GetClientFromPlayer(p5, p6) --[[ Line: 49 ]]
    return p5.Clients[p6];
end;
function u1.GetClientFromName(p7, p8) --[[ Line: 56 ]]
    -- upvalues: l__Players__1 (copy)
    local v9 = l__Players__1:FindFirstChild(p8);
    if v9 then
        return p7.Clients[v9];
    end;
end;
return u1.new();