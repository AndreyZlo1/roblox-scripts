-- Roblox: ReplicatedStorage.Packages.Rodux
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Store__1 = require(script.Store);
local l__createReducer__2 = require(script.createReducer);
local l__combineReducers__3 = require(script.combineReducers);
local l__makeActionCreator__4 = require(script.makeActionCreator);
local l__loggerMiddleware__5 = require(script.loggerMiddleware);
local l__thunkMiddleware__6 = require(script.thunkMiddleware);
return {
    Store = l__Store__1,
    createReducer = l__createReducer__2,
    combineReducers = l__combineReducers__3,
    makeActionCreator = l__makeActionCreator__4,
    loggerMiddleware = l__loggerMiddleware__5.middleware,
    thunkMiddleware = l__thunkMiddleware__6
};