-- Roblox: ReplicatedStorage.Packages.Roact
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__GlobalConfig__1 = require(script.GlobalConfig);
local l__createReconciler__2 = require(script.createReconciler);
local l__createReconcilerCompat__3 = require(script.createReconcilerCompat);
local l__RobloxRenderer__4 = require(script.RobloxRenderer);
local l__strict__5 = require(script.strict);
local l__Binding__6 = require(script.Binding);
local v1 = l__createReconciler__2(l__RobloxRenderer__4);
local v2 = l__createReconcilerCompat__3(v1);
return l__strict__5({
    Component = require(script.Component),
    createElement = require(script.createElement),
    createFragment = require(script.createFragment),
    oneChild = require(script.oneChild),
    PureComponent = require(script.PureComponent),
    None = require(script.None),
    Portal = require(script.Portal),
    createRef = require(script.createRef),
    forwardRef = require(script.forwardRef),
    createBinding = l__Binding__6.create,
    joinBindings = l__Binding__6.join,
    createContext = require(script.createContext),
    Change = require(script.PropMarkers.Change),
    Children = require(script.PropMarkers.Children),
    Event = require(script.PropMarkers.Event),
    Ref = require(script.PropMarkers.Ref),
    mount = v1.mountVirtualTree,
    unmount = v1.unmountVirtualTree,
    update = v1.updateVirtualTree,
    reify = v2.reify,
    teardown = v2.teardown,
    reconcile = v2.reconcile,
    setGlobalConfig = l__GlobalConfig__1.set,
    UNSTABLE = {}
});