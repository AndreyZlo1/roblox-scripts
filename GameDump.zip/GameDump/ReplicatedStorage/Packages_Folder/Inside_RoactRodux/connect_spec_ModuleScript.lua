-- Roblox: ReplicatedStorage.Packages.RoactRodux.connect.spec
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function() --[[ Line: 1 ]]
    local l__connect__1 = require(script.Parent.connect);
    local l__StoreProvider__2 = require(script.Parent.StoreProvider);
    local l__Roact__3 = require(script.Parent.Parent.Roact);
    local l__Rodux__4 = require(script.Parent.Parent.Rodux);
    local function u1() --[[ Line: 9 ]]
        return nil;
    end;
    local function u2() --[[ Line: 13 ]]
        return nil;
    end;
    local u6 = l__Rodux__4.combineReducers({
        count = function(p3, p4) --[[ Name: countReducer, Line 17 ]]
            local v5 = p3 or 0;
            if p4.type == "increment" then
                return v5 + 1;
            else
                return v5;
            end;
        end
    });
    describe("Argument validation", function() --[[ Line: 31 ]]
        -- upvalues: l__connect__1 (copy), u1 (copy)
        it("should accept no arguments", function() --[[ Line: 32 ]]
            -- upvalues: l__connect__1 (ref)
            l__connect__1();
        end);
        it("should accept one function", function() --[[ Line: 36 ]]
            -- upvalues: l__connect__1 (ref), u1 (ref)
            l__connect__1(u1);
        end);
        it("should accept two functions", function() --[[ Line: 40 ]]
            -- upvalues: l__connect__1 (ref), u1 (ref)
            l__connect__1(u1, u1);
        end);
        it("should accept only the second function", function() --[[ Line: 44 ]]
            -- upvalues: l__connect__1 (ref)
            l__connect__1(nil, function() --[[ Line: 45 ]] end);
        end);
        it("should throw if not passed a component", function() --[[ Line: 48 ]]
            -- upvalues: l__connect__1 (ref)
            local function u7(_) --[[ Line: 49 ]]
                return {};
            end;
            expect(function() --[[ Line: 53 ]]
                -- upvalues: l__connect__1 (ref), u7 (copy)
                l__connect__1(u7)(nil);
            end).to.throw();
        end);
    end);
    it("should throw if not mounted under a StoreProvider", function() --[[ Line: 59 ]]
        -- upvalues: l__connect__1 (copy), u2 (copy), l__Roact__3 (copy)
        local u8 = l__connect__1()(u2);
        expect(function() --[[ Line: 62 ]]
            -- upvalues: l__Roact__3 (ref), u8 (copy)
            l__Roact__3.mount(l__Roact__3.createElement(u8));
        end).to.throw();
    end);
    it("should accept a higher-order function mapStateToProps", function() --[[ Line: 67 ]]
        -- upvalues: l__connect__1 (copy), u2 (copy), l__Rodux__4 (copy), u6 (copy), l__Roact__3 (copy), l__StoreProvider__2 (copy)
        local v10 = l__connect__1(function() --[[ Name: mapStateToProps, Line 68 ]]
            return function(p9) --[[ Line: 69 ]]
                return {
                    count = p9.count
                };
            end;
        end)(u2);
        local v11 = l__Rodux__4.Store.new(u6);
        local v12 = l__Roact__3.createElement(l__StoreProvider__2, {
            store = v11
        }, {
            someComponent = l__Roact__3.createElement(v10)
        });
        local v13 = l__Roact__3.mount(v12);
        l__Roact__3.unmount(v13);
    end);
    it("should not accept a higher-order mapStateToProps that returns a non-table value", function() --[[ Line: 90 ]]
        -- upvalues: l__connect__1 (copy), u2 (copy), l__Rodux__4 (copy), u6 (copy), l__Roact__3 (copy), l__StoreProvider__2 (copy)
        local v14 = l__connect__1(function() --[[ Name: mapStateToProps, Line 91 ]]
            return function(_) --[[ Line: 92 ]]
                return "nope";
            end;
        end)(u2);
        local v15 = l__Rodux__4.Store.new(u6);
        local u16 = l__Roact__3.createElement(l__StoreProvider__2, {
            store = v15
        }, {
            someComponent = l__Roact__3.createElement(v14)
        });
        expect(function() --[[ Line: 106 ]]
            -- upvalues: l__Roact__3 (ref), u16 (copy)
            l__Roact__3.mount(u16);
        end).to.throw();
    end);
    it("should not accept a mapStateToProps that returns a non-table value", function() --[[ Line: 111 ]]
        -- upvalues: l__connect__1 (copy), u2 (copy), l__Rodux__4 (copy), u6 (copy), l__Roact__3 (copy), l__StoreProvider__2 (copy)
        local v17 = l__connect__1(function() --[[ Name: mapStateToProps, Line 112 ]]
            return "nah";
        end)(u2);
        local v18 = l__Rodux__4.Store.new(u6);
        local u19 = l__Roact__3.createElement(l__StoreProvider__2, {
            store = v18
        }, {
            someComponent = l__Roact__3.createElement(v17)
        });
        expect(function() --[[ Line: 125 ]]
            -- upvalues: l__Roact__3 (ref), u19 (copy)
            l__Roact__3.mount(u19);
        end).to.throw();
    end);
    it("should abort renders when mapStateToProps returns the same data", function() --[[ Line: 130 ]]
        -- upvalues: l__connect__1 (copy), l__Rodux__4 (copy), u6 (copy), l__Roact__3 (copy), l__StoreProvider__2 (copy)
        local u20 = 0;
        local function v21(_) --[[ Line: 138 ]]
            -- upvalues: u20 (ref)
            u20 = u20 + 1;
        end;
        local v23 = l__connect__1(function(p22) --[[ Name: mapStateToProps, Line 131 ]]
            return {
                count = p22.count
            };
        end)(v21);
        local v24 = l__Rodux__4.Store.new(u6);
        local v25 = l__Roact__3.createElement(l__StoreProvider__2, {
            store = v24
        }, {
            someComponent = l__Roact__3.createElement(v23)
        });
        local v26 = l__Roact__3.mount(v25);
        expect(u20).to.equal(1);
        v24:dispatch({
            type = "an unknown action"
        });
        v24:flush();
        expect(u20).to.equal(1);
        v24:dispatch({
            type = "increment"
        });
        v24:flush();
        expect(u20).to.equal(2);
        l__Roact__3.unmount(v26);
    end);
    it("should only call mapDispatchToProps once and never re-render if no mapStateToProps was passed", function() --[[ Line: 168 ]]
        -- upvalues: l__connect__1 (copy), l__Rodux__4 (copy), u6 (copy), l__Roact__3 (copy), l__StoreProvider__2 (copy)
        local u27 = 0;
        local function v29(u28) --[[ Line: 170 ]]
            -- upvalues: u27 (ref)
            u27 = u27 + 1;
            return {
                increment = function() --[[ Name: increment, Line 174 ]]
                    -- upvalues: u28 (copy)
                    return u28({
                        type = "increment"
                    });
                end
            };
        end;
        local u30 = 0;
        local function v31(_) --[[ Line: 181 ]]
            -- upvalues: u30 (ref)
            u30 = u30 + 1;
        end;
        local v32 = l__connect__1(nil, v29)(v31);
        local v33 = l__Rodux__4.Store.new(u6);
        local v34 = l__Roact__3.createElement(l__StoreProvider__2, {
            store = v33
        }, {
            someComponent = l__Roact__3.createElement(v32)
        });
        local v35 = l__Roact__3.mount(v34);
        expect(u27).to.equal(1);
        expect(u30).to.equal(1);
        v33:dispatch({
            type = "an unknown action"
        });
        v33:flush();
        expect(u27).to.equal(1);
        expect(u30).to.equal(1);
        v33:dispatch({
            type = "increment"
        });
        v33:flush();
        expect(u27).to.equal(1);
        expect(u30).to.equal(1);
        l__Roact__3.unmount(v35);
    end);
    it("should return result values from the dispatch passed to mapDispatchToProps", function() --[[ Line: 214 ]]
        -- upvalues: l__connect__1 (copy), l__Rodux__4 (copy), l__Roact__3 (copy), l__StoreProvider__2 (copy)
        local u36 = nil;
        local function v38(p37) --[[ Line: 224 ]]
            -- upvalues: u36 (ref)
            u36 = p37.dispatch;
        end;
        local v40 = l__connect__1(nil, function(p39) --[[ Name: mapDispatchToProps, Line 228 ]]
            return {
                dispatch = p39
            };
        end)(v38);
        local v41 = l__Rodux__4.Store.new(function() --[[ Name: reducer, Line 215 ]]
            return 0;
        end, nil, { l__Rodux__4.thunkMiddleware });
        local v42 = l__Roact__3.createElement(l__StoreProvider__2, {
            store = v41
        }, {
            someComponent = l__Roact__3.createElement(v40)
        });
        local v43 = l__Roact__3.mount(v42);
        expect(u36).to.be.a("function");
        expect(u36(function() --[[ Name: fiveThunk, Line 219 ]]
            return 5;
        end)).to.equal(5);
        l__Roact__3.unmount(v43);
    end);
    it("should render parent elements before children", function() --[[ Line: 252 ]]
        -- upvalues: l__connect__1 (copy), l__Roact__3 (copy), l__Rodux__4 (copy), u6 (copy), l__StoreProvider__2 (copy)
        local function v45(p44) --[[ Line: 253 ]]
            return {
                count = p44.count
            };
        end;
        local u46 = false;
        local function v48(p47) --[[ Line: 261 ]]
            -- upvalues: u46 (ref)
            if p47.count > p47.parentCount then
                u46 = true;
            end;
        end;
        local u49 = l__connect__1(v45)(v48);
        local function v51(p50) --[[ Line: 269 ]]
            -- upvalues: l__Roact__3 (ref), u49 (copy)
            return l__Roact__3.createElement(u49, {
                parentCount = p50.count
            });
        end;
        local v52 = l__connect__1(v45)(v51);
        local v53 = l__Rodux__4.Store.new(u6);
        local v54 = l__Roact__3.createElement(l__StoreProvider__2, {
            store = v53
        }, {
            parent = l__Roact__3.createElement(v52)
        });
        local v55 = l__Roact__3.mount(v54);
        v53:dispatch({
            type = "increment"
        });
        v53:flush();
        v53:dispatch({
            type = "increment"
        });
        v53:flush();
        l__Roact__3.unmount(v55);
        expect(u46).to.equal(false);
    end);
end;