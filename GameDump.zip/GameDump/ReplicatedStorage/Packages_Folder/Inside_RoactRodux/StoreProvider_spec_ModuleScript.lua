-- Roblox: ReplicatedStorage.Packages.RoactRodux.StoreProvider.spec
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function() --[[ Line: 1 ]]
    local l__StoreProvider__1 = require(script.Parent.StoreProvider);
    local l__Roact__2 = require(script.Parent.Parent.Roact);
    local l__Rodux__3 = require(script.Parent.Parent.Rodux);
    it("should be instantiable as a component", function() --[[ Line: 8 ]]
        -- upvalues: l__Rodux__3 (copy), l__Roact__2 (copy), l__StoreProvider__1 (copy)
        local v1 = l__Rodux__3.Store.new(function() --[[ Line: 9 ]]
            return 0;
        end);
        local v2 = l__Roact__2.createElement(l__StoreProvider__1, {
            store = v1
        });
        expect(v2).to.be.ok();
        local v3 = l__Roact__2.mount(v2, nil, "StoreProvider-test");
        l__Roact__2.unmount(v3);
        v1:destruct();
    end);
    it("should expect a \'store\' prop", function() --[[ Line: 24 ]]
        -- upvalues: l__Roact__2 (copy), l__StoreProvider__1 (copy)
        local u4 = l__Roact__2.createElement(l__StoreProvider__1);
        expect(function() --[[ Line: 27 ]]
            -- upvalues: l__Roact__2 (ref), u4 (copy)
            l__Roact__2.mount(u4);
        end).to.throw();
    end);
    it("should accept multiple children", function() --[[ Line: 32 ]]
        -- upvalues: l__Rodux__3 (copy), l__Roact__2 (copy), l__StoreProvider__1 (copy)
        local v5 = l__Rodux__3.Store.new(function() --[[ Line: 33 ]]
            return 0;
        end);
        local v6 = Instance.new("Folder");
        local v7 = l__Roact__2.createElement(l__StoreProvider__1, {
            store = v5
        }, {
            test1 = l__Roact__2.createElement("Frame"),
            test2 = l__Roact__2.createElement("Frame"),
            test3 = l__Roact__2.createElement("Frame")
        });
        expect(v7).to.be.ok();
        local v8 = l__Roact__2.mount(v7, v6, "StoreProvider-test");
        expect(v6:FindFirstChild("test1")).to.be.ok();
        expect(v6:FindFirstChild("test2")).to.be.ok();
        expect(v6:FindFirstChild("test3")).to.be.ok();
        l__Roact__2.unmount(v8);
        v5:destruct();
    end);
end;