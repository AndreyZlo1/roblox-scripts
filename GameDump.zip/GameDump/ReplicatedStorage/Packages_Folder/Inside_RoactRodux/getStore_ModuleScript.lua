-- Roblox: ReplicatedStorage.Packages.RoactRodux.getStore
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__storeKey__1 = require(script.Parent.storeKey);
return function(p1) --[[ Name: getStore, Line 3 ]]
    -- upvalues: l__storeKey__1 (copy)
    return p1._context[l__storeKey__1];
end;