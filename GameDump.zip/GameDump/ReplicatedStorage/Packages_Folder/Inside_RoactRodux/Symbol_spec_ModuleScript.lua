-- Roblox: ReplicatedStorage.Packages.RoactRodux.Symbol.spec
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function() --[[ Line: 1 ]]
    local l__Symbol__1 = require(script.Parent.Symbol);
    describe("named", function() --[[ Line: 4 ]]
        -- upvalues: l__Symbol__1 (copy)
        it("should give an opaque object", function() --[[ Line: 5 ]]
            -- upvalues: l__Symbol__1 (ref)
            local v1 = l__Symbol__1.named("foo");
            expect(v1).to.be.a("userdata");
        end);
        it("should coerce to the given name", function() --[[ Line: 11 ]]
            -- upvalues: l__Symbol__1 (ref)
            local v2 = l__Symbol__1.named("foo");
            expect(tostring(v2):find("foo")).to.be.ok();
        end);
        it("should be unique when constructed", function() --[[ Line: 17 ]]
            -- upvalues: l__Symbol__1 (ref)
            local v3 = l__Symbol__1.named("abc");
            local v4 = l__Symbol__1.named("abc");
            expect(v3).never.to.equal(v4);
        end);
    end);
    describe("unnamed", function() --[[ Line: 25 ]]
        -- upvalues: l__Symbol__1 (copy)
        it("should give an opaque object", function() --[[ Line: 26 ]]
            -- upvalues: l__Symbol__1 (ref)
            local v5 = l__Symbol__1.unnamed();
            expect(v5).to.be.a("userdata");
        end);
        it("should coerce to some string", function() --[[ Line: 32 ]]
            -- upvalues: l__Symbol__1 (ref)
            local v6 = l__Symbol__1.unnamed();
            expect((tostring(v6))).to.be.a("string");
        end);
        it("should be unique when constructed", function() --[[ Line: 38 ]]
            -- upvalues: l__Symbol__1 (ref)
            local v7 = l__Symbol__1.unnamed();
            local v8 = l__Symbol__1.unnamed();
            expect(v7).never.to.equal(v8);
        end);
    end);
end;