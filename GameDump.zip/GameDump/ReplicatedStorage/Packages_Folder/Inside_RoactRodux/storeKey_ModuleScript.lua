-- Roblox: ReplicatedStorage.Packages.RoactRodux.storeKey
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent.Symbol).named("RoduxStore");