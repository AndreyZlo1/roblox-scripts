-- Roblox: ReplicatedStorage.Packages.RoactRodux.join
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function(...) --[[ Name: join, Line 1 ]]
    local v1 = {};
    for v2 = 1, select("#", ...) do
        local v3 = select(v2, ...);
        if v3 ~= nil then
            for v4, v5 in pairs(v3) do
                v1[v4] = v5;
            end;
        end;
    end;
    return v1;
end;