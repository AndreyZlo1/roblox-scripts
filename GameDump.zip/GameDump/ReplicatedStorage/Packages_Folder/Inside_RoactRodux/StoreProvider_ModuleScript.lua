-- Roblox: ReplicatedStorage.Packages.RoactRodux.StoreProvider
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Roact__1 = require(script.Parent.Parent.Roact);
local l__storeKey__2 = require(script.Parent.storeKey);
local v1 = l__Roact__1.Component:extend("StoreProvider");
function v1.init(p2, p3) --[[ Line: 7 ]]
    -- upvalues: l__storeKey__2 (copy)
    local l__store__3 = p3.store;
    if l__store__3 == nil then
        error("Error initializing StoreProvider. Expected a `store` prop to be a Rodux store.");
    end;
    p2._context[l__storeKey__2] = l__store__3;
end;
function v1.render(p4) --[[ Line: 17 ]]
    -- upvalues: l__Roact__1 (copy)
    return l__Roact__1.createFragment(p4.props[l__Roact__1.Children]);
end;
return v1;