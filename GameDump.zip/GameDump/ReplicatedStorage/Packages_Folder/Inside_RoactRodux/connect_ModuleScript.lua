-- Roblox: ReplicatedStorage.Packages.RoactRodux.connect
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Roact__1 = require(script.Parent.Parent.Roact);
local l__getStore__2 = require(script.Parent.getStore);
local l__shallowEqual__3 = require(script.Parent.shallowEqual);
local l__join__4 = require(script.Parent.join);
local function u1() --[[ Line: 13 ]]
    return nil;
end;
return function(u2, u3) --[[ Name: connect, Line 50 ]]
    -- upvalues: u1 (copy), l__Roact__1 (copy), l__shallowEqual__3 (copy), l__getStore__2 (copy), l__join__4 (copy)
    local u4 = debug.traceback();
    if u2 == nil then
        u2 = u1;
    else
        local v5 = typeof(u2) == "function";
        assert(v5, "mapStateToProps must be a function or nil!");
    end;
    if u3 == nil then
        u3 = u1;
    else
        local v6 = typeof(u3) == "function";
        assert(v6, "mapDispatchToProps must be a function or nil!");
    end;
    return function(u7) --[[ Line: 65 ]]
        -- upvalues: u4 (copy), l__Roact__1 (ref), l__shallowEqual__3 (ref), l__getStore__2 (ref), u2 (ref), u3 (ref), l__join__4 (ref)
        if u7 == nil then
            local v8 = { u4 };
            local v9 = table.concat({ "connect returns a function that must be passed a component.", "Check the connection at:", "%s" }, "\n"):format(unpack(v8 or {}));
            error(v9, 2);
        end;
        local v10 = ("RoduxConnection(%s)"):format((tostring(u7)));
        local v11 = l__Roact__1.Component:extend(v10);
        function v11.getDerivedStateFromProps(p12, p13) --[[ Line: 82 ]]
            if p13.stateUpdater ~= nil then
                return p13.stateUpdater(p12, p13);
            end;
        end;
        function v11.createStoreConnection(u14) --[[ Line: 88 ]]
            -- upvalues: l__shallowEqual__3 (ref)
            u14.storeChangedConnection = u14.store.changed:connect(function(u15) --[[ Line: 89 ]]
                -- upvalues: u14 (copy), l__shallowEqual__3 (ref)
                u14:setState(function(p16, p17) --[[ Line: 90 ]]
                    -- upvalues: u15 (copy), l__shallowEqual__3 (ref)
                    local v18 = p16.mapStateToProps(u15, p17);
                    if l__shallowEqual__3(v18, p16.mappedStoreState) then
                        return nil;
                    else
                        return p16.stateUpdater(p17, p16, v18);
                    end;
                end);
            end);
        end;
        function v11.init(u19) --[[ Line: 105 ]]
            -- upvalues: l__getStore__2 (ref), u7 (copy), u2 (ref), u3 (ref), l__join__4 (ref)
            u19.store = l__getStore__2(u19);
            if u19.store == nil then
                local v20 = { (tostring(u7)) };
                local v21 = table.concat({ "Cannot initialize Roact-Rodux connection without being a descendent of StoreProvider!", "Tried to wrap component %q", "Make sure there is a StoreProvider above this component in the tree." }, "\n"):format(unpack(v20 or {}));
                error(v21);
            end;
            local v22 = u19.store:getState();
            local v23 = u2;
            local v24 = v23(v22, u19.props);
            local v25;
            if typeof(v24) == "function" then
                v25 = v24(v22, u19.props);
            else
                v25 = v24;
                v24 = v23;
            end;
            if v25 ~= nil and typeof(v25) ~= "table" then
                local v26 = { tostring(v25), (typeof(v25)) };
                local v27 = table.concat({ "mapStateToProps must either return a table, or return another function that returns a table.", "Instead, it returned %q, which is of type %s." }, "\n"):format(unpack(v26 or {}));
                error(v27);
            end;
            local v28 = u3(function(...) --[[ Line: 146 ]]
                -- upvalues: u19 (copy)
                return u19.store:dispatch(...);
            end);
            local l__store__5 = u19.store;
            local function v32(p29, p30, p31) --[[ Line: 27 ]]
                -- upvalues: l__store__5 (copy), l__join__4 (ref)
                if p31 == nil then
                    p31 = p30.mapStateToProps(l__store__5:getState(), p29);
                end;
                return {
                    mappedStoreState = p31,
                    propsForChild = l__join__4(p29, p31, p30.mappedStoreDispatch)
                };
            end;
            u19.state = {
                propsForChild = nil,
                stateUpdater = v32,
                mapStateToProps = v24,
                mappedStoreDispatch = v28
            };
            local v33 = v32(u19.props, u19.state, v25);
            for v34, v35 in pairs(v33) do
                u19.state[v34] = v35;
            end;
            u19:createStoreConnection();
        end;
        function v11.willUnmount(p36) --[[ Line: 179 ]]
            p36.storeChangedConnection:disconnect();
        end;
        function v11.render(p37) --[[ Line: 183 ]]
            -- upvalues: l__Roact__1 (ref), u7 (copy)
            return l__Roact__1.createElement(u7, p37.state.propsForChild);
        end;
        return v11;
    end;
end;