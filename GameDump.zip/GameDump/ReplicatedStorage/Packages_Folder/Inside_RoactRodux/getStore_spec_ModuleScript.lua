-- Roblox: ReplicatedStorage.Packages.RoactRodux.getStore.spec
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function() --[[ Line: 1 ]]
    local l__Roact__1 = require(script.Parent.Parent.Roact);
    local l__Rodux__2 = require(script.Parent.Parent.Rodux);
    local l__StoreProvider__3 = require(script.Parent.StoreProvider);
    local l__getStore__4 = require(script.Parent.getStore);
    it("should return the store when present", function() --[[ Line: 9 ]]
        -- upvalues: l__Rodux__2 (copy), l__Roact__1 (copy), l__getStore__4 (copy), l__StoreProvider__3 (copy)
        local v1 = l__Rodux__2.Store.new(function() --[[ Name: reducer, Line 10 ]]
            return 0;
        end);
        local u2 = nil;
        local v3 = l__Roact__1.Component:extend("StoreConsumer");
        function v3.init(p4) --[[ Line: 19 ]]
            -- upvalues: u2 (ref), l__getStore__4 (ref)
            u2 = l__getStore__4(p4);
        end;
        function v3.render(_) --[[ Line: 23 ]]
            return nil;
        end;
        local v5 = l__Roact__1.createElement(l__StoreProvider__3, {
            store = v1
        }, {
            Consumer = l__Roact__1.createElement(v3)
        });
        local v6 = l__Roact__1.mount(v5);
        expect(u2).to.equal(v1);
        l__Roact__1.unmount(v6);
        v1:destruct();
    end);
    it("should return nil when the store is not present", function() --[[ Line: 41 ]]
        -- upvalues: l__Roact__1 (copy), l__getStore__4 (copy)
        local u7 = 6;
        local v8 = l__Roact__1.Component:extend("StoreConsumer");
        function v8.init(p9) --[[ Line: 47 ]]
            -- upvalues: u7 (ref), l__getStore__4 (ref)
            u7 = l__getStore__4(p9);
        end;
        function v8.render(_) --[[ Line: 51 ]]
            return nil;
        end;
        local v10 = l__Roact__1.createElement(v8);
        local v11 = l__Roact__1.mount(v10);
        expect(u7).to.equal(nil);
        l__Roact__1.unmount(v11);
    end);
end;