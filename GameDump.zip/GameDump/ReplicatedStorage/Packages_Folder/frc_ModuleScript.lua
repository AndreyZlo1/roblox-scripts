-- Roblox: ReplicatedStorage.Packages.frc
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function(p1) --[[ Line: 2 ]]
    return p1 >= 1 and 1 or p1;
end;