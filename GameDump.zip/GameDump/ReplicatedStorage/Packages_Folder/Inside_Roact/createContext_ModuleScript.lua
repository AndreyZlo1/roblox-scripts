-- Roblox: ReplicatedStorage.Packages.Roact.createContext
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Symbol__1 = require(script.Parent.Symbol);
local l__createFragment__2 = require(script.Parent.createFragment);
local l__createSignal__3 = require(script.Parent.createSignal);
local l__Children__4 = require(script.Parent.PropMarkers.Children);
local l__Component__5 = require(script.Parent.Component);
local function u10(u1) --[[ Line: 17 ]]
    -- upvalues: l__Component__5 (copy), l__createSignal__3 (copy), l__createFragment__2 (copy), l__Children__4 (copy)
    local v2 = l__Component__5:extend("Provider");
    function v2.init(p3, p4) --[[ Line: 20 ]]
        -- upvalues: l__createSignal__3 (ref), u1 (copy)
        p3.contextEntry = {
            value = p4.value,
            onUpdate = l__createSignal__3()
        };
        p3:__addContext(u1.key, p3.contextEntry);
    end;
    function v2.willUpdate(p5, p6) --[[ Line: 25 ]]
        if p6.value ~= p5.props.value then
            p5.contextEntry.value = p6.value;
        end;
    end;
    function v2.didUpdate(p7, p8) --[[ Line: 36 ]]
        if p8.value ~= p7.props.value then
            p7.contextEntry.onUpdate:fire(p7.props.value);
        end;
    end;
    function v2.render(p9) --[[ Line: 51 ]]
        -- upvalues: l__createFragment__2 (ref), l__Children__4 (ref)
        return l__createFragment__2(p9.props[l__Children__4]);
    end;
    return v2;
end;
local function u21(u11) --[[ Line: 58 ]]
    -- upvalues: l__Component__5 (copy)
    local v12 = l__Component__5:extend("Consumer");
    function v12.validateProps(p13) --[[ Line: 61 ]]
        if type(p13.render) == "function" then
            return true;
        else
            return false, "Consumer expects a `render` function";
        end;
    end;
    function v12.init(p14, _) --[[ Line: 69 ]]
        -- upvalues: u11 (copy)
        p14.contextEntry = p14:__getContext(u11.key);
    end;
    function v12.render(p15) --[[ Line: 75 ]]
        -- upvalues: u11 (copy)
        local v16;
        if p15.contextEntry == nil then
            v16 = u11.defaultValue;
        else
            v16 = p15.contextEntry.value;
        end;
        return p15.props.render(v16);
    end;
    function v12.didUpdate(p17) --[[ Line: 90 ]]
        if p17.contextEntry ~= nil then
            p17.lastValue = p17.contextEntry.value;
        end;
    end;
    function v12.didMount(u18) --[[ Line: 99 ]]
        if u18.contextEntry ~= nil then
            u18.disconnect = u18.contextEntry.onUpdate:subscribe(function(p19) --[[ Line: 110 ]]
                -- upvalues: u18 (copy)
                if p19 ~= u18.lastValue then
                    u18:setState({});
                end;
            end);
        end;
    end;
    function v12.willUnmount(p20) --[[ Line: 119 ]]
        if p20.disconnect ~= nil then
            p20.disconnect();
            p20.disconnect = nil;
        end;
    end;
    return v12;
end;
local u22 = {};
u22.__index = u22;
function u22.new(p23) --[[ Line: 132 ]]
    -- upvalues: l__Symbol__1 (copy), u22 (copy)
    local v24 = {
        defaultValue = p23,
        key = l__Symbol__1.named("ContextKey")
    };
    return setmetatable(v24, u22);
end;
function u22.__tostring(_) --[[ Line: 139 ]]
    return "RoactContext";
end;
return function(p25) --[[ Name: createContext, Line 143 ]]
    -- upvalues: u22 (copy), u10 (copy), u21 (copy)
    local v26 = u22.new(p25);
    return {
        Provider = u10(v26),
        Consumer = u21(v26)
    };
end;