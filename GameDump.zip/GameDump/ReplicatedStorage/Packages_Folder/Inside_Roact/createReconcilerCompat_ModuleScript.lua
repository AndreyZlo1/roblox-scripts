-- Roblox: ReplicatedStorage.Packages.Roact.createReconcilerCompat
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Logging__1 = require(script.Parent.Logging);
return function(u1) --[[ Name: createReconcilerCompat, Line 23 ]]
    -- upvalues: l__Logging__1 (copy)
    return {
        reify = function(...) --[[ Name: reify, Line 26 ]]
            -- upvalues: l__Logging__1 (ref), u1 (copy)
            l__Logging__1.warnOnce("Roact.reify has been renamed to Roact.mount and will be removed in a future release.\nCheck the call to Roact.reify at:\n");
            return u1.mountVirtualTree(...);
        end,
        teardown = function(...) --[[ Name: teardown, Line 32 ]]
            -- upvalues: l__Logging__1 (ref), u1 (copy)
            l__Logging__1.warnOnce("Roact.teardown has been renamed to Roact.unmount and will be removed in a future release.\nCheck the call to Roact.teardown at:\n");
            return u1.unmountVirtualTree(...);
        end,
        reconcile = function(...) --[[ Name: reconcile, Line 38 ]]
            -- upvalues: l__Logging__1 (ref), u1 (copy)
            l__Logging__1.warnOnce("Roact.reconcile has been renamed to Roact.update and will be removed in a future release.\nCheck the call to Roact.reconcile at:\n");
            return u1.updateVirtualTree(...);
        end
    };
end;