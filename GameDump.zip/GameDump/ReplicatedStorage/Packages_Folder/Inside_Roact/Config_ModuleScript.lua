-- Roblox: ReplicatedStorage.Packages.Roact.Config
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {
    internalTypeChecks = false,
    typeChecks = false,
    elementTracing = false,
    propValidation = false
};
local u2 = {};
for v3 in pairs(u1) do
    table.insert(u2, v3);
end;
local u4 = {};
function u4.new() --[[ Line: 35 ]]
    -- upvalues: u2 (copy), u4 (copy), u1 (copy)
    local u7 = {
        _currentConfig = setmetatable({}, {
            __index = function(_, p5) --[[ Name: __index, Line 39 ]]
                -- upvalues: u2 (ref)
                local v6 = ("Invalid global configuration key %q. Valid configuration keys are: %s"):format(tostring(p5), table.concat(u2, ", "));
                error(v6, 3);
            end
        })
    };
    function u7.set(...) --[[ Line: 52 ]]
        -- upvalues: u4 (ref), u7 (copy)
        return u4.set(u7, ...);
    end;
    function u7.get(...) --[[ Line: 56 ]]
        -- upvalues: u4 (ref), u7 (copy)
        return u4.get(u7, ...);
    end;
    function u7.scoped(...) --[[ Line: 60 ]]
        -- upvalues: u4 (ref), u7 (copy)
        return u4.scoped(u7, ...);
    end;
    u7.set(u1);
    return u7;
end;
function u4.set(p8, p9) --[[ Line: 69 ]]
    -- upvalues: u1 (copy), u2 (copy)
    for v10, v11 in pairs(p9) do
        if u1[v10] == nil then
            local v12 = ("Invalid global configuration key %q (type %s). Valid configuration keys are: %s"):format(tostring(v10), typeof(v10), table.concat(u2, ", "));
            error(v12, 3);
        end;
        if typeof(v11) ~= "boolean" then
            local v13 = ("Invalid value %q (type %s) for global configuration key %q. Valid values are: true, false"):format(tostring(v11), typeof(v11), (tostring(v10)));
            error(v13, 3);
        end;
        p8._currentConfig[v10] = v11;
    end;
end;
function u4.get(p14) --[[ Line: 96 ]]
    return p14._currentConfig;
end;
function u4.scoped(p15, p16, p17) --[[ Line: 100 ]]
    local v18 = {};
    for v19, v20 in pairs(p15._currentConfig) do
        v18[v19] = v20;
    end;
    p15.set(p16);
    local v21, v22 = pcall(p17);
    p15.set(v18);
    assert(v21, v22);
end;
return u4;