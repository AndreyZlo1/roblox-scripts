-- Roblox: ReplicatedStorage.Packages.Roact.ElementKind
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Symbol__1 = require(script.Parent.Symbol);
local l__strict__2 = require(script.Parent.strict);
local l__Portal__3 = require(script.Parent.Portal);
local u1 = newproxy(true);
local v3 = {
    Portal = l__Symbol__1.named("Portal"),
    Host = l__Symbol__1.named("Host"),
    Function = l__Symbol__1.named("Function"),
    Stateful = l__Symbol__1.named("Stateful"),
    Fragment = l__Symbol__1.named("Fragment"),
    of = function(p2) --[[ Name: of, Line 25 ]]
        -- upvalues: u1 (copy)
        if typeof(p2) == "table" then
            return p2[u1];
        else
            return nil;
        end;
    end
};
local u4 = {
    string = v3.Host,
    ["function"] = v3.Function,
    table = v3.Stateful
};
function v3.fromComponent(p5) --[[ Line: 39 ]]
    -- upvalues: l__Portal__3 (copy), u1 (copy), u4 (copy)
    if p5 == l__Portal__3 then
        return u1.Portal;
    else
        return u4[typeof(p5)];
    end;
end;
getmetatable(u1).__index = v3;
l__strict__2(v3, "ElementKind");
return u1;