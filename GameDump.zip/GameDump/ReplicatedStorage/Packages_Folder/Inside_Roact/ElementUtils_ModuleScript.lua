-- Roblox: ReplicatedStorage.Packages.Roact.ElementUtils
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Type__1 = require(script.Parent.Type);
local function u1() --[[ Line: 5 ]]
    return nil;
end;
local u2 = {
    UseParentKey = require(script.Parent.Symbol).named("UseParentKey")
};
function u2.iterateElements(u3) --[[ Line: 43 ]]
    -- upvalues: l__Type__1 (copy), u2 (copy), u1 (copy)
    if l__Type__1.of(u3) == l__Type__1.Element then
        local u4 = false;
        return function(_, _) --[[ Line: 50 ]]
            -- upvalues: u4 (ref), u2 (ref), u3 (copy)
            if u4 then
                return nil;
            end;
            u4 = true;
            return u2.UseParentKey, u3;
        end;
    end;
    local v5 = typeof(u3);
    if u3 == nil or v5 == "boolean" then
        return u1;
    end;
    if v5 == "table" then
        return pairs(u3);
    end;
    error("Invalid elements");
end;
function u2.getElementByKey(p6, p7) --[[ Line: 82 ]]
    -- upvalues: l__Type__1 (copy), u2 (copy)
    if p6 == nil or typeof(p6) == "boolean" then
        return nil;
    elseif l__Type__1.of(p6) == l__Type__1.Element then
        if p7 == u2.UseParentKey then
            return p6;
        else
            return nil;
        end;
    else
        if typeof(p6) == "table" then
            return p6[p7];
        end;
        error("Invalid elements");
    end;
end;
return u2;