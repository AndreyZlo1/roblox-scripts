-- Roblox: ReplicatedStorage.Packages.Roact.assign
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__None__1 = require(script.Parent.None);
return function(p1, ...) --[[ Name: assign, Line 9 ]]
    -- upvalues: l__None__1 (copy)
    for v2 = 1, select("#", ...) do
        local v3 = select(v2, ...);
        if v3 ~= nil then
            for v4, v5 in pairs(v3) do
                if v5 == l__None__1 then
                    p1[v4] = nil;
                else
                    p1[v4] = v5;
                end;
            end;
        end;
    end;
    return p1;
end;