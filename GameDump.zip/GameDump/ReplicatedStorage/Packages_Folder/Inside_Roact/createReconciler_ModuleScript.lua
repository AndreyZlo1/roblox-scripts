-- Roblox: ReplicatedStorage.Packages.Roact.createReconciler
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Type__1 = require(script.Parent.Type);
local l__ElementKind__2 = require(script.Parent.ElementKind);
local l__ElementUtils__3 = require(script.Parent.ElementUtils);
local l__Children__4 = require(script.Parent.PropMarkers.Children);
local l__Symbol__5 = require(script.Parent.Symbol);
local l__internalAssert__6 = require(script.Parent.internalAssert);
local u1 = require(script.Parent.GlobalConfig).get();
local u2 = l__Symbol__5.named("InternalData");
return function(u3) --[[ Name: createReconciler, Line 25 ]]
    -- upvalues: u1 (copy), l__internalAssert__6 (copy), l__Type__1 (copy), l__ElementUtils__3 (copy), l__ElementKind__2 (copy), l__Children__4 (copy), u2 (copy)
    local u4 = nil;
    local u5 = nil;
    local u6 = nil;
    local u7 = nil;
    local function u20(p8, p9, p10) --[[ Line: 70 ]]
        -- upvalues: u1 (ref), l__internalAssert__6 (ref), l__Type__1 (ref), l__ElementUtils__3 (ref), u6 (ref), u7 (ref), u5 (ref)
        if u1.internalTypeChecks then
            l__internalAssert__6(l__Type__1.of(p8) == l__Type__1.VirtualNode, "Expected arg #1 to be of type VirtualNode");
        end;
        p8.updateChildrenCount = p8.updateChildrenCount + 1;
        local l__updateChildrenCount__7 = p8.updateChildrenCount;
        local v11 = {};
        for v12, v13 in pairs(p8.children) do
            local v14 = u6(v13, (l__ElementUtils__3.getElementByKey(p10, v12)));
            if p8.updateChildrenCount ~= l__updateChildrenCount__7 then
                if v14 and v14 ~= p8.children[v12] then
                    u7(v14);
                end;
                return;
            end;
            if v14 == nil then
                v11[v12] = true;
            else
                p8.children[v12] = v14;
            end;
        end;
        for v15 in pairs(v11) do
            p8.children[v15] = nil;
        end;
        for v16, v17 in l__ElementUtils__3.iterateElements(p10) do
            local v18;
            if v16 == l__ElementUtils__3.UseParentKey then
                v18 = p8.hostKey;
            else
                v18 = v16;
            end;
            if p8.children[v16] == nil then
                local v19 = u5(v17, p9, v18, p8.context, p8.legacyContext);
                if p8.updateChildrenCount ~= l__updateChildrenCount__7 then
                    if v19 then
                        u7(v19);
                    end;
                    return;
                end;
                if v19 ~= nil then
                    v19.depth = p8.depth + 1;
                    v19.parent = p8;
                    p8.children[v16] = v19;
                end;
            end;
        end;
    end;
    local function u24(p21, p22, p23) --[[ Line: 147 ]]
        -- upvalues: l__Type__1 (ref), u20 (copy)
        if l__Type__1.of(p23) == l__Type__1.Element or (p23 == nil or typeof(p23) == "boolean") then
            u20(p21, p22, p23);
        else
            error(("%s\n%s"):format("Component returned invalid children:", p21.currentElement.source or "<enable element tracebacks>"), 0);
        end;
    end;
    u7 = function(p25) --[[ Name: unmountVirtualNode, Line 164 ]]
        -- upvalues: u1 (ref), l__internalAssert__6 (ref), l__Type__1 (ref), l__ElementKind__2 (ref), u3 (copy), u4 (ref), u7 (ref)
        if u1.internalTypeChecks then
            l__internalAssert__6(l__Type__1.of(p25) == l__Type__1.VirtualNode, "Expected arg #1 to be of type VirtualNode");
        end;
        p25.wasUnmounted = true;
        local v26 = l__ElementKind__2.of(p25.currentElement);
        if v26 == l__ElementKind__2.Host then
            u3.unmountHostNode(u4, p25);
        elseif v26 == l__ElementKind__2.Function then
            for _, v27 in pairs(p25.children) do
                u7(v27);
            end;
        elseif v26 == l__ElementKind__2.Stateful then
            p25.instance:__unmount();
        elseif v26 == l__ElementKind__2.Portal then
            for _, v28 in pairs(p25.children) do
                u7(v28);
            end;
        elseif v26 == l__ElementKind__2.Fragment then
            for _, v29 in pairs(p25.children) do
                u7(v29);
            end;
        else
            error(("Unknown ElementKind %q"):format((tostring(v26))), 2);
        end;
    end;
    u6 = function(p30, p31, p32) --[[ Name: updateVirtualNode, Line 240 ]]
        -- upvalues: u1 (ref), l__internalAssert__6 (ref), l__Type__1 (ref), u7 (ref), u5 (ref), l__ElementKind__2 (ref), u3 (copy), u4 (ref), u24 (copy), l__Children__4 (ref), u20 (copy)
        if u1.internalTypeChecks then
            l__internalAssert__6(l__Type__1.of(p30) == l__Type__1.VirtualNode, "Expected arg #1 to be of type VirtualNode");
        end;
        if u1.typeChecks then
            local v33 = (l__Type__1.of(p31) == l__Type__1.Element or typeof(p31) == "boolean") and true or p31 == nil;
            assert(v33, "Expected arg #2 to be of type Element, boolean, or nil");
        end;
        if p30.currentElement == p31 and p32 == nil then
            return p30;
        end;
        if typeof(p31) == "boolean" or p31 == nil then
            u7(p30);
            return nil;
        end;
        if p30.currentElement.component == p31.component then
            local v34 = l__ElementKind__2.of(p31);
            local v35 = true;
            if v34 == l__ElementKind__2.Host then
                p30 = u3.updateHostNode(u4, p30, p31);
            elseif v34 == l__ElementKind__2.Function then
                local v36 = p31.component(p31.props);
                u24(p30, p30.hostParent, v36);
            elseif v34 == l__ElementKind__2.Stateful then
                v35 = p30.instance:__update(p31, p32);
            elseif v34 == l__ElementKind__2.Portal then
                local l__target__8 = p30.currentElement.props.target;
                local l__target__9 = p31.props.target;
                local v37 = u3.isHostObject(l__target__9);
                assert(v37, "Expected target to be host object");
                if l__target__9 == l__target__8 then
                    u20(p30, l__target__9, p31.props[l__Children__4]);
                else
                    local l__hostParent__10 = p30.hostParent;
                    local l__hostKey__11 = p30.hostKey;
                    local l__depth__12 = p30.depth;
                    local l__parent__13 = p30.parent;
                    local v38 = p30.originalContext or p30.context;
                    local l__parentLegacyContext__14 = p30.parentLegacyContext;
                    if not p30.wasUnmounted then
                        u7(p30);
                    end;
                    p30 = u5(p31, l__hostParent__10, l__hostKey__11, v38, l__parentLegacyContext__14);
                    if p30 ~= nil then
                        p30.depth = l__depth__12;
                        p30.parent = l__parent__13;
                    end;
                end;
            elseif v34 == l__ElementKind__2.Fragment then
                u20(p30, p30.hostParent, p31.elements);
            else
                error(("Unknown ElementKind %q"):format((tostring(v34))), 2);
            end;
            if not v35 then
                return p30;
            end;
            p30.currentElement = p31;
            return p30;
        end;
        local l__hostParent__15 = p30.hostParent;
        local l__hostKey__16 = p30.hostKey;
        local l__depth__17 = p30.depth;
        local l__parent__18 = p30.parent;
        local v39 = p30.originalContext or p30.context;
        local l__parentLegacyContext__19 = p30.parentLegacyContext;
        if not p30.wasUnmounted then
            u7(p30);
        end;
        local v40 = u5(p31, l__hostParent__15, l__hostKey__16, v39, l__parentLegacyContext__19);
        if v40 ~= nil then
            v40.depth = l__depth__17;
            v40.parent = l__parent__18;
        end;
        return v40;
    end;
    local function u47(p41, p42, p43, p44, p45) --[[ Line: 297 ]]
        -- upvalues: u1 (ref), l__internalAssert__6 (ref), u3 (copy), l__Type__1 (ref)
        if u1.internalTypeChecks then
            l__internalAssert__6(u3.isHostObject(p42) or p42 == nil, "Expected arg #2 to be a host object");
            l__internalAssert__6(typeof(p44) == "table" and true or p44 == nil, "Expected arg #4 to be of type table or nil");
            l__internalAssert__6(typeof(p45) == "table" and true or p45 == nil, "Expected arg #5 to be of type table or nil");
        end;
        if u1.typeChecks then
            assert(p43 ~= nil, "Expected arg #3 to be non-nil");
            local v46 = l__Type__1.of(p41) == l__Type__1.Element and true or typeof(p41) == "boolean";
            assert(v46, "Expected arg #1 to be of type Element or boolean");
        end;
        return {
            [l__Type__1] = l__Type__1.VirtualNode,
            currentElement = p41,
            depth = 1,
            parent = nil,
            children = {},
            hostParent = p42,
            hostKey = p43,
            updateChildrenCount = 0,
            wasUnmounted = false,
            legacyContext = p45,
            parentLegacyContext = p45,
            context = p44 or {},
            originalContext = nil
        };
    end;
    u5 = function(p48, p49, p50, p51, p52) --[[ Name: mountVirtualNode, Line 375 ]]
        -- upvalues: u1 (ref), l__internalAssert__6 (ref), u3 (copy), l__Type__1 (ref), l__ElementKind__2 (ref), u47 (copy), u4 (ref), u24 (copy), l__Children__4 (ref), u20 (copy)
        if u1.internalTypeChecks then
            l__internalAssert__6(u3.isHostObject(p49) or p49 == nil, "Expected arg #2 to be a host object");
            l__internalAssert__6(typeof(p52) == "table" and true or p52 == nil, "Expected arg #5 to be of type table or nil");
        end;
        if u1.typeChecks then
            assert(p50 ~= nil, "Expected arg #3 to be non-nil");
            local v53 = l__Type__1.of(p48) == l__Type__1.Element and true or typeof(p48) == "boolean";
            assert(v53, "Expected arg #1 to be of type Element or boolean");
        end;
        if typeof(p48) == "boolean" then
            return nil;
        else
            local v54 = l__ElementKind__2.of(p48);
            local v55 = u47(p48, p49, p50, p51, p52);
            if v54 == l__ElementKind__2.Host then
                u3.mountHostNode(u4, v55);
                return v55;
            elseif v54 == l__ElementKind__2.Function then
                local l__currentElement__20 = v55.currentElement;
                local v56 = l__currentElement__20.component(l__currentElement__20.props);
                u24(v55, v55.hostParent, v56);
                return v55;
            elseif v54 == l__ElementKind__2.Stateful then
                p48.component:__mount(u4, v55);
                return v55;
            elseif v54 == l__ElementKind__2.Portal then
                local l__currentElement__21 = v55.currentElement;
                local l__target__22 = l__currentElement__21.props.target;
                local v57 = l__currentElement__21.props[l__Children__4];
                local v58 = u3.isHostObject(l__target__22);
                assert(v58, "Expected target to be host object");
                u20(v55, l__target__22, v57);
                return v55;
            elseif v54 == l__ElementKind__2.Fragment then
                u20(v55, v55.hostParent, v55.currentElement.elements);
                return v55;
            else
                error(("Unknown ElementKind %q"):format((tostring(v54))), 2);
                return v55;
            end;
        end;
    end;
    u4 = {
        mountVirtualTree = function(p59, p60, p61) --[[ Name: mountVirtualTree, Line 424 ]]
            -- upvalues: u1 (ref), l__Type__1 (ref), u3 (copy), u2 (ref), u5 (ref)
            if u1.typeChecks then
                local v62 = l__Type__1.of(p59) == l__Type__1.Element;
                assert(v62, "Expected arg #1 to be of type Element");
                local v63 = u3.isHostObject(p60) or p60 == nil;
                assert(v63, "Expected arg #2 to be a host object");
            end;
            local v64 = p61 == nil and "RoactTree" or p61;
            local v65 = {
                [l__Type__1] = l__Type__1.VirtualTree,
                [u2] = {
                    rootNode = nil,
                    mounted = true
                }
            };
            v65[u2].rootNode = u5(p59, p60, v64);
            return v65;
        end,
        unmountVirtualTree = function(p66) --[[ Name: unmountVirtualTree, Line 455 ]]
            -- upvalues: u2 (ref), u1 (ref), l__Type__1 (ref), u7 (ref)
            local v67 = p66[u2];
            if u1.typeChecks then
                local v68 = l__Type__1.of(p66) == l__Type__1.VirtualTree;
                assert(v68, "Expected arg #1 to be a Roact handle");
                assert(v67.mounted, "Cannot unmounted a Roact tree that has already been unmounted");
            end;
            v67.mounted = false;
            if v67.rootNode ~= nil then
                u7(v67.rootNode);
            end;
        end,
        updateVirtualTree = function(p69, p70) --[[ Name: updateVirtualTree, Line 473 ]]
            -- upvalues: u2 (ref), u1 (ref), l__Type__1 (ref), u6 (ref)
            local v71 = p69[u2];
            if u1.typeChecks then
                local v72 = l__Type__1.of(p69) == l__Type__1.VirtualTree;
                assert(v72, "Expected arg #1 to be a Roact handle");
                local v73 = l__Type__1.of(p70) == l__Type__1.Element;
                assert(v73, "Expected arg #2 to be a Roact Element");
            end;
            v71.rootNode = u6(v71.rootNode, p70);
            return p69;
        end,
        createVirtualNode = u47,
        mountVirtualNode = u5,
        unmountVirtualNode = u7,
        updateVirtualNode = u6,
        updateVirtualNodeWithChildren = function(p74, p75, p76) --[[ Name: updateVirtualNodeWithChildren, Line 143 ]]
            -- upvalues: u20 (copy)
            u20(p74, p75, p76);
        end,
        updateVirtualNodeWithRenderResult = u24
    };
    return u4;
end;