-- Roblox: ReplicatedStorage.Packages.Roact.PureComponent
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Component__1 = require(script.Parent.Component);
local v1 = l__Component__1:extend("PureComponent");
v1.extend = l__Component__1.extend;
function v1.shouldUpdate(p2, p3, p4) --[[ Line: 15 ]]
    if p4 ~= p2.state then
        return true;
    end;
    if p3 == p2.props then
        return false;
    end;
    for v5, v6 in pairs(p3) do
        if p2.props[v5] ~= v6 then
            return true;
        end;
    end;
    for v7, v8 in pairs(p2.props) do
        if p3[v7] ~= v8 then
            return true;
        end;
    end;
    return false;
end;
return v1;