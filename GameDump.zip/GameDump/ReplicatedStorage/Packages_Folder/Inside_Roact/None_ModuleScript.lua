-- Roblox: ReplicatedStorage.Packages.Roact.None
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent.Symbol).named("None");