-- Roblox: ReplicatedStorage.Packages.Roact.GlobalConfig
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent.Config).new();