-- Roblox: ReplicatedStorage.Packages.Roact.Component
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__assign__1 = require(script.Parent.assign);
local l__ComponentLifecyclePhase__2 = require(script.Parent.ComponentLifecyclePhase);
local l__Type__3 = require(script.Parent.Type);
local l__Symbol__4 = require(script.Parent.Symbol);
local l__invalidSetStateMessages__5 = require(script.Parent.invalidSetStateMessages);
local l__internalAssert__6 = require(script.Parent.internalAssert);
local u1 = require(script.Parent.GlobalConfig).get();
local u2 = l__Symbol__4.named("InternalData");
local u4 = {
    __tostring = function(p3) --[[ Name: __tostring, Line 29 ]]
        return p3.__componentName;
    end
};
local v5 = {};
setmetatable(v5, u4);
v5[l__Type__3] = l__Type__3.StatefulComponentClass;
v5.__index = v5;
v5.__componentName = "Component";
function v5.extend(p6, p7) --[[ Line: 45 ]]
    -- upvalues: u1 (copy), l__Type__3 (copy), u4 (copy)
    if u1.typeChecks then
        local v8 = l__Type__3.of(p6) == l__Type__3.StatefulComponentClass;
        assert(v8, "Invalid `self` argument to `extend`.");
        local v9 = typeof(p7) == "string";
        assert(v9, "Component class name must be a string");
    end;
    local v10 = {};
    for v11, v12 in pairs(p6) do
        if v11 ~= "extend" then
            v10[v11] = v12;
        end;
    end;
    v10[l__Type__3] = l__Type__3.StatefulComponentClass;
    v10.__index = v10;
    v10.__componentName = p7;
    setmetatable(v10, u4);
    return v10;
end;
function v5.__getDerivedState(p13, p14, p15) --[[ Line: 71 ]]
    -- upvalues: u1 (copy), l__internalAssert__6 (copy), l__Type__3 (copy), u2 (copy)
    if u1.internalTypeChecks then
        l__internalAssert__6(l__Type__3.of(p13) == l__Type__3.StatefulComponentInstance, "Invalid use of `__getDerivedState`");
    end;
    local l__componentClass__7 = p13[u2].componentClass;
    if l__componentClass__7.getDerivedStateFromProps ~= nil then
        local v16 = l__componentClass__7.getDerivedStateFromProps(p14, p15);
        if v16 ~= nil then
            if u1.typeChecks then
                local v17 = typeof(v16) == "table";
                assert(v17, "getDerivedStateFromProps must return a table!");
            end;
            return v16;
        end;
    end;
    return nil;
end;
function v5.setState(p18, p19) --[[ Line: 94 ]]
    -- upvalues: u1 (copy), l__Type__3 (copy), u2 (copy), l__ComponentLifecyclePhase__2 (copy), l__invalidSetStateMessages__5 (copy), l__assign__1 (copy)
    if u1.typeChecks then
        local v20 = l__Type__3.of(p18) == l__Type__3.StatefulComponentInstance;
        assert(v20, "Invalid `self` argument to `extend`.");
    end;
    local v21 = p18[u2];
    local l__lifecyclePhase__8 = v21.lifecyclePhase;
    if l__lifecyclePhase__8 == l__ComponentLifecyclePhase__2.ShouldUpdate or (l__lifecyclePhase__8 == l__ComponentLifecyclePhase__2.WillUpdate or l__lifecyclePhase__8 == l__ComponentLifecyclePhase__2.Render) then
        local v22 = l__invalidSetStateMessages__5[v21.lifecyclePhase]:format((tostring(v21.componentClass)));
        error(v22, 2);
    elseif l__lifecyclePhase__8 == l__ComponentLifecyclePhase__2.WillUnmount then
        return;
    end;
    local l__pendingState__9 = v21.pendingState;
    local v23 = nil;
    if typeof(p19) == "function" then
        v23 = p19(l__pendingState__9 or p18.state, p18.props);
        if v23 == nil then
            return;
        end;
    elseif typeof(p19) == "table" then
        v23 = p19;
    else
        error("Invalid argument to setState, expected function or table", 2);
    end;
    local v24;
    if l__pendingState__9 == nil then
        v24 = l__assign__1({}, p18.state, v23);
    else
        v24 = l__assign__1(l__pendingState__9, v23);
    end;
    if l__lifecyclePhase__8 == l__ComponentLifecyclePhase__2.Init then
        p18.state = l__assign__1(v24, (p18:__getDerivedState(p18.props, v24)));
    elseif l__lifecyclePhase__8 == l__ComponentLifecyclePhase__2.DidMount or (l__lifecyclePhase__8 == l__ComponentLifecyclePhase__2.DidUpdate or l__lifecyclePhase__8 == l__ComponentLifecyclePhase__2.ReconcileChildren) then
        v21.pendingState = l__assign__1(v24, (p18:__getDerivedState(p18.props, v24)));
    elseif l__lifecyclePhase__8 == l__ComponentLifecyclePhase__2.Idle then
        p18:__update(nil, v24);
    else
        local v25 = l__invalidSetStateMessages__5.default:format((tostring(v21.componentClass)));
        error(v25, 2);
    end;
end;
function v5.getElementTraceback(p26) --[[ Line: 178 ]]
    -- upvalues: u2 (copy)
    return p26[u2].virtualNode.currentElement.source;
end;
function v5.render(p27) --[[ Line: 189 ]]
    -- upvalues: u2 (copy)
    local v28 = ("The component %q is missing the `render` method.\n`render` must be defined when creating a Roact component!"):format((tostring(p27[u2].componentClass)));
    error(v28, 0);
end;
function v5.__getContext(p29, p30) --[[ Line: 201 ]]
    -- upvalues: u1 (copy), l__internalAssert__6 (copy), l__Type__3 (copy), u2 (copy)
    if u1.internalTypeChecks then
        l__internalAssert__6(l__Type__3.of(p29) == l__Type__3.StatefulComponentInstance, "Invalid use of `__getContext`");
        l__internalAssert__6(p30 ~= nil, "Context key cannot be nil");
    end;
    return p29[u2].virtualNode.context[p30];
end;
function v5.__addContext(p31, p32, p33) --[[ Line: 217 ]]
    -- upvalues: u1 (copy), l__internalAssert__6 (copy), l__Type__3 (copy), u2 (copy), l__assign__1 (copy)
    if u1.internalTypeChecks then
        l__internalAssert__6(l__Type__3.of(p31) == l__Type__3.StatefulComponentInstance, "Invalid use of `__addContext`");
    end;
    local l__virtualNode__10 = p31[u2].virtualNode;
    if l__virtualNode__10.originalContext == nil then
        l__virtualNode__10.originalContext = l__virtualNode__10.context;
    end;
    l__virtualNode__10.context = l__assign__1({}, l__virtualNode__10.context, {
        [p32] = p33
    });
end;
function v5.__validateProps(p34, p35) --[[ Line: 244 ]]
    -- upvalues: u1 (copy), u2 (copy)
    if u1.propValidation then
        local l__validateProps__11 = p34[u2].componentClass.validateProps;
        if l__validateProps__11 == nil then
        else
            if typeof(l__validateProps__11) ~= "function" then
                error(("validateProps must be a function, but it is a %s.\nCheck the definition of the component %q."):format(typeof(l__validateProps__11), p34.__componentName));
            end;
            local v36, v37 = l__validateProps__11(p35);
            if not v36 then
                error(("Property validation failed in %s: %s\n\n%s"):format(p34.__componentName, tostring(v37 or "<Validator function did not supply a message>"), p34:getElementTraceback() or "<enable element tracebacks>"), 0);
            end;
        end;
    end;
end;
function v5.__mount(p38, p39, p40) --[[ Line: 283 ]]
    -- upvalues: u1 (copy), l__internalAssert__6 (copy), l__Type__3 (copy), l__ComponentLifecyclePhase__2 (copy), u2 (copy), l__assign__1 (copy)
    if u1.internalTypeChecks then
        l__internalAssert__6(l__Type__3.of(p38) == l__Type__3.StatefulComponentClass, "Invalid use of `__mount`");
        l__internalAssert__6(l__Type__3.of(p40) == l__Type__3.VirtualNode, "Expected arg #2 to be of type VirtualNode");
    end;
    local l__currentElement__12 = p40.currentElement;
    local l__hostParent__13 = p40.hostParent;
    local v41 = {
        pendingState = nil,
        reconciler = p39,
        virtualNode = p40,
        componentClass = p38,
        lifecyclePhase = l__ComponentLifecyclePhase__2.Init
    };
    local v42 = {
        [l__Type__3] = l__Type__3.StatefulComponentInstance,
        [u2] = v41
    };
    setmetatable(v42, p38);
    p40.instance = v42;
    local l__props__14 = l__currentElement__12.props;
    if p38.defaultProps ~= nil then
        l__props__14 = l__assign__1({}, p38.defaultProps, l__props__14);
    end;
    v42:__validateProps(l__props__14);
    v42.props = l__props__14;
    v42._context = l__assign__1({}, p40.legacyContext);
    v42.state = l__assign__1({}, v42:__getDerivedState(v42.props, {}));
    if v42.init ~= nil then
        v42:init(v42.props);
        l__assign__1(v42.state, v42:__getDerivedState(v42.props, v42.state));
    end;
    p40.legacyContext = v42._context;
    v41.lifecyclePhase = l__ComponentLifecyclePhase__2.Render;
    local v43 = v42:render();
    v41.lifecyclePhase = l__ComponentLifecyclePhase__2.ReconcileChildren;
    p39.updateVirtualNodeWithRenderResult(p40, l__hostParent__13, v43);
    if v42.didMount ~= nil then
        v41.lifecyclePhase = l__ComponentLifecyclePhase__2.DidMount;
        v42:didMount();
    end;
    if v41.pendingState ~= nil then
        v42:__update(nil, nil);
    end;
    v41.lifecyclePhase = l__ComponentLifecyclePhase__2.Idle;
end;
function v5.__unmount(p44) --[[ Line: 357 ]]
    -- upvalues: u1 (copy), l__internalAssert__6 (copy), l__Type__3 (copy), u2 (copy), l__ComponentLifecyclePhase__2 (copy)
    if u1.internalTypeChecks then
        l__internalAssert__6(l__Type__3.of(p44) == l__Type__3.StatefulComponentInstance, "Invalid use of `__unmount`");
    end;
    local v45 = p44[u2];
    local l__virtualNode__15 = v45.virtualNode;
    local l__reconciler__16 = v45.reconciler;
    if p44.willUnmount ~= nil then
        v45.lifecyclePhase = l__ComponentLifecyclePhase__2.WillUnmount;
        p44:willUnmount();
    end;
    for _, v46 in pairs(l__virtualNode__15.children) do
        l__reconciler__16.unmountVirtualNode(v46);
    end;
end;
function v5.__update(p47, p48, p49) --[[ Line: 382 ]]
    -- upvalues: u1 (copy), l__internalAssert__6 (copy), l__Type__3 (copy), u2 (copy), l__assign__1 (copy)
    if u1.internalTypeChecks then
        l__internalAssert__6(l__Type__3.of(p47) == l__Type__3.StatefulComponentInstance, "Invalid use of `__update`");
        l__internalAssert__6(l__Type__3.of(p48) == l__Type__3.Element and true or p48 == nil, "Expected arg #1 to be of type Element or nil");
        l__internalAssert__6(typeof(p49) == "table" and true or p49 == nil, "Expected arg #2 to be of type table or nil");
    end;
    local v50 = p47[u2];
    local l__componentClass__17 = v50.componentClass;
    local l__props__18 = p47.props;
    if p48 ~= nil then
        l__props__18 = p48.props;
        if l__componentClass__17.defaultProps ~= nil then
            l__props__18 = l__assign__1({}, l__componentClass__17.defaultProps, l__props__18);
        end;
        p47:__validateProps(l__props__18);
    end;
    local v51 = 0;
    while true do
        local v52;
        if v50.pendingState == nil then
            v52 = nil;
        else
            v52 = v50.pendingState;
            v50.pendingState = nil;
        end;
        if p49 ~= nil or l__props__18 ~= p47.props then
            if v52 == nil then
                v52 = p49 or p47.state;
            else
                v52 = l__assign__1(v52, p49);
            end;
            local v53 = p47:__getDerivedState(l__props__18, v52);
            if v53 ~= nil then
                v52 = l__assign__1({}, v52, v53);
            end;
            p49 = nil;
        end;
        if not p47:__resolveUpdate(l__props__18, v52) then
            return false;
        end;
        v51 = v51 + 1;
        if v51 > 100 then
            error(("The component %q has reached the setState update recursion limit.\nWhen using `setState` in `didUpdate`, make sure that it won\'t repeat infinitely!"):format((tostring(v50.componentClass))), 3);
        end;
        if v50.pendingState == nil then
            return true;
        end;
    end;
end;
function v5.__resolveUpdate(p54, p55, p56) --[[ Line: 459 ]]
    -- upvalues: u1 (copy), l__internalAssert__6 (copy), l__Type__3 (copy), u2 (copy), l__ComponentLifecyclePhase__2 (copy)
    if u1.internalTypeChecks then
        l__internalAssert__6(l__Type__3.of(p54) == l__Type__3.StatefulComponentInstance, "Invalid use of `__resolveUpdate`");
    end;
    local v57 = p54[u2];
    local l__virtualNode__19 = v57.virtualNode;
    local l__reconciler__20 = v57.reconciler;
    local l__props__21 = p54.props;
    local l__state__22 = p54.state;
    if p55 == nil then
        p55 = l__props__21;
    end;
    if p56 == nil then
        p56 = l__state__22;
    end;
    if p54.shouldUpdate ~= nil then
        v57.lifecyclePhase = l__ComponentLifecyclePhase__2.ShouldUpdate;
        if not p54:shouldUpdate(p55, p56) then
            v57.lifecyclePhase = l__ComponentLifecyclePhase__2.Idle;
            return false;
        end;
    end;
    if p54.willUpdate ~= nil then
        v57.lifecyclePhase = l__ComponentLifecyclePhase__2.WillUpdate;
        p54:willUpdate(p55, p56);
    end;
    v57.lifecyclePhase = l__ComponentLifecyclePhase__2.Render;
    p54.props = p55;
    p54.state = p56;
    local v58 = l__virtualNode__19.instance:render();
    v57.lifecyclePhase = l__ComponentLifecyclePhase__2.ReconcileChildren;
    l__reconciler__20.updateVirtualNodeWithRenderResult(l__virtualNode__19, l__virtualNode__19.hostParent, v58);
    if p54.didUpdate ~= nil then
        v57.lifecyclePhase = l__ComponentLifecyclePhase__2.DidUpdate;
        p54:didUpdate(l__props__21, l__state__22);
    end;
    v57.lifecyclePhase = l__ComponentLifecyclePhase__2.Idle;
    return true;
end;
return v5;