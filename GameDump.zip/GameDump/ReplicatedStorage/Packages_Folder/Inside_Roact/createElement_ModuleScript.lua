-- Roblox: ReplicatedStorage.Packages.Roact.createElement
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Children__1 = require(script.Parent.PropMarkers.Children);
local l__ElementKind__2 = require(script.Parent.ElementKind);
local l__Logging__3 = require(script.Parent.Logging);
local l__Type__4 = require(script.Parent.Type);
local u1 = require(script.Parent.GlobalConfig).get();
return function(p2, p3, p4) --[[ Name: createElement, Line 37 ]]
    -- upvalues: u1 (copy), l__Children__1 (copy), l__Logging__3 (copy), l__ElementKind__2 (copy), l__Type__4 (copy)
    if u1.typeChecks then
        assert(p2 ~= nil, "`component` is required");
        local v5 = typeof(p3) == "table" and true or p3 == nil;
        assert(v5, "`props` must be a table or nil");
        local v6 = typeof(p4) == "table" and true or p4 == nil;
        assert(v6, "`children` must be a table or nil");
    end;
    local v7 = p3 == nil and {} or p3;
    if p4 ~= nil then
        if v7[l__Children__1] ~= nil then
            l__Logging__3.warnOnce("The prop `Roact.Children` was defined but was overridden by the third parameter to createElement!\nThis can happen when a component passes props through to a child element but also uses the `children` argument:\n\n\tRoact.createElement(\"Frame\", passedProps, {\n\t\tchild = ...\n\t})\n\nInstead, consider using a utility function to merge tables of children together:\n\n\tlocal children = mergeTables(passedProps[Roact.Children], {\n\t\tchild = ...\n\t})\n\n\tlocal fullProps = mergeTables(passedProps, {\n\t\t[Roact.Children] = children\n\t})\n\n\tRoact.createElement(\"Frame\", fullProps)");
        end;
        v7[l__Children__1] = p4;
    end;
    local v8 = l__ElementKind__2.fromComponent(p2);
    local v9 = {
        [l__Type__4] = l__Type__4.Element,
        [l__ElementKind__2] = v8,
        component = p2,
        props = v7
    };
    if u1.elementTracing then
        v9.source = debug.traceback("", 2):sub(2);
    end;
    return v9;
end;