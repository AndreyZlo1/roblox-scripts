-- Roblox: ReplicatedStorage.Packages.Roact.SingleEventManager
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Logging__1 = require(script.Parent.Logging);
local u1 = {};
u1.__index = u1;
function u1.new(p2) --[[ Line: 23 ]]
    -- upvalues: u1 (copy)
    return setmetatable({
        _status = "Disabled",
        _isResuming = false,
        _suspendedEventQueue = {},
        _connections = {},
        _listeners = {},
        _instance = p2
    }, u1);
end;
function u1.connectEvent(p3, p4, p5) --[[ Line: 51 ]]
    p3:_connect(p4, p3._instance[p4], p5);
end;
function u1.connectPropertyChange(u6, u7, p8) --[[ Line: 55 ]]
    local v9, v10 = pcall(function() --[[ Line: 56 ]]
        -- upvalues: u6 (copy), u7 (copy)
        return u6._instance:GetPropertyChangedSignal(u7);
    end);
    if not v9 then
        error(("Cannot get changed signal on property %q: %s"):format(tostring(u7), v10), 0);
    end;
    u6:_connect("Change." .. u7, v10, p8);
end;
function u1._connect(u11, u12, p13, p14) --[[ Line: 67 ]]
    if p14 == nil then
        if u11._connections[u12] ~= nil then
            u11._connections[u12]:Disconnect();
            u11._connections[u12] = nil;
        end;
        u11._listeners[u12] = nil;
    else
        if u11._connections[u12] == nil then
            u11._connections[u12] = p13:Connect(function(...) --[[ Line: 78 ]]
                -- upvalues: u11 (copy), u12 (copy)
                if u11._status == "Enabled" then
                    u11._listeners[u12](u11._instance, ...);
                else
                    if u11._status == "Suspended" then
                        local v15 = { u12, select("#", ...), ... };
                        table.insert(u11._suspendedEventQueue, v15);
                    end;
                end;
            end);
        end;
        u11._listeners[u12] = p14;
    end;
end;
function u1.suspend(p16) --[[ Line: 95 ]]
    p16._status = "Suspended";
end;
function u1.resume(p17) --[[ Line: 99 ]]
    -- upvalues: l__Logging__1 (copy)
    if p17._isResuming then
    else
        p17._isResuming = true;
        local v18 = 1;
        while v18 <= #p17._suspendedEventQueue do
            local v19 = p17._suspendedEventQueue[v18];
            local v20 = p17._listeners[v19[1]];
            local v21 = v19[2];
            if v20 ~= nil then
                local v22 = coroutine.create(v20);
                local v23, v24 = coroutine.resume(v22, p17._instance, unpack(v19, 3, 2 + v21));
                if not v23 then
                    l__Logging__1.warn("%s", v24);
                end;
            end;
            v18 = v18 + 1;
        end;
        p17._isResuming = false;
        p17._status = "Enabled";
        p17._suspendedEventQueue = {};
    end;
end;
return u1;