-- Roblox: ReplicatedStorage.Packages.Roact.Binding
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__createSignal__1 = require(script.Parent.createSignal);
local l__Symbol__2 = require(script.Parent.Symbol);
local l__Type__3 = require(script.Parent.Type);
local u1 = require(script.Parent.GlobalConfig).get();
local u2 = l__Symbol__2.named("BindingImpl");
local u3 = {};
local u8 = {
    __index = {
        getValue = function(p4) --[[ Name: getValue, Line 13 ]]
            -- upvalues: u3 (copy)
            return u3.getValue(p4);
        end,
        map = function(p5, p6) --[[ Name: map, Line 17 ]]
            -- upvalues: u3 (copy)
            return u3.map(p5, p6);
        end
    },
    __tostring = function(p7) --[[ Name: __tostring, Line 23 ]]
        return string.format("RoactBinding(%s)", (tostring(p7:getValue())));
    end
};
function u3.update(p9, p10) --[[ Line: 28 ]]
    -- upvalues: u2 (copy)
    return p9[u2].update(p10);
end;
function u3.subscribe(p11, p12) --[[ Line: 32 ]]
    -- upvalues: u2 (copy)
    return p11[u2].subscribe(p12);
end;
function u3.getValue(p13) --[[ Line: 36 ]]
    -- upvalues: u2 (copy)
    return p13[u2].getValue();
end;
function u3.create(p14) --[[ Line: 40 ]]
    -- upvalues: l__createSignal__1 (copy), l__Type__3 (copy), u2 (copy), u8 (copy)
    local u15 = {
        value = p14,
        changeSignal = l__createSignal__1()
    };
    function u15.subscribe(p16) --[[ Line: 46 ]]
        -- upvalues: u15 (copy)
        return u15.changeSignal:subscribe(p16);
    end;
    function u15.update(p17) --[[ Line: 50 ]]
        -- upvalues: u15 (copy)
        u15.value = p17;
        u15.changeSignal:fire(p17);
    end;
    function u15.getValue() --[[ Line: 55 ]]
        -- upvalues: u15 (copy)
        return u15.value;
    end;
    return setmetatable({
        [l__Type__3] = l__Type__3.Binding,
        [u2] = u15
    }, u8), u15.update;
end;
function u3.map(u18, u19) --[[ Line: 65 ]]
    -- upvalues: u1 (copy), l__Type__3 (copy), u3 (copy), u2 (copy), u8 (copy)
    if u1.typeChecks then
        local v20 = l__Type__3.of(u18) == l__Type__3.Binding;
        assert(v20, "Expected arg #1 to be a binding");
        local v21 = typeof(u19) == "function";
        assert(v21, "Expected arg #1 to be a function");
    end;
    return setmetatable({
        [l__Type__3] = l__Type__3.Binding,
        [u2] = {
            subscribe = function(u22) --[[ Name: subscribe, Line 73 ]]
                -- upvalues: u3 (ref), u18 (copy), u19 (copy)
                return u3.subscribe(u18, function(p23) --[[ Line: 74 ]]
                    -- upvalues: u22 (copy), u19 (ref)
                    u22(u19(p23));
                end);
            end,
            update = function(_) --[[ Name: update, Line 79 ]]
                error("Bindings created by Binding:map(fn) cannot be updated directly", 2);
            end,
            getValue = function() --[[ Name: getValue, Line 83 ]]
                -- upvalues: u19 (copy), u18 (copy)
                return u19(u18:getValue());
            end
        }
    }, u8);
end;
function u3.join(u24) --[[ Line: 93 ]]
    -- upvalues: u1 (copy), l__Type__3 (copy), u3 (copy), u2 (copy), u8 (copy)
    if u1.typeChecks then
        local v25 = typeof(u24) == "table";
        assert(v25, "Expected arg #1 to be of type table");
        for v26, v27 in pairs(u24) do
            if l__Type__3.of(v27) ~= l__Type__3.Binding then
                local v28 = ("Expected arg #1 to contain only bindings, but key %q had a non-binding value"):format((tostring(v26)));
                error(v28, 2);
            end;
        end;
    end;
    local v29 = {};
    local function u33() --[[ Line: 109 ]]
        -- upvalues: u24 (copy)
        local v30 = {};
        for v31, v32 in pairs(u24) do
            v30[v31] = v32:getValue();
        end;
        return v30;
    end;
    function v29.subscribe(u34) --[[ Line: 119 ]]
        -- upvalues: u24 (copy), u3 (ref), u33 (copy)
        local u35 = {};
        for v36, v37 in pairs(u24) do
            u35[v36] = u3.subscribe(v37, function(_) --[[ Line: 123 ]]
                -- upvalues: u34 (copy), u33 (ref)
                u34((u33()));
            end);
        end;
        return function() --[[ Line: 128 ]]
            -- upvalues: u35 (ref)
            if u35 == nil then
            else
                for _, v38 in pairs(u35) do
                    v38();
                end;
                u35 = nil;
            end;
        end;
    end;
    function v29.update(_) --[[ Line: 141 ]]
        error("Bindings created by joinBindings(...) cannot be updated directly", 2);
    end;
    function v29.getValue() --[[ Line: 145 ]]
        -- upvalues: u33 (copy)
        return u33();
    end;
    return setmetatable({
        [l__Type__3] = l__Type__3.Binding,
        [u2] = v29
    }, u8);
end;
return u3;