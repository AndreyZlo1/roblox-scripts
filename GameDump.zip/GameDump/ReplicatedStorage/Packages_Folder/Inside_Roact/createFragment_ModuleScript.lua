-- Roblox: ReplicatedStorage.Packages.Roact.createFragment
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ElementKind__1 = require(script.Parent.ElementKind);
local l__Type__2 = require(script.Parent.Type);
return function(p1) --[[ Name: createFragment, Line 4 ]]
    -- upvalues: l__Type__2 (copy), l__ElementKind__1 (copy)
    return {
        [l__Type__2] = l__Type__2.Element,
        [l__ElementKind__1] = l__ElementKind__1.Fragment,
        elements = p1
    };
end;