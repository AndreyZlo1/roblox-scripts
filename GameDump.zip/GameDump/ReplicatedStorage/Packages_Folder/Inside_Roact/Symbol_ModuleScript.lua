-- Roblox: ReplicatedStorage.Packages.Roact.Symbol
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    named = function(p1) --[[ Name: named, Line 17 ]]
        local v2 = type(p1) == "string";
        assert(v2, "Symbols must be created using a string name!");
        local v3 = newproxy(true);
        local u4 = ("Symbol(%s)"):format(p1);
        getmetatable(v3).__tostring = function() --[[ Line: 24 ]]
            -- upvalues: u4 (copy)
            return u4;
        end;
        return v3;
    end
};