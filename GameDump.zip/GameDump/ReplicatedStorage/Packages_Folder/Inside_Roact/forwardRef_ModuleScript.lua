-- Roblox: ReplicatedStorage.Packages.Roact.forwardRef
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__assign__1 = require(script.Parent.assign);
local l__None__2 = require(script.Parent.None);
local l__Ref__3 = require(script.Parent.PropMarkers.Ref);
local u1 = require(script.Parent.GlobalConfig).get();
local u2 = {
    [l__Ref__3] = l__None__2
};
return function(u3) --[[ Name: forwardRef, Line 15 ]]
    -- upvalues: u1 (copy), l__Ref__3 (copy), l__assign__1 (copy), u2 (copy)
    if u1.typeChecks then
        local v4 = typeof(u3) == "function";
        assert(v4, "Expected arg #1 to be a function");
    end;
    return function(p5) --[[ Line: 20 ]]
        -- upvalues: l__Ref__3 (ref), l__assign__1 (ref), u2 (ref), u3 (copy)
        local v6 = p5[l__Ref__3];
        return u3(l__assign__1({}, p5, u2), v6);
    end;
end;