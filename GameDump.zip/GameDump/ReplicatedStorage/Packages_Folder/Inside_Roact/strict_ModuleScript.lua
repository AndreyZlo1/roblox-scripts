-- Roblox: ReplicatedStorage.Packages.Roact.strict
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function(p1, p2) --[[ Name: strict, Line 2 ]]
    local u3 = p2 or tostring(p1);
    return setmetatable(p1, {
        __index = function(_, p4) --[[ Name: __index, Line 8 ]]
            -- upvalues: u3 (copy)
            local v5 = ("%q (%s) is not a valid member of %s"):format(tostring(p4), typeof(p4), u3);
            error(v5, 2);
        end,
        __newindex = function(_, p6, _) --[[ Name: __newindex, Line 14 ]]
            -- upvalues: u3 (copy)
            local v7 = ("%q (%s) is not a valid member of %s"):format(tostring(p6), typeof(p6), u3);
            error(v7, 2);
        end
    });
end;