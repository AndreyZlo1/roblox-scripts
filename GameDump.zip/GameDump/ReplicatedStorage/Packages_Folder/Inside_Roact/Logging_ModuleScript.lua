-- Roblox: ReplicatedStorage.Packages.Roact.Logging
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = true;
local u2 = {};
local u3 = {};
local function u10(p4, p5) --[[ Line: 34 ]]
    local v6 = {};
    for _, v7 in ipairs(p4) do
        local v8 = ("\t"):rep(p5);
        local v9 = v8 .. v7:gsub("\n", "\n" .. v8);
        table.insert(v6, v9);
    end;
    return table.concat(v6, "\n");
end;
local u16 = {
    __tostring = function(p11) --[[ Name: __tostring, Line 50 ]]
        -- upvalues: u10 (copy)
        local v12 = { "LogInfo {" };
        local v13 = #p11.errors;
        local v14 = #p11.warnings;
        local v15 = #p11.infos;
        if v13 + v14 + v15 == 0 then
            table.insert(v12, "\t(no messages)");
        end;
        if v13 > 0 then
            table.insert(v12, ("\tErrors (%d) {"):format(v13));
            table.insert(v12, u10(p11.errors, 2));
            table.insert(v12, "\t}");
        end;
        if v14 > 0 then
            table.insert(v12, ("\tWarnings (%d) {"):format(v14));
            table.insert(v12, u10(p11.warnings, 2));
            table.insert(v12, "\t}");
        end;
        if v15 > 0 then
            table.insert(v12, ("\tInfos (%d) {"):format(v15));
            table.insert(v12, u10(p11.infos, 2));
            table.insert(v12, "\t}");
        end;
        table.insert(v12, "}");
        return table.concat(v12, "\n");
    end
};
local function u18() --[[ Line: 84 ]]
    -- upvalues: u16 (copy)
    local v17 = {
        errors = {},
        warnings = {},
        infos = {}
    };
    setmetatable(v17, u16);
    return v17;
end;
local u30 = {
    capture = function(p19) --[[ Name: capture, Line 105 ]]
        -- upvalues: u18 (copy), u1 (ref), u2 (copy)
        local v20 = u18();
        local v21 = u1;
        u1 = false;
        u2[v20] = true;
        local v22, v23 = pcall(p19);
        u2[v20] = nil;
        u1 = v21;
        assert(v22, v23);
        return v20;
    end,
    warn = function(p24, ...) --[[ Name: warn, Line 125 ]]
        -- upvalues: u2 (copy), u1 (ref)
        local v25 = p24:format(...);
        for v26 in pairs(u2) do
            table.insert(v26.warnings, v25);
        end;
        local v27 = debug.traceback("", 2):sub(2);
        local v28 = ("\t"):rep(1);
        local v29 = ("%s\n%s"):format(v25, v28 .. v27:gsub("\n", "\n" .. v28));
        if u1 then
            warn(v29);
        end;
    end
};
function u30.warnOnce(p31, ...) --[[ Line: 148 ]]
    -- upvalues: u3 (copy), u30 (copy)
    local v32 = debug.traceback();
    if u3[v32] then
    else
        u3[v32] = true;
        u30.warn(p31, ...);
    end;
end;
return u30;