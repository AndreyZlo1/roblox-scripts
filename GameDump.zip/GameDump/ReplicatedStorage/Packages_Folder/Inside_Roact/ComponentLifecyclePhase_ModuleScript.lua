-- Roblox: ReplicatedStorage.Packages.Roact.ComponentLifecyclePhase
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Symbol__1 = require(script.Parent.Symbol);
return require(script.Parent.strict)({
    Init = l__Symbol__1.named("init"),
    Render = l__Symbol__1.named("render"),
    ShouldUpdate = l__Symbol__1.named("shouldUpdate"),
    WillUpdate = l__Symbol__1.named("willUpdate"),
    DidMount = l__Symbol__1.named("didMount"),
    DidUpdate = l__Symbol__1.named("didUpdate"),
    WillUnmount = l__Symbol__1.named("willUnmount"),
    ReconcileChildren = l__Symbol__1.named("reconcileChildren"),
    Idle = l__Symbol__1.named("idle")
}, "ComponentLifecyclePhase");