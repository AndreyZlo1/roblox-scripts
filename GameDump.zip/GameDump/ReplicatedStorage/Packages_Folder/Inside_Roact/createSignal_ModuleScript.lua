-- Roblox: ReplicatedStorage.Packages.Roact.createSignal
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function() --[[ Name: createSignal, Line 15 ]]
    local u1 = {};
    local u2 = {};
    local u3 = false;
    return {
        subscribe = function(_, u4) --[[ Name: subscribe, Line 20 ]]
            -- upvalues: u3 (ref), u1 (copy), u2 (copy)
            local v5 = typeof(u4) == "function";
            assert(v5, "Can only subscribe to signals with a function.");
            local u6 = {
                disconnected = false,
                callback = u4
            };
            if u3 and not u1[u4] then
                u2[u4] = u6;
            end;
            u1[u4] = u6;
            return function() --[[ Name: disconnect, Line 36 ]]
                -- upvalues: u6 (copy), u1 (ref), u4 (copy), u2 (ref)
                assert(not u6.disconnected, "Listeners can only be disconnected once.");
                u6.disconnected = true;
                u1[u4] = nil;
                u2[u4] = nil;
            end;
        end,
        fire = function(_, ...) --[[ Name: fire, Line 47 ]]
            -- upvalues: u3 (ref), u1 (copy), u2 (copy)
            u3 = true;
            for v7, v8 in pairs(u1) do
                if not (v8.disconnected or u2[v7]) then
                    v7(...);
                end;
            end;
            u3 = false;
            for v9, _ in pairs(u2) do
                u2[v9] = nil;
            end;
        end
    };
end;