-- Roblox: ReplicatedStorage.Packages.Roact.Type
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Symbol__1 = require(script.Parent.Symbol);
local l__strict__2 = require(script.Parent.strict);
local u1 = newproxy(true);
local v3 = {
    Binding = l__Symbol__1.named("RoactBinding"),
    Element = l__Symbol__1.named("RoactElement"),
    HostChangeEvent = l__Symbol__1.named("RoactHostChangeEvent"),
    HostEvent = l__Symbol__1.named("RoactHostEvent"),
    StatefulComponentClass = l__Symbol__1.named("RoactStatefulComponentClass"),
    StatefulComponentInstance = l__Symbol__1.named("RoactStatefulComponentInstance"),
    VirtualNode = l__Symbol__1.named("RoactVirtualNode"),
    VirtualTree = l__Symbol__1.named("RoactVirtualTree"),
    of = function(p2) --[[ Name: of, Line 32 ]]
        -- upvalues: u1 (copy)
        if typeof(p2) == "table" then
            return p2[u1];
        else
            return nil;
        end;
    end
};
getmetatable(u1).__index = v3;
getmetatable(u1).__tostring = function() --[[ Line: 42 ]]
    return "RoactType";
end;
l__strict__2(v3, "Type");
return u1;