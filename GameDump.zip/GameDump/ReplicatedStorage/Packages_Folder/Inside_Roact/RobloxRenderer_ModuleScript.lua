-- Roblox: ReplicatedStorage.Packages.Roact.RobloxRenderer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Binding__1 = require(script.Parent.Binding);
local l__Children__2 = require(script.Parent.PropMarkers.Children);
local l__ElementKind__3 = require(script.Parent.ElementKind);
local l__SingleEventManager__4 = require(script.Parent.SingleEventManager);
local l__getDefaultInstanceProperty__5 = require(script.Parent.getDefaultInstanceProperty);
local l__Ref__6 = require(script.Parent.PropMarkers.Ref);
local l__Type__7 = require(script.Parent.Type);
local l__internalAssert__8 = require(script.Parent.internalAssert);
local u1 = require(script.Parent.GlobalConfig).get();
local function u2(...) --[[ Line: 32 ]]
    return ...;
end;
local function u5(p3, p4) --[[ Line: 36 ]]
    -- upvalues: l__Type__7 (copy), l__Binding__1 (copy)
    if p3 == nil then
    elseif typeof(p3) == "function" then
        p3(p4);
    elseif l__Type__7.of(p3) == l__Type__7.Binding then
        l__Binding__1.update(p3, p4);
    else
        error(("Invalid ref: Expected type Binding but got %s"):format((typeof(p3))));
    end;
end;
local function u17(u6, u7, p8) --[[ Line: 72 ]]
    -- upvalues: l__getDefaultInstanceProperty__5 (copy), u2 (copy), l__Binding__1 (copy)
    local function v16(u9) --[[ Line: 73 ]]
        -- upvalues: u6 (copy), u7 (copy), l__getDefaultInstanceProperty__5 (ref), u2 (ref)
        local v13, v14 = xpcall(function() --[[ Line: 74 ]]
            -- upvalues: u6 (ref), u7 (ref), u9 (copy), l__getDefaultInstanceProperty__5 (ref)
            local l__hostObject__9 = u6.hostObject;
            local v10 = u7;
            local v11 = u9;
            if v11 == nil then
                local v12;
                v12, v11 = l__getDefaultInstanceProperty__5(l__hostObject__9.ClassName, v10);
            end;
            l__hostObject__9[v10] = v11;
        end, u2);
        if not v13 then
            local l__source__10 = u6.currentElement.source;
            local v15 = ("Error updating props:\n\t%s\nIn element:\n%s\n"):format(v14, l__source__10 == nil and "<enable element tracebacks>" or l__source__10);
            error(v15, 0);
        end;
    end;
    if u6.bindings == nil then
        u6.bindings = {};
    end;
    u6.bindings[u7] = l__Binding__1.subscribe(p8, v16);
    v16(p8:getValue());
end;
local function u25(p18, p19, p20, p21) --[[ Line: 108 ]]
    -- upvalues: l__Ref__6 (copy), l__Children__2 (copy), l__Type__7 (copy), l__SingleEventManager__4 (copy), u17 (copy), l__getDefaultInstanceProperty__5 (copy)
    if p20 == p21 then
    elseif p19 == l__Ref__6 or p19 == l__Children__2 then
    else
        local v22 = l__Type__7.of(p19);
        if v22 == l__Type__7.HostEvent or v22 == l__Type__7.HostChangeEvent then
            if p18.eventManager == nil then
                p18.eventManager = l__SingleEventManager__4.new(p18.hostObject);
            end;
            local l__name__11 = p19.name;
            if v22 == l__Type__7.HostChangeEvent then
                p18.eventManager:connectPropertyChange(l__name__11, p20);
            else
                p18.eventManager:connectEvent(l__name__11, p20);
            end;
        else
            local v23 = l__Type__7.of(p20) == l__Type__7.Binding;
            if l__Type__7.of(p21) == l__Type__7.Binding and p18.bindings ~= nil then
                p18.bindings[p19]();
                p18.bindings[p19] = nil;
            end;
            if v23 then
                u17(p18, p19, p20);
            else
                local l__hostObject__12 = p18.hostObject;
                if p20 == nil then
                    local v24;
                    v24, p20 = l__getDefaultInstanceProperty__5(l__hostObject__12.ClassName, p19);
                end;
                l__hostObject__12[p19] = p20;
            end;
        end;
    end;
end;
local function u30(p26, p27) --[[ Line: 150 ]]
    -- upvalues: u25 (copy)
    for v28, v29 in pairs(p27) do
        u25(p26, v28, v29, nil);
    end;
end;
local function u38(p31, p32, p33) --[[ Line: 156 ]]
    -- upvalues: u25 (copy)
    for v34, v35 in pairs(p33) do
        u25(p31, v34, v35, p32[v34]);
    end;
    for v36, v37 in pairs(p32) do
        if p33[v36] == nil then
            u25(p31, v36, nil, v37);
        end;
    end;
end;
return {
    isHostObject = function(p39) --[[ Name: isHostObject, Line 176 ]]
        return typeof(p39) == "Instance";
    end,
    mountHostNode = function(p40, u41) --[[ Name: mountHostNode, Line 180 ]]
        -- upvalues: u1 (copy), l__internalAssert__8 (copy), l__ElementKind__3 (copy), u30 (copy), u2 (copy), l__Children__2 (copy), u5 (copy), l__Ref__6 (copy)
        local l__currentElement__13 = u41.currentElement;
        local l__hostParent__14 = u41.hostParent;
        local l__hostKey__15 = u41.hostKey;
        if u1.internalTypeChecks then
            l__internalAssert__8(l__ElementKind__3.of(l__currentElement__13) == l__ElementKind__3.Host, "Element at given node is not a host Element");
        end;
        if u1.typeChecks then
            assert(l__currentElement__13.props.Name == nil, "Name can not be specified as a prop to a host component in Roact.");
            assert(l__currentElement__13.props.Parent == nil, "Parent can not be specified as a prop to a host component in Roact.");
        end;
        local v42 = Instance.new(l__currentElement__13.component);
        u41.hostObject = v42;
        local v43, v44 = xpcall(function() --[[ Line: 196 ]]
            -- upvalues: u30 (ref), u41 (copy), l__currentElement__13 (copy)
            u30(u41, l__currentElement__13.props);
        end, u2);
        if not v43 then
            local l__source__16 = l__currentElement__13.source;
            local v45 = ("Error applying props:\n\t%s\nIn element:\n%s\n"):format(v44, l__source__16 == nil and "<enable element tracebacks>" or l__source__16);
            error(v45, 0);
        end;
        v42.Name = tostring(l__hostKey__15);
        local v46 = l__currentElement__13.props[l__Children__2];
        if v46 ~= nil then
            p40.updateVirtualNodeWithChildren(u41, u41.hostObject, v46);
        end;
        v42.Parent = l__hostParent__14;
        u41.hostObject = v42;
        u5(l__currentElement__13.props[l__Ref__6], v42);
        if u41.eventManager ~= nil then
            u41.eventManager:resume();
        end;
    end,
    unmountHostNode = function(p47, p48) --[[ Name: unmountHostNode, Line 229 ]]
        -- upvalues: u5 (copy), l__Ref__6 (copy)
        u5(p48.currentElement.props[l__Ref__6], nil);
        for _, v49 in pairs(p48.children) do
            p47.unmountVirtualNode(v49);
        end;
        if p48.bindings ~= nil then
            for _, v50 in pairs(p48.bindings) do
                v50();
            end;
            p48.bindings = nil;
        end;
        p48.hostObject:Destroy();
    end,
    updateHostNode = function(p51, u52, p53) --[[ Name: updateHostNode, Line 243 ]]
        -- upvalues: l__Ref__6 (copy), u5 (copy), u38 (copy), u2 (copy), l__Children__2 (copy)
        local l__props__17 = u52.currentElement.props;
        local l__props__18 = p53.props;
        if u52.eventManager ~= nil then
            u52.eventManager:suspend();
        end;
        if l__props__17[l__Ref__6] ~= l__props__18[l__Ref__6] then
            u5(l__props__17[l__Ref__6], nil);
            u5(l__props__18[l__Ref__6], u52.hostObject);
        end;
        local v54, v55 = xpcall(function() --[[ Line: 257 ]]
            -- upvalues: u38 (ref), u52 (copy), l__props__17 (copy), l__props__18 (copy)
            u38(u52, l__props__17, l__props__18);
        end, u2);
        if not v54 then
            local l__source__19 = p53.source;
            local v56 = ("Error updating props:\n\t%s\nIn element:\n%s\n"):format(v55, l__source__19 == nil and "<enable element tracebacks>" or l__source__19);
            error(v56, 0);
        end;
        local v57 = p53.props[l__Children__2];
        if v57 ~= nil or l__props__17[l__Children__2] ~= nil then
            p51.updateVirtualNodeWithChildren(u52, u52.hostObject, v57);
        end;
        if u52.eventManager ~= nil then
            u52.eventManager:resume();
        end;
        return u52;
    end
};