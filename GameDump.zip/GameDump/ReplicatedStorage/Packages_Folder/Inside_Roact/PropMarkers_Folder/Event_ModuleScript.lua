-- Roblox: ReplicatedStorage.Packages.Roact.PropMarkers.Event
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Type__1 = require(script.Parent.Parent.Type);
local u1 = {};
local u3 = {
    __tostring = function(p2) --[[ Name: __tostring, Line 21 ]]
        return ("RoactHostEvent(%s)"):format(p2.name);
    end
};
setmetatable(u1, {
    __index = function(_, p4) --[[ Name: __index, Line 27 ]]
        -- upvalues: l__Type__1 (copy), u3 (copy), u1 (copy)
        local v5 = {
            [l__Type__1] = l__Type__1.HostEvent,
            name = p4
        };
        setmetatable(v5, u3);
        u1[p4] = v5;
        return v5;
    end
});
return u1;