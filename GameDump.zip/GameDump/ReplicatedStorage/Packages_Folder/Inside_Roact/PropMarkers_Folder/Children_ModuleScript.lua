-- Roblox: ReplicatedStorage.Packages.Roact.PropMarkers.Children
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent.Parent.Symbol).named("Children");