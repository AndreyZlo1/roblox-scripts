-- Roblox: ReplicatedStorage.Packages.Roact.PropMarkers.Ref
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent.Parent.Symbol).named("Ref");