-- Roblox: ReplicatedStorage.Packages.Roact.NoopRenderer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    isHostObject = function(p1) --[[ Name: isHostObject, Line 8 ]]
        return p1 == nil;
    end,
    mountHostNode = function(_, _) --[[ Name: mountHostNode, Line 14 ]] end,
    unmountHostNode = function(_, _) --[[ Name: unmountHostNode, Line 16 ]] end,
    updateHostNode = function(_, p2, _) --[[ Name: updateHostNode, Line 18 ]]
        return p2;
    end
};