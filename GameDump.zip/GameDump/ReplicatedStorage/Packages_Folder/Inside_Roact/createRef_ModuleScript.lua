-- Roblox: ReplicatedStorage.Packages.Roact.createRef
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Binding__1 = require(script.Parent.Binding);
return function() --[[ Name: createRef, Line 7 ]]
    -- upvalues: l__Binding__1 (copy)
    local u1, _ = l__Binding__1.create(nil);
    local v2 = {};
    setmetatable(v2, {
        __index = function(_, p3) --[[ Name: __index, Line 16 ]]
            -- upvalues: u1 (copy)
            if p3 == "current" then
                return u1:getValue();
            else
                return u1[p3];
            end;
        end,
        __newindex = function(_, p4, p5) --[[ Name: __newindex, Line 23 ]]
            -- upvalues: u1 (copy)
            if p4 == "current" then
                error("Cannot assign to the \'current\' property of refs", 2);
            end;
            u1[p4] = p5;
        end,
        __tostring = function(_) --[[ Name: __tostring, Line 30 ]]
            -- upvalues: u1 (copy)
            return ("RoactRef(%s)"):format((tostring(u1:getValue())));
        end
    });
    return v2;
end;