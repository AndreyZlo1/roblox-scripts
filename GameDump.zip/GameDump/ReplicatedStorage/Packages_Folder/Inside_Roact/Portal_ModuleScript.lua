-- Roblox: ReplicatedStorage.Packages.Roact.Portal
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent.Symbol).named("Portal");