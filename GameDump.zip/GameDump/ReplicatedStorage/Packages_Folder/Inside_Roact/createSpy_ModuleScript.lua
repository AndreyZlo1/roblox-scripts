-- Roblox: ReplicatedStorage.Packages.Roact.createSpy
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__assertDeepEqual__1 = require(script.Parent.assertDeepEqual);
return function(u1) --[[ Name: createSpy, Line 11 ]]
    -- upvalues: l__assertDeepEqual__1 (copy)
    local u2 = {
        callCount = 0,
        values = {},
        valuesLength = 0
    };
    function u2.value(...) --[[ Line: 16 ]]
        -- upvalues: u2 (copy), u1 (copy)
        u2.callCount = u2.callCount + 1;
        u2.values = { ... };
        u2.valuesLength = select("#", ...);
        if u1 == nil then
            return nil;
        else
            return u1(...);
        end;
    end;
    function u2.assertCalledWith(_, ...) --[[ Line: 27 ]]
        -- upvalues: u2 (copy)
        local v3 = select("#", ...);
        if u2.valuesLength ~= v3 then
            error(("Expected %d arguments, but was called with %d arguments"):format(u2.valuesLength, v3), 2);
        end;
        for v4 = 1, v3 do
            local v5 = select(v4, ...) == u2.values[v4];
            assert(v5, "value differs");
        end;
    end;
    function u2.assertCalledWithDeepEqual(_, ...) --[[ Line: 41 ]]
        -- upvalues: u2 (copy), l__assertDeepEqual__1 (ref)
        local v6 = select("#", ...);
        if u2.valuesLength ~= v6 then
            error(("Expected %d arguments, but was called with %d arguments"):format(u2.valuesLength, v6), 2);
        end;
        for v7 = 1, v6 do
            local v8 = select(v7, ...);
            l__assertDeepEqual__1(u2.values[v7], v8);
        end;
    end;
    function u2.captureValues(_, ...) --[[ Line: 55 ]]
        -- upvalues: u2 (copy)
        local v9 = select("#", ...);
        assert(u2.valuesLength == v9, "length of expected values differs from stored values");
        local v10 = {};
        for v11 = 1, v9 do
            v10[select(v11, ...)] = u2.values[v11];
        end;
        return v10;
    end;
    setmetatable(u2, {
        __index = function(_, p12) --[[ Name: __index, Line 70 ]]
            error(("%q is not a valid member of spy"):format(p12));
        end
    });
    return u2;
end;