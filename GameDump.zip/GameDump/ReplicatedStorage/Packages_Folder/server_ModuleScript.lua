-- Roblox: ReplicatedStorage.Packages.server
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__RunService__1 = game:GetService("RunService");
local l__HttpService__2 = game:GetService("HttpService");
local l__ReplicatedStorage__3 = game:GetService("ReplicatedStorage");
local l__signal__4 = require(script.Parent:WaitForChild("signal"));
local l__defaults__5 = require(script:WaitForChild("defaults"));
local u1 = {};
function u1.new() --[[ Line: 21 ]]
    -- upvalues: l__RunService__1 (copy), l__ReplicatedStorage__3 (copy), l__HttpService__2 (copy), l__defaults__5 (copy), l__signal__4 (copy), u1 (copy)
    local u2 = {};
    local v3 = nil;
    local v4;
    if l__RunService__1:IsServer() or l__RunService__1:IsStudio() and not l__RunService__1:IsRunning() then
        v3 = Instance.new("StringValue");
        v3.Name = "Settings";
        v3.Parent = l__ReplicatedStorage__3;
        v3.Value = l__HttpService__2:JSONEncode(l__defaults__5);
        v4 = l__defaults__5;
    else
        local u5 = l__signal__4.new();
        local l__Settings__6 = l__ReplicatedStorage__3:WaitForChild("Settings");
        l__Settings__6.Changed:Connect(function(p6) --[[ Line: 34 ]]
            -- upvalues: l__HttpService__2 (ref), u2 (ref), u5 (copy)
            local v7 = l__HttpService__2:JSONDecode(p6);
            for v8, v9 in v7 do
                u2[v8] = v9;
            end;
            for v10, _ in u2 do
                u2[v10] = v7[v10];
            end;
            u2.Changed = u5;
            u5:Fire(u2);
        end);
        local v11 = l__HttpService__2:JSONDecode(l__Settings__6.Value);
        v11.Changed = u5;
        v4 = v11;
    end;
    return setmetatable({
        _cache = v4,
        _value = v3
    }, u1);
end;
function u1.__index(p12, p13) --[[ Line: 62 ]]
    return p12._cache[p13];
end;
function u1.__newindex(p14, p15, p16) --[[ Line: 70 ]]
    -- upvalues: l__HttpService__2 (copy)
    if not p14._value then
        error("Server globals cannot be written by the client.");
    end;
    p14._cache[p15] = p16;
    p14._value.Value = l__HttpService__2:JSONEncode(p14._cache);
end;
return u1.new();