-- Roblox: ReplicatedStorage.Packages.Rodux.thunkMiddleware.spec
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function() --[[ Line: 1 ]]
    local l__Store__1 = require(script.Parent.Store);
    local l__thunkMiddleware__2 = require(script.Parent.thunkMiddleware);
    it("should dispatch thunks", function() --[[ Line: 5 ]]
        -- upvalues: l__Store__1 (copy), l__thunkMiddleware__2 (copy)
        local v2 = l__Store__1.new(function(p1, _) --[[ Name: reducer, Line 6 ]]
            return p1;
        end, {}, { l__thunkMiddleware__2 });
        local u3 = 0;
        v2:dispatch(function(_) --[[ Name: thunk, Line 13 ]]
            -- upvalues: u3 (ref)
            u3 = u3 + 1;
        end);
        expect(u3).to.equal(1);
    end);
    it("should allow normal actions to pass through", function() --[[ Line: 22 ]]
        -- upvalues: l__Store__1 (copy), l__thunkMiddleware__2 (copy)
        local u4 = 0;
        l__Store__1.new(function(p5, _) --[[ Name: reducer, Line 25 ]]
            -- upvalues: u4 (ref)
            u4 = u4 + 1;
            return p5;
        end, {}, { l__thunkMiddleware__2 }):dispatch({
            type = "test"
        });
        expect(u4).to.equal(2);
    end);
    it("should return the value from the thunk", function() --[[ Line: 42 ]]
        -- upvalues: l__Store__1 (copy), l__thunkMiddleware__2 (copy)
        local v7 = l__Store__1.new(function(p6, _) --[[ Name: reducer, Line 43 ]]
            return p6;
        end, {}, { l__thunkMiddleware__2 }):dispatch(function(_) --[[ Name: thunk, Line 50 ]]
            return "test";
        end);
        expect(v7).to.equal("test");
    end);
end;