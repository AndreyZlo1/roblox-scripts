-- Roblox: ReplicatedStorage.Packages.Rodux.loggerMiddleware.spec
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function() --[[ Line: 1 ]]
    local l__Store__1 = require(script.Parent.Store);
    local l__loggerMiddleware__2 = require(script.Parent.loggerMiddleware);
    it("should print whenever an action is dispatched", function() --[[ Line: 5 ]]
        -- upvalues: l__Store__1 (copy), l__loggerMiddleware__2 (copy)
        local u1 = 0;
        local u2 = nil;
        local v4 = l__Store__1.new(function(p3, _) --[[ Name: reducer, Line 9 ]]
            return p3;
        end, {
            fooValue = 12345,
            barValue = {
                bazValue = "hiBaz"
            }
        }, { l__loggerMiddleware__2.middleware });
        function l__loggerMiddleware__2.outputFunction(p5) --[[ Line: 20 ]]
            -- upvalues: u1 (ref), u2 (ref)
            u1 = u1 + 1;
            u2 = p5;
        end;
        v4:dispatch({
            type = "testActionType"
        });
        expect(u1).to.equal(1);
        expect(u2:find("testActionType")).to.be.ok();
        expect(u2:find("fooValue")).to.be.ok();
        expect(u2:find("12345")).to.be.ok();
        expect(u2:find("barValue")).to.be.ok();
        expect(u2:find("bazValue")).to.be.ok();
        expect(u2:find("hiBaz")).to.be.ok();
        l__loggerMiddleware__2.outputFunction = print;
    end);
end;