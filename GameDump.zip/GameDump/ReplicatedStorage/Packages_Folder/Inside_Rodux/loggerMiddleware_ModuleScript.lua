-- Roblox: ReplicatedStorage.Packages.Rodux.loggerMiddleware
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local function u10(p1, p2) --[[ Line: 3 ]]
    -- upvalues: u10 (copy)
    local v3 = p2 or 0;
    local v4 = {};
    if typeof(p1) == "table" then
        table.insert(v4, "{\n");
        for v5, v6 in pairs(p1) do
            table.insert(v4, ("    "):rep(v3 + 1));
            local v7 = tostring(v5);
            table.insert(v4, v7);
            table.insert(v4, " = ");
            table.insert(v4, u10(v6, v3 + 1));
            table.insert(v4, "\n");
        end;
        table.insert(v4, ("    "):rep(v3));
        table.insert(v4, "}");
    elseif typeof(p1) == "string" then
        table.insert(v4, string.format("%q", p1));
        table.insert(v4, " (string)");
    else
        local v8 = tostring(p1);
        table.insert(v4, v8);
        table.insert(v4, " (");
        local v9 = typeof(p1);
        table.insert(v4, v9);
        table.insert(v4, ")");
    end;
    return table.concat(v4, "");
end;
local u11 = {
    outputFunction = print
};
function u11.middleware(u12, u13) --[[ Line: 42 ]]
    -- upvalues: u11 (copy), u10 (copy)
    return function(p14) --[[ Line: 43 ]]
        -- upvalues: u12 (copy), u11 (ref), u10 (ref), u13 (copy)
        local v15 = u12(p14);
        u11.outputFunction(("Action dispatched: %s\nState changed to: %s"):format(u10(p14), u10(u13:getState())));
        return v15;
    end;
end;
return u11;