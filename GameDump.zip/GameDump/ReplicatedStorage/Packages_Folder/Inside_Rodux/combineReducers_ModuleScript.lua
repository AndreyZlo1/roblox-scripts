-- Roblox: ReplicatedStorage.Packages.Rodux.combineReducers
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function(u1) --[[ Name: combineReducers, Line 4 ]]
    return function(p2, p3) --[[ Line: 5 ]]
        -- upvalues: u1 (copy)
        local v4 = p2 == nil and {} or p2;
        local v5 = {};
        for v6, v7 in pairs(u1) do
            v5[v6] = v7(v4[v6], p3);
        end;
        return v5;
    end;
end;