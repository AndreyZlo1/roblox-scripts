-- Roblox: ReplicatedStorage.Packages.Rodux.NoYield
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local function u3(p1, p2, ...) --[[ Line: 10 ]]
    if not p2 then
        error(debug.traceback(p1, (...)), 2);
    end;
    if coroutine.status(p1) ~= "dead" then
        error(debug.traceback(p1, "Attempted to yield inside changed event!"), 2);
    end;
    return ...;
end;
return function(p4, ...) --[[ Name: NoYield, Line 23 ]]
    -- upvalues: u3 (copy)
    local v5 = coroutine.create(p4);
    return u3(v5, coroutine.resume(v5, ...));
end;