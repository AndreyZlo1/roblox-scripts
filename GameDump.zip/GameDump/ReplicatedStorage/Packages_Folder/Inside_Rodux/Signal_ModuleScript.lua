-- Roblox: ReplicatedStorage.Packages.Rodux.Signal
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local function u6(p1, ...) --[[ Line: 8 ]]
    local v2 = #p1;
    local v3 = {};
    for v4 = 1, v2 do
        v3[v4] = p1[v4];
    end;
    for v5 = 1, select("#", ...) do
        v3[v2 + v5] = select(v5, ...);
    end;
    return v3;
end;
local function u11(p7, p8) --[[ Line: 23 ]]
    local v9 = {};
    for v10 = 1, #p7 do
        if p7[v10] ~= p8 then
            table.insert(v9, p7[v10]);
        end;
    end;
    return v9;
end;
local u12 = {};
u12.__index = u12;
function u12.new() --[[ Line: 39 ]]
    -- upvalues: u12 (copy)
    local v13 = {
        _listeners = {}
    };
    setmetatable(v13, u12);
    return v13;
end;
function u12.connect(u14, p15) --[[ Line: 49 ]]
    -- upvalues: u6 (copy), u11 (copy)
    local u16 = {
        disconnected = false,
        callback = p15
    };
    u14._listeners = u6(u14._listeners, u16);
    return {
        disconnect = function() --[[ Name: disconnect, Line 57 ]]
            -- upvalues: u16 (copy), u14 (copy), u11 (ref)
            u16.disconnected = true;
            u14._listeners = u11(u14._listeners, u16);
        end
    };
end;
function u12.fire(p17, ...) --[[ Line: 67 ]]
    for _, v18 in ipairs(p17._listeners) do
        if not v18.disconnected then
            v18.callback(...);
        end;
    end;
end;
return u12;