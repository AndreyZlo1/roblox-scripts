-- Roblox: ReplicatedStorage.Packages.Rodux.Store.spec
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function() --[[ Line: 1 ]]
    local l__Store__1 = require(script.Parent.Store);
    describe("new", function() --[[ Line: 4 ]]
        -- upvalues: l__Store__1 (copy)
        it("should instantiate with a reducer", function() --[[ Line: 5 ]]
            -- upvalues: l__Store__1 (ref)
            local v1 = l__Store__1.new(function(_, _) --[[ Line: 6 ]]
                return "hello, world";
            end);
            expect(v1).to.be.ok();
            expect(v1:getState()).to.equal("hello, world");
            v1:destruct();
        end);
        it("should instantiate with a reducer and an initial state", function() --[[ Line: 16 ]]
            -- upvalues: l__Store__1 (ref)
            local v3 = l__Store__1.new(function(p2, _) --[[ Line: 17 ]]
                return p2;
            end, "initial state");
            expect(v3).to.be.ok();
            expect(v3:getState()).to.equal("initial state");
            v3:destruct();
        end);
        it("should instantiate with a reducer, initial state, and middlewares", function() --[[ Line: 27 ]]
            -- upvalues: l__Store__1 (ref)
            local v5 = l__Store__1.new(function(p4, _) --[[ Line: 28 ]]
                return p4;
            end, "initial state", {});
            expect(v5).to.be.ok();
            expect(v5:getState()).to.equal("initial state");
            v5:destruct();
        end);
        it("should modify the dispatch method when middlewares are passed", function() --[[ Line: 38 ]]
            -- upvalues: l__Store__1 (ref)
            local u6 = 0;
            local u7 = 0;
            local u8 = nil;
            local u9 = nil;
            local u10 = nil;
            local v16 = l__Store__1.new(function(p11, p12) --[[ Name: reducer, Line 45 ]]
                return p12.type == "test" and "test state" or p11;
            end, "initial state", { function(u13, p14) --[[ Name: testMiddleware, Line 53 ]]
                    -- upvalues: u6 (ref), u8 (ref), u9 (ref), u7 (ref), u10 (ref)
                    u6 = u6 + 1;
                    u8 = u13;
                    u9 = p14;
                    return function(p15) --[[ Line: 58 ]]
                        -- upvalues: u7 (ref), u10 (ref), u13 (copy)
                        u7 = u7 + 1;
                        u10 = p15;
                        u13(p15);
                    end;
                end });
            expect(u6).to.equal(1);
            expect(u7).to.equal(0);
            expect(u8).to.be.a("function");
            expect(u9).to.equal(v16);
            v16:dispatch({
                type = "test"
            });
            expect(u6).to.equal(1);
            expect(u7).to.equal(1);
            expect(u10.type).to.equal("test");
            v16:flush();
            expect(v16:getState()).to.equal("test state");
            v16:destruct();
        end);
        it("should execute middleware left-to-right", function() --[[ Line: 88 ]]
            -- upvalues: l__Store__1 (ref)
            local u17 = {};
            local v23 = l__Store__1.new(function(p18) --[[ Name: reducer, Line 91 ]]
                return p18;
            end, 5, { function(u19, _) --[[ Name: middlewareA, Line 95 ]]
                    -- upvalues: u17 (copy)
                    table.insert(u17, "instantiate a");
                    return function(p20) --[[ Line: 97 ]]
                        -- upvalues: u17 (ref), u19 (copy)
                        table.insert(u17, "execute a");
                        return u19(p20);
                    end;
                end, function(u21, _) --[[ Name: middlewareB, Line 103 ]]
                    -- upvalues: u17 (copy)
                    table.insert(u17, "instantiate b");
                    return function(p22) --[[ Line: 105 ]]
                        -- upvalues: u17 (ref), u21 (copy)
                        table.insert(u17, "execute b");
                        return u21(p22);
                    end;
                end });
            expect(#u17).to.equal(2);
            expect(u17[1]).to.equal("instantiate b");
            expect(u17[2]).to.equal("instantiate a");
            v23:dispatch({
                type = "test"
            });
            expect(#u17).to.equal(4);
            expect(u17[3]).to.equal("execute a");
            expect(u17[4]).to.equal("execute b");
            v23:destruct();
        end);
        it("should send an initial action with a \'type\' field", function() --[[ Line: 128 ]]
            -- upvalues: l__Store__1 (ref)
            local u24 = nil;
            local u25 = 0;
            local v28 = l__Store__1.new(function(p26, p27) --[[ Line: 132 ]]
                -- upvalues: u24 (ref), u25 (ref)
                u24 = p27;
                u25 = u25 + 1;
                return p26;
            end);
            expect(u25).to.equal(1);
            expect(u24).to.be.a("table");
            expect(u24.type).to.be.ok();
            v28:destruct();
        end);
    end);
    describe("getState", function() --[[ Line: 147 ]]
        -- upvalues: l__Store__1 (copy)
        it("should get the current state", function() --[[ Line: 148 ]]
            -- upvalues: l__Store__1 (ref)
            local v29 = l__Store__1.new(function(_, _) --[[ Line: 149 ]]
                return "foo";
            end);
            local v30 = v29:getState();
            expect(v30).to.equal("foo");
            v29:destruct();
        end);
    end);
    describe("dispatch", function() --[[ Line: 161 ]]
        -- upvalues: l__Store__1 (copy)
        it("should be sent through the reducer", function() --[[ Line: 162 ]]
            -- upvalues: l__Store__1 (ref)
            local v33 = l__Store__1.new(function(p31, p32) --[[ Line: 163 ]]
                return p32.type == "act" and "bar" or (p31 or "foo");
            end);
            expect(v33).to.be.ok();
            expect(v33:getState()).to.equal("foo");
            v33:dispatch({
                type = "act"
            });
            v33:flush();
            expect(v33:getState()).to.equal("bar");
            v33:destruct();
        end);
        it("should trigger the changed event after a flush", function() --[[ Line: 187 ]]
            -- upvalues: l__Store__1 (ref)
            local v37 = l__Store__1.new(function(p34, p35) --[[ Line: 188 ]]
                local v36 = p34 or 0;
                if p35.type == "increment" then
                    return v36 + 1;
                else
                    return v36;
                end;
            end);
            local u38 = 0;
            v37.changed:connect(function(p39, p40) --[[ Line: 200 ]]
                -- upvalues: u38 (ref)
                expect(p40).to.equal(0);
                expect(p39).to.equal(1);
                u38 = u38 + 1;
            end);
            v37:dispatch({
                type = "increment"
            });
            v37:flush();
            expect(u38).to.equal(1);
            v37:destruct();
        end);
        it("should handle actions dispatched within the changed event", function() --[[ Line: 218 ]]
            -- upvalues: l__Store__1 (ref)
            local u44 = l__Store__1.new(function(p41, p42) --[[ Line: 219 ]]
                local v43 = p41 or {
                    value = 0
                };
                return p42.type == "increment" and {
                    value = v43.value + 1
                } or (p42.type == "decrement" and {
                    value = v43.value - 1
                } or v43);
            end);
            local u45 = 0;
            u44.changed:connect(function(p46, p47) --[[ Line: 239 ]]
                -- upvalues: u44 (copy), u45 (ref)
                expect(p46).never.to.equal(p47);
                if p46.value > 0 then
                    u44:dispatch({
                        type = "decrement"
                    });
                end;
                u45 = u45 + 1;
            end);
            u44:dispatch({
                type = "increment"
            });
            u44:flush();
            u44:flush();
            expect(u45).to.equal(2);
            u44:destruct();
        end);
        it("should prevent yielding from changed handler", function() --[[ Line: 262 ]]
            -- upvalues: l__Store__1 (ref)
            local u48 = 0;
            local u49 = 0;
            local u51 = l__Store__1.new(function(p50, _) --[[ Line: 266 ]]
                return (p50 or 0) + 1;
            end);
            u51.changed:connect(function(_, _) --[[ Line: 271 ]]
                -- upvalues: u48 (ref), u49 (ref)
                u48 = u48 + 1;
                wait();
                u49 = u49 + 1;
            end);
            u51:dispatch({
                type = "increment"
            });
            expect(function() --[[ Line: 281 ]]
                -- upvalues: u51 (copy)
                u51:flush();
            end).to.throw();
            expect(u48).to.equal(1);
            expect(u49).to.equal(0);
            u51:destruct();
        end);
        it("should throw if an action is dispatched without a type field", function() --[[ Line: 291 ]]
            -- upvalues: l__Store__1 (ref)
            local u53 = l__Store__1.new(function(p52, _) --[[ Line: 292 ]]
                return p52;
            end);
            expect(function() --[[ Line: 296 ]]
                -- upvalues: u53 (copy)
                u53:dispatch({});
            end).to.throw();
            u53:destruct();
        end);
        it("should throw if the action is not a function or table", function() --[[ Line: 303 ]]
            -- upvalues: l__Store__1 (ref)
            local u55 = l__Store__1.new(function(p54, _) --[[ Line: 304 ]]
                return p54;
            end);
            expect(function() --[[ Line: 308 ]]
                -- upvalues: u55 (copy)
                u55:dispatch(1);
            end).to.throw();
            u55:destruct();
        end);
    end);
    describe("flush", function() --[[ Line: 316 ]]
        -- upvalues: l__Store__1 (copy)
        it("should not fire a changed event if there were no dispatches", function() --[[ Line: 317 ]]
            -- upvalues: l__Store__1 (ref)
            local v56 = l__Store__1.new(function() --[[ Line: 318 ]] end);
            local u57 = 0;
            v56.changed:connect(function() --[[ Line: 322 ]]
                -- upvalues: u57 (ref)
                u57 = u57 + 1;
            end);
            v56:flush();
            expect(u57).to.equal(0);
            v56:dispatch({
                type = "increment"
            });
            v56:flush();
            expect(u57).to.equal(1);
            v56:flush();
            expect(u57).to.equal(1);
            v56:destruct();
        end);
    end);
end;