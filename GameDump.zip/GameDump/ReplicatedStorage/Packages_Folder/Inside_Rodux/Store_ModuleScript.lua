-- Roblox: ReplicatedStorage.Packages.Rodux.Store
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__RunService__1 = game:GetService("RunService");
local l__Signal__2 = require(script.Parent.Signal);
local l__NoYield__3 = require(script.Parent.NoYield);
local u1 = {
    _flushEvent = l__RunService__1.Heartbeat
};
u1.__index = u1;
function u1.new(p2, p3, p4) --[[ Line: 26 ]]
    -- upvalues: l__Signal__2 (copy), u1 (copy)
    local v5 = typeof(p2) == "function";
    assert(v5, "Bad argument #1 to Store.new, expected function.");
    local v6 = p4 == nil and true or typeof(p4) == "table";
    assert(v6, "Bad argument #3 to Store.new, expected nil or table.");
    local u7 = {
        _reducer = p2,
        _state = p2(p3, {
            type = "@@INIT"
        })
    };
    u7._lastState = u7._state;
    u7._mutatedSinceFlush = false;
    u7._connections = {};
    u7.changed = l__Signal__2.new();
    setmetatable(u7, u1);
    local v8 = u7._flushEvent:Connect(function() --[[ Line: 45 ]]
        -- upvalues: u7 (copy)
        u7:flush();
    end);
    table.insert(u7._connections, v8);
    if p4 then
        local l__dispatch__4 = u7.dispatch;
        local function u9(...) --[[ Line: 52 ]]
            -- upvalues: l__dispatch__4 (copy), u7 (copy)
            return l__dispatch__4(u7, ...);
        end;
        for v10 = #p4, 1, -1 do
            u9 = p4[v10](u9, u7);
        end;
        function u7.dispatch(_, ...) --[[ Line: 61 ]]
            -- upvalues: u9 (ref)
            return u9(...);
        end;
    end;
    return u7;
end;
function u1.getState(p11) --[[ Line: 72 ]]
    return p11._state;
end;
function u1.dispatch(p12, p13) --[[ Line: 83 ]]
    if typeof(p13) == "table" then
        if p13.type == nil then
            error("action does not have a type field", 2);
        end;
        p12._state = p12._reducer(p12._state, p13);
        p12._mutatedSinceFlush = true;
    else
        error(("actions of type %q are not permitted"):format((typeof(p13))), 2);
    end;
end;
function u1.destruct(p14) --[[ Line: 99 ]]
    for _, v15 in ipairs(p14._connections) do
        v15:Disconnect();
    end;
    p14._connections = nil;
end;
function u1.flush(u16) --[[ Line: 110 ]]
    -- upvalues: l__NoYield__3 (copy)
    if u16._mutatedSinceFlush then
        u16._mutatedSinceFlush = false;
        local l___state__5 = u16._state;
        l__NoYield__3(function() --[[ Line: 124 ]]
            -- upvalues: u16 (copy), l___state__5 (copy)
            u16.changed:fire(l___state__5, u16._lastState);
        end);
        u16._lastState = l___state__5;
    end;
end;
return u1;