-- Roblox: ReplicatedStorage.Packages.Rodux.createReducer.spec
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function() --[[ Line: 1 ]]
    local l__createReducer__1 = require(script.Parent.createReducer);
    it("should handle actions", function() --[[ Line: 4 ]]
        -- upvalues: l__createReducer__1 (copy)
        local v3 = l__createReducer__1({
            a = 0,
            b = 0
        }, {
            a = function(p1, _) --[[ Name: a, Line 9 ]]
                return {
                    a = p1.a + 1,
                    b = p1.b
                };
            end,
            b = function(p2, _) --[[ Name: b, Line 15 ]]
                return {
                    a = p2.a,
                    b = p2.b + 2
                };
            end
        });
        local v4 = v3({
            a = 0,
            b = 0
        }, {
            type = "a"
        });
        expect(v4.a).to.equal(1);
        local v5 = v3(v4, {
            type = "b"
        });
        expect(v5.b).to.equal(2);
    end);
    it("should return the initial state if the state is nil", function() --[[ Line: 39 ]]
        -- upvalues: l__createReducer__1 (copy)
        local v6 = l__createReducer__1({
            a = 0,
            b = 0
        }, {})(nil, {});
        expect(v6).to.be.ok();
        expect(v6.a).to.equal(0);
        expect(v6.b).to.equal(0);
    end);
    it("should still run action handlers if the state is nil", function() --[[ Line: 52 ]]
        -- upvalues: l__createReducer__1 (copy)
        local u7 = 0;
        local v8 = l__createReducer__1(0, {
            foo = function(_, _) --[[ Name: foo, Line 56 ]]
                -- upvalues: u7 (ref)
                u7 = u7 + 1;
                return nil;
            end
        });
        expect(u7).to.equal(0);
        local v9 = v8(nil, {
            type = "foo"
        });
        expect(u7).to.equal(1);
        expect(v9).to.equal(nil);
        local v10 = v8(v9, {
            type = "foo"
        });
        expect(u7).to.equal(2);
        expect(v10).to.equal(nil);
    end);
    it("should return the same state if the action is not handled", function() --[[ Line: 79 ]]
        -- upvalues: l__createReducer__1 (copy)
        local v11 = {
            a = 0,
            b = 0
        };
        local v14 = l__createReducer__1(v11, {
            a = function(p12, _) --[[ Name: a, Line 86 ]]
                return {
                    a = p12.a + 1,
                    b = p12.b
                };
            end,
            b = function(p13, _) --[[ Name: b, Line 92 ]]
                return {
                    a = p13.a,
                    b = p13.b + 2
                };
            end
        })(v11, {
            type = "c"
        });
        expect(v14).to.equal(v11);
    end);
end;