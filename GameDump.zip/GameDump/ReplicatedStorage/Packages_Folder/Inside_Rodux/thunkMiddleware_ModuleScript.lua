-- Roblox: ReplicatedStorage.Packages.Rodux.thunkMiddleware
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function(u1, u2) --[[ Name: thunkMiddleware, Line 7 ]]
    return function(p3) --[[ Line: 8 ]]
        -- upvalues: u2 (copy), u1 (copy)
        if typeof(p3) == "function" then
            return p3(u2);
        else
            return u1(p3);
        end;
    end;
end;