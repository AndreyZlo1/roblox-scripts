-- Roblox: ReplicatedStorage.Packages.Rodux.init.spec
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function() --[[ Line: 1 ]]
    describe("Rodux", function() --[[ Line: 2 ]]
        it("should load", function() --[[ Line: 3 ]]
            local l__Parent__1 = require(script.Parent);
            expect(l__Parent__1.Store).to.be.ok();
        end);
    end);
end;