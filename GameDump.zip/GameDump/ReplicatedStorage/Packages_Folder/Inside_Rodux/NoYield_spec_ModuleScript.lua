-- Roblox: ReplicatedStorage.Packages.Rodux.NoYield.spec
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function() --[[ Line: 1 ]]
    local l__NoYield__1 = require(script.Parent.NoYield);
    it("should call functions normally", function() --[[ Line: 4 ]]
        -- upvalues: l__NoYield__1 (copy)
        local u1 = 0;
        local v4, v5 = l__NoYield__1(function(p2, p3) --[[ Name: test, Line 7 ]]
            -- upvalues: u1 (ref)
            expect(p2).to.equal(5);
            expect(p3).to.equal(6);
            u1 = u1 + 1;
            return 11, "hello";
        end, 5, 6);
        expect(v4).to.equal(11);
        expect(v5).to.equal("hello");
    end);
    it("should throw on yield", function() --[[ Line: 22 ]]
        -- upvalues: l__NoYield__1 (copy)
        local u6 = 0;
        local u7 = 0;
        local v8, v9 = pcall(l__NoYield__1, function() --[[ Name: testMethod, Line 26 ]]
            -- upvalues: u6 (ref), u7 (ref)
            u6 = u6 + 1;
            wait();
            u7 = u7 + 1;
        end);
        expect(u6).to.equal(1);
        expect(u7).to.equal(0);
        expect(v8).to.equal(false);
        expect(v9:find("Attempted to yield inside changed event!")).to.be.ok();
        expect(v9:find("NoYield.spec")).to.be.ok();
    end);
    it("should propagate error messages", function() --[[ Line: 42 ]]
        -- upvalues: l__NoYield__1 (copy)
        local u10 = 0;
        local v11, v12 = pcall(l__NoYield__1, function() --[[ Name: test, Line 45 ]]
            -- upvalues: u10 (ref)
            u10 = u10 + 1;
            error("foo");
        end);
        expect(v11).to.equal(false);
        expect(v12:find("foo")).to.be.ok();
        expect(v12:find("NoYield.spec")).to.be.ok();
    end);
end;