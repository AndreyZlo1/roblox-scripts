-- Roblox: ReplicatedStorage.Packages.Rodux.makeActionCreator
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function(u1, u2) --[[ Name: makeActionCreator, Line 4 ]]
    local v3 = type(u1) == "string";
    assert(v3, "Bad argument #1: Expected a string name for the action creator");
    local v4 = type(u2) == "function";
    assert(v4, "Bad argument #2: Expected a function that creates action objects");
    return setmetatable({
        name = u1
    }, {
        __call = function(_, ...) --[[ Name: __call, Line 12 ]]
            -- upvalues: u2 (copy), u1 (copy)
            local v5 = u2(...);
            local v6 = type(v5) == "table";
            assert(v6, "Invalid action: An action creator must return a table");
            v5.type = u1;
            return v5;
        end
    });
end;