-- Roblox: ReplicatedStorage.Packages.Rodux.combineReducers.spec
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function() --[[ Line: 1 ]]
    local l__combineReducers__1 = require(script.Parent.combineReducers);
    it("should invoke each sub-reducer for every action", function() --[[ Line: 4 ]]
        -- upvalues: l__combineReducers__1 (copy)
        local u1 = 0;
        local u2 = 0;
        l__combineReducers__1({
            a = function(_, _) --[[ Name: a, Line 9 ]]
                -- upvalues: u1 (ref)
                u1 = u1 + 1;
            end,
            b = function(_, _) --[[ Name: b, Line 12 ]]
                -- upvalues: u2 (ref)
                u2 = u2 + 1;
            end
        })({}, {});
        expect(u1).to.equal(1);
        expect(u2).to.equal(1);
    end);
    it("should assign each sub-reducer\'s value to the new state", function() --[[ Line: 23 ]]
        -- upvalues: l__combineReducers__1 (copy)
        local v5 = l__combineReducers__1({
            a = function(p3, _) --[[ Name: a, Line 25 ]]
                return (p3 or 0) + 1;
            end,
            b = function(p4, _) --[[ Name: b, Line 28 ]]
                return (p4 or 0) + 3;
            end
        })({}, {});
        expect(v5.a).to.equal(1);
        expect(v5.b).to.equal(3);
    end);
    it("should not throw when state is nil", function() --[[ Line: 38 ]]
        -- upvalues: l__combineReducers__1 (copy)
        local u8 = l__combineReducers__1({
            a = function(p6, _) --[[ Name: a, Line 40 ]]
                return (p6 or 0) + 1;
            end,
            b = function(p7, _) --[[ Name: b, Line 43 ]]
                return (p7 or 0) + 3;
            end
        });
        expect(function() --[[ Line: 48 ]]
            -- upvalues: u8 (copy)
            u8(nil, {});
        end).to.never.throw();
    end);
end;