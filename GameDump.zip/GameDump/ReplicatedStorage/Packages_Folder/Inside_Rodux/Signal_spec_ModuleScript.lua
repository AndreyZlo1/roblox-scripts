-- Roblox: ReplicatedStorage.Packages.Rodux.Signal.spec
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function() --[[ Line: 1 ]]
    local l__Signal__1 = require(script.Parent.Signal);
    it("should construct from nothing", function() --[[ Line: 4 ]]
        -- upvalues: l__Signal__1 (copy)
        local v1 = l__Signal__1.new();
        expect(v1).to.be.ok();
    end);
    it("should fire connected callbacks", function() --[[ Line: 10 ]]
        -- upvalues: l__Signal__1 (copy)
        local u2 = 0;
        local function v5(p3, p4) --[[ Line: 15 ]]
            -- upvalues: u2 (ref)
            expect(p3).to.equal("Hello World");
            expect(p4).to.equal(7);
            u2 = u2 + 1;
        end;
        local v6 = l__Signal__1.new();
        local v7 = v6:connect(v5);
        v6:fire("Hello World", 7);
        expect(u2).to.equal(1);
        v7:disconnect();
        v6:fire("Hello World", 7);
        expect(u2).to.equal(1);
    end);
    it("should disconnect handlers", function() --[[ Line: 34 ]]
        -- upvalues: l__Signal__1 (copy)
        local v8 = l__Signal__1.new();
        v8:connect(function() --[[ Line: 35 ]]
            error("Callback was called after disconnect!");
        end):disconnect();
        v8:fire();
    end);
    it("should fire handlers in order", function() --[[ Line: 47 ]]
        -- upvalues: l__Signal__1 (copy)
        local v9 = l__Signal__1.new();
        local u10 = 0;
        local u11 = 0;
        local function v12() --[[ Line: 58 ]]
            -- upvalues: u10 (ref), u11 (ref)
            expect(u10).to.equal(1);
            expect(u11).to.equal(0);
            u11 = u11 + 1;
        end;
        v9:connect(function() --[[ Line: 52 ]]
            -- upvalues: u10 (ref), u11 (ref)
            expect(u10).to.equal(0);
            expect(u11).to.equal(0);
            u10 = u10 + 1;
        end);
        v9:connect(v12);
        v9:fire();
        expect(u10).to.equal(1);
        expect(u11).to.equal(1);
    end);
    it("should continue firing despite mid-event disconnection", function() --[[ Line: 72 ]]
        -- upvalues: l__Signal__1 (copy)
        local v13 = l__Signal__1.new();
        local u14 = 0;
        local u15 = 0;
        local u16 = nil;
        u16 = v13:connect(function() --[[ Line: 78 ]]
            -- upvalues: u16 (ref), u14 (ref)
            u16:disconnect();
            u14 = u14 + 1;
        end);
        v13:connect(function() --[[ Line: 83 ]]
            -- upvalues: u15 (ref)
            u15 = u15 + 1;
        end);
        v13:fire();
        expect(u14).to.equal(1);
        expect(u15).to.equal(1);
    end);
    it("should skip listeners that were disconnected during event evaluation", function() --[[ Line: 93 ]]
        -- upvalues: l__Signal__1 (copy)
        local v17 = l__Signal__1.new();
        local u18 = 0;
        local u19 = 0;
        local u20 = nil;
        v17:connect(function() --[[ Line: 100 ]]
            -- upvalues: u18 (ref), u20 (ref)
            u18 = u18 + 1;
            u20:disconnect();
        end);
        u20 = v17:connect(function() --[[ Line: 105 ]]
            -- upvalues: u19 (ref)
            u19 = u19 + 1;
        end);
        v17:fire();
        expect(u18).to.equal(1);
        expect(u19).to.equal(0);
    end);
end;