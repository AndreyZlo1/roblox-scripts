-- Roblox: ReplicatedStorage.Packages.asset.AssetClass
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ContentProvider__1 = game:GetService("ContentProvider");
local u1 = {};
u1.__index = u1;
function u1.new(p2, p3) --[[ Line: 6 ]]
    -- upvalues: u1 (copy)
    local v4 = nil;
    local v5 = nil;
    if typeof(p2.Asset) == "table" then
        if p2.Asset._sound then
            v4 = Instance.new("Sound");
            v4.SoundId = "rbxassetid://" .. p2.Asset._sound;
            v5 = p2.Asset._sound;
        elseif p2.Asset._animation then
            v4 = Instance.new("Animation");
            v4.AnimationId = "rbxassetid://" .. p2.Asset._animation;
            v5 = p2.Asset._animation;
        end;
    elseif typeof(p2.Asset) == "Instance" then
        v4 = p2.Asset;
    end;
    return setmetatable({
        Asset = p2.Asset,
        ID = v5,
        _debugger = p3,
        _asset = p2,
        _assetToLoad = v4
    }, u1);
end;
function u1.Preload(u6, u7) --[[ Line: 37 ]]
    -- upvalues: l__ContentProvider__1 (copy)
    if u6._asset.IsLoaded then
        if u7 then
            u7(true);
        end;
    else
        local u8 = true;
        local function u11(p9, p10) --[[ Line: 46 ]]
            -- upvalues: u6 (copy), u8 (ref)
            if u6._debugger then
                u6._debugger:Switch(p10 == Enum.AssetFetchStatus.Success, "Loaded " .. p9, "Failed to load " .. p9);
            end;
            if p10 == Enum.AssetFetchStatus.Failure then
                u8 = false;
            end;
        end;
        task.spawn(function() --[[ Line: 56 ]]
            -- upvalues: l__ContentProvider__1 (ref), u6 (copy), u11 (copy), u7 (copy), u8 (ref)
            l__ContentProvider__1:PreloadAsync({ u6._assetToLoad }, u11);
            u6._asset.IsLoaded = true;
            if u7 then
                u7(u8);
            end;
        end);
    end;
end;
return u1;