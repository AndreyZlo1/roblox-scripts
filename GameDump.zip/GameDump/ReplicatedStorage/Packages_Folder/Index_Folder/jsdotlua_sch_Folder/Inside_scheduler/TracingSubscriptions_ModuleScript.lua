-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_scheduler@17.1.0.scheduler.TracingSubscriptions
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__Object__1 = require(script.Parent.Parent:WaitForChild("luau-polyfill")).Object;
local l__Tracing__2 = require(script.Parent:WaitForChild("Tracing"));
local l__enableSchedulerTracing__3 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags.enableSchedulerTracing;
local l____subscriberRef__4 = l__Tracing__2.__subscriberRef;
local u2 = {};
function v1.unstable_subscribe(p3) --[[ Line: 29 ]]
    -- upvalues: l__enableSchedulerTracing__3 (copy), u2 (ref), l__Object__1 (copy), l____subscriberRef__4 (copy)
    if l__enableSchedulerTracing__3 then
        u2[p3] = true;
        if #l__Object__1.keys(u2) == 1 then
            l____subscriberRef__4.current = {
                onInteractionScheduledWorkCompleted = onInteractionScheduledWorkCompleted,
                onInteractionTraced = onInteractionTraced,
                onWorkCanceled = onWorkCanceled,
                onWorkScheduled = onWorkScheduled,
                onWorkStarted = onWorkStarted,
                onWorkStopped = onWorkStopped
            };
        end;
    end;
end;
function v1.unstable_unsubscribe(p4) --[[ Line: 46 ]]
    -- upvalues: l__enableSchedulerTracing__3 (copy), u2 (ref), l__Object__1 (copy), l____subscriberRef__4 (copy)
    if l__enableSchedulerTracing__3 then
        u2[p4] = nil;
        if #l__Object__1.keys(u2) == 0 then
            l____subscriberRef__4.current = nil;
        end;
    end;
end;
function onInteractionTraced(p5)
    -- upvalues: u2 (ref)
    local v6 = false;
    local v7 = nil;
    for v8, _ in u2 do
        local v9, v10 = pcall(v8.onInteractionTraced, p5);
        if not (v9 or v6) then
            v7 = v10;
            v6 = true;
        end;
    end;
    if v6 then
        error(v7);
    end;
end;
function onInteractionScheduledWorkCompleted(p11)
    -- upvalues: u2 (ref)
    local v12 = false;
    local v13 = nil;
    for v14, _ in u2 do
        local v15, v16 = pcall(v14.onInteractionScheduledWorkCompleted, p11);
        if not (v15 or v12) then
            v13 = v16;
            v12 = true;
        end;
    end;
    if v12 then
        error(v13);
    end;
end;
function onWorkScheduled(p17, p18)
    -- upvalues: u2 (ref)
    local v19 = false;
    local v20 = nil;
    for v21, _ in u2 do
        local v22, v23 = pcall(v21.onWorkScheduled, p17, p18);
        if not (v22 or v19) then
            v20 = v23;
            v19 = true;
        end;
    end;
    if v19 then
        error(v20);
    end;
end;
function onWorkStarted(p24, p25)
    -- upvalues: u2 (ref)
    local v26 = false;
    local v27 = nil;
    for v28, _ in u2 do
        local v29, v30 = pcall(v28.onWorkStarted, p24, p25);
        if not (v29 or v26) then
            v27 = v30;
            v26 = true;
        end;
    end;
    if v26 then
        error(v27);
    end;
end;
function onWorkStopped(p31, p32)
    -- upvalues: u2 (ref)
    local v33 = false;
    local v34 = nil;
    for v35, _ in u2 do
        local v36, v37 = pcall(v35.onWorkStopped, p31, p32);
        if not (v36 or v33) then
            v34 = v37;
            v33 = true;
        end;
    end;
    if v33 then
        error(v34);
    end;
end;
function onWorkCanceled(p38, p39)
    -- upvalues: u2 (ref)
    local v40 = false;
    local v41 = nil;
    for v42, _ in u2 do
        local v43, v44 = pcall(v42.onWorkCanceled, p38, p39);
        if not (v43 or v40) then
            v41 = v44;
            v40 = true;
        end;
    end;
    if v40 then
        error(v41);
    end;
end;
return v1;