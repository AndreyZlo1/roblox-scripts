-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_scheduler@17.1.0.scheduler.SchedulerFeatureFlags
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    enableSchedulerDebugging = false,
    enableIsInputPending = false,
    enableProfiling = _G.__PROFILE__
};