-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_scheduler@17.1.0.scheduler.unstable_mock
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Tracing__1 = require(script.Parent:WaitForChild("Tracing"));
local l__TracingSubscriptions__2 = require(script.Parent:WaitForChild("TracingSubscriptions"));
local l__Scheduler__3 = require(script.Parent:WaitForChild("Scheduler"));
local v1 = require(script.Parent:WaitForChild("forks"):WaitForChild("SchedulerHostConfig.mock"));
local v2 = l__Scheduler__3(v1);
local v3 = {
    tracing = {}
};
for v4, v5 in v2 do
    v3[v4] = v5;
end;
for v6, v7 in l__Tracing__1 do
    v3.tracing[v6] = v7;
end;
for v8, v9 in l__TracingSubscriptions__2 do
    v3.tracing[v8] = v9;
end;
v3.unstable_flushAllWithoutAsserting = v1.unstable_flushAllWithoutAsserting;
v3.unstable_flushNumberOfYields = v1.unstable_flushNumberOfYields;
v3.unstable_flushExpired = v1.unstable_flushExpired;
v3.unstable_clearYields = v1.unstable_clearYields;
v3.unstable_flushUntilNextPaint = v1.unstable_flushUntilNextPaint;
v3.unstable_flushAll = v1.unstable_flushAll;
v3.unstable_yieldValue = v1.unstable_yieldValue;
v3.unstable_advanceTime = v1.unstable_advanceTime;
v3.unstable_Profiling = v2.unstable_Profiling;
return v3;