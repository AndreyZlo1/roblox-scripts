-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_scheduler@17.1.0.scheduler.SchedulerMinHeap
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local u2 = nil;
local u3 = nil;
local u4 = nil;
function v1.push(p5, p6) --[[ Line: 22 ]]
    -- upvalues: u3 (ref)
    local v7 = #p5 + 1;
    p5[v7] = p6;
    u3(p5, p6, v7);
end;
function v1.peek(p8) --[[ Line: 29 ]]
    return p8[1];
end;
function v1.pop(p9) --[[ Line: 33 ]]
    -- upvalues: u4 (ref)
    local v10 = p9[1];
    if v10 == nil then
        return nil;
    end;
    local v11 = p9[#p9];
    p9[#p9] = nil;
    if v11 ~= v10 then
        p9[1] = v11;
        u4(p9, v11, 1);
    end;
    return v10;
end;
u3 = function(p12, p13, p14) --[[ Line: 49 ]]
    -- upvalues: u2 (ref)
    while true do
        local v15 = math.floor(p14 / 2);
        local v16 = p12[v15];
        if v16 == nil or u2(v16, p13) <= 0 then
            break;
        end;
        p12[v15] = p13;
        p12[p14] = v16;
        p14 = v15;
    end;
end;
u4 = function(p17, p18, p19) --[[ Line: 65 ]]
    -- upvalues: u2 (ref)
    local v20 = #p17;
    while p19 < v20 do
        local v21 = p19 * 2;
        local v22 = p17[v21];
        local v23 = v21 + 1;
        local v24 = p17[v23];
        if v22 == nil or u2(v22, p18) >= 0 then
            if v24 == nil or u2(v24, p18) >= 0 then
                return;
            end;
            p17[p19] = v24;
            p17[v23] = p18;
        elseif v24 == nil or u2(v24, v22) >= 0 then
            p17[p19] = v22;
            p17[v21] = p18;
            v23 = v21;
        else
            p17[p19] = v24;
            p17[v23] = p18;
        end;
        p19 = v23;
    end;
end;
u2 = function(p25, p26) --[[ Line: 95 ]]
    local v27 = p25.sortIndex - p26.sortIndex;
    if v27 == 0 then
        return p25.id - p26.id;
    else
        return v27;
    end;
end;
return v1;