-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_scheduler@17.1.0.scheduler.SchedulerHostConfig
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent:WaitForChild("forks"):WaitForChild("SchedulerHostConfig.default"));