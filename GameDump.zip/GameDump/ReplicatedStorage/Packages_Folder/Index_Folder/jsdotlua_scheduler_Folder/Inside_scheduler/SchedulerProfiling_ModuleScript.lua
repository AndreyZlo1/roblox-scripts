-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_scheduler@17.1.0.scheduler.SchedulerProfiling
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__console__1 = require(script.Parent.Parent:WaitForChild("shared")).console;
local u1 = {};
require(script.Parent:WaitForChild("SchedulerPriorities"));
local l__enableProfiling__2 = require(script.Parent:WaitForChild("SchedulerFeatureFlags")).enableProfiling;
local u2 = 0;
local u3 = 0;
local u4 = 0;
local u5 = nil;
local u6 = nil;
local u7 = 1;
local function u10(p8) --[[ Line: 45 ]]
    -- upvalues: u6 (ref), u7 (ref), u4 (ref), l__console__1 (copy), u1 (copy), u5 (ref)
    if u6 ~= nil then
        u7 = u7 + #p8;
        if u4 < u7 + 1 then
            u4 = u4 * 2;
            if u4 > 524288 then
                l__console__1.error("Scheduler Profiling: Event log exceeded maximum size. Don\'t forget to call `stopLoggingProfilingEvents()`.");
                u1.stopLoggingProfilingEvents();
                return;
            end;
            local v9 = {};
            table.insert(v9, u6);
            u5 = v9;
            u6 = v9;
        end;
        table.insert(u6, p8);
    end;
end;
function u1.startLoggingProfilingEvents() --[[ Line: 69 ]]
    -- upvalues: u4 (ref), u5 (ref), u6 (ref), u7 (ref)
    u4 = 131072;
    u5 = {};
    u6 = u5;
    u7 = 1;
end;
function u1.stopLoggingProfilingEvents() --[[ Line: 76 ]]
    -- upvalues: u5 (ref), u4 (ref), u6 (ref), u7 (ref)
    local v11 = u5;
    u4 = 0;
    u5 = nil;
    u6 = nil;
    u7 = 1;
    return v11;
end;
function u1.markTaskStart(p12, p13) --[[ Line: 86 ]]
    -- upvalues: l__enableProfiling__2 (copy), u6 (ref), u10 (copy)
    if l__enableProfiling__2 and u6 ~= nil then
        u10({
            1,
            p13 * 1000,
            p12.id,
            p12.priorityLevel
        });
    end;
end;
function u1.markTaskCompleted(p14, p15) --[[ Line: 97 ]]
    -- upvalues: l__enableProfiling__2 (copy), u6 (ref), u10 (copy)
    if l__enableProfiling__2 and u6 ~= nil then
        u10({ 2, p15 * 1000, p14.id });
    end;
end;
function u1.markTaskCanceled(p16, p17) --[[ Line: 108 ]]
    -- upvalues: l__enableProfiling__2 (copy), u6 (ref), u10 (copy)
    if l__enableProfiling__2 and u6 ~= nil then
        u10({ 4, p17 * 1000, p16.id });
    end;
end;
function u1.markTaskErrored(p18, p19) --[[ Line: 116 ]]
    -- upvalues: l__enableProfiling__2 (copy), u6 (ref), u10 (copy)
    if l__enableProfiling__2 and u6 ~= nil then
        u10({ 3, p19 * 1000, p18.id });
    end;
end;
function u1.markTaskRun(p20, p21) --[[ Line: 124 ]]
    -- upvalues: l__enableProfiling__2 (copy), u2 (ref), u6 (ref), u10 (copy)
    if l__enableProfiling__2 then
        u2 = u2 + 1;
        if u6 ~= nil then
            u10({
                5,
                p21 * 1000,
                p20.id,
                u2
            });
        end;
    end;
end;
function u1.markTaskYield(p22, p23) --[[ Line: 134 ]]
    -- upvalues: l__enableProfiling__2 (copy), u6 (ref), u10 (copy), u2 (ref)
    if l__enableProfiling__2 and u6 ~= nil then
        u10({
            6,
            p23 * 1000,
            p22.id,
            u2
        });
    end;
end;
function u1.markSchedulerSuspended(p24) --[[ Line: 142 ]]
    -- upvalues: l__enableProfiling__2 (copy), u3 (ref), u6 (ref), u10 (copy)
    if l__enableProfiling__2 then
        u3 = u3 + 1;
        if u6 ~= nil then
            u10({ 7, p24 * 1000, u3 });
        end;
    end;
end;
function u1.markSchedulerUnsuspended(p25) --[[ Line: 152 ]]
    -- upvalues: l__enableProfiling__2 (copy), u6 (ref), u10 (copy), u3 (ref)
    if l__enableProfiling__2 and u6 ~= nil then
        u10({ 8, p25 * 1000, u3 });
    end;
end;
return u1;