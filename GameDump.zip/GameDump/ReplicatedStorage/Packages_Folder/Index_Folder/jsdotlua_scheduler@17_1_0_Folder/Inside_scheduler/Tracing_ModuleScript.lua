-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_scheduler@17.1.0.scheduler.Tracing
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Set__1 = require(script.Parent.Parent:WaitForChild("luau-polyfill")).Set;
local v1 = {};
local l__enableSchedulerTracing__2 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags.enableSchedulerTracing;
local u2 = 0;
local u3 = 0;
local u4, u5;
if l__enableSchedulerTracing__2 then
    u4 = {
        current = l__Set__1.new()
    };
    u5 = {
        current = nil
    };
else
    u4 = nil;
    u5 = nil;
end;
v1.__interactionsRef = u4;
v1.__subscriberRef = u5;
function v1.unstable_clear(p6) --[[ Line: 91 ]]
    -- upvalues: l__enableSchedulerTracing__2 (copy), u4 (ref), l__Set__1 (copy)
    if not l__enableSchedulerTracing__2 then
        return p6();
    end;
    local l__current__3 = u4.current;
    u4.current = l__Set__1.new();
    local v7, v8 = pcall(p6);
    u4.current = l__current__3;
    if not v7 then
        error(v8);
    end;
    return v8;
end;
function v1.unstable_getCurrent() --[[ Line: 111 ]]
    -- upvalues: l__enableSchedulerTracing__2 (copy), u4 (ref)
    if l__enableSchedulerTracing__2 then
        return u4.current;
    else
        return nil;
    end;
end;
function v1.unstable_getThreadID() --[[ Line: 119 ]]
    -- upvalues: u3 (ref)
    u3 = u3 + 1;
    return u3;
end;
function v1.unstable_trace(p9, p10, u11, p12) --[[ Line: 125 ]]
    -- upvalues: l__enableSchedulerTracing__2 (copy), u2 (ref), u4 (ref), l__Set__1 (copy), u5 (ref)
    local u13 = p12 == nil and 0 or p12;
    if not l__enableSchedulerTracing__2 then
        return u11();
    end;
    local u14 = {
        __count = 1,
        id = u2,
        name = p9,
        timestamp = p10
    };
    u2 = u2 + 1;
    local l__current__4 = u4.current;
    local u15 = l__Set__1.new(l__current__4);
    u15:add(u14);
    u4.current = u15;
    local l__current__5 = u5.current;
    local u16 = nil;
    local v17, v18 = pcall(function() --[[ Line: 154 ]]
        -- upvalues: l__current__5 (copy), u14 (copy)
        if l__current__5 ~= nil then
            l__current__5.onInteractionTraced(u14);
        end;
    end);
    local v19, v20 = pcall(function() --[[ Line: 161 ]]
        -- upvalues: l__current__5 (copy), u15 (copy), u13 (copy)
        if l__current__5 ~= nil then
            l__current__5.onWorkStarted(u15, u13);
        end;
    end);
    local v21, v22 = pcall(function() --[[ Line: 169 ]]
        -- upvalues: u16 (ref), u11 (copy)
        u16 = u11();
    end);
    u4.current = l__current__4;
    local v23, v24 = pcall(function() --[[ Line: 175 ]]
        -- upvalues: l__current__5 (copy), u15 (copy), u13 (copy)
        if l__current__5 ~= nil then
            l__current__5.onWorkStopped(u15, u13);
        end;
    end);
    u14.__count = u14.__count - 1;
    if l__current__5 ~= nil and u14.__count == 0 then
        l__current__5.onInteractionScheduledWorkCompleted(u14);
    end;
    if not v23 then
        error(v24);
    end;
    if not v21 then
        error(v22);
    end;
    if not v19 then
        error(v20);
    end;
    if not v17 then
        error(v18);
    end;
    return u16;
end;
function v1.unstable_wrap(u25, p26) --[[ Line: 208 ]]
    -- upvalues: l__enableSchedulerTracing__2 (copy), u4 (ref), u5 (ref)
    local u27 = p26 == nil and 0 or p26;
    if not l__enableSchedulerTracing__2 then
        return u25;
    end;
    local l__current__6 = u4.current;
    local l__current__7 = u5.current;
    if l__current__7 ~= nil then
        l__current__7.onWorkScheduled(l__current__6, u27);
    end;
    for _, v28 in l__current__6 do
        v28.__count = v28.__count + 1;
    end;
    local u29 = false;
    local function v33() --[[ Line: 301 ]]
        -- upvalues: l__current__7 (ref), u5 (ref), l__current__6 (copy), u27 (ref)
        l__current__7 = u5.current;
        local v30, v31 = pcall(function() --[[ Line: 304 ]]
            -- upvalues: l__current__7 (ref), l__current__6 (ref), u27 (ref)
            if l__current__7 ~= nil then
                l__current__7.onWorkCanceled(l__current__6, u27);
            end;
        end);
        for _, v32 in l__current__6 do
            v32.__count = v32.__count - 1;
            if l__current__7 ~= nil and v32.__count == 0 then
                l__current__7.onInteractionScheduledWorkCompleted(v32);
            end;
        end;
        if not v30 then
            error(v31);
        end;
    end;
    local v34 = {};
    setmetatable(v34, {
        __call = function(_, ...) --[[ Name: _wrapped, Line 236 ]]
            -- upvalues: u4 (ref), l__current__6 (copy), l__current__7 (ref), u5 (ref), u27 (ref), u25 (copy), u29 (ref)
            local l__current__8 = u4.current;
            u4.current = l__current__6;
            l__current__7 = u5.current;
            local v40, v41 = pcall(function(...) --[[ Line: 243 ]]
                -- upvalues: l__current__7 (ref), l__current__6 (ref), u27 (ref), u25 (ref), u4 (ref), l__current__8 (copy)
                local u35 = nil;
                local v36, v37 = pcall(function() --[[ Line: 247 ]]
                    -- upvalues: l__current__7 (ref), l__current__6 (ref), u27 (ref)
                    if l__current__7 ~= nil then
                        l__current__7.onWorkStarted(l__current__6, u27);
                    end;
                end);
                local v38, v39 = pcall(function(...) --[[ Line: 254 ]]
                    -- upvalues: u35 (ref), u25 (ref)
                    u35 = u25(...);
                end, ...);
                u4.current = l__current__8;
                if l__current__7 ~= nil then
                    l__current__7.onWorkStopped(l__current__6, u27);
                end;
                if not v38 then
                    error(v39);
                end;
                if not v36 then
                    error(v37);
                end;
                return u35;
            end, ...);
            if not u29 then
                u29 = true;
                for _, v42 in l__current__6 do
                    v42.__count = v42.__count - 1;
                    if l__current__7 ~= nil and v42.__count == 0 then
                        l__current__7.onInteractionScheduledWorkCompleted(v42);
                    end;
                end;
            end;
            if not v40 then
                error(v41);
            end;
            return v41;
        end
    });
    v34.cancel = v33;
    return v34;
end;
return v1;