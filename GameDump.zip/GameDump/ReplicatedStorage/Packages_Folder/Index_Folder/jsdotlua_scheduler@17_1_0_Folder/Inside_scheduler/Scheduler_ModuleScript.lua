-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_scheduler@17.1.0.scheduler.Scheduler
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function(p1) --[[ Line: 12 ]]
    local l__describeError__1 = require(script.Parent.Parent:WaitForChild("shared")).describeError;
    local l__SchedulerFeatureFlags__2 = require(script.Parent:WaitForChild("SchedulerFeatureFlags"));
    local l__enableSchedulerDebugging__3 = l__SchedulerFeatureFlags__2.enableSchedulerDebugging;
    local l__enableProfiling__4 = l__SchedulerFeatureFlags__2.enableProfiling;
    local v2 = p1 or require(script.Parent:WaitForChild("SchedulerHostConfig"));
    local l__requestHostCallback__5 = v2.requestHostCallback;
    local l__requestHostTimeout__6 = v2.requestHostTimeout;
    local l__cancelHostTimeout__7 = v2.cancelHostTimeout;
    local l__shouldYieldToHost__8 = v2.shouldYieldToHost;
    local l__getCurrentTime__9 = v2.getCurrentTime;
    local l__forceFrameRate__10 = v2.forceFrameRate;
    local l__requestPaint__11 = v2.requestPaint;
    local u3 = nil;
    local u4 = nil;
    local u5 = nil;
    u4 = function(p6, p7, p8) --[[ Line: 69 ]]
        -- upvalues: u3 (ref)
        while true do
            local v9 = math.floor(p8 / 2);
            local v10 = p6[v9];
            if v10 == nil or u3(v10, p7) <= 0 then
                break;
            end;
            p6[v9] = p7;
            p6[p8] = v10;
            p8 = v9;
        end;
    end;
    u5 = function(p11, p12, p13) --[[ Line: 85 ]]
        -- upvalues: u3 (ref)
        local v14 = #p11;
        while p13 < v14 do
            local v15 = p13 * 2;
            local v16 = p11[v15];
            local v17 = v15 + 1;
            local v18 = p11[v17];
            if v16 == nil or u3(v16, p12) >= 0 then
                if v18 == nil or u3(v18, p12) >= 0 then
                    return;
                end;
                p11[p13] = v18;
                p11[v17] = p12;
            elseif v18 == nil or u3(v18, v16) >= 0 then
                p11[p13] = v16;
                p11[v15] = p12;
                v17 = v15;
            else
                p11[p13] = v18;
                p11[v17] = p12;
            end;
            p13 = v17;
        end;
    end;
    u3 = function(p19, p20) --[[ Line: 115 ]]
        local v21 = p19.sortIndex - p20.sortIndex;
        if v21 == 0 then
            return p19.id - p20.id;
        else
            return v21;
        end;
    end;
    local l__SchedulerPriorities__12 = require(script.Parent:WaitForChild("SchedulerPriorities"));
    local l__ImmediatePriority__13 = l__SchedulerPriorities__12.ImmediatePriority;
    local l__UserBlockingPriority__14 = l__SchedulerPriorities__12.UserBlockingPriority;
    local l__NormalPriority__15 = l__SchedulerPriorities__12.NormalPriority;
    local l__LowPriority__16 = l__SchedulerPriorities__12.LowPriority;
    local l__IdlePriority__17 = l__SchedulerPriorities__12.IdlePriority;
    local l__SchedulerProfiling__18 = require(script.Parent:WaitForChild("SchedulerProfiling"));
    local l__markTaskRun__19 = l__SchedulerProfiling__18.markTaskRun;
    local l__markTaskYield__20 = l__SchedulerProfiling__18.markTaskYield;
    local l__markTaskCompleted__21 = l__SchedulerProfiling__18.markTaskCompleted;
    local l__markTaskCanceled__22 = l__SchedulerProfiling__18.markTaskCanceled;
    local l__markTaskErrored__23 = l__SchedulerProfiling__18.markTaskErrored;
    local l__markSchedulerSuspended__24 = l__SchedulerProfiling__18.markSchedulerSuspended;
    local l__markSchedulerUnsuspended__25 = l__SchedulerProfiling__18.markSchedulerUnsuspended;
    local l__markTaskStart__26 = l__SchedulerProfiling__18.markTaskStart;
    local l__stopLoggingProfilingEvents__27 = l__SchedulerProfiling__18.stopLoggingProfilingEvents;
    local l__startLoggingProfilingEvents__28 = l__SchedulerProfiling__18.startLoggingProfilingEvents;
    local u22 = {};
    local u23 = {};
    local u24 = 1;
    local u25 = false;
    local u26 = nil;
    local u27 = l__NormalPriority__15;
    local u28 = false;
    local u29 = false;
    local u30 = false;
    local u31 = nil;
    local u32 = nil;
    local function u43(p33) --[[ Line: 182 ]]
        -- upvalues: u23 (copy), u5 (ref), u22 (copy), u4 (ref), l__enableProfiling__4 (copy), l__markTaskStart__26 (copy)
        local v34 = u23[1];
        while v34 ~= nil do
            if v34.callback == nil then
                local v35 = u23;
                local v36 = v35[1];
                if v36 ~= nil then
                    local v37 = v35[#v35];
                    v35[#v35] = nil;
                    if v37 ~= v36 then
                        v35[1] = v37;
                        u5(v35, v37, 1);
                    end;
                end;
            else
                if v34.startTime > p33 then
                    return;
                end;
                local v38 = u23;
                local v39 = v38[1];
                if v39 ~= nil then
                    local v40 = v38[#v38];
                    v38[#v38] = nil;
                    if v40 ~= v39 then
                        v38[1] = v40;
                        u5(v38, v40, 1);
                    end;
                end;
                v34.sortIndex = v34.expirationTime;
                local v41 = u22;
                local v42 = #v41 + 1;
                v41[v42] = v34;
                u4(v41, v34, v42);
                if l__enableProfiling__4 then
                    l__markTaskStart__26(v34, p33);
                    v34.isQueued = true;
                end;
            end;
            v34 = u23[1];
        end;
    end;
    local function u46(p44) --[[ Line: 208 ]]
        -- upvalues: u30 (ref), u43 (copy), u29 (ref), u22 (copy), l__requestHostCallback__5 (copy), u31 (ref), u23 (copy), l__requestHostTimeout__6 (copy), u46 (ref)
        u30 = false;
        u43(p44);
        if not u29 then
            if u22[1] ~= nil then
                u29 = true;
                l__requestHostCallback__5(u31);
                return;
            end;
            local v45 = u23[1];
            if v45 ~= nil then
                l__requestHostTimeout__6(u46, v45.startTime - p44);
            end;
        end;
    end;
    u31 = function(p47, p48) --[[ Line: 225 ]]
        -- upvalues: l__enableProfiling__4 (copy), l__markSchedulerUnsuspended__25 (copy), u29 (ref), u30 (ref), l__cancelHostTimeout__7 (copy), u28 (ref), u27 (ref), u32 (ref), l__describeError__1 (copy), u26 (ref), l__getCurrentTime__9 (copy), l__markTaskErrored__23 (copy), l__markSchedulerSuspended__24 (copy)
        if l__enableProfiling__4 then
            l__markSchedulerUnsuspended__25(p48);
        end;
        u29 = false;
        if u30 then
            u30 = false;
            l__cancelHostTimeout__7();
        end;
        u28 = true;
        local v49 = u27;
        local v50, v51;
        if _G.__YOLO__ then
            v50 = u32(p47, p48);
            v51 = true;
        elseif l__enableProfiling__4 then
            v51, v50 = xpcall(u32, l__describeError__1, p47, p48);
            if not v51 and u26 ~= nil then
                l__markTaskErrored__23(u26, (l__getCurrentTime__9()));
                u26.isQueued = false;
            end;
        else
            v50 = u32(p47, p48);
            v51 = true;
        end;
        u26 = nil;
        u27 = v49;
        u28 = false;
        if l__enableProfiling__4 then
            l__markSchedulerSuspended__24((l__getCurrentTime__9()));
        end;
        if not v51 then
            error(v50);
        end;
        return v50;
    end;
    u32 = function(p52, p53) --[[ Line: 282 ]]
        -- upvalues: u43 (copy), u26 (ref), u22 (copy), l__enableSchedulerDebugging__3 (copy), u25 (ref), l__shouldYieldToHost__8 (copy), u27 (ref), l__markTaskRun__19 (copy), l__getCurrentTime__9 (copy), l__markTaskYield__20 (copy), l__enableProfiling__4 (copy), l__markTaskCompleted__21 (copy), u5 (ref), u23 (copy), l__requestHostTimeout__6 (copy), u46 (ref)
        u43(p53);
        u26 = u22[1];
        while u26 ~= nil and not (l__enableSchedulerDebugging__3 and u25) and (p53 >= u26.expirationTime or p52 and not l__shouldYieldToHost__8()) do
            local l__callback__29 = u26.callback;
            if typeof(l__callback__29) == "function" then
                u26.callback = nil;
                u27 = u26.priorityLevel;
                local v54 = u26.expirationTime <= p53;
                l__markTaskRun__19(u26, p53);
                local v55 = l__callback__29(v54);
                p53 = l__getCurrentTime__9();
                if typeof(v55) == "function" then
                    u26.callback = v55;
                    l__markTaskYield__20(u26, p53);
                else
                    if l__enableProfiling__4 then
                        l__markTaskCompleted__21(u26, p53);
                        u26.isQueued = false;
                    end;
                    if u26 == u22[1] then
                        local v56 = u22;
                        local v57 = v56[1];
                        if v57 ~= nil then
                            local v58 = v56[#v56];
                            v56[#v56] = nil;
                            if v58 ~= v57 then
                                v56[1] = v58;
                                u5(v56, v58, 1);
                            end;
                        end;
                    end;
                end;
                u43(p53);
            else
                local v59 = u22;
                local v60 = v59[1];
                if v60 ~= nil then
                    local v61 = v59[#v59];
                    v59[#v59] = nil;
                    if v61 ~= v60 then
                        v59[1] = v61;
                        u5(v59, v61, 1);
                    end;
                end;
            end;
            u26 = u22[1];
        end;
        if u26 ~= nil then
            return true;
        end;
        local v62 = u23[1];
        if v62 ~= nil then
            l__requestHostTimeout__6(u46, v62.startTime - p53);
        end;
        return false;
    end;
    return {
        unstable_ImmediatePriority = l__ImmediatePriority__13,
        unstable_UserBlockingPriority = l__UserBlockingPriority__14,
        unstable_NormalPriority = l__NormalPriority__15,
        unstable_IdlePriority = l__IdlePriority__17,
        unstable_LowPriority = l__LowPriority__16,
        unstable_runWithPriority = function(p63, p64) --[[ Name: unstable_runWithPriority, Line 339 ]]
            -- upvalues: l__ImmediatePriority__13 (copy), l__UserBlockingPriority__14 (copy), l__NormalPriority__15 (copy), l__LowPriority__16 (copy), l__IdlePriority__17 (copy), u27 (ref), l__describeError__1 (copy)
            if p63 ~= l__ImmediatePriority__13 and (p63 ~= l__UserBlockingPriority__14 and (p63 ~= l__NormalPriority__15 and (p63 ~= l__LowPriority__16 and p63 ~= l__IdlePriority__17))) then
                p63 = l__NormalPriority__15;
            end;
            local v65 = u27;
            u27 = p63;
            local v66, v67;
            if _G.__YOLO__ then
                v66 = p64();
                v67 = true;
            else
                v67, v66 = xpcall(p64, l__describeError__1);
            end;
            u27 = v65;
            if not v67 then
                error(v66);
            end;
            return v66;
        end,
        unstable_next = function(p68) --[[ Name: unstable_next, Line 374 ]]
            -- upvalues: u27 (ref), l__ImmediatePriority__13 (copy), l__UserBlockingPriority__14 (copy), l__NormalPriority__15 (copy), l__describeError__1 (copy)
            local v69;
            if u27 == l__ImmediatePriority__13 or (u27 == l__UserBlockingPriority__14 or u27 == l__NormalPriority__15) then
                v69 = l__NormalPriority__15;
            else
                v69 = u27;
            end;
            local v70 = u27;
            u27 = v69;
            local v71, v72;
            if _G.__YOLO__ then
                v71 = p68();
                v72 = true;
            else
                v72, v71 = xpcall(p68, l__describeError__1);
            end;
            u27 = v70;
            if not v72 then
                error(v71);
            end;
            return v71;
        end,
        unstable_scheduleCallback = function(p73, p74, p75) --[[ Name: unstable_scheduleCallback, Line 438 ]]
            -- upvalues: l__getCurrentTime__9 (copy), l__ImmediatePriority__13 (copy), l__UserBlockingPriority__14 (copy), l__IdlePriority__17 (copy), l__LowPriority__16 (copy), u24 (ref), l__enableProfiling__4 (copy), u23 (copy), u4 (ref), u22 (copy), u30 (ref), l__cancelHostTimeout__7 (copy), l__requestHostTimeout__6 (copy), u46 (ref), l__markTaskStart__26 (copy), u29 (ref), u28 (ref), l__requestHostCallback__5 (copy), u31 (ref)
            local v76 = l__getCurrentTime__9();
            local v77;
            if typeof(p75) == "table" then
                local l__delay__30 = p75.delay;
                if typeof(l__delay__30) == "number" and l__delay__30 > 0 then
                    v77 = v76 + l__delay__30;
                else
                    v77 = v76;
                end;
            else
                v77 = v76;
            end;
            local v78 = v77 + (p73 == l__ImmediatePriority__13 and -1 or (p73 == l__UserBlockingPriority__14 and 250 or (p73 == l__IdlePriority__17 and 1073741823 or (p73 == l__LowPriority__16 and 10000 or 5000))));
            local v79 = {
                sortIndex = -1,
                id = u24,
                callback = p74,
                priorityLevel = p73,
                startTime = v77,
                expirationTime = v78
            };
            u24 = u24 + 1;
            if l__enableProfiling__4 then
                v79.isQueued = false;
            end;
            if v76 < v77 then
                v79.sortIndex = v77;
                local v80 = u23;
                local v81 = #v80 + 1;
                v80[v81] = v79;
                u4(v80, v79, v81);
                if #u22 == 0 and v79 == u23[1] then
                    if u30 then
                        l__cancelHostTimeout__7();
                    else
                        u30 = true;
                    end;
                    l__requestHostTimeout__6(u46, v77 - v76);
                    return v79;
                end;
            else
                v79.sortIndex = v78;
                local v82 = u22;
                local v83 = #v82 + 1;
                v82[v83] = v79;
                u4(v82, v79, v83);
                if l__enableProfiling__4 then
                    l__markTaskStart__26(v79, v76);
                    v79.isQueued = true;
                end;
                if not (u29 or u28) then
                    u29 = true;
                    l__requestHostCallback__5(u31);
                end;
            end;
            return v79;
        end,
        unstable_cancelCallback = function(p84) --[[ Name: unstable_cancelCallback, Line 534 ]]
            -- upvalues: l__enableProfiling__4 (copy), l__getCurrentTime__9 (copy), l__markTaskCanceled__22 (copy)
            if l__enableProfiling__4 and p84.isQueued then
                l__markTaskCanceled__22(p84, (l__getCurrentTime__9()));
                p84.isQueued = false;
            end;
            p84.callback = nil;
        end,
        unstable_wrapCallback = function(u85) --[[ Name: unstable_wrapCallback, Line 410 ]]
            -- upvalues: u27 (ref), l__describeError__1 (copy)
            local u86 = u27;
            return function(...) --[[ Line: 413 ]]
                -- upvalues: u27 (ref), u86 (copy), u85 (copy), l__describeError__1 (ref)
                local v87 = u27;
                u27 = u86;
                local v88, v89;
                if _G.__YOLO__ then
                    v88 = u85(...);
                    v89 = true;
                else
                    v89, v88 = xpcall(u85, l__describeError__1, ...);
                end;
                u27 = v87;
                if not v89 then
                    error(v88);
                end;
                return v88;
            end;
        end,
        unstable_getCurrentPriorityLevel = function() --[[ Name: unstable_getCurrentPriorityLevel, Line 549 ]]
            -- upvalues: u27 (ref)
            return u27;
        end,
        unstable_shouldYield = l__shouldYieldToHost__8,
        unstable_requestPaint = l__requestPaint__11,
        unstable_continueExecution = function() --[[ Name: unstable_continueExecution, Line 522 ]]
            -- upvalues: u25 (ref), u29 (ref), u28 (ref), l__requestHostCallback__5 (copy), u31 (ref)
            u25 = false;
            if not (u29 or u28) then
                u29 = true;
                l__requestHostCallback__5(u31);
            end;
        end,
        unstable_pauseExecution = function() --[[ Name: unstable_pauseExecution, Line 518 ]]
            -- upvalues: u25 (ref)
            u25 = true;
        end,
        unstable_getFirstCallbackNode = function() --[[ Name: unstable_getFirstCallbackNode, Line 530 ]]
            -- upvalues: u22 (copy)
            return u22[1];
        end,
        unstable_now = l__getCurrentTime__9,
        unstable_forceFrameRate = l__forceFrameRate__10,
        unstable_Profiling = l__enableProfiling__4 and {
            startLoggingProfilingEvents = l__startLoggingProfilingEvents__28,
            stopLoggingProfilingEvents = l__stopLoggingProfilingEvents__27
        } or nil
    };
end;