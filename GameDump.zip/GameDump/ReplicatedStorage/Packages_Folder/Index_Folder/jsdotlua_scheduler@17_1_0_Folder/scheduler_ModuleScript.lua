-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_scheduler@17.1.0.scheduler
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = require(script:WaitForChild("Scheduler"))(nil);
local l__Tracing__1 = require(script:WaitForChild("Tracing"));
local l__TracingSubscriptions__2 = require(script:WaitForChild("TracingSubscriptions"));
if _G.__ROACT_17_MOCK_SCHEDULER__ then
    return require(script:WaitForChild("unstable_mock"));
end;
local v2 = {
    unstable_ImmediatePriority = v1.unstable_ImmediatePriority,
    unstable_UserBlockingPriority = v1.unstable_UserBlockingPriority,
    unstable_NormalPriority = v1.unstable_NormalPriority,
    unstable_IdlePriority = v1.unstable_IdlePriority,
    unstable_LowPriority = v1.unstable_LowPriority,
    unstable_runWithPriority = v1.unstable_runWithPriority,
    unstable_next = v1.unstable_next,
    unstable_scheduleCallback = v1.unstable_scheduleCallback,
    unstable_cancelCallback = v1.unstable_cancelCallback,
    unstable_wrapCallback = v1.unstable_wrapCallback,
    unstable_getCurrentPriorityLevel = v1.unstable_getCurrentPriorityLevel,
    unstable_shouldYield = v1.unstable_shouldYield,
    unstable_requestPaint = v1.unstable_requestPaint,
    unstable_continueExecution = v1.unstable_continueExecution,
    unstable_pauseExecution = v1.unstable_pauseExecution,
    unstable_getFirstCallbackNode = v1.unstable_getFirstCallbackNode,
    unstable_now = v1.unstable_now,
    unstable_forceFrameRate = v1.unstable_forceFrameRate
};
local u3 = "unstable_flushAllWithoutAsserting";
function v2.unstable_flushAllWithoutAsserting() --[[ Line: 15 ]]
    -- upvalues: u3 (copy)
    error(u3 .. " is only available in tests, not in production");
end;
local u4 = "unstable_flushAll";
function v2.unstable_flushAll() --[[ Line: 15 ]]
    -- upvalues: u4 (copy)
    error(u4 .. " is only available in tests, not in production");
end;
local u5 = "unstable_flushNumberOfYields";
function v2.unstable_flushNumberOfYields() --[[ Line: 15 ]]
    -- upvalues: u5 (copy)
    error(u5 .. " is only available in tests, not in production");
end;
local u6 = "unstable_clearYields";
function v2.unstable_clearYields() --[[ Line: 15 ]]
    -- upvalues: u6 (copy)
    error(u6 .. " is only available in tests, not in production");
end;
local u7 = "unstable_clearYields";
function v2.unstable_flushUntilNextPaint() --[[ Line: 15 ]]
    -- upvalues: u7 (copy)
    error(u7 .. " is only available in tests, not in production");
end;
local u8 = "unstable_advanceTime";
function v2.unstable_advanceTime() --[[ Line: 15 ]]
    -- upvalues: u8 (copy)
    error(u8 .. " is only available in tests, not in production");
end;
local u9 = "unstable_flushExpired";
function v2.unstable_flushExpired() --[[ Line: 15 ]]
    -- upvalues: u9 (copy)
    error(u9 .. " is only available in tests, not in production");
end;
local u10 = "unstable_yieldValue";
function v2.unstable_yieldValue() --[[ Line: 15 ]]
    -- upvalues: u10 (copy)
    error(u10 .. " is only available in tests, not in production");
end;
local v11 = {};
local u12 = "unstable_wrap";
function v11.unstable_wrap() --[[ Line: 15 ]]
    -- upvalues: u12 (copy)
    error(u12 .. " is only available in tests, not in production");
end;
v11.__interactionsRef = {};
v11.__subscriberRef = {};
v2.tracing = v11;
for v13, v14 in l__Tracing__1 do
    v2.tracing[v13] = v14;
end;
for v15, v16 in l__TracingSubscriptions__2 do
    v2.tracing[v15] = v16;
end;
return v2;