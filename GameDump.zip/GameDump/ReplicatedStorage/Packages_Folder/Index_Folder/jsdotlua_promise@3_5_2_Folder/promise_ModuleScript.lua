-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_promise@3.5.2.promise
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {
    __mode = "k"
};
local function v7(u2, p3) --[[ Line: 28 ]]
    local v4 = {};
    for _, v5 in ipairs(p3) do
        v4[v5] = v5;
    end;
    return setmetatable(v4, {
        __index = function(_, p6) --[[ Name: __index, Line 36 ]]
            -- upvalues: u2 (copy)
            error(string.format("%s is not in %s!", p6, u2), 2);
        end,
        __newindex = function() --[[ Name: __newindex, Line 39 ]]
            -- upvalues: u2 (copy)
            error(string.format("Creating new members in %s is not allowed!", u2), 2);
        end
    });
end;
local u8 = {
    Kind = v7("Promise.Error.Kind", {
        "ExecutionError",
        "AlreadyCancelled",
        "NotResolvedInTime",
        "TimedOut"
    })
};
u8.__index = u8;
function u8.new(p9, p10) --[[ Line: 64 ]]
    -- upvalues: u8 (ref)
    local v11 = p9 or {};
    local v12 = {
        error = tostring(v11.error) or "[This error has no error text.]",
        trace = v11.trace,
        context = v11.context,
        kind = v11.kind,
        parent = p10,
        createdTick = os.clock(),
        createdTrace = debug.traceback()
    };
    return setmetatable(v12, u8);
end;
function u8.is(p13) --[[ Line: 77 ]]
    if type(p13) == "table" then
        local v14 = getmetatable(p13);
        if type(v14) == "table" then
            local v15;
            if rawget(p13, "error") == nil then
                v15 = false;
            else
                local v16 = rawget(v14, "extend");
                v15 = type(v16) == "function";
            end;
            return v15;
        end;
    end;
    return false;
end;
function u8.isKind(p17, p18) --[[ Line: 89 ]]
    -- upvalues: u8 (ref)
    assert(p18 ~= nil, "Argument #2 to Promise.Error.isKind must not be nil");
    local v19 = u8.is(p17);
    if v19 then
        v19 = p17.kind == p18;
    end;
    return v19;
end;
function u8.extend(p20, p21) --[[ Line: 95 ]]
    -- upvalues: u8 (ref)
    local v22 = p21 or {};
    v22.kind = v22.kind or p20.kind;
    return u8.new(v22, p20);
end;
function u8.getErrorChain(p23) --[[ Line: 103 ]]
    local v24 = { p23 };
    while v24[#v24].parent do
        table.insert(v24, v24[#v24].parent);
    end;
    return v24;
end;
function u8.__tostring(p25) --[[ Line: 113 ]]
    local v26 = { string.format("-- Promise.Error(%s) --", p25.kind or "?") };
    for _, v27 in ipairs(p25:getErrorChain()) do
        table.insert(v26, table.concat({ v27.trace or v27.error, v27.context }, "\n"));
    end;
    return table.concat(v26, "\n");
end;
local function u28(...) --[[ Line: 137 ]]
    return select("#", ...), { ... };
end;
local function u30(p29, ...) --[[ Line: 144 ]]
    return p29, select("#", ...), { ... };
end;
local function u36(u31, p32, ...) --[[ Line: 171 ]]
    -- upvalues: u30 (copy), u8 (ref)
    local v33 = u30;
    local v34 = xpcall;
    assert(u31 ~= nil, "traceback is nil");
    return v33(v34(p32, function(p35) --[[ Line: 151 ]]
        -- upvalues: u8 (ref), u31 (copy)
        if type(p35) == "table" then
            return p35;
        else
            return u8.new({
                error = p35,
                kind = u8.Kind.ExecutionError,
                trace = debug.traceback(tostring(p35), 2),
                context = "Promise created at:\n\n" .. u31
            });
        end;
    end, ...));
end;
local u37 = {
    Error = u8,
    Status = v7("Promise.Status", {
        "Started",
        "Resolved",
        "Rejected",
        "Cancelled"
    }),
    _getTime = os.clock,
    _timeEvent = game:GetService("RunService").Heartbeat,
    _unhandledRejectionCallbacks = {},
    prototype = {}
};
u37.__index = u37.prototype;
function u37._new(p38, u39, p40) --[[ Line: 230 ]]
    -- upvalues: u37 (copy), u1 (copy), u36 (copy)
    if p40 ~= nil and not u37.is(p40) then
        error("Argument #2 to Promise.new must be a promise or nil", 2);
    end;
    local u41 = {
        _thread = nil,
        _values = nil,
        _valuesLength = -1,
        _unhandledRejection = true,
        _cancellationHook = nil,
        _source = p38,
        _status = u37.Status.Started,
        _queuedResolve = {},
        _queuedReject = {},
        _queuedFinally = {},
        _parent = p40,
        _consumers = setmetatable({}, u1)
    };
    if p40 and p40._status == u37.Status.Started then
        p40._consumers[u41] = true;
    end;
    setmetatable(u41, u37);
    local function u42(...) --[[ Line: 278 ]]
        -- upvalues: u41 (copy)
        u41:_resolve(...);
    end;
    local function u43(...) --[[ Line: 282 ]]
        -- upvalues: u41 (copy)
        u41:_reject(...);
    end;
    local function u45(p44) --[[ Line: 286 ]]
        -- upvalues: u41 (copy), u37 (ref)
        if p44 then
            if u41._status == u37.Status.Cancelled then
                p44();
            else
                u41._cancellationHook = p44;
            end;
        end;
        return u41._status == u37.Status.Cancelled;
    end;
    u41._thread = coroutine.create(function() --[[ Line: 298 ]]
        -- upvalues: u36 (ref), u41 (copy), u39 (copy), u42 (copy), u43 (copy), u45 (copy)
        local v46, _, v47 = u36(u41._source, u39, u42, u43, u45);
        if not v46 then
            u43(v47[1]);
        end;
    end);
    task.spawn(u41._thread);
    return u41;
end;
function u37.new(p48) --[[ Line: 349 ]]
    -- upvalues: u37 (copy)
    return u37._new(debug.traceback(nil, 2), p48);
end;
function u37.__tostring(p49) --[[ Line: 353 ]]
    return string.format("Promise(%s)", p49._status);
end;
function u37.defer(u50) --[[ Line: 375 ]]
    -- upvalues: u37 (copy), u36 (copy)
    local u51 = debug.traceback(nil, 2);
    return u37._new(u51, function(u52, u53, u54) --[[ Line: 378 ]]
        -- upvalues: u37 (ref), u36 (ref), u51 (copy), u50 (copy)
        local u55 = nil;
        u55 = u37._timeEvent:Connect(function() --[[ Line: 380 ]]
            -- upvalues: u55 (ref), u36 (ref), u51 (ref), u50 (ref), u52 (copy), u53 (copy), u54 (copy)
            u55:Disconnect();
            local v56, _, v57 = u36(u51, u50, u52, u53, u54);
            if not v56 then
                u53(v57[1]);
            end;
        end);
    end);
end;
u37.async = u37.defer;
function u37.resolve(...) --[[ Line: 418 ]]
    -- upvalues: u28 (copy), u37 (copy)
    local u58, u59 = u28(...);
    return u37._new(debug.traceback(nil, 2), function(p60) --[[ Line: 420 ]]
        -- upvalues: u59 (copy), u58 (copy)
        p60(unpack(u59, 1, u58));
    end);
end;
function u37.reject(...) --[[ Line: 435 ]]
    -- upvalues: u28 (copy), u37 (copy)
    local u61, u62 = u28(...);
    return u37._new(debug.traceback(nil, 2), function(_, p63) --[[ Line: 437 ]]
        -- upvalues: u62 (copy), u61 (copy)
        p63(unpack(u62, 1, u61));
    end);
end;
function u37._try(p64, u65, ...) --[[ Line: 446 ]]
    -- upvalues: u28 (copy), u37 (copy)
    local u66, u67 = u28(...);
    return u37._new(p64, function(p68) --[[ Line: 449 ]]
        -- upvalues: u65 (copy), u67 (copy), u66 (copy)
        p68(u65(unpack(u67, 1, u66)));
    end);
end;
function u37.try(p69, ...) --[[ Line: 477 ]]
    -- upvalues: u37 (copy)
    return u37._try(debug.traceback(nil, 2), p69, ...);
end;
function u37._all(p70, u71, u72) --[[ Line: 486 ]]
    -- upvalues: u37 (copy)
    if type(u71) ~= "table" then
        error(string.format("Please pass a list of promises to %s", "Promise.all"), 3);
    end;
    for v73, v74 in pairs(u71) do
        if not u37.is(v74) then
            error(string.format("Non-promise value passed into %s at index %s", "Promise.all", (tostring(v73))), 3);
        end;
    end;
    if #u71 == 0 or u72 == 0 then
        return u37.resolve({});
    else
        return u37._new(p70, function(u75, u76, p77) --[[ Line: 504 ]]
            -- upvalues: u72 (copy), u71 (copy)
            local u78 = {};
            local u79 = {};
            local u80 = 0;
            local u81 = 0;
            local u82 = false;
            local function u85(p83, ...) --[[ Line: 522 ]]
                -- upvalues: u82 (ref), u80 (ref), u72 (ref), u78 (copy), u71 (ref), u75 (copy), u79 (copy)
                if u82 then
                else
                    u80 = u80 + 1;
                    if u72 == nil then
                        u78[p83] = ...;
                    else
                        u78[u80] = ...;
                    end;
                    if u80 >= (u72 or #u71) then
                        u82 = true;
                        u75(u78);
                        for _, v84 in ipairs(u79) do
                            v84:cancel();
                        end;
                    end;
                end;
            end;
            p77(function() --[[ Name: cancel, Line 515 ]]
                -- upvalues: u79 (copy)
                for _, v86 in ipairs(u79) do
                    v86:cancel();
                end;
            end);
            local u87 = u82;
            for u88, v89 in ipairs(u71) do
                u79[u88] = v89:andThen(function(...) --[[ Line: 547 ]]
                    -- upvalues: u85 (copy), u88 (copy)
                    u85(u88, ...);
                end, function(...) --[[ Line: 549 ]]
                    -- upvalues: u81 (ref), u72 (ref), u71 (ref), u79 (copy), u87 (ref), u76 (copy)
                    u81 = u81 + 1;
                    if u72 == nil or #u71 - u81 < u72 then
                        for _, v90 in ipairs(u79) do
                            v90:cancel();
                        end;
                        u87 = true;
                        u76(...);
                    end;
                end);
            end;
            if u87 then
                for _, v91 in ipairs(u79) do
                    v91:cancel();
                end;
            end;
        end);
    end;
end;
function u37.all(...) --[[ Line: 591 ]]
    -- upvalues: u37 (copy)
    local v92 = { ... };
    if type(v92[1]) == "table" and not u37.is(v92[1]) then
        v92 = v92[1];
    end;
    return u37._all(debug.traceback(nil, 2), v92);
end;
function u37.fold(p93, u94, p95) --[[ Line: 628 ]]
    -- upvalues: u37 (copy)
    local v96 = type(p93) == "table";
    assert(v96, "Bad argument #1 to Promise.fold: must be a table");
    local v97;
    if type(u94) == "function" then
        v97 = true;
    elseif type(u94) == "table" then
        local v98 = getmetatable(u94);
        if v98 then
            local v99 = rawget(v98, "__call");
            v97 = type(v99) == "function";
        else
            v97 = false;
        end;
    else
        v97 = false;
    end;
    assert(v97, "Bad argument #2 to Promise.fold: must be a function");
    local u100 = u37.resolve(p95);
    return u37.each(p93, function(u101, u102) --[[ Line: 633 ]]
        -- upvalues: u100 (ref), u94 (copy)
        u100 = u100:andThen(function(p103) --[[ Line: 634 ]]
            -- upvalues: u94 (ref), u101 (copy), u102 (copy)
            return u94(p103, u101, u102);
        end);
    end):andThen(function() --[[ Line: 637 ]]
        -- upvalues: u100 (ref)
        return u100;
    end);
end;
function u37.some(p104, p105) --[[ Line: 661 ]]
    -- upvalues: u37 (copy)
    local v106 = type(p105) == "number";
    assert(v106, "Bad argument #2 to Promise.some: must be a number");
    return u37._all(debug.traceback(nil, 2), p104, p105);
end;
function u37.any(p107) --[[ Line: 685 ]]
    -- upvalues: u37 (copy)
    return u37._all(debug.traceback(nil, 2), p107, 1):andThen(function(p108) --[[ Line: 686 ]]
        return p108[1];
    end);
end;
function u37.allSettled(u109) --[[ Line: 707 ]]
    -- upvalues: u37 (copy)
    if type(u109) ~= "table" then
        error(string.format("Please pass a list of promises to %s", "Promise.allSettled"), 2);
    end;
    for v110, v111 in pairs(u109) do
        if not u37.is(v111) then
            error(string.format("Non-promise value passed into %s at index %s", "Promise.allSettled", (tostring(v110))), 2);
        end;
    end;
    if #u109 == 0 then
        return u37.resolve({});
    else
        return u37._new(debug.traceback(nil, 2), function(u112, _, p113) --[[ Line: 725 ]]
            -- upvalues: u109 (copy)
            local u114 = {};
            local u115 = {};
            local u116 = 0;
            local function u118(p117, ...) --[[ Line: 735 ]]
                -- upvalues: u116 (ref), u114 (copy), u109 (ref), u112 (copy)
                u116 = u116 + 1;
                u114[p117] = ...;
                if u116 >= #u109 then
                    u112(u114);
                end;
            end;
            p113(function() --[[ Line: 745 ]]
                -- upvalues: u115 (copy)
                for _, v119 in ipairs(u115) do
                    v119:cancel();
                end;
            end);
            for u120, v121 in ipairs(u109) do
                u115[u120] = v121:finally(function(...) --[[ Line: 754 ]]
                    -- upvalues: u118 (copy), u120 (copy)
                    u118(u120, ...);
                end);
            end;
        end);
    end;
end;
function u37.race(u122) --[[ Line: 785 ]]
    -- upvalues: u37 (copy)
    local v123 = type(u122) == "table";
    assert(v123, string.format("Please pass a list of promises to %s", "Promise.race"));
    for v124, v125 in pairs(u122) do
        local v126 = u37.is(v125);
        local l__format__1 = string.format;
        local v127 = tostring(v124);
        assert(v126, l__format__1("Non-promise value passed into %s at index %s", "Promise.race", v127));
    end;
    return u37._new(debug.traceback(nil, 2), function(u128, u129, p130) --[[ Line: 792 ]]
        -- upvalues: u122 (copy)
        local u131 = {};
        local u132 = false;
        if p130(function(...) --[[ Line: 803 ]]
            -- upvalues: u131 (copy), u132 (ref), u129 (copy)
            for _, v133 in ipairs(u131) do
                v133:cancel();
            end;
            u132 = true;
            return u129(...);
        end) then
        else
            local u134 = u132;
            for v135, v136 in ipairs(u122) do
                u131[v135] = v136:andThen(function(...) --[[ Line: 803 ]]
                    -- upvalues: u131 (copy), u134 (ref), u128 (copy)
                    for _, v137 in ipairs(u131) do
                        v137:cancel();
                    end;
                    u134 = true;
                    return u128(...);
                end, function(...) --[[ Line: 803 ]]
                    -- upvalues: u131 (copy), u134 (ref), u129 (copy)
                    for _, v138 in ipairs(u131) do
                        v138:cancel();
                    end;
                    u134 = true;
                    return u129(...);
                end);
            end;
            if u134 then
                for _, v139 in ipairs(u131) do
                    v139:cancel();
                end;
            end;
        end;
    end);
end;
function u37.each(u140, u141) --[[ Line: 880 ]]
    -- upvalues: u37 (copy), u8 (ref)
    local v142 = type(u140) == "table";
    assert(v142, string.format("Please pass a list of promises to %s", "Promise.each"));
    local v143;
    if type(u141) == "function" then
        v143 = true;
    elseif type(u141) == "table" then
        local v144 = getmetatable(u141);
        if v144 then
            local v145 = rawget(v144, "__call");
            v143 = type(v145) == "function";
        else
            v143 = false;
        end;
    else
        v143 = false;
    end;
    assert(v143, string.format("Please pass a handler function to %s!", "Promise.each"));
    return u37._new(debug.traceback(nil, 2), function(p146, p147, p148) --[[ Line: 884 ]]
        -- upvalues: u140 (copy), u37 (ref), u8 (ref), u141 (copy)
        local v149 = {};
        local u150 = {};
        local u151 = false;
        p148(function() --[[ Line: 896 ]]
            -- upvalues: u151 (ref), u150 (copy)
            u151 = true;
            for _, v152 in ipairs(u150) do
                v152:cancel();
            end;
        end);
        local v153 = u151;
        local v154 = {};
        for v155, v156 in ipairs(u140) do
            if u37.is(v156) then
                if v156:getStatus() == u37.Status.Cancelled then
                    for _, v157 in ipairs(u150) do
                        v157:cancel();
                    end;
                    return p147(u8.new({
                        error = "Promise is cancelled",
                        kind = u8.Kind.AlreadyCancelled,
                        context = string.format("The Promise that was part of the array at index %d passed into Promise.each was already cancelled when Promise.each began.\n\nThat Promise was created at:\n\n%s", v155, v156._source)
                    }));
                end;
                if v156:getStatus() == u37.Status.Rejected then
                    for _, v158 in ipairs(u150) do
                        v158:cancel();
                    end;
                    return p147(select(2, v156:await()));
                end;
                local v159 = v156:andThen(function(...) --[[ Line: 929 ]]
                    return ...;
                end);
                table.insert(u150, v159);
                v154[v155] = v159;
            else
                v154[v155] = v156;
            end;
        end;
        for v160, v163 in ipairs(v154) do
            if u37.is(v163) then
                local v162, v163 = v163:await();
                if not v162 then
                    for _, v164 in ipairs(u150) do
                        v164:cancel();
                    end;
                    return p147(v163);
                end;
            end;
            if v153 then
                return;
            end;
            local v165 = u37.resolve(u141(v163, v160));
            table.insert(u150, v165);
            local v166, v167 = v165:await();
            if not v166 then
                for _, v168 in ipairs(u150) do
                    v168:cancel();
                end;
                return p147(v167);
            end;
            v149[v160] = v167;
        end;
        p146(v149);
    end);
end;
function u37.is(p169) --[[ Line: 979 ]]
    -- upvalues: u37 (copy)
    if type(p169) ~= "table" then
        return false;
    end;
    local v170 = getmetatable(p169);
    if v170 == u37 then
        return true;
    end;
    if v170 ~= nil then
        if type(v170) == "table" then
            local v171 = rawget(v170, "__index");
            if type(v171) == "table" then
                local v172 = rawget(v170, "__index");
                local v173 = rawget(v172, "andThen");
                local v174;
                if type(v173) == "function" then
                    v174 = true;
                else
                    local v175 = type(v173) == "table" and getmetatable(v173);
                    if v175 then
                        local v176 = rawget(v175, "__call");
                        v174 = type(v176) == "function";
                    else
                        v174 = false;
                    end;
                end;
                if v174 then
                    return true;
                end;
            end;
        end;
        return false;
    end;
    local l__andThen__2 = p169.andThen;
    if type(l__andThen__2) == "function" then
        return true;
    end;
    local v177 = type(l__andThen__2) == "table" and getmetatable(l__andThen__2);
    if v177 then
        local v178 = rawget(v177, "__call");
        if type(v178) == "function" then
            return true;
        end;
    end;
    return false;
end;
function u37.promisify(u179) --[[ Line: 1028 ]]
    -- upvalues: u37 (copy)
    return function(...) --[[ Line: 1029 ]]
        -- upvalues: u37 (ref), u179 (copy)
        return u37._try(debug.traceback(nil, 2), u179, ...);
    end;
end;
local u180 = nil;
local u181 = nil;
function u37.delay(p182) --[[ Line: 1059 ]]
    -- upvalues: u37 (copy), u181 (ref), u180 (ref)
    local v183 = type(p182) == "number";
    assert(v183, "Bad argument #1 to Promise.delay, must be a number.");
    local u184 = (p182 < 0.016666666666666666 or p182 == (1 / 0)) and 0.016666666666666666 or p182;
    return u37._new(debug.traceback(nil, 2), function(p185, _, p186) --[[ Line: 1067 ]]
        -- upvalues: u37 (ref), u184 (ref), u181 (ref), u180 (ref)
        local v187 = u37._getTime();
        local v188 = v187 + u184;
        local u189 = {
            resolve = p185,
            startTime = v187,
            endTime = v188
        };
        if u181 == nil then
            u180 = u189;
            u181 = u37._timeEvent:Connect(function() --[[ Line: 1079 ]]
                -- upvalues: u37 (ref), u180 (ref), u181 (ref)
                local v190 = u37._getTime();
                while u180 ~= nil and u180.endTime < v190 do
                    local v191 = u180;
                    u180 = v191.next;
                    if u180 == nil then
                        u181:Disconnect();
                        u181 = nil;
                    else
                        u180.previous = nil;
                    end;
                    v191.resolve(u37._getTime() - v191.startTime);
                end;
            end);
        elseif u180.endTime < v188 then
            local v192 = u180;
            local l__next__3 = v192.next;
            while l__next__3 ~= nil and l__next__3.endTime < v188 do
                local l__next__4 = l__next__3.next;
                v192 = l__next__3;
                l__next__3 = l__next__4;
            end;
            v192.next = u189;
            u189.previous = v192;
            if l__next__3 ~= nil then
                u189.next = l__next__3;
                l__next__3.previous = u189;
            end;
        else
            u189.next = u180;
            u180.previous = u189;
            u180 = u189;
        end;
        p186(function() --[[ Line: 1124 ]]
            -- upvalues: u189 (copy), u180 (ref), u181 (ref)
            local l__next__5 = u189.next;
            if u180 == u189 then
                if l__next__5 == nil then
                    u181:Disconnect();
                    u181 = nil;
                else
                    l__next__5.previous = nil;
                end;
                u180 = l__next__5;
            else
                local l__previous__6 = u189.previous;
                l__previous__6.next = l__next__5;
                if l__next__5 ~= nil then
                    l__next__5.previous = l__previous__6;
                end;
            end;
        end);
    end);
end;
function u37.prototype.timeout(p193, u194, u195) --[[ Line: 1188 ]]
    -- upvalues: u37 (copy), u8 (ref)
    local u196 = debug.traceback(nil, 2);
    return u37.race({ u37.delay(u194):andThen(function() --[[ Line: 1192 ]]
            -- upvalues: u37 (ref), u195 (copy), u8 (ref), u194 (copy), u196 (copy)
            return u37.reject(u195 == nil and u8.new({
                error = "Timed out",
                kind = u8.Kind.TimedOut,
                context = string.format("Timeout of %d seconds exceeded.\n:timeout() called at:\n\n%s", u194, u196)
            }) or u195);
        end), p193 });
end;
function u37.prototype.getStatus(p197) --[[ Line: 1212 ]]
    return p197._status;
end;
function u37.prototype._andThen(u198, u199, u200, u201) --[[ Line: 1221 ]]
    -- upvalues: u37 (copy), u36 (copy), u8 (ref)
    u198._unhandledRejection = false;
    return u37._new(u199, function(u202, u203) --[[ Line: 1225 ]]
        -- upvalues: u200 (copy), u199 (copy), u36 (ref), u201 (copy), u198 (copy), u37 (ref), u8 (ref)
        local v204;
        if u200 then
            local u205 = u199;
            local u206 = u200;
            v204 = function(...) --[[ Line: 180 ]]
                -- upvalues: u36 (ref), u205 (copy), u206 (copy), u202 (copy), u203 (copy)
                local v207, v208, v209 = u36(u205, u206, ...);
                if v207 then
                    u202(unpack(v209, 1, v208));
                else
                    u203(v209[1]);
                end;
            end;
        else
            v204 = u202;
        end;
        local v210;
        if u201 then
            local u211 = u199;
            local u212 = u201;
            v210 = function(...) --[[ Line: 180 ]]
                -- upvalues: u36 (ref), u211 (copy), u212 (copy), u202 (copy), u203 (copy)
                local v213, v214, v215 = u36(u211, u212, ...);
                if v213 then
                    u202(unpack(v215, 1, v214));
                else
                    u203(v215[1]);
                end;
            end;
        else
            v210 = u203;
        end;
        if u198._status == u37.Status.Started then
            table.insert(u198._queuedResolve, v204);
            table.insert(u198._queuedReject, v210);
        elseif u198._status == u37.Status.Resolved then
            v204(unpack(u198._values, 1, u198._valuesLength));
        elseif u198._status == u37.Status.Rejected then
            v210(unpack(u198._values, 1, u198._valuesLength));
        else
            if u198._status == u37.Status.Cancelled then
                u203(u8.new({
                    error = "Promise is cancelled",
                    kind = u8.Kind.AlreadyCancelled,
                    context = "Promise created at\n\n" .. u199
                }));
            end;
        end;
    end, u198);
end;
function u37.prototype.andThen(p216, p217, p218) --[[ Line: 1282 ]]
    local v219;
    if p217 == nil or type(p217) == "function" then
        v219 = true;
    elseif type(p217) == "table" then
        local v220 = getmetatable(p217);
        if v220 then
            local v221 = rawget(v220, "__call");
            v219 = type(v221) == "function";
        else
            v219 = false;
        end;
    else
        v219 = false;
    end;
    assert(v219, string.format("Please pass a handler function to %s!", "Promise:andThen"));
    local v222;
    if p218 == nil or type(p218) == "function" then
        v222 = true;
    elseif type(p218) == "table" then
        local v223 = getmetatable(p218);
        if v223 then
            local v224 = rawget(v223, "__call");
            v222 = type(v224) == "function";
        else
            v222 = false;
        end;
    else
        v222 = false;
    end;
    assert(v222, string.format("Please pass a handler function to %s!", "Promise:andThen"));
    return p216:_andThen(debug.traceback(nil, 2), p217, p218);
end;
function u37.prototype.andThenAsync(p225, p226, p227) --[[ Line: 1310 ]]
    -- upvalues: u28 (copy), u37 (copy)
    local v228;
    if p226 == nil or type(p226) == "function" then
        v228 = true;
    elseif type(p226) == "table" then
        local v229 = getmetatable(p226);
        if v229 then
            local v230 = rawget(v229, "__call");
            v228 = type(v230) == "function";
        else
            v228 = false;
        end;
    else
        v228 = false;
    end;
    assert(v228, string.format("Please pass a handler function to %s!", "Promise:andThenAsync"));
    local v231;
    if p227 == nil or type(p227) == "function" then
        v231 = true;
    elseif type(p227) == "table" then
        local v232 = getmetatable(p227);
        if v232 then
            local v233 = rawget(v232, "__call");
            v231 = type(v233) == "function";
        else
            v231 = false;
        end;
    else
        v231 = false;
    end;
    assert(v231, string.format("Please pass a handler function to %s!", "Promise:andThenAsync"));
    return p225:_andThen(debug.traceback(nil, 2), function(...) --[[ Line: 1317 ]]
        -- upvalues: u28 (ref), u37 (ref)
        local u234, u235 = u28(...);
        return u37.defer(function(p236) --[[ Line: 1319 ]]
            -- upvalues: u235 (copy), u234 (copy)
            p236(unpack(u235, 1, u234));
        end);
    end, function(...) --[[ Line: 1323 ]]
        -- upvalues: u28 (ref), u37 (ref)
        local u237, u238 = u28(...);
        return u37.defer(function(_, p239) --[[ Line: 1325 ]]
            -- upvalues: u238 (copy), u237 (copy)
            p239(unpack(u238, 1, u237));
        end);
    end):andThen(p226, p227);
end;
function u37.prototype.catch(p240, p241) --[[ Line: 1352 ]]
    local v242;
    if p241 == nil or type(p241) == "function" then
        v242 = true;
    elseif type(p241) == "table" then
        local v243 = getmetatable(p241);
        if v243 then
            local v244 = rawget(v243, "__call");
            v242 = type(v244) == "function";
        else
            v242 = false;
        end;
    else
        v242 = false;
    end;
    assert(v242, string.format("Please pass a handler function to %s!", "Promise:catch"));
    return p240:_andThen(debug.traceback(nil, 2), nil, p241);
end;
function u37.prototype.tap(p245, u246) --[[ Line: 1373 ]]
    -- upvalues: u37 (copy), u28 (copy)
    local v247;
    if type(u246) == "function" then
        v247 = true;
    elseif type(u246) == "table" then
        local v248 = getmetatable(u246);
        if v248 then
            local v249 = rawget(v248, "__call");
            v247 = type(v249) == "function";
        else
            v247 = false;
        end;
    else
        v247 = false;
    end;
    assert(v247, string.format("Please pass a handler function to %s!", "Promise:tap"));
    return p245:_andThen(debug.traceback(nil, 2), function(...) --[[ Line: 1375 ]]
        -- upvalues: u246 (copy), u37 (ref), u28 (ref)
        local v250 = u246(...);
        if not u37.is(v250) then
            return ...;
        end;
        local u251, u252 = u28(...);
        return v250:andThen(function() --[[ Line: 1380 ]]
            -- upvalues: u252 (copy), u251 (copy)
            return unpack(u252, 1, u251);
        end);
    end);
end;
function u37.prototype.andThenCall(p253, u254, ...) --[[ Line: 1408 ]]
    -- upvalues: u28 (copy)
    local v255;
    if type(u254) == "function" then
        v255 = true;
    elseif type(u254) == "table" then
        local v256 = getmetatable(u254);
        if v256 then
            local v257 = rawget(v256, "__call");
            v255 = type(v257) == "function";
        else
            v255 = false;
        end;
    else
        v255 = false;
    end;
    assert(v255, string.format("Please pass a handler function to %s!", "Promise:andThenCall"));
    local u258, u259 = u28(...);
    return p253:_andThen(debug.traceback(nil, 2), function() --[[ Line: 1411 ]]
        -- upvalues: u254 (copy), u259 (copy), u258 (copy)
        return u254(unpack(u259, 1, u258));
    end);
end;
function u37.prototype.andThenReturn(p260, ...) --[[ Line: 1438 ]]
    -- upvalues: u28 (copy)
    local u261, u262 = u28(...);
    return p260:_andThen(debug.traceback(nil, 2), function() --[[ Line: 1440 ]]
        -- upvalues: u262 (copy), u261 (copy)
        return unpack(u262, 1, u261);
    end);
end;
function u37.prototype.cancel(p263) --[[ Line: 1456 ]]
    -- upvalues: u37 (copy)
    if p263._status == u37.Status.Started then
        p263._status = u37.Status.Cancelled;
        if p263._cancellationHook then
            p263._cancellationHook();
        end;
        coroutine.close(p263._thread);
        if p263._parent then
            p263._parent:_consumerCancelled(p263);
        end;
        for v264 in pairs(p263._consumers) do
            v264:cancel();
        end;
        p263:_finalize();
    end;
end;
function u37.prototype._consumerCancelled(p265, p266) --[[ Line: 1484 ]]
    -- upvalues: u37 (copy)
    if p265._status == u37.Status.Started then
        p265._consumers[p266] = nil;
        if next(p265._consumers) == nil then
            p265:cancel();
        end;
    end;
end;
function u37.prototype._finally(u267, u268, u269, u270) --[[ Line: 1500 ]]
    -- upvalues: u37 (copy), u36 (copy)
    if not u270 then
        u267._unhandledRejection = false;
    end;
    return u37._new(u268, function(u271, u272) --[[ Line: 1506 ]]
        -- upvalues: u269 (copy), u268 (copy), u36 (ref), u270 (copy), u267 (copy), u37 (ref)
        local u273;
        if u269 then
            local u274 = u268;
            local u275 = u269;
            u273 = function(...) --[[ Line: 180 ]]
                -- upvalues: u36 (ref), u274 (copy), u275 (copy), u271 (copy), u272 (copy)
                local v276, v277, v278 = u36(u274, u275, ...);
                if v276 then
                    u271(unpack(v278, 1, v277));
                else
                    u272(v278[1]);
                end;
            end;
        else
            u273 = u271;
        end;
        local v279 = u270 and function(...) --[[ Line: 1514 ]]
            -- upvalues: u267 (ref), u37 (ref), u271 (copy), u273 (copy)
            if u267._status == u37.Status.Rejected then
                return u271(u267);
            else
                return u273(...);
            end;
        end or u273;
        if u267._status == u37.Status.Started then
            table.insert(u267._queuedFinally, v279);
        else
            v279(u267._status);
        end;
    end, u267);
end;
function u37.prototype.finally(p280, p281) --[[ Line: 1582 ]]
    local v282;
    if p281 == nil or type(p281) == "function" then
        v282 = true;
    elseif type(p281) == "table" then
        local v283 = getmetatable(p281);
        if v283 then
            local v284 = rawget(v283, "__call");
            v282 = type(v284) == "function";
        else
            v282 = false;
        end;
    else
        v282 = false;
    end;
    assert(v282, string.format("Please pass a handler function to %s!", "Promise:finally"));
    return p280:_finally(debug.traceback(nil, 2), p281);
end;
function u37.prototype.finallyCall(p285, u286, ...) --[[ Line: 1596 ]]
    -- upvalues: u28 (copy)
    local v287;
    if type(u286) == "function" then
        v287 = true;
    elseif type(u286) == "table" then
        local v288 = getmetatable(u286);
        if v288 then
            local v289 = rawget(v288, "__call");
            v287 = type(v289) == "function";
        else
            v287 = false;
        end;
    else
        v287 = false;
    end;
    assert(v287, string.format("Please pass a handler function to %s!", "Promise:finallyCall"));
    local u290, u291 = u28(...);
    return p285:_finally(debug.traceback(nil, 2), function() --[[ Line: 1599 ]]
        -- upvalues: u286 (copy), u291 (copy), u290 (copy)
        return u286(unpack(u291, 1, u290));
    end);
end;
function u37.prototype.finallyReturn(p292, ...) --[[ Line: 1622 ]]
    -- upvalues: u28 (copy)
    local u293, u294 = u28(...);
    return p292:_finally(debug.traceback(nil, 2), function() --[[ Line: 1624 ]]
        -- upvalues: u294 (copy), u293 (copy)
        return unpack(u294, 1, u293);
    end);
end;
function u37.prototype.done(p295, p296) --[[ Line: 1632 ]]
    local v297;
    if p296 == nil or type(p296) == "function" then
        v297 = true;
    elseif type(p296) == "table" then
        local v298 = getmetatable(p296);
        if v298 then
            local v299 = rawget(v298, "__call");
            v297 = type(v299) == "function";
        else
            v297 = false;
        end;
    else
        v297 = false;
    end;
    assert(v297, string.format("Please pass a handler function to %s!", "Promise:done"));
    return p295:_finally(debug.traceback(nil, 2), p296, true);
end;
function u37.prototype.doneCall(p300, u301, ...) --[[ Line: 1643 ]]
    -- upvalues: u28 (copy)
    local v302;
    if type(u301) == "function" then
        v302 = true;
    elseif type(u301) == "table" then
        local v303 = getmetatable(u301);
        if v303 then
            local v304 = rawget(v303, "__call");
            v302 = type(v304) == "function";
        else
            v302 = false;
        end;
    else
        v302 = false;
    end;
    assert(v302, string.format("Please pass a handler function to %s!", "Promise:doneCall"));
    local u305, u306 = u28(...);
    return p300:_finally(debug.traceback(nil, 2), function() --[[ Line: 1646 ]]
        -- upvalues: u301 (copy), u306 (copy), u305 (copy)
        return u301(unpack(u306, 1, u305));
    end, true);
end;
function u37.prototype.doneReturn(p307, ...) --[[ Line: 1654 ]]
    -- upvalues: u28 (copy)
    local u308, u309 = u28(...);
    return p307:_finally(debug.traceback(nil, 2), function() --[[ Line: 1656 ]]
        -- upvalues: u309 (copy), u308 (copy)
        return unpack(u309, 1, u308);
    end, true);
end;
function u37.prototype.awaitStatus(p310) --[[ Line: 1668 ]]
    -- upvalues: u37 (copy)
    p310._unhandledRejection = false;
    if p310._status == u37.Status.Started then
        local u311 = coroutine.running();
        p310:finally(function() --[[ Line: 1674 ]]
            -- upvalues: u311 (copy)
            task.spawn(u311);
        end);
        coroutine.yield();
    end;
    if p310._status == u37.Status.Resolved then
        return p310._status, unpack(p310._values, 1, p310._valuesLength);
    elseif p310._status == u37.Status.Rejected then
        return p310._status, unpack(p310._values, 1, p310._valuesLength);
    else
        return p310._status;
    end;
end;
local function u313(p312, ...) --[[ Line: 1690 ]]
    -- upvalues: u37 (copy)
    return p312 == u37.Status.Resolved, ...;
end;
function u37.prototype.await(p314) --[[ Line: 1715 ]]
    -- upvalues: u313 (copy)
    return u313(p314:awaitStatus());
end;
local function u316(p315, ...) --[[ Line: 1719 ]]
    -- upvalues: u37 (copy)
    if p315 ~= u37.Status.Resolved then
        error(... == nil and "Expected Promise rejected with no value." or ..., 3);
    end;
    return ...;
end;
function u37.prototype.expect(p317) --[[ Line: 1752 ]]
    -- upvalues: u316 (copy)
    return u316(p317:awaitStatus());
end;
u37.prototype.awaitValue = u37.prototype.expect;
function u37.prototype._unwrap(p318) --[[ Line: 1766 ]]
    -- upvalues: u37 (copy)
    if p318._status == u37.Status.Started then
        error("Promise has not resolved or rejected.", 2);
    end;
    return p318._status == u37.Status.Resolved, unpack(p318._values, 1, p318._valuesLength);
end;
function u37.prototype._resolve(u319, ...) --[[ Line: 1776 ]]
    -- upvalues: u37 (copy), u8 (ref), u28 (copy)
    if u319._status == u37.Status.Started then
        if u37.is((...)) then
            if select("#", ...) > 1 then
                local v320 = string.format("When returning a Promise from andThen, extra arguments are discarded! See:\n\n%s", u319._source);
                warn(v320);
            end;
            local u321 = ...;
            local v323 = u321:andThen(function(...) --[[ Line: 1797 ]]
                -- upvalues: u319 (copy)
                u319:_resolve(...);
            end, function(...) --[[ Line: 1799 ]]
                -- upvalues: u321 (copy), u8 (ref), u319 (copy)
                local v322 = u321._values[1];
                if u321._error then
                    v322 = u8.new({
                        context = "[No stack trace available as this Promise originated from an older version of the Promise library (< v2)]",
                        error = u321._error,
                        kind = u8.Kind.ExecutionError
                    });
                end;
                if u8.isKind(v322, u8.Kind.ExecutionError) then
                    return u319:_reject(v322:extend({
                        error = "This Promise was chained to a Promise that errored.",
                        trace = "",
                        context = string.format("The Promise at:\n\n%s\n...Rejected because it was chained to the following Promise, which encountered an error:\n", u319._source)
                    }));
                end;
                u319:_reject(...);
            end);
            if v323._status == u37.Status.Cancelled then
                u319:cancel();
            else
                if v323._status == u37.Status.Started then
                    u319._parent = v323;
                    v323._consumers[u319] = true;
                end;
            end;
        else
            u319._status = u37.Status.Resolved;
            local v324, v325 = u28(...);
            u319._valuesLength = v324;
            u319._values = v325;
            for _, v326 in ipairs(u319._queuedResolve) do
                coroutine.wrap(v326)(...);
            end;
            u319:_finalize();
        end;
    else
        if u37.is((...)) then
            (...):_consumerCancelled(u319);
        end;
    end;
end;
function u37.prototype._reject(u327, ...) --[[ Line: 1847 ]]
    -- upvalues: u37 (copy), u28 (copy)
    if u327._status == u37.Status.Started then
        u327._status = u37.Status.Rejected;
        local v328, v329 = u28(...);
        u327._valuesLength = v328;
        u327._values = v329;
        if next(u327._queuedReject) == nil then
            local u330 = tostring((...));
            coroutine.wrap(function() --[[ Line: 1869 ]]
                -- upvalues: u37 (ref), u327 (copy), u330 (copy)
                u37._timeEvent:Wait();
                if u327._unhandledRejection then
                    local v331 = string.format("Unhandled Promise rejection:\n\n%s\n\n%s", u330, u327._source);
                    for _, v332 in ipairs(u37._unhandledRejectionCallbacks) do
                        task.spawn(v332, u327, unpack(u327._values, 1, u327._valuesLength));
                    end;
                    if u37.TEST then
                    else
                        warn(v331);
                    end;
                end;
            end)();
        else
            for _, v333 in ipairs(u327._queuedReject) do
                coroutine.wrap(v333)(...);
            end;
        end;
        u327:_finalize();
    end;
end;
function u37.prototype._finalize(p334) --[[ Line: 1901 ]]
    -- upvalues: u37 (copy)
    for _, v335 in ipairs(p334._queuedFinally) do
        coroutine.wrap(v335)(p334._status);
    end;
    p334._queuedFinally = nil;
    p334._queuedReject = nil;
    p334._queuedResolve = nil;
    if not u37.TEST then
        p334._parent = nil;
        p334._consumers = nil;
    end;
    task.defer(coroutine.close, p334._thread);
end;
function u37.prototype.now(p336, p337) --[[ Line: 1938 ]]
    -- upvalues: u37 (copy), u8 (ref)
    local v338 = debug.traceback(nil, 2);
    if p336._status == u37.Status.Resolved then
        return p336:_andThen(v338, function(...) --[[ Line: 1941 ]]
            return ...;
        end);
    end;
    local l__reject__7 = u37.reject;
    if p337 == nil then
        p337 = u8.new({
            error = "This Promise was not resolved in time for :now()",
            kind = u8.Kind.NotResolvedInTime,
            context = ":now() was called at:\n\n" .. v338
        }) or p337;
    end;
    return l__reject__7(p337);
end;
function u37.retry(u339, u340, ...) --[[ Line: 1983 ]]
    -- upvalues: u37 (copy)
    local v341;
    if type(u339) == "function" then
        v341 = true;
    elseif type(u339) == "table" then
        local v342 = getmetatable(u339);
        if v342 then
            local v343 = rawget(v342, "__call");
            v341 = type(v343) == "function";
        else
            v341 = false;
        end;
    else
        v341 = false;
    end;
    assert(v341, "Parameter #1 to Promise.retry must be a function");
    local v344 = type(u340) == "number";
    assert(v344, "Parameter #2 to Promise.retry must be a number");
    local u345 = { ... };
    local u346 = select("#", ...);
    return u37.resolve(u339(...)):catch(function(...) --[[ Line: 1989 ]]
        -- upvalues: u340 (copy), u37 (ref), u339 (copy), u345 (copy), u346 (copy)
        if u340 > 0 then
            return u37.retry(u339, u340 - 1, unpack(u345, 1, u346));
        else
            return u37.reject(...);
        end;
    end);
end;
function u37.retryWithDelay(u347, u348, u349, ...) --[[ Line: 2011 ]]
    -- upvalues: u37 (copy)
    local v350;
    if type(u347) == "function" then
        v350 = true;
    elseif type(u347) == "table" then
        local v351 = getmetatable(u347);
        if v351 then
            local v352 = rawget(v351, "__call");
            v350 = type(v352) == "function";
        else
            v350 = false;
        end;
    else
        v350 = false;
    end;
    assert(v350, "Parameter #1 to Promise.retry must be a function");
    local v353 = type(u348) == "number";
    assert(v353, "Parameter #2 (times) to Promise.retry must be a number");
    local v354 = type(u349) == "number";
    assert(v354, "Parameter #3 (seconds) to Promise.retry must be a number");
    local u355 = { ... };
    local u356 = select("#", ...);
    return u37.resolve(u347(...)):catch(function(...) --[[ Line: 2018 ]]
        -- upvalues: u348 (copy), u37 (ref), u349 (copy), u347 (copy), u355 (copy), u356 (copy)
        if u348 <= 0 then
            return u37.reject(...);
        end;
        u37.delay(u349):await();
        return u37.retryWithDelay(u347, u348 - 1, u349, unpack(u355, 1, u356));
    end);
end;
function u37.fromEvent(u357, p358) --[[ Line: 2053 ]]
    -- upvalues: u37 (copy)
    local u359 = p358 or function() --[[ Line: 2054 ]]
        return true;
    end;
    return u37._new(debug.traceback(nil, 2), function(u360, _, p361) --[[ Line: 2058 ]]
        -- upvalues: u357 (copy), u359 (ref)
        local u362 = nil;
        local u363 = false;
        local function v364() --[[ Line: 2062 ]]
            -- upvalues: u362 (ref)
            u362:Disconnect();
            u362 = nil;
        end;
        u362 = u357:Connect(function(...) --[[ Line: 2071 ]]
            -- upvalues: u359 (ref), u360 (copy), u362 (ref), u363 (ref)
            local v365 = u359(...);
            if v365 == true then
                u360(...);
                if u362 then
                    u362:Disconnect();
                    u362 = nil;
                else
                    u363 = true;
                end;
            else
                if type(v365) ~= "boolean" then
                    error("Promise.fromEvent predicate should always return a boolean");
                end;
            end;
        end);
        if u363 and u362 then
            return v364();
        end;
        p361(v364);
    end);
end;
function u37.onUnhandledRejection(u366) --[[ Line: 2105 ]]
    -- upvalues: u37 (copy)
    table.insert(u37._unhandledRejectionCallbacks, u366);
    return function() --[[ Line: 2108 ]]
        -- upvalues: u37 (ref), u366 (copy)
        local v367 = table.find(u37._unhandledRejectionCallbacks, u366);
        if v367 then
            table.remove(u37._unhandledRejectionCallbacks, v367);
        end;
    end;
end;
return u37;