-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.inspect
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__HttpService__1 = game:GetService("HttpService");
local l__isArray__2 = require(script.Parent:WaitForChild("Array"):WaitForChild("isArray"));
require(script.Parent.Parent:WaitForChild("es7-types"));
local u1 = nil;
local u2 = nil;
local u3 = nil;
local u4 = nil;
local u5 = nil;
local function v10(p6, p7) --[[ Line: 34 ]]
    -- upvalues: u1 (ref)
    local v8 = p7 or {
        depth = 2
    };
    local v9 = v8.depth or 2;
    v8.depth = v9 < 0 and 2 or v9;
    return u1(p6, {}, v8);
end;
local function u15(p11, p12) --[[ Line: 58 ]]
    local v13 = type(p11);
    local v14 = type(p12);
    if v13 == v14 and (v13 == "number" or v13 == "string") then
        return p11 < p12;
    else
        return v13 < v14;
    end;
end;
local function u24(p16) --[[ Line: 75 ]]
    -- upvalues: u15 (copy)
    local v17 = 1;
    local v18 = rawget(p16, v17);
    local v19 = 0;
    local v20 = {};
    while v18 ~= nil do
        v17 = v17 + 1;
        v18 = rawget(p16, v17);
    end;
    local v21 = v17 - 1;
    for v22, _ in next, p16 do
        local v23;
        if type(v22) == "number" and (v22 <= v21 and v22 >= 1) then
            v23 = math.floor(v22) == v22;
        else
            v23 = false;
        end;
        if not v23 then
            v19 = v19 + 1;
            v20[v19] = v22;
        end;
    end;
    table.sort(v20, u15);
    return v20, v19, v21;
end;
u1 = function(p25, p26, p27) --[[ Name: formatValue, Line 89 ]]
    -- upvalues: l__HttpService__1 (copy), u2 (ref)
    local v28 = typeof(p25);
    if v28 == "string" then
        return l__HttpService__1:JSONEncode(p25);
    elseif v28 == "number" then
        return p25 ~= p25 and "NaN" or (p25 == (1 / 0) and "Infinity" or (p25 == (-1 / 0) and "-Infinity" or tostring(p25)));
    elseif v28 == "function" then
        local v29 = "[function";
        local v30 = debug.info(p25, "n");
        if v30 ~= nil and v30 ~= "" then
            v29 = v29 .. " " .. v30;
        end;
        return v29 .. "]";
    elseif v28 == "table" then
        return u2(p25, p26, p27);
    else
        return tostring(p25);
    end;
end;
u2 = function(p31, p32, p33) --[[ Name: formatObjectValue, Line 122 ]]
    -- upvalues: u1 (ref), l__isArray__2 (copy), u3 (ref), u4 (ref)
    if table.find(p32, p31) ~= nil then
        return "[Circular]";
    end;
    local v34 = { unpack(p32) };
    table.insert(v34, p31);
    if typeof(p31.toJSON) == "function" then
        local v35 = p31:toJSON(p31);
        if v35 ~= p31 then
            if typeof(v35) == "string" then
                return v35;
            else
                return u1(v35, v34, p33);
            end;
        end;
    elseif l__isArray__2(p31) then
        return u3(p31, v34, p33);
    end;
    return u4(p31, v34, p33);
end;
u4 = function(p36, p37, p38) --[[ Name: formatObject, Line 147 ]]
    -- upvalues: u24 (copy), u5 (ref), u1 (ref)
    local v39 = "";
    local v40 = getmetatable(p36);
    if v40 and rawget(v40, "__tostring") then
        return tostring(p36);
    end;
    local v41, v42, v43 = u24(p36);
    if v43 == 0 and v42 == 0 then
        return v39 .. "{}";
    end;
    if #p37 > p38.depth then
        return v39 .. "[" .. u5(p36) .. "]";
    end;
    local v44 = {};
    for v45 = 1, v43 do
        local v46 = u1(p36[v45], p37, p38);
        table.insert(v44, v46);
    end;
    for v47 = 1, v42 do
        local v48 = v41[v47];
        local v49 = v48 .. ": " .. u1(p36[v48], p37, p38);
        table.insert(v44, v49);
    end;
    return v39 .. "{ " .. table.concat(v44, ", ") .. " }";
end;
u3 = function(p50, p51, p52) --[[ Name: formatArray, Line 183 ]]
    -- upvalues: u1 (ref)
    local v53 = #p50;
    if v53 == 0 then
        return "[]";
    end;
    if #p51 > p52.depth then
        return "[Array]";
    end;
    local v54 = math.min(10, v53);
    local v55 = v53 - v54;
    local v56 = {};
    for v57 = 1, v54 do
        v56[v57] = u1(p50[v57], p51, p52);
    end;
    if v55 == 1 then
        table.insert(v56, "... 1 more item");
    elseif v55 > 1 then
        local v58 = tostring(v55);
        table.insert(v56, ("... %s more items"):format(v58));
    end;
    return "[" .. table.concat(v56, ", ") .. "]";
end;
u5 = function(_) --[[ Name: getObjectTag, Line 209 ]]
    return "Object";
end;
return v10;