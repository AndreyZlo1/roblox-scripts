-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Set
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
local l__inspect__2 = require(script.Parent:WaitForChild("inspect"));
local l__isArray__3 = require(script.Parent:WaitForChild("Array"):WaitForChild("isArray"));
local l__forEach__4 = require(script.Parent:WaitForChild("Array"):WaitForChild("forEach"));
local l__fromString__5 = require(script.Parent:WaitForChild("Array"):WaitForChild("from"):WaitForChild("fromString"));
require(script.Parent.Parent:WaitForChild("es7-types"));
local u4 = {
    __iter = function(p1) --[[ Name: __iter, Line 23 ]]
        return next, p1._array;
    end,
    __tostring = function(p2) --[[ Name: __tostring, Line 26 ]]
        -- upvalues: l__inspect__2 (copy)
        local v3 = "Set ";
        if #p2._array > 0 then
            v3 = v3 .. "(" .. tostring(#p2._array) .. ") ";
        end;
        return v3 .. l__inspect__2(p2._array);
    end
};
u4.__index = u4;
function u4.new(p5) --[[ Line: 38 ]]
    -- upvalues: l__isArray__3 (copy), l____DEV____1 (copy), l__fromString__5 (copy), u4 (copy)
    local v6 = {};
    local v7;
    if p5 == nil then
        v7 = {};
    else
        local v8 = nil;
        if typeof(p5) == "table" then
            if l__isArray__3(p5) then
                v8 = table.clone(p5);
            else
                local v9 = getmetatable(p5);
                if v9 and rawget(v9, "__iter") then
                    v8 = p5;
                elseif l____DEV____1 then
                    error("cannot create array from an object-like table");
                end;
            end;
        elseif typeof(p5) == "string" then
            v8 = l__fromString__5(p5);
        else
            error(("cannot create array from value of type `%s`"):format((typeof(p5))));
        end;
        if v8 then
            v7 = table.create(#v8);
            for _, v10 in v8 do
                if not v6[v10] then
                    v6[v10] = true;
                    table.insert(v7, v10);
                end;
            end;
        else
            v7 = {};
        end;
    end;
    return setmetatable({
        size = #v7,
        _map = v6,
        _array = v7
    }, u4);
end;
function u4.add(p11, p12) --[[ Line: 84 ]]
    if not p11._map[p12] then
        p11.size = p11.size + 1;
        p11._map[p12] = true;
        table.insert(p11._array, p12);
    end;
    return p11;
end;
function u4.clear(p13) --[[ Line: 94 ]]
    p13.size = 0;
    table.clear(p13._map);
    table.clear(p13._array);
end;
function u4.delete(p14, p15) --[[ Line: 100 ]]
    if not p14._map[p15] then
        return false;
    end;
    p14.size = p14.size - 1;
    p14._map[p15] = nil;
    local v16 = table.find(p14._array, p15);
    if v16 then
        table.remove(p14._array, v16);
    end;
    return true;
end;
function u4.forEach(u17, u18, u19) --[[ Line: 116 ]]
    -- upvalues: l__forEach__4 (copy)
    if typeof(u18) ~= "function" then
        error("callback is not a function");
    end;
    l__forEach__4(u17._array, function(p20) --[[ Line: 122 ]]
        -- upvalues: u19 (copy), u18 (copy), u17 (copy)
        if u19 == nil then
            u18(p20, p20, u17);
        else
            u18(u19, p20, p20, u17);
        end;
    end);
end;
function u4.has(p21, p22) --[[ Line: 131 ]]
    return p21._map[p22] ~= nil;
end;
function u4.ipairs(p23) --[[ Line: 135 ]]
    -- upvalues: l____DEV____1 (copy)
    if l____DEV____1 then
        warn(debug.traceback("`for _,_ in mySet:ipairs() do` is deprecated and will be removed in a future release, please use `for _,_ in mySet do` instead\n", 2));
    end;
    return ipairs(p23._array);
end;
return u4;