-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Array__1 = require(script:WaitForChild("Array"));
local l__Map__2 = require(script:WaitForChild("Map"));
local l__Object__3 = require(script:WaitForChild("Object"));
local l__Set__4 = require(script:WaitForChild("Set"));
local l__WeakMap__5 = require(script:WaitForChild("WeakMap"));
local l__inspect__6 = require(script:WaitForChild("inspect"));
require(script.Parent:WaitForChild("es7-types"));
return {
    Array = l__Array__1,
    Object = l__Object__3,
    Map = l__Map__2.Map,
    coerceToMap = l__Map__2.coerceToMap,
    coerceToTable = l__Map__2.coerceToTable,
    Set = l__Set__4,
    WeakMap = l__WeakMap__5,
    inspect = l__inspect__6
};