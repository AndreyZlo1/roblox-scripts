-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_string@1.2.7.string.trim
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__trimStart__1 = require(script.Parent:WaitForChild("trimStart"));
local l__trimEnd__2 = require(script.Parent:WaitForChild("trimEnd"));
return function(p1) --[[ Line: 4 ]]
    -- upvalues: l__trimStart__1 (copy), l__trimEnd__2 (copy)
    return l__trimStart__1(l__trimEnd__2(p1));
end;