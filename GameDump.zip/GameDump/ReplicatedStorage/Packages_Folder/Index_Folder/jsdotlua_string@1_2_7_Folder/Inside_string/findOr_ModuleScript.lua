-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_string@1.2.7.string.findOr
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = "([" .. ("$%^()-[].?"):gsub("(.)", "%%%1") .. "])";
return function(p2, p3, p4) --[[ Name: findOr, Line 9 ]]
    -- upvalues: u1 (copy)
    local v5 = utf8.offset(p2, p4 or 1);
    local v6 = {};
    for _, v7 in p3 do
        local v8 = v7:gsub(u1, "%%%1");
        local v9, v10 = string.find(p2, v8, v5);
        if v9 then
            local v11 = string.sub(p2, 1, v9 - 1);
            local v12, v13 = utf8.len(v11);
            if v12 == nil then
                error(("string `%s` has an invalid byte at position %s"):format(v11, (tostring(v13))));
            end;
            local v14 = {
                index = v12 + 1,
                match = string.sub(p2, v9, v10)
            };
            table.insert(v6, v14);
        end;
    end;
    if #v6 == 0 then
        return nil;
    end;
    local v15 = nil;
    for _, v16 in v6 do
        if v15 == nil then
            v15 = v16;
        end;
        if v16.index < v15.index then
            v15 = v16;
        end;
    end;
    return v15;
end;