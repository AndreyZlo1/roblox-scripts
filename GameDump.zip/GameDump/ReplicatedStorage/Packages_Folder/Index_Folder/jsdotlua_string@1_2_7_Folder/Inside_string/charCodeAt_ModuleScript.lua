-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_string@1.2.7.string.charCodeAt
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__NaN__1 = require(script.Parent.Parent:WaitForChild("number")).NaN;
return function(p1, p2) --[[ Line: 7 ]]
    -- upvalues: l__NaN__1 (copy)
    local v3 = type(p2) ~= "number" and 1 or p2;
    local v4 = string.len(p1);
    if v3 < 1 or v4 < v3 then
        return l__NaN__1;
    else
        local v5 = utf8.offset(p1, v3);
        if v5 == nil or v4 < v5 then
            return l__NaN__1;
        else
            local v6 = utf8.codepoint(p1, v5, v5);
            if v6 == nil then
                return l__NaN__1;
            else
                return v6;
            end;
        end;
    end;
end;