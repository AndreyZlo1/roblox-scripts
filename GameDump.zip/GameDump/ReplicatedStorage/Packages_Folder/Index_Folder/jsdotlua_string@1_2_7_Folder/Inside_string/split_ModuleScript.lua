-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_string@1.2.7.string.split
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__findOr__1 = require(script.Parent:WaitForChild("findOr"));
local l__slice__2 = require(script.Parent:WaitForChild("slice"));
require(script.Parent.Parent:WaitForChild("es7-types"));
local l__MAX_SAFE_INTEGER__3 = require(script.Parent.Parent:WaitForChild("number")).MAX_SAFE_INTEGER;
return function(p1, p2, p3) --[[ Name: split, Line 10 ]]
    -- upvalues: l__MAX_SAFE_INTEGER__3 (copy), l__findOr__1 (copy), l__slice__2 (copy)
    if p2 == nil then
        return { p1 };
    end;
    if p3 == 0 then
        return {};
    end;
    if p3 == nil or p3 < 0 then
        p3 = l__MAX_SAFE_INTEGER__3;
    end;
    if typeof(p2) == "string" then
        if p2 == "" then
            local v4 = {};
            for v5 in p1:gmatch(".") do
                table.insert(v4, v5);
            end;
            return v4;
        end;
        p2 = { p2 };
    end;
    local v6, v7 = utf8.len(p1);
    local v8 = v6 ~= nil;
    local v9 = tostring(v7);
    assert(v8, ("string `%s` has an invalid byte at position %s"):format(p1, v9));
    local v10 = 1;
    local v11 = {};
    local v12 = nil;
    while true do
        local v13 = l__findOr__1(p1, p2, v10);
        if v13 == nil then
            table.insert(v11, l__slice__2(p1, v10, nil));
        else
            table.insert(v11, l__slice__2(p1, v10, v13.index));
            local v14 = utf8.len(v13.match);
            v10 = v13.index + v14;
        end;
        if v13 ~= nil then
            v12 = v13;
        end;
        if v13 == nil or (v6 < v10 or p3 <= #v11) then
            if v12 ~= nil then
                local v15, v16 = utf8.len(v12.match);
                local v17 = v15 ~= nil;
                local l__match__4 = v12.match;
                local v18 = tostring(v16);
                assert(v17, ("string `%s` has an invalid byte at position %s"):format(l__match__4, v18));
                if v12.index + v15 == v6 + 1 then
                    table.insert(v11, "");
                end;
            end;
            return v11;
        end;
    end;
end;