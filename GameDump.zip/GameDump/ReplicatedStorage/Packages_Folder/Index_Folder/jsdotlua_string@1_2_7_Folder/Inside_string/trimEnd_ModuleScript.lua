-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_string@1.2.7.string.trimEnd
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function(p1) --[[ Line: 1 ]]
    return p1:gsub("[%s]+$", "");
end;