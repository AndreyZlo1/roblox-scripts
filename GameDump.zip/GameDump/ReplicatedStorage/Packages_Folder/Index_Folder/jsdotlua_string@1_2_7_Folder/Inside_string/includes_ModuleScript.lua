-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_string@1.2.7.string.includes
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = "([" .. ("$%^()-[].?"):gsub("(.)", "%%%1") .. "])";
return function(p2, p3, p4) --[[ Name: includes, Line 4 ]]
    -- upvalues: u1 (copy)
    local v5, v6 = utf8.len(p2);
    local v7 = v5 ~= nil;
    local v8 = tostring(v6);
    assert(v7, ("string `%s` has an invalid byte at position %s"):format(p2, v8));
    if v5 == 0 then
        return false;
    end;
    if #p3 == 0 then
        return true;
    end;
    local v9;
    if p4 == nil then
        v9 = 1;
    else
        v9 = tonumber(p4) or 1;
        if v5 < v9 then
            return false;
        end;
    end;
    local v10 = utf8.offset(p2, v9 < 1 and 1 or v9);
    local v11 = p3:gsub(u1, "%%%1");
    local v12, _ = string.find(p2, v11, v10);
    return v12 ~= nil;
end;