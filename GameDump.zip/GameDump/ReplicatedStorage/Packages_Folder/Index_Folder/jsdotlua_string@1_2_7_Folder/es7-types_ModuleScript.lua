-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_string@1.2.7.es7-types
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent.Parent["jsdotlua_es7-types@1.2.7"]["es7-types"]);