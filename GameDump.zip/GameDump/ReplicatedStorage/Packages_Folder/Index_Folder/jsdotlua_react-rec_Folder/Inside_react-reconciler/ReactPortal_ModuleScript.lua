-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactPortal
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__REACT_PORTAL_TYPE__1 = require(script.Parent.Parent:WaitForChild("shared")).ReactSymbols.REACT_PORTAL_TYPE;
require(script.Parent.Parent:WaitForChild("shared"));
return {
    createPortal = function(p1, p2, p3, p4) --[[ Name: createPortal, Line 17 ]]
        -- upvalues: l__REACT_PORTAL_TYPE__1 (copy)
        if p4 ~= nil then
            p4 = tostring(p4);
        end;
        return {
            ["$$typeof"] = l__REACT_PORTAL_TYPE__1,
            key = p4,
            children = p1,
            containerInfo = p2,
            implementation = p3
        };
    end
};