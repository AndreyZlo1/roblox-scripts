-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.DebugTracing
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__console__1 = require(script.Parent.Parent:WaitForChild("shared")).console;
local v1 = {};
local u2 = nil;
require(script.Parent:WaitForChild("ReactFiberLane"));
local l__enableDebugTracing__2 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags.enableDebugTracing;
local u3 = nil;
local u4 = {};
local u5 = 0;
function decimalToBinaryString(p6)
    local v7 = "";
    repeat
        local v8;
        p6, v8 = math.modf(p6 / 2);
        v7 = math.ceil(v8) .. v7;
    until p6 == 0;
    local v9 = 31 - string.len(v7);
    return string.rep("0", v9) .. v7;
end;
local function u11(...) --[[ Line: 58 ]]
    -- upvalues: u4 (copy), u3 (ref), l__console__1 (copy), u2 (ref)
    for _, v10 in { ... } do
        table.insert(u4, v10);
    end;
    if u3 == nil then
        u3 = l__console__1.log;
        l__console__1.log = u2;
    end;
end;
local function u12() --[[ Line: 68 ]]
    -- upvalues: u4 (copy), u5 (ref), l__console__1 (copy), u3 (ref)
    table.remove(u4, 1);
    while u5 > #u4 do
        l__console__1.groupEnd();
        u5 = u5 - 1;
    end;
    if #u4 == 0 then
        l__console__1.log = u3;
        u3 = nil;
    end;
end;
u2 = function(...) --[[ Name: log, Line 80 ]]
    -- upvalues: u5 (ref), u4 (copy), l__console__1 (copy), u3 (ref)
    if u5 < #u4 then
        for v13 = u5 + 1, #u4 do
            l__console__1.group(u4[v13]);
        end;
        u5 = #u4;
    end;
    if typeof(u3) == "function" then
        u3(...);
    else
        l__console__1.log(...);
    end;
end;
function v1.logCommitStarted(p14) --[[ Line: 98 ]]
    -- upvalues: l__enableDebugTracing__2 (copy), u11 (copy)
    if _G.__DEV__ and l__enableDebugTracing__2 then
        u11(string.format("* commit (%s)", "0b" .. decimalToBinaryString(p14)), "", "", "");
    end;
end;
function v1.logCommitStopped() --[[ Line: 113 ]]
    -- upvalues: l__enableDebugTracing__2 (copy), u12 (copy)
    if _G.__DEV__ and l__enableDebugTracing__2 then
        u12();
    end;
end;
function v1.logComponentSuspended(u15, p16) --[[ Line: 141 ]]
    -- upvalues: l__enableDebugTracing__2 (copy), u2 (ref)
    if _G.__DEV__ and l__enableDebugTracing__2 then
        u2(string.format("* %s suspended", u15));
        p16:andThen(function() --[[ Line: 155 ]]
            -- upvalues: u2 (ref), u15 (copy)
            u2(string.format("* %s resolved", u15));
        end, function() --[[ Line: 164 ]]
            -- upvalues: u2 (ref), u15 (copy)
            u2(string.format("* %s rejected", u15));
        end);
    end;
end;
function v1.logLayoutEffectsStarted(p17) --[[ Line: 179 ]]
    -- upvalues: l__enableDebugTracing__2 (copy), u11 (copy)
    if _G.__DEV__ and l__enableDebugTracing__2 then
        u11(string.format("* layout effects (%s)", "0b" .. decimalToBinaryString(p17)));
    end;
end;
function v1.logLayoutEffectsStopped() --[[ Line: 194 ]]
    -- upvalues: l__enableDebugTracing__2 (copy), u12 (copy)
    if _G.__DEV__ and l__enableDebugTracing__2 then
        u12();
    end;
end;
function v1.logPassiveEffectsStarted(p18) --[[ Line: 203 ]]
    -- upvalues: l__enableDebugTracing__2 (copy), u11 (copy)
    if _G.__DEV__ and l__enableDebugTracing__2 then
        u11(string.format("* passive effects (%s)", "0b" .. decimalToBinaryString(p18)));
    end;
end;
function v1.logPassiveEffectsStopped() --[[ Line: 218 ]]
    -- upvalues: l__enableDebugTracing__2 (copy), u12 (copy)
    if _G.__DEV__ and l__enableDebugTracing__2 then
        u12();
    end;
end;
function v1.logRenderStarted(p19) --[[ Line: 227 ]]
    -- upvalues: l__enableDebugTracing__2 (copy), u11 (copy)
    if _G.__DEV__ and l__enableDebugTracing__2 then
        u11(string.format("* render (%s)", "0b" .. decimalToBinaryString(p19)));
    end;
end;
function v1.logRenderStopped() --[[ Line: 242 ]]
    -- upvalues: l__enableDebugTracing__2 (copy), u12 (copy)
    if _G.__DEV__ and l__enableDebugTracing__2 then
        u12();
    end;
end;
function v1.logForceUpdateScheduled(p20, p21) --[[ Line: 251 ]]
    -- upvalues: l__enableDebugTracing__2 (copy), u2 (ref)
    if _G.__DEV__ and l__enableDebugTracing__2 then
        u2(string.format("* %s forced update (%s)", p20, "0b" .. decimalToBinaryString(p21)));
    end;
end;
function v1.logStateUpdateScheduled(p22, p23, _) --[[ Line: 266 ]]
    -- upvalues: l__enableDebugTracing__2 (copy), u2 (ref)
    if _G.__DEV__ and l__enableDebugTracing__2 then
        u2(string.format("* %s updated state (%s)", p22, "0b" .. decimalToBinaryString(p23)));
    end;
end;
return v1;