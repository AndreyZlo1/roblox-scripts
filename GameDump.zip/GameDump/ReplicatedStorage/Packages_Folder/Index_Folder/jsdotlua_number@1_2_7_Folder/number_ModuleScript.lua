-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_number@1.2.7.number
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    NaN = (0 / 0),
    isFinite = require(script:WaitForChild("isFinite")),
    isInteger = require(script:WaitForChild("isInteger")),
    isNaN = require(script:WaitForChild("isNaN")),
    isSafeInteger = require(script:WaitForChild("isSafeInteger")),
    MAX_SAFE_INTEGER = require(script:WaitForChild("MAX_SAFE_INTEGER")),
    MIN_SAFE_INTEGER = require(script:WaitForChild("MIN_SAFE_INTEGER")),
    toExponential = require(script:WaitForChild("toExponential"))
};