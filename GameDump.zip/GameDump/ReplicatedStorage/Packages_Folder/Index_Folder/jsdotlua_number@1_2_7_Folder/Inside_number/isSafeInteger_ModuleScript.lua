-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_number@1.2.7.number.isSafeInteger
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__isInteger__1 = require(script.Parent:WaitForChild("isInteger"));
local l__MAX_SAFE_INTEGER__2 = require(script.Parent:WaitForChild("MAX_SAFE_INTEGER"));
return function(p1) --[[ Line: 5 ]]
    -- upvalues: l__isInteger__1 (copy), l__MAX_SAFE_INTEGER__2 (copy)
    local v2 = l__isInteger__1(p1);
    if v2 then
        v2 = math.abs(p1) <= l__MAX_SAFE_INTEGER__2;
    end;
    return v2;
end;