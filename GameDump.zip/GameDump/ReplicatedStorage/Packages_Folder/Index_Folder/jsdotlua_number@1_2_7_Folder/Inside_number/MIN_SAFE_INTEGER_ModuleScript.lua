-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_number@1.2.7.number.MIN_SAFE_INTEGER
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return -9007199254740991;