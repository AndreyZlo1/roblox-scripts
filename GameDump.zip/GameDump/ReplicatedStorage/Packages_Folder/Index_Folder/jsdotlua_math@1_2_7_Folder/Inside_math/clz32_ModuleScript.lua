-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_math@1.2.7.math.clz32
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return bit32.countlz;