-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_math@1.2.7.math
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    clz32 = require(script:WaitForChild("clz32"))
};