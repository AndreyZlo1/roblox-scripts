-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_luau-polyfill@1.2.7.luau-polyfill.encodeURIComponent
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__HttpService__1 = game:GetService("HttpService");
local l__charCodeAt__2 = require(script.Parent.Parent:WaitForChild("string")).charCodeAt;
local l__Error__3 = require(script.Parent:WaitForChild("Error"));
return function(p1) --[[ Name: encodeURIComponent, Line 8 ]]
    -- upvalues: l__charCodeAt__2 (copy), l__Error__3 (copy), l__HttpService__1 (copy)
    local v2 = utf8.len(p1);
    if v2 == 0 or v2 == nil then
        return "";
    end;
    local v3 = l__charCodeAt__2(p1, 1);
    if v2 == 1 then
        if v3 == 55296 then
            error(l__Error__3.new("URI malformed"));
        end;
        if v3 == 57343 then
            error(l__Error__3.new("URI malformed"));
        end;
    end;
    if v3 >= 56320 and v3 < 57343 then
        error(l__Error__3.new("URI malformed"));
    end;
    return l__HttpService__1:UrlEncode(p1):gsub("%%2D", "-"):gsub("%%5F", "_"):gsub("%%2E", "."):gsub("%%21", "!"):gsub("%%7E", "~"):gsub("%%2A", "*"):gsub("%%27", "\'"):gsub("%%28", "("):gsub("%%29", ")");
end;