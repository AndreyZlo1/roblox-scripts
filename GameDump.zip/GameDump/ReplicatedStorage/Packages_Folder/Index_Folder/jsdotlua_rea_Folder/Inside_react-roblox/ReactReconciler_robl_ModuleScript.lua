-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-roblox@17.1.0.react-roblox.ReactReconciler.roblox
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent.Parent:WaitForChild("react-reconciler"))((require(script.Parent:WaitForChild("client"):WaitForChild("ReactRobloxHostConfig"))));