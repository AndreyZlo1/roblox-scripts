-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberSuspenseContext.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent:WaitForChild("ReactInternalTypes"));
local v1 = require(script.Parent:WaitForChild("ReactFiberStack.new"));
local l__createCursor__1 = v1.createCursor;
local l__push__2 = v1.push;
local l__pop__3 = v1.pop;
local v2 = {
    InvisibleParentSuspenseContext = 1,
    ForceSuspenseFallback = 2
};
local u3 = l__createCursor__1(0);
v2.suspenseStackCursor = u3;
function v2.hasSuspenseContext(p4, p5) --[[ Line: 59 ]]
    return bit32.band(p4, p5) ~= 0;
end;
function v2.setDefaultShallowSuspenseContext(p6) --[[ Line: 66 ]]
    return bit32.band(p6, 1);
end;
function v2.setShallowSuspenseContext(p7, p8) --[[ Line: 72 ]]
    local v9 = bit32.band(p7, 1);
    return bit32.bor(v9, p8);
end;
function v2.addSubtreeSuspenseContext(p10, p11) --[[ Line: 82 ]]
    return bit32.bor(p10, p11);
end;
function v2.pushSuspenseContext(p12, p13) --[[ Line: 89 ]]
    -- upvalues: l__push__2 (copy), u3 (copy)
    l__push__2(u3, p13, p12);
end;
function v2.popSuspenseContext(p14) --[[ Line: 93 ]]
    -- upvalues: l__pop__3 (copy), u3 (copy)
    l__pop__3(u3, p14);
end;
return v2;