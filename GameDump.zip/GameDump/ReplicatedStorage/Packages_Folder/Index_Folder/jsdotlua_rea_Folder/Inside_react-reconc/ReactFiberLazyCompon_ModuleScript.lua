-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberLazyComponent.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    resolveDefaultProps = function(p1, p2) --[[ Name: resolveDefaultProps, Line 14 ]]
        if not p1 or (typeof(p1) ~= "table" or not p1.defaultProps) then
            return p2;
        end;
        local v3 = table.clone(p2);
        local l__defaultProps__1 = p1.defaultProps;
        for v4, _ in l__defaultProps__1 do
            if v3[v4] == nil then
                v3[v4] = l__defaultProps__1[v4];
            end;
        end;
        return v3;
    end
};