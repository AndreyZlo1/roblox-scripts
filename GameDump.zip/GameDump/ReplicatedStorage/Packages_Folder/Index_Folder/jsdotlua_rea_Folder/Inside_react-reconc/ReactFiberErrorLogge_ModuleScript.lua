-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberErrorLogger
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local l__inspect__1 = v1.util.inspect;
local l__setTimeout__2 = v1.setTimeout;
local l__shared__3 = require(script.Parent.Parent:WaitForChild("shared"));
local l__console__4 = l__shared__3.console;
local l__errorToString__5 = l__shared__3.errorToString;
require(script.Parent:WaitForChild("ReactInternalTypes"));
require(script.Parent:WaitForChild("ReactCapturedValue"));
local l__showErrorDialog__6 = require(script.Parent:WaitForChild("ReactFiberErrorDialog")).showErrorDialog;
local l__ClassComponent__7 = require(script.Parent:WaitForChild("ReactWorkTags")).ClassComponent;
local l__getComponentName__8 = require(script.Parent.Parent:WaitForChild("shared")).getComponentName;
return {
    logCapturedError = function(u2, u3) --[[ Line: 32 ]]
        -- upvalues: l__showErrorDialog__6 (copy), l__ClassComponent__7 (copy), l__console__4 (copy), l__getComponentName__8 (copy), l__inspect__1 (copy), l__setTimeout__2 (copy), l__errorToString__5 (copy)
        local v8, u9 = pcall(function() --[[ Line: 33 ]]
            -- upvalues: l__showErrorDialog__6 (ref), u2 (copy), u3 (copy), l__ClassComponent__7 (ref), l__console__4 (ref), l__getComponentName__8 (ref), l__inspect__1 (ref)
            if l__showErrorDialog__6(u2, u3) == false then
                return nil;
            end;
            local l__value__9 = u3.value;
            if _G.__DEV__ then
                local l__source__10 = u3.source;
                local v4 = u3.stack or "";
                if l__value__9 ~= nil and l__value__9._suppressLogging then
                    if u2.tag == l__ClassComponent__7 then
                        return;
                    end;
                    l__console__4.error(l__value__9);
                end;
                local v5;
                if l__source__10 == nil then
                    v5 = nil;
                else
                    v5 = l__getComponentName__8(l__source__10.type);
                end;
                local v6 = not v5 and "The above error occurred in one of your React components:" or "The above error occurred in the <" .. tostring(v5) .. "> component:";
                local v7 = l__getComponentName__8(u2.type);
                l__console__4.error(v6 .. "\n" .. v4 .. "\n\n" .. (not v7 and "Consider adding an error boundary to your tree to customize error handling behavior.\nVisit https://reactjs.org/link/error-boundaries to learn more about error boundaries." or "React will try to recreate this component tree from scratch " .. "using the error boundary you provided, " .. v7 .. "."));
            else
                l__console__4.error(l__inspect__1(l__value__9));
            end;
            return nil;
        end);
        if not v8 then
            warn("failed to error with error: " .. l__inspect__1(u9));
            l__setTimeout__2(function() --[[ Line: 124 ]]
                -- upvalues: l__errorToString__5 (ref), u9 (copy)
                error(l__errorToString__5(u9));
            end);
        end;
    end
};