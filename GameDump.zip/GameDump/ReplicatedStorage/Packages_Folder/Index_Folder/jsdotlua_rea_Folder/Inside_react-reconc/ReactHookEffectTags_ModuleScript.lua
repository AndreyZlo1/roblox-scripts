-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactHookEffectTags
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    NoFlags = 0,
    HasEffect = 1,
    Layout = 2,
    Passive = 4
};