-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberThrow.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Object__1 = require(script.Parent.Parent:WaitForChild("luau-polyfill")).Object;
local l__console__2 = require(script.Parent.Parent:WaitForChild("shared")).console;
require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__ReactFiberLane__3 = require(script.Parent:WaitForChild("ReactFiberLane"));
require(script.Parent:WaitForChild("ReactCapturedValue"));
local v1 = require(script.Parent:WaitForChild("ReactUpdateQueue.new"));
require(script.Parent.Parent:WaitForChild("shared"));
local v2 = require(script.Parent:WaitForChild("ReactFiberSuspenseContext.new"));
local l__getComponentName__4 = require(script.Parent.Parent:WaitForChild("shared")).getComponentName;
local l__ReactWorkTags__5 = require(script.Parent:WaitForChild("ReactWorkTags"));
local l__ClassComponent__6 = l__ReactWorkTags__5.ClassComponent;
local l__HostRoot__7 = l__ReactWorkTags__5.HostRoot;
local l__SuspenseComponent__8 = l__ReactWorkTags__5.SuspenseComponent;
local l__IncompleteClassComponent__9 = l__ReactWorkTags__5.IncompleteClassComponent;
local l__ReactFiberFlags__10 = require(script.Parent:WaitForChild("ReactFiberFlags"));
local l__DidCapture__11 = l__ReactFiberFlags__10.DidCapture;
local l__Incomplete__12 = l__ReactFiberFlags__10.Incomplete;
local l__NoFlags__13 = l__ReactFiberFlags__10.NoFlags;
local l__ShouldCapture__14 = l__ReactFiberFlags__10.ShouldCapture;
local l__LifecycleEffectMask__15 = l__ReactFiberFlags__10.LifecycleEffectMask;
local l__ForceUpdateForLegacySuspense__16 = l__ReactFiberFlags__10.ForceUpdateForLegacySuspense;
local l__shouldCaptureSuspense__17 = require(script.Parent:WaitForChild("ReactFiberSuspenseComponent.new")).shouldCaptureSuspense;
local l__ReactTypeOfMode__18 = require(script.Parent:WaitForChild("ReactTypeOfMode"));
local l__NoMode__19 = l__ReactTypeOfMode__18.NoMode;
local l__BlockingMode__20 = l__ReactTypeOfMode__18.BlockingMode;
local l__DebugTracingMode__21 = l__ReactTypeOfMode__18.DebugTracingMode;
local l__ReactFeatureFlags__22 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags;
local l__enableDebugTracing__23 = l__ReactFeatureFlags__22.enableDebugTracing;
local l__enableSchedulingProfiler__24 = l__ReactFeatureFlags__22.enableSchedulingProfiler;
local l__createCapturedValue__25 = require(script.Parent:WaitForChild("ReactCapturedValue")).createCapturedValue;
local l__enqueueCapturedUpdate__26 = v1.enqueueCapturedUpdate;
local l__createUpdate__27 = v1.createUpdate;
local l__CaptureUpdate__28 = v1.CaptureUpdate;
local l__ForceUpdate__29 = v1.ForceUpdate;
local l__enqueueUpdate__30 = v1.enqueueUpdate;
local l__markFailedErrorBoundaryForHotReloading__31 = require(script.Parent["ReactFiberHotReloading.new"]).markFailedErrorBoundaryForHotReloading;
local l__hasSuspenseContext__32 = v2.hasSuspenseContext;
local l__InvisibleParentSuspenseContext__33 = v2.InvisibleParentSuspenseContext;
local l__suspenseStackCursor__34 = v2.suspenseStackCursor;
local u3 = nil;
local u4 = nil;
local u5 = nil;
local u6 = nil;
local function u7(...) --[[ Line: 87 ]]
    -- upvalues: u4 (ref), u3 (ref)
    if not u4 then
        u3 = require(script.Parent:WaitForChild("ReactFiberWorkLoop.new"));
        u4 = u3.markLegacyErrorBoundaryAsFailed;
    end;
    return u4(...);
end;
local function u8(...) --[[ Line: 102 ]]
    -- upvalues: u3 (ref), u6 (ref)
    if u3 == nil then
        u3 = require(script.Parent:WaitForChild("ReactFiberWorkLoop.new"));
    end;
    u6 = u3.pingSuspendedRoot;
    return u6(...);
end;
local function u9(...) --[[ Line: 109 ]]
    -- upvalues: u3 (ref), u5 (ref)
    if u3 == nil then
        u3 = require(script.Parent:WaitForChild("ReactFiberWorkLoop.new"));
    end;
    u5 = u3.isAlreadyFailedLegacyErrorBoundary;
    return u5(...);
end;
local l__logCapturedError__35 = require(script.Parent:WaitForChild("ReactFiberErrorLogger")).logCapturedError;
local l__logComponentSuspended__36 = require(script.Parent:WaitForChild("DebugTracing")).logComponentSuspended;
local l__markComponentSuspended__37 = require(script.Parent:WaitForChild("SchedulingProfiler")).markComponentSuspended;
local l__SyncLane__38 = l__ReactFiberLane__3.SyncLane;
local l__NoTimestamp__39 = l__ReactFiberLane__3.NoTimestamp;
local l__includesSomeLane__40 = l__ReactFiberLane__3.includesSomeLane;
local l__mergeLanes__41 = l__ReactFiberLane__3.mergeLanes;
local l__pickArbitraryLane__42 = l__ReactFiberLane__3.pickArbitraryLane;
function createRootErrorUpdate(u10, u11, p12, u13)
    -- upvalues: l__createUpdate__27 (copy), l__NoTimestamp__39 (copy), l__CaptureUpdate__28 (copy), l__Object__1 (copy), l__logCapturedError__35 (copy)
    local v14 = l__createUpdate__27(l__NoTimestamp__39, p12);
    v14.tag = l__CaptureUpdate__28;
    v14.payload = {
        element = l__Object__1.None
    };
    local l__value__43 = u11.value;
    function v14.callback() --[[ Line: 144 ]]
        -- upvalues: u13 (copy), l__value__43 (copy), l__logCapturedError__35 (ref), u10 (copy), u11 (copy)
        if u13 ~= nil then
            u13(l__value__43);
        end;
        l__logCapturedError__35(u10, u11);
    end;
    return v14;
end;
function createClassErrorUpdate(u15, u16, p17)
    -- upvalues: l__createUpdate__27 (copy), l__NoTimestamp__39 (copy), l__CaptureUpdate__28 (copy), l__logCapturedError__35 (copy), l__markFailedErrorBoundaryForHotReloading__31 (copy), u7 (copy), l__includesSomeLane__40 (copy), l__SyncLane__38 (copy), l__console__2 (copy), l__getComponentName__4 (copy)
    local v18 = l__createUpdate__27(l__NoTimestamp__39, p17);
    v18.tag = l__CaptureUpdate__28;
    local l__getDerivedStateFromError__44 = u15.type.getDerivedStateFromError;
    if typeof(l__getDerivedStateFromError__44) == "function" then
        local l__value__45 = u16.value;
        function v18.payload() --[[ Line: 163 ]]
            -- upvalues: l__logCapturedError__35 (ref), u15 (copy), u16 (copy), l__getDerivedStateFromError__44 (copy), l__value__45 (copy)
            l__logCapturedError__35(u15, u16);
            return l__getDerivedStateFromError__44(l__value__45);
        end;
    end;
    local l__stateNode__46 = u15.stateNode;
    if l__stateNode__46 == nil or typeof(l__stateNode__46.componentDidCatch) ~= "function" then
        if _G.__DEV__ then
            function v18.callback() --[[ Line: 209 ]]
                -- upvalues: l__markFailedErrorBoundaryForHotReloading__31 (ref), u15 (copy)
                l__markFailedErrorBoundaryForHotReloading__31(u15);
            end;
        end;
        return v18;
    else
        function v18.callback() --[[ Line: 171 ]]
            -- upvalues: l__markFailedErrorBoundaryForHotReloading__31 (ref), u15 (copy), l__getDerivedStateFromError__44 (copy), u7 (ref), l__stateNode__46 (copy), l__logCapturedError__35 (ref), u16 (copy), l__includesSomeLane__40 (ref), l__SyncLane__38 (ref), l__console__2 (ref), l__getComponentName__4 (ref)
            if _G.__DEV__ then
                l__markFailedErrorBoundaryForHotReloading__31(u15);
            end;
            if typeof(l__getDerivedStateFromError__44) ~= "function" then
                u7(l__stateNode__46);
                l__logCapturedError__35(u15, u16);
            end;
            l__stateNode__46:componentDidCatch(u16.value, {
                componentStack = u16.stack or ""
            });
            if _G.__DEV__ and (typeof(l__getDerivedStateFromError__44) ~= "function" and not l__includesSomeLane__40(u15.lanes, l__SyncLane__38)) then
                l__console__2.error("%s: Error boundaries should implement getDerivedStateFromError(). In that method, return a state update to display an error message or fallback UI.", l__getComponentName__4(u15.type) or "Unknown");
            end;
        end;
        return v18;
    end;
end;
local function u24(u19, u20, u21) --[[ Line: 216 ]]
    -- upvalues: u8 (copy)
    local l__pingCache__47 = u19.pingCache;
    local v22;
    if l__pingCache__47 == nil then
        v22 = {};
        u19.pingCache = {
            [u20] = v22
        };
        local _ = u19.pingCache;
    else
        v22 = l__pingCache__47[u20];
        if v22 == nil then
            v22 = {};
            l__pingCache__47[u20] = v22;
        end;
    end;
    if not v22[u21] then
        v22[u21] = true;
        local function v23() --[[ Line: 244 ]]
            -- upvalues: u8 (ref), u19 (copy), u20 (copy), u21 (copy)
            return u8(u19, u20, u21);
        end;
        u20:andThen(v23, v23);
    end;
end;
function throwException(p25, p26, p27, p28, p29, p30, p31)
    -- upvalues: l__Incomplete__12 (copy), l__enableDebugTracing__23 (copy), l__DebugTracingMode__21 (copy), l__getComponentName__4 (copy), l__logComponentSuspended__36 (copy), l__enableSchedulingProfiler__24 (copy), l__markComponentSuspended__37 (copy), l__BlockingMode__20 (copy), l__NoMode__19 (copy), l__hasSuspenseContext__32 (copy), l__suspenseStackCursor__34 (copy), l__InvisibleParentSuspenseContext__33 (copy), l__SuspenseComponent__8 (copy), l__shouldCaptureSuspense__17 (copy), l__DidCapture__11 (copy), l__ForceUpdateForLegacySuspense__16 (copy), l__LifecycleEffectMask__15 (copy), l__ClassComponent__6 (copy), l__IncompleteClassComponent__9 (copy), l__createUpdate__27 (copy), l__NoTimestamp__39 (copy), l__SyncLane__38 (copy), l__ForceUpdate__29 (copy), l__enqueueUpdate__30 (copy), l__mergeLanes__41 (copy), u24 (copy), l__ShouldCapture__14 (copy), l__createCapturedValue__25 (copy), l__HostRoot__7 (copy), l__pickArbitraryLane__42 (copy), l__enqueueCapturedUpdate__26 (copy), l__NoFlags__13 (copy), u9 (copy)
    p27.flags = bit32.bor(p27.flags, l__Incomplete__12);
    local v32, v33, v34, v35, v36;
    if p28 == nil or (typeof(p28) ~= "table" or typeof(p28.andThen) ~= "function") then
        p31();
        v32 = l__createCapturedValue__25(p28, p27);
        while p26.tag ~= l__HostRoot__7 do
            if p26.tag == l__ClassComponent__6 then
                v33 = p26.type;
                v34 = p26.stateNode;
                if bit32.band(p26.flags, l__DidCapture__11) == l__NoFlags__13 and (typeof(v33.getDerivedStateFromError) == "function" or v34 ~= nil and (typeof(v34.componentDidCatch) == "function" and not u9(v34))) then
                    p26.flags = bit32.bor(p26.flags, l__ShouldCapture__14);
                    v35 = l__pickArbitraryLane__42(p29);
                    p26.lanes = l__mergeLanes__41(p26.lanes, v35);
                    l__enqueueCapturedUpdate__26(p26, (createClassErrorUpdate(p26, v32, v35)));
                    return;
                end;
            end;
            p26 = p26.return_;
            if p26 == nil then
                return;
            end;
        end;
        p26.flags = bit32.bor(p26.flags, l__ShouldCapture__14);
        v36 = l__pickArbitraryLane__42(p29);
        p26.lanes = l__mergeLanes__41(p26.lanes, v36);
        l__enqueueCapturedUpdate__26(p26, (createRootErrorUpdate(p26, v32, v36, p30)));
    else
        if _G.__DEV__ and (l__enableDebugTracing__23 and bit32.band(p27.mode, l__DebugTracingMode__21) ~= 0) then
            l__logComponentSuspended__36(l__getComponentName__4(p27.type) or "Unknown", p28);
        end;
        if l__enableSchedulingProfiler__24 then
            l__markComponentSuspended__37(p27, p28);
        end;
        if bit32.band(p27.mode, l__BlockingMode__20) == l__NoMode__19 then
            local l__alternate__48 = p27.alternate;
            if l__alternate__48 then
                p27.updateQueue = l__alternate__48.updateQueue;
                p27.memoizedState = l__alternate__48.memoizedState;
                p27.lanes = l__alternate__48.lanes;
            else
                p27.updateQueue = nil;
                p27.memoizedState = nil;
            end;
        end;
        local v37 = l__hasSuspenseContext__32(l__suspenseStackCursor__34.current, l__InvisibleParentSuspenseContext__33);
        local v38 = p26;
        while true do
            if v38.tag == l__SuspenseComponent__8 and l__shouldCaptureSuspense__17(v38, v37) then
                local l__updateQueue__49 = v38.updateQueue;
                if l__updateQueue__49 == nil then
                    v38.updateQueue = {
                        [p28] = true
                    };
                else
                    l__updateQueue__49[p28] = true;
                end;
                if bit32.band(v38.mode, l__BlockingMode__20) == l__NoMode__19 then
                    v38.flags = bit32.bor(v38.flags, l__DidCapture__11);
                    p27.flags = bit32.bor(p27.flags, l__ForceUpdateForLegacySuspense__16);
                    local l__flags__50 = p27.flags;
                    local v39 = bit32.bor(l__LifecycleEffectMask__15, l__Incomplete__12);
                    local v40 = bit32.bnot(v39);
                    p27.flags = bit32.band(l__flags__50, v40);
                    if p27.tag == l__ClassComponent__6 then
                        if p27.alternate == nil then
                            p27.tag = l__IncompleteClassComponent__9;
                        else
                            local v41 = l__createUpdate__27(l__NoTimestamp__39, l__SyncLane__38);
                            v41.tag = l__ForceUpdate__29;
                            l__enqueueUpdate__30(p27, v41);
                        end;
                    end;
                    p27.lanes = l__mergeLanes__41(p27.lanes, l__SyncLane__38);
                    return;
                else
                    u24(p25, p28, p29);
                    v38.flags = bit32.bor(v38.flags, l__ShouldCapture__14);
                    v38.lanes = p29;
                    return;
                end;
            end;
            v38 = v38.return_;
            if v38 == nil then
                p28 = (l__getComponentName__4(p27.type) or "A React component") .. " suspended while rendering, but no fallback UI was specified.\n\nAdd a <Suspense fallback=...> component higher in the tree to provide a loading indicator or placeholder to display.";
                p31();
                v32 = l__createCapturedValue__25(p28, p27);
                while p26.tag ~= l__HostRoot__7 do
                    if p26.tag == l__ClassComponent__6 then
                        v33 = p26.type;
                        v34 = p26.stateNode;
                        if bit32.band(p26.flags, l__DidCapture__11) == l__NoFlags__13 and (typeof(v33.getDerivedStateFromError) == "function" or v34 ~= nil and (typeof(v34.componentDidCatch) == "function" and not u9(v34))) then
                            p26.flags = bit32.bor(p26.flags, l__ShouldCapture__14);
                            v35 = l__pickArbitraryLane__42(p29);
                            p26.lanes = l__mergeLanes__41(p26.lanes, v35);
                            l__enqueueCapturedUpdate__26(p26, (createClassErrorUpdate(p26, v32, v35)));
                            return;
                        end;
                    end;
                    p26 = p26.return_;
                    if p26 == nil then
                        return;
                    end;
                end;
                p26.flags = bit32.bor(p26.flags, l__ShouldCapture__14);
                v36 = l__pickArbitraryLane__42(p29);
                p26.lanes = l__mergeLanes__41(p26.lanes, v36);
                l__enqueueCapturedUpdate__26(p26, (createRootErrorUpdate(p26, v32, v36, p30)));
                return;
            end;
        end;
    end;
end;
return {
    throwException = throwException,
    createRootErrorUpdate = createRootErrorUpdate,
    createClassErrorUpdate = createClassErrorUpdate
};