-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactMutableSource.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__console__1 = require(script.Parent.Parent:WaitForChild("shared")).console;
local v1 = {};
require(script.Parent.Parent:WaitForChild("shared"));
require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__isPrimaryRenderer__2 = require(script.Parent:WaitForChild("ReactFiberHostConfig")).isPrimaryRenderer;
local u2 = {};
local u3 = _G.__DEV__ and {} or nil;
function v1.markSourceAsDirty(p4) --[[ Line: 37 ]]
    -- upvalues: u2 (copy)
    table.insert(u2, p4);
end;
function v1.resetWorkInProgressVersions() --[[ Line: 41 ]]
    -- upvalues: u2 (copy), l__isPrimaryRenderer__2 (copy)
    for _, v5 in u2 do
        if l__isPrimaryRenderer__2 then
            v5._workInProgressVersionPrimary = nil;
        else
            v5._workInProgressVersionSecondary = nil;
        end;
    end;
    table.clear(u2);
end;
function v1.getWorkInProgressVersion(p6) --[[ Line: 53 ]]
    -- upvalues: l__isPrimaryRenderer__2 (copy)
    if l__isPrimaryRenderer__2 then
        return p6._workInProgressVersionPrimary;
    else
        return p6._workInProgressVersionSecondary;
    end;
end;
function v1.setWorkInProgressVersion(p7, p8) --[[ Line: 62 ]]
    -- upvalues: l__isPrimaryRenderer__2 (copy), u2 (copy)
    if l__isPrimaryRenderer__2 then
        p7._workInProgressVersionPrimary = p8;
    else
        p7._workInProgressVersionSecondary = p8;
    end;
    table.insert(u2, p7);
end;
function v1.warnAboutMultipleRenderersDEV(p9) --[[ Line: 71 ]]
    -- upvalues: l__isPrimaryRenderer__2 (copy), u3 (ref), l__console__1 (copy)
    if _G.__DEV__ then
        if l__isPrimaryRenderer__2 then
            if p9._currentPrimaryRenderer == nil then
                p9._currentPrimaryRenderer = u3;
                return;
            end;
            if p9._currentPrimaryRenderer ~= u3 then
                l__console__1.error("Detected multiple renderers concurrently rendering the same mutable source. This is currently unsupported.");
            end;
        else
            if p9._currentSecondaryRenderer == nil then
                p9._currentSecondaryRenderer = u3;
                return;
            end;
            if p9._currentSecondaryRenderer ~= u3 then
                l__console__1.error("Detected multiple renderers concurrently rendering the same mutable source. This is currently unsupported.");
            end;
        end;
    end;
end;
function v1.registerMutableSourceForHydration(p10, p11) --[[ Line: 100 ]]
    local v12 = p11._getVersion(p11._source);
    if p10.mutableSourceEagerHydrationData == nil then
        p10.mutableSourceEagerHydrationData = { p11, v12 };
    end;
end;
return v1;