-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiber.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
local v1 = require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local l__Object__2 = v1.Object;
local l__Array__3 = v1.Array;
local l__inspect__4 = v1.util.inspect;
local l__console__5 = require(script.Parent.Parent:WaitForChild("shared")).console;
require(script.Parent.Parent:WaitForChild("shared"));
require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__ReactRootTags__6 = require(script.Parent:WaitForChild("ReactRootTags"));
local l__ReactWorkTags__7 = require(script.Parent:WaitForChild("ReactWorkTags"));
local l__ReactTypeOfMode__8 = require(script.Parent:WaitForChild("ReactTypeOfMode"));
local l__ReactFiberLane__9 = require(script.Parent:WaitForChild("ReactFiberLane"));
require(script.Parent:WaitForChild("ReactFiberHostConfig"));
require(script.Parent:WaitForChild("ReactFiberOffscreenComponent"));
local l__invariant__10 = require(script.Parent.Parent:WaitForChild("shared")).invariant;
local l__enableProfilerTimer__11 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags.enableProfilerTimer;
local l__ReactFiberFlags__12 = require(script.Parent:WaitForChild("ReactFiberFlags"));
local l__NoFlags__13 = l__ReactFiberFlags__12.NoFlags;
local l__Placement__14 = l__ReactFiberFlags__12.Placement;
local l__StaticMask__15 = l__ReactFiberFlags__12.StaticMask;
local l__ConcurrentRoot__16 = l__ReactRootTags__6.ConcurrentRoot;
local l__BlockingRoot__17 = l__ReactRootTags__6.BlockingRoot;
local l__IndeterminateComponent__18 = l__ReactWorkTags__7.IndeterminateComponent;
local l__ClassComponent__19 = l__ReactWorkTags__7.ClassComponent;
local l__HostRoot__20 = l__ReactWorkTags__7.HostRoot;
local l__HostComponent__21 = l__ReactWorkTags__7.HostComponent;
local l__HostText__22 = l__ReactWorkTags__7.HostText;
local l__HostPortal__23 = l__ReactWorkTags__7.HostPortal;
local l__ForwardRef__24 = l__ReactWorkTags__7.ForwardRef;
local l__Fragment__25 = l__ReactWorkTags__7.Fragment;
local l__Mode__26 = l__ReactWorkTags__7.Mode;
local l__ContextProvider__27 = l__ReactWorkTags__7.ContextProvider;
local l__ContextConsumer__28 = l__ReactWorkTags__7.ContextConsumer;
local l__Profiler__29 = l__ReactWorkTags__7.Profiler;
local l__SuspenseComponent__30 = l__ReactWorkTags__7.SuspenseComponent;
local l__SuspenseListComponent__31 = l__ReactWorkTags__7.SuspenseListComponent;
local l__DehydratedFragment__32 = l__ReactWorkTags__7.DehydratedFragment;
local l__FunctionComponent__33 = l__ReactWorkTags__7.FunctionComponent;
local l__MemoComponent__34 = l__ReactWorkTags__7.MemoComponent;
local l__SimpleMemoComponent__35 = l__ReactWorkTags__7.SimpleMemoComponent;
local l__LazyComponent__36 = l__ReactWorkTags__7.LazyComponent;
local l__FundamentalComponent__37 = l__ReactWorkTags__7.FundamentalComponent;
local _ = l__ReactWorkTags__7.ScopeComponent;
local l__OffscreenComponent__38 = l__ReactWorkTags__7.OffscreenComponent;
local l__LegacyHiddenComponent__39 = l__ReactWorkTags__7.LegacyHiddenComponent;
local l__getComponentName__40 = require(script.Parent.Parent:WaitForChild("shared")).getComponentName;
local l__isDevToolsPresent__41 = require(script.Parent:WaitForChild("ReactFiberDevToolsHook.new")).isDevToolsPresent;
local v2 = require(script.Parent:WaitForChild("ReactFiberHotReloading.new"));
local l__resolveClassForHotReloading__42 = v2.resolveClassForHotReloading;
local l__resolveFunctionForHotReloading__43 = v2.resolveFunctionForHotReloading;
local l__resolveForwardRefForHotReloading__44 = v2.resolveForwardRefForHotReloading;
local l__NoLanes__45 = l__ReactFiberLane__9.NoLanes;
local l__NoMode__46 = l__ReactTypeOfMode__8.NoMode;
local l__ConcurrentMode__47 = l__ReactTypeOfMode__8.ConcurrentMode;
local l__DebugTracingMode__48 = l__ReactTypeOfMode__8.DebugTracingMode;
local l__ProfileMode__49 = l__ReactTypeOfMode__8.ProfileMode;
local l__StrictMode__50 = l__ReactTypeOfMode__8.StrictMode;
local l__BlockingMode__51 = l__ReactTypeOfMode__8.BlockingMode;
local l__ReactSymbols__52 = require(script.Parent.Parent:WaitForChild("shared")).ReactSymbols;
local l__REACT_FORWARD_REF_TYPE__53 = l__ReactSymbols__52.REACT_FORWARD_REF_TYPE;
local l__REACT_FRAGMENT_TYPE__54 = l__ReactSymbols__52.REACT_FRAGMENT_TYPE;
local l__REACT_ELEMENT_TYPE__55 = l__ReactSymbols__52.REACT_ELEMENT_TYPE;
local l__REACT_DEBUG_TRACING_MODE_TYPE__56 = l__ReactSymbols__52.REACT_DEBUG_TRACING_MODE_TYPE;
local l__REACT_STRICT_MODE_TYPE__57 = l__ReactSymbols__52.REACT_STRICT_MODE_TYPE;
local l__REACT_PROFILER_TYPE__58 = l__ReactSymbols__52.REACT_PROFILER_TYPE;
local l__REACT_PROVIDER_TYPE__59 = l__ReactSymbols__52.REACT_PROVIDER_TYPE;
local l__REACT_CONTEXT_TYPE__60 = l__ReactSymbols__52.REACT_CONTEXT_TYPE;
local l__REACT_SUSPENSE_TYPE__61 = l__ReactSymbols__52.REACT_SUSPENSE_TYPE;
local l__REACT_SUSPENSE_LIST_TYPE__62 = l__ReactSymbols__52.REACT_SUSPENSE_LIST_TYPE;
local l__REACT_MEMO_TYPE__63 = l__ReactSymbols__52.REACT_MEMO_TYPE;
local l__REACT_LAZY_TYPE__64 = l__ReactSymbols__52.REACT_LAZY_TYPE;
local l__REACT_OFFSCREEN_TYPE__65 = l__ReactSymbols__52.REACT_OFFSCREEN_TYPE;
local l__REACT_LEGACY_HIDDEN_TYPE__66 = l__ReactSymbols__52.REACT_LEGACY_HIDDEN_TYPE;
local u3 = nil;
local u4 = nil;
local u5 = nil;
local u6 = nil;
local u7 = nil;
local u8 = 1;
local function u18(p9, p10, p11, p12, p13, p14, p15, p16) --[[ Line: 164 ]]
    -- upvalues: l__NoFlags__13 (copy), l__NoLanes__45 (copy), l__enableProfilerTimer__11 (copy), l____DEV____1 (copy), u8 (ref)
    local v17 = {
        index = 1,
        tag = p9,
        key = p11,
        elementType = p13,
        type = p14,
        stateNode = p15,
        pendingProps = p10,
        mode = p12,
        flags = l__NoFlags__13,
        subtreeFlags = l__NoFlags__13,
        lanes = p16 or l__NoLanes__45,
        childLanes = l__NoLanes__45
    };
    if l__enableProfilerTimer__11 then
        v17.actualDuration = 0;
        v17.actualStartTime = -1;
        v17.selfBaseDuration = 0;
        v17.treeBaseDuration = 0;
    end;
    if l____DEV____1 then
        v17._debugID = u8;
        u8 = u8 + 1;
        v17._debugSource = nil;
        v17._debugOwner = nil;
        v17._debugNeedsRemount = false;
        v17._debugHookTypes = nil;
    end;
    return v17;
end;
function _shouldConstruct(p19)
    local v20;
    if type(p19) == "function" then
        v20 = false;
    else
        v20 = p19.isReactComponent and true or false;
    end;
    return v20;
end;
local function u35(p21, p22, p23, p24, p25, p26) --[[ Line: 502 ]]
    -- upvalues: l__IndeterminateComponent__18 (copy), l____DEV____1 (copy), l__resolveFunctionForHotReloading__43 (copy), l__ClassComponent__19 (copy), l__resolveClassForHotReloading__42 (copy), l__HostComponent__21 (copy), l__REACT_FRAGMENT_TYPE__54 (copy), u4 (ref), l__REACT_DEBUG_TRACING_MODE_TYPE__56 (copy), l__Mode__26 (copy), l__DebugTracingMode__48 (copy), l__REACT_STRICT_MODE_TYPE__57 (copy), l__StrictMode__50 (copy), l__REACT_PROFILER_TYPE__58 (copy), u3 (ref), l__REACT_SUSPENSE_TYPE__61 (copy), u5 (ref), l__REACT_OFFSCREEN_TYPE__65 (copy), u6 (ref), l__REACT_LEGACY_HIDDEN_TYPE__66 (copy), u7 (ref), l__REACT_PROVIDER_TYPE__59 (copy), l__ContextProvider__27 (copy), l__REACT_CONTEXT_TYPE__60 (copy), l__ContextConsumer__28 (copy), l__REACT_FORWARD_REF_TYPE__53 (copy), l__ForwardRef__24 (copy), l__resolveForwardRefForHotReloading__44 (copy), l__REACT_MEMO_TYPE__63 (copy), l__MemoComponent__34 (copy), l__REACT_LAZY_TYPE__64 (copy), l__LazyComponent__36 (copy), l__Object__2 (copy), l__inspect__4 (copy), l__getComponentName__40 (copy), l__Array__3 (copy), l__REACT_ELEMENT_TYPE__55 (copy), l__invariant__10 (copy), u18 (copy)
    local v27 = l__IndeterminateComponent__18;
    local v28 = type(p21);
    local v29;
    if v28 == "function" then
        if l____DEV____1 then
            v29 = l__resolveFunctionForHotReloading__43(p21);
        else
            v29 = p21;
        end;
    elseif v28 == "table" and p21.isReactComponent then
        v27 = l__ClassComponent__19;
        if l____DEV____1 then
            v29 = l__resolveClassForHotReloading__42(p21);
        else
            v29 = p21;
        end;
    elseif v28 == "string" then
        v27 = l__HostComponent__21;
        v29 = p21;
    else
        if p21 == l__REACT_FRAGMENT_TYPE__54 then
            return u4(p23.children, p25, p26, p22);
        end;
        if p21 == l__REACT_DEBUG_TRACING_MODE_TYPE__56 then
            v27 = l__Mode__26;
            p25 = bit32.bor(p25, l__DebugTracingMode__48);
            v29 = p21;
        elseif p21 == l__REACT_STRICT_MODE_TYPE__57 then
            v27 = l__Mode__26;
            p25 = bit32.bor(p25, l__StrictMode__50);
            v29 = p21;
        else
            if p21 == l__REACT_PROFILER_TYPE__58 then
                return u3(p23, p25, p26, p22);
            end;
            if p21 == l__REACT_SUSPENSE_TYPE__61 then
                return u5(p23, p25, p26, p22);
            end;
            if p21 == l__REACT_OFFSCREEN_TYPE__65 then
                return u6(p23, p25, p26, p22);
            end;
            if p21 == l__REACT_LEGACY_HIDDEN_TYPE__66 then
                return u7(p23, p25, p26, p22);
            end;
            local v30 = false;
            local v31;
            if v28 == "table" then
                v31 = p21["$$typeof"];
                if v31 == l__REACT_PROVIDER_TYPE__59 then
                    v27 = l__ContextProvider__27;
                    v29 = p21;
                    v30 = true;
                elseif v31 == l__REACT_CONTEXT_TYPE__60 then
                    v27 = l__ContextConsumer__28;
                    v29 = p21;
                    v30 = true;
                elseif v31 == l__REACT_FORWARD_REF_TYPE__53 then
                    v27 = l__ForwardRef__24;
                    if l____DEV____1 then
                        v29 = l__resolveForwardRefForHotReloading__44(p21);
                    else
                        v29 = p21;
                    end;
                    v30 = true;
                elseif v31 == l__REACT_MEMO_TYPE__63 then
                    v27 = l__MemoComponent__34;
                    v29 = p21;
                    v30 = true;
                elseif v31 == l__REACT_LAZY_TYPE__64 then
                    v27 = l__LazyComponent__36;
                    v30 = true;
                    v29 = nil;
                else
                    v29 = p21;
                end;
            else
                v29 = p21;
                v31 = nil;
            end;
            if not v30 then
                local v32 = "";
                if l____DEV____1 then
                    if p21 == nil or v28 == "table" and #l__Object__2.keys(p21) == 0 then
                        v32 = v32 .. " You likely forgot to export your component from the file it\'s defined in, or you might have mixed up default and named imports.";
                    elseif p21 ~= nil and v28 == "table" then
                        v32 = v32 .. "\n" .. l__inspect__4(p21);
                    end;
                    local v33;
                    if p24 then
                        v33 = l__getComponentName__40(p24.type);
                    else
                        v33 = nil;
                    end;
                    if v33 == nil or v33 == "" then
                        if p24 then
                            v32 = v32 .. "\n" .. l__inspect__4(p24);
                        end;
                    else
                        v32 = v32 .. "\n\nCheck the render method of `" .. v33 .. "`.";
                    end;
                end;
                if p21 == nil then
                    v28 = "nil";
                elseif l__Array__3.isArray(p21) then
                    v28 = "array";
                elseif v28 == "table" and v31 == l__REACT_ELEMENT_TYPE__55 then
                    v28 = string.format("<%s />", l__getComponentName__40(p21.type) or "Unknown");
                    v32 = " Did you accidentally export a JSX literal or Element instead of a component?";
                end;
                l__invariant__10(false, "Element type is invalid: expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", v28, v32);
            end;
        end;
    end;
    local v34 = u18(v27, p23, p22, p25, p21, v29, nil, p26);
    if l____DEV____1 then
        v34._debugOwner = p24;
    end;
    return v34;
end;
u4 = function(p36, p37, p38, p39) --[[ Name: createFiberFromFragment, Line 684 ]]
    -- upvalues: u18 (copy), l__Fragment__25 (copy)
    return u18(l__Fragment__25, p36, p39, p37, nil, nil, nil, p38);
end;
u3 = function(p40, p41, p42, p43) --[[ Name: createFiberFromProfiler, Line 739 ]]
    -- upvalues: l____DEV____1 (copy), l__console__5 (copy), u18 (copy), l__Profiler__29 (copy), l__ProfileMode__49 (copy), l__REACT_PROFILER_TYPE__58 (copy), l__enableProfilerTimer__11 (copy)
    if l____DEV____1 and typeof(p40.id) ~= "string" then
        l__console__5.error("Profiler must specify an \"id\" as a prop");
    end;
    return u18(l__Profiler__29, p40, p43, bit32.bor(p41, l__ProfileMode__49), l__REACT_PROFILER_TYPE__58, l__REACT_PROFILER_TYPE__58, l__enableProfilerTimer__11 and {
        effectDuration = 0,
        passiveEffectDuration = 0
    } or nil, p42);
end;
u5 = function(p44, p45, p46, p47) --[[ Name: createFiberFromSuspense, Line 783 ]]
    -- upvalues: u18 (copy), l__SuspenseComponent__30 (copy), l__REACT_SUSPENSE_TYPE__61 (copy)
    return u18(l__SuspenseComponent__30, p44, p47, p45, l__REACT_SUSPENSE_TYPE__61, l__REACT_SUSPENSE_TYPE__61, nil, p46);
end;
u6 = function(p48, p49, p50, p51) --[[ Name: createFiberFromOffscreen, Line 841 ]]
    -- upvalues: u18 (copy), l__OffscreenComponent__38 (copy), l__REACT_OFFSCREEN_TYPE__65 (copy), l____DEV____1 (copy)
    local v52 = u18;
    local v53 = l__OffscreenComponent__38;
    local v54 = l__REACT_OFFSCREEN_TYPE__65;
    local v55;
    if l____DEV____1 then
        v55 = l__REACT_OFFSCREEN_TYPE__65;
    else
        v55 = nil;
    end;
    return v52(v53, p48, p51, p49, v54, v55, nil, p50);
end;
u7 = function(p56, p57, p58, p59) --[[ Name: createFiberFromLegacyHidden, Line 870 ]]
    -- upvalues: u18 (copy), l__LegacyHiddenComponent__39 (copy), l__REACT_LEGACY_HIDDEN_TYPE__66 (copy), l____DEV____1 (copy)
    local v60 = u18;
    local v61 = l__LegacyHiddenComponent__39;
    local v62 = l__REACT_LEGACY_HIDDEN_TYPE__66;
    local v63;
    if l____DEV____1 then
        v63 = l__REACT_LEGACY_HIDDEN_TYPE__66;
    else
        v63 = nil;
    end;
    return v60(v61, p56, p59, p57, v62, v63, nil, p58);
end;
return {
    isSimpleFunctionComponent = function(p64) --[[ Name: isSimpleFunctionComponent, Line 271 ]]
        return type(p64) == "function";
    end,
    resolveLazyComponentTag = function(p65) --[[ Name: resolveLazyComponentTag, Line 279 ]]
        -- upvalues: l__FunctionComponent__33 (copy), l__ClassComponent__19 (copy), l__REACT_FORWARD_REF_TYPE__53 (copy), l__ForwardRef__24 (copy), l__REACT_MEMO_TYPE__63 (copy), l__MemoComponent__34 (copy), l__IndeterminateComponent__18 (copy)
        local v66 = typeof(p65);
        if v66 == "function" then
            return l__FunctionComponent__33;
        end;
        if v66 == "table" then
            if p65.isReactComponent then
                return l__ClassComponent__19;
            end;
            local v67 = p65["$$typeof"];
            if v67 == l__REACT_FORWARD_REF_TYPE__53 then
                return l__ForwardRef__24;
            end;
            if v67 == l__REACT_MEMO_TYPE__63 then
                return l__MemoComponent__34;
            end;
        end;
        return l__IndeterminateComponent__18;
    end,
    createWorkInProgress = function(p68, p69) --[[ Name: createWorkInProgress, Line 302 ]]
        -- upvalues: u18 (copy), l____DEV____1 (copy), l__NoFlags__13 (copy), l__enableProfilerTimer__11 (copy), l__StaticMask__15 (copy), l__IndeterminateComponent__18 (copy), l__FunctionComponent__33 (copy), l__SimpleMemoComponent__35 (copy), l__resolveFunctionForHotReloading__43 (copy), l__ClassComponent__19 (copy), l__resolveClassForHotReloading__42 (copy), l__ForwardRef__24 (copy), l__resolveForwardRefForHotReloading__44 (copy)
        local l__alternate__67 = p68.alternate;
        if l__alternate__67 == nil then
            l__alternate__67 = u18(p68.tag, p69, p68.key, p68.mode, p68.elementType, p68.type, p68.stateNode);
            if l____DEV____1 then
                l__alternate__67._debugID = p68._debugID;
                l__alternate__67._debugSource = p68._debugSource;
                l__alternate__67._debugOwner = p68._debugOwner;
                l__alternate__67._debugHookTypes = p68._debugHookTypes;
            end;
            l__alternate__67.alternate = p68;
            p68.alternate = l__alternate__67;
        else
            l__alternate__67.pendingProps = p69;
            l__alternate__67.type = p68.type;
            l__alternate__67.flags = l__NoFlags__13;
            l__alternate__67.subtreeFlags = l__NoFlags__13;
            l__alternate__67.deletions = nil;
            if l__enableProfilerTimer__11 then
                l__alternate__67.actualDuration = 0;
                l__alternate__67.actualStartTime = -1;
            end;
        end;
        l__alternate__67.flags = bit32.band(p68.flags, l__StaticMask__15);
        l__alternate__67.childLanes = p68.childLanes;
        l__alternate__67.lanes = p68.lanes;
        l__alternate__67.child = p68.child;
        l__alternate__67.memoizedProps = p68.memoizedProps;
        l__alternate__67.memoizedState = p68.memoizedState;
        l__alternate__67.updateQueue = p68.updateQueue;
        local l__dependencies__68 = p68.dependencies;
        if l__dependencies__68 == nil then
            l__alternate__67.dependencies = nil;
        else
            l__alternate__67.dependencies = {
                lanes = l__dependencies__68.lanes,
                firstContext = l__dependencies__68.firstContext
            };
        end;
        l__alternate__67.sibling = p68.sibling;
        l__alternate__67.index = p68.index;
        l__alternate__67.ref = p68.ref;
        if l__enableProfilerTimer__11 then
            l__alternate__67.selfBaseDuration = p68.selfBaseDuration;
            l__alternate__67.treeBaseDuration = p68.treeBaseDuration;
        end;
        if l____DEV____1 then
            l__alternate__67._debugNeedsRemount = p68._debugNeedsRemount;
            if l__alternate__67.tag == l__IndeterminateComponent__18 or (l__alternate__67.tag == l__FunctionComponent__33 or l__alternate__67.tag == l__SimpleMemoComponent__35) then
                l__alternate__67.type = l__resolveFunctionForHotReloading__43(p68.type);
                return l__alternate__67;
            end;
            if l__alternate__67.tag == l__ClassComponent__19 then
                l__alternate__67.type = l__resolveClassForHotReloading__42(p68.type);
                return l__alternate__67;
            end;
            if l__alternate__67.tag == l__ForwardRef__24 then
                l__alternate__67.type = l__resolveForwardRefForHotReloading__44(p68.type);
            end;
        end;
        return l__alternate__67;
    end,
    resetWorkInProgress = function(p70, p71) --[[ Name: resetWorkInProgress, Line 406 ]]
        -- upvalues: l__StaticMask__15 (copy), l__Placement__14 (copy), l__NoLanes__45 (copy), l__NoFlags__13 (copy), l__enableProfilerTimer__11 (copy)
        local l__flags__69 = p70.flags;
        local v72 = bit32.bor(l__StaticMask__15, l__Placement__14);
        p70.flags = bit32.band(l__flags__69, v72);
        local l__alternate__70 = p70.alternate;
        if l__alternate__70 == nil then
            p70.childLanes = l__NoLanes__45;
            p70.lanes = p71;
            p70.child = nil;
            p70.subtreeFlags = l__NoFlags__13;
            p70.memoizedProps = nil;
            p70.memoizedState = nil;
            p70.updateQueue = nil;
            p70.dependencies = nil;
            p70.stateNode = nil;
            if l__enableProfilerTimer__11 then
                p70.selfBaseDuration = 0;
                p70.treeBaseDuration = 0;
                return p70;
            end;
        else
            p70.childLanes = l__alternate__70.childLanes;
            p70.lanes = l__alternate__70.lanes;
            p70.child = l__alternate__70.child;
            p70.subtreeFlags = l__alternate__70.subtreeFlags;
            p70.deletions = nil;
            p70.memoizedProps = l__alternate__70.memoizedProps;
            p70.memoizedState = l__alternate__70.memoizedState;
            p70.updateQueue = l__alternate__70.updateQueue;
            p70.type = l__alternate__70.type;
            local l__dependencies__71 = l__alternate__70.dependencies;
            if l__dependencies__71 == nil then
                p70.dependencies = nil;
            else
                p70.dependencies = {
                    lanes = l__dependencies__71.lanes,
                    firstContext = l__dependencies__71.firstContext
                };
            end;
            if l__enableProfilerTimer__11 then
                p70.selfBaseDuration = l__alternate__70.selfBaseDuration;
                p70.treeBaseDuration = l__alternate__70.treeBaseDuration;
            end;
        end;
        return p70;
    end,
    createHostRootFiber = function(p73) --[[ Name: createHostRootFiber, Line 481 ]]
        -- upvalues: l__ConcurrentRoot__16 (copy), l__ConcurrentMode__47 (copy), l__BlockingMode__51 (copy), l__StrictMode__50 (copy), l__BlockingRoot__17 (copy), l__NoMode__46 (copy), l__enableProfilerTimer__11 (copy), l__isDevToolsPresent__41 (copy), l__ProfileMode__49 (copy), u18 (copy), l__HostRoot__20 (copy)
        local v74;
        if p73 == l__ConcurrentRoot__16 then
            v74 = bit32.bor(l__ConcurrentMode__47, l__BlockingMode__51, l__StrictMode__50);
        elseif p73 == l__BlockingRoot__17 then
            v74 = bit32.bor(l__BlockingMode__51, l__StrictMode__50);
        else
            v74 = l__NoMode__46;
        end;
        if l__enableProfilerTimer__11 and l__isDevToolsPresent__41() then
            v74 = bit32.bor(v74, l__ProfileMode__49);
        end;
        return u18(l__HostRoot__20, nil, nil, v74);
    end,
    createFiberFromTypeAndProps = u35,
    createFiberFromElement = function(p75, p76, p77) --[[ Name: createFiberFromElement, Line 656 ]]
        -- upvalues: l____DEV____1 (copy), u35 (copy)
        local v78;
        if l____DEV____1 then
            v78 = p75._owner;
        else
            v78 = nil;
        end;
        local v79 = u35(p75.type, p75.key, p75.props, v78, p76, p77);
        if l____DEV____1 then
            v79._debugSource = p75._source;
            v79._debugOwner = p75._owner;
        end;
        return v79;
    end,
    createFiberFromFragment = u4,
    createFiberFromFundamental = function(p80, p81, p82, p83, p84) --[[ Name: createFiberFromFundamental, Line 697 ]]
        -- upvalues: u18 (copy), l__FundamentalComponent__37 (copy)
        return u18(l__FundamentalComponent__37, p81, p84, p82, p80, p80, nil, p83);
    end,
    createFiberFromSuspense = u5,
    createFiberFromSuspenseList = function(p85, p86, p87, p88) --[[ Name: createFiberFromSuspenseList, Line 812 ]]
        -- upvalues: u18 (copy), l__SuspenseListComponent__31 (copy), l__REACT_SUSPENSE_LIST_TYPE__62 (copy), l____DEV____1 (copy)
        local v89 = u18;
        local v90 = l__SuspenseListComponent__31;
        local v91 = l__REACT_SUSPENSE_LIST_TYPE__62;
        local v92;
        if l____DEV____1 then
            v92 = l__REACT_SUSPENSE_LIST_TYPE__62;
        else
            v92 = nil;
        end;
        return v89(v90, p85, p88, p86, v91, v92, nil, p87);
    end,
    createFiberFromOffscreen = u6,
    createFiberFromLegacyHidden = u7,
    createFiberFromText = function(p93, p94, p95) --[[ Name: createFiberFromText, Line 899 ]]
        -- upvalues: u18 (copy), l__HostText__22 (copy)
        return u18(l__HostText__22, p93, nil, p94, nil, nil, nil, p95);
    end,
    createFiberFromHostInstanceForDeletion = function() --[[ Name: createFiberFromHostInstanceForDeletion, Line 907 ]]
        -- upvalues: u18 (copy), l__HostComponent__21 (copy), l__NoMode__46 (copy)
        return u18(l__HostComponent__21, nil, nil, l__NoMode__46, "DELETED", "DELETED");
    end,
    createFiberFromDehydratedFragment = function(p96) --[[ Name: createFiberFromDehydratedFragment, Line 917 ]]
        -- upvalues: u18 (copy), l__DehydratedFragment__32 (copy), l__NoMode__46 (copy)
        return u18(l__DehydratedFragment__32, nil, nil, l__NoMode__46, nil, nil, p96);
    end,
    createFiberFromPortal = function(p97, p98, p99) --[[ Name: createFiberFromPortal, Line 926 ]]
        -- upvalues: u18 (copy), l__HostPortal__23 (copy)
        return u18(l__HostPortal__23, p97.children == nil and {} or p97.children, p97.key, p98, nil, nil, {
            pendingChildren = nil,
            containerInfo = p97.containerInfo,
            implementation = p97.implementation
        }, p99);
    end,
    assignFiberPropertiesInDEV = function(p100, p101) --[[ Name: assignFiberPropertiesInDEV, Line 950 ]]
        -- upvalues: u18 (copy), l__IndeterminateComponent__18 (copy), l__NoMode__46 (copy), l__enableProfilerTimer__11 (copy)
        if p100 == nil then
            p100 = u18(l__IndeterminateComponent__18, nil, nil, l__NoMode__46);
        end;
        p100.tag = p101.tag;
        p100.key = p101.key;
        p100.elementType = p101.elementType;
        p100.type = p101.type;
        p100.stateNode = p101.stateNode;
        p100.return_ = p101.return_;
        p100.child = p101.child;
        p100.sibling = p101.sibling;
        p100.index = p101.index;
        p100.ref = p101.ref;
        p100.pendingProps = p101.pendingProps;
        p100.memoizedProps = p101.memoizedProps;
        p100.updateQueue = p101.updateQueue;
        p100.memoizedState = p101.memoizedState;
        p100.dependencies = p101.dependencies;
        p100.mode = p101.mode;
        p100.flags = p101.flags;
        p100.subtreeFlags = p101.subtreeFlags;
        p100.deletions = p101.deletions;
        p100.lanes = p101.lanes;
        p100.childLanes = p101.childLanes;
        p100.alternate = p101.alternate;
        if l__enableProfilerTimer__11 then
            p100.actualDuration = p101.actualDuration;
            p100.actualStartTime = p101.actualStartTime;
            p100.selfBaseDuration = p101.selfBaseDuration;
            p100.treeBaseDuration = p101.treeBaseDuration;
        end;
        p100._debugID = p101._debugID;
        p100._debugSource = p101._debugSource;
        p100._debugOwner = p101._debugOwner;
        p100._debugNeedsRemount = p101._debugNeedsRemount;
        p100._debugHookTypes = p101._debugHookTypes;
        return p100;
    end
};