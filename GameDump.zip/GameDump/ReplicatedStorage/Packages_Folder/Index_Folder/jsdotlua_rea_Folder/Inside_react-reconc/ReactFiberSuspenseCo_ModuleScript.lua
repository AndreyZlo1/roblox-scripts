-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberSuspenseComponent.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent:WaitForChild("shared"));
require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__ReactFiberHostConfig__1 = require(script.Parent:WaitForChild("ReactFiberHostConfig"));
require(script.Parent:WaitForChild("ReactFiberLane"));
local l__ReactWorkTags__2 = require(script.Parent:WaitForChild("ReactWorkTags"));
local l__SuspenseComponent__3 = l__ReactWorkTags__2.SuspenseComponent;
local l__SuspenseListComponent__4 = l__ReactWorkTags__2.SuspenseListComponent;
local l__ReactFiberFlags__5 = require(script.Parent:WaitForChild("ReactFiberFlags"));
local l__NoFlags__6 = l__ReactFiberFlags__5.NoFlags;
local l__DidCapture__7 = l__ReactFiberFlags__5.DidCapture;
local l__isSuspenseInstancePending__8 = l__ReactFiberHostConfig__1.isSuspenseInstancePending;
local l__isSuspenseInstanceFallback__9 = l__ReactFiberHostConfig__1.isSuspenseInstanceFallback;
return {
    shouldCaptureSuspense = function(p1, p2) --[[ Line: 83 ]]
        local l__memoizedState__10 = p1.memoizedState;
        if l__memoizedState__10 then
            return l__memoizedState__10.dehydrated ~= nil;
        else
            local l__memoizedProps__11 = p1.memoizedProps;
            if l__memoizedProps__11.fallback == nil then
                return false;
            else
                return l__memoizedProps__11.unstable_avoidThisFallback ~= true and true or not p2;
            end;
        end;
    end,
    findFirstSuspended = function(p3) --[[ Line: 112 ]]
        -- upvalues: l__SuspenseComponent__3 (copy), l__isSuspenseInstancePending__8 (copy), l__isSuspenseInstanceFallback__9 (copy), l__SuspenseListComponent__4 (copy), l__DidCapture__7 (copy), l__NoFlags__6 (copy)
        local v4 = p3;
        while true do
            while true do
                if p3 == nil then
                    return nil;
                end;
                if p3.tag == l__SuspenseComponent__3 then
                    break;
                end;
                if p3.tag == l__SuspenseListComponent__4 and p3.memoizedProps.revealOrder ~= nil then
                    if bit32.band(p3.flags, l__DidCapture__7) ~= l__NoFlags__6 then
                        return p3;
                    end;
                    if p3 == v4 then
                        return nil;
                    end;
                    while p3.sibling == nil do
                        if p3.return_ == nil or p3.return_ == v4 then
                            return nil;
                        end;
                        p3 = p3.return_;
                    end;
                    p3.sibling.return_ = p3.return_;
                    p3 = p3.sibling;
                end;
                if p3.child == nil then
                    if p3 == v4 then
                        return nil;
                    end;
                    while p3.sibling == nil do
                        if p3.return_ == nil or p3.return_ == v4 then
                            return nil;
                        end;
                        p3 = p3.return_;
                    end;
                    p3.sibling.return_ = p3.return_;
                    p3 = p3.sibling;
                end;
                p3.child.return_ = p3;
                p3 = p3.child;
            end;
            local l__memoizedState__12 = p3.memoizedState;
            if l__memoizedState__12 then
                local l__dehydrated__13 = l__memoizedState__12.dehydrated;
                if l__dehydrated__13 == nil or (l__isSuspenseInstancePending__8(l__dehydrated__13) or l__isSuspenseInstanceFallback__9(l__dehydrated__13)) then
                    return p3;
                end;
            end;
            if p3 == v4 then
                return nil;
            end;
            while p3.sibling == nil do
                if p3.return_ == nil or p3.return_ == v4 then
                    return nil;
                end;
                p3 = p3.return_;
            end;
            p3.sibling.return_ = p3.return_;
            p3 = p3.sibling;
        end;
    end
};