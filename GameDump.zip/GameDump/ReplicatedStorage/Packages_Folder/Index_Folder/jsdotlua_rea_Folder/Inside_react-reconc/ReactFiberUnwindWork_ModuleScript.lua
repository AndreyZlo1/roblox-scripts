-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberUnwindWork.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent:WaitForChild("ReactInternalTypes"));
require(script.Parent:WaitForChild("ReactFiberLane"));
require(script.Parent:WaitForChild("ReactFiberSuspenseComponent.new"));
local l__resetWorkInProgressVersions__1 = require(script.Parent:WaitForChild("ReactMutableSource.new")).resetWorkInProgressVersions;
local l__ReactWorkTags__2 = require(script.Parent:WaitForChild("ReactWorkTags"));
local l__ReactFiberFlags__3 = require(script.Parent:WaitForChild("ReactFiberFlags"));
local l__ReactTypeOfMode__4 = require(script.Parent:WaitForChild("ReactTypeOfMode"));
local l__ReactFeatureFlags__5 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags;
local l__enableSuspenseServerRenderer__6 = l__ReactFeatureFlags__5.enableSuspenseServerRenderer;
local l__enableProfilerTimer__7 = l__ReactFeatureFlags__5.enableProfilerTimer;
local v1 = require(script.Parent:WaitForChild("ReactFiberHostContext.new"));
local l__popHostContainer__8 = v1.popHostContainer;
local l__popHostContext__9 = v1.popHostContext;
local l__popSuspenseContext__10 = require(script.Parent:WaitForChild("ReactFiberSuspenseContext.new")).popSuspenseContext;
local l__resetHydrationState__11 = require(script.Parent:WaitForChild("ReactFiberHydrationContext.new")).resetHydrationState;
local v2 = require(script.Parent:WaitForChild("ReactFiberContext.new"));
local l__isContextProvider__12 = v2.isContextProvider;
local l__popContext__13 = v2.popContext;
local l__popTopLevelContextObject__14 = v2.popTopLevelContextObject;
local l__popProvider__15 = require(script.Parent:WaitForChild("ReactFiberNewContext.new")).popProvider;
local u3 = nil;
local function u4(...) --[[ Line: 44 ]]
    -- upvalues: u3 (ref)
    if not u3 then
        u3 = require(script.Parent:WaitForChild("ReactFiberWorkLoop.new")).popRenderLanes;
    end;
    return u3(...);
end;
local l__transferActualDuration__16 = require(script.Parent:WaitForChild("ReactProfilerTimer.new")).transferActualDuration;
local l__invariant__17 = require(script.Parent.Parent:WaitForChild("shared")).invariant;
function unwindInterruptedWork(p5)
    -- upvalues: l__ReactWorkTags__2 (copy), l__popContext__13 (copy), l__popHostContainer__8 (copy), l__popTopLevelContextObject__14 (copy), l__resetWorkInProgressVersions__1 (copy), l__popHostContext__9 (copy), l__popSuspenseContext__10 (copy), l__popProvider__15 (copy), u4 (copy)
    if p5.tag == l__ReactWorkTags__2.ClassComponent then
        local v6;
        if typeof(p5.type) == "table" then
            v6 = p5.type.childContextTypes;
        else
            v6 = nil;
        end;
        if v6 == nil then
        else
            l__popContext__13(p5);
        end;
    elseif p5.tag == l__ReactWorkTags__2.HostRoot then
        l__popHostContainer__8(p5);
        l__popTopLevelContextObject__14(p5);
        l__resetWorkInProgressVersions__1();
    elseif p5.tag == l__ReactWorkTags__2.HostComponent then
        l__popHostContext__9(p5);
    elseif p5.tag == l__ReactWorkTags__2.HostPortal then
        l__popHostContainer__8(p5);
    elseif p5.tag == l__ReactWorkTags__2.SuspenseComponent then
        l__popSuspenseContext__10(p5);
    elseif p5.tag == l__ReactWorkTags__2.SuspenseListComponent then
        l__popSuspenseContext__10(p5);
    elseif p5.tag == l__ReactWorkTags__2.ContextProvider then
        l__popProvider__15(p5);
    elseif p5.tag == l__ReactWorkTags__2.OffscreenComponent or p5.tag == l__ReactWorkTags__2.LegacyHiddenComponent then
        u4(p5);
    end;
end;
return {
    unwindWork = function(p7, _) --[[ Name: unwindWork, Line 55 ]]
        -- upvalues: l__ReactWorkTags__2 (copy), l__isContextProvider__12 (copy), l__popContext__13 (copy), l__ReactFiberFlags__3 (copy), l__enableProfilerTimer__7 (copy), l__ReactTypeOfMode__4 (copy), l__transferActualDuration__16 (copy), l__popHostContainer__8 (copy), l__popTopLevelContextObject__14 (copy), l__resetWorkInProgressVersions__1 (copy), l__invariant__17 (copy), l__popHostContext__9 (copy), l__popSuspenseContext__10 (copy), l__enableSuspenseServerRenderer__6 (copy), l__resetHydrationState__11 (copy), l__popProvider__15 (copy), u4 (copy)
        if p7.tag == l__ReactWorkTags__2.ClassComponent then
            if l__isContextProvider__12(p7.type) then
                l__popContext__13(p7);
            end;
            local l__flags__18 = p7.flags;
            if bit32.band(l__flags__18, l__ReactFiberFlags__3.ShouldCapture) == 0 then
                return nil;
            end;
            local v8 = bit32.bnot(l__ReactFiberFlags__3.ShouldCapture);
            local v9 = bit32.band(l__flags__18, v8);
            p7.flags = bit32.bor(v9, l__ReactFiberFlags__3.DidCapture);
            if l__enableProfilerTimer__7 and bit32.band(p7.mode, l__ReactTypeOfMode__4.ProfileMode) ~= l__ReactTypeOfMode__4.NoMode then
                l__transferActualDuration__16(p7);
            end;
            return p7;
        end;
        if p7.tag == l__ReactWorkTags__2.HostRoot then
            l__popHostContainer__8(p7);
            l__popTopLevelContextObject__14(p7);
            l__resetWorkInProgressVersions__1();
            local l__flags__19 = p7.flags;
            l__invariant__17(bit32.band(l__flags__19, l__ReactFiberFlags__3.DidCapture) == l__ReactFiberFlags__3.NoFlags, "The root failed to unmount after an error. This is likely a bug in React. Please file an issue.");
            local v10 = bit32.bnot(l__ReactFiberFlags__3.ShouldCapture);
            local v11 = bit32.band(l__flags__19, v10);
            p7.flags = bit32.bor(v11, l__ReactFiberFlags__3.DidCapture);
            return p7;
        end;
        if p7.tag == l__ReactWorkTags__2.HostComponent then
            l__popHostContext__9(p7);
            return nil;
        end;
        if p7.tag ~= l__ReactWorkTags__2.SuspenseComponent then
            if p7.tag == l__ReactWorkTags__2.SuspenseListComponent then
                l__popSuspenseContext__10(p7);
                return nil;
            end;
            if p7.tag == l__ReactWorkTags__2.HostPortal then
                l__popHostContainer__8(p7);
                return nil;
            end;
            if p7.tag == l__ReactWorkTags__2.ContextProvider then
                l__popProvider__15(p7);
                return nil;
            end;
            if p7.tag ~= l__ReactWorkTags__2.OffscreenComponent and p7.tag ~= l__ReactWorkTags__2.LegacyHiddenComponent then
                return nil;
            end;
            u4(p7);
            return nil;
        end;
        l__popSuspenseContext__10(p7);
        if l__enableSuspenseServerRenderer__6 then
            local l__memoizedState__20 = p7.memoizedState;
            if l__memoizedState__20 ~= nil and l__memoizedState__20.dehydrated ~= nil then
                l__invariant__17(p7.alternate ~= nil, "Threw in newly mounted dehydrated component. This is likely a bug in React. Please file an issue.");
                l__resetHydrationState__11();
            end;
        end;
        local l__flags__21 = p7.flags;
        if bit32.band(l__flags__21, l__ReactFiberFlags__3.ShouldCapture) == 0 then
            return nil;
        end;
        local v12 = bit32.bnot(l__ReactFiberFlags__3.ShouldCapture);
        local v13 = bit32.band(l__flags__21, v12);
        p7.flags = bit32.bor(v13, l__ReactFiberFlags__3.DidCapture);
        if l__enableProfilerTimer__7 and bit32.band(p7.mode, l__ReactTypeOfMode__4.ProfileMode) ~= l__ReactTypeOfMode__4.NoMode then
            l__transferActualDuration__16(p7);
        end;
        return p7;
    end,
    unwindInterruptedWork = unwindInterruptedWork
};