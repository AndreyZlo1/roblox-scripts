-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactProfilerTimer.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__ReactFeatureFlags__1 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags;
local l__enableProfilerTimer__2 = l__ReactFeatureFlags__1.enableProfilerTimer;
local l__enableProfilerCommitHooks__3 = l__ReactFeatureFlags__1.enableProfilerCommitHooks;
local l__Profiler__4 = require(script.Parent:WaitForChild("ReactWorkTags")).Profiler;
local l__unstable_now__5 = require(script.Parent.Parent:WaitForChild("scheduler")).unstable_now;
local u1 = 0;
local u2 = -1;
local u3 = -1;
local u4 = -1;
function getCommitTime()
    -- upvalues: u1 (ref)
    return u1;
end;
function recordCommitTime()
    -- upvalues: l__enableProfilerTimer__2 (copy), u1 (ref), l__unstable_now__5 (copy)
    if l__enableProfilerTimer__2 then
        u1 = l__unstable_now__5();
    end;
end;
function startProfilerTimer(p5)
    -- upvalues: l__enableProfilerTimer__2 (copy), u3 (ref), l__unstable_now__5 (copy)
    if l__enableProfilerTimer__2 then
        u3 = l__unstable_now__5();
        if p5.actualStartTime ~= nil and p5.actualStartTime < 0 then
            p5.actualStartTime = l__unstable_now__5();
        end;
    end;
end;
function stopProfilerTimerIfRunning(_)
    -- upvalues: l__enableProfilerTimer__2 (copy), u3 (ref)
    if l__enableProfilerTimer__2 then
        u3 = -1;
    end;
end;
function stopProfilerTimerIfRunningAndRecordDelta(p6, p7)
    -- upvalues: l__enableProfilerTimer__2 (copy), u3 (ref), l__unstable_now__5 (copy)
    if l__enableProfilerTimer__2 then
        if u3 >= 0 then
            local v8 = l__unstable_now__5() - u3;
            p6.actualDuration = p6.actualDuration + v8;
            if p7 then
                p6.selfBaseDuration = v8;
            end;
            u3 = -1;
        end;
    end;
end;
function recordLayoutEffectDuration(p9)
    -- upvalues: l__enableProfilerTimer__2 (copy), l__enableProfilerCommitHooks__3 (copy), u2 (ref), l__unstable_now__5 (copy), l__Profiler__4 (copy)
    if l__enableProfilerTimer__2 and l__enableProfilerCommitHooks__3 then
        if u2 >= 0 then
            local v10 = l__unstable_now__5() - u2;
            u2 = -1;
            local l__return___6 = p9.return_;
            while l__return___6 ~= nil do
                if l__return___6.tag == l__Profiler__4 then
                    local l__stateNode__7 = l__return___6.stateNode;
                    l__stateNode__7.effectDuration = l__stateNode__7.effectDuration + v10;
                    return;
                end;
                l__return___6 = l__return___6.return_;
            end;
        end;
    end;
end;
function recordPassiveEffectDuration(p11)
    -- upvalues: l__enableProfilerTimer__2 (copy), l__enableProfilerCommitHooks__3 (copy), u4 (ref), l__unstable_now__5 (copy), l__Profiler__4 (copy)
    if not (l__enableProfilerTimer__2 and l__enableProfilerCommitHooks__3) then
        return;
    end;
    if u4 >= 0 then
        local v12 = l__unstable_now__5() - u4;
        u4 = -1;
        local l__return___8 = p11.return_;
        while l__return___8 ~= nil do
            if l__return___8.tag == l__Profiler__4 then
                local l__stateNode__9 = l__return___8.stateNode;
                if l__stateNode__9 ~= nil then
                    l__stateNode__9.passiveEffectDuration = l__stateNode__9.passiveEffectDuration + v12;
                    return;
                end;
                break;
            end;
            l__return___8 = l__return___8.return_;
        end;
    end;
end;
function startLayoutEffectTimer()
    -- upvalues: l__enableProfilerTimer__2 (copy), l__enableProfilerCommitHooks__3 (copy), u2 (ref), l__unstable_now__5 (copy)
    if l__enableProfilerTimer__2 and l__enableProfilerCommitHooks__3 then
        u2 = l__unstable_now__5();
    end;
end;
function startPassiveEffectTimer()
    -- upvalues: l__enableProfilerTimer__2 (copy), l__enableProfilerCommitHooks__3 (copy), u4 (ref), l__unstable_now__5 (copy)
    if l__enableProfilerTimer__2 and l__enableProfilerCommitHooks__3 then
        u4 = l__unstable_now__5();
    end;
end;
function transferActualDuration(p13)
    local l__child__10 = p13.child;
    while l__child__10 do
        p13.actualDuration = p13.actualDuration + l__child__10.actualDuration;
        l__child__10 = l__child__10.sibling;
    end;
end;
return {
    getCommitTime = getCommitTime,
    recordCommitTime = recordCommitTime,
    recordLayoutEffectDuration = recordLayoutEffectDuration,
    recordPassiveEffectDuration = recordPassiveEffectDuration,
    startLayoutEffectTimer = startLayoutEffectTimer,
    startPassiveEffectTimer = startPassiveEffectTimer,
    startProfilerTimer = startProfilerTimer,
    stopProfilerTimerIfRunning = stopProfilerTimerIfRunning,
    stopProfilerTimerIfRunningAndRecordDelta = stopProfilerTimerIfRunningAndRecordDelta,
    transferActualDuration = transferActualDuration
};