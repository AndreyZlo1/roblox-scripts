-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberWorkLoop.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
local l____YOLO____2 = _G.__YOLO__;
local l__console__3 = require(script.Parent.Parent:WaitForChild("shared")).console;
local l__Set__4 = require(script.Parent.Parent:WaitForChild("luau-polyfill")).Set;
local u1 = {};
require(script.Parent.Parent:WaitForChild("shared"));
require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__ReactFiberLane__5 = require(script.Parent:WaitForChild("ReactFiberLane"));
local l__scheduler__6 = require(script.Parent.Parent:WaitForChild("scheduler"));
require(script.Parent:WaitForChild("ReactFiberSuspenseComponent.new"));
local v2 = require(script.Parent:WaitForChild("ReactFiberStack.new"));
local l__ReactFeatureFlags__7 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags;
local l__enableDebugTracing__8 = l__ReactFeatureFlags__7.enableDebugTracing;
local l__enableSchedulingProfiler__9 = l__ReactFeatureFlags__7.enableSchedulingProfiler;
local l__skipUnmountedBoundaries__10 = l__ReactFeatureFlags__7.skipUnmountedBoundaries;
local l__enableDoubleInvokingEffects__11 = l__ReactFeatureFlags__7.enableDoubleInvokingEffects;
local l__shared__12 = require(script.Parent.Parent:WaitForChild("shared"));
local l__describeError__13 = require(script.Parent.Parent:WaitForChild("shared")).describeError;
local l__ReactSharedInternals__14 = l__shared__12.ReactSharedInternals;
local l__invariant__15 = l__shared__12.invariant;
local v3 = require(script.Parent:WaitForChild("SchedulerWithReactIntegration.new"));
local l__scheduleCallback__16 = v3.scheduleCallback;
local l__cancelCallback__17 = v3.cancelCallback;
local l__getCurrentPriorityLevel__18 = v3.getCurrentPriorityLevel;
local l__runWithPriority__19 = v3.runWithPriority;
local l__shouldYield__20 = v3.shouldYield;
local l__requestPaint__21 = v3.requestPaint;
local l__now__22 = v3.now;
local l__NoPriority__23 = v3.NoPriority;
local l__ImmediatePriority__24 = v3.ImmediatePriority;
local l__UserBlockingPriority__25 = v3.UserBlockingPriority;
local l__NormalPriority__26 = v3.NormalPriority;
local l__flushSyncCallbackQueue__27 = v3.flushSyncCallbackQueue;
local l__scheduleSyncCallback__28 = v3.scheduleSyncCallback;
local l__DebugTracing__29 = require(script.Parent:WaitForChild("DebugTracing"));
local l__SchedulingProfiler__30 = require(script.Parent:WaitForChild("SchedulingProfiler"));
local l__tracing__31 = require(script.Parent.Parent:WaitForChild("scheduler")).tracing;
local l____interactionsRef__32 = l__tracing__31.__interactionsRef;
local l____subscriberRef__33 = l__tracing__31.__subscriberRef;
local l__ReactFiberHostConfig__34 = require(script.Parent:WaitForChild("ReactFiberHostConfig"));
local u4 = require(script.Parent:WaitForChild("ReactFiber.new"));
local l__ReactTypeOfMode__35 = require(script.Parent:WaitForChild("ReactTypeOfMode"));
local l__ReactWorkTags__36 = require(script.Parent:WaitForChild("ReactWorkTags"));
local l__LegacyRoot__37 = require(script.Parent:WaitForChild("ReactRootTags")).LegacyRoot;
local l__ReactFiberFlags__38 = require(script.Parent:WaitForChild("ReactFiberFlags"));
local l__SyncLane__39 = l__ReactFiberLane__5.SyncLane;
local l__SyncBatchedLane__40 = l__ReactFiberLane__5.SyncBatchedLane;
local l__NoTimestamp__41 = l__ReactFiberLane__5.NoTimestamp;
local l__findUpdateLane__42 = l__ReactFiberLane__5.findUpdateLane;
local l__findTransitionLane__43 = l__ReactFiberLane__5.findTransitionLane;
local l__findRetryLane__44 = l__ReactFiberLane__5.findRetryLane;
local l__includesSomeLane__45 = l__ReactFiberLane__5.includesSomeLane;
local l__isSubsetOfLanes__46 = l__ReactFiberLane__5.isSubsetOfLanes;
local l__mergeLanes__47 = l__ReactFiberLane__5.mergeLanes;
local l__removeLanes__48 = l__ReactFiberLane__5.removeLanes;
local l__pickArbitraryLane__49 = l__ReactFiberLane__5.pickArbitraryLane;
local l__hasDiscreteLanes__50 = l__ReactFiberLane__5.hasDiscreteLanes;
local l__includesNonIdleWork__51 = l__ReactFiberLane__5.includesNonIdleWork;
local l__includesOnlyRetries__52 = l__ReactFiberLane__5.includesOnlyRetries;
local l__includesOnlyTransitions__53 = l__ReactFiberLane__5.includesOnlyTransitions;
local l__getNextLanes__54 = l__ReactFiberLane__5.getNextLanes;
local l__returnNextLanesPriority__55 = l__ReactFiberLane__5.returnNextLanesPriority;
local l__setCurrentUpdateLanePriority__56 = l__ReactFiberLane__5.setCurrentUpdateLanePriority;
local l__getCurrentUpdateLanePriority__57 = l__ReactFiberLane__5.getCurrentUpdateLanePriority;
local l__markStarvedLanesAsExpired__58 = l__ReactFiberLane__5.markStarvedLanesAsExpired;
local l__getLanesToRetrySynchronouslyOnError__59 = l__ReactFiberLane__5.getLanesToRetrySynchronouslyOnError;
local l__getMostRecentEventTime__60 = l__ReactFiberLane__5.getMostRecentEventTime;
local l__markRootUpdated__61 = l__ReactFiberLane__5.markRootUpdated;
local l__markRootSuspended__62 = l__ReactFiberLane__5.markRootSuspended;
local l__markRootPinged__63 = l__ReactFiberLane__5.markRootPinged;
local l__markRootExpired__64 = l__ReactFiberLane__5.markRootExpired;
local l__markDiscreteUpdatesExpired__65 = l__ReactFiberLane__5.markDiscreteUpdatesExpired;
local l__markRootFinished__66 = l__ReactFiberLane__5.markRootFinished;
local l__schedulerPriorityToLanePriority__67 = l__ReactFiberLane__5.schedulerPriorityToLanePriority;
local l__lanePriorityToSchedulerPriority__68 = l__ReactFiberLane__5.lanePriorityToSchedulerPriority;
local l__ReactFiberTransition__69 = require(script.Parent:WaitForChild("ReactFiberTransition"));
local v5 = require(script.Parent:WaitForChild("ReactFiberUnwindWork.new"));
local l__unwindWork__70 = v5.unwindWork;
local l__unwindInterruptedWork__71 = v5.unwindInterruptedWork;
local v6 = require(script.Parent:WaitForChild("ReactFiberThrow.new"));
local l__throwException__72 = v6.throwException;
local l__createRootErrorUpdate__73 = v6.createRootErrorUpdate;
local l__createClassErrorUpdate__74 = v6.createClassErrorUpdate;
local u7 = require(script.Parent:WaitForChild("ReactFiberCommitWork.new"));
local l__commitBeforeMutationLifeCycles__75 = u7.commitBeforeMutationLifeCycles;
local l__commitPlacement__76 = u7.commitPlacement;
local l__commitWork__77 = u7.commitWork;
local l__commitDeletion__78 = u7.commitDeletion;
local l__commitPassiveUnmount__79 = u7.commitPassiveUnmount;
local l__commitPassiveUnmountInsideDeletedTree__80 = u7.commitPassiveUnmountInsideDeletedTree;
local l__commitPassiveMount__81 = u7.commitPassiveMount;
local l__commitDetachRef__82 = u7.commitDetachRef;
local l__invokeLayoutEffectMountInDEV__83 = u7.invokeLayoutEffectMountInDEV;
local l__invokePassiveEffectMountInDEV__84 = u7.invokePassiveEffectMountInDEV;
local l__invokeLayoutEffectUnmountInDEV__85 = u7.invokeLayoutEffectUnmountInDEV;
local l__invokePassiveEffectUnmountInDEV__86 = u7.invokePassiveEffectUnmountInDEV;
local l__recursivelyCommitLayoutEffects__87 = u7.recursivelyCommitLayoutEffects;
local l__promise__88 = require(script.Parent.Parent:WaitForChild("promise"));
local l__enqueueUpdate__89 = require(script.Parent:WaitForChild("ReactUpdateQueue.new")).enqueueUpdate;
local l__resetContextDependencies__90 = require(script.Parent:WaitForChild("ReactFiberNewContext.new")).resetContextDependencies;
local u8 = nil;
local u9 = {
    resetHooksAfterThrowRef = nil,
    ContextOnlyDispatcherRef = nil,
    getIsUpdatingOpaqueValueInRenderPhaseInDEVRef = nil,
    originalBeginWorkRef = nil,
    completeWorkRef = nil
};
local function u13(p10, p11, p12) --[[ Line: 237 ]]
    -- upvalues: u9 (copy)
    if not u9.originalBeginWorkRef then
        u9.originalBeginWorkRef = require(script.Parent:WaitForChild("ReactFiberBeginWork.new")).beginWork;
    end;
    return u9.originalBeginWorkRef(p10, p11, p12);
end;
local u14 = nil;
local l__createCapturedValue__91 = require(script.Parent:WaitForChild("ReactCapturedValue")).createCapturedValue;
local l__push__92 = v2.push;
local l__pop__93 = v2.pop;
local l__createCursor__94 = v2.createCursor;
local u15 = require(script.Parent:WaitForChild("ReactProfilerTimer.new"));
local l__getComponentName__95 = require(script.Parent.Parent:WaitForChild("shared")).getComponentName;
local u16 = require(script.Parent:WaitForChild("ReactStrictModeWarnings.new"));
local l__ReactCurrentFiber__96 = require(script.Parent:WaitForChild("ReactCurrentFiber"));
local l__current__97 = l__ReactCurrentFiber__96.current;
local l__resetCurrentFiber__98 = l__ReactCurrentFiber__96.resetCurrentFiber;
local l__setCurrentFiber__99 = l__ReactCurrentFiber__96.setCurrentFiber;
local l__ReactErrorUtils__100 = require(script.Parent.Parent:WaitForChild("shared")).ReactErrorUtils;
local l__invokeGuardedCallback__101 = l__ReactErrorUtils__100.invokeGuardedCallback;
local l__hasCaughtError__102 = l__ReactErrorUtils__100.hasCaughtError;
local l__clearCaughtError__103 = l__ReactErrorUtils__100.clearCaughtError;
local l__onCommitRoot__104 = require(script.Parent:WaitForChild("ReactFiberDevToolsHook.new")).onCommitRoot;
local l__onCommitRoot__105 = require(script.Parent:WaitForChild("ReactTestSelectors")).onCommitRoot;
local l__enqueueTask__106 = require(script.Parent.Parent:WaitForChild("shared")).enqueueTask;
local l__doesFiberContain__107 = require(script.Parent:WaitForChild("ReactFiberTreeReflection")).doesFiberContain;
local l__ReactCurrentDispatcher__108 = l__ReactSharedInternals__14.ReactCurrentDispatcher;
local l__ReactCurrentOwner__109 = l__ReactSharedInternals__14.ReactCurrentOwner;
local l__IsSomeRendererActing__110 = l__ReactSharedInternals__14.IsSomeRendererActing;
local u17 = nil;
local u18 = {};
u1.NoContext = 0;
u1.RetryAfterError = 64;
local u19 = 0;
local u20 = nil;
local u21 = nil;
local l__NoLanes__111 = l__ReactFiberLane__5.NoLanes;
u1.subtreeRenderLanes = l__ReactFiberLane__5.NoLanes;
local u22 = l__createCursor__94(l__ReactFiberLane__5.NoLanes);
local u23 = 0;
local u24 = nil;
local l__NoLanes__112 = l__ReactFiberLane__5.NoLanes;
local l__ReactFiberWorkInProgress__113 = require(script.Parent:WaitForChild("ReactFiberWorkInProgress"));
local l__workInProgressRootSkippedLanes__114 = l__ReactFiberWorkInProgress__113.workInProgressRootSkippedLanes;
local l__NoLanes__115 = l__ReactFiberLane__5.NoLanes;
local l__NoLanes__116 = l__ReactFiberLane__5.NoLanes;
local u25 = nil;
local u26 = 0;
local u27 = (1 / 0);
local u28 = nil;
function u1.getRenderTargetTime() --[[ Line: 420 ]]
    -- upvalues: u27 (ref)
    return u27;
end;
local u29 = false;
local u30 = nil;
local u31 = nil;
local u32 = false;
local u33 = nil;
local u34 = l__NoPriority__23;
local l__NoLanes__117 = l__ReactFiberLane__5.NoLanes;
local u35 = nil;
local u36 = 0;
local u37 = nil;
local u38 = 0;
local u39 = nil;
local u40 = l__NoTimestamp__41;
local l__NoLanes__118 = l__ReactFiberLane__5.NoLanes;
local l__NoLanes__119 = l__ReactFiberLane__5.NoLanes;
local u41 = nil;
local u42 = false;
function u1.getWorkInProgressRoot() --[[ Line: 460 ]]
    -- upvalues: u20 (ref)
    return u20;
end;
function u1.requestEventTime() --[[ Line: 464 ]]
    -- upvalues: u19 (ref), l__now__22 (copy), u40 (ref), l__NoTimestamp__41 (copy)
    if bit32.band(u19, 48) ~= 0 then
        return l__now__22();
    end;
    if u40 ~= l__NoTimestamp__41 then
        return u40;
    end;
    u40 = l__now__22();
    return u40;
end;
function u1.requestUpdateLane(p43) --[[ Line: 486 ]]
    -- upvalues: l__ReactTypeOfMode__35 (copy), l__SyncLane__39 (copy), l__getCurrentPriorityLevel__18 (copy), l__ImmediatePriority__24 (copy), l__SyncBatchedLane__40 (copy), l__ReactFeatureFlags__7 (copy), u19 (ref), l__NoLanes__111 (ref), l__ReactFiberLane__5 (copy), l__pickArbitraryLane__49 (copy), l__NoLanes__118 (ref), l__NoLanes__112 (ref), l__ReactFiberTransition__69 (copy), l__NoLanes__119 (ref), u25 (ref), l__findTransitionLane__43 (copy), l__UserBlockingPriority__25 (copy), l__findUpdateLane__42 (copy), l__schedulerPriorityToLanePriority__67 (copy), l__getCurrentUpdateLanePriority__57 (copy), l____DEV____1 (copy), l__console__3 (copy)
    local l__mode__120 = p43.mode;
    if bit32.band(l__mode__120, l__ReactTypeOfMode__35.BlockingMode) == l__ReactTypeOfMode__35.NoMode then
        return l__SyncLane__39;
    elseif bit32.band(l__mode__120, l__ReactTypeOfMode__35.ConcurrentMode) == l__ReactTypeOfMode__35.NoMode then
        if l__getCurrentPriorityLevel__18() == l__ImmediatePriority__24 then
            return l__SyncLane__39;
        else
            return l__SyncBatchedLane__40;
        end;
    else
        if not l__ReactFeatureFlags__7.deferRenderPhaseUpdateToNextBatch and (bit32.band(u19, 16) ~= 0 and l__NoLanes__111 ~= l__ReactFiberLane__5.NoLanes) then
            return l__pickArbitraryLane__49(l__NoLanes__111);
        end;
        if l__NoLanes__118 == l__ReactFiberLane__5.NoLanes then
            l__NoLanes__118 = l__NoLanes__112;
        end;
        if l__ReactFiberTransition__69.requestCurrentTransition() ~= l__ReactFiberTransition__69.NoTransition then
            if l__NoLanes__119 ~= l__ReactFiberLane__5.NoLanes then
                if u25 == nil then
                    l__NoLanes__119 = l__ReactFiberLane__5.NoLanes;
                else
                    l__NoLanes__119 = u25.pendingLanes;
                end;
            end;
            return l__findTransitionLane__43(l__NoLanes__118, l__NoLanes__119);
        end;
        local v44 = l__getCurrentPriorityLevel__18();
        if bit32.band(u19, 4) ~= 0 and v44 == l__UserBlockingPriority__25 then
            return l__findUpdateLane__42(l__ReactFiberLane__5.InputDiscreteLanePriority, l__NoLanes__118);
        end;
        local v45 = l__schedulerPriorityToLanePriority__67(v44);
        if l__ReactFeatureFlags__7.decoupleUpdatePriorityFromScheduler then
            local v46 = l__getCurrentUpdateLanePriority__57();
            if v45 ~= v46 and (v46 ~= l__ReactFiberLane__5.NoLanePriority and l____DEV____1) then
                l__console__3.error("Expected current scheduler lane priority %s to match current update lane priority %s", tostring(v45), (tostring(v46)));
            end;
        end;
        return l__findUpdateLane__42(v45, l__NoLanes__118);
    end;
end;
function requestRetryLane(p47)
    -- upvalues: l__ReactTypeOfMode__35 (copy), l__SyncLane__39 (copy), l__getCurrentPriorityLevel__18 (copy), l__ImmediatePriority__24 (copy), l__SyncBatchedLane__40 (copy), l__NoLanes__118 (ref), l__ReactFiberLane__5 (copy), l__NoLanes__112 (ref), l__findRetryLane__44 (copy)
    local l__mode__121 = p47.mode;
    if bit32.band(l__mode__121, l__ReactTypeOfMode__35.BlockingMode) == l__ReactTypeOfMode__35.NoMode then
        return l__SyncLane__39;
    elseif bit32.band(l__mode__121, l__ReactTypeOfMode__35.ConcurrentMode) == l__ReactTypeOfMode__35.NoMode then
        if l__getCurrentPriorityLevel__18() == l__ImmediatePriority__24 then
            return l__SyncLane__39;
        else
            return l__SyncBatchedLane__40;
        end;
    else
        if l__NoLanes__118 == l__ReactFiberLane__5.NoLanes then
            l__NoLanes__118 = l__NoLanes__112;
        end;
        return l__findRetryLane__44(l__NoLanes__118);
    end;
end;
function u1.scheduleUpdateOnFiber(p48, p49, p50) --[[ Line: 612 ]]
    -- upvalues: u18 (copy), l__markRootUpdated__61 (copy), u20 (ref), l__ReactFeatureFlags__7 (copy), u19 (ref), l__NoLanes__115 (ref), l__mergeLanes__47 (copy), u23 (ref), l__NoLanes__111 (ref), l__getCurrentPriorityLevel__18 (copy), l__SyncLane__39 (copy), u8 (ref), u27 (ref), l__now__22 (copy), l__flushSyncCallbackQueue__27 (copy), l__UserBlockingPriority__25 (copy), l__ImmediatePriority__24 (copy), u35 (ref), l__Set__4 (copy), u25 (ref)
    u18.checkForNestedUpdates();
    local v51 = u18.markUpdateLaneFromFiberToRoot(p48, p49);
    if v51 == nil then
        return nil;
    end;
    l__markRootUpdated__61(v51, p49, p50);
    if v51 == u20 then
        u18.warnAboutRenderPhaseUpdatesInDEV(p48);
        if l__ReactFeatureFlags__7.deferRenderPhaseUpdateToNextBatch or bit32.band(u19, 16) == 0 then
            l__NoLanes__115 = l__mergeLanes__47(l__NoLanes__115, p49);
        end;
        if u23 == 4 then
            u18.markRootSuspended(v51, l__NoLanes__111);
        end;
    end;
    local v52 = l__getCurrentPriorityLevel__18();
    if p49 == l__SyncLane__39 then
        if bit32.band(u19, 8) == 0 or bit32.band(u19, 48) ~= 0 then
            u8(v51, p50);
            u18.schedulePendingInteractions(v51, p49);
            if u19 == 0 then
                u27 = l__now__22() + 500;
                l__flushSyncCallbackQueue__27();
            end;
        else
            u18.schedulePendingInteractions(v51, p49);
            u18.performSyncWorkOnRoot(v51);
        end;
    else
        if bit32.band(u19, 4) ~= 0 and (v52 == l__UserBlockingPriority__25 or v52 == l__ImmediatePriority__24) then
            if u35 == nil then
                u35 = l__Set__4.new({ v51 });
            else
                u35:add(v51);
            end;
        end;
        u8(v51, p50);
        u18.schedulePendingInteractions(v51, p49);
    end;
    u25 = v51;
    return v51;
end;
function u18.markUpdateLaneFromFiberToRoot(p53, p54) --[[ Line: 722 ]]
    -- upvalues: l__mergeLanes__47 (copy), l____DEV____1 (copy), l__ReactFiberFlags__38 (copy), u18 (copy), l__ReactWorkTags__36 (copy)
    p53.lanes = l__mergeLanes__47(p53.lanes, p54);
    local l__alternate__122 = p53.alternate;
    if l__alternate__122 ~= nil then
        l__alternate__122.lanes = l__mergeLanes__47(l__alternate__122.lanes, p54);
    end;
    if l____DEV____1 and l__alternate__122 == nil then
        local l__flags__123 = p53.flags;
        local v55 = bit32.bor(l__ReactFiberFlags__38.Placement, l__ReactFiberFlags__38.Hydrating);
        if bit32.band(l__flags__123, v55) ~= l__ReactFiberFlags__38.NoFlags then
            u18.warnAboutUpdateOnNotYetMountedFiberInDEV(p53);
        end;
    end;
    local l__return___124 = p53.return_;
    local v56 = p53;
    while l__return___124 ~= nil do
        l__return___124.childLanes = l__mergeLanes__47(l__return___124.childLanes, p54);
        local l__alternate__125 = l__return___124.alternate;
        if l__alternate__125 == nil then
            if l____DEV____1 then
                local l__flags__126 = l__return___124.flags;
                local v57 = bit32.bor(l__ReactFiberFlags__38.Placement, l__ReactFiberFlags__38.Hydrating);
                if bit32.band(l__flags__126, v57) ~= l__ReactFiberFlags__38.NoFlags then
                    u18.warnAboutUpdateOnNotYetMountedFiberInDEV(v56);
                end;
            end;
        else
            l__alternate__125.childLanes = l__mergeLanes__47(l__alternate__125.childLanes, p54);
        end;
        local l__return___127 = l__return___124.return_;
        p53 = l__return___124;
        l__return___124 = l__return___127;
    end;
    if p53.tag == l__ReactWorkTags__36.HostRoot then
        return p53.stateNode;
    else
        return nil;
    end;
end;
u8 = function(u58, p59) --[[ Line: 777 ]]
    -- upvalues: l__markStarvedLanesAsExpired__58 (copy), u20 (ref), l__NoLanes__111 (ref), l__ReactFiberLane__5 (copy), l__getNextLanes__54 (copy), l__returnNextLanesPriority__55 (copy), l__cancelCallback__17 (copy), l__scheduleSyncCallback__28 (copy), u18 (copy), l__scheduleCallback__16 (copy), l__ImmediatePriority__24 (copy), l__lanePriorityToSchedulerPriority__68 (copy)
    local l__callbackNode__128 = u58.callbackNode;
    l__markStarvedLanesAsExpired__58(u58, p59);
    local v60;
    if u58 == u20 then
        v60 = l__NoLanes__111;
    else
        v60 = l__ReactFiberLane__5.NoLanes;
    end;
    local v61 = l__getNextLanes__54(u58, v60);
    local v62 = l__returnNextLanesPriority__55();
    if v61 == l__ReactFiberLane__5.NoLanes then
        if l__callbackNode__128 ~= nil then
            l__cancelCallback__17(l__callbackNode__128);
            u58.callbackNode = nil;
            u58.callbackPriority = l__ReactFiberLane__5.NoLanePriority;
        end;
    else
        if l__callbackNode__128 ~= nil then
            if u58.callbackPriority == v62 then
                return;
            end;
            l__cancelCallback__17(l__callbackNode__128);
        end;
        local v63;
        if v62 == l__ReactFiberLane__5.SyncLanePriority then
            v63 = l__scheduleSyncCallback__28(function() --[[ Line: 822 ]]
                -- upvalues: u18 (ref), u58 (copy)
                return u18.performSyncWorkOnRoot(u58);
            end);
        elseif v62 == l__ReactFiberLane__5.SyncBatchedLanePriority then
            v63 = l__scheduleCallback__16(l__ImmediatePriority__24, function() --[[ Line: 826 ]]
                -- upvalues: u18 (ref), u58 (copy)
                return u18.performSyncWorkOnRoot(u58);
            end);
        else
            v63 = l__scheduleCallback__16(l__lanePriorityToSchedulerPriority__68(v62), function() --[[ Line: 832 ]]
                -- upvalues: u18 (ref), u58 (copy)
                return u18.performConcurrentWorkOnRoot(u58);
            end);
        end;
        u58.callbackPriority = v62;
        u58.callbackNode = v63;
    end;
end;
function u18.performConcurrentWorkOnRoot(u64) --[[ Line: 844 ]]
    -- upvalues: u40 (ref), l__NoTimestamp__41 (copy), l__NoLanes__118 (ref), l__ReactFiberLane__5 (copy), l__NoLanes__119 (ref), l__invariant__15 (copy), u19 (ref), u1 (copy), l__getNextLanes__54 (copy), u20 (ref), l__NoLanes__111 (ref), u18 (copy), l__includesSomeLane__45 (copy), l__NoLanes__112 (ref), l__NoLanes__115 (ref), l__ReactFiberHostConfig__34 (copy), l__getLanesToRetrySynchronouslyOnError__59 (copy), u24 (ref), u8 (ref), l__now__22 (copy)
    u40 = l__NoTimestamp__41;
    l__NoLanes__118 = l__ReactFiberLane__5.NoLanes;
    l__NoLanes__119 = l__ReactFiberLane__5.NoLanes;
    l__invariant__15(bit32.band(u19, 48) == 0, "Should not already be working.");
    local l__callbackNode__129 = u64.callbackNode;
    if u1.flushPassiveEffects() and u64.callbackNode ~= l__callbackNode__129 then
        return nil;
    end;
    local v65 = l__getNextLanes__54;
    local v66;
    if u64 == u20 then
        v66 = l__NoLanes__111;
    else
        v66 = l__ReactFiberLane__5.NoLanes;
    end;
    local v67 = v65(u64, v66);
    if v67 == l__ReactFiberLane__5.NoLanes then
        return nil;
    end;
    local v68 = u18.renderRootConcurrent(u64, v67);
    if l__includesSomeLane__45(l__NoLanes__112, l__NoLanes__115) then
        u18.prepareFreshStack(u64, l__ReactFiberLane__5.NoLanes);
    elseif v68 ~= 0 then
        if v68 == 2 then
            u19 = bit32.bor(u19, 64);
            if u64.hydrate then
                u64.hydrate = false;
                l__ReactFiberHostConfig__34.clearContainer(u64.containerInfo);
            end;
            v67 = l__getLanesToRetrySynchronouslyOnError__59(u64);
            if v67 ~= l__ReactFiberLane__5.NoLanes then
                v68 = u18.renderRootSync(u64, v67);
            end;
        end;
        if v68 == 1 then
            local v69 = u24;
            u18.prepareFreshStack(u64, l__ReactFiberLane__5.NoLanes);
            u18.markRootSuspended(u64, v67);
            u8(u64, l__now__22());
            error(v69);
        end;
        u64.finishedWork = u64.current.alternate;
        u64.finishedLanes = v67;
        u18.finishConcurrentRender(u64, v68, v67);
    end;
    u8(u64, l__now__22());
    return u64.callbackNode == l__callbackNode__129 and function() --[[ Line: 939 ]]
        -- upvalues: u18 (ref), u64 (copy)
        return u18.performConcurrentWorkOnRoot(u64);
    end or nil;
end;
local u70 = 0;
local u71 = false;
function shouldForceFlushFallbacksInDEV()
    -- upvalues: l____DEV____1 (copy), u70 (ref)
    local v72 = l____DEV____1;
    if v72 then
        v72 = u70 > 0;
    end;
    return v72;
end;
function u18.finishConcurrentRender(u73, p74, p75) --[[ Line: 957 ]]
    -- upvalues: l__invariant__15 (copy), u18 (copy), l__includesOnlyRetries__52 (copy), u26 (ref), l__now__22 (copy), l__getNextLanes__54 (copy), l__ReactFiberLane__5 (copy), l__isSubsetOfLanes__46 (copy), u1 (copy), l__markRootPinged__63 (copy), l__ReactFiberHostConfig__34 (copy), l__includesOnlyTransitions__53 (copy), l__getMostRecentEventTime__60 (copy)
    if p74 == 0 or p74 == 1 then
        l__invariant__15(false, "Root did not complete. This is a bug in React.");
    elseif p74 == 2 then
        u18.commitRoot(u73);
    elseif p74 == 3 then
        u18.markRootSuspended(u73, p75);
        if l__includesOnlyRetries__52(p75) and not shouldForceFlushFallbacksInDEV() then
            local v76 = u26 + 500 - l__now__22();
            if v76 > 10 then
                if l__getNextLanes__54(u73, l__ReactFiberLane__5.NoLanes) == l__ReactFiberLane__5.NoLanes then
                    local l__suspendedLanes__130 = u73.suspendedLanes;
                    if l__isSubsetOfLanes__46(l__suspendedLanes__130, p75) then
                        u73.timeoutHandle = l__ReactFiberHostConfig__34.scheduleTimeout(function() --[[ Line: 1006 ]]
                            -- upvalues: u18 (ref), u73 (copy)
                            return u18.commitRoot(u73);
                        end, v76);
                        return;
                    else
                        l__markRootPinged__63(u73, l__suspendedLanes__130, (u1.requestEventTime()));
                        return;
                    end;
                else
                    return;
                end;
            end;
        end;
        u18.commitRoot(u73);
    elseif p74 == 4 then
        u18.markRootSuspended(u73, p75);
        if l__includesOnlyTransitions__53(p75) then
        else
            if not shouldForceFlushFallbacksInDEV() then
                local v77 = l__getMostRecentEventTime__60(u73, p75);
                local v78 = l__now__22() - v77;
                local v79 = jnd(v78) - v78;
                if v79 > 10 then
                    u73.timeoutHandle = l__ReactFiberHostConfig__34.scheduleTimeout(function() --[[ Line: 1041 ]]
                        -- upvalues: u18 (ref), u73 (copy)
                        return u18.commitRoot(u73);
                    end, v79);
                    return;
                end;
            end;
            u18.commitRoot(u73);
        end;
    elseif p74 == 5 then
        u18.commitRoot(u73);
    else
        l__invariant__15(false, "Unknown root exit status.");
    end;
end;
function u18.markRootSuspended(p80, p81) --[[ Line: 1057 ]]
    -- upvalues: l__removeLanes__48 (copy), l__NoLanes__116 (ref), l__NoLanes__115 (ref), l__markRootSuspended__62 (copy)
    l__markRootSuspended__62(p80, (l__removeLanes__48(l__removeLanes__48(p81, l__NoLanes__116), l__NoLanes__115)));
end;
function u18.performSyncWorkOnRoot(p82) --[[ Line: 1069 ]]
    -- upvalues: l__invariant__15 (copy), u19 (ref), u1 (copy), u20 (ref), l__includesSomeLane__45 (copy), l__NoLanes__111 (ref), u18 (copy), l__NoLanes__112 (ref), l__NoLanes__115 (ref), l__getNextLanes__54 (copy), l__ReactFiberLane__5 (copy), l__LegacyRoot__37 (copy), l__ReactFiberHostConfig__34 (copy), l__getLanesToRetrySynchronouslyOnError__59 (copy), u24 (ref), u8 (ref), l__now__22 (copy)
    l__invariant__15(bit32.band(u19, 48) == 0, "Should not already be working.");
    u1.flushPassiveEffects();
    local v83, v84;
    if p82 == u20 and l__includesSomeLane__45(p82.expiredLanes, l__NoLanes__111) then
        v83 = l__NoLanes__111;
        v84 = u18.renderRootSync(p82, v83);
        if l__includesSomeLane__45(l__NoLanes__112, l__NoLanes__115) then
            v83 = l__getNextLanes__54(p82, v83);
            v84 = u18.renderRootSync(p82, v83);
        end;
    else
        v83 = l__getNextLanes__54(p82, l__ReactFiberLane__5.NoLanes);
        v84 = u18.renderRootSync(p82, v83);
    end;
    if p82.tag ~= l__LegacyRoot__37 and v84 == 2 then
        u19 = bit32.bor(u19, 64);
        if p82.hydrate then
            p82.hydrate = false;
            l__ReactFiberHostConfig__34.clearContainer(p82.containerInfo);
        end;
        v83 = l__getLanesToRetrySynchronouslyOnError__59(p82);
        if v83 ~= l__ReactFiberLane__5.NoLanes then
            v84 = u18.renderRootSync(p82, v83);
        end;
    end;
    if v84 == 1 then
        local v85 = u24;
        u18.prepareFreshStack(p82, l__ReactFiberLane__5.NoLanes);
        u18.markRootSuspended(p82, v83);
        u8(p82, l__now__22());
        error(v85);
    end;
    p82.finishedWork = p82.current.alternate;
    p82.finishedLanes = v83;
    u18.commitRoot(p82);
    u8(p82, l__now__22());
    return nil;
end;
function u1.flushRoot(p86, p87) --[[ Line: 1151 ]]
    -- upvalues: l__markRootExpired__64 (copy), u8 (ref), l__now__22 (copy), u19 (ref), u27 (ref), l__flushSyncCallbackQueue__27 (copy)
    l__markRootExpired__64(p86, p87);
    u8(p86, l__now__22());
    if bit32.band(u19, 48) == 0 then
        u27 = l__now__22() + 500;
        l__flushSyncCallbackQueue__27();
    end;
end;
function u1.getExecutionContext() --[[ Line: 1163 ]]
    -- upvalues: u19 (ref)
    return u19;
end;
function u1.flushDiscreteUpdates() --[[ Line: 1167 ]]
    -- upvalues: u19 (ref), l____DEV____1 (copy), l__console__3 (copy), u18 (copy), u1 (copy)
    if bit32.band(u19, 49) == 0 then
        u18.flushPendingDiscreteUpdates();
        u1.flushPassiveEffects();
    else
        if l____DEV____1 and bit32.band(u19, 16) ~= 0 then
            l__console__3.error("unstable_flushDiscreteUpdates: Cannot flush updates when React is already rendering.");
        end;
    end;
end;
function u1.deferredUpdates(p88) --[[ Line: 1197 ]]
    -- upvalues: l__ReactFeatureFlags__7 (copy), l__getCurrentUpdateLanePriority__57 (copy), l____YOLO____2 (copy), l__setCurrentUpdateLanePriority__56 (copy), l__ReactFiberLane__5 (copy), l__runWithPriority__19 (copy), l__describeError__13 (copy), l__NormalPriority__26 (copy)
    if not l__ReactFeatureFlags__7.decoupleUpdatePriorityFromScheduler then
        return l__runWithPriority__19(l__NormalPriority__26, p88);
    end;
    local v89 = l__getCurrentUpdateLanePriority__57();
    local v90, v91;
    if l____YOLO____2 then
        l__setCurrentUpdateLanePriority__56(l__ReactFiberLane__5.DefaultLanePriority);
        v90 = l__runWithPriority__19(l__NormalPriority__26, p88);
        v91 = true;
    else
        l__setCurrentUpdateLanePriority__56(l__ReactFiberLane__5.DefaultLanePriority);
        v91, v90 = xpcall(l__runWithPriority__19, l__describeError__13, l__NormalPriority__26, p88);
    end;
    l__setCurrentUpdateLanePriority__56(v89);
    if v91 then
        return v90;
    end;
    error(v90);
end;
function u18.flushPendingDiscreteUpdates() --[[ Line: 1226 ]]
    -- upvalues: u35 (ref), l__markDiscreteUpdatesExpired__65 (copy), u8 (ref), l__now__22 (copy), l__flushSyncCallbackQueue__27 (copy)
    if u35 ~= nil then
        local v92 = u35;
        u35 = nil;
        v92:forEach(function(p93) --[[ Line: 1232 ]]
            -- upvalues: l__markDiscreteUpdatesExpired__65 (ref), u8 (ref), l__now__22 (ref)
            l__markDiscreteUpdatesExpired__65(p93);
            u8(p93, l__now__22());
        end);
    end;
    l__flushSyncCallbackQueue__27();
end;
function u1.batchedUpdates(p94, p95) --[[ Line: 1241 ]]
    -- upvalues: u19 (ref), l____YOLO____2 (copy), l__describeError__13 (copy), u27 (ref), l__now__22 (copy), l__flushSyncCallbackQueue__27 (copy)
    local v96 = u19;
    u19 = bit32.bor(u19, 1);
    local v97, v98;
    if l____YOLO____2 then
        v97 = p94(p95);
        v98 = true;
    else
        v98, v97 = xpcall(p94, l__describeError__13, p95);
    end;
    u19 = v96;
    if u19 == 0 then
        u27 = l__now__22() + 500;
        l__flushSyncCallbackQueue__27();
    end;
    if v98 then
        return v97;
    end;
    error(v97);
end;
function u1.batchedEventUpdates(p99, p100) --[[ Line: 1269 ]]
    -- upvalues: u19 (ref), l____YOLO____2 (copy), l__describeError__13 (copy), u27 (ref), l__now__22 (copy), l__flushSyncCallbackQueue__27 (copy)
    local v101 = u19;
    u19 = bit32.bor(u19, 2);
    local v102, v103;
    if l____YOLO____2 then
        v102 = p99(p100);
        v103 = true;
    else
        v103, v102 = xpcall(p99, l__describeError__13, p100);
    end;
    u19 = v101;
    if u19 == 0 then
        u27 = l__now__22() + 500;
        l__flushSyncCallbackQueue__27();
    end;
    if v103 then
        return v102;
    end;
    error(v102);
end;
function u1.discreteUpdates(u104, u105, u106, u107, u108) --[[ Line: 1298 ]]
    -- upvalues: u19 (ref), l__ReactFeatureFlags__7 (copy), l__getCurrentUpdateLanePriority__57 (copy), l__setCurrentUpdateLanePriority__56 (copy), l__ReactFiberLane__5 (copy), l__runWithPriority__19 (copy), l__describeError__13 (copy), l__UserBlockingPriority__25 (copy), u27 (ref), l__now__22 (copy), l__flushSyncCallbackQueue__27 (copy)
    local v109 = u19;
    u19 = bit32.bor(u19, 4);
    if l__ReactFeatureFlags__7.decoupleUpdatePriorityFromScheduler then
        local v110 = l__getCurrentUpdateLanePriority__57();
        l__setCurrentUpdateLanePriority__56(l__ReactFiberLane__5.InputDiscreteLanePriority);
        local v111, v112 = xpcall(l__runWithPriority__19, l__describeError__13, l__UserBlockingPriority__25, function() --[[ Line: 1310 ]]
            -- upvalues: u104 (copy), u105 (copy), u106 (copy), u107 (copy), u108 (copy)
            return u104(u105, u106, u107, u108);
        end);
        l__setCurrentUpdateLanePriority__56(v110);
        u19 = v109;
        if u19 == 0 then
            u27 = l__now__22() + 500;
            l__flushSyncCallbackQueue__27();
        end;
        if v111 then
            return v112;
        end;
        error(v112);
    else
        local v113, v114 = xpcall(l__runWithPriority__19, l__describeError__13, l__UserBlockingPriority__25, function() --[[ Line: 1334 ]]
            -- upvalues: u104 (copy), u105 (copy), u106 (copy), u107 (copy), u108 (copy)
            return u104(u105, u106, u107, u108);
        end);
        u19 = v109;
        if u19 == 0 then
            u27 = l__now__22() + 500;
            l__flushSyncCallbackQueue__27();
        end;
        if v113 then
            return v114;
        end;
        error(v114);
    end;
end;
function u1.unbatchedUpdates(p115, p116) --[[ Line: 1355 ]]
    -- upvalues: u19 (ref), l____YOLO____2 (copy), l__describeError__13 (copy), u27 (ref), l__now__22 (copy), l__flushSyncCallbackQueue__27 (copy)
    local v117 = u19;
    u19 = bit32.band(u19, 4294967294);
    u19 = bit32.bor(u19, 8);
    local v118, v119;
    if l____YOLO____2 then
        v118 = p115(p116);
        v119 = true;
    else
        v119, v118 = xpcall(p115, l__describeError__13, p116);
    end;
    u19 = v117;
    if u19 == 0 then
        u27 = l__now__22() + 500;
        l__flushSyncCallbackQueue__27();
    end;
    if v119 then
        return v118;
    end;
    error(v118);
end;
function u1.flushSync(u120, u121) --[[ Line: 1383 ]]
    -- upvalues: u19 (ref), l____DEV____1 (copy), l__console__3 (copy), l__ReactFeatureFlags__7 (copy), l__getCurrentUpdateLanePriority__57 (copy), l__setCurrentUpdateLanePriority__56 (copy), l__ReactFiberLane__5 (copy), l____YOLO____2 (copy), l__runWithPriority__19 (copy), l__describeError__13 (copy), l__ImmediatePriority__24 (copy), l__flushSyncCallbackQueue__27 (copy)
    local v122 = u19;
    if bit32.band(v122, 48) ~= 0 then
        if l____DEV____1 then
            l__console__3.error("flushSync was called from inside a lifecycle method. React cannot flush when React is already rendering. Consider moving this call to a scheduler task or micro task.");
        end;
        return u120(u121);
    end;
    u19 = bit32.bor(u19, 1);
    if not l__ReactFeatureFlags__7.decoupleUpdatePriorityFromScheduler then
        local v123, v124;
        if l____YOLO____2 then
            v123 = true;
            if u120 then
                v124 = l__runWithPriority__19(l__ImmediatePriority__24, function() --[[ Line: 1468 ]]
                    -- upvalues: u120 (copy), u121 (copy)
                    return u120(u121);
                end);
            else
                v124 = nil;
            end;
        elseif u120 then
            v123, v124 = xpcall(l__runWithPriority__19, l__describeError__13, l__ImmediatePriority__24, function() --[[ Line: 1456 ]]
                -- upvalues: u120 (copy), u121 (copy)
                return u120(u121);
            end);
        else
            v123 = true;
            v124 = nil;
        end;
        u19 = v122;
        l__flushSyncCallbackQueue__27();
        if not v123 then
            error(v124);
        end;
        return v124;
    end;
    local v125 = l__getCurrentUpdateLanePriority__57();
    l__setCurrentUpdateLanePriority__56(l__ReactFiberLane__5.SyncLanePriority);
    local v126, v127;
    if l____YOLO____2 then
        v126 = true;
        l__setCurrentUpdateLanePriority__56(l__ReactFiberLane__5.SyncLanePriority);
        if u120 then
            v127 = l__runWithPriority__19(l__ImmediatePriority__24, function() --[[ Line: 1426 ]]
                -- upvalues: u120 (copy), u121 (copy)
                return u120(u121);
            end);
        else
            v127 = nil;
        end;
    elseif u120 then
        v126, v127 = xpcall(l__runWithPriority__19, l__describeError__13, l__ImmediatePriority__24, function() --[[ Line: 1413 ]]
            -- upvalues: u120 (copy), u121 (copy)
            return u120(u121);
        end);
    else
        v126 = true;
        v127 = nil;
    end;
    l__setCurrentUpdateLanePriority__56(v125);
    u19 = v122;
    l__flushSyncCallbackQueue__27();
    if not v126 then
        error(v127);
    end;
    return v127;
end;
function u1.flushControlled(p128) --[[ Line: 1489 ]]
    -- upvalues: u19 (ref), l__ReactFeatureFlags__7 (copy), l__getCurrentUpdateLanePriority__57 (copy), l__setCurrentUpdateLanePriority__56 (copy), l__ReactFiberLane__5 (copy), l__runWithPriority__19 (copy), l__describeError__13 (copy), l__ImmediatePriority__24 (copy), u27 (ref), l__now__22 (copy), l__flushSyncCallbackQueue__27 (copy)
    local v129 = u19;
    u19 = bit32.bor(u19, 1);
    if l__ReactFeatureFlags__7.decoupleUpdatePriorityFromScheduler then
        local v130 = l__getCurrentUpdateLanePriority__57();
        l__setCurrentUpdateLanePriority__56(l__ReactFiberLane__5.SyncLanePriority);
        local v131, v132 = xpcall(l__runWithPriority__19, l__describeError__13, l__ImmediatePriority__24, p128);
        l__setCurrentUpdateLanePriority__56(v130);
        u19 = v129;
        if u19 == 0 then
            u27 = l__now__22() + 500;
            l__flushSyncCallbackQueue__27();
        end;
        if not v131 then
            error(v132);
        end;
    else
        local v133, v134 = xpcall(l__runWithPriority__19, l__describeError__13, l__ImmediatePriority__24, p128);
        u19 = v129;
        if u19 == 0 then
            u27 = l__now__22() + 500;
            l__flushSyncCallbackQueue__27();
        end;
        if not v133 then
            error(v134);
        end;
    end;
end;
function u1.pushRenderLanes(p135, p136) --[[ Line: 1529 ]]
    -- upvalues: l__push__92 (copy), u22 (copy), u1 (copy), l__mergeLanes__47 (copy), l__NoLanes__112 (ref)
    l__push__92(u22, u1.subtreeRenderLanes, p135);
    u1.subtreeRenderLanes = l__mergeLanes__47(u1.subtreeRenderLanes, p136);
    l__NoLanes__112 = l__mergeLanes__47(l__NoLanes__112, p136);
end;
function u1.popRenderLanes(p137) --[[ Line: 1535 ]]
    -- upvalues: u1 (copy), u22 (copy), l__pop__93 (copy)
    u1.subtreeRenderLanes = u22.current;
    l__pop__93(u22, p137);
end;
function u18.prepareFreshStack(p138, p139) --[[ Line: 1540 ]]
    -- upvalues: l__ReactFiberLane__5 (copy), l__ReactFiberHostConfig__34 (copy), u21 (ref), l__unwindInterruptedWork__71 (copy), u20 (ref), u4 (copy), l__NoLanes__111 (ref), u1 (copy), l__NoLanes__112 (ref), u23 (ref), u24 (ref), l__workInProgressRootSkippedLanes__114 (copy), l__NoLanes__115 (ref), l__NoLanes__116 (ref), l__ReactFeatureFlags__7 (copy), u39 (ref), l____DEV____1 (copy), u16 (copy)
    p138.finishedWork = nil;
    p138.finishedLanes = l__ReactFiberLane__5.NoLanes;
    local l__timeoutHandle__131 = p138.timeoutHandle;
    if l__timeoutHandle__131 ~= l__ReactFiberHostConfig__34.noTimeout then
        p138.timeoutHandle = l__ReactFiberHostConfig__34.noTimeout;
        l__ReactFiberHostConfig__34.cancelTimeout(l__timeoutHandle__131);
    end;
    if u21 ~= nil then
        local l__return___132 = u21.return_;
        while l__return___132 ~= nil do
            l__unwindInterruptedWork__71(l__return___132);
            l__return___132 = l__return___132.return_;
        end;
    end;
    u20 = p138;
    u21 = u4.createWorkInProgress(p138.current, nil);
    l__NoLanes__111 = p139;
    u1.subtreeRenderLanes = p139;
    l__NoLanes__112 = p139;
    u23 = 0;
    u24 = nil;
    l__workInProgressRootSkippedLanes__114(l__ReactFiberLane__5.NoLanes);
    l__NoLanes__115 = l__ReactFiberLane__5.NoLanes;
    l__NoLanes__116 = l__ReactFiberLane__5.NoLanes;
    if l__ReactFeatureFlags__7.enableSchedulerTracing then
        u39 = nil;
    end;
    if l____DEV____1 then
        u16.discardPendingWarnings();
    end;
end;
function u18.handleError(u140, u141) --[[ Line: 1580 ]]
    -- upvalues: u21 (ref), l__resetContextDependencies__90 (copy), u9 (copy), u14 (ref), l__resetCurrentFiber__98 (copy), l__ReactCurrentOwner__109 (copy), u23 (ref), u24 (ref), l__ReactFeatureFlags__7 (copy), l__ReactTypeOfMode__35 (copy), u15 (copy), l__throwException__72 (copy), l__NoLanes__111 (ref), u1 (copy), u18 (copy)
    while true do
        local u142 = u21;
        local v143, v144 = pcall(function() --[[ Line: 1584 ]]
            -- upvalues: l__resetContextDependencies__90 (ref), u9 (ref), u14 (ref), l__resetCurrentFiber__98 (ref), l__ReactCurrentOwner__109 (ref), u142 (ref), u23 (ref), u24 (ref), u141 (ref), u21 (ref), l__ReactFeatureFlags__7 (ref), l__ReactTypeOfMode__35 (ref), u15 (ref), l__throwException__72 (ref), u140 (copy), l__NoLanes__111 (ref), u1 (ref), u18 (ref)
            l__resetContextDependencies__90();
            if not u9.resetHooksAfterThrowRef then
                u14 = require(script.Parent:WaitForChild("ReactFiberHooks.new"));
                u9.resetHooksAfterThrowRef = u14.resetHooksAfterThrow;
                u9.ContextOnlyDispatcherRef = u14.ContextOnlyDispatcher;
                u9.getIsUpdatingOpaqueValueInRenderPhaseInDEVRef = u14.getIsUpdatingOpaqueValueInRenderPhaseInDEV;
            end;
            u9.resetHooksAfterThrowRef();
            l__resetCurrentFiber__98();
            l__ReactCurrentOwner__109.current = nil;
            if u142 == nil or u142.return_ == nil then
                u23 = 1;
                u24 = u141;
                u21 = nil;
            else
                if l__ReactFeatureFlags__7.enableProfilerTimer and bit32.band(u142.mode, l__ReactTypeOfMode__35.ProfileMode) ~= 0 then
                    u15.stopProfilerTimerIfRunningAndRecordDelta(u142, true);
                end;
                l__throwException__72(u140, u142.return_, u142, u141, l__NoLanes__111, u1.onUncaughtError, u1.renderDidError);
                u18.completeUnitOfWork(u142);
            end;
        end);
        if v143 then
            break;
        end;
        u141 = v144;
        if u21 == u142 and u142 ~= nil then
            u142 = u142.return_;
            u21 = u142;
        else
            u142 = u21;
        end;
    end;
end;
function u18.pushDispatcher() --[[ Line: 1659 ]]
    -- upvalues: l__ReactCurrentDispatcher__108 (copy), u9 (copy), u14 (ref)
    local l__current__133 = l__ReactCurrentDispatcher__108.current;
    local v145 = l__ReactCurrentDispatcher__108;
    if not u9.ContextOnlyDispatcherRef then
        u14 = require(script.Parent:WaitForChild("ReactFiberHooks.new"));
        u9.resetHooksAfterThrowRef = u14.resetHooksAfterThrow;
        u9.ContextOnlyDispatcherRef = u14.ContextOnlyDispatcher;
        u9.getIsUpdatingOpaqueValueInRenderPhaseInDEVRef = u14.getIsUpdatingOpaqueValueInRenderPhaseInDEV;
    end;
    v145.current = u9.ContextOnlyDispatcherRef;
    if l__current__133 ~= nil then
        return l__current__133;
    end;
    if not u9.ContextOnlyDispatcherRef then
        u14 = require(script.Parent:WaitForChild("ReactFiberHooks.new"));
        u9.resetHooksAfterThrowRef = u14.resetHooksAfterThrow;
        u9.ContextOnlyDispatcherRef = u14.ContextOnlyDispatcher;
        u9.getIsUpdatingOpaqueValueInRenderPhaseInDEVRef = u14.getIsUpdatingOpaqueValueInRenderPhaseInDEV;
    end;
    return u9.ContextOnlyDispatcherRef;
end;
function u18.popDispatcher(p146) --[[ Line: 1676 ]]
    -- upvalues: l__ReactCurrentDispatcher__108 (copy)
    l__ReactCurrentDispatcher__108.current = p146;
end;
function u18.pushInteractions(p147) --[[ Line: 1680 ]]
    -- upvalues: l__ReactFeatureFlags__7 (copy), l____interactionsRef__32 (copy)
    if not l__ReactFeatureFlags__7.enableSchedulerTracing then
        return nil;
    end;
    local l__current__134 = l____interactionsRef__32.current;
    l____interactionsRef__32.current = p147.memoizedInteractions;
    return l__current__134;
end;
function u18.popInteractions(p148) --[[ Line: 1689 ]]
    -- upvalues: l__ReactFeatureFlags__7 (copy), l____interactionsRef__32 (copy)
    if l__ReactFeatureFlags__7.enableSchedulerTracing then
        l____interactionsRef__32.current = p148;
    end;
end;
function u1.markCommitTimeOfFallback() --[[ Line: 1695 ]]
    -- upvalues: u26 (ref), l__now__22 (copy)
    u26 = l__now__22();
end;
function u1.markSkippedUpdateLanes(p149) --[[ Line: 1699 ]]
    -- upvalues: l__ReactFiberWorkInProgress__113 (copy)
    l__ReactFiberWorkInProgress__113.markSkippedUpdateLanes(p149);
end;
function u1.renderDidSuspend() --[[ Line: 1703 ]]
    -- upvalues: u23 (ref)
    if u23 == 0 then
        u23 = 3;
    end;
end;
function u1.renderDidSuspendDelayIfPossible() --[[ Line: 1709 ]]
    -- upvalues: u23 (ref), u20 (ref), l__includesNonIdleWork__51 (copy), l__workInProgressRootSkippedLanes__114 (copy), l__NoLanes__115 (ref), u18 (copy), l__NoLanes__111 (ref)
    if u23 == 0 or u23 == 3 then
        u23 = 4;
    end;
    if u20 ~= nil and (l__includesNonIdleWork__51(l__workInProgressRootSkippedLanes__114()) or l__includesNonIdleWork__51(l__NoLanes__115)) then
        u18.markRootSuspended(u20, l__NoLanes__111);
    end;
end;
function u1.renderDidError() --[[ Line: 1737 ]]
    -- upvalues: u23 (ref)
    if u23 ~= 5 then
        u23 = 2;
    end;
end;
function u1.renderHasNotSuspendedYet() --[[ Line: 1745 ]]
    -- upvalues: u23 (ref)
    return u23 == 0;
end;
function u18.renderRootSync(p150, p151) --[[ Line: 1751 ]]
    -- upvalues: u19 (ref), u18 (copy), u20 (ref), l__NoLanes__111 (ref), l____DEV____1 (copy), l__enableDebugTracing__8 (copy), l__DebugTracing__29 (copy), l__enableSchedulingProfiler__9 (copy), l__SchedulingProfiler__30 (copy), l____YOLO____2 (copy), l__describeError__13 (copy), l__resetContextDependencies__90 (copy), l__ReactFeatureFlags__7 (copy), u21 (ref), l__invariant__15 (copy), l__ReactFiberLane__5 (copy), u23 (ref)
    local v152 = u19;
    u19 = bit32.bor(u19, 16);
    local v153 = u18.pushDispatcher();
    if u20 ~= p150 or l__NoLanes__111 ~= p151 then
        u18.prepareFreshStack(p150, p151);
        u18.startWorkOnPendingInteractions(p150, p151);
    end;
    local v154 = u18.pushInteractions(p150);
    if l____DEV____1 and l__enableDebugTracing__8 then
        l__DebugTracing__29.logRenderStarted(p151);
    end;
    if l__enableSchedulingProfiler__9 then
        l__SchedulingProfiler__30.markRenderStarted(p151);
    end;
    while true do
        local v155 = nil;
        local v156;
        if l____YOLO____2 then
            u18.workLoopSync();
            v156 = true;
        else
            v156, v155 = xpcall(u18.workLoopSync, l__describeError__13);
        end;
        if v156 then
            l__resetContextDependencies__90();
            if l__ReactFeatureFlags__7.enableSchedulerTracing then
                u18.popInteractions(v154);
            end;
            u19 = v152;
            u18.popDispatcher(v153);
            if u21 ~= nil then
                l__invariant__15(false, "Cannot commit an incomplete root. This error is likely caused by a bug in React. Please file an issue.");
            end;
            if l____DEV____1 and l__enableDebugTracing__8 then
                l__DebugTracing__29.logRenderStopped();
            end;
            if l__enableSchedulingProfiler__9 then
                l__SchedulingProfiler__30.markRenderStopped();
            end;
            u20 = nil;
            l__NoLanes__111 = l__ReactFiberLane__5.NoLanes;
            return u23;
        end;
        u18.handleError(p150, v155);
    end;
end;
function u18.workLoopSync() --[[ Line: 1827 ]]
    -- upvalues: u21 (ref), u18 (copy)
    while u21 ~= nil do
        u18.performUnitOfWork(u21);
    end;
end;
function u18.renderRootConcurrent(p157, p158) --[[ Line: 1834 ]]
    -- upvalues: u19 (ref), u18 (copy), u20 (ref), l__NoLanes__111 (ref), u27 (ref), l__now__22 (copy), l____DEV____1 (copy), l__enableDebugTracing__8 (copy), l__DebugTracing__29 (copy), l__enableSchedulingProfiler__9 (copy), l__SchedulingProfiler__30 (copy), l____YOLO____2 (copy), l__describeError__13 (copy), l__resetContextDependencies__90 (copy), l__ReactFeatureFlags__7 (copy), u21 (ref), l__ReactFiberLane__5 (copy), u23 (ref)
    local v159 = u19;
    u19 = bit32.bor(u19, 16);
    local v160 = u18.pushDispatcher();
    if u20 ~= p157 or l__NoLanes__111 ~= p158 then
        u27 = l__now__22() + 500;
        u18.prepareFreshStack(p157, p158);
        u18.startWorkOnPendingInteractions(p157, p158);
    end;
    local v161 = u18.pushInteractions(p157);
    if l____DEV____1 and l__enableDebugTracing__8 then
        l__DebugTracing__29.logRenderStarted(p158);
    end;
    if l__enableSchedulingProfiler__9 then
        l__SchedulingProfiler__30.markRenderStarted(p158);
    end;
    while true do
        local v162, v163;
        if l____YOLO____2 then
            u18.workLoopConcurrent();
            v162 = "break";
            v163 = true;
        else
            v163, v162 = xpcall(u18.workLoopConcurrent, l__describeError__13);
            if v163 then
                v162 = "break";
            end;
        end;
        if v162 == "break" then
            l__resetContextDependencies__90();
            if l__ReactFeatureFlags__7.enableSchedulerTracing then
                u18.popInteractions(v161);
            end;
            u18.popDispatcher(v160);
            u19 = v159;
            if l____DEV____1 and l__enableDebugTracing__8 then
                l__DebugTracing__29.logRenderStopped();
            end;
            if u21 ~= nil then
                if l__enableSchedulingProfiler__9 then
                    l__SchedulingProfiler__30.markRenderYielded();
                end;
                return 0;
            end;
            if l__enableSchedulingProfiler__9 then
                l__SchedulingProfiler__30.markRenderStopped();
            end;
            u20 = nil;
            l__NoLanes__111 = l__ReactFiberLane__5.NoLanes;
            return u23;
        end;
        if not v163 then
            u18.handleError(p157, v162);
        end;
    end;
end;
function u18.workLoopConcurrent() --[[ Line: 1918 ]]
    -- upvalues: u21 (ref), l__shouldYield__20 (copy), u18 (copy)
    while u21 ~= nil and not l__shouldYield__20() do
        u18.performUnitOfWork(u21);
    end;
end;
function u18.performUnitOfWork(p164) --[[ Line: 1925 ]]
    -- upvalues: l__setCurrentFiber__99 (copy), l__ReactFeatureFlags__7 (copy), l__ReactTypeOfMode__35 (copy), u15 (copy), u18 (copy), u1 (copy), l__resetCurrentFiber__98 (copy), u21 (ref), l__ReactCurrentOwner__109 (copy)
    local l__alternate__135 = p164.alternate;
    l__setCurrentFiber__99(p164);
    local v165;
    if l__ReactFeatureFlags__7.enableProfilerTimer and bit32.band(p164.mode, l__ReactTypeOfMode__35.ProfileMode) ~= l__ReactTypeOfMode__35.NoMode then
        u15.startProfilerTimer(p164);
        v165 = u18.beginWork(l__alternate__135, p164, u1.subtreeRenderLanes);
        u15.stopProfilerTimerIfRunningAndRecordDelta(p164, true);
    else
        v165 = u18.beginWork(l__alternate__135, p164, u1.subtreeRenderLanes);
    end;
    l__resetCurrentFiber__98();
    p164.memoizedProps = p164.pendingProps;
    if v165 == nil then
        u18.completeUnitOfWork(p164);
    else
        u21 = v165;
    end;
    l__ReactCurrentOwner__109.current = nil;
end;
function u18.completeUnitOfWork(p166) --[[ Line: 1957 ]]
    -- upvalues: l__ReactFiberFlags__38 (copy), l__setCurrentFiber__99 (copy), l__ReactFeatureFlags__7 (copy), l__ReactTypeOfMode__35 (copy), u1 (copy), u9 (copy), u15 (copy), l__resetCurrentFiber__98 (copy), u21 (ref), l__unwindWork__70 (copy), u23 (ref)
    while true do
        local l__alternate__136 = p166.alternate;
        local l__return___137 = p166.return_;
        if bit32.band(p166.flags, l__ReactFiberFlags__38.Incomplete) == l__ReactFiberFlags__38.NoFlags then
            l__setCurrentFiber__99(p166);
            local v167;
            if l__ReactFeatureFlags__7.enableProfilerTimer and bit32.band(p166.mode, l__ReactTypeOfMode__35.ProfileMode) ~= l__ReactTypeOfMode__35.NoMode then
                u15.startProfilerTimer(p166);
                local l__subtreeRenderLanes__138 = u1.subtreeRenderLanes;
                if not u9.completeWorkRef then
                    u9.completeWorkRef = require(script.Parent:WaitForChild("ReactFiberCompleteWork.new")).completeWork;
                end;
                v167 = u9.completeWorkRef(l__alternate__136, p166, l__subtreeRenderLanes__138);
                u15.stopProfilerTimerIfRunningAndRecordDelta(p166, false);
            else
                local l__subtreeRenderLanes__139 = u1.subtreeRenderLanes;
                if not u9.completeWorkRef then
                    u9.completeWorkRef = require(script.Parent:WaitForChild("ReactFiberCompleteWork.new")).completeWork;
                end;
                v167 = u9.completeWorkRef(l__alternate__136, p166, l__subtreeRenderLanes__139);
            end;
            l__resetCurrentFiber__98();
            if v167 ~= nil then
                u21 = v167;
                return;
            end;
        else
            local v168 = l__unwindWork__70(p166, u1.subtreeRenderLanes);
            if v168 ~= nil then
                v168.flags = bit32.band(v168.flags, l__ReactFiberFlags__38.HostEffectMask);
                u21 = v168;
                return;
            end;
            if l__ReactFeatureFlags__7.enableProfilerTimer and bit32.band(p166.mode, l__ReactTypeOfMode__35.ProfileMode) ~= l__ReactTypeOfMode__35.NoMode then
                u15.stopProfilerTimerIfRunningAndRecordDelta(p166, false);
                local v169 = p166.actualDuration or 0;
                local l__child__140 = p166.child;
                while l__child__140 ~= nil do
                    v169 = v169 + (l__child__140.actualDuration or 0);
                    l__child__140 = l__child__140.sibling;
                end;
                p166.actualDuration = v169;
            end;
            if l__return___137 ~= nil then
                l__return___137.flags = bit32.bor(l__return___137.flags, l__ReactFiberFlags__38.Incomplete);
                l__return___137.subtreeFlags = l__ReactFiberFlags__38.NoFlags;
                l__return___137.deletions = nil;
            end;
        end;
        local l__sibling__141 = p166.sibling;
        if l__sibling__141 ~= nil then
            u21 = l__sibling__141;
            return;
        end;
        u21 = l__return___137;
        if l__return___137 == nil then
            if u23 == 0 then
                u23 = 5;
            end;
            return;
        end;
        p166 = l__return___137;
    end;
end;
function u18.commitRoot(u170) --[[ Line: 2065 ]]
    -- upvalues: l__getCurrentPriorityLevel__18 (copy), l__runWithPriority__19 (copy), l__ImmediatePriority__24 (copy), u18 (copy)
    local u171 = l__getCurrentPriorityLevel__18();
    l__runWithPriority__19(l__ImmediatePriority__24, function() --[[ Line: 2067 ]]
        -- upvalues: u18 (ref), u170 (copy), u171 (copy)
        return u18.commitRootImpl(u170, u171);
    end);
    return nil;
end;
function u18.commitRootImpl(p172, p173) --[[ Line: 2074 ]]
    -- upvalues: u1 (copy), u33 (ref), l__invariant__15 (copy), u19 (ref), l____DEV____1 (copy), l__enableDebugTracing__8 (copy), l__DebugTracing__29 (copy), l__enableSchedulingProfiler__9 (copy), l__SchedulingProfiler__30 (copy), l__ReactFiberLane__5 (copy), l__mergeLanes__47 (copy), l__markRootFinished__66 (copy), u35 (ref), l__hasDiscreteLanes__50 (copy), u20 (ref), u21 (ref), l__NoLanes__111 (ref), l__ReactFiberFlags__38 (copy), l__ReactFeatureFlags__7 (copy), l__getCurrentUpdateLanePriority__57 (copy), l__setCurrentUpdateLanePriority__56 (copy), u18 (copy), l__ReactCurrentOwner__109 (copy), u41 (ref), l__ReactFiberHostConfig__34 (copy), u42 (ref), u15 (copy), l__setCurrentFiber__99 (copy), l__invokeGuardedCallback__101 (copy), l__recursivelyCommitLayoutEffects__87 (copy), l__hasCaughtError__102 (copy), l__clearCaughtError__103 (copy), u17 (ref), l__resetCurrentFiber__98 (copy), l____YOLO____2 (copy), l__describeError__13 (copy), u32 (ref), l__scheduleCallback__16 (copy), l__NormalPriority__26 (copy), l__requestPaint__21 (copy), l__NoLanes__117 (ref), u34 (ref), u39 (ref), u31 (ref), l__enableDoubleInvokingEffects__11 (copy), l__SyncLane__39 (copy), u37 (ref), u36 (ref), l__onCommitRoot__104 (copy), l__onCommitRoot__105 (copy), u8 (ref), l__now__22 (copy), u29 (ref), u30 (ref), l__flushSyncCallbackQueue__27 (copy)
    repeat
        u1.flushPassiveEffects();
    until u33 == nil;
    flushRenderPhaseStrictModeWarningsInDEV();
    l__invariant__15(bit32.band(u19, 48) == 0, "Should not already be working.");
    local l__finishedWork__142 = p172.finishedWork;
    local l__finishedLanes__143 = p172.finishedLanes;
    if l____DEV____1 and l__enableDebugTracing__8 then
        l__DebugTracing__29.logCommitStarted(l__finishedLanes__143);
    end;
    if l__enableSchedulingProfiler__9 then
        l__SchedulingProfiler__30.markCommitStarted(l__finishedLanes__143);
    end;
    if l__finishedWork__142 == nil then
        if l____DEV____1 and l__enableDebugTracing__8 then
            l__DebugTracing__29.logCommitStopped();
        end;
        if l__enableSchedulingProfiler__9 then
            l__SchedulingProfiler__30.markCommitStopped();
        end;
        return nil;
    end;
    p172.finishedWork = nil;
    p172.finishedLanes = l__ReactFiberLane__5.NoLanes;
    l__invariant__15(l__finishedWork__142 ~= p172.current, "Cannot commit the same tree as before. This error is likely caused by a bug in React. Please file an issue.");
    p172.callbackNode = nil;
    local v174 = l__mergeLanes__47(l__finishedWork__142.lanes, l__finishedWork__142.childLanes);
    l__markRootFinished__66(p172, v174);
    if u35 ~= nil and (not l__hasDiscreteLanes__50(v174) and u35:has(p172)) then
        u35:delete(p172);
    end;
    if p172 == u20 then
        u20 = nil;
        u21 = nil;
        l__NoLanes__111 = l__ReactFiberLane__5.NoLanes;
    end;
    local l__subtreeFlags__144 = l__finishedWork__142.subtreeFlags;
    local v175 = bit32.bor(l__ReactFiberFlags__38.BeforeMutationMask, l__ReactFiberFlags__38.MutationMask, l__ReactFiberFlags__38.LayoutMask, l__ReactFiberFlags__38.PassiveMask);
    local v176 = bit32.band(l__subtreeFlags__144, v175) ~= l__ReactFiberFlags__38.NoFlags;
    local l__flags__145 = l__finishedWork__142.flags;
    local v177 = bit32.bor(l__ReactFiberFlags__38.BeforeMutationMask, l__ReactFiberFlags__38.MutationMask, l__ReactFiberFlags__38.LayoutMask, l__ReactFiberFlags__38.PassiveMask);
    if v176 or bit32.band(l__flags__145, v177) ~= l__ReactFiberFlags__38.NoFlags then
        local v178;
        if l__ReactFeatureFlags__7.decoupleUpdatePriorityFromScheduler then
            v178 = l__getCurrentUpdateLanePriority__57();
            l__setCurrentUpdateLanePriority__56(l__ReactFiberLane__5.SyncLanePriority);
        else
            v178 = nil;
        end;
        local v179 = u19;
        u19 = bit32.bor(u19, 32);
        local v180 = u18.pushInteractions(p172);
        l__ReactCurrentOwner__109.current = nil;
        u41 = l__ReactFiberHostConfig__34.prepareForCommit(p172.containerInfo);
        u42 = false;
        u18.commitBeforeMutationEffects(l__finishedWork__142);
        u41 = nil;
        if l__ReactFeatureFlags__7.enableProfilerTimer then
            u15.recordCommitTime();
        end;
        u18.commitMutationEffects(l__finishedWork__142, p172, p173);
        if u42 then
            l__ReactFiberHostConfig__34.afterActiveInstanceBlur();
        end;
        l__ReactFiberHostConfig__34.resetAfterCommit(p172.containerInfo);
        p172.current = l__finishedWork__142;
        if l____DEV____1 and l__enableDebugTracing__8 then
            l__DebugTracing__29.logLayoutEffectsStarted(l__finishedLanes__143);
        end;
        if l__enableSchedulingProfiler__9 then
            l__SchedulingProfiler__30.markLayoutEffectsStarted(l__finishedLanes__143);
        end;
        if l____DEV____1 then
            l__setCurrentFiber__99(l__finishedWork__142);
            l__invokeGuardedCallback__101(nil, l__recursivelyCommitLayoutEffects__87, nil, l__finishedWork__142, p172, u1.captureCommitPhaseError, u1.schedulePassiveEffectCallback);
            if l__hasCaughtError__102() then
                u17(l__finishedWork__142, l__finishedWork__142, (l__clearCaughtError__103()));
            end;
            l__resetCurrentFiber__98();
        else
            local v181 = nil;
            local v182;
            if l____YOLO____2 then
                l__recursivelyCommitLayoutEffects__87(l__finishedWork__142, p172, u1.captureCommitPhaseError, u1.schedulePassiveEffectCallback);
                v182 = true;
            else
                v182, v181 = xpcall(l__recursivelyCommitLayoutEffects__87, l__describeError__13, l__finishedWork__142, p172, u1.captureCommitPhaseError, u1.schedulePassiveEffectCallback);
            end;
            if not v182 then
                u17(l__finishedWork__142, l__finishedWork__142, v181);
            end;
        end;
        if l____DEV____1 and l__enableDebugTracing__8 then
            l__DebugTracing__29.logLayoutEffectsStopped();
        end;
        if l__enableSchedulingProfiler__9 then
            l__SchedulingProfiler__30.markLayoutEffectsStopped();
        end;
        if (bit32.band(l__finishedWork__142.subtreeFlags, l__ReactFiberFlags__38.PassiveMask) ~= l__ReactFiberFlags__38.NoFlags or bit32.band(l__finishedWork__142.flags, l__ReactFiberFlags__38.PassiveMask) ~= l__ReactFiberFlags__38.NoFlags) and not u32 then
            u32 = true;
            l__scheduleCallback__16(l__NormalPriority__26, function() --[[ Line: 2307 ]]
                -- upvalues: u1 (ref)
                u1.flushPassiveEffects();
                return nil;
            end);
        end;
        l__requestPaint__21();
        if l__ReactFeatureFlags__7.enableSchedulerTracing then
            u18.popInteractions(v180);
        end;
        u19 = v179;
        if l__ReactFeatureFlags__7.decoupleUpdatePriorityFromScheduler and v178 ~= nil then
            l__setCurrentUpdateLanePriority__56(v178);
        end;
    else
        p172.current = l__finishedWork__142;
        if l__ReactFeatureFlags__7.enableProfilerTimer then
            u15.recordCommitTime();
        end;
    end;
    local v183 = u32;
    if u32 then
        u32 = false;
        u33 = p172;
        l__NoLanes__117 = l__finishedLanes__143;
        u34 = p173;
    end;
    local l__pendingLanes__146 = p172.pendingLanes;
    if l__pendingLanes__146 == l__ReactFiberLane__5.NoLanes then
        u31 = nil;
    elseif l__ReactFeatureFlags__7.enableSchedulerTracing then
        if u39 ~= nil then
            local v184 = u39;
            u39 = nil;
            for v185 = 1, #v184 do
                scheduleInteractions(p172, v184[v185], p172.memoizedInteractions);
            end;
        end;
        u18.schedulePendingInteractions(p172, l__pendingLanes__146);
    end;
    if l____DEV____1 and (l__enableDoubleInvokingEffects__11 and not v183) then
        commitDoubleInvokeEffectsInDEV(p172.current, false);
    end;
    if l__ReactFeatureFlags__7.enableSchedulerTracing and not v183 then
        u18.finishPendingInteractions(p172, l__finishedLanes__143);
    end;
    if l__pendingLanes__146 == l__SyncLane__39 then
        if p172 == u37 then
            u36 = u36 + 1;
        else
            u36 = 0;
            u37 = p172;
        end;
    else
        u36 = 0;
    end;
    l__onCommitRoot__104(l__finishedWork__142.stateNode, p173);
    if l____DEV____1 then
        l__onCommitRoot__105();
    end;
    u8(p172, l__now__22());
    if u29 then
        u29 = false;
        local v186 = u30;
        u30 = nil;
        error(v186);
    end;
    if bit32.band(u19, 8) ~= 0 then
        if l____DEV____1 and l__enableDebugTracing__8 then
            l__DebugTracing__29.logCommitStopped();
        end;
        if l__enableSchedulingProfiler__9 then
            l__SchedulingProfiler__30.markCommitStopped();
        end;
        return nil;
    end;
    l__flushSyncCallbackQueue__27();
    if l____DEV____1 and l__enableDebugTracing__8 then
        l__DebugTracing__29.logCommitStopped();
    end;
    if l__enableSchedulingProfiler__9 then
        l__SchedulingProfiler__30.markCommitStopped();
    end;
    return nil;
end;
function u18.commitBeforeMutationEffects(p187) --[[ Line: 2458 ]]
    -- upvalues: u18 (copy), l__ReactFiberFlags__38 (copy), l____DEV____1 (copy), l__setCurrentFiber__99 (copy), l__invokeGuardedCallback__101 (copy), l__hasCaughtError__102 (copy), l__clearCaughtError__103 (copy), u1 (copy), l__resetCurrentFiber__98 (copy), l____YOLO____2 (copy), l__describeError__13 (copy)
    while p187 ~= nil do
        if p187.deletions ~= nil then
            u18.commitBeforeMutationEffectsDeletions(p187.deletions);
        end;
        if p187.child ~= nil and bit32.band(p187.subtreeFlags, l__ReactFiberFlags__38.BeforeMutationMask) ~= l__ReactFiberFlags__38.NoFlags then
            u18.commitBeforeMutationEffects(p187.child);
        end;
        if l____DEV____1 then
            l__setCurrentFiber__99(p187);
            l__invokeGuardedCallback__101(nil, u18.commitBeforeMutationEffectsImpl, nil, p187);
            if l__hasCaughtError__102() then
                local v188 = l__clearCaughtError__103();
                u1.captureCommitPhaseError(p187, p187.return_, v188);
            end;
            l__resetCurrentFiber__98();
        else
            local v189 = nil;
            local v190;
            if l____YOLO____2 then
                u18.commitBeforeMutationEffectsImpl(p187);
                v190 = true;
            else
                v190, v189 = xpcall(u18.commitBeforeMutationEffectsImpl, l__describeError__13, p187);
            end;
            if not v190 then
                u1.captureCommitPhaseError(p187, p187.return_, v189);
            end;
        end;
        p187 = p187.sibling;
    end;
end;
function u18.commitBeforeMutationEffectsImpl(p191) --[[ Line: 2501 ]]
    -- upvalues: u42 (ref), u41 (ref), l__ReactWorkTags__36 (copy), u7 (copy), l__doesFiberContain__107 (copy), l__ReactFiberHostConfig__34 (copy), l__ReactFiberFlags__38 (copy), l__setCurrentFiber__99 (copy), l__commitBeforeMutationLifeCycles__75 (copy), l__resetCurrentFiber__98 (copy), u32 (ref), l__scheduleCallback__16 (copy), l__NormalPriority__26 (copy), u1 (copy)
    local l__alternate__147 = p191.alternate;
    local l__flags__148 = p191.flags;
    if not u42 and (u41 ~= nil and (p191.tag == l__ReactWorkTags__36.SuspenseComponent and (u7.isSuspenseBoundaryBeingHidden(l__alternate__147, p191) and l__doesFiberContain__107(p191, u41)))) then
        u42 = true;
        l__ReactFiberHostConfig__34.beforeActiveInstanceBlur();
    end;
    if bit32.band(l__flags__148, l__ReactFiberFlags__38.Snapshot) ~= l__ReactFiberFlags__38.NoFlags then
        l__setCurrentFiber__99(p191);
        l__commitBeforeMutationLifeCycles__75(l__alternate__147, p191);
        l__resetCurrentFiber__98();
    end;
    if bit32.band(l__flags__148, l__ReactFiberFlags__38.Passive) ~= l__ReactFiberFlags__38.NoFlags and not u32 then
        u32 = true;
        l__scheduleCallback__16(l__NormalPriority__26, function() --[[ Line: 2529 ]]
            -- upvalues: u1 (ref)
            u1.flushPassiveEffects();
            return nil;
        end);
    end;
end;
function u18.commitBeforeMutationEffectsDeletions(p192) --[[ Line: 2537 ]]
    -- upvalues: l__doesFiberContain__107 (copy), u41 (ref), u42 (ref), l__ReactFiberHostConfig__34 (copy)
    for v193 = 1, #p192 do
        if l__doesFiberContain__107(p192[v193], u41) then
            u42 = true;
            l__ReactFiberHostConfig__34.beforeActiveInstanceBlur();
        end;
    end;
end;
function u18.commitMutationEffects(p194, p195, p196) --[[ Line: 2553 ]]
    -- upvalues: l__commitDeletion__78 (copy), l__describeError__13 (copy), u1 (copy), l__ReactFiberFlags__38 (copy), u18 (copy), l____DEV____1 (copy), l__setCurrentFiber__99 (copy), l__invokeGuardedCallback__101 (copy), l__hasCaughtError__102 (copy), l__clearCaughtError__103 (copy), l__resetCurrentFiber__98 (copy), l____YOLO____2 (copy)
    while p194 ~= nil do
        local l__deletions__149 = p194.deletions;
        if l__deletions__149 ~= nil then
            for _, v197 in l__deletions__149 do
                local v198, v199 = xpcall(l__commitDeletion__78, l__describeError__13, p195, v197, p194, p196);
                if not v198 then
                    u1.captureCommitPhaseError(v197, p194, v199);
                end;
            end;
        end;
        if p194.child ~= nil and bit32.band(p194.subtreeFlags, l__ReactFiberFlags__38.MutationMask) ~= l__ReactFiberFlags__38.NoFlags then
            u18.commitMutationEffects(p194.child, p195, p196);
        end;
        if l____DEV____1 then
            l__setCurrentFiber__99(p194);
            l__invokeGuardedCallback__101(nil, u18.commitMutationEffectsImpl, nil, p194, p195, p196);
            if l__hasCaughtError__102() then
                local v200 = l__clearCaughtError__103();
                u1.captureCommitPhaseError(p194, p194.return_, v200);
            end;
            l__resetCurrentFiber__98();
        else
            local v201 = nil;
            local v202;
            if l____YOLO____2 then
                u18.commitMutationEffectsImpl(p194, p195, p196);
                v202 = true;
            else
                v202, v201 = xpcall(u18.commitMutationEffectsImpl, l__describeError__13, p194, p195, p196);
            end;
            if not v202 then
                u1.captureCommitPhaseError(p194, p194.return_, v201);
            end;
        end;
        p194 = p194.sibling;
    end;
end;
function u18.commitMutationEffectsImpl(p203, _, _) --[[ Line: 2623 ]]
    -- upvalues: l__ReactFiberFlags__38 (copy), l__commitDetachRef__82 (copy), l__commitPlacement__76 (copy), l__commitWork__77 (copy)
    local l__flags__150 = p203.flags;
    if bit32.band(l__flags__150, l__ReactFiberFlags__38.Ref) ~= 0 then
        local l__alternate__151 = p203.alternate;
        if l__alternate__151 ~= nil then
            l__commitDetachRef__82(l__alternate__151);
        end;
    end;
    local v204 = bit32.bor(l__ReactFiberFlags__38.Placement, l__ReactFiberFlags__38.Update, l__ReactFiberFlags__38.Hydrating);
    local v205 = bit32.band(l__flags__150, v204);
    if v205 == l__ReactFiberFlags__38.Placement then
        l__commitPlacement__76(p203);
        local l__flags__152 = p203.flags;
        local v206 = bit32.bnot(l__ReactFiberFlags__38.Placement);
        p203.flags = bit32.band(l__flags__152, v206);
    elseif v205 == l__ReactFiberFlags__38.PlacementAndUpdate then
        l__commitPlacement__76(p203);
        local l__flags__153 = p203.flags;
        local v207 = bit32.bnot(l__ReactFiberFlags__38.Placement);
        p203.flags = bit32.band(l__flags__153, v207);
        l__commitWork__77(p203.alternate, p203);
    else
        if v205 == l__ReactFiberFlags__38.Update then
            l__commitWork__77(p203.alternate, p203);
        end;
    end;
end;
function u18.commitMutationEffectsDeletions(p208, p209, p210, p211) --[[ Line: 2689 ]]
    -- upvalues: l__commitDeletion__78 (copy), l__describeError__13 (copy), u1 (copy)
    for _, v212 in p208 do
        local v213, v214 = xpcall(l__commitDeletion__78, l__describeError__13, p210, v212, p209, p211);
        if not v213 then
            u1.captureCommitPhaseError(v212, p209, v214);
        end;
    end;
end;
function u1.schedulePassiveEffectCallback() --[[ Line: 2707 ]]
    -- upvalues: u32 (ref), l__scheduleCallback__16 (copy), l__NormalPriority__26 (copy), u1 (copy)
    if not u32 then
        u32 = true;
        l__scheduleCallback__16(l__NormalPriority__26, function() --[[ Line: 2710 ]]
            -- upvalues: u1 (ref)
            u1.flushPassiveEffects();
            return nil;
        end);
    end;
end;
local u215 = nil;
function u1.flushPassiveEffects() --[[ Line: 2719 ]]
    -- upvalues: u34 (ref), l__NoPriority__23 (copy), l__NormalPriority__26 (copy), l__ReactFeatureFlags__7 (copy), l__getCurrentUpdateLanePriority__57 (copy), l__setCurrentUpdateLanePriority__56 (copy), l__schedulerPriorityToLanePriority__67 (copy), l____YOLO____2 (copy), l__runWithPriority__19 (copy), l__describeError__13 (copy), u215 (ref)
    if u34 == l__NoPriority__23 then
        return false;
    end;
    local v216;
    if l__NormalPriority__26 < u34 then
        v216 = l__NormalPriority__26;
    else
        v216 = u34;
    end;
    u34 = l__NoPriority__23;
    if not l__ReactFeatureFlags__7.decoupleUpdatePriorityFromScheduler then
        return l__runWithPriority__19(v216, u215);
    end;
    local v217 = l__getCurrentUpdateLanePriority__57();
    l__setCurrentUpdateLanePriority__56(l__schedulerPriorityToLanePriority__67(v216));
    local v218, v219;
    if l____YOLO____2 then
        l__setCurrentUpdateLanePriority__56(l__schedulerPriorityToLanePriority__67(v216));
        v218 = l__runWithPriority__19(v216, u215);
        v219 = true;
    else
        v219, v218 = xpcall(l__runWithPriority__19, l__describeError__13, v216, u215);
    end;
    l__setCurrentUpdateLanePriority__56(v217);
    if not v219 then
        error(v218);
    end;
    return v218;
end;
local function u227(p220, p221) --[[ Line: 2763 ]]
    -- upvalues: l__ReactFeatureFlags__7 (copy), l__ReactWorkTags__36 (copy), u28 (ref), l__ReactFiberFlags__38 (copy), u227 (ref), l____DEV____1 (copy), l__setCurrentFiber__99 (copy), l__invokeGuardedCallback__101 (copy), l__commitPassiveMount__81 (copy), l__hasCaughtError__102 (copy), l__clearCaughtError__103 (copy), u1 (copy), l__resetCurrentFiber__98 (copy), l____YOLO____2 (copy), l__describeError__13 (copy)
    while p221 ~= nil do
        local v222;
        if l__ReactFeatureFlags__7.enableProfilerTimer and (l__ReactFeatureFlags__7.enableProfilerCommitHooks and p221.tag == l__ReactWorkTags__36.Profiler) then
            v222 = u28;
            u28 = p221;
        else
            v222 = nil;
        end;
        local v223 = bit32.band(p221.subtreeFlags, l__ReactFiberFlags__38.PassiveMask);
        if p221.child ~= nil and v223 ~= l__ReactFiberFlags__38.NoFlags then
            u227(p220, p221.child);
        end;
        if bit32.band(p221.flags, l__ReactFiberFlags__38.Passive) ~= l__ReactFiberFlags__38.NoFlags then
            if l____DEV____1 then
                l__setCurrentFiber__99(p221);
                l__invokeGuardedCallback__101(nil, l__commitPassiveMount__81, nil, p220, p221);
                if l__hasCaughtError__102() then
                    local v224 = l__clearCaughtError__103();
                    u1.captureCommitPhaseError(p221, p221.return_, v224);
                end;
                l__resetCurrentFiber__98();
            else
                local v225 = nil;
                local v226;
                if l____YOLO____2 then
                    l__commitPassiveMount__81(p220, p221);
                    v226 = true;
                else
                    v226, v225 = xpcall(l__commitPassiveMount__81, l__describeError__13, p220, p221);
                end;
                if not v226 then
                    u1.captureCommitPhaseError(p221, p221.return_, v225);
                end;
            end;
        end;
        if l__ReactFeatureFlags__7.enableProfilerTimer and (l__ReactFeatureFlags__7.enableProfilerCommitHooks and p221.tag == l__ReactWorkTags__36.Profiler) then
            if v222 ~= nil then
                local l__stateNode__154 = v222.stateNode;
                l__stateNode__154.passiveEffectDuration = l__stateNode__154.passiveEffectDuration + p221.stateNode.passiveEffectDuration;
            end;
            u28 = v222;
        end;
        p221 = p221.sibling;
    end;
end;
local function u231(p228) --[[ Line: 2832 ]]
    -- upvalues: u18 (copy), l__ReactFiberFlags__38 (copy), u231 (copy), l__setCurrentFiber__99 (copy), l__commitPassiveUnmount__79 (copy), l__resetCurrentFiber__98 (copy)
    while p228 ~= nil do
        local l__deletions__155 = p228.deletions;
        if l__deletions__155 ~= nil then
            for v229 = 1, #l__deletions__155 do
                local v230 = l__deletions__155[v229];
                u18.flushPassiveUnmountEffectsInsideOfDeletedTree(v230, p228);
                u18.detachFiberAfterEffects(v230);
            end;
        end;
        local l__child__156 = p228.child;
        if l__child__156 ~= nil and bit32.band(p228.subtreeFlags, l__ReactFiberFlags__38.PassiveMask) ~= l__ReactFiberFlags__38.NoFlags then
            u231(l__child__156);
        end;
        if bit32.band(p228.flags, l__ReactFiberFlags__38.Passive) ~= l__ReactFiberFlags__38.NoFlags then
            l__setCurrentFiber__99(p228);
            l__commitPassiveUnmount__79(p228);
            l__resetCurrentFiber__98();
        end;
        p228 = p228.sibling;
    end;
end;
function u18.flushPassiveUnmountEffectsInsideOfDeletedTree(p232, p233) --[[ Line: 2872 ]]
    -- upvalues: l__ReactFiberFlags__38 (copy), u18 (copy), l__setCurrentFiber__99 (copy), l__commitPassiveUnmountInsideDeletedTree__80 (copy), l__resetCurrentFiber__98 (copy)
    if bit32.band(p232.subtreeFlags, l__ReactFiberFlags__38.PassiveStatic) ~= l__ReactFiberFlags__38.NoFlags then
        local l__child__157 = p232.child;
        while l__child__157 ~= nil do
            u18.flushPassiveUnmountEffectsInsideOfDeletedTree(l__child__157, p233);
            l__child__157 = l__child__157.sibling;
        end;
    end;
    if bit32.band(p232.flags, l__ReactFiberFlags__38.PassiveStatic) ~= l__ReactFiberFlags__38.NoFlags then
        l__setCurrentFiber__99(p232);
        l__commitPassiveUnmountInsideDeletedTree__80(p232, p233);
        l__resetCurrentFiber__98();
    end;
end;
u215 = function() --[[ Line: 2904 ]]
    -- upvalues: u33 (ref), l__NoLanes__117 (ref), l__ReactFiberLane__5 (copy), l__invariant__15 (copy), u19 (ref), l____DEV____1 (copy), l__enableDebugTracing__8 (copy), l__DebugTracing__29 (copy), l__enableSchedulingProfiler__9 (copy), l__SchedulingProfiler__30 (copy), u18 (copy), u231 (copy), u227 (ref), l__enableDoubleInvokingEffects__11 (copy), l__ReactFeatureFlags__7 (copy), l__flushSyncCallbackQueue__27 (copy), u38 (ref)
    if u33 == nil then
        return false;
    end;
    local v234 = u33;
    local v235 = l__NoLanes__117;
    u33 = nil;
    l__NoLanes__117 = l__ReactFiberLane__5.NoLanes;
    l__invariant__15(bit32.band(u19, 48) == 0, "Cannot flush passive effects while already rendering.");
    if l____DEV____1 and l__enableDebugTracing__8 then
        l__DebugTracing__29.logPassiveEffectsStarted(v235);
    end;
    if l__enableSchedulingProfiler__9 then
        l__SchedulingProfiler__30.markPassiveEffectsStarted(v235);
    end;
    local v236 = u19;
    u19 = bit32.bor(u19, 32);
    local v237 = u18.pushInteractions(v234);
    u231(v234.current);
    u227(v234, v234.current);
    if l____DEV____1 and l__enableDebugTracing__8 then
        l__DebugTracing__29.logPassiveEffectsStopped();
    end;
    if l__enableSchedulingProfiler__9 then
        l__SchedulingProfiler__30.markPassiveEffectsStopped();
    end;
    if l____DEV____1 and l__enableDoubleInvokingEffects__11 then
        commitDoubleInvokeEffectsInDEV(v234.current, true);
    end;
    if l__ReactFeatureFlags__7.enableSchedulerTracing then
        u18.popInteractions(v237);
        u18.finishPendingInteractions(v234, v235);
    end;
    u19 = v236;
    l__flushSyncCallbackQueue__27();
    if u33 == nil then
        u38 = 0;
    else
        u38 = u38 + 1;
    end;
    return true;
end;
function u1.isAlreadyFailedLegacyErrorBoundary(p238) --[[ Line: 2977 ]]
    -- upvalues: u31 (ref)
    local v239;
    if u31 == nil then
        v239 = false;
    else
        v239 = u31:has(p238);
    end;
    return v239;
end;
function u1.markLegacyErrorBoundaryAsFailed(p240) --[[ Line: 2983 ]]
    -- upvalues: u31 (ref), l__Set__4 (copy)
    if u31 == nil then
        u31 = l__Set__4.new({ p240 });
    else
        u31:add(p240);
    end;
end;
function u1.onUncaughtError(p241) --[[ Line: 2992 ]]
    -- upvalues: u29 (ref), u30 (ref)
    if not u29 then
        u29 = true;
        u30 = p241;
    end;
end;
u17 = function(p242, p243, p244) --[[ Line: 3000 ]]
    -- upvalues: l__createCapturedValue__91 (copy), l__createRootErrorUpdate__73 (copy), l__SyncLane__39 (copy), u1 (copy), l__enqueueUpdate__89 (copy), u18 (copy), l__markRootUpdated__61 (copy), u8 (ref)
    l__enqueueUpdate__89(p242, (l__createRootErrorUpdate__73(p242, l__createCapturedValue__91(p244, p243), l__SyncLane__39, u1.onUncaughtError)));
    local v245 = u1.requestEventTime();
    local v246 = u18.markUpdateLaneFromFiberToRoot(p242, l__SyncLane__39);
    if v246 ~= nil then
        l__markRootUpdated__61(v246, l__SyncLane__39, v245);
        u8(v246, v245);
        u18.schedulePendingInteractions(v246, l__SyncLane__39);
    end;
end;
function u1.captureCommitPhaseError(p247, p248, p249) --[[ Line: 3021 ]]
    -- upvalues: l__ReactWorkTags__36 (copy), u17 (ref), l__skipUnmountedBoundaries__10 (copy), u1 (copy), l__createCapturedValue__91 (copy), l__createClassErrorUpdate__74 (copy), l__SyncLane__39 (copy), l__enqueueUpdate__89 (copy), u18 (copy), l__markRootUpdated__61 (copy), u8 (ref)
    if p247.tag == l__ReactWorkTags__36.HostRoot then
        u17(p247, p247, p249);
    else
        if not l__skipUnmountedBoundaries__10 then
            p248 = p247.return_;
        end;
        while p248 ~= nil do
            if p248.tag == l__ReactWorkTags__36.HostRoot then
                u17(p248, p247, p249);
                return;
            end;
            if p248.tag == l__ReactWorkTags__36.ClassComponent then
                local l__type__158 = p248.type;
                local l__stateNode__159 = p248.stateNode;
                if typeof(l__type__158.getDerivedStateFromError) == "function" or typeof(l__stateNode__159.componentDidCatch) == "function" and not u1.isAlreadyFailedLegacyErrorBoundary(l__stateNode__159) then
                    l__enqueueUpdate__89(p248, (l__createClassErrorUpdate__74(p248, l__createCapturedValue__91(p249, p247), l__SyncLane__39)));
                    local v250 = u1.requestEventTime();
                    local v251 = u18.markUpdateLaneFromFiberToRoot(p248, l__SyncLane__39);
                    if v251 ~= nil then
                        l__markRootUpdated__61(v251, l__SyncLane__39, v250);
                        u8(v251, v250);
                        u18.schedulePendingInteractions(v251, l__SyncLane__39);
                    end;
                    return;
                end;
            end;
            p248 = p248.return_;
        end;
    end;
end;
function u1.pingSuspendedRoot(p252, p253, p254) --[[ Line: 3070 ]]
    -- upvalues: u1 (copy), l__markRootPinged__63 (copy), u20 (ref), l__isSubsetOfLanes__46 (copy), l__NoLanes__111 (ref), u23 (ref), l__includesOnlyRetries__52 (copy), l__now__22 (copy), u26 (ref), u18 (copy), l__ReactFiberLane__5 (copy), l__NoLanes__116 (ref), l__mergeLanes__47 (copy), u8 (ref)
    local l__pingCache__160 = p252.pingCache;
    if l__pingCache__160 ~= nil then
        l__pingCache__160[p253] = nil;
    end;
    local v255 = u1.requestEventTime();
    l__markRootPinged__63(p252, p254, v255);
    if u20 == p252 and l__isSubsetOfLanes__46(l__NoLanes__111, p254) then
        if u23 == 4 or u23 == 3 and (l__includesOnlyRetries__52(l__NoLanes__111) and l__now__22() - u26 < 500) then
            u18.prepareFreshStack(p252, l__ReactFiberLane__5.NoLanes);
        else
            l__NoLanes__116 = l__mergeLanes__47(l__NoLanes__116, p254);
        end;
    end;
    u8(p252, v255);
    u18.schedulePendingInteractions(p252, p254);
end;
function retryTimedOutBoundary(p256, p257)
    -- upvalues: l__ReactFiberLane__5 (copy), u1 (copy), u18 (copy), l__markRootUpdated__61 (copy), u8 (ref)
    if p257 == l__ReactFiberLane__5.NoLane then
        p257 = requestRetryLane(p256);
    end;
    local v258 = u1.requestEventTime();
    local v259 = u18.markUpdateLaneFromFiberToRoot(p256, p257);
    if v259 ~= nil then
        l__markRootUpdated__61(v259, p257, v258);
        u8(v259, v258);
        u18.schedulePendingInteractions(v259, p257);
    end;
end;
function u1.resolveRetryWakeable(p260, p261) --[[ Line: 3141 ]]
    -- upvalues: l__ReactFiberLane__5 (copy)
    local l__NoLane__161 = l__ReactFiberLane__5.NoLane;
    local l__stateNode__162 = p260.stateNode;
    if l__stateNode__162 ~= nil then
        l__stateNode__162:delete(p261);
    end;
    retryTimedOutBoundary(p260, l__NoLane__161);
end;
function jnd(p262)
    return p262 < 120 and 120 or (p262 < 480 and 480 or (p262 < 1080 and 1080 or (p262 < 1920 and 1920 or (p262 < 3000 and 3000 or (p262 < 4320 and 4320 or math.ceil(p262 / 1960) * 1960)))));
end;
function u18.checkForNestedUpdates() --[[ Line: 3203 ]]
    -- upvalues: u36 (ref), u37 (ref), l__invariant__15 (copy), l____DEV____1 (copy), u38 (ref), l__console__3 (copy)
    if u36 > 50 then
        u36 = 0;
        u37 = nil;
        l__invariant__15(false, "Maximum update depth exceeded. This can happen when a component repeatedly calls setState inside componentWillUpdate or componentDidUpdate. React limits the number of nested updates to prevent infinite loops.");
    end;
    if l____DEV____1 and u38 > 50 then
        u38 = 0;
        l__console__3.error("Maximum update depth exceeded. This can happen when a component calls setState inside useEffect, but useEffect either doesn\'t have a dependency array, or one of the dependencies changes on every render.");
    end;
end;
function flushRenderPhaseStrictModeWarningsInDEV()
    -- upvalues: l____DEV____1 (copy), u16 (copy), l__ReactFeatureFlags__7 (copy)
    if l____DEV____1 then
        u16.flushLegacyContextWarning();
        if l__ReactFeatureFlags__7.warnAboutDeprecatedLifecycles then
            u16.flushPendingUnsafeLifecycleWarnings();
        end;
    end;
end;
function commitDoubleInvokeEffectsInDEV(p263, p264)
    -- upvalues: l____DEV____1 (copy), l__enableDoubleInvokingEffects__11 (copy), l__setCurrentFiber__99 (copy), l__ReactFiberFlags__38 (copy), l__invokeLayoutEffectUnmountInDEV__85 (copy), l__invokePassiveEffectUnmountInDEV__86 (copy), l__invokeLayoutEffectMountInDEV__83 (copy), l__invokePassiveEffectMountInDEV__84 (copy), l__resetCurrentFiber__98 (copy)
    if l____DEV____1 and l__enableDoubleInvokingEffects__11 then
        l__setCurrentFiber__99(p263);
        invokeEffectsInDev(p263, l__ReactFiberFlags__38.MountLayoutDev, l__invokeLayoutEffectUnmountInDEV__85);
        if p264 then
            invokeEffectsInDev(p263, l__ReactFiberFlags__38.MountPassiveDev, l__invokePassiveEffectUnmountInDEV__86);
        end;
        invokeEffectsInDev(p263, l__ReactFiberFlags__38.MountLayoutDev, l__invokeLayoutEffectMountInDEV__83);
        if p264 then
            invokeEffectsInDev(p263, l__ReactFiberFlags__38.MountPassiveDev, l__invokePassiveEffectMountInDEV__84);
        end;
        l__resetCurrentFiber__98();
    end;
end;
function invokeEffectsInDev(p265, p266, p267)
    -- upvalues: l____DEV____1 (copy), l__enableDoubleInvokingEffects__11 (copy), l__ReactFiberFlags__38 (copy)
    if l____DEV____1 and l__enableDoubleInvokingEffects__11 then
        while p265 ~= nil do
            if p265.child ~= nil and bit32.band(p265.subtreeFlags, p266) ~= l__ReactFiberFlags__38.NoFlags then
                invokeEffectsInDev(p265.child, p266, p267);
            end;
            if bit32.band(p265.flags, p266) ~= l__ReactFiberFlags__38.NoFlags then
                p267(p265);
            end;
            p265 = p265.sibling;
        end;
    end;
end;
local u268 = nil;
function u18.warnAboutUpdateOnNotYetMountedFiberInDEV(u269) --[[ Line: 3297 ]]
    -- upvalues: l____DEV____1 (copy), u19 (ref), l__ReactTypeOfMode__35 (copy), l__ReactWorkTags__36 (copy), l__getComponentName__95 (copy), u268 (ref), l__ReactCurrentFiber__96 (copy), l__setCurrentFiber__99 (copy), l__console__3 (copy), l__resetCurrentFiber__98 (copy)
    if l____DEV____1 then
        if bit32.band(u19, 16) ~= 0 then
            return;
        end;
        local l__mode__163 = u269.mode;
        local v270 = bit32.bor(l__ReactTypeOfMode__35.BlockingMode, l__ReactTypeOfMode__35.ConcurrentMode);
        if bit32.band(l__mode__163, v270) == 0 then
            return;
        end;
        local l__tag__164 = u269.tag;
        if l__tag__164 ~= l__ReactWorkTags__36.IndeterminateComponent and (l__tag__164 ~= l__ReactWorkTags__36.HostRoot and (l__tag__164 ~= l__ReactWorkTags__36.ClassComponent and (l__tag__164 ~= l__ReactWorkTags__36.FunctionComponent and (l__tag__164 ~= l__ReactWorkTags__36.ForwardRef and (l__tag__164 ~= l__ReactWorkTags__36.MemoComponent and (l__tag__164 ~= l__ReactWorkTags__36.SimpleMemoComponent and l__tag__164 ~= l__ReactWorkTags__36.Block)))))) then
            return;
        end;
        local v271 = l__getComponentName__95(u269.type) or "ReactComponent";
        if u268 == nil then
            u268 = {
                [v271] = true
            };
        else
            if u268[v271] then
                return;
            end;
            u268[v271] = true;
        end;
        local l__current__165 = l__ReactCurrentFiber__96.current;
        local v272, v273 = pcall(function() --[[ Line: 3342 ]]
            -- upvalues: l__setCurrentFiber__99 (ref), u269 (copy), l__console__3 (ref)
            l__setCurrentFiber__99(u269);
            l__console__3.error("Can\'t perform a React state update on a component that hasn\'t mounted yet. This indicates that you have a side-effect in your render function that asynchronously later calls tries to update the component. Move this work to useEffect instead.");
        end);
        if l__current__165 then
            l__setCurrentFiber__99(u269);
        else
            l__resetCurrentFiber__98();
        end;
        if not v272 then
            error(v273);
        end;
    end;
end;
if l____DEV____1 and l__ReactFeatureFlags__7.replayFailedUnitOfWorkWithInvokeGuardedCallback then
    function u18.beginWork(p274, p275, p276) --[[ Line: 3368 ]]
        -- upvalues: u4 (copy), u13 (copy), l__describeError__13 (copy), l__resetContextDependencies__90 (copy), u9 (copy), u14 (ref), l__unwindInterruptedWork__71 (copy), l__ReactFeatureFlags__7 (copy), l__ReactTypeOfMode__35 (copy), u15 (copy), l__invokeGuardedCallback__101 (copy), l__hasCaughtError__102 (copy), l__clearCaughtError__103 (copy)
        local v277 = u4.assignFiberPropertiesInDEV(nil, p275);
        local v278, v279 = xpcall(u13, l__describeError__13, p274, p275, p276);
        if not v278 then
            if v279 ~= nil and (typeof(v279) == "table" and typeof(v279.andThen) == "function") then
                error(v279);
            end;
            l__resetContextDependencies__90();
            if not u9.resetHooksAfterThrowRef then
                u14 = require(script.Parent:WaitForChild("ReactFiberHooks.new"));
                u9.resetHooksAfterThrowRef = u14.resetHooksAfterThrow;
                u9.ContextOnlyDispatcherRef = u14.ContextOnlyDispatcher;
                u9.getIsUpdatingOpaqueValueInRenderPhaseInDEVRef = u14.getIsUpdatingOpaqueValueInRenderPhaseInDEV;
            end;
            u9.resetHooksAfterThrowRef();
            l__unwindInterruptedWork__71(p275);
            u4.assignFiberPropertiesInDEV(p275, v277);
            if l__ReactFeatureFlags__7.enableProfilerTimer and bit32.band(p275.mode, l__ReactTypeOfMode__35.ProfileMode) ~= 0 then
                u15.startProfilerTimer(p275);
            end;
            l__invokeGuardedCallback__101(nil, u13, nil, p274, p275, p276);
            if l__hasCaughtError__102() then
                local v280 = l__clearCaughtError__103();
                error(v280);
                return v279;
            end;
            error(v279);
        end;
        return v279;
    end;
else
    u18.beginWork = u13;
end;
local u281 = false;
local u282 = l____DEV____1 and {} or nil;
function u18.warnAboutRenderPhaseUpdatesInDEV(p283) --[[ Line: 3438 ]]
    -- upvalues: l____DEV____1 (copy), l__ReactCurrentFiber__96 (copy), u19 (ref), u9 (copy), u14 (ref), l__ReactWorkTags__36 (copy), u21 (ref), l__getComponentName__95 (copy), u282 (ref), l__console__3 (copy), u281 (ref)
    if l____DEV____1 and (l__ReactCurrentFiber__96.isRendering and bit32.band(u19, 16) ~= 0) then
        if not u9.getIsUpdatingOpaqueValueInRenderPhaseInDEVRef then
            u14 = require(script.Parent:WaitForChild("ReactFiberHooks.new"));
            u9.resetHooksAfterThrowRef = u14.resetHooksAfterThrow;
            u9.ContextOnlyDispatcherRef = u14.ContextOnlyDispatcher;
            u9.getIsUpdatingOpaqueValueInRenderPhaseInDEVRef = u14.getIsUpdatingOpaqueValueInRenderPhaseInDEV;
        end;
        if not u9.getIsUpdatingOpaqueValueInRenderPhaseInDEVRef() then
            if p283.tag == l__ReactWorkTags__36.FunctionComponent or (p283.tag == l__ReactWorkTags__36.ForwardRef or p283.tag == l__ReactWorkTags__36.SimpleMemoComponent) then
                local v284 = u21 == nil and "Unknown" or l__getComponentName__95(u21.type);
                if u282[v284] == nil then
                    u282[v284] = true;
                    local v285 = l__getComponentName__95(p283.type) or "Unknown";
                    l__console__3.error("Cannot update a component (`%s`) while rendering a different component (`%s`). To locate the bad setState() call inside `%s`, follow the stack trace as described in https://reactjs.org/link/setstate-in-render", v285, v284, v284);
                end;
            elseif p283.tag == l__ReactWorkTags__36.ClassComponent and not u281 then
                l__console__3.error("Cannot update during an existing state transition (such as within `render`). Render methods should be a pure function of props and state.");
                u281 = true;
            end;
        end;
    end;
end;
u1.IsThisRendererActing = {
    current = false
};
function u1.warnIfNotScopedWithMatchingAct(u286) --[[ Line: 3490 ]]
    -- upvalues: l____DEV____1 (copy), l__ReactFiberHostConfig__34 (copy), l__IsSomeRendererActing__110 (copy), u1 (copy), l__ReactCurrentFiber__96 (copy), l__setCurrentFiber__99 (copy), l__console__3 (copy), l__resetCurrentFiber__98 (copy)
    if l____DEV____1 and (l__ReactFiberHostConfig__34.warnsIfNotActing == true and (l__IsSomeRendererActing__110.current == true and u1.IsThisRendererActing.current ~= true)) then
        local l__current__166 = l__ReactCurrentFiber__96.current;
        local v287, v288 = pcall(function() --[[ Line: 3498 ]]
            -- upvalues: l__setCurrentFiber__99 (ref), u286 (copy), l__console__3 (ref)
            l__setCurrentFiber__99(u286);
            l__console__3.error("It looks like you\'re using the wrong act() around your test interactions.\nBe sure to use the matching version of act() corresponding to your renderer:\n\n-- for react-roblox:\nlocal React = require(Packages.React)\n-- ...\nReact.TestUtils.act(function() ... end)\n\n-- for react-test-renderer:\nlocal TestRenderer = require(Packages.ReactTestRenderer)\n-- ...\nTestRenderer.act(function() ... end)");
        end);
        if l__current__166 then
            l__setCurrentFiber__99(u286);
        else
            l__resetCurrentFiber__98();
        end;
        if not v287 then
            error(v288);
        end;
    end;
end;
function u1.warnIfNotCurrentlyActingEffectsInDEV(p289) --[[ Line: 3534 ]]
    -- upvalues: l____DEV____1 (copy), l__ReactFiberHostConfig__34 (copy), l__ReactTypeOfMode__35 (copy), l__IsSomeRendererActing__110 (copy), u1 (copy), l__console__3 (copy), l__getComponentName__95 (copy)
    if l____DEV____1 and (l__ReactFiberHostConfig__34.warnsIfNotActing == true and (bit32.band(p289.mode, l__ReactTypeOfMode__35.StrictMode) ~= l__ReactTypeOfMode__35.NoMode and (l__IsSomeRendererActing__110.current == false and u1.IsThisRendererActing.current == false))) then
        l__console__3.error("An update to %s ran an effect, but was not wrapped in act(...).\n\nWhen testing, code that causes React state updates should be wrapped into act(...):\n\nact(function()\n  --[[ fire events that update state ]]\nend)\n--[[ assert on the output ]]\n\nThis ensures that you\'re testing the behavior the user would see in the real client. Learn more at https://reactjs.org/link/wrap-tests-with-act", l__getComponentName__95(p289.type));
    end;
end;
function u1.warnIfNotCurrentlyActingUpdatesInDEV(u290) --[[ Line: 3560 ]]
    -- upvalues: l____DEV____1 (copy), l__ReactFiberHostConfig__34 (copy), u19 (ref), l__IsSomeRendererActing__110 (copy), u1 (copy), l__current__97 (copy), l__setCurrentFiber__99 (copy), l__console__3 (copy), l__getComponentName__95 (copy), l__resetCurrentFiber__98 (copy)
    if l____DEV____1 and (l__ReactFiberHostConfig__34.warnsIfNotActing == true and (u19 == 0 and (l__IsSomeRendererActing__110.current == false and u1.IsThisRendererActing.current == false))) then
        local v291 = l__current__97;
        local v292, v293 = pcall(function() --[[ Line: 3569 ]]
            -- upvalues: l__setCurrentFiber__99 (ref), u290 (copy), l__console__3 (ref), l__getComponentName__95 (ref)
            l__setCurrentFiber__99(u290);
            l__console__3.error("An update to %s inside a test was not wrapped in act(...).\n\nWhen testing, code that causes React state updates should be wrapped into act(...):\n\nact(function()\n  --[[ fire events that update state ]]\nend)\n--[[ assert on the output ]]\n\nThis ensures that you\'re testing the behavior the user would see in the client application. Learn more at https://reactjs.org/link/wrap-tests-with-act", l__getComponentName__95(u290.type));
        end);
        if v291 then
            l__setCurrentFiber__99(u290);
        else
            l__resetCurrentFiber__98();
        end;
        if v292 then
            return v293;
        end;
    end;
end;
local u294 = false;
function u1.warnIfUnmockedScheduler(p295) --[[ Line: 3610 ]]
    -- upvalues: l____DEV____1 (copy), u294 (ref), l__scheduler__6 (copy), l__ReactTypeOfMode__35 (copy), l__console__3 (copy), l__ReactFeatureFlags__7 (copy)
    if l____DEV____1 and (u294 == false and l__scheduler__6.unstable_flushAllWithoutAsserting == nil) then
        if bit32.band(p295.mode, l__ReactTypeOfMode__35.BlockingMode) ~= 0 or bit32.band(p295.mode, l__ReactTypeOfMode__35.ConcurrentMode) ~= 0 then
            u294 = true;
            l__console__3.error("In Concurrent or Sync modes, the \'scheduler\' module needs to be mocked to guarantee consistent behaviour across tests and client application. For example, with Jest: \njest.mock(\'scheduler\', function() return require(@pkg/scheduler).unstable_mock end)\n\nFor more info, visit https://reactjs.org/link/mock-scheduler");
            return;
        end;
        if l__ReactFeatureFlags__7.warnAboutUnmockedScheduler == true then
            u294 = true;
            l__console__3.error("Starting from React v18, the \'scheduler\' module will need to be mocked to guarantee consistent behaviour across tests and client applications. For example, with Jest: \njest.mock(\'scheduler\', function() return require(@pkg/scheduler).unstable_mock end)\n\nFor more info, visit https://reactjs.org/link/mock-scheduler");
        end;
    end;
end;
function computeThreadID(p296, p297)
    return p297 * 1000 + p296.interactionThreadID;
end;
function u1.markSpawnedWork(p298) --[[ Line: 3661 ]]
    -- upvalues: l__ReactFeatureFlags__7 (copy), u39 (ref)
    if l__ReactFeatureFlags__7.enableSchedulerTracing then
        if u39 == nil then
            u39 = { p298 };
        else
            table.insert(u39, p298);
        end;
    end;
end;
function scheduleInteractions(p299, p300, p301)
    -- upvalues: l__ReactFeatureFlags__7 (copy), l__Set__4 (copy), l____subscriberRef__33 (copy)
    if l__ReactFeatureFlags__7.enableSchedulerTracing then
        if p301.size > 0 then
            local l__pendingInteractionMap__167 = p299.pendingInteractionMap;
            local u302 = l__pendingInteractionMap__167:get(p300);
            if u302 == nil then
                l__pendingInteractionMap__167:set(p300, l__Set__4.new(p301));
                for _, v303 in p301 do
                    v303.__count = v303.__count + 1;
                end;
            else
                p301:forEach(function(p304) --[[ Line: 3686 ]]
                    -- upvalues: u302 (copy)
                    if not u302:has(p304) then
                        p304.__count = p304.__count + 1;
                    end;
                    u302:add(p304);
                end);
            end;
            local l__current__168 = l____subscriberRef__33.current;
            if l__current__168 ~= nil then
                local v305 = computeThreadID(p299, p300);
                l__current__168.onWorkScheduled(p301, v305);
            end;
        end;
    end;
end;
function u18.schedulePendingInteractions(p306, p307) --[[ Line: 3711 ]]
    -- upvalues: l__ReactFeatureFlags__7 (copy), l____interactionsRef__32 (copy)
    if l__ReactFeatureFlags__7.enableSchedulerTracing then
        scheduleInteractions(p306, p307, l____interactionsRef__32.current);
    end;
end;
function u18.startWorkOnPendingInteractions(p308, u309) --[[ Line: 3722 ]]
    -- upvalues: l__ReactFeatureFlags__7 (copy), l__Set__4 (copy), l__includesSomeLane__45 (copy), l____subscriberRef__33 (copy), l__describeError__13 (copy), l__scheduleCallback__16 (copy), l__ImmediatePriority__24 (copy)
    if l__ReactFeatureFlags__7.enableSchedulerTracing then
        local u310 = l__Set__4.new();
        p308.pendingInteractionMap:forEach(function(p311, p312) --[[ Line: 3732 ]]
            -- upvalues: l__includesSomeLane__45 (ref), u309 (copy), u310 (copy)
            if l__includesSomeLane__45(u309, p312) then
                p311:forEach(function(p313) --[[ Line: 3734 ]]
                    -- upvalues: u310 (ref)
                    u310:add(p313);
                end);
            end;
        end);
        p308.memoizedInteractions = u310;
        if u310.size > 0 then
            local l__current__169 = l____subscriberRef__33.current;
            if l__current__169 ~= nil then
                local v314 = computeThreadID(p308, u309);
                local v315, u316 = xpcall(l__current__169.onWorkStarted, l__describeError__13, u310, v314);
                if not v315 then
                    l__scheduleCallback__16(l__ImmediatePriority__24, function() --[[ Line: 3756 ]]
                        -- upvalues: u316 (copy)
                        error(u316);
                    end);
                end;
            end;
        end;
    end;
end;
function u18.finishPendingInteractions(p317, p318) --[[ Line: 3764 ]]
    -- upvalues: l__ReactFeatureFlags__7 (copy), l____subscriberRef__33 (copy), l__describeError__13 (copy), l__includesSomeLane__45 (copy), l__scheduleCallback__16 (copy), l__ImmediatePriority__24 (copy)
    if l__ReactFeatureFlags__7.enableSchedulerTracing then
        local l__pendingLanes__170 = p317.pendingLanes;
        local u319 = nil;
        local u320, v321;
        if u319 == nil or p317.memoizedInteractions.size <= 0 then
            u320 = nil;
            v321 = true;
        else
            local v322 = computeThreadID(p317, p318);
            u319 = l____subscriberRef__33.current;
            v321, u320 = xpcall(u319.onWorkStopped, l__describeError__13, p317.memoizedInteractions, v322);
        end;
        local l__pendingInteractionMap__171 = p317.pendingInteractionMap;
        l__pendingInteractionMap__171:forEach(function(p323, p324) --[[ Line: 3795 ]]
            -- upvalues: l__includesSomeLane__45 (ref), l__pendingLanes__170 (copy), l__pendingInteractionMap__171 (copy), u319 (ref), l__describeError__13 (ref), l__scheduleCallback__16 (ref), l__ImmediatePriority__24 (ref)
            if not l__includesSomeLane__45(l__pendingLanes__170, p324) then
                l__pendingInteractionMap__171:delete(p324);
                p323:forEach(function(p325) --[[ Line: 3801 ]]
                    -- upvalues: u319 (ref), l__describeError__13 (ref), l__scheduleCallback__16 (ref), l__ImmediatePriority__24 (ref)
                    p325.__count = p325.__count - 1;
                    if u319 ~= nil and p325.__count == 0 then
                        local v326, u327 = xpcall(u319.onInteractionScheduledWorkCompleted, l__describeError__13, p325);
                        if not v326 then
                            l__scheduleCallback__16(l__ImmediatePriority__24, function() --[[ Line: 3812 ]]
                                -- upvalues: u327 (copy)
                                error(u327);
                            end);
                        end;
                    end;
                end);
            end;
        end);
        if not v321 then
            l__scheduleCallback__16(l__ImmediatePriority__24, function() --[[ Line: 3824 ]]
                -- upvalues: u320 (ref)
                error(u320);
            end);
        end;
    end;
end;
local u328 = false;
local u329 = false;
local l__unstable_flushAllWithoutAsserting__172 = l__scheduler__6.unstable_flushAllWithoutAsserting;
local u330 = typeof(l__unstable_flushAllWithoutAsserting__172) == "function";
local function u338() --[[ Line: 3843 ]]
    -- upvalues: l__unstable_flushAllWithoutAsserting__172 (copy), u328 (ref), l__describeError__13 (copy), u1 (copy)
    if l__unstable_flushAllWithoutAsserting__172 == nil then
        local v331 = u328;
        u328 = true;
        local v333, v334 = xpcall(function() --[[ Line: 3863 ]]
            -- upvalues: u1 (ref)
            local v332 = false;
            while u1.flushPassiveEffects() do
                v332 = true;
            end;
            return v332;
        end, l__describeError__13);
        u328 = v331;
        if v333 then
            return v334;
        end;
        error(v334);
    else
        local v335 = u328;
        u328 = true;
        local v336, v337 = xpcall(l__unstable_flushAllWithoutAsserting__172, l__describeError__13);
        u328 = v335;
        if v336 then
            return v337;
        end;
        error(v337);
    end;
end;
local function u342(u339) --[[ Line: 3882 ]]
    -- upvalues: u338 (copy), l__describeError__13 (copy), l__enqueueTask__106 (copy), u342 (copy)
    local v340, v341 = xpcall(u338, l__describeError__13);
    if v340 then
        v340, v341 = xpcall(l__enqueueTask__106, l__describeError__13, function() --[[ Line: 3886 ]]
            -- upvalues: u338 (ref), u342 (ref), u339 (copy)
            if u338() then
                u342(u339);
            else
                u339();
            end;
        end);
    end;
    if not v340 then
        u339(v341);
    end;
end;
function u1.act(p343) --[[ Line: 3900 ]]
    -- upvalues: l____DEV____1 (copy), u71 (ref), l__console__3 (copy), u70 (ref), l__IsSomeRendererActing__110 (copy), u1 (copy), u329 (ref), l__describeError__13 (copy), l__promise__88 (copy), u330 (copy), u342 (copy), u338 (copy)
    if not l____DEV____1 and (not _G.__ROACT_17_MOCK_SCHEDULER__ and u71 == false) then
        u71 = true;
        l__console__3.error("act(...) is not supported in production builds of React, and might not behave as expected.");
    end;
    local u344 = u70;
    u70 = u70 + 1;
    local l__current__173 = l__IsSomeRendererActing__110.current;
    local l__current__174 = u1.IsThisRendererActing.current;
    local u345 = u329;
    l__IsSomeRendererActing__110.current = true;
    u1.IsThisRendererActing.current = true;
    u329 = true;
    local v346, u347 = xpcall(u1.batchedUpdates, l__describeError__13, p343);
    if not v346 then
        u70 = u70 - 1;
        l__IsSomeRendererActing__110.current = l__current__173;
        u1.IsThisRendererActing.current = l__current__174;
        u329 = u345;
        if l____DEV____1 and u344 < u70 then
            l__console__3.error("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. ");
        end;
        error(u347);
    end;
    if u347 ~= nil and (typeof(u347) == "table" and typeof(u347.andThen) == "function") then
        local u348 = false;
        if l____DEV____1 and typeof(l__promise__88) ~= nil then
            l__promise__88.resolve():andThen(function() --[[ Line: 3958 ]] end):andThen(function() --[[ Line: 3958 ]]
                -- upvalues: u348 (ref), l__console__3 (ref)
                if u348 == false then
                    l__console__3.error("You called act(Promise.new(function() --[[ ... ]] end)) without :await() or :expect(). This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - act(function() Promise.new(function() --[[ ... ]] end):await() end);");
                end;
            end);
        end;
        return {
            andThen = function(_, u349, u350) --[[ Name: andThen, Line 3977 ]]
                -- upvalues: u348 (ref), u347 (copy), u70 (ref), u330 (ref), l__current__173 (copy), l__IsSomeRendererActing__110 (ref), u1 (ref), l__current__174 (copy), u329 (ref), u345 (copy), l____DEV____1 (ref), u344 (copy), l__console__3 (ref), u342 (ref)
                u348 = true;
                return u347:andThen(function() --[[ Line: 3979 ]]
                    -- upvalues: u70 (ref), u330 (ref), l__current__173 (ref), l__IsSomeRendererActing__110 (ref), u1 (ref), l__current__174 (ref), u329 (ref), u345 (ref), l____DEV____1 (ref), u344 (ref), l__console__3 (ref), u349 (copy), u342 (ref), u350 (copy)
                    if u70 > 1 or u330 == true and l__current__173 == true then
                        u70 = u70 - 1;
                        l__IsSomeRendererActing__110.current = l__current__173;
                        u1.IsThisRendererActing.current = l__current__174;
                        u329 = u345;
                        if l____DEV____1 and u344 < u70 then
                            l__console__3.error("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. ");
                        end;
                        u349();
                    else
                        u342(function(p351) --[[ Line: 3993 ]]
                            -- upvalues: u70 (ref), l__IsSomeRendererActing__110 (ref), l__current__173 (ref), u1 (ref), l__current__174 (ref), u329 (ref), u345 (ref), l____DEV____1 (ref), u344 (ref), l__console__3 (ref), u350 (ref), u349 (ref)
                            u70 = u70 - 1;
                            l__IsSomeRendererActing__110.current = l__current__173;
                            u1.IsThisRendererActing.current = l__current__174;
                            u329 = u345;
                            if l____DEV____1 and u344 < u70 then
                                l__console__3.error("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. ");
                            end;
                            if p351 then
                                u350(p351);
                            else
                                u349();
                            end;
                        end);
                    end;
                end, function(p352) --[[ Line: 4001 ]]
                    -- upvalues: u70 (ref), l__IsSomeRendererActing__110 (ref), l__current__173 (ref), u1 (ref), l__current__174 (ref), u329 (ref), u345 (ref), l____DEV____1 (ref), u344 (ref), l__console__3 (ref), u350 (copy)
                    u70 = u70 - 1;
                    l__IsSomeRendererActing__110.current = l__current__173;
                    u1.IsThisRendererActing.current = l__current__174;
                    u329 = u345;
                    if l____DEV____1 and u344 < u70 then
                        l__console__3.error("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. ");
                    end;
                    u350(p352);
                end);
            end
        };
    end;
    if l____DEV____1 and u347 ~= nil then
        l__console__3.error("The callback passed to act(...) function must return nil, or a Promise. You returned %s", (tostring(u347)));
    end;
    local v353, v354 = xpcall(function() --[[ Line: 4020 ]]
        -- upvalues: u70 (ref), u330 (ref), l__current__173 (copy), u338 (ref), l__IsSomeRendererActing__110 (ref), u1 (ref), l__current__174 (copy), u329 (ref), u345 (copy), l____DEV____1 (ref), u344 (copy), l__console__3 (ref)
        if u70 == 1 and (u330 == false or l__current__173 == false) then
            u338();
        end;
        u70 = u70 - 1;
        l__IsSomeRendererActing__110.current = l__current__173;
        u1.IsThisRendererActing.current = l__current__174;
        u329 = u345;
        if l____DEV____1 and u344 < u70 then
            l__console__3.error("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. ");
        end;
    end, l__describeError__13);
    if not v353 then
        u70 = u70 - 1;
        l__IsSomeRendererActing__110.current = l__current__173;
        u1.IsThisRendererActing.current = l__current__174;
        u329 = u345;
        if l____DEV____1 and u344 < u70 then
            l__console__3.error("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. ");
        end;
        error(v354);
    end;
    return {
        andThen = function(_, p355, _) --[[ Name: andThen, Line 4040 ]]
            -- upvalues: l____DEV____1 (ref), l__console__3 (ref)
            if l____DEV____1 then
                l__console__3.error("Do not await the result of calling act(...) with sync logic, it is not a Promise.");
            end;
            p355();
        end
    };
end;
function u18.detachFiberAfterEffects(p356) --[[ Line: 4052 ]]
    -- upvalues: l____DEV____1 (copy)
    p356.child = nil;
    p356.deletions = nil;
    p356.dependencies = nil;
    p356.memoizedProps = nil;
    p356.memoizedState = nil;
    p356.pendingProps = nil;
    p356.sibling = nil;
    p356.stateNode = nil;
    p356.updateQueue = nil;
    if l____DEV____1 then
        p356._debugOwner = nil;
    end;
end;
return u1;