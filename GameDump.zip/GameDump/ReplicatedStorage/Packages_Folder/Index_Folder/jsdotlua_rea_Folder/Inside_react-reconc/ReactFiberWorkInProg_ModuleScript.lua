-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberWorkInProgress
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReactFiberLane__1 = require(script.Parent:WaitForChild("ReactFiberLane"));
local l__NoLanes__2 = l__ReactFiberLane__1.NoLanes;
local l__mergeLanes__3 = l__ReactFiberLane__1.mergeLanes;
return {
    workInProgressRootSkippedLanes = function(p1) --[[ Line: 24 ]]
        -- upvalues: l__NoLanes__2 (ref)
        if p1 == nil then
            return l__NoLanes__2;
        end;
        l__NoLanes__2 = p1;
        return l__NoLanes__2;
    end,
    markSkippedUpdateLanes = function(p2) --[[ Line: 34 ]]
        -- upvalues: l__NoLanes__2 (ref), l__mergeLanes__3 (copy)
        l__NoLanes__2 = l__mergeLanes__3(p2, l__NoLanes__2);
    end
};