-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactTypeOfMode
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    NoMode = 0,
    StrictMode = 1,
    BlockingMode = 2,
    ConcurrentMode = 4,
    ProfileMode = 8,
    DebugTracingMode = 16
};