-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactRootTags
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    LegacyRoot = 0,
    BlockingRoot = 1,
    ConcurrentRoot = 2
};