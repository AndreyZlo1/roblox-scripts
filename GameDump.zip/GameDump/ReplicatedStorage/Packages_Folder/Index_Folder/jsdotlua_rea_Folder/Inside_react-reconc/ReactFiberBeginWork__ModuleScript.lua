-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberBeginWork.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
local l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2 = _G.__DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION__;
local l____COMPAT_WARNINGS____3 = _G.__COMPAT_WARNINGS__;
local l__console__4 = require(script.Parent.Parent:WaitForChild("shared")).console;
local v1 = require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local l__Array__5 = v1.Array;
local l__Object__6 = v1.Object;
local l__inspect__7 = v1.util.inspect;
require(script.Parent.Parent:WaitForChild("shared"));
require(script.Parent.Parent:WaitForChild("react"));
require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__ReactFiberLane__8 = require(script.Parent:WaitForChild("ReactFiberLane"));
require(script.Parent:WaitForChild("ReactFiberSuspenseComponent.new"));
local v2 = require(script.Parent:WaitForChild("ReactFiberSuspenseContext.new"));
require(script.Parent:WaitForChild("ReactFiberOffscreenComponent"));
local l__checkPropTypes__9 = require(script.Parent.Parent:WaitForChild("shared")).checkPropTypes;
local l__ReactWorkTags__10 = require(script.Parent:WaitForChild("ReactWorkTags"));
local l__FunctionComponent__11 = l__ReactWorkTags__10.FunctionComponent;
local l__ClassComponent__12 = l__ReactWorkTags__10.ClassComponent;
local l__HostRoot__13 = l__ReactWorkTags__10.HostRoot;
local l__HostComponent__14 = l__ReactWorkTags__10.HostComponent;
local l__HostText__15 = l__ReactWorkTags__10.HostText;
local l__HostPortal__16 = l__ReactWorkTags__10.HostPortal;
local l__ForwardRef__17 = l__ReactWorkTags__10.ForwardRef;
local l__Fragment__18 = l__ReactWorkTags__10.Fragment;
local l__Mode__19 = l__ReactWorkTags__10.Mode;
local l__ContextProvider__20 = l__ReactWorkTags__10.ContextProvider;
local l__ContextConsumer__21 = l__ReactWorkTags__10.ContextConsumer;
local l__Profiler__22 = l__ReactWorkTags__10.Profiler;
local l__SuspenseComponent__23 = l__ReactWorkTags__10.SuspenseComponent;
local l__SuspenseListComponent__24 = l__ReactWorkTags__10.SuspenseListComponent;
local l__MemoComponent__25 = l__ReactWorkTags__10.MemoComponent;
local l__SimpleMemoComponent__26 = l__ReactWorkTags__10.SimpleMemoComponent;
local l__LazyComponent__27 = l__ReactWorkTags__10.LazyComponent;
local l__IncompleteClassComponent__28 = l__ReactWorkTags__10.IncompleteClassComponent;
local l__OffscreenComponent__29 = l__ReactWorkTags__10.OffscreenComponent;
local l__LegacyHiddenComponent__30 = l__ReactWorkTags__10.LegacyHiddenComponent;
local l__ReactFiberFlags__31 = require(script.Parent:WaitForChild("ReactFiberFlags"));
local l__NoFlags__32 = l__ReactFiberFlags__31.NoFlags;
local l__StaticMask__33 = l__ReactFiberFlags__31.StaticMask;
local l__PerformedWork__34 = l__ReactFiberFlags__31.PerformedWork;
local l__Placement__35 = l__ReactFiberFlags__31.Placement;
local l__Hydrating__36 = l__ReactFiberFlags__31.Hydrating;
local l__ContentReset__37 = l__ReactFiberFlags__31.ContentReset;
local l__DidCapture__38 = l__ReactFiberFlags__31.DidCapture;
local l__Ref__39 = l__ReactFiberFlags__31.Ref;
local l__Deletion__40 = l__ReactFiberFlags__31.Deletion;
local l__ForceUpdateForLegacySuspense__41 = l__ReactFiberFlags__31.ForceUpdateForLegacySuspense;
local l__ReactSharedInternals__42 = require(script.Parent.Parent:WaitForChild("shared")).ReactSharedInternals;
local l__ReactFeatureFlags__43 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags;
local l__debugRenderPhaseSideEffectsForStrictMode__44 = l__ReactFeatureFlags__43.debugRenderPhaseSideEffectsForStrictMode;
local l__disableLegacyContext__45 = l__ReactFeatureFlags__43.disableLegacyContext;
local l__disableModulePatternComponents__46 = l__ReactFeatureFlags__43.disableModulePatternComponents;
local l__enableProfilerTimer__47 = l__ReactFeatureFlags__43.enableProfilerTimer;
local l__enableSchedulerTracing__48 = l__ReactFeatureFlags__43.enableSchedulerTracing;
local l__enableSuspenseServerRenderer__49 = l__ReactFeatureFlags__43.enableSuspenseServerRenderer;
local l__warnAboutDefaultPropsOnFunctionComponents__50 = l__ReactFeatureFlags__43.warnAboutDefaultPropsOnFunctionComponents;
local l__invariant__51 = require(script.Parent.Parent:WaitForChild("shared")).invariant;
local l__describeError__52 = require(script.Parent.Parent:WaitForChild("shared")).describeError;
local l__shallowEqual__53 = require(script.Parent.Parent:WaitForChild("shared")).shallowEqual;
local l__getComponentName__54 = require(script.Parent.Parent:WaitForChild("shared")).getComponentName;
local l__ReactSymbols__55 = require(script.Parent.Parent:WaitForChild("shared")).ReactSymbols;
local l__REACT_LAZY_TYPE__56 = l__ReactSymbols__55.REACT_LAZY_TYPE;
local _ = l__ReactSymbols__55.getIteratorFn;
local u3 = require(script.Parent:WaitForChild("ReactStrictModeWarnings.new"));
local l__ReactCurrentFiber__57 = require(script.Parent:WaitForChild("ReactCurrentFiber"));
local l__getCurrentFiberOwnerNameInDevOrNull__58 = l__ReactCurrentFiber__57.getCurrentFiberOwnerNameInDevOrNull;
local l__setIsRendering__59 = l__ReactCurrentFiber__57.setIsRendering;
local v4 = require(script.Parent:WaitForChild("ReactFiberHotReloading.new"));
local l__resolveFunctionForHotReloading__60 = v4.resolveFunctionForHotReloading;
local l__resolveForwardRefForHotReloading__61 = v4.resolveForwardRefForHotReloading;
local l__resolveClassForHotReloading__62 = v4.resolveClassForHotReloading;
local v5 = require(script.Parent:WaitForChild("ReactChildFiber.new"));
local l__mountChildFibers__63 = v5.mountChildFibers;
local l__reconcileChildFibers__64 = v5.reconcileChildFibers;
local l__cloneChildFibers__65 = v5.cloneChildFibers;
local v6 = require(script.Parent:WaitForChild("ReactUpdateQueue.new"));
local l__processUpdateQueue__66 = v6.processUpdateQueue;
local l__cloneUpdateQueue__67 = v6.cloneUpdateQueue;
local l__initializeUpdateQueue__68 = v6.initializeUpdateQueue;
local l__ReactTypeOfMode__69 = require(script.Parent:WaitForChild("ReactTypeOfMode"));
local l__ConcurrentMode__70 = l__ReactTypeOfMode__69.ConcurrentMode;
local l__NoMode__71 = l__ReactTypeOfMode__69.NoMode;
local l__ProfileMode__72 = l__ReactTypeOfMode__69.ProfileMode;
local l__StrictMode__73 = l__ReactTypeOfMode__69.StrictMode;
local l__BlockingMode__74 = l__ReactTypeOfMode__69.BlockingMode;
local l__ReactFiberHostConfig__75 = require(script.Parent:WaitForChild("ReactFiberHostConfig"));
local l__shouldSetTextContent__76 = l__ReactFiberHostConfig__75.shouldSetTextContent;
local l__isSuspenseInstancePending__77 = l__ReactFiberHostConfig__75.isSuspenseInstancePending;
local l__isSuspenseInstanceFallback__78 = l__ReactFiberHostConfig__75.isSuspenseInstanceFallback;
local l__registerSuspenseInstanceRetry__79 = l__ReactFiberHostConfig__75.registerSuspenseInstanceRetry;
local l__supportsHydration__80 = l__ReactFiberHostConfig__75.supportsHydration;
local v7 = require(script.Parent:WaitForChild("ReactFiberHostContext.new"));
local l__pushHostContext__81 = v7.pushHostContext;
local l__pushHostContainer__82 = v7.pushHostContainer;
local l__suspenseStackCursor__83 = v2.suspenseStackCursor;
local l__hasSuspenseContext__84 = v2.hasSuspenseContext;
local l__ForceSuspenseFallback__85 = v2.ForceSuspenseFallback;
local l__addSubtreeSuspenseContext__86 = v2.addSubtreeSuspenseContext;
local l__InvisibleParentSuspenseContext__87 = v2.InvisibleParentSuspenseContext;
local l__pushSuspenseContext__88 = v2.pushSuspenseContext;
local l__setDefaultShallowSuspenseContext__89 = v2.setDefaultShallowSuspenseContext;
local v8 = require(script.Parent:WaitForChild("ReactFiberNewContext.new"));
local l__propagateContextChange__90 = v8.propagateContextChange;
local l__readContext__91 = v8.readContext;
local l__calculateChangedBits__92 = v8.calculateChangedBits;
local l__prepareToReadContext__93 = v8.prepareToReadContext;
local l__pushProvider__94 = v8.pushProvider;
local u9 = {
    renderWithHooksRef = nil,
    bailoutHooksRef = nil,
    shouldSuspendRef = nil
};
local function u11(...) --[[ Line: 200 ]]
    -- upvalues: u9 (copy)
    if not u9.renderWithHooksRef then
        local v10 = require(script.Parent:WaitForChild("ReactFiberHooks.new"));
        u9.renderWithHooksRef = v10.renderWithHooks;
        u9.bailoutHooksRef = v10.bailoutHooks;
    end;
    return u9.renderWithHooksRef(...);
end;
local function u13(...) --[[ Line: 208 ]]
    -- upvalues: u9 (copy)
    if not u9.bailoutHooksRef then
        local v12 = require(script.Parent:WaitForChild("ReactFiberHooks.new"));
        u9.renderWithHooksRef = v12.renderWithHooks;
        u9.bailoutHooksRef = v12.bailoutHooks;
    end;
    return u9.bailoutHooksRef(...);
end;
local l__stopProfilerTimerIfRunning__95 = require(script.Parent:WaitForChild("ReactProfilerTimer.new")).stopProfilerTimerIfRunning;
local v14 = require(script.Parent:WaitForChild("ReactFiberContext.new"));
local l__getMaskedContext__96 = v14.getMaskedContext;
local l__getUnmaskedContext__97 = v14.getUnmaskedContext;
local l__hasContextChanged__98 = v14.hasContextChanged;
local l__pushContextProvider__99 = v14.pushContextProvider;
local l__isContextProvider__100 = v14.isContextProvider;
local l__pushTopLevelContextObject__101 = v14.pushTopLevelContextObject;
local l__invalidateContextProvider__102 = v14.invalidateContextProvider;
local v15 = require(script.Parent:WaitForChild("ReactFiberHydrationContext.new"));
local l__resetHydrationState__103 = v15.resetHydrationState;
local l__enterHydrationState__104 = v15.enterHydrationState;
local l__reenterHydrationStateFromDehydratedSuspenseInstance__105 = v15.reenterHydrationStateFromDehydratedSuspenseInstance;
local l__tryToClaimNextHydratableInstance__106 = v15.tryToClaimNextHydratableInstance;
local l__warnIfHydrating__107 = v15.warnIfHydrating;
local v16 = require(script.Parent:WaitForChild("ReactFiberClassComponent.new"));
local l__adoptClassInstance__108 = v16.adoptClassInstance;
local l__applyDerivedStateFromProps__109 = v16.applyDerivedStateFromProps;
local l__constructClassInstance__110 = v16.constructClassInstance;
local l__mountClassInstance__111 = v16.mountClassInstance;
local l__resumeMountClassInstance__112 = v16.resumeMountClassInstance;
local l__updateClassInstance__113 = v16.updateClassInstance;
local l__resolveDefaultProps__114 = require(script.Parent:WaitForChild("ReactFiberLazyComponent.new")).resolveDefaultProps;
local v17 = require(script.Parent:WaitForChild("ReactFiber.new"));
local l__resolveLazyComponentTag__115 = v17.resolveLazyComponentTag;
local l__createFiberFromFragment__116 = v17.createFiberFromFragment;
local l__createFiberFromOffscreen__117 = v17.createFiberFromOffscreen;
local l__createFiberFromTypeAndProps__118 = v17.createFiberFromTypeAndProps;
local l__isSimpleFunctionComponent__119 = v17.isSimpleFunctionComponent;
local l__createWorkInProgress__120 = v17.createWorkInProgress;
local v18 = require(script.Parent:WaitForChild("ReactFiberWorkLoop.new"));
local l__pushRenderLanes__121 = v18.pushRenderLanes;
local l__markSpawnedWork__122 = v18.markSpawnedWork;
local l__retryDehydratedSuspenseBoundary__123 = v18.retryDehydratedSuspenseBoundary;
local l__scheduleUpdateOnFiber__124 = v18.scheduleUpdateOnFiber;
local l__renderDidSuspendDelayIfPossible__125 = v18.renderDidSuspendDelayIfPossible;
local l__getWorkInProgressRoot__126 = v18.getWorkInProgressRoot;
local l__getExecutionContext__127 = v18.getExecutionContext;
local l__RetryAfterError__128 = v18.RetryAfterError;
local l__NoContext__129 = v18.NoContext;
local u19 = nil;
local l__setWorkInProgressVersion__130 = require(script.Parent:WaitForChild("ReactMutableSource.new")).setWorkInProgressVersion;
local l__markSkippedUpdateLanes__131 = require(script.Parent:WaitForChild("ReactFiberWorkInProgress")).markSkippedUpdateLanes;
local l__ConsolePatchingDev__132 = require(script.Parent.Parent:WaitForChild("shared")).ConsolePatchingDev;
local l__disableLogs__133 = l__ConsolePatchingDev__132.disableLogs;
local l__reenableLogs__134 = l__ConsolePatchingDev__132.reenableLogs;
local l__ReactCurrentOwner__135 = l__ReactSharedInternals__42.ReactCurrentOwner;
local u20 = {};
local u21 = nil;
local u22 = nil;
local u23 = false;
local u24 = {
    didWarnAboutBadClass = {},
    didWarnAboutModulePatternComponent = {},
    didWarnAboutContextTypeOnFunctionComponent = {},
    didWarnAboutGetDerivedStateOnFunctionComponent = {},
    didWarnAboutFunctionRefs = {},
    didWarnAboutDefaultPropsOnFunctionComponent = {}
};
local u25 = nil;
if l____DEV____1 then
    u24.didWarnAboutBadClass = {};
    u24.didWarnAboutModulePatternComponent = {};
    u24.didWarnAboutContextTypeOnFunctionComponent = {};
    u24.didWarnAboutGetDerivedStateOnFunctionComponent = {};
    u24.didWarnAboutFunctionRefs = {};
    u20.didWarnAboutReassigningProps = false;
    u24.didWarnAboutDefaultPropsOnFunctionComponent = {};
end;
local function u34(p26, p27, p28, p29, p30) --[[ Line: 360 ]]
    -- upvalues: l____DEV____1 (copy), l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2 (copy), l__checkPropTypes__9 (copy), l__getComponentName__54 (copy), l__prepareToReadContext__93 (copy), u20 (copy), l__ReactCurrentOwner__135 (copy), l__setIsRendering__59 (copy), u11 (copy), l__debugRenderPhaseSideEffectsForStrictMode__44 (copy), l__StrictMode__73 (copy), l__disableLogs__133 (copy), l__describeError__52 (copy), l__reenableLogs__134 (copy), u23 (ref), u13 (copy), u21 (ref), l__PerformedWork__34 (copy), l__mountChildFibers__63 (copy), l__reconcileChildFibers__64 (copy)
    if (l____DEV____1 or l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2) and p27.type ~= p27.elementType then
        local l__propTypes__136 = p28.propTypes;
        local l__validateProps__137 = p28.validateProps;
        if l__propTypes__136 or l__validateProps__137 then
            l__checkPropTypes__9(l__propTypes__136, l__validateProps__137, p29, "prop", l__getComponentName__54(p28));
        end;
    end;
    local l__render__138 = p28.render;
    local l__ref__139 = p27.ref;
    l__prepareToReadContext__93(p27, p30, u20.markWorkInProgressReceivedUpdate);
    local v31;
    if l____DEV____1 then
        l__ReactCurrentOwner__135.current = p27;
        l__setIsRendering__59(true);
        v31 = u11(p26, p27, l__render__138, p29, l__ref__139, p30);
        if l__debugRenderPhaseSideEffectsForStrictMode__44 and bit32.band(p27.mode, l__StrictMode__73) ~= 0 then
            l__disableLogs__133();
            local v32, v33 = xpcall(u11, l__describeError__52, p26, p27, l__render__138, p29, l__ref__139, p30);
            if v32 then
                v31 = v33;
            end;
            l__reenableLogs__134();
            if not v32 then
                error(v33);
            end;
        end;
        l__setIsRendering__59(false);
    else
        v31 = u11(p26, p27, l__render__138, p29, l__ref__139, p30);
    end;
    if p26 ~= nil and not u23 then
        u13(p26, p27, p30);
        return u21(p26, p27, p30);
    end;
    p27.flags = bit32.bor(p27.flags, l__PerformedWork__34);
    if p26 == nil then
        p27.child = l__mountChildFibers__63(p27, nil, v31, p30);
    else
        p27.child = l__reconcileChildFibers__64(p27, p26.child, v31, p30);
    end;
    return p27.child;
end;
local function u48(p35, p36, p37, p38, p39, p40) --[[ Line: 447 ]]
    -- upvalues: l__isSimpleFunctionComponent__119 (copy), l____DEV____1 (copy), l__resolveFunctionForHotReloading__60 (copy), l__SimpleMemoComponent__26 (copy), u25 (ref), l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2 (copy), l__checkPropTypes__9 (copy), l__getComponentName__54 (copy), l__createFiberFromTypeAndProps__118 (copy), l__ReactFiberLane__8 (copy), l__shallowEqual__53 (copy), u21 (ref), l__PerformedWork__34 (copy), l__createWorkInProgress__120 (copy)
    if p35 == nil then
        local l__type__140 = p37.type;
        if l__isSimpleFunctionComponent__119(l__type__140) and (p37.compare == nil and p37.defaultProps == nil) then
            local v41;
            if l____DEV____1 then
                v41 = l__resolveFunctionForHotReloading__60(l__type__140);
            else
                v41 = l__type__140;
            end;
            p36.tag = l__SimpleMemoComponent__26;
            p36.type = v41;
            if l____DEV____1 then
                validateFunctionComponentInDev(p36, l__type__140);
            end;
            return u25(p35, p36, v41, p38, p39, p40);
        end;
        if l____DEV____1 or l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2 then
            local v42, v43;
            if type(l__type__140) == "table" then
                v42 = l__type__140.propTypes;
                v43 = l__type__140.validateProps;
            else
                v42 = nil;
                v43 = nil;
            end;
            if v42 or v43 then
                l__checkPropTypes__9(v42, v43, p38, "prop", l__getComponentName__54(l__type__140));
            end;
        end;
        local v44 = l__createFiberFromTypeAndProps__118(p37.type, nil, p38, p36, p36.mode, p40);
        v44.ref = p36.ref;
        v44.return_ = p36;
        p36.child = v44;
        return v44;
    end;
    if l____DEV____1 or l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2 then
        local l__type__141 = p37.type;
        local v45, v46;
        if type(l__type__141) == "table" then
            v45 = l__type__141.propTypes;
            v46 = l__type__141.validateProps;
        else
            v45 = nil;
            v46 = nil;
        end;
        if v45 or v46 then
            l__checkPropTypes__9(v45, v46, p38, "prop", l__getComponentName__54(l__type__141));
        end;
    end;
    local l__child__142 = p35.child;
    if not l__ReactFiberLane__8.includesSomeLane(p39, p40) then
        local l__memoizedProps__143 = l__child__142.memoizedProps;
        local l__compare__144 = p37.compare;
        if l__compare__144 == nil then
            l__compare__144 = l__shallowEqual__53;
        end;
        if l__compare__144(l__memoizedProps__143, p38) and p35.ref == p36.ref then
            return u21(p35, p36, p40);
        end;
    end;
    p36.flags = bit32.bor(p36.flags, l__PerformedWork__34);
    local v47 = l__createWorkInProgress__120(l__child__142, p38);
    v47.ref = p36.ref;
    v47.return_ = p36;
    p36.child = v47;
    return v47;
end;
local function u60(p49, p50, p51, p52, p53, p54) --[[ Line: 568 ]]
    -- upvalues: l____DEV____1 (copy), l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2 (copy), l__REACT_LAZY_TYPE__56 (copy), l__describeError__52 (copy), l__checkPropTypes__9 (copy), l__getComponentName__54 (copy), l__shallowEqual__53 (copy), u23 (ref), l__ReactFiberLane__8 (copy), u21 (ref), l__ForceUpdateForLegacySuspense__41 (copy), l__NoFlags__32 (copy), u22 (ref)
    if (l____DEV____1 or l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2) and p50.type ~= p50.elementType then
        local l__elementType__145 = p50.elementType;
        if l__elementType__145["$$typeof"] == l__REACT_LAZY_TYPE__56 then
            local v55, v56 = xpcall(l__elementType__145._init, l__describeError__52, l__elementType__145._payload);
            if not v55 then
                v56 = nil;
            end;
            local v57, v58;
            if v56 == nil or type(v56) ~= "table" then
                v57 = nil;
                v58 = nil;
            else
                v57 = v56.propTypes;
                v58 = v56.validateProps;
            end;
            if v57 or v58 then
                l__checkPropTypes__9(v57, v58, p52, "prop", l__getComponentName__54(v56));
            end;
        end;
    end;
    if p49 ~= nil then
        local l__memoizedProps__146 = p49.memoizedProps;
        local v59 = not l____DEV____1 and true or p50.type == p49.type;
        if l__shallowEqual__53(l__memoizedProps__146, p52) and (p49.ref == p50.ref and v59) then
            u23 = false;
            if not l__ReactFiberLane__8.includesSomeLane(p54, p53) then
                p50.lanes = p49.lanes;
                return u21(p49, p50, p54);
            end;
            if bit32.band(p49.flags, l__ForceUpdateForLegacySuspense__41) ~= l__NoFlags__32 then
                u23 = true;
            end;
        end;
    end;
    return u22(p49, p50, p51, p52, p54);
end;
local function u67(p61, p62, p63) --[[ Line: 670 ]]
    -- upvalues: l__ConcurrentMode__70 (copy), l__NoMode__71 (copy), l__ReactFiberLane__8 (copy), l__pushRenderLanes__121 (copy), l__enableSchedulerTracing__48 (copy), l__markSpawnedWork__122 (copy), l__mountChildFibers__63 (copy), l__reconcileChildFibers__64 (copy)
    local l__pendingProps__147 = p62.pendingProps;
    local l__children__148 = l__pendingProps__147.children;
    local v64;
    if p61 == nil then
        v64 = nil;
    else
        v64 = p61.memoizedState;
    end;
    if l__pendingProps__147.mode == "hidden" or l__pendingProps__147.mode == "unstable-defer-without-hiding" then
        if bit32.band(p62.mode, l__ConcurrentMode__70) == l__NoMode__71 then
            p62.memoizedState = {
                baseLanes = l__ReactFiberLane__8.NoLanes
            };
            l__pushRenderLanes__121(p62, p63);
        else
            if not l__ReactFiberLane__8.includesSomeLane(p63, l__ReactFiberLane__8.OffscreenLane) then
                if v64 ~= nil then
                    p63 = l__ReactFiberLane__8.mergeLanes(v64.baseLanes, p63);
                end;
                if l__enableSchedulerTracing__48 then
                    l__markSpawnedWork__122(l__ReactFiberLane__8.OffscreenLane);
                end;
                p62.childLanes = l__ReactFiberLane__8.laneToLanes(l__ReactFiberLane__8.OffscreenLane);
                p62.lanes = p62.childLanes;
                p62.memoizedState = {
                    baseLanes = p63
                };
                l__pushRenderLanes__121(p62, p63);
                return nil;
            end;
            p62.memoizedState = {
                baseLanes = l__ReactFiberLane__8.NoLanes
            };
            local v65;
            if v64 == nil then
                v65 = p63;
            else
                v65 = v64.baseLanes;
            end;
            l__pushRenderLanes__121(p62, v65);
        end;
    else
        local v66;
        if v64 == nil then
            v66 = p63;
        else
            v66 = l__ReactFiberLane__8.mergeLanes(v64.baseLanes, p63);
            p62.memoizedState = nil;
        end;
        l__pushRenderLanes__121(p62, v66);
    end;
    if p61 == nil then
        p62.child = l__mountChildFibers__63(p62, nil, l__children__148, p63);
    else
        p62.child = l__reconcileChildFibers__64(p62, p61.child, l__children__148, p63);
    end;
    return p62.child;
end;
function updateFragment(p68, p69, p70)
    -- upvalues: l__mountChildFibers__63 (copy), l__reconcileChildFibers__64 (copy)
    local l__pendingProps__149 = p69.pendingProps;
    if p68 == nil then
        p69.child = l__mountChildFibers__63(p69, nil, l__pendingProps__149, p70);
    else
        p69.child = l__reconcileChildFibers__64(p69, p68.child, l__pendingProps__149, p70);
    end;
    return p69.child;
end;
function updateMode(p71, p72, p73)
    -- upvalues: l__mountChildFibers__63 (copy), l__reconcileChildFibers__64 (copy)
    local l__children__150 = p72.pendingProps.children;
    if p71 == nil then
        p72.child = l__mountChildFibers__63(p72, nil, l__children__150, p73);
    else
        p72.child = l__reconcileChildFibers__64(p72, p71.child, l__children__150, p73);
    end;
    return p72.child;
end;
function updateProfiler(p74, p75, p76)
    -- upvalues: l__enableProfilerTimer__47 (copy), l__mountChildFibers__63 (copy), l__reconcileChildFibers__64 (copy)
    if l__enableProfilerTimer__47 then
        local l__stateNode__151 = p75.stateNode;
        l__stateNode__151.effectDuration = 0;
        l__stateNode__151.passiveEffectDuration = 0;
    end;
    local l__children__152 = p75.pendingProps.children;
    if p74 == nil then
        p75.child = l__mountChildFibers__63(p75, nil, l__children__152, p76);
    else
        p75.child = l__reconcileChildFibers__64(p75, p74.child, l__children__152, p76);
    end;
    return p75.child;
end;
local function u88(p77, p78, p79, p80, p81) --[[ Line: 809 ]]
    -- upvalues: l____DEV____1 (copy), l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2 (copy), l__checkPropTypes__9 (copy), l__getComponentName__54 (copy), l__disableLegacyContext__45 (copy), l__getUnmaskedContext__97 (copy), l__getMaskedContext__96 (copy), l__prepareToReadContext__93 (copy), u20 (copy), l__ReactCurrentOwner__135 (copy), l__setIsRendering__59 (copy), u11 (copy), l__debugRenderPhaseSideEffectsForStrictMode__44 (copy), l__StrictMode__73 (copy), l__disableLogs__133 (copy), l__describeError__52 (copy), l__reenableLogs__134 (copy), u23 (ref), u13 (copy), u21 (ref), l__PerformedWork__34 (copy), l__mountChildFibers__63 (copy), l__reconcileChildFibers__64 (copy)
    if (l____DEV____1 or l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2) and (type(p79) ~= "function" and p78.type ~= p78.elementType) then
        local v82, v83;
        if type(p79) == "table" then
            v82 = p79.propTypes;
            v83 = p79.validateProps;
        else
            v82 = nil;
            v83 = nil;
        end;
        if v82 or v83 then
            l__checkPropTypes__9(v82, v83, p80, "prop", l__getComponentName__54(p79));
        end;
    end;
    local v84;
    if l__disableLegacyContext__45 then
        v84 = nil;
    else
        v84 = l__getMaskedContext__96(p78, (l__getUnmaskedContext__97(p78, p79, true)));
    end;
    l__prepareToReadContext__93(p78, p81, u20.markWorkInProgressReceivedUpdate);
    local v85;
    if l____DEV____1 then
        l__ReactCurrentOwner__135.current = p78;
        l__setIsRendering__59(true);
        v85 = u11(p77, p78, p79, p80, v84, p81);
        if l__debugRenderPhaseSideEffectsForStrictMode__44 and bit32.band(p78.mode, l__StrictMode__73) ~= 0 then
            l__disableLogs__133();
            local v86, v87 = xpcall(u11, l__describeError__52, p77, p78, p79, p80, v84, p81);
            l__reenableLogs__134();
            if v86 then
                v85 = v87;
            else
                error(v87);
            end;
        end;
        l__setIsRendering__59(false);
    else
        v85 = u11(p77, p78, p79, p80, v84, p81);
    end;
    if p77 ~= nil and not u23 then
        u13(p77, p78, p81);
        return u21(p77, p78, p81);
    end;
    p78.flags = bit32.bor(p78.flags, l__PerformedWork__34);
    if p77 == nil then
        p78.child = l__mountChildFibers__63(p78, nil, v85, p81);
    else
        p78.child = l__reconcileChildFibers__64(p78, p77.child, v85, p81);
    end;
    return p78.child;
end;
local function u97(p89, p90, p91, p92, p93) --[[ Line: 988 ]]
    -- upvalues: l____DEV____1 (copy), l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2 (copy), l__checkPropTypes__9 (copy), l__getComponentName__54 (copy), l__isContextProvider__100 (copy), l__pushContextProvider__99 (copy), l__prepareToReadContext__93 (copy), u20 (copy), l__Placement__35 (copy), l__constructClassInstance__110 (copy), l__mountClassInstance__111 (copy), l__resumeMountClassInstance__112 (copy), l__updateClassInstance__113 (copy), l__console__4 (copy)
    if (l____DEV____1 or l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2) and p90.type ~= p90.elementType then
        local l__propTypes__153 = p91.propTypes;
        local l__validateProps__154 = p91.validateProps;
        if l__propTypes__153 or l__validateProps__154 then
            l__checkPropTypes__9(l__propTypes__153, l__validateProps__154, p92, "prop", l__getComponentName__54(p91));
        end;
    end;
    local v94;
    if l__isContextProvider__100(p91) then
        l__pushContextProvider__99(p90);
        v94 = true;
    else
        v94 = false;
    end;
    l__prepareToReadContext__93(p90, p93, u20.markWorkInProgressReceivedUpdate);
    local v95;
    if p90.stateNode == nil then
        if p89 ~= nil then
            p89.alternate = nil;
            p90.alternate = nil;
            p90.flags = bit32.bor(p90.flags, l__Placement__35);
        end;
        l__constructClassInstance__110(p90, p91, p92);
        l__mountClassInstance__111(p90, p91, p92, p93);
        v95 = true;
    elseif p89 == nil then
        v95 = l__resumeMountClassInstance__112(p90, p91, p92, p93);
    else
        v95 = l__updateClassInstance__113(p89, p90, p91, p92, p93);
    end;
    local v96 = finishClassComponent(p89, p90, p91, v95, v94, p93);
    if l____DEV____1 and (v95 and p90.stateNode.props ~= p92) then
        if not u20.didWarnAboutReassigningProps then
            l__console__4.error("It looks like %s is reassigning its own `this.props` while rendering. This is not supported and can lead to confusing bugs.", l__getComponentName__54(p90.type) or "a component");
        end;
        u20.didWarnAboutReassigningProps = true;
    end;
    return v96;
end;
function finishClassComponent(p98, p99, p100, p101, p102, p103)
    -- upvalues: l__Ref__39 (copy), l__DidCapture__38 (copy), l__NoFlags__32 (copy), l__invalidateContextProvider__102 (copy), u21 (ref), l__ReactCurrentOwner__135 (copy), l__enableProfilerTimer__47 (copy), l__stopProfilerTimerIfRunning__95 (copy), l____DEV____1 (copy), l__setIsRendering__59 (copy), l__debugRenderPhaseSideEffectsForStrictMode__44 (copy), l__StrictMode__73 (copy), l__disableLogs__133 (copy), l__describeError__52 (copy), l__reenableLogs__134 (copy), l__PerformedWork__34 (copy), l__reconcileChildFibers__64 (copy), l__mountChildFibers__63 (copy)
    local l__ref__155 = p99.ref;
    if p98 == nil and l__ref__155 ~= nil or p98 ~= nil and p98.ref ~= l__ref__155 then
        p99.flags = bit32.bor(p99.flags, l__Ref__39);
    end;
    local v104 = bit32.band(p99.flags, l__DidCapture__38) ~= l__NoFlags__32;
    if not (p101 or v104) then
        if p102 then
            l__invalidateContextProvider__102(p99, p100, false);
        end;
        return u21(p98, p99, p103);
    end;
    local l__stateNode__156 = p99.stateNode;
    l__ReactCurrentOwner__135.current = p99;
    local v105;
    if v104 and (p100.getDerivedStateFromError == nil or type(p100.getDerivedStateFromError) ~= "function") then
        v105 = nil;
        if l__enableProfilerTimer__47 then
            l__stopProfilerTimerIfRunning__95(p99);
        end;
    elseif l____DEV____1 then
        l__setIsRendering__59(true);
        v105 = l__stateNode__156:render();
        if l__debugRenderPhaseSideEffectsForStrictMode__44 and bit32.band(p99.mode, l__StrictMode__73) ~= 0 then
            l__disableLogs__133();
            local v106, v107 = xpcall(l__stateNode__156.render, l__describeError__52, l__stateNode__156);
            l__reenableLogs__134();
            if not v106 then
                error(v107);
            end;
        end;
        l__setIsRendering__59(false);
    else
        v105 = l__stateNode__156:render();
    end;
    p99.flags = bit32.bor(p99.flags, l__PerformedWork__34);
    if p98 == nil or not v104 then
        if p98 == nil then
            p99.child = l__mountChildFibers__63(p99, nil, v105, p103);
        else
            p99.child = l__reconcileChildFibers__64(p99, p98.child, v105, p103);
        end;
    else
        p99.child = l__reconcileChildFibers__64(p99, p98.child, nil, p103);
        p99.child = l__reconcileChildFibers__64(p99, nil, v105, p103);
    end;
    p99.memoizedState = l__stateNode__156.state;
    if p102 then
        l__invalidateContextProvider__102(p99, p100, true);
    end;
    return p99.child;
end;
local function u118(p108, p109, p110) --[[ Line: 1199 ]]
    -- upvalues: l__pushTopLevelContextObject__101 (copy), l__pushHostContainer__82 (copy), l__invariant__51 (copy), l__cloneUpdateQueue__67 (copy), l__processUpdateQueue__66 (copy), l__resetHydrationState__103 (copy), u21 (ref), l__enterHydrationState__104 (copy), l__supportsHydration__80 (copy), l__setWorkInProgressVersion__130 (copy), l__mountChildFibers__63 (copy), l__Placement__35 (copy), l__Hydrating__36 (copy), l__reconcileChildFibers__64 (copy)
    local l__stateNode__157 = p109.stateNode;
    if l__stateNode__157.pendingContext then
        l__pushTopLevelContextObject__101(p109, l__stateNode__157.pendingContext, l__stateNode__157.pendingContext ~= l__stateNode__157.context);
    elseif l__stateNode__157.context then
        l__pushTopLevelContextObject__101(p109, l__stateNode__157.context, false);
    end;
    l__pushHostContainer__82(p109, l__stateNode__157.containerInfo);
    local l__updateQueue__158 = p109.updateQueue;
    local v111 = l__invariant__51;
    local v112;
    if p108 == nil then
        v112 = false;
    else
        v112 = l__updateQueue__158 ~= nil;
    end;
    v111(v112, "If the root does not have an updateQueue, we should have already bailed out. This error is likely caused by a bug in React. Please file an issue.");
    local l__pendingProps__159 = p109.pendingProps;
    local l__memoizedState__160 = p109.memoizedState;
    local v113;
    if l__memoizedState__160 == nil then
        v113 = nil;
    else
        v113 = l__memoizedState__160.element;
    end;
    l__cloneUpdateQueue__67(p108, p109);
    l__processUpdateQueue__66(p109, l__pendingProps__159, nil, p110);
    local l__element__161 = p109.memoizedState.element;
    if l__element__161 == v113 then
        l__resetHydrationState__103();
        return u21(p108, p109, p110);
    end;
    local l__stateNode__162 = p109.stateNode;
    if l__stateNode__162.hydrate and l__enterHydrationState__104(p109) then
        if l__supportsHydration__80 then
            local l__mutableSourceEagerHydrationData__163 = l__stateNode__162.mutableSourceEagerHydrationData;
            if l__mutableSourceEagerHydrationData__163 ~= nil then
                for v114 = 1, #l__mutableSourceEagerHydrationData__163, 2 do
                    l__setWorkInProgressVersion__130(l__mutableSourceEagerHydrationData__163[v114], l__mutableSourceEagerHydrationData__163[v114 + 1]);
                end;
            end;
        end;
        local v115 = l__mountChildFibers__63(p109, nil, l__element__161, p110);
        p109.child = v115;
        while v115 do
            local l__flags__164 = v115.flags;
            local v116 = bit32.bnot(l__Placement__35);
            local v117 = bit32.band(l__flags__164, v116);
            v115.flags = bit32.bor(v117, l__Hydrating__36);
            v115 = v115.sibling;
        end;
    else
        if p108 == nil then
            p109.child = l__mountChildFibers__63(p109, nil, l__element__161, p110);
        else
            p109.child = l__reconcileChildFibers__64(p109, p108.child, l__element__161, p110);
        end;
        l__resetHydrationState__103();
    end;
    return p109.child;
end;
local function u123(p119, p120, p121) --[[ Line: 1276 ]]
    -- upvalues: l__pushHostContext__81 (copy), l__tryToClaimNextHydratableInstance__106 (copy), l__shouldSetTextContent__76 (copy), l__ContentReset__37 (copy), l__PerformedWork__34 (copy), l__Ref__39 (copy), l__mountChildFibers__63 (copy), l__reconcileChildFibers__64 (copy)
    l__pushHostContext__81(p120);
    if p119 == nil then
        l__tryToClaimNextHydratableInstance__106(p120);
    end;
    local l__type__165 = p120.type;
    local l__pendingProps__166 = p120.pendingProps;
    local v122;
    if p119 == nil then
        v122 = nil;
    else
        v122 = p119.memoizedProps;
    end;
    local l__children__167 = l__pendingProps__166.children;
    if l__shouldSetTextContent__76(l__type__165, l__pendingProps__166) then
        l__children__167 = nil;
    elseif v122 ~= nil and l__shouldSetTextContent__76(l__type__165, v122) then
        p120.flags = bit32.bor(p120.flags, l__ContentReset__37);
    end;
    p120.flags = bit32.bor(p120.flags, l__PerformedWork__34);
    local l__ref__168 = p120.ref;
    if p119 == nil and l__ref__168 ~= nil or p119 ~= nil and p119.ref ~= l__ref__168 then
        p120.flags = bit32.bor(p120.flags, l__Ref__39);
    end;
    if p119 == nil then
        p120.child = l__mountChildFibers__63(p120, nil, l__children__167, p121);
    else
        p120.child = l__reconcileChildFibers__64(p120, p119.child, l__children__167, p121);
    end;
    return p120.child;
end;
local function u132(p124, p125, p126, p127, p128) --[[ Line: 1326 ]]
    -- upvalues: l__Placement__35 (copy), l__resolveLazyComponentTag__115 (copy), l__resolveDefaultProps__114 (copy), l__FunctionComponent__11 (copy), l____DEV____1 (copy), l__resolveFunctionForHotReloading__60 (copy), u88 (ref), l__ClassComponent__12 (copy), l__resolveClassForHotReloading__62 (copy), u97 (copy), l__ForwardRef__17 (copy), l__resolveForwardRefForHotReloading__61 (copy), u34 (copy), l__MemoComponent__25 (copy), l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2 (copy), l__checkPropTypes__9 (copy), l__getComponentName__54 (copy), u48 (copy), l__REACT_LAZY_TYPE__56 (copy), l__inspect__7 (copy), l__invariant__51 (copy)
    if p124 ~= nil then
        p124.alternate = nil;
        p125.alternate = nil;
        p125.flags = bit32.bor(p125.flags, l__Placement__35);
    end;
    local l__pendingProps__169 = p125.pendingProps;
    local v129 = p126._init(p126._payload);
    p125.type = v129;
    p125.tag = l__resolveLazyComponentTag__115(v129);
    local l__tag__170 = p125.tag;
    local v130 = l__resolveDefaultProps__114(v129, l__pendingProps__169);
    if l__tag__170 == l__FunctionComponent__11 then
        if l____DEV____1 then
            validateFunctionComponentInDev(p125, v129);
            v129 = l__resolveFunctionForHotReloading__60(v129);
            p125.type = v129;
        end;
        return u88(nil, p125, v129, v130, p128);
    end;
    if l__tag__170 == l__ClassComponent__12 then
        if l____DEV____1 then
            v129 = l__resolveClassForHotReloading__62(v129);
            p125.type = v129;
        end;
        return u97(nil, p125, v129, v130, p128);
    end;
    if l__tag__170 == l__ForwardRef__17 then
        if l____DEV____1 then
            v129 = l__resolveForwardRefForHotReloading__61(v129);
            p125.type = v129;
        end;
        return u34(nil, p125, v129, v130, p128);
    end;
    if l__tag__170 == l__MemoComponent__25 then
        if (l____DEV____1 or l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2) and p125.type ~= p125.elementType then
            local l__propTypes__171 = v129.propTypes;
            local l__validateProps__172 = v129.validateProps;
            if l__propTypes__171 or l__validateProps__172 then
                l__checkPropTypes__9(l__propTypes__171, l__validateProps__172, v130, "prop", l__getComponentName__54(v129));
            end;
        end;
        return u48(nil, p125, v129, l__resolveDefaultProps__114(v129.type, v130), p127, p128);
    end;
    local v131 = "";
    if l____DEV____1 then
        if v129 == nil or (type(v129) ~= "table" or v129["$$typeof"] ~= l__REACT_LAZY_TYPE__56) then
            if type(v129) == "table" and v129["$$typeof"] == nil then
                v131 = "\n" .. l__inspect__7(v129);
            end;
        else
            v131 = " Did you wrap a component in React.lazy() more than once?";
        end;
    end;
    l__invariant__51(false, "Element type is invalid. Received a promise that resolves to: %s. Lazy element type must resolve to a class or function.%s", tostring(v129), v131);
    return nil;
end;
function mountIncompleteClassComponent(p133, p134, p135, p136, p137)
    -- upvalues: l__Placement__35 (copy), l__ClassComponent__12 (copy), l__isContextProvider__100 (copy), l__pushContextProvider__99 (copy), l__prepareToReadContext__93 (copy), u20 (copy), l__constructClassInstance__110 (copy), l__mountClassInstance__111 (copy)
    if p133 ~= nil then
        p133.alternate = nil;
        p134.alternate = nil;
        p134.flags = bit32.bor(p134.flags, l__Placement__35);
    end;
    p134.tag = l__ClassComponent__12;
    local v138;
    if l__isContextProvider__100(p135) then
        l__pushContextProvider__99(p134);
        v138 = true;
    else
        v138 = false;
    end;
    l__prepareToReadContext__93(p134, p137, u20.markWorkInProgressReceivedUpdate);
    l__constructClassInstance__110(p134, p135, p136);
    l__mountClassInstance__111(p134, p135, p136, p137);
    return finishClassComponent(nil, p134, p135, true, v138, p137);
end;
local function u153(p139, p140, p141, p142) --[[ Line: 1509 ]]
    -- upvalues: l__Placement__35 (copy), l__disableLegacyContext__45 (copy), l__getUnmaskedContext__97 (copy), l__getMaskedContext__96 (copy), l__prepareToReadContext__93 (copy), u20 (copy), l____DEV____1 (copy), l__getComponentName__54 (copy), u24 (copy), l__console__4 (copy), l__StrictMode__73 (copy), u3 (copy), l__setIsRendering__59 (copy), l__ReactCurrentOwner__135 (copy), u11 (copy), l__PerformedWork__34 (copy), l__disableModulePatternComponents__46 (copy), l__ClassComponent__12 (copy), l__isContextProvider__100 (copy), l__pushContextProvider__99 (copy), l__initializeUpdateQueue__68 (copy), l__applyDerivedStateFromProps__109 (copy), l__adoptClassInstance__108 (copy), l__mountClassInstance__111 (copy), l__FunctionComponent__11 (copy), l__debugRenderPhaseSideEffectsForStrictMode__44 (copy), l__disableLogs__133 (copy), l__describeError__52 (copy), l__reenableLogs__134 (copy), l__mountChildFibers__63 (copy)
    if p139 ~= nil then
        p139.alternate = nil;
        p140.alternate = nil;
        p140.flags = bit32.bor(p140.flags, l__Placement__35);
    end;
    local l__pendingProps__173 = p140.pendingProps;
    local v143;
    if l__disableLegacyContext__45 then
        v143 = nil;
    else
        v143 = l__getMaskedContext__96(p140, (l__getUnmaskedContext__97(p140, p141, false)));
    end;
    l__prepareToReadContext__93(p140, p142, u20.markWorkInProgressReceivedUpdate);
    local v144;
    if l____DEV____1 then
        if type(p141) == "table" and type(p141.render) == "function" then
            local v145 = l__getComponentName__54(p141) or "Unknown";
            if not u24.didWarnAboutBadClass[v145] then
                l__console__4.error("The <%s /> component appears to have a render method, but doesn\'t extend React.Component. This is likely to cause errors. Change %s to extend React.Component instead.", v145, v145);
                u24.didWarnAboutBadClass[v145] = true;
            end;
        end;
        if bit32.band(p140.mode, l__StrictMode__73) ~= 0 then
            u3.recordLegacyContextWarning(p140);
        end;
        l__setIsRendering__59(true);
        l__ReactCurrentOwner__135.current = p140;
        v144 = u11(nil, p140, p141, l__pendingProps__173, v143, p142);
        l__setIsRendering__59(false);
    else
        v144 = u11(nil, p140, p141, l__pendingProps__173, v143, p142);
    end;
    p140.flags = bit32.bor(p140.flags, l__PerformedWork__34);
    local v146 = type(v144);
    if l____DEV____1 and (v144 ~= nil and (v146 == "table" and (type(v144.render) == "function" and v144["$$typeof"] == nil))) then
        local v147 = l__getComponentName__54(p141) or "Unknown";
        if not u24.didWarnAboutModulePatternComponent[v147] then
            l__console__4.error("The <%s /> component appears to be a function component that returns a class instance. Change %s to a class that extends React.Component instead. ", v147, v147);
            u24.didWarnAboutModulePatternComponent[v147] = true;
        end;
    end;
    if l__disableModulePatternComponents__46 or (v144 == nil or (v146 ~= "table" or (type(v144.render) ~= "function" or v144["$$typeof"] ~= nil))) then
        p140.tag = l__FunctionComponent__11;
        if l____DEV____1 then
            if l__disableLegacyContext__45 and p141.contextTypes then
                l__console__4.error("%s uses the legacy contextTypes API which is no longer supported. Use React.createContext() with React.useContext() instead.", l__getComponentName__54(p141) or "Unknown");
            end;
            if l__debugRenderPhaseSideEffectsForStrictMode__44 and bit32.band(p140.mode, l__StrictMode__73) ~= 0 then
                l__disableLogs__133();
                local v148, v149 = xpcall(u11, l__describeError__52, nil, p140, p141, l__pendingProps__173, v143, p142);
                l__reenableLogs__134();
                if v148 then
                    v144 = v149;
                else
                    error(v149);
                end;
            end;
        end;
        p140.child = l__mountChildFibers__63(p140, nil, v144, p142);
        if l____DEV____1 then
            validateFunctionComponentInDev(p140, p141);
        end;
        return p140.child;
    end;
    if l____DEV____1 then
        local v150 = l__getComponentName__54(p141) or "Unknown";
        if not u24.didWarnAboutModulePatternComponent[v150] then
            l__console__4.error("The <%s /> component appears to be a function component that returns a class instance. " .. "Change %s to a class that extends React.Component instead. " .. v150, v150);
            u24.didWarnAboutModulePatternComponent[v150] = true;
        end;
    end;
    p140.tag = l__ClassComponent__12;
    p140.memoizedState = nil;
    p140.updateQueue = nil;
    local v151;
    if l__isContextProvider__100(p141) then
        l__pushContextProvider__99(p140);
        v151 = true;
    else
        v151 = false;
    end;
    p140.memoizedState = v144.state;
    l__initializeUpdateQueue__68(p140);
    local v152;
    if type(p141) == "function" then
        v152 = nil;
    else
        v152 = p141.getDerivedStateFromProps;
    end;
    if v152 ~= nil and type(v152) == "function" then
        l__applyDerivedStateFromProps__109(p140, p141, v152, l__pendingProps__173);
    end;
    l__adoptClassInstance__108(p140, v144);
    l__mountClassInstance__111(p140, p141, l__pendingProps__173, p142);
    return finishClassComponent(nil, p140, p141, true, v151, p142);
end;
function validateFunctionComponentInDev(p154, p155)
    -- upvalues: l____DEV____1 (copy), l__getCurrentFiberOwnerNameInDevOrNull__58 (copy), u24 (copy), l__console__4 (copy), l__warnAboutDefaultPropsOnFunctionComponents__50 (copy), l__getComponentName__54 (copy)
    if l____DEV____1 then
        if p154.ref ~= nil then
            local v156 = "";
            local v157 = l__getCurrentFiberOwnerNameInDevOrNull__58();
            if v157 then
                v156 = v156 .. "\n\nCheck the render method of `" .. v157 .. "`.";
            end;
            local v158 = v157 or (p154._debugID or "");
            local l___debugSource__174 = p154._debugSource;
            if l___debugSource__174 then
                v158 = l___debugSource__174.fileName .. ":" .. l___debugSource__174.lineNumber;
            end;
            if not u24.didWarnAboutFunctionRefs[v158] then
                u24.didWarnAboutFunctionRefs[v158] = true;
                l__console__4.error("Function components cannot be given refs. Attempts to access this ref will fail. Did you mean to use React.forwardRef()?%s", v156);
            end;
        end;
        if l__warnAboutDefaultPropsOnFunctionComponents__50 and (type(p155) ~= "function" and p155.defaultProps ~= nil) then
            local v159 = l__getComponentName__54(p155) or "Unknown";
            if not u24.didWarnAboutDefaultPropsOnFunctionComponent[v159] then
                l__console__4.error("%s: Support for defaultProps will be removed from function components in a future major release.", v159);
                u24.didWarnAboutDefaultPropsOnFunctionComponent[v159] = true;
            end;
        end;
        if type(p155) ~= "function" and (p155.getDerivedStateFromProps ~= nil and type(p155.getDerivedStateFromProps) == "function") then
            local v160 = l__getComponentName__54(p155) or "Unknown";
            if not u24.didWarnAboutGetDerivedStateOnFunctionComponent[v160] then
                l__console__4.error("%s: Function components do not support getDerivedStateFromProps.", v160);
                u24.didWarnAboutGetDerivedStateOnFunctionComponent[v160] = true;
            end;
        end;
        if type(p155) ~= "function" and (p155.contextType ~= nil and type(p155.contextType) == "table") then
            local v161 = l__getComponentName__54(p155) or "Unknown";
            if not u24.didWarnAboutContextTypeOnFunctionComponent[v161] then
                l__console__4.error("%s: Function components do not support contextType.", v161);
                u24.didWarnAboutContextTypeOnFunctionComponent[v161] = true;
            end;
        end;
    end;
end;
local u162 = {
    dehydrated = nil,
    retryLane = l__ReactFiberLane__8.NoLane
};
local u163 = nil;
local u164 = nil;
local u165 = nil;
local u166 = nil;
local u167 = nil;
local function u192(p168, p169, p170) --[[ Line: 1875 ]]
    -- upvalues: l____DEV____1 (copy), u9 (copy), l__DidCapture__38 (copy), l__suspenseStackCursor__83 (copy), l__NoFlags__32 (copy), l__hasSuspenseContext__84 (copy), l__ForceSuspenseFallback__85 (copy), l__addSubtreeSuspenseContext__86 (copy), l__InvisibleParentSuspenseContext__87 (copy), l__setDefaultShallowSuspenseContext__89 (copy), l__pushSuspenseContext__88 (copy), l__tryToClaimNextHydratableInstance__106 (copy), l__enableSuspenseServerRenderer__49 (copy), u164 (ref), u162 (copy), l__ReactFiberLane__8 (copy), l__enableSchedulerTracing__48 (copy), l__markSpawnedWork__122 (copy), u165 (ref), u167 (ref), u166 (ref), u163 (ref)
    local l__pendingProps__175 = p169.pendingProps;
    if l____DEV____1 then
        if not u9.shouldSuspendRef then
            u9.shouldSuspendRef = require(script.Parent:WaitForChild("ReactFiberReconciler")).shouldSuspend;
        end;
        if u9.shouldSuspendRef(p169) then
            p169.flags = bit32.bor(p169.flags, l__DidCapture__38);
        end;
    end;
    local l__current__176 = l__suspenseStackCursor__83.current;
    local v171 = false;
    local v172 = bit32.band(p169.flags, l__DidCapture__38) ~= l__NoFlags__32;
    local v173, v174, v175, v176, v177, v178, v179, v180, v181, v182, v183, v184, v185, v186, v187, v188, v189;
    if not v172 then
        local v190;
        if p168 == nil or p168.memoizedState ~= nil then
            v190 = l__hasSuspenseContext__84(l__current__176, l__ForceSuspenseFallback__85);
        else
            v190 = false;
        end;
        if not v190 then
            if (p168 == nil or p168.memoizedState ~= nil) and (l__pendingProps__175.fallback ~= nil and l__pendingProps__175.unstable_avoidThisFallback ~= true) then
                l__current__176 = l__addSubtreeSuspenseContext__86(l__current__176, l__InvisibleParentSuspenseContext__87);
            end;
            l__pushSuspenseContext__88(p169, (l__setDefaultShallowSuspenseContext__89(l__current__176)));
            if p168 == nil then
                if l__pendingProps__175.fallback ~= nil then
                    l__tryToClaimNextHydratableInstance__106(p169);
                    if l__enableSuspenseServerRenderer__49 then
                        v173 = p169.memoizedState;
                        if v173 ~= nil then
                            v174 = v173.dehydrated;
                            if v174 ~= nil then
                                return u164(p169, v174, p170);
                            end;
                        end;
                    end;
                end;
                v175 = l__pendingProps__175.children;
                v176 = l__pendingProps__175.fallback;
                if v171 then
                    v177 = mountSuspenseFallbackChildren(p169, v175, v176, p170);
                    p169.child.memoizedState = {
                        baseLanes = p170
                    };
                    p169.memoizedState = u162;
                    return v177;
                end;
                if l__pendingProps__175.unstable_expectedLoadTime == nil or type(l__pendingProps__175.unstable_expectedLoadTime) ~= "number" then
                    return u165(p169, v175, p170);
                end;
                v178 = mountSuspenseFallbackChildren(p169, v175, v176, p170);
                p169.child.memoizedState = {
                    baseLanes = p170
                };
                p169.memoizedState = u162;
                p169.lanes = l__ReactFiberLane__8.SomeRetryLane;
                if l__enableSchedulerTracing__48 then
                    l__markSpawnedWork__122(l__ReactFiberLane__8.SomeRetryLane);
                end;
                return v178;
            else
                v179 = p168.memoizedState;
                if v179 == nil then
                    if not v171 then
                        v180 = u163(p168, p169, l__pendingProps__175.children, p170);
                        p169.memoizedState = nil;
                        return v180;
                    end;
                    v181 = u166(p168, p169, l__pendingProps__175.children, l__pendingProps__175.fallback, p170);
                    v182 = p169.child;
                    v183 = p168.child.memoizedState;
                    if v183 == nil then
                        v182.memoizedState = {
                            baseLanes = p170
                        };
                    else
                        v182.memoizedState = {
                            baseLanes = l__ReactFiberLane__8.mergeLanes(v183.baseLanes, p170)
                        };
                    end;
                    v182.childLanes = l__ReactFiberLane__8.removeLanes(p168.childLanes, p170);
                    p169.memoizedState = u162;
                    return v181;
                end;
                if l__enableSuspenseServerRenderer__49 then
                    v184 = v179.dehydrated;
                    if v184 ~= nil then
                        if not v172 then
                            return u167(p168, p169, v184, v179, p170);
                        end;
                        if p169.memoizedState ~= nil then
                            p169.child = p168.child;
                            p169.flags = bit32.bor(p169.flags, l__DidCapture__38);
                            return nil;
                        end;
                        v185 = mountSuspenseFallbackAfterRetryWithoutHydrating(p168, p169, l__pendingProps__175.children, l__pendingProps__175.fallback, p170);
                        p169.child.memoizedState = {
                            baseLanes = p170
                        };
                        p169.memoizedState = u162;
                        return v185;
                    end;
                end;
                if not v171 then
                    v186 = u163(p168, p169, l__pendingProps__175.children, p170);
                    p169.memoizedState = nil;
                    return v186;
                end;
                v187 = u166(p168, p169, l__pendingProps__175.children, l__pendingProps__175.fallback, p170);
                v188 = p169.child;
                v189 = p168.child.memoizedState;
                if v189 == nil then
                    v188.memoizedState = {
                        baseLanes = p170
                    };
                else
                    v188.memoizedState = {
                        baseLanes = l__ReactFiberLane__8.mergeLanes(v189.baseLanes, p170)
                    };
                end;
                v188.childLanes = l__ReactFiberLane__8.removeLanes(p168.childLanes, p170);
                p169.memoizedState = u162;
                return v187;
            end;
        end;
    end;
    local l__flags__177 = p169.flags;
    local v191 = bit32.bnot(l__DidCapture__38);
    p169.flags = bit32.band(l__flags__177, v191);
    v171 = true;
    l__pushSuspenseContext__88(p169, (l__setDefaultShallowSuspenseContext__89(l__current__176)));
    if p168 == nil then
        if l__pendingProps__175.fallback ~= nil then
            l__tryToClaimNextHydratableInstance__106(p169);
            if l__enableSuspenseServerRenderer__49 then
                v173 = p169.memoizedState;
                if v173 ~= nil then
                    v174 = v173.dehydrated;
                    if v174 ~= nil then
                        return u164(p169, v174, p170);
                    end;
                end;
            end;
        end;
        v175 = l__pendingProps__175.children;
        v176 = l__pendingProps__175.fallback;
        if v171 then
            v177 = mountSuspenseFallbackChildren(p169, v175, v176, p170);
            p169.child.memoizedState = {
                baseLanes = p170
            };
            p169.memoizedState = u162;
            return v177;
        end;
        if l__pendingProps__175.unstable_expectedLoadTime == nil or type(l__pendingProps__175.unstable_expectedLoadTime) ~= "number" then
            return u165(p169, v175, p170);
        end;
        v178 = mountSuspenseFallbackChildren(p169, v175, v176, p170);
        p169.child.memoizedState = {
            baseLanes = p170
        };
        p169.memoizedState = u162;
        p169.lanes = l__ReactFiberLane__8.SomeRetryLane;
        if l__enableSchedulerTracing__48 then
            l__markSpawnedWork__122(l__ReactFiberLane__8.SomeRetryLane);
        end;
        return v178;
    else
        v179 = p168.memoizedState;
        if v179 == nil then
            if not v171 then
                v180 = u163(p168, p169, l__pendingProps__175.children, p170);
                p169.memoizedState = nil;
                return v180;
            end;
            v181 = u166(p168, p169, l__pendingProps__175.children, l__pendingProps__175.fallback, p170);
            v182 = p169.child;
            v183 = p168.child.memoizedState;
            if v183 == nil then
                v182.memoizedState = {
                    baseLanes = p170
                };
            else
                v182.memoizedState = {
                    baseLanes = l__ReactFiberLane__8.mergeLanes(v183.baseLanes, p170)
                };
            end;
            v182.childLanes = l__ReactFiberLane__8.removeLanes(p168.childLanes, p170);
            p169.memoizedState = u162;
            return v181;
        end;
        if l__enableSuspenseServerRenderer__49 then
            v184 = v179.dehydrated;
            if v184 ~= nil then
                if not v172 then
                    return u167(p168, p169, v184, v179, p170);
                end;
                if p169.memoizedState ~= nil then
                    p169.child = p168.child;
                    p169.flags = bit32.bor(p169.flags, l__DidCapture__38);
                    return nil;
                end;
                v185 = mountSuspenseFallbackAfterRetryWithoutHydrating(p168, p169, l__pendingProps__175.children, l__pendingProps__175.fallback, p170);
                p169.child.memoizedState = {
                    baseLanes = p170
                };
                p169.memoizedState = u162;
                return v185;
            end;
        end;
        if not v171 then
            v186 = u163(p168, p169, l__pendingProps__175.children, p170);
            p169.memoizedState = nil;
            return v186;
        end;
        v187 = u166(p168, p169, l__pendingProps__175.children, l__pendingProps__175.fallback, p170);
        v188 = p169.child;
        v189 = p168.child.memoizedState;
        if v189 == nil then
            v188.memoizedState = {
                baseLanes = p170
            };
        else
            v188.memoizedState = {
                baseLanes = l__ReactFiberLane__8.mergeLanes(v189.baseLanes, p170)
            };
        end;
        v188.childLanes = l__ReactFiberLane__8.removeLanes(p168.childLanes, p170);
        p169.memoizedState = u162;
        return v187;
    end;
end;
u165 = function(p193, p194, p195) --[[ Name: mountSuspensePrimaryChildren, Line 2160 ]]
    -- upvalues: l__createFiberFromOffscreen__117 (copy)
    local v196 = l__createFiberFromOffscreen__117({
        mode = "visible",
        children = p194
    }, p193.mode, p195, nil);
    v196.return_ = p193;
    p193.child = v196;
    return v196;
end;
function mountSuspenseFallbackChildren(p197, p198, p199, p200)
    -- upvalues: l__BlockingMode__74 (copy), l__NoMode__71 (copy), l__ReactFiberLane__8 (copy), l__enableProfilerTimer__47 (copy), l__ProfileMode__72 (copy), l__createFiberFromFragment__116 (copy), l__createFiberFromOffscreen__117 (copy)
    local l__mode__178 = p197.mode;
    local l__child__179 = p197.child;
    local v201 = {
        mode = "hidden",
        children = p198
    };
    local v202;
    if bit32.band(l__mode__178, l__BlockingMode__74) == l__NoMode__71 and l__child__179 ~= nil then
        l__child__179.childLanes = l__ReactFiberLane__8.NoLanes;
        l__child__179.pendingProps = v201;
        if l__enableProfilerTimer__47 and bit32.band(p197.mode, l__ProfileMode__72) ~= 0 then
            l__child__179.actualDuration = 0;
            l__child__179.actualStartTime = -1;
            l__child__179.selfBaseDuration = 0;
            l__child__179.treeBaseDuration = 0;
        end;
        v202 = l__createFiberFromFragment__116(p199, l__mode__178, p200, nil);
    else
        l__child__179 = l__createFiberFromOffscreen__117(v201, l__mode__178, l__ReactFiberLane__8.NoLanes, nil);
        v202 = l__createFiberFromFragment__116(p199, l__mode__178, p200, nil);
    end;
    l__child__179.return_ = p197;
    v202.return_ = p197;
    l__child__179.sibling = v202;
    p197.child = l__child__179;
    return v202;
end;
u163 = function(p203, p204, p205, p206) --[[ Name: updateSuspensePrimaryChildren, Line 2232 ]]
    -- upvalues: l__createWorkInProgress__120 (copy), l__BlockingMode__74 (copy), l__NoMode__71 (copy), l__Deletion__40 (copy)
    local l__child__180 = p203.child;
    local l__sibling__181 = l__child__180.sibling;
    local v207 = l__createWorkInProgress__120(l__child__180, {
        mode = "visible",
        children = p205
    });
    if bit32.band(p204.mode, l__BlockingMode__74) == l__NoMode__71 then
        v207.lanes = p206;
    end;
    v207.return_ = p204;
    v207.sibling = nil;
    if l__sibling__181 ~= nil then
        local l__deletions__182 = p204.deletions;
        if l__deletions__182 == nil then
            p204.deletions = { l__sibling__181 };
            p204.flags = bit32.bor(p204.flags, l__Deletion__40);
        else
            table.insert(l__deletions__182, l__sibling__181);
        end;
    end;
    p204.child = v207;
    return v207;
end;
u166 = function(p208, p209, p210, p211, p212) --[[ Name: updateSuspenseFallbackChildren, Line 2267 ]]
    -- upvalues: l__BlockingMode__74 (copy), l__NoMode__71 (copy), l__ReactFiberLane__8 (copy), l__enableProfilerTimer__47 (copy), l__ProfileMode__72 (copy), l__createWorkInProgress__120 (copy), l__StaticMask__33 (copy), l__createFiberFromFragment__116 (copy), l__Placement__35 (copy)
    local l__mode__183 = p209.mode;
    local l__child__184 = p208.child;
    local l__sibling__185 = l__child__184.sibling;
    local v213 = {
        mode = "hidden",
        children = p210
    };
    local v214;
    if bit32.band(l__mode__183, l__BlockingMode__74) == l__NoMode__71 and p209.child ~= l__child__184 then
        v214 = p209.child;
        v214.childLanes = l__ReactFiberLane__8.NoLanes;
        v214.pendingProps = v213;
        if l__enableProfilerTimer__47 and bit32.band(p209.mode, l__ProfileMode__72) ~= 0 then
            v214.actualDuration = 0;
            v214.actualStartTime = -1;
            v214.selfBaseDuration = l__child__184.selfBaseDuration;
            v214.treeBaseDuration = l__child__184.treeBaseDuration;
        end;
        p209.deletions = nil;
    else
        v214 = l__createWorkInProgress__120(l__child__184, v213);
        v214.subtreeFlags = bit32.band(l__child__184.subtreeFlags, l__StaticMask__33);
    end;
    local v215;
    if l__sibling__185 == nil then
        v215 = l__createFiberFromFragment__116(p211, l__mode__183, p212, nil);
        v215.flags = bit32.bor(v215.flags, l__Placement__35);
    else
        v215 = l__createWorkInProgress__120(l__sibling__185, p211);
    end;
    v215.return_ = p209;
    v214.return_ = p209;
    v214.sibling = v215;
    p209.child = v214;
    return v215;
end;
function mountSuspenseFallbackAfterRetryWithoutHydrating(p216, p217, p218, p219, p220)
    -- upvalues: l__createFiberFromOffscreen__117 (copy), l__ReactFiberLane__8 (copy), l__createFiberFromFragment__116 (copy), l__Placement__35 (copy), l__BlockingMode__74 (copy), l__NoMode__71 (copy), l__reconcileChildFibers__64 (copy)
    local l__mode__186 = p217.mode;
    local v221 = l__createFiberFromOffscreen__117(p218, l__mode__186, l__ReactFiberLane__8.NoLanes, nil);
    local v222 = l__createFiberFromFragment__116(p219, l__mode__186, p220, nil);
    v222.flags = bit32.bor(v222.flags, l__Placement__35);
    v221.return_ = p217;
    v222.return_ = p217;
    v221.sibling = v222;
    p217.child = v221;
    if bit32.band(p217.mode, l__BlockingMode__74) ~= l__NoMode__71 then
        l__reconcileChildFibers__64(p217, p216.child, nil, p220);
    end;
    return v222;
end;
u164 = function(p223, p224, _) --[[ Name: mountDehydratedSuspenseComponent, Line 2401 ]]
    -- upvalues: l__BlockingMode__74 (copy), l__NoMode__71 (copy), l____DEV____1 (copy), l__console__4 (copy), l__ReactFiberLane__8 (copy), l__isSuspenseInstanceFallback__78 (copy), l__enableSchedulerTracing__48 (copy), l__markSpawnedWork__122 (copy)
    if bit32.band(p223.mode, l__BlockingMode__74) == l__NoMode__71 then
        if l____DEV____1 then
            l__console__4.error("Cannot hydrate Suspense in legacy mode. Switch fromReactDOM.hydrate(element, container) to ReactDOM.createBlockingRoot(container, { hydrate: true }).render(element) or remove the Suspense componentsthe server rendered components.");
        end;
        p223.lanes = l__ReactFiberLane__8.laneToLanes(l__ReactFiberLane__8.SyncLane);
    elseif l__isSuspenseInstanceFallback__78(p224) then
        if l__enableSchedulerTracing__48 then
            l__markSpawnedWork__122(l__ReactFiberLane__8.DefaultHydrationLane);
        end;
        p223.lanes = l__ReactFiberLane__8.laneToLanes(l__ReactFiberLane__8.DefaultHydrationLane);
    else
        p223.lanes = l__ReactFiberLane__8.laneToLanes(l__ReactFiberLane__8.OffscreenLane);
        if l__enableSchedulerTracing__48 then
            l__markSpawnedWork__122(l__ReactFiberLane__8.OffscreenLane);
        end;
    end;
    return nil;
end;
u167 = function(u225, p226, p227, p228, p229) --[[ Name: updateDehydratedSuspenseComponent, Line 2448 ]]
    -- upvalues: l__warnIfHydrating__107 (copy), l__getExecutionContext__127 (copy), l__RetryAfterError__128 (copy), l__NoContext__129 (copy), l__reconcileChildFibers__64 (copy), u165 (ref), l__Placement__35 (copy), l__BlockingMode__74 (copy), l__NoMode__71 (copy), l__isSuspenseInstanceFallback__78 (copy), l__ReactFiberLane__8 (copy), u23 (ref), l__getWorkInProgressRoot__126 (copy), l__scheduleUpdateOnFiber__124 (copy), l__renderDidSuspendDelayIfPossible__125 (copy), l__isSuspenseInstancePending__77 (copy), l__DidCapture__38 (copy), l__retryDehydratedSuspenseBoundary__123 (copy), l__enableSchedulerTracing__48 (copy), u19 (ref), l__registerSuspenseInstanceRetry__79 (copy), l__reenterHydrationStateFromDehydratedSuspenseInstance__105 (copy), l__Hydrating__36 (copy)
    l__warnIfHydrating__107();
    local v230 = l__getExecutionContext__127();
    if bit32.band(v230, l__RetryAfterError__128) ~= l__NoContext__129 then
        l__reconcileChildFibers__64(p226, u225.child, nil, p229);
        local v231 = u165(p226, p226.pendingProps.children, p229);
        v231.flags = bit32.bor(v231.flags, l__Placement__35);
        p226.memoizedState = nil;
        return v231;
    end;
    if bit32.band(p226.mode, l__BlockingMode__74) == l__NoMode__71 then
        l__reconcileChildFibers__64(p226, u225.child, nil, p229);
        local v232 = u165(p226, p226.pendingProps.children, p229);
        v232.flags = bit32.bor(v232.flags, l__Placement__35);
        p226.memoizedState = nil;
        return v232;
    end;
    if l__isSuspenseInstanceFallback__78(p227) then
        l__reconcileChildFibers__64(p226, u225.child, nil, p229);
        local v233 = u165(p226, p226.pendingProps.children, p229);
        v233.flags = bit32.bor(v233.flags, l__Placement__35);
        p226.memoizedState = nil;
        return v233;
    end;
    if not (u23 or l__ReactFiberLane__8.includesSomeLane(p229, u225.childLanes)) then
        if not l__isSuspenseInstancePending__77(p227) then
            l__reenterHydrationStateFromDehydratedSuspenseInstance__105(p226, p227);
            local v234 = u165(p226, p226.pendingProps.children, p229);
            v234.flags = bit32.bor(v234.flags, l__Hydrating__36);
            return v234;
        end;
        p226.flags = bit32.bor(p226.flags, l__DidCapture__38);
        p226.child = u225.child;
        local function v235() --[[ Line: 2544 ]]
            -- upvalues: l__retryDehydratedSuspenseBoundary__123 (ref), u225 (copy)
            return l__retryDehydratedSuspenseBoundary__123(u225);
        end;
        if l__enableSchedulerTracing__48 then
            if u19 == nil then
                u19 = require(script.Parent.Parent:WaitForChild("scheduler")).tracing.unstable_wrap;
            end;
            v235 = u19(v235);
        end;
        l__registerSuspenseInstanceRetry__79(p227, v235);
        return nil;
    end;
    local v236 = l__getWorkInProgressRoot__126();
    if v236 ~= nil then
        local v237 = l__ReactFiberLane__8.getBumpedLaneForHydration(v236, p229);
        if v237 ~= l__ReactFiberLane__8.NoLane and v237 ~= p228.retryLane then
            p228.retryLane = v237;
            l__scheduleUpdateOnFiber__124(u225, v237, l__ReactFiberLane__8.NoTimestamp);
        end;
    end;
    l__renderDidSuspendDelayIfPossible__125();
    l__reconcileChildFibers__64(p226, u225.child, nil, p229);
    local v238 = u165(p226, p226.pendingProps.children, p229);
    v238.flags = bit32.bor(v238.flags, l__Placement__35);
    p226.memoizedState = nil;
    return v238;
end;
function updatePortalComponent(p239, p240, p241)
    -- upvalues: l__pushHostContainer__82 (copy), l__reconcileChildFibers__64 (copy), l__mountChildFibers__63 (copy)
    l__pushHostContainer__82(p240, p240.stateNode.containerInfo);
    local l__pendingProps__187 = p240.pendingProps;
    if p239 == nil then
        p240.child = l__reconcileChildFibers__64(p240, nil, l__pendingProps__187, p241);
    elseif p239 == nil then
        p240.child = l__mountChildFibers__63(p240, nil, l__pendingProps__187, p241);
    else
        p240.child = l__reconcileChildFibers__64(p240, p239.child, l__pendingProps__187, p241);
    end;
    return p240.child;
end;
local u242 = false;
local function u247(p243, p244, p245) --[[ Line: 2981 ]]
    -- upvalues: l____DEV____1 (copy), l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2 (copy), l__Array__5 (copy), l__Object__6 (copy), u242 (ref), l__console__4 (copy), l__checkPropTypes__9 (copy), l__pushProvider__94 (copy), l__calculateChangedBits__92 (copy), l__hasContextChanged__98 (copy), u21 (ref), l__propagateContextChange__90 (copy), l__mountChildFibers__63 (copy), l__reconcileChildFibers__64 (copy)
    local l___context__188 = p244.type._context;
    local l__pendingProps__189 = p244.pendingProps;
    local l__memoizedProps__190 = p244.memoizedProps;
    local l__value__191 = l__pendingProps__189.value;
    if l____DEV____1 or l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2 then
        if l__Array__5.indexOf(l__Object__6.keys(l__pendingProps__189), "value") < 1 and not u242 then
            u242 = true;
            l__console__4.error("The `value` prop is required for the `<Context.Provider>`. Did you misspell it or forget to pass it?");
        end;
        local l__propTypes__192 = p244.type.propTypes;
        local l__validateProps__193 = p244.type.validateProps;
        if l__propTypes__192 or l__validateProps__193 then
            l__checkPropTypes__9(l__propTypes__192, l__validateProps__193, l__pendingProps__189, "prop", "Context.Provider");
        end;
    end;
    l__pushProvider__94(p244, l__value__191);
    if l__memoizedProps__190 ~= nil then
        local v246 = l__calculateChangedBits__92(l___context__188, l__value__191, l__memoizedProps__190.value);
        if v246 == 0 then
            if l__memoizedProps__190.children == l__pendingProps__189.children and not l__hasContextChanged__98() then
                return u21(p243, p244, p245);
            end;
        else
            l__propagateContextChange__90(p244, l___context__188, v246, p245);
        end;
    end;
    local l__children__194 = l__pendingProps__189.children;
    if p243 == nil then
        p244.child = l__mountChildFibers__63(p244, nil, l__children__194, p245);
    else
        p244.child = l__reconcileChildFibers__64(p244, p243.child, l__children__194, p245);
    end;
    return p244.child;
end;
local u248 = {
    usingContextAsConsumer = false,
    usingLegacyConsumer = false
};
function updateContextConsumer(p249, p250, p251)
    -- upvalues: l____DEV____1 (copy), u248 (copy), l__console__4 (copy), l____COMPAT_WARNINGS____3 (copy), l__prepareToReadContext__93 (copy), u20 (copy), l__readContext__91 (copy), l__ReactCurrentOwner__135 (copy), l__setIsRendering__59 (copy), l__PerformedWork__34 (copy), l__mountChildFibers__63 (copy), l__reconcileChildFibers__64 (copy)
    local l__type__195 = p250.type;
    if l____DEV____1 then
        if l__type__195._context == nil then
            if l__type__195 ~= l__type__195.Consumer and not u248.usingContextAsConsumer then
                u248.usingContextAsConsumer = true;
                l__console__4.error("Rendering <Context> directly is not supported and will be removed in a future major release. Did you mean to render <Context.Consumer> instead?");
            end;
        else
            l__type__195 = l__type__195._context;
        end;
    end;
    local l__pendingProps__196 = p250.pendingProps;
    local v252;
    if l__pendingProps__196.render then
        if l____DEV____1 and (l____COMPAT_WARNINGS____3 and not u248.usingLegacyConsumer) then
            u248.usingLegacyConsumer = true;
            l__console__4.warn("Your Context.Consumer component is using legacy Roact syntax, which won\'t be supported in future versions of Roact. \nPlease provide no props and supply the \'render\' function as a child (the 3rd argument of createElement). For example: \n       createElement(ContextConsumer, {render = function(...) end})\nbecomes:\n       createElement(ContextConsumer, nil, function(...) end)\nFor more info, reference the React documentation here: \nhttps://reactjs.org/docs/context.html#contextconsumer");
        end;
        v252 = l__pendingProps__196.render;
    else
        v252 = l__pendingProps__196.children;
    end;
    if l____DEV____1 and type(v252) ~= "function" then
        l__console__4.error("A context consumer was rendered with multiple children, or a child that isn\'t a function. A context consumer expects a single child that is a function. If you did pass a function, make sure there is no trailing or leading whitespace around it.");
    end;
    l__prepareToReadContext__93(p250, p251, u20.markWorkInProgressReceivedUpdate);
    local v253 = l__readContext__91(l__type__195, l__pendingProps__196.unstable_observedBits);
    local v254;
    if l____DEV____1 then
        l__ReactCurrentOwner__135.current = p250;
        l__setIsRendering__59(true);
        v254 = v252(v253);
        l__setIsRendering__59(false);
    else
        v254 = v252(v253);
    end;
    p250.flags = bit32.bor(p250.flags, l__PerformedWork__34);
    if p249 == nil then
        p250.child = l__mountChildFibers__63(p250, nil, v254, p251);
    else
        p250.child = l__reconcileChildFibers__64(p250, p249.child, v254, p251);
    end;
    return p250.child;
end;
function u20.markWorkInProgressReceivedUpdate() --[[ Line: 3159 ]]
    -- upvalues: u23 (ref)
    u23 = true;
end;
local function u258(p255, p256, p257) --[[ Line: 3163 ]]
    -- upvalues: l__enableProfilerTimer__47 (copy), l__stopProfilerTimerIfRunning__95 (copy), l__markSkippedUpdateLanes__131 (copy), l__ReactFiberLane__8 (copy), l__cloneChildFibers__65 (copy)
    if p255 then
        p256.dependencies = p255.dependencies;
    end;
    if l__enableProfilerTimer__47 then
        l__stopProfilerTimerIfRunning__95(p256);
    end;
    l__markSkippedUpdateLanes__131(p256.lanes);
    if not l__ReactFiberLane__8.includesSomeLane(p257, p256.childLanes) then
        return nil;
    end;
    l__cloneChildFibers__65(p255, p256);
    return p256.child;
end;
function remountFiber(p259, p260, p261)
    -- upvalues: l____DEV____1 (copy), l__Deletion__40 (copy), l__Placement__35 (copy)
    if l____DEV____1 then
        local l__return___197 = p260.return_;
        if l__return___197 == nil then
            error("Cannot swap the root fiber.");
        end;
        assert(l__return___197 ~= nil, "returnFiber was nil in remountFiber");
        p259.alternate = nil;
        p260.alternate = nil;
        p261.index = p260.index;
        p261.sibling = p260.sibling;
        p261.return_ = p260.return_;
        p261.ref = p260.ref;
        if p260 == l__return___197.child then
            l__return___197.child = p261;
        else
            local l__child__198 = l__return___197.child;
            if l__child__198 == nil then
                error("Expected parent to have a child.");
            end;
            assert(l__child__198 ~= nil, "prevSibling was nil in remountFiber");
            while l__child__198.sibling ~= p260 do
                l__child__198 = l__child__198.sibling;
                if l__child__198 == nil then
                    error("Expected to find the previous sibling.");
                end;
            end;
            l__child__198.sibling = p261;
        end;
        local l__deletions__199 = l__return___197.deletions;
        if l__deletions__199 == nil then
            l__return___197.deletions = { p259 };
            l__return___197.flags = bit32.bor(l__return___197.flags, l__Deletion__40);
        else
            table.insert(l__deletions__199, p259);
        end;
        p261.flags = bit32.bor(p261.flags, l__Placement__35);
        return p261;
    end;
    error("Did not expect this call in production. This is a bug in React. Please file an issue.");
end;
function u20.beginWork(p262, p263, p264) --[[ Line: 3263 ]]
    -- upvalues: l____DEV____1 (copy), l__createFiberFromTypeAndProps__118 (copy), l__hasContextChanged__98 (copy), u23 (ref), l__ReactFiberLane__8 (copy), l__HostRoot__13 (copy), l__pushTopLevelContextObject__101 (copy), l__pushHostContainer__82 (copy), l__resetHydrationState__103 (copy), l__HostComponent__14 (copy), l__pushHostContext__81 (copy), l__ClassComponent__12 (copy), l__isContextProvider__100 (copy), l__pushContextProvider__99 (copy), l__HostPortal__16 (copy), l__ContextProvider__20 (copy), l__pushProvider__94 (copy), l__Profiler__22 (copy), l__enableProfilerTimer__47 (copy), l__SuspenseComponent__23 (copy), l__enableSuspenseServerRenderer__49 (copy), l__pushSuspenseContext__88 (copy), l__setDefaultShallowSuspenseContext__89 (copy), l__suspenseStackCursor__83 (copy), l__DidCapture__38 (copy), u192 (copy), u258 (ref), l__SuspenseListComponent__24 (copy), l__OffscreenComponent__29 (copy), l__LegacyHiddenComponent__30 (copy), u67 (copy), l__ForceUpdateForLegacySuspense__41 (copy), l__NoFlags__32 (copy), l__ReactWorkTags__10 (copy), u153 (copy), l__LazyComponent__27 (copy), u132 (copy), l__FunctionComponent__11 (copy), l__resolveDefaultProps__114 (copy), u88 (ref), u97 (copy), u118 (copy), u123 (copy), l__HostText__15 (copy), l__tryToClaimNextHydratableInstance__106 (copy), l__ForwardRef__17 (copy), u34 (copy), l__Fragment__18 (copy), l__Mode__19 (copy), u247 (copy), l__ContextConsumer__21 (copy), l__MemoComponent__25 (copy), l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2 (copy), l__checkPropTypes__9 (copy), l__getComponentName__54 (copy), u48 (copy), l__SimpleMemoComponent__26 (copy), u60 (ref), l__IncompleteClassComponent__28 (copy), u67 (copy), l__invariant__51 (copy)
    local l__lanes__200 = p263.lanes;
    if l____DEV____1 and (p263._debugNeedsRemount and p262 ~= nil) then
        return remountFiber(p262, p263, l__createFiberFromTypeAndProps__118(p263.type, p263.key, p263.pendingProps, p263._debugOwner or nil, p263.mode, p263.lanes));
    end;
    local v265, v266, v267, v268, v269, v270, v271, v272, v273, v274, v275, v276, v277;
    if p262 == nil then
        u23 = false;
        p263.lanes = l__ReactFiberLane__8.NoLanes;
        if p263.tag == l__ReactWorkTags__10.IndeterminateComponent then
            return u153(p262, p263, p263.type, p264);
        elseif p263.tag == l__LazyComponent__27 then
            return u132(p262, p263, p263.elementType, l__lanes__200, p264);
        elseif p263.tag == l__FunctionComponent__11 then
            v265 = p263.type;
            v266 = p263.pendingProps;
            if p263.elementType ~= v265 then
                v266 = l__resolveDefaultProps__114(v265, v266);
            end;
            return u88(p262, p263, v265, v266, p264);
        elseif p263.tag == l__ClassComponent__12 then
            v267 = p263.type;
            v268 = p263.pendingProps;
            return u97(p262, p263, v267, p263.elementType == v267 and v268 and v268 or l__resolveDefaultProps__114(v267, v268), p264);
        elseif p263.tag == l__HostRoot__13 then
            return u118(p262, p263, p264);
        elseif p263.tag == l__HostComponent__14 then
            return u123(p262, p263, p264);
        elseif p263.tag == l__HostText__15 then
            if p262 == nil then
                l__tryToClaimNextHydratableInstance__106(p263);
            end;
            return nil;
        elseif p263.tag == l__SuspenseComponent__23 then
            return u192(p262, p263, p264);
        elseif p263.tag == l__HostPortal__16 then
            return updatePortalComponent(p262, p263, p264);
        elseif p263.tag == l__ForwardRef__17 then
            v269 = p263.type;
            v270 = p263.pendingProps;
            if p263.elementType ~= v269 then
                v270 = l__resolveDefaultProps__114(v269, v270);
            end;
            return u34(p262, p263, v269, v270, p264);
        elseif p263.tag == l__Fragment__18 then
            return updateFragment(p262, p263, p264);
        elseif p263.tag == l__Mode__19 then
            return updateMode(p262, p263, p264);
        elseif p263.tag == l__Profiler__22 then
            return updateProfiler(p262, p263, p264);
        elseif p263.tag == l__ContextProvider__20 then
            return u247(p262, p263, p264);
        elseif p263.tag == l__ContextConsumer__21 then
            return updateContextConsumer(p262, p263, p264);
        elseif p263.tag == l__MemoComponent__25 then
            v271 = p263.type;
            v272 = l__resolveDefaultProps__114(v271, p263.pendingProps);
            if (l____DEV____1 or l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2) and p263.type ~= p263.elementType then
                if type(v271) == "table" then
                    v273 = v271.propTypes;
                    v274 = v271.validateProps;
                else
                    v273 = nil;
                    v274 = nil;
                end;
                if v273 or v274 then
                    l__checkPropTypes__9(v273, v274, v272, "prop", l__getComponentName__54(v271));
                end;
            end;
            return u48(p262, p263, v271, l__resolveDefaultProps__114(v271.type, v272), l__lanes__200, p264);
        elseif p263.tag == l__SimpleMemoComponent__26 then
            return u60(p262, p263, p263.type, p263.pendingProps, l__lanes__200, p264);
        elseif p263.tag == l__IncompleteClassComponent__28 then
            v275 = p263.type;
            v276 = p263.pendingProps;
            v277 = p263.elementType == v275 and v276 and v276 or l__resolveDefaultProps__114(v275, v276);
            return mountIncompleteClassComponent(p262, p263, v275, v277, p264);
        else
            if p263.tag == l__OffscreenComponent__29 then
                return u67(p262, p263, p264);
            end;
            if p263.tag == l__LegacyHiddenComponent__30 then
                return u67(p262, p263, p264);
            end;
            l__invariant__51(false, "Unknown unit of work tag (%s). This error is likely caused by a bug in React. Please file an issue.", (tostring(p263.tag)));
            return nil;
        end;
    end;
    if p262.memoizedProps == p263.pendingProps and not l__hasContextChanged__98() then
        local v278;
        if l____DEV____1 then
            v278 = p263.type ~= p262.type;
        else
            v278 = false;
        end;
        if not v278 then
            if not l__ReactFiberLane__8.includesSomeLane(p264, l__lanes__200) then
                u23 = false;
                if p263.tag == l__HostRoot__13 then
                    local l__stateNode__201 = p263.stateNode;
                    if l__stateNode__201.pendingContext then
                        l__pushTopLevelContextObject__101(p263, l__stateNode__201.pendingContext, l__stateNode__201.pendingContext ~= l__stateNode__201.context);
                    elseif l__stateNode__201.context then
                        l__pushTopLevelContextObject__101(p263, l__stateNode__201.context, false);
                    end;
                    l__pushHostContainer__82(p263, l__stateNode__201.containerInfo);
                    l__resetHydrationState__103();
                elseif p263.tag == l__HostComponent__14 then
                    l__pushHostContext__81(p263);
                elseif p263.tag == l__ClassComponent__12 then
                    if l__isContextProvider__100(p263.type) then
                        l__pushContextProvider__99(p263);
                    end;
                elseif p263.tag == l__HostPortal__16 then
                    l__pushHostContainer__82(p263, p263.stateNode.containerInfo);
                elseif p263.tag == l__ContextProvider__20 then
                    l__pushProvider__94(p263, p263.memoizedProps.value);
                elseif p263.tag == l__Profiler__22 then
                    if l__enableProfilerTimer__47 then
                        local l__stateNode__202 = p263.stateNode;
                        l__stateNode__202.effectDuration = 0;
                        l__stateNode__202.passiveEffectDuration = 0;
                    end;
                elseif p263.tag == l__SuspenseComponent__23 then
                    local l__memoizedState__203 = p263.memoizedState;
                    if l__memoizedState__203 ~= nil then
                        if l__enableSuspenseServerRenderer__49 and l__memoizedState__203.dehydrated ~= nil then
                            l__pushSuspenseContext__88(p263, l__setDefaultShallowSuspenseContext__89(l__suspenseStackCursor__83.current));
                            p263.flags = bit32.bor(p263.flags, l__DidCapture__38);
                            return nil;
                        elseif l__ReactFiberLane__8.includesSomeLane(p264, p263.child.childLanes) then
                            return u192(p262, p263, p264);
                        else
                            l__pushSuspenseContext__88(p263, l__setDefaultShallowSuspenseContext__89(l__suspenseStackCursor__83.current));
                            local v279 = u258(p262, p263, p264);
                            if v279 == nil then
                                return nil;
                            else
                                return v279.sibling;
                            end;
                        end;
                    end;
                    l__pushSuspenseContext__88(p263, l__setDefaultShallowSuspenseContext__89(l__suspenseStackCursor__83.current));
                elseif p263.tag == l__SuspenseListComponent__24 then
                    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    print("UNIMPLEMENTED ERROR: " .. tostring("beginWork: SuspenseListComponent"));
                    error("FIXME (roblox): beginWork: SuspenseListComponent is unimplemented", 2);
                elseif p263.tag == l__OffscreenComponent__29 or p263.tag == l__LegacyHiddenComponent__30 then
                    p263.lanes = l__ReactFiberLane__8.NoLanes;
                    return u67(p262, p263, p264);
                end;
                return u258(p262, p263, p264);
            end;
            if bit32.band(p262.flags, l__ForceUpdateForLegacySuspense__41) == l__NoFlags__32 then
                u23 = false;
            else
                u23 = true;
            end;
            p263.lanes = l__ReactFiberLane__8.NoLanes;
            if p263.tag == l__ReactWorkTags__10.IndeterminateComponent then
                return u153(p262, p263, p263.type, p264);
            elseif p263.tag == l__LazyComponent__27 then
                return u132(p262, p263, p263.elementType, l__lanes__200, p264);
            elseif p263.tag == l__FunctionComponent__11 then
                v265 = p263.type;
                v266 = p263.pendingProps;
                if p263.elementType ~= v265 then
                    v266 = l__resolveDefaultProps__114(v265, v266);
                end;
                return u88(p262, p263, v265, v266, p264);
            elseif p263.tag == l__ClassComponent__12 then
                v267 = p263.type;
                v268 = p263.pendingProps;
                return u97(p262, p263, v267, p263.elementType == v267 and v268 and v268 or l__resolveDefaultProps__114(v267, v268), p264);
            elseif p263.tag == l__HostRoot__13 then
                return u118(p262, p263, p264);
            elseif p263.tag == l__HostComponent__14 then
                return u123(p262, p263, p264);
            elseif p263.tag == l__HostText__15 then
                if p262 == nil then
                    l__tryToClaimNextHydratableInstance__106(p263);
                end;
                return nil;
            elseif p263.tag == l__SuspenseComponent__23 then
                return u192(p262, p263, p264);
            elseif p263.tag == l__HostPortal__16 then
                return updatePortalComponent(p262, p263, p264);
            elseif p263.tag == l__ForwardRef__17 then
                v269 = p263.type;
                v270 = p263.pendingProps;
                if p263.elementType ~= v269 then
                    v270 = l__resolveDefaultProps__114(v269, v270);
                end;
                return u34(p262, p263, v269, v270, p264);
            elseif p263.tag == l__Fragment__18 then
                return updateFragment(p262, p263, p264);
            elseif p263.tag == l__Mode__19 then
                return updateMode(p262, p263, p264);
            elseif p263.tag == l__Profiler__22 then
                return updateProfiler(p262, p263, p264);
            elseif p263.tag == l__ContextProvider__20 then
                return u247(p262, p263, p264);
            elseif p263.tag == l__ContextConsumer__21 then
                return updateContextConsumer(p262, p263, p264);
            elseif p263.tag == l__MemoComponent__25 then
                v271 = p263.type;
                v272 = l__resolveDefaultProps__114(v271, p263.pendingProps);
                if (l____DEV____1 or l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2) and p263.type ~= p263.elementType then
                    if type(v271) == "table" then
                        v273 = v271.propTypes;
                        v274 = v271.validateProps;
                    else
                        v273 = nil;
                        v274 = nil;
                    end;
                    if v273 or v274 then
                        l__checkPropTypes__9(v273, v274, v272, "prop", l__getComponentName__54(v271));
                    end;
                end;
                return u48(p262, p263, v271, l__resolveDefaultProps__114(v271.type, v272), l__lanes__200, p264);
            elseif p263.tag == l__SimpleMemoComponent__26 then
                return u60(p262, p263, p263.type, p263.pendingProps, l__lanes__200, p264);
            elseif p263.tag == l__IncompleteClassComponent__28 then
                v275 = p263.type;
                v276 = p263.pendingProps;
                v277 = p263.elementType == v275 and v276 and v276 or l__resolveDefaultProps__114(v275, v276);
                return mountIncompleteClassComponent(p262, p263, v275, v277, p264);
            else
                if p263.tag == l__OffscreenComponent__29 then
                    return u67(p262, p263, p264);
                end;
                if p263.tag == l__LegacyHiddenComponent__30 then
                    return u67(p262, p263, p264);
                end;
                l__invariant__51(false, "Unknown unit of work tag (%s). This error is likely caused by a bug in React. Please file an issue.", (tostring(p263.tag)));
                return nil;
            end;
        end;
    end;
    u23 = true;
    p263.lanes = l__ReactFiberLane__8.NoLanes;
    if p263.tag == l__ReactWorkTags__10.IndeterminateComponent then
        return u153(p262, p263, p263.type, p264);
    elseif p263.tag == l__LazyComponent__27 then
        return u132(p262, p263, p263.elementType, l__lanes__200, p264);
    elseif p263.tag == l__FunctionComponent__11 then
        v265 = p263.type;
        v266 = p263.pendingProps;
        if p263.elementType ~= v265 then
            v266 = l__resolveDefaultProps__114(v265, v266);
        end;
        return u88(p262, p263, v265, v266, p264);
    elseif p263.tag == l__ClassComponent__12 then
        v267 = p263.type;
        v268 = p263.pendingProps;
        return u97(p262, p263, v267, p263.elementType == v267 and v268 and v268 or l__resolveDefaultProps__114(v267, v268), p264);
    elseif p263.tag == l__HostRoot__13 then
        return u118(p262, p263, p264);
    elseif p263.tag == l__HostComponent__14 then
        return u123(p262, p263, p264);
    elseif p263.tag == l__HostText__15 then
        if p262 == nil then
            l__tryToClaimNextHydratableInstance__106(p263);
        end;
        return nil;
    elseif p263.tag == l__SuspenseComponent__23 then
        return u192(p262, p263, p264);
    elseif p263.tag == l__HostPortal__16 then
        return updatePortalComponent(p262, p263, p264);
    elseif p263.tag == l__ForwardRef__17 then
        v269 = p263.type;
        v270 = p263.pendingProps;
        if p263.elementType ~= v269 then
            v270 = l__resolveDefaultProps__114(v269, v270);
        end;
        return u34(p262, p263, v269, v270, p264);
    elseif p263.tag == l__Fragment__18 then
        return updateFragment(p262, p263, p264);
    elseif p263.tag == l__Mode__19 then
        return updateMode(p262, p263, p264);
    elseif p263.tag == l__Profiler__22 then
        return updateProfiler(p262, p263, p264);
    elseif p263.tag == l__ContextProvider__20 then
        return u247(p262, p263, p264);
    elseif p263.tag == l__ContextConsumer__21 then
        return updateContextConsumer(p262, p263, p264);
    elseif p263.tag == l__MemoComponent__25 then
        v271 = p263.type;
        v272 = l__resolveDefaultProps__114(v271, p263.pendingProps);
        if (l____DEV____1 or l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2) and p263.type ~= p263.elementType then
            if type(v271) == "table" then
                v273 = v271.propTypes;
                v274 = v271.validateProps;
            else
                v273 = nil;
                v274 = nil;
            end;
            if v273 or v274 then
                l__checkPropTypes__9(v273, v274, v272, "prop", l__getComponentName__54(v271));
            end;
        end;
        return u48(p262, p263, v271, l__resolveDefaultProps__114(v271.type, v272), l__lanes__200, p264);
    elseif p263.tag == l__SimpleMemoComponent__26 then
        return u60(p262, p263, p263.type, p263.pendingProps, l__lanes__200, p264);
    elseif p263.tag == l__IncompleteClassComponent__28 then
        v275 = p263.type;
        v276 = p263.pendingProps;
        v277 = p263.elementType == v275 and v276 and v276 or l__resolveDefaultProps__114(v275, v276);
        return mountIncompleteClassComponent(p262, p263, v275, v277, p264);
    else
        if p263.tag == l__OffscreenComponent__29 then
            return u67(p262, p263, p264);
        end;
        if p263.tag == l__LegacyHiddenComponent__30 then
            return u67(p262, p263, p264);
        end;
        l__invariant__51(false, "Unknown unit of work tag (%s). This error is likely caused by a bug in React. Please file an issue.", (tostring(p263.tag)));
        return nil;
    end;
end;
return u20;