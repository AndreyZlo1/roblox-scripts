-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberStack.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__console__1 = require(script.Parent.Parent:WaitForChild("shared")).console;
require(script.Parent:WaitForChild("ReactInternalTypes"));
local u1 = {};
local u2 = {};
local u3 = _G.__DEV__ and {} or nil;
local u4 = 0;
return {
    createCursor = function(p5) --[[ Name: createCursor, Line 34 ]]
        return {
            current = p5
        };
    end,
    isEmpty = function() --[[ Name: isEmpty, Line 40 ]]
        -- upvalues: u4 (ref)
        return u4 == 0;
    end,
    pop = function(p6, p7) --[[ Name: pop, Line 44 ]]
        -- upvalues: u4 (ref), l__console__1 (copy), u3 (ref), u2 (copy), u1 (copy)
        if u4 < 1 then
            if _G.__DEV__ then
                l__console__1.error("Unexpected pop.");
            end;
        else
            if _G.__DEV__ and p7 ~= u3[u4] then
                l__console__1.error("Unexpected Fiber popped.");
            end;
            local v8 = u2[u4];
            if v8 == u1 then
                p6.current = nil;
            else
                p6.current = v8;
            end;
            u2[u4] = nil;
            if _G.__DEV__ then
                u3[u4] = nil;
            end;
            u4 = u4 - 1;
        end;
    end,
    push = function(p9, p10, p11) --[[ Name: push, Line 76 ]]
        -- upvalues: u4 (ref), u2 (copy), u1 (copy), u3 (ref)
        u4 = u4 + 1;
        local l__current__2 = p9.current;
        if l__current__2 == nil then
            u2[u4] = u1;
        else
            u2[u4] = l__current__2;
        end;
        if _G.__DEV__ then
            u3[u4] = p11;
        end;
        p9.current = p10;
    end,
    checkThatStackIsEmpty = function() --[[ Name: checkThatStackIsEmpty, Line 93 ]]
        -- upvalues: u4 (ref), l__console__1 (copy)
        if _G.__DEV__ and u4 ~= 0 then
            l__console__1.error("Expected an empty stack. Something was not reset properly.");
        end;
    end,
    resetStackAfterFatalErrorInDev = function() --[[ Name: resetStackAfterFatalErrorInDev, Line 101 ]]
        -- upvalues: u4 (ref), u2 (copy), u3 (ref)
        if _G.__DEV__ then
            u4 = 0;
            table.clear(u2);
            table.clear(u3);
        end;
    end
};