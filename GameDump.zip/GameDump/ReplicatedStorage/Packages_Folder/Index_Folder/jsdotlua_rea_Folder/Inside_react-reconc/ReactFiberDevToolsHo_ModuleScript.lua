-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberDevToolsHook.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__console__1 = require(script.Parent.Parent:WaitForChild("shared")).console;
require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local v1 = {};
local l__enableProfilerTimer__2 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags.enableProfilerTimer;
require(script.Parent:WaitForChild("ReactInternalTypes"));
require(script.Parent.Parent:WaitForChild("shared"));
local l__DidCapture__3 = require(script.Parent:WaitForChild("ReactFiberFlags")).DidCapture;
local u2 = nil;
local u3 = nil;
local u4 = false;
function v1.isDevToolsPresent() --[[ Line: 63 ]]
    return _G.__REACT_DEVTOOLS_GLOBAL_HOOK__ ~= nil;
end;
function v1.injectInternals(u5) --[[ Line: 67 ]]
    -- upvalues: l__console__1 (copy), u2 (ref), u3 (ref)
    if _G.__REACT_DEVTOOLS_GLOBAL_HOOK__ == nil then
        return false;
    end;
    local l____REACT_DEVTOOLS_GLOBAL_HOOK____4 = _G.__REACT_DEVTOOLS_GLOBAL_HOOK__;
    if l____REACT_DEVTOOLS_GLOBAL_HOOK____4.isDisabled then
        return true;
    end;
    if not l____REACT_DEVTOOLS_GLOBAL_HOOK____4.supportsFiber then
        if _G.__DEV__ then
            l__console__1.error("The installed version of React DevTools is too old and will not work with the current version of React. Please update React DevTools. https://reactjs.org/link/react-devtools");
        end;
        return true;
    end;
    local v6, v7 = pcall(function() --[[ Line: 90 ]]
        -- upvalues: u2 (ref), l____REACT_DEVTOOLS_GLOBAL_HOOK____4 (copy), u5 (copy), u3 (ref)
        u2 = l____REACT_DEVTOOLS_GLOBAL_HOOK____4.inject(u5);
        u3 = l____REACT_DEVTOOLS_GLOBAL_HOOK____4;
    end);
    if not v6 and _G.__DEV__ then
        l__console__1.error("React instrumentation encountered an error: %s.", v7);
    end;
    return true;
end;
function v1.onScheduleRoot(p8, p9) --[[ Line: 106 ]]
    -- upvalues: u3 (ref), u2 (ref), u4 (ref), l__console__1 (copy)
    if _G.__DEV__ and u3 then
        local l__onScheduleFiberRoot__5 = u3.onScheduleFiberRoot;
        local v10;
        if typeof(l__onScheduleFiberRoot__5) == "function" then
            v10 = true;
        elseif typeof(l__onScheduleFiberRoot__5) == "table" then
            local v11 = getmetatable(l__onScheduleFiberRoot__5);
            v10 = v11 and rawget(v11, "__call") and true or (l__onScheduleFiberRoot__5._isMockFunction and true or false);
        else
            v10 = false;
        end;
        if v10 then
            local v12, v13 = pcall(u3.onScheduleFiberRoot, u2, p8, p9);
            if not v12 and (_G.__DEV__ and not u4) then
                u4 = true;
                l__console__1.error("React instrumentation encountered an error: %s", v13);
            end;
        end;
    end;
end;
function v1.onCommitRoot(u14, u15) --[[ Line: 126 ]]
    -- upvalues: u3 (ref), l__DidCapture__3 (copy), l__enableProfilerTimer__2 (copy), u2 (ref), u4 (ref), l__console__1 (copy)
    if u3 then
        local l__onCommitFiberRoot__6 = u3.onCommitFiberRoot;
        local v16;
        if typeof(l__onCommitFiberRoot__6) == "function" then
            v16 = true;
        elseif typeof(l__onCommitFiberRoot__6) == "table" then
            local v17 = getmetatable(l__onCommitFiberRoot__6);
            v16 = v17 and rawget(v17, "__call") and true or (l__onCommitFiberRoot__6._isMockFunction and true or false);
        else
            v16 = false;
        end;
        if v16 then
            local v19, v20 = pcall(function() --[[ Line: 132 ]]
                -- upvalues: u14 (copy), l__DidCapture__3 (ref), l__enableProfilerTimer__2 (ref), u3 (ref), u2 (ref), u15 (copy)
                local v18 = bit32.band(u14.current.flags, l__DidCapture__3) == l__DidCapture__3;
                if l__enableProfilerTimer__2 then
                    u3.onCommitFiberRoot(u2, u14, u15, v18);
                else
                    u3.onCommitFiberRoot(u2, u14, nil, v18);
                end;
            end);
            if not v19 and (_G.__DEV__ and not u4) then
                u4 = true;
                l__console__1.error("React instrumentation encountered an error: %s", v20);
            end;
        end;
    end;
end;
function v1.onCommitUnmount(p21) --[[ Line: 151 ]]
    -- upvalues: u3 (ref), u2 (ref), u4 (ref), l__console__1 (copy)
    if u3 then
        local l__onCommitFiberUnmount__7 = u3.onCommitFiberUnmount;
        local v22;
        if typeof(l__onCommitFiberUnmount__7) == "function" then
            v22 = true;
        elseif typeof(l__onCommitFiberUnmount__7) == "table" then
            local v23 = getmetatable(l__onCommitFiberUnmount__7);
            v22 = v23 and rawget(v23, "__call") and true or (l__onCommitFiberUnmount__7._isMockFunction and true or false);
        else
            v22 = false;
        end;
        if v22 then
            local v24, v25 = pcall(u3.onCommitFiberUnmount, u2, p21);
            if not v24 and (_G.__DEV__ and not u4) then
                u4 = true;
                l__console__1.error("React instrumentation encountered an error: %s", v25);
            end;
        end;
    end;
end;
return v1;