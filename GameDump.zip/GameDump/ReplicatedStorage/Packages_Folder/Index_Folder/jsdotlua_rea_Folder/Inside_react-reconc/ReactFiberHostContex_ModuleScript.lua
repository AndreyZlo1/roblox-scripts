-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberHostContext.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent:WaitForChild("ReactInternalTypes"));
local v1 = require(script.Parent:WaitForChild("ReactFiberStack.new"));
local l__ReactFiberHostConfig__1 = require(script.Parent:WaitForChild("ReactFiberHostConfig"));
local l__getChildHostContext__2 = l__ReactFiberHostConfig__1.getChildHostContext;
local l__getRootHostContext__3 = l__ReactFiberHostConfig__1.getRootHostContext;
local l__createCursor__4 = v1.createCursor;
local l__push__5 = v1.push;
local l__pop__6 = v1.pop;
local u2 = {};
local u3 = l__createCursor__4(u2);
local u4 = l__createCursor__4(u2);
local u5 = l__createCursor__4(u2);
function requiredContext(p6)
    return p6;
end;
function getRootHostContainer()
    -- upvalues: u5 (copy)
    return u5.current;
end;
function pushHostContainer(p7, p8)
    -- upvalues: l__push__5 (copy), u5 (copy), u4 (copy), u3 (copy), u2 (copy), l__getRootHostContext__3 (copy), l__pop__6 (copy)
    l__push__5(u5, p8, p7);
    l__push__5(u4, p7, p7);
    l__push__5(u3, u2, p7);
    local v9 = l__getRootHostContext__3(p8);
    l__pop__6(u3, p7);
    l__push__5(u3, v9, p7);
end;
function popHostContainer(p10)
    -- upvalues: l__pop__6 (copy), u3 (copy), u4 (copy), u5 (copy)
    l__pop__6(u3, p10);
    l__pop__6(u4, p10);
    l__pop__6(u5, p10);
end;
function getHostContext()
    -- upvalues: u3 (copy)
    return u3.current;
end;
function pushHostContext(p11)
    -- upvalues: u5 (copy), u3 (copy), l__getChildHostContext__2 (copy), l__push__5 (copy), u4 (copy)
    local v12 = requiredContext(u5.current);
    local v13 = requiredContext(u3.current);
    local v14 = l__getChildHostContext__2(v13, p11.type, v12);
    if v13 == v14 then
    else
        l__push__5(u4, p11, p11);
        l__push__5(u3, v14, p11);
    end;
end;
function popHostContext(p15)
    -- upvalues: u4 (copy), l__pop__6 (copy), u3 (copy)
    if u4.current == p15 then
        l__pop__6(u3, p15);
        l__pop__6(u4, p15);
    end;
end;
return {
    getHostContext = getHostContext,
    getRootHostContainer = getRootHostContainer,
    popHostContainer = popHostContainer,
    popHostContext = popHostContext,
    pushHostContainer = pushHostContainer,
    pushHostContext = pushHostContext
};