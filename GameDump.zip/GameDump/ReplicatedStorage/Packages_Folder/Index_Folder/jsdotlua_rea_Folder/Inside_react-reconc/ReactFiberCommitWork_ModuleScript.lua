-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberCommitWork.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local function u2(p1) --[[ Line: 11 ]]
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("UNIMPLEMENTED ERROR: " .. tostring(p1));
    error("FIXME (roblox): " .. p1 .. " is unimplemented", 2);
end;
local l____DEV____1 = _G.__DEV__;
local l____YOLO____2 = _G.__YOLO__;
local u3 = 0;
local l__console__3 = require(script.Parent.Parent:WaitForChild("shared")).console;
local v4 = require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local l__Error__4 = v4.Error;
local l__Set__5 = v4.Set;
local l__ReactFiberHostConfig__6 = require(script.Parent:WaitForChild("ReactFiberHostConfig"));
require(script.Parent:WaitForChild("ReactInternalTypes"));
require(script.Parent:WaitForChild("ReactFiberSuspenseComponent.new"));
local v5 = require(script.Parent:WaitForChild("ReactUpdateQueue.new"));
require(script.Parent.Parent:WaitForChild("shared"));
require(script.Parent:WaitForChild("ReactFiberOffscreenComponent"));
local l__ReactHookEffectTags__7 = require(script.Parent:WaitForChild("ReactHookEffectTags"));
local l__unstable_wrap__8 = require(script.Parent.Parent:WaitForChild("scheduler")).tracing.unstable_wrap;
local l__ReactFeatureFlags__9 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags;
local l__enableSchedulerTracing__10 = l__ReactFeatureFlags__9.enableSchedulerTracing;
local l__enableProfilerTimer__11 = l__ReactFeatureFlags__9.enableProfilerTimer;
local l__enableProfilerCommitHooks__12 = l__ReactFeatureFlags__9.enableProfilerCommitHooks;
local l__enableSuspenseCallback__13 = l__ReactFeatureFlags__9.enableSuspenseCallback;
local l__enableDoubleInvokingEffects__14 = l__ReactFeatureFlags__9.enableDoubleInvokingEffects;
local l__ReactWorkTags__15 = require(script.Parent:WaitForChild("ReactWorkTags"));
local l__FunctionComponent__16 = l__ReactWorkTags__15.FunctionComponent;
local l__ForwardRef__17 = l__ReactWorkTags__15.ForwardRef;
local l__ClassComponent__18 = l__ReactWorkTags__15.ClassComponent;
local l__HostRoot__19 = l__ReactWorkTags__15.HostRoot;
local l__HostComponent__20 = l__ReactWorkTags__15.HostComponent;
local l__HostText__21 = l__ReactWorkTags__15.HostText;
local l__HostPortal__22 = l__ReactWorkTags__15.HostPortal;
local l__Profiler__23 = l__ReactWorkTags__15.Profiler;
local l__SuspenseComponent__24 = l__ReactWorkTags__15.SuspenseComponent;
local l__DehydratedFragment__25 = l__ReactWorkTags__15.DehydratedFragment;
local l__IncompleteClassComponent__26 = l__ReactWorkTags__15.IncompleteClassComponent;
local l__MemoComponent__27 = l__ReactWorkTags__15.MemoComponent;
local l__SimpleMemoComponent__28 = l__ReactWorkTags__15.SimpleMemoComponent;
local l__SuspenseListComponent__29 = l__ReactWorkTags__15.SuspenseListComponent;
local l__FundamentalComponent__30 = l__ReactWorkTags__15.FundamentalComponent;
local l__ScopeComponent__31 = l__ReactWorkTags__15.ScopeComponent;
local l__Block__32 = l__ReactWorkTags__15.Block;
local l__OffscreenComponent__33 = l__ReactWorkTags__15.OffscreenComponent;
local l__LegacyHiddenComponent__34 = l__ReactWorkTags__15.LegacyHiddenComponent;
local l__ReactErrorUtils__35 = require(script.Parent.Parent:WaitForChild("shared")).ReactErrorUtils;
local l__invokeGuardedCallback__36 = l__ReactErrorUtils__35.invokeGuardedCallback;
local l__hasCaughtError__37 = l__ReactErrorUtils__35.hasCaughtError;
local l__clearCaughtError__38 = l__ReactErrorUtils__35.clearCaughtError;
local l__ReactFiberFlags__39 = require(script.Parent:WaitForChild("ReactFiberFlags"));
local l__NoFlags__40 = l__ReactFiberFlags__39.NoFlags;
local l__ContentReset__41 = l__ReactFiberFlags__39.ContentReset;
local l__Placement__42 = l__ReactFiberFlags__39.Placement;
local l__Snapshot__43 = l__ReactFiberFlags__39.Snapshot;
local l__Update__44 = l__ReactFiberFlags__39.Update;
local l__Callback__45 = l__ReactFiberFlags__39.Callback;
local l__LayoutMask__46 = l__ReactFiberFlags__39.LayoutMask;
local l__PassiveMask__47 = l__ReactFiberFlags__39.PassiveMask;
local l__Ref__48 = l__ReactFiberFlags__39.Ref;
local l__getComponentName__49 = require(script.Parent.Parent:WaitForChild("shared")).getComponentName;
local l__invariant__50 = require(script.Parent.Parent:WaitForChild("shared")).invariant;
local l__describeError__51 = require(script.Parent.Parent:WaitForChild("shared")).describeError;
local l__ReactCurrentFiber__52 = require(script.Parent:WaitForChild("ReactCurrentFiber"));
local l__current__53 = l__ReactCurrentFiber__52.current;
local l__resetCurrentFiber__54 = l__ReactCurrentFiber__52.resetCurrentFiber;
local l__setCurrentFiber__55 = l__ReactCurrentFiber__52.setCurrentFiber;
local l__onCommitUnmount__56 = require(script.Parent:WaitForChild("ReactFiberDevToolsHook.new")).onCommitUnmount;
local l__resolveDefaultProps__57 = require(script.Parent:WaitForChild("ReactFiberLazyComponent.new")).resolveDefaultProps;
local v6 = require(script.Parent:WaitForChild("ReactProfilerTimer.new"));
local l__startLayoutEffectTimer__58 = v6.startLayoutEffectTimer;
local l__recordPassiveEffectDuration__59 = v6.recordPassiveEffectDuration;
local l__recordLayoutEffectDuration__60 = v6.recordLayoutEffectDuration;
local l__startPassiveEffectTimer__61 = v6.startPassiveEffectTimer;
local l__getCommitTime__62 = v6.getCommitTime;
local l__ProfileMode__63 = require(script.Parent:WaitForChild("ReactTypeOfMode")).ProfileMode;
local l__commitUpdateQueue__64 = v5.commitUpdateQueue;
local l__getPublicInstance__65 = l__ReactFiberHostConfig__6.getPublicInstance;
local l__supportsMutation__66 = l__ReactFiberHostConfig__6.supportsMutation;
local l__supportsPersistence__67 = l__ReactFiberHostConfig__6.supportsPersistence;
local l__supportsHydration__68 = l__ReactFiberHostConfig__6.supportsHydration;
local l__commitMount__69 = l__ReactFiberHostConfig__6.commitMount;
local l__commitUpdate__70 = l__ReactFiberHostConfig__6.commitUpdate;
local l__resetTextContent__71 = l__ReactFiberHostConfig__6.resetTextContent;
local l__commitTextUpdate__72 = l__ReactFiberHostConfig__6.commitTextUpdate;
local l__appendChild__73 = l__ReactFiberHostConfig__6.appendChild;
local l__appendChildToContainer__74 = l__ReactFiberHostConfig__6.appendChildToContainer;
local l__insertBefore__75 = l__ReactFiberHostConfig__6.insertBefore;
local l__insertInContainerBefore__76 = l__ReactFiberHostConfig__6.insertInContainerBefore;
local l__removeChild__77 = l__ReactFiberHostConfig__6.removeChild;
local l__removeChildFromContainer__78 = l__ReactFiberHostConfig__6.removeChildFromContainer;
local l__hideInstance__79 = l__ReactFiberHostConfig__6.hideInstance;
local l__hideTextInstance__80 = l__ReactFiberHostConfig__6.hideTextInstance;
local l__unhideInstance__81 = l__ReactFiberHostConfig__6.unhideInstance;
local l__unhideTextInstance__82 = l__ReactFiberHostConfig__6.unhideTextInstance;
local l__commitHydratedSuspenseInstance__83 = l__ReactFiberHostConfig__6.commitHydratedSuspenseInstance;
local l__clearContainer__84 = l__ReactFiberHostConfig__6.clearContainer;
local u7 = nil;
local function u10(p8, p9) --[[ Line: 190 ]]
    -- upvalues: u7 (ref)
    if not u7 then
        u7 = require(script.Parent:WaitForChild("ReactFiberWorkLoop.new"));
    end;
    u7.resolveRetryWakeable(p8, p9);
end;
local function u11() --[[ Line: 205 ]]
    -- upvalues: l__console__3 (copy)
    l__console__3.warn("ReactFiberCommitWork: schedulePassiveEffectCallback causes a dependency cycle\n" .. debug.traceback());
end;
local function u13(_, _, p12) --[[ Line: 213 ]]
    -- upvalues: l__console__3 (copy)
    l__console__3.warn("ReactFiberCommitWork: captureCommitPhaseError causes a dependency cycle");
    error(p12);
end;
local l__NoFlags__85 = l__ReactHookEffectTags__7.NoFlags;
local l__HasEffect__86 = l__ReactHookEffectTags__7.HasEffect;
local l__Layout__87 = l__ReactHookEffectTags__7.Layout;
local l__Passive__88 = l__ReactHookEffectTags__7.Passive;
local u14 = nil;
local function u15() --[[ Line: 231 ]]
    -- upvalues: u14 (ref)
    if not u14 then
        u14 = require(script.Parent:WaitForChild("ReactFiberBeginWork.new")).didWarnAboutReassigningProps;
    end;
    return u14;
end;
local u16 = nil;
local u17 = nil;
local u18 = nil;
local u19 = nil;
local u20 = nil;
local u21 = nil;
local u22 = nil;
local u23 = nil;
local function u28(p24, u25) --[[ Line: 256 ]]
    -- upvalues: l__enableProfilerTimer__11 (copy), l__enableProfilerCommitHooks__12 (copy), l__ProfileMode__63 (copy), l__startLayoutEffectTimer__58 (copy), l__describeError__51 (copy), l__recordLayoutEffectDuration__60 (copy)
    u25.props = p24.memoizedProps;
    u25.state = p24.memoizedState;
    if l__enableProfilerTimer__11 and (l__enableProfilerCommitHooks__12 and bit32.band(p24.mode, l__ProfileMode__63) ~= 0) then
        local v26, v27 = xpcall(function() --[[ Line: 265 ]]
            -- upvalues: l__startLayoutEffectTimer__58 (ref), u25 (copy)
            l__startLayoutEffectTimer__58();
            u25:componentWillUnmount();
        end, l__describeError__51);
        l__recordLayoutEffectDuration__60(p24);
        if not v26 then
            error(v27);
        end;
    else
        u25:componentWillUnmount();
    end;
end;
function safelyCallComponentWillUnmount(p29, p30, p31)
    -- upvalues: u28 (copy), l__describeError__51 (copy), u13 (ref)
    local v32, v33 = xpcall(u28, l__describeError__51, p29, p30);
    if not v32 then
        u13(p29, p31, v33);
    end;
end;
local function v39(p34, p35, p36) --[[ Line: 313 ]]
    -- upvalues: l__describeError__51 (copy), u13 (ref)
    local v37, v38 = xpcall(p36, l__describeError__51);
    if not v37 then
        u13(p34, p35, v38);
    end;
end;
local function u47(p40, p41, p42) --[[ Line: 418 ]]
    -- upvalues: l__describeError__51 (copy), u13 (ref)
    local l__updateQueue__89 = p41.updateQueue;
    local v43;
    if l__updateQueue__89 == nil then
        v43 = nil;
    else
        v43 = l__updateQueue__89.lastEffect;
    end;
    if v43 == nil then
    else
        local l__next__90 = v43.next;
        local v44 = l__next__90;
        while true do
            if bit32.band(l__next__90.tag, p40) == p40 then
                local l__destroy__91 = l__next__90.destroy;
                l__next__90.destroy = nil;
                if l__destroy__91 ~= nil then
                    local v45, v46 = xpcall(l__destroy__91, l__describeError__51);
                    if not v45 then
                        u13(p41, p42, v46);
                    end;
                end;
            end;
            l__next__90 = l__next__90.next;
            if l__next__90 == v44 then
                return;
            end;
        end;
    end;
end;
local function u53(p48, p49) --[[ Line: 446 ]]
    -- upvalues: l____DEV____1 (copy), l__console__3 (copy)
    local l__updateQueue__92 = p49.updateQueue;
    local v50;
    if l__updateQueue__92 == nil then
        v50 = nil;
    else
        v50 = l__updateQueue__92.lastEffect;
    end;
    if v50 == nil then
    else
        local l__next__93 = v50.next;
        local v51 = l__next__93;
        while true do
            if bit32.band(l__next__93.tag, p48) == p48 then
                l__next__93.destroy = l__next__93.create();
                if l____DEV____1 then
                    local l__destroy__94 = l__next__93.destroy;
                    if l__destroy__94 ~= nil and typeof(l__destroy__94) ~= "function" then
                        local v52 = l__destroy__94 == nil and " You returned nil. If your effect does not require clean up, return nil (or nothing)." or (typeof(l__destroy__94.andThen) == "function" and "\n\nIt looks like you wrote useEffect(Promise.new(function() --[[...]] end) or returned a Promise. Instead, write the async function inside your effect and call it immediately:\n\nuseEffect(function()\n  function fetchData()\n    -- You can await here\n    local response = MyAPI.getData(someId):await()\n    -- ...\n  end\n  fetchData()\nend, {someId}) -- Or {} if effect doesn\'t need props or state\n\nLearn more about data fetching with Hooks: https://reactjs.org/link/hooks-data-fetching" or " You returned: " .. l__destroy__94);
                        l__console__3.error("An effect function must not return anything besides a function, which is used for clean-up.%s", v52);
                    end;
                end;
            end;
            l__next__93 = l__next__93.next;
            if l__next__93 == v51 then
                return;
            end;
        end;
    end;
end;
function commitProfilerPassiveEffect(p54, p55)
    -- upvalues: l__enableProfilerTimer__11 (copy), l__enableProfilerCommitHooks__12 (copy), l__Profiler__23 (copy), l__getCommitTime__62 (copy), l__enableSchedulerTracing__10 (copy)
    if l__enableProfilerTimer__11 and (l__enableProfilerCommitHooks__12 and p55.tag == l__Profiler__23) then
        local l__passiveEffectDuration__95 = p55.stateNode.passiveEffectDuration;
        local l__id__96 = p55.memoizedProps.id;
        local l__onPostCommit__97 = p55.memoizedProps.onPostCommit;
        local v56 = l__getCommitTime__62();
        if typeof(l__onPostCommit__97) == "function" then
            if l__enableSchedulerTracing__10 then
                l__onPostCommit__97(l__id__96, p55.alternate == nil and "mount" or "update", l__passiveEffectDuration__95, v56, p54.memoizedInteractions);
                return;
            end;
            l__onPostCommit__97(l__id__96, p55.alternate == nil and "mount" or "update", l__passiveEffectDuration__95, v56);
        end;
    end;
end;
local function u75(u57, p58, p59, p60) --[[ Line: 530 ]]
    -- upvalues: u13 (ref), u11 (ref), l__Profiler__23 (copy), l__enableProfilerTimer__11 (copy), l__enableProfilerCommitHooks__12 (copy), u23 (ref), l__LayoutMask__46 (copy), l__NoFlags__40 (copy), l____DEV____1 (copy), l__current__53 (copy), l__setCurrentFiber__55 (copy), l__invokeGuardedCallback__36 (copy), u75 (copy), l__hasCaughtError__37 (copy), l__clearCaughtError__38 (copy), l__resetCurrentFiber__54 (copy), l__describeError__51 (copy), l__Update__44 (copy), l__Callback__45 (copy), l__ReactCurrentFiber__52 (copy), u3 (ref), l____YOLO____2 (copy), l__FunctionComponent__16 (copy), l__ForwardRef__17 (copy), l__SimpleMemoComponent__28 (copy), l__Block__32 (copy), l__ProfileMode__63 (copy), l__startLayoutEffectTimer__58 (copy), u53 (copy), l__Layout__87 (copy), l__HasEffect__86 (copy), l__recordLayoutEffectDuration__60 (copy), l__PassiveMask__47 (copy), l__ClassComponent__18 (copy), u21 (ref), l__HostRoot__19 (copy), u19 (ref), l__HostComponent__20 (copy), u20 (ref), l__SuspenseComponent__24 (copy), l__FundamentalComponent__30 (copy), l__HostPortal__22 (copy), l__HostText__21 (copy), l__IncompleteClassComponent__26 (copy), l__LegacyHiddenComponent__34 (copy), l__OffscreenComponent__33 (copy), l__ScopeComponent__31 (copy), l__SuspenseListComponent__29 (copy), l__invariant__50 (copy), l__Ref__48 (copy)
    if p59 ~= nil then
        u13 = p59;
    end;
    if p60 ~= nil then
        u11 = p60;
    end;
    local l__flags__98 = u57.flags;
    local l__tag__99 = u57.tag;
    if l__tag__99 == l__Profiler__23 then
        local v61;
        if l__enableProfilerTimer__11 and l__enableProfilerCommitHooks__12 then
            v61 = u23;
            u23 = u57;
        else
            v61 = nil;
        end;
        local l__child__100 = u57.child;
        while l__child__100 ~= nil do
            if bit32.band(u57.subtreeFlags, l__LayoutMask__46) ~= l__NoFlags__40 then
                if l____DEV____1 then
                    local v62 = l__current__53;
                    l__setCurrentFiber__55(l__child__100);
                    l__invokeGuardedCallback__36(nil, u75, nil, l__child__100, p58, u13, u11);
                    if l__hasCaughtError__37() then
                        u13(l__child__100, u57, (l__clearCaughtError__38()));
                    end;
                    if v62 == nil then
                        l__resetCurrentFiber__54();
                    else
                        l__setCurrentFiber__55(v62);
                    end;
                else
                    local v63, v64 = xpcall(u75, l__describeError__51, l__child__100, p58, u13, u11);
                    if not v63 then
                        u13(l__child__100, u57, v64);
                    end;
                end;
            end;
            l__child__100 = l__child__100.sibling;
        end;
        local v65 = bit32.bor(l__Update__44, l__Callback__45);
        if bit32.band(l__flags__98, v65) ~= l__NoFlags__40 and l__enableProfilerTimer__11 then
            if l____DEV____1 then
                local v66 = l__current__53;
                l__setCurrentFiber__55(u57);
                l__invokeGuardedCallback__36(nil, commitLayoutEffectsForProfiler, nil, u57, p58);
                if l__hasCaughtError__37() then
                    local v67 = l__clearCaughtError__38();
                    u13(u57, u57.return_, v67);
                end;
                if v66 == nil then
                    l__resetCurrentFiber__54();
                else
                    l__setCurrentFiber__55(v66);
                end;
            else
                local v68, v69 = xpcall(commitLayoutEffectsForProfiler, l__describeError__51, u57, p58);
                if not v68 then
                    u13(u57, u57.return_, v69);
                end;
            end;
        end;
        if l__enableProfilerTimer__11 and l__enableProfilerCommitHooks__12 then
            if v61 ~= nil then
                local l__stateNode__101 = v61.stateNode;
                l__stateNode__101.effectDuration = l__stateNode__101.effectDuration + u57.stateNode.effectDuration;
            end;
            u23 = v61;
        end;
    else
        local l__child__102 = u57.child;
        while l__child__102 ~= nil do
            if bit32.band(u57.subtreeFlags, l__LayoutMask__46) ~= l__NoFlags__40 then
                if l____DEV____1 then
                    local l__current__103 = l__ReactCurrentFiber__52.current;
                    l__setCurrentFiber__55(l__child__102);
                    if u3 < 20 then
                        u3 = u3 + 1;
                        l__invokeGuardedCallback__36(nil, u75, nil, l__child__102, p58, u13, u11);
                        u3 = u3 - 1;
                        if l__hasCaughtError__37() then
                            u13(l__child__102, u57, (l__clearCaughtError__38()));
                        end;
                    else
                        u75(l__child__102, p58, u13, u11);
                    end;
                    if l__current__103 == nil then
                        l__resetCurrentFiber__54();
                    else
                        l__setCurrentFiber__55(l__current__103);
                    end;
                else
                    local v70 = nil;
                    local v71;
                    if l____YOLO____2 or u3 >= 20 then
                        u75(l__child__102, p58, u13, u11);
                        v71 = true;
                    else
                        u3 = u3 + 1;
                        v71, v70 = xpcall(u75, l__describeError__51, l__child__102, p58, u13, u11);
                        u3 = u3 - 1;
                    end;
                    if not v71 then
                        u13(l__child__102, u57, v70);
                    end;
                end;
            end;
            l__child__102 = l__child__102.sibling;
        end;
        local v72 = bit32.bor(l__Update__44, l__Callback__45);
        if bit32.band(l__flags__98, v72) ~= l__NoFlags__40 then
            if l__tag__99 == l__FunctionComponent__16 or (l__tag__99 == l__ForwardRef__17 or (l__tag__99 == l__SimpleMemoComponent__28 or l__tag__99 == l__Block__32)) then
                if l__enableProfilerTimer__11 and (l__enableProfilerCommitHooks__12 and bit32.band(u57.mode, l__ProfileMode__63) ~= 0) then
                    local v73, v74 = xpcall(function() --[[ Line: 751 ]]
                        -- upvalues: l__startLayoutEffectTimer__58 (ref), u53 (ref), l__Layout__87 (ref), l__HasEffect__86 (ref), u57 (copy)
                        l__startLayoutEffectTimer__58();
                        u53(bit32.bor(l__Layout__87, l__HasEffect__86), u57);
                    end, l__describeError__51);
                    l__recordLayoutEffectDuration__60(u57);
                    if not v73 then
                        error(v74);
                    end;
                else
                    u53(bit32.bor(l__Layout__87, l__HasEffect__86), u57);
                end;
                if bit32.band(u57.subtreeFlags, l__PassiveMask__47) ~= l__NoFlags__40 then
                    u11();
                end;
            elseif l__tag__99 == l__ClassComponent__18 then
                u21(u57);
            elseif l__tag__99 == l__HostRoot__19 then
                u19(u57);
            elseif l__tag__99 == l__HostComponent__20 then
                u20(u57);
            elseif l__tag__99 == l__SuspenseComponent__24 then
                commitSuspenseHydrationCallbacks(p58, u57);
            elseif l__tag__99 ~= l__FundamentalComponent__30 and (l__tag__99 ~= l__HostPortal__22 and (l__tag__99 ~= l__HostText__21 and (l__tag__99 ~= l__IncompleteClassComponent__26 and (l__tag__99 ~= l__LegacyHiddenComponent__34 and (l__tag__99 ~= l__OffscreenComponent__33 and (l__tag__99 ~= l__ScopeComponent__31 and l__tag__99 ~= l__SuspenseListComponent__29)))))) then
                l__invariant__50(false, "This unit of work tag should not have side-effects. This error is likely caused by a bug in React. Please file an issue.");
            end;
        end;
        if bit32.band(l__flags__98, l__Ref__48) ~= 0 then
            commitAttachRef(u57);
        end;
    end;
end;
function commitLayoutEffectsForProfiler(p76, p77)
    -- upvalues: l__enableProfilerTimer__11 (copy), l__getCommitTime__62 (copy), l__Update__44 (copy), l__Callback__45 (copy), l__NoFlags__40 (copy), l__enableSchedulerTracing__10 (copy), l__enableProfilerCommitHooks__12 (copy)
    if l__enableProfilerTimer__11 then
        local l__flags__104 = p76.flags;
        local l__alternate__105 = p76.alternate;
        local l__onCommit__106 = p76.memoizedProps.onCommit;
        local l__onRender__107 = p76.memoizedProps.onRender;
        local l__effectDuration__108 = p76.stateNode.effectDuration;
        local v78 = l__getCommitTime__62();
        local v79 = l__Callback__45;
        if bit32.band(l__flags__104, l__Update__44) ~= l__NoFlags__40 then
            local v80;
            if typeof(l__onRender__107) == "function" then
                v80 = true;
            elseif typeof(l__onRender__107) == "table" then
                local v81 = getmetatable(l__onRender__107);
                v80 = v81 and rawget(v81, "__call") and true or (l__onRender__107._isMockFunction and true or false);
            else
                v80 = false;
            end;
            if v80 then
                if l__enableSchedulerTracing__10 then
                    l__onRender__107(p76.memoizedProps.id, l__alternate__105 == nil and "mount" or "update", p76.actualDuration, p76.treeBaseDuration, p76.actualStartTime, v78, p77.memoizedInteractions);
                else
                    l__onRender__107(p76.memoizedProps.id, l__alternate__105 == nil and "mount" or "update", p76.actualDuration, p76.treeBaseDuration, p76.actualStartTime, v78);
                end;
            end;
        end;
        if l__enableProfilerCommitHooks__12 and bit32.band(l__flags__104, v79) ~= l__NoFlags__40 then
            local v82;
            if typeof(l__onCommit__106) == "function" then
                v82 = true;
            elseif typeof(l__onCommit__106) == "table" then
                local v83 = getmetatable(l__onCommit__106);
                v82 = v83 and rawget(v83, "__call") and true or (l__onCommit__106._isMockFunction and true or false);
            else
                v82 = false;
            end;
            if v82 then
                if l__enableSchedulerTracing__10 then
                    l__onCommit__106(p76.memoizedProps.id, l__alternate__105 == nil and "mount" or "update", l__effectDuration__108, v78, p77.memoizedInteractions);
                    return;
                end;
                l__onCommit__106(p76.memoizedProps.id, l__alternate__105 == nil and "mount" or "update", l__effectDuration__108, v78);
            end;
        end;
    end;
end;
u21 = function(p84) --[[ Name: commitLayoutEffectsForClassComponent, Line 882 ]]
    -- upvalues: l__Update__44 (copy), l____DEV____1 (copy), u15 (copy), l__console__3 (copy), l__getComponentName__49 (copy), l__enableProfilerTimer__11 (copy), l__enableProfilerCommitHooks__12 (copy), l__ProfileMode__63 (copy), l__startLayoutEffectTimer__58 (copy), l__describeError__51 (copy), l__recordLayoutEffectDuration__60 (copy), l__resolveDefaultProps__57 (copy), l__commitUpdateQueue__64 (copy)
    local l__stateNode__109 = p84.stateNode;
    local l__alternate__110 = p84.alternate;
    if bit32.band(p84.flags, l__Update__44) ~= 0 then
        if l__alternate__110 == nil then
            if l____DEV____1 and (p84.type == p84.elementType and not u15) then
                if l__stateNode__109.props ~= p84.memoizedProps then
                    l__console__3.error("Expected %s props to match memoized props before componentDidMount. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.", l__getComponentName__49(p84.type) or "instance");
                end;
                if l__stateNode__109.state ~= p84.memoizedState then
                    l__console__3.error("Expected %s state to match memoized state before componentDidMount. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.", l__getComponentName__49(p84.type) or "instance");
                end;
            end;
            if l__enableProfilerTimer__11 and (l__enableProfilerCommitHooks__12 and bit32.band(p84.mode, l__ProfileMode__63) ~= 0) then
                local v85, v86 = xpcall(function() --[[ Line: 914 ]]
                    -- upvalues: l__startLayoutEffectTimer__58 (ref), l__stateNode__109 (copy)
                    l__startLayoutEffectTimer__58();
                    l__stateNode__109:componentDidMount();
                end, l__describeError__51);
                l__recordLayoutEffectDuration__60(p84);
                if not v85 then
                    error(v86);
                end;
            else
                l__stateNode__109:componentDidMount();
            end;
        else
            local u87 = p84.elementType == p84.type and l__alternate__110.memoizedProps or l__resolveDefaultProps__57(p84.type, l__alternate__110.memoizedProps);
            local l__memoizedState__111 = l__alternate__110.memoizedState;
            if l____DEV____1 and (p84.type == p84.elementType and not u15) then
                if l__stateNode__109.props ~= p84.memoizedProps then
                    l__console__3.error("Expected %s props to match memoized props before componentDidUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.", l__getComponentName__49(p84.type) or "instance");
                end;
                if l__stateNode__109.state ~= p84.memoizedState then
                    l__console__3.error("Expected %s state to match memoized state before componentDidUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.", l__getComponentName__49(p84.type) or "instance");
                end;
            end;
            if l__enableProfilerTimer__11 and (l__enableProfilerCommitHooks__12 and bit32.band(p84.mode, l__ProfileMode__63) ~= 0) then
                local v88, v89 = xpcall(function() --[[ Line: 968 ]]
                    -- upvalues: l__startLayoutEffectTimer__58 (ref), l__stateNode__109 (copy), u87 (copy), l__memoizedState__111 (copy)
                    l__startLayoutEffectTimer__58();
                    l__stateNode__109:componentDidUpdate(u87, l__memoizedState__111, l__stateNode__109.__reactInternalSnapshotBeforeUpdate);
                end, l__describeError__51);
                l__recordLayoutEffectDuration__60(p84);
                if not v88 then
                    error(v89);
                end;
            else
                l__stateNode__109:componentDidUpdate(u87, l__memoizedState__111, l__stateNode__109.__reactInternalSnapshotBeforeUpdate);
            end;
        end;
    end;
    local l__updateQueue__112 = p84.updateQueue;
    if l__updateQueue__112 ~= nil then
        if l____DEV____1 and (p84.type == p84.elementType and not u15) then
            if l__stateNode__109.props ~= p84.memoizedProps then
                l__console__3.error("Expected %s props to match memoized props before processing the update queue. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.", l__getComponentName__49(p84.type) or "instance");
            end;
            if l__stateNode__109.state ~= p84.memoizedState then
                l__console__3.error("Expected %s state to match memoized state before processing the update queue. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.", l__getComponentName__49(p84.type) or "instance");
            end;
        end;
        l__commitUpdateQueue__64(p84, l__updateQueue__112, l__stateNode__109);
    end;
end;
u19 = function(p90) --[[ Name: commitLayoutEffectsForHostRoot, Line 1031 ]]
    -- upvalues: l__HostComponent__20 (copy), l__getPublicInstance__65 (copy), l__ClassComponent__18 (copy), l__commitUpdateQueue__64 (copy)
    local l__updateQueue__113 = p90.updateQueue;
    if l__updateQueue__113 ~= nil then
        local v91 = nil;
        if p90.child ~= nil then
            local l__child__114 = p90.child;
            if l__child__114.tag == l__HostComponent__20 then
                v91 = l__getPublicInstance__65(l__child__114.stateNode);
            elseif l__child__114.tag == l__ClassComponent__18 then
                v91 = l__child__114.stateNode;
            end;
        end;
        l__commitUpdateQueue__64(p90, l__updateQueue__113, v91);
    end;
end;
u20 = function(p92) --[[ Name: commitLayoutEffectsForHostComponent, Line 1050 ]]
    -- upvalues: l__Update__44 (copy), l__commitMount__69 (copy)
    local l__stateNode__115 = p92.stateNode;
    if p92.alternate == nil and bit32.band(p92.flags, l__Update__44) ~= 0 then
        l__commitMount__69(l__stateNode__115, p92.type, p92.memoizedProps, p92);
    end;
end;
local function u96(p93, p94) --[[ Line: 1065 ]]
    -- upvalues: l__supportsMutation__66 (copy), l__HostComponent__20 (copy), l__hideInstance__79 (copy), l__unhideInstance__81 (copy), l__HostText__21 (copy), l__hideTextInstance__80 (copy), l__unhideTextInstance__82 (copy), l__OffscreenComponent__33 (copy), l__LegacyHiddenComponent__34 (copy)
    if not l__supportsMutation__66 then
        return;
    end;
    local v95 = p93;
    while true do
        while p93.tag == l__HostComponent__20 do
            local l__stateNode__116 = p93.stateNode;
            if p94 then
                l__hideInstance__79(l__stateNode__116);
            else
                l__unhideInstance__81(p93.stateNode, p93.memoizedProps);
            end;
            if p93 == v95 then
                return;
            end;
            while p93.sibling == nil do
                if p93.return_ == nil or p93.return_ == v95 then
                    return;
                end;
                p93 = p93.return_;
            end;
            p93.sibling.return_ = p93.return_;
            p93 = p93.sibling;
        end;
        if p93.tag == l__HostText__21 then
            local l__stateNode__117 = p93.stateNode;
            if p94 then
                l__hideTextInstance__80(l__stateNode__117);
            else
                l__unhideTextInstance__82(l__stateNode__117, p93.memoizedProps);
            end;
            if p93 == v95 then
                return;
            end;
            while p93.sibling == nil do
                if p93.return_ == nil or p93.return_ == v95 then
                    return;
                end;
                p93 = p93.return_;
            end;
            p93.sibling.return_ = p93.return_;
            p93 = p93.sibling;
        end;
        if (p93.tag == l__OffscreenComponent__33 or p93.tag == l__LegacyHiddenComponent__34) and (p93.memoizedState ~= nil and p93 ~= v95) or p93.child == nil then
            if p93 == v95 then
                return;
            end;
            while p93.sibling == nil do
                if p93.return_ == nil or p93.return_ == v95 then
                    return;
                end;
                p93 = p93.return_;
            end;
            p93.sibling.return_ = p93.return_;
            p93 = p93.sibling;
        end;
        p93.child.return_ = p93;
        p93 = p93.child;
    end;
end;
function commitAttachRef(p97)
    -- upvalues: l__HostComponent__20 (copy), l__getPublicInstance__65 (copy), l____DEV____1 (copy), l__console__3 (copy), l__getComponentName__49 (copy)
    local l__ref__118 = p97.ref;
    if l__ref__118 ~= nil then
        local l__stateNode__119 = p97.stateNode;
        if p97.tag == l__HostComponent__20 then
            l__stateNode__119 = l__getPublicInstance__65(l__stateNode__119);
        end;
        if typeof(l__ref__118) == "function" then
            l__ref__118(l__stateNode__119);
            return;
        end;
        if l____DEV____1 and typeof(l__ref__118) ~= "table" then
            l__console__3.error("Unexpected ref object provided for %s. Use either a ref-setter function or React.createRef().", l__getComponentName__49(p97.type) or "instance");
            return;
        end;
        l__ref__118.current = l__stateNode__119;
    end;
end;
function commitDetachRef(p98)
    local l__ref__120 = p98.ref;
    if l__ref__120 ~= nil then
        if typeof(l__ref__120) == "function" then
            l__ref__120(nil);
            return;
        end;
        l__ref__120.current = nil;
    end;
end;
local function u112(p99, p100, p101, p102) --[[ Line: 1168 ]]
    -- upvalues: l__onCommitUnmount__56 (copy), l__FunctionComponent__16 (copy), l__ForwardRef__17 (copy), l__MemoComponent__27 (copy), l__SimpleMemoComponent__28 (copy), l__Block__32 (copy), l__Layout__87 (copy), l__NoFlags__85 (copy), l__enableProfilerTimer__11 (copy), l__enableProfilerCommitHooks__12 (copy), l__ProfileMode__63 (copy), l__startLayoutEffectTimer__58 (copy), l__describeError__51 (copy), u13 (ref), l__recordLayoutEffectDuration__60 (copy), l__ClassComponent__18 (copy), l__HostComponent__20 (copy), l__HostPortal__22 (copy), l__supportsMutation__66 (copy), u22 (ref), l__supportsPersistence__67 (copy), u2 (copy)
    l__onCommitUnmount__56(p100);
    if p100.tag ~= l__FunctionComponent__16 and (p100.tag ~= l__ForwardRef__17 and (p100.tag ~= l__MemoComponent__27 and (p100.tag ~= l__SimpleMemoComponent__28 and p100.tag ~= l__Block__32))) then
        if p100.tag == l__ClassComponent__18 then
            local l__ref__121 = p100.ref;
            if l__ref__121 ~= nil then
                if typeof(l__ref__121) == "function" then
                    local v103, v104 = xpcall(l__ref__121, l__describeError__51);
                    if not v103 then
                        u13(p100, p101, v104);
                    end;
                else
                    l__ref__121.current = nil;
                end;
            end;
            local l__stateNode__122 = p100.stateNode;
            if typeof(l__stateNode__122.componentWillUnmount) == "function" then
                safelyCallComponentWillUnmount(p100, l__stateNode__122, p101);
            end;
            return;
        elseif p100.tag == l__HostComponent__20 then
            local l__ref__123 = p100.ref;
            if l__ref__123 ~= nil then
                if typeof(l__ref__123) == "function" then
                    local v105, v106 = xpcall(l__ref__123, l__describeError__51);
                    if not v105 then
                        u13(p100, p101, v106);
                        return;
                    end;
                else
                    l__ref__123.current = nil;
                end;
            end;
            return;
        elseif p100.tag == l__HostPortal__22 then
            if l__supportsMutation__66 then
                u22(p99, p100, p101, p102);
                return;
            else
                if l__supportsPersistence__67 then
                    u2("emptyPortalContainer");
                end;
                return;
            end;
        else
            return;
        end;
    end;
    local l__updateQueue__124 = p100.updateQueue;
    if l__updateQueue__124 ~= nil then
        local l__lastEffect__125 = l__updateQueue__124.lastEffect;
        if l__lastEffect__125 ~= nil then
            local l__next__126 = l__lastEffect__125.next;
            local v107 = l__next__126;
            while true do
                if l__next__126.destroy ~= nil and bit32.band(l__next__126.tag, l__Layout__87) ~= l__NoFlags__85 then
                    if l__enableProfilerTimer__11 and (l__enableProfilerCommitHooks__12 and bit32.band(p100.mode, l__ProfileMode__63) ~= 0) then
                        l__startLayoutEffectTimer__58();
                        local v108, v109 = xpcall(l__next__126.destroy, l__describeError__51);
                        if not v108 then
                            u13(p100, p101, v109);
                        end;
                        l__recordLayoutEffectDuration__60(p100);
                    else
                        local v110, v111 = xpcall(l__next__126.destroy, l__describeError__51);
                        if not v110 then
                            u13(p100, p101, v111);
                        end;
                    end;
                end;
                l__next__126 = l__next__126.next;
                if l__next__126 == v107 then
                end;
            end;
        end;
    end;
end;
local function u118(p113, p114, p115, p116) --[[ Line: 1275 ]]
    -- upvalues: u112 (ref), l__supportsMutation__66 (copy), l__HostPortal__22 (copy)
    local v117 = p114;
    while true do
        while true do
            u112(p113, p114, p115, p116);
            if p114.child ~= nil and (not l__supportsMutation__66 or p114.tag ~= l__HostPortal__22) then
                break;
            end;
            if p114 == v117 then
                return;
            end;
            while p114.sibling == nil do
                if p114.return_ == nil or p114.return_ == v117 then
                    return;
                end;
                p114 = p114.return_;
            end;
            p114.sibling.return_ = p114.return_;
            p114 = p114.sibling;
        end;
        p114.child.return_ = p114;
        p114 = p114.child;
    end;
end;
local function u120(p119) --[[ Line: 1382 ]]
    -- upvalues: u16 (ref), l__Error__4 (copy)
    local l__return___127 = p119.return_;
    while l__return___127 ~= nil do
        if u16(l__return___127) then
            return l__return___127;
        end;
        l__return___127 = l__return___127.return_;
    end;
    error(l__Error__4.new("Expected to find a host parent. This error is likely caused by a bug in React. Please file an issue."));
end;
u16 = function(p121) --[[ Name: isHostParent, Line 1400 ]]
    -- upvalues: l__HostComponent__20 (copy), l__HostRoot__19 (copy), l__HostPortal__22 (copy)
    return (p121.tag == l__HostComponent__20 or p121.tag == l__HostRoot__19) and true or p121.tag == l__HostPortal__22;
end;
local function u124(p122) --[[ Line: 1404 ]]
    -- upvalues: u16 (ref), l__HostComponent__20 (copy), l__HostText__21 (copy), l__DehydratedFragment__25 (copy), l__Placement__42 (copy), l__HostPortal__22 (copy)
    while true do
        local v123 = false;
        while p122.sibling == nil do
            if p122.return_ == nil or u16(p122.return_) then
                return nil;
            end;
            p122 = p122.return_;
        end;
        p122.sibling.return_ = p122.return_;
        p122 = p122.sibling;
        while p122.tag ~= l__HostComponent__20 and (p122.tag ~= l__HostText__21 and p122.tag ~= l__DehydratedFragment__25) do
            if bit32.band(p122.flags, l__Placement__42) ~= 0 or (p122.child == nil or p122.tag == l__HostPortal__22) then
                v123 = true;
                break;
            end;
            p122.child.return_ = p122;
            p122 = p122.child;
        end;
        if not v123 and bit32.band(p122.flags, l__Placement__42) == 0 then
            return p122.stateNode;
        end;
    end;
end;
local function v131(p125) --[[ Line: 1458 ]]
    -- upvalues: l__supportsMutation__66 (copy), u120 (copy), l__HostComponent__20 (copy), l__HostRoot__19 (copy), l__HostPortal__22 (copy), l__invariant__50 (copy), l__ContentReset__41 (copy), l__resetTextContent__71 (copy), u124 (ref), u18 (ref), u17 (ref)
    if l__supportsMutation__66 then
        local v126 = u120(p125);
        local v127 = nil;
        local v128 = nil;
        local l__stateNode__128 = v126.stateNode;
        if v126.tag == l__HostComponent__20 then
            v127 = l__stateNode__128;
            v128 = false;
        elseif v126.tag == l__HostRoot__19 then
            v127 = l__stateNode__128.containerInfo;
            v128 = true;
        elseif v126.tag == l__HostPortal__22 then
            v127 = l__stateNode__128.containerInfo;
            v128 = true;
        else
            l__invariant__50(false, "Invalid host parent fiber. This error is likely caused by a bug in React. Please file an issue.");
        end;
        if bit32.band(v126.flags, l__ContentReset__41) ~= 0 then
            l__resetTextContent__71(v127);
            local l__flags__129 = v126.flags;
            local v129 = bit32.bnot(l__ContentReset__41);
            v126.flags = bit32.band(l__flags__129, v129);
        end;
        local v130 = u124(p125);
        if v128 then
            u18(p125, v130, v127);
        else
            u17(p125, v130, v127);
        end;
    end;
end;
u18 = function(p132, p133, p134) --[[ Name: insertOrAppendPlacementNodeIntoContainer, Line 1509 ]]
    -- upvalues: l__HostComponent__20 (copy), l__HostText__21 (copy), l__insertInContainerBefore__76 (copy), l__appendChildToContainer__74 (copy), l__HostPortal__22 (copy), u18 (ref)
    local l__tag__130 = p132.tag;
    if l__tag__130 == l__HostComponent__20 and true or l__tag__130 == l__HostText__21 then
        local l__stateNode__131 = p132.stateNode;
        if p133 then
            l__insertInContainerBefore__76(p134, l__stateNode__131, p133);
        else
            l__appendChildToContainer__74(p134, l__stateNode__131);
        end;
    elseif l__tag__130 == l__HostPortal__22 then
    else
        local l__child__132 = p132.child;
        if l__child__132 ~= nil then
            u18(l__child__132, p133, p134);
            local l__sibling__133 = l__child__132.sibling;
            while l__sibling__133 ~= nil do
                u18(l__sibling__133, p133, p134);
                l__sibling__133 = l__sibling__133.sibling;
            end;
        end;
    end;
end;
u17 = function(p135, p136, p137) --[[ Name: insertOrAppendPlacementNode, Line 1541 ]]
    -- upvalues: l__HostComponent__20 (copy), l__HostText__21 (copy), l__insertBefore__75 (copy), l__appendChild__73 (copy), l__HostPortal__22 (copy), u17 (ref)
    local l__tag__134 = p135.tag;
    if l__tag__134 == l__HostComponent__20 and true or l__tag__134 == l__HostText__21 then
        local l__stateNode__135 = p135.stateNode;
        if p136 then
            l__insertBefore__75(p137, l__stateNode__135, p136);
        else
            l__appendChild__73(p137, l__stateNode__135);
        end;
    elseif l__tag__134 == l__HostPortal__22 then
    else
        local l__child__136 = p135.child;
        if l__child__136 ~= nil then
            u17(l__child__136, p136, p137);
            local l__sibling__137 = l__child__136.sibling;
            while l__sibling__137 ~= nil do
                u17(l__sibling__137, p136, p137);
                l__sibling__137 = l__sibling__137.sibling;
            end;
        end;
    end;
end;
u22 = function(p138, p139, p140, p141) --[[ Name: unmountHostComponents, Line 1569 ]]
    -- upvalues: l__Error__4 (copy), l__HostComponent__20 (copy), l__HostRoot__19 (copy), l__HostPortal__22 (copy), l__HostText__21 (copy), u118 (ref), l__removeChildFromContainer__78 (copy), l__removeChild__77 (copy), u112 (ref)
    local v142 = p139;
    local v143 = false;
    local v144 = nil;
    local v145 = nil;
    while v143 do
        local v146 = 0;
        while true do
            if v146 == 0 then
                v146 = -1;
                if p139.tag == l__HostComponent__20 or p139.tag == l__HostText__21 then
                    u118(p138, p139, p140, p141);
                    if v144 then
                        l__removeChildFromContainer__78(v145, p139.stateNode);
                    else
                        l__removeChild__77(v145, p139.stateNode);
                    end;
                    if p139 == v142 then
                        return;
                    end;
                    while p139.sibling == nil do
                        if p139.return_ == nil or p139.return_ == v142 then
                            return;
                        end;
                        p139 = p139.return_;
                        if p139.tag == l__HostPortal__22 then
                            v143 = false;
                        end;
                    end;
                    p139.sibling.return_ = p139.return_;
                    p139 = p139.sibling;
                elseif p139.tag == l__HostPortal__22 then
                    if p139.child == nil then
                        goto l0;
                    end;
                    v145 = p139.stateNode.containerInfo;
                    p139.child.return_ = p139;
                    p139 = p139.child;
                    v144 = true;
                else
                    u112(p138, p139, p140, p141);
                    if p139.child == nil then
                        goto l0;
                    end;
                    p139.child.return_ = p139;
                    p139 = p139.child;
                end;
                break;
            else
                break;
            end;
        end;
    end;
    local l__return___138 = p139.return_;
    while true do
        if l__return___138 == nil then
            error(l__Error__4.new("Expected to find a host parent. This error is likely caused by a bug in React. Please file an issue."));
        end;
        v145 = l__return___138.stateNode;
        if l__return___138.tag == l__HostComponent__20 then
            v144 = false;
            break;
        end;
        if l__return___138.tag == l__HostRoot__19 then
            v145 = v145.containerInfo;
            v144 = true;
            break;
        end;
        if l__return___138.tag == l__HostPortal__22 then
            v145 = v145.containerInfo;
            v144 = true;
            break;
        end;
        l__return___138 = l__return___138.return_;
    end;
    v143 = true;
    goto l1;
end;
local function v151(p147, p148, p149, p150) --[[ Line: 1747 ]]
    -- upvalues: u22 (ref)
    u22(p147, p148, p149, p150);
    local l__alternate__139 = p148.alternate;
    local l__alternate__140 = p148.alternate;
    if l__alternate__140 ~= nil then
        l__alternate__140.return_ = nil;
        p148.alternate = nil;
    end;
    p148.return_ = nil;
    if l__alternate__139 ~= nil then
        local l__alternate__141 = l__alternate__139.alternate;
        if l__alternate__141 ~= nil then
            l__alternate__141.return_ = nil;
            l__alternate__139.alternate = nil;
        end;
        l__alternate__139.return_ = nil;
    end;
end;
function commitSuspenseComponent(p152)
    -- upvalues: u7 (ref), l__supportsMutation__66 (copy), u96 (copy), l__enableSuspenseCallback__13 (copy), l____DEV____1 (copy), l__console__3 (copy)
    local l__memoizedState__142 = p152.memoizedState;
    if l__memoizedState__142 ~= nil then
        if not u7 then
            u7 = require(script.Parent:WaitForChild("ReactFiberWorkLoop.new"));
        end;
        u7.markCommitTimeOfFallback();
        if l__supportsMutation__66 then
            u96(p152.child, true);
        end;
    end;
    if l__enableSuspenseCallback__13 and l__memoizedState__142 ~= nil then
        local l__suspenseCallback__143 = p152.memoizedProps.suspenseCallback;
        if typeof(l__suspenseCallback__143) == "function" then
            local l__updateQueue__144 = p152.updateQueue;
            if l__updateQueue__144 ~= nil then
                l__suspenseCallback__143(table.clone(l__updateQueue__144));
            end;
        elseif l____DEV____1 and l__suspenseCallback__143 ~= nil then
            l__console__3.error("Unexpected type for suspenseCallback: %s", (tostring(l__suspenseCallback__143)));
        end;
    end;
end;
function commitSuspenseHydrationCallbacks(p153, p154)
    -- upvalues: l__supportsHydration__68 (copy), l__commitHydratedSuspenseInstance__83 (copy), l__enableSuspenseCallback__13 (copy)
    if l__supportsHydration__68 then
        if p154.memoizedState == nil then
            local l__alternate__145 = p154.alternate;
            if l__alternate__145 ~= nil then
                local l__memoizedState__146 = l__alternate__145.memoizedState;
                if l__memoizedState__146 ~= nil then
                    local l__dehydrated__147 = l__memoizedState__146.dehydrated;
                    if l__dehydrated__147 ~= nil then
                        l__commitHydratedSuspenseInstance__83(l__dehydrated__147);
                        if l__enableSuspenseCallback__13 then
                            local l__hydrationCallbacks__148 = p153.hydrationCallbacks;
                            local v155 = l__hydrationCallbacks__148 ~= nil and l__hydrationCallbacks__148.onHydrated;
                            if v155 then
                                v155(l__dehydrated__147);
                            end;
                        end;
                    end;
                end;
            end;
        end;
    end;
end;
function attachSuspenseRetryListeners(u156)
    -- upvalues: l__Set__5 (copy), u10 (copy), l__enableSchedulerTracing__10 (copy), l__unstable_wrap__8 (copy)
    local l__updateQueue__149 = u156.updateQueue;
    if l__updateQueue__149 ~= nil then
        u156.updateQueue = nil;
        local l__stateNode__150 = u156.stateNode;
        if l__stateNode__150 == nil then
            u156.stateNode = l__Set__5.new();
            l__stateNode__150 = u156.stateNode;
        end;
        for u157, _ in l__updateQueue__149 do
            local function u158() --[[ Line: 2075 ]]
                -- upvalues: u10 (ref), u156 (copy), u157 (copy)
                return u10(u156, u157);
            end;
            if not l__stateNode__150:has(u157) then
                if l__enableSchedulerTracing__10 and u157.__reactDoNotTraceInteractions ~= true then
                    u158 = l__unstable_wrap__8(u158);
                end;
                l__stateNode__150:add(u157);
                u157:andThen(function() --[[ Line: 2086 ]]
                    -- upvalues: u158 (ref)
                    return u158();
                end, function() --[[ Line: 2088 ]]
                    -- upvalues: u158 (ref)
                    return u158();
                end);
            end;
        end;
    end;
end;
function isSuspenseBoundaryBeingHidden(p159, p160)
    if p159 ~= nil then
        local l__memoizedState__151 = p159.memoizedState;
        if l__memoizedState__151 == nil or l__memoizedState__151.dehydrated ~= nil then
            local l__memoizedState__152 = p160.memoizedState;
            local v161;
            if l__memoizedState__152 == nil then
                v161 = false;
            else
                v161 = l__memoizedState__152.dehydrated == nil;
            end;
            return v161;
        end;
    end;
    return false;
end;
function commitResetTextContent(p162)
    -- upvalues: l__supportsMutation__66 (copy), l__resetTextContent__71 (copy)
    if l__supportsMutation__66 then
        l__resetTextContent__71(p162.stateNode);
    end;
end;
function invokeLayoutEffectMountInDEV(p163)
    -- upvalues: l____DEV____1 (copy), l__enableDoubleInvokingEffects__14 (copy), l__FunctionComponent__16 (copy), l__ForwardRef__17 (copy), l__SimpleMemoComponent__28 (copy), l__Block__32 (copy), l__invokeGuardedCallback__36 (copy), u53 (copy), l__Layout__87 (copy), l__HasEffect__86 (copy), l__hasCaughtError__37 (copy), l__clearCaughtError__38 (copy), u13 (ref), l__ClassComponent__18 (copy)
    if l____DEV____1 and l__enableDoubleInvokingEffects__14 then
        if p163.tag == l__FunctionComponent__16 or (p163.tag == l__ForwardRef__17 or (p163.tag == l__SimpleMemoComponent__28 or p163.tag == l__Block__32)) then
            l__invokeGuardedCallback__36(nil, u53, nil, bit32.bor(l__Layout__87, l__HasEffect__86), p163);
            if l__hasCaughtError__37() then
                local v164 = l__clearCaughtError__38();
                u13(p163, p163.return_, v164);
            end;
        end;
    elseif p163.tag == l__ClassComponent__18 then
        local l__stateNode__153 = p163.stateNode;
        l__invokeGuardedCallback__36(nil, l__stateNode__153.componentDidMount, l__stateNode__153);
        if l__hasCaughtError__37() then
            local v165 = l__clearCaughtError__38();
            u13(p163, p163.return_, v165);
        end;
    end;
end;
function invokePassiveEffectMountInDEV(p166)
    -- upvalues: l____DEV____1 (copy), l__enableDoubleInvokingEffects__14 (copy), l__FunctionComponent__16 (copy), l__ForwardRef__17 (copy), l__SimpleMemoComponent__28 (copy), l__Block__32 (copy), l__invokeGuardedCallback__36 (copy), u53 (copy), l__Passive__88 (copy), l__HasEffect__86 (copy), l__hasCaughtError__37 (copy), l__clearCaughtError__38 (copy), u13 (ref)
    if l____DEV____1 and (l__enableDoubleInvokingEffects__14 and (p166.tag == l__FunctionComponent__16 or (p166.tag == l__ForwardRef__17 or (p166.tag == l__SimpleMemoComponent__28 or p166.tag == l__Block__32)))) then
        l__invokeGuardedCallback__36(nil, u53, nil, bit32.bor(l__Passive__88, l__HasEffect__86), p166);
        if l__hasCaughtError__37() then
            local v167 = l__clearCaughtError__38();
            u13(p166, p166.return_, v167);
        end;
    end;
end;
function invokeLayoutEffectUnmountInDEV(p168)
    -- upvalues: l____DEV____1 (copy), l__enableDoubleInvokingEffects__14 (copy), l__FunctionComponent__16 (copy), l__ForwardRef__17 (copy), l__SimpleMemoComponent__28 (copy), l__Block__32 (copy), l__invokeGuardedCallback__36 (copy), u47 (copy), l__Layout__87 (copy), l__HasEffect__86 (copy), l__hasCaughtError__37 (copy), l__clearCaughtError__38 (copy), u13 (ref), l__ClassComponent__18 (copy)
    if l____DEV____1 and l__enableDoubleInvokingEffects__14 then
        if p168.tag == l__FunctionComponent__16 or (p168.tag == l__ForwardRef__17 or (p168.tag == l__SimpleMemoComponent__28 or p168.tag == l__Block__32)) then
            l__invokeGuardedCallback__36(nil, u47, nil, bit32.bor(l__Layout__87, l__HasEffect__86), p168, p168.return_);
            if l__hasCaughtError__37() then
                local v169 = l__clearCaughtError__38();
                u13(p168, p168.return_, v169);
            end;
        end;
    elseif p168.tag == l__ClassComponent__18 then
        local l__stateNode__154 = p168.stateNode;
        if typeof(l__stateNode__154.componentWillUnmount) == "function" then
            safelyCallComponentWillUnmount(p168, l__stateNode__154, p168.return_);
        end;
    end;
end;
function invokePassiveEffectUnmountInDEV(p170)
    -- upvalues: l____DEV____1 (copy), l__enableDoubleInvokingEffects__14 (copy), l__FunctionComponent__16 (copy), l__ForwardRef__17 (copy), l__SimpleMemoComponent__28 (copy), l__Block__32 (copy), l__invokeGuardedCallback__36 (copy), u47 (copy), l__Passive__88 (copy), l__HasEffect__86 (copy), l__hasCaughtError__37 (copy), l__clearCaughtError__38 (copy), u13 (ref)
    if l____DEV____1 and (l__enableDoubleInvokingEffects__14 and (p170.tag == l__FunctionComponent__16 or (p170.tag == l__ForwardRef__17 or (p170.tag == l__SimpleMemoComponent__28 or p170.tag == l__Block__32)))) then
        l__invokeGuardedCallback__36(nil, u47, nil, bit32.bor(l__Passive__88, l__HasEffect__86), p170, p170.return_);
        if l__hasCaughtError__37() then
            local v171 = l__clearCaughtError__38();
            u13(p170, p170.return_, v171);
        end;
    end;
end;
return {
    safelyCallDestroy = v39,
    commitBeforeMutationLifeCycles = function(p172, p173) --[[ Name: commitBeforeMutationLifeCycles, Line 325 ]]
        -- upvalues: l__FunctionComponent__16 (copy), l__ForwardRef__17 (copy), l__SimpleMemoComponent__28 (copy), l__Block__32 (copy), l__ClassComponent__18 (copy), l__Snapshot__43 (copy), l____DEV____1 (copy), u15 (copy), l__console__3 (copy), l__getComponentName__49 (copy), l__resolveDefaultProps__57 (copy), l__HostRoot__19 (copy), l__supportsMutation__66 (copy), l__clearContainer__84 (copy), l__HostComponent__20 (copy), l__HostText__21 (copy), l__HostPortal__22 (copy), l__IncompleteClassComponent__26 (copy), l__invariant__50 (copy)
        if p173.tag == l__FunctionComponent__16 or (p173.tag == l__ForwardRef__17 or (p173.tag == l__SimpleMemoComponent__28 or p173.tag == l__Block__32)) then
        elseif p173.tag == l__ClassComponent__18 then
            if bit32.band(p173.flags, l__Snapshot__43) ~= 0 and p172 ~= nil then
                local l__memoizedProps__155 = p172.memoizedProps;
                local l__memoizedState__156 = p172.memoizedState;
                local l__stateNode__157 = p173.stateNode;
                if l____DEV____1 and (p173.type == p173.elementType and not u15) then
                    if l__stateNode__157.props ~= p173.memoizedProps then
                        l__console__3.error("Expected %s props to match memoized props before getSnapshotBeforeUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.", l__getComponentName__49(p173.type) or "instance");
                    end;
                    if l__stateNode__157.state ~= p173.memoizedState then
                        l__console__3.error("Expected %s state to match memoized state before getSnapshotBeforeUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.", l__getComponentName__49(p173.type) or "instance");
                    end;
                end;
                l__stateNode__157.__reactInternalSnapshotBeforeUpdate = l__stateNode__157:getSnapshotBeforeUpdate(p173.elementType == p173.type and l__memoizedProps__155 and l__memoizedProps__155 or l__resolveDefaultProps__57(p173.type, l__memoizedProps__155), l__memoizedState__156);
            end;
        elseif p173.tag == l__HostRoot__19 then
            if l__supportsMutation__66 and bit32.band(p173.flags, l__Snapshot__43) ~= 0 then
                l__clearContainer__84(p173.stateNode.containerInfo);
            end;
        elseif p173.tag == l__HostComponent__20 or (p173.tag == l__HostText__21 or (p173.tag == l__HostPortal__22 or p173.tag == l__IncompleteClassComponent__26)) then
        else
            l__invariant__50(false, "This unit of work tag should not have side-effects. This error is likely caused by a bug in React. Please file an issue.");
        end;
    end,
    commitResetTextContent = commitResetTextContent,
    commitPlacement = v131,
    commitDeletion = v151,
    commitWork = function(p174, u175) --[[ Name: commitWork, Line 1779 ]]
        -- upvalues: l__FunctionComponent__16 (copy), l__ForwardRef__17 (copy), l__MemoComponent__27 (copy), l__SimpleMemoComponent__28 (copy), l__Block__32 (copy), l__enableProfilerTimer__11 (copy), l__enableProfilerCommitHooks__12 (copy), l__ProfileMode__63 (copy), l__startLayoutEffectTimer__58 (copy), u47 (copy), l__Layout__87 (copy), l__HasEffect__86 (copy), l__describeError__51 (copy), l__recordLayoutEffectDuration__60 (copy), l__ClassComponent__18 (copy), l__HostComponent__20 (copy), l__commitUpdate__70 (copy), l__HostText__21 (copy), l__invariant__50 (copy), l__commitTextUpdate__72 (copy), l__HostRoot__19 (copy), l__supportsHydration__68 (copy), u2 (copy), l__Profiler__23 (copy), l__SuspenseComponent__24 (copy), l__SuspenseListComponent__29 (copy), l__IncompleteClassComponent__26 (copy), l__OffscreenComponent__33 (copy), l__LegacyHiddenComponent__34 (copy), u96 (copy)
        if u175.tag == l__FunctionComponent__16 or (u175.tag == l__ForwardRef__17 or (u175.tag == l__MemoComponent__27 or (u175.tag == l__SimpleMemoComponent__28 or u175.tag == l__Block__32))) then
            if l__enableProfilerTimer__11 and (l__enableProfilerCommitHooks__12 and bit32.band(u175.mode, l__ProfileMode__63) ~= 0) then
                local v176, v177 = xpcall(function() --[[ Line: 1868 ]]
                    -- upvalues: l__startLayoutEffectTimer__58 (ref), u47 (ref), l__Layout__87 (ref), l__HasEffect__86 (ref), u175 (copy)
                    l__startLayoutEffectTimer__58();
                    u47(bit32.bor(l__Layout__87, l__HasEffect__86), u175, u175.return_);
                end, l__describeError__51);
                l__recordLayoutEffectDuration__60(u175);
                if not v176 then
                    error(v177);
                end;
            else
                u47(bit32.bor(l__Layout__87, l__HasEffect__86), u175, u175.return_);
            end;
        elseif u175.tag == l__ClassComponent__18 then
        elseif u175.tag == l__HostComponent__20 then
            local l__stateNode__158 = u175.stateNode;
            if l__stateNode__158 ~= nil then
                local l__memoizedProps__159 = u175.memoizedProps;
                local v178;
                if p174 then
                    v178 = p174.memoizedProps;
                else
                    v178 = l__memoizedProps__159;
                end;
                local l__type__160 = u175.type;
                local l__updateQueue__161 = u175.updateQueue;
                u175.updateQueue = nil;
                if l__updateQueue__161 ~= nil then
                    l__commitUpdate__70(l__stateNode__158, l__updateQueue__161, l__type__160, v178, l__memoizedProps__159, u175);
                end;
            end;
        elseif u175.tag == l__HostText__21 then
            l__invariant__50(u175.stateNode ~= nil, "This should have a text node initialized. This error is likely caused by a bug in React. Please file an issue.");
            local l__stateNode__162 = u175.stateNode;
            local l__memoizedProps__163 = u175.memoizedProps;
            local v179;
            if p174 == nil then
                v179 = nil;
            else
                local _ = p174.memoizedProps;
                v179 = l__memoizedProps__163;
            end;
            l__commitTextUpdate__72(l__stateNode__162, v179, l__memoizedProps__163);
        elseif u175.tag == l__HostRoot__19 then
            if l__supportsHydration__68 then
                local l__stateNode__164 = u175.stateNode;
                if l__stateNode__164.hydrate then
                    l__stateNode__164.hydrate = false;
                    u2("commitWork: HostRoot: commitHydratedContainer");
                end;
            end;
        elseif u175.tag == l__Profiler__23 then
        elseif u175.tag == l__SuspenseComponent__24 then
            commitSuspenseComponent(u175);
            attachSuspenseRetryListeners(u175);
        else
            if u175.tag == l__SuspenseListComponent__29 then
                u2("commitWork: SuspenseListComponent");
            else
                if u175.tag == l__IncompleteClassComponent__26 then
                    return;
                end;
                if u175.tag == l__OffscreenComponent__33 or u175.tag == l__LegacyHiddenComponent__34 then
                    u96(u175, u175.memoizedState ~= nil);
                    return;
                end;
            end;
            l__invariant__50(false, "This unit of work tag should not have side-effects. This error is likely caused by a bug in React. Please file an issue.");
        end;
    end,
    commitAttachRef = commitAttachRef,
    commitDetachRef = commitDetachRef,
    commitPassiveUnmount = function(p180) --[[ Name: commitPassiveUnmount, Line 2118 ]]
        -- upvalues: l__FunctionComponent__16 (copy), l__ForwardRef__17 (copy), l__SimpleMemoComponent__28 (copy), l__Block__32 (copy), l__enableProfilerTimer__11 (copy), l__enableProfilerCommitHooks__12 (copy), l__ProfileMode__63 (copy), l__startPassiveEffectTimer__61 (copy), u47 (copy), l__Passive__88 (copy), l__HasEffect__86 (copy), l__recordPassiveEffectDuration__59 (copy)
        if p180.tag == l__FunctionComponent__16 or (p180.tag == l__ForwardRef__17 or (p180.tag == l__SimpleMemoComponent__28 or p180.tag == l__Block__32)) then
            if l__enableProfilerTimer__11 and (l__enableProfilerCommitHooks__12 and bit32.band(p180.mode, l__ProfileMode__63) ~= 0) then
                l__startPassiveEffectTimer__61();
                u47(bit32.bor(l__Passive__88, l__HasEffect__86), p180, p180.return_);
                l__recordPassiveEffectDuration__59(p180);
                return;
            end;
            u47(bit32.bor(l__Passive__88, l__HasEffect__86), p180, p180.return_);
        end;
    end,
    commitPassiveUnmountInsideDeletedTree = function(p181, p182) --[[ Name: commitPassiveUnmountInsideDeletedTree, Line 2147 ]]
        -- upvalues: l__FunctionComponent__16 (copy), l__ForwardRef__17 (copy), l__SimpleMemoComponent__28 (copy), l__Block__32 (copy), l__enableProfilerTimer__11 (copy), l__enableProfilerCommitHooks__12 (copy), l__ProfileMode__63 (copy), l__startPassiveEffectTimer__61 (copy), u47 (copy), l__Passive__88 (copy), l__recordPassiveEffectDuration__59 (copy)
        if p181.tag == l__FunctionComponent__16 or (p181.tag == l__ForwardRef__17 or (p181.tag == l__SimpleMemoComponent__28 or p181.tag == l__Block__32)) then
            if l__enableProfilerTimer__11 and (l__enableProfilerCommitHooks__12 and bit32.band(p181.mode, l__ProfileMode__63) ~= 0) then
                l__startPassiveEffectTimer__61();
                u47(l__Passive__88, p181, p182);
                l__recordPassiveEffectDuration__59(p181);
                return;
            end;
            u47(l__Passive__88, p181, p182);
        end;
    end,
    commitPassiveMount = function(p183, p184) --[[ Name: commitPassiveMount, Line 2171 ]]
        -- upvalues: l__FunctionComponent__16 (copy), l__ForwardRef__17 (copy), l__SimpleMemoComponent__28 (copy), l__Block__32 (copy), l__enableProfilerTimer__11 (copy), l__enableProfilerCommitHooks__12 (copy), l__ProfileMode__63 (copy), l__startPassiveEffectTimer__61 (copy), u53 (copy), l__describeError__51 (copy), l__Passive__88 (copy), l__HasEffect__86 (copy), l__recordPassiveEffectDuration__59 (copy), l__Profiler__23 (copy)
        if p184.tag == l__FunctionComponent__16 or (p184.tag == l__ForwardRef__17 or (p184.tag == l__SimpleMemoComponent__28 or p184.tag == l__Block__32)) then
            if not l__enableProfilerTimer__11 or (not l__enableProfilerCommitHooks__12 or bit32.band(p184.mode, l__ProfileMode__63) == 0) then
                u53(bit32.bor(l__Passive__88, l__HasEffect__86), p184);
                return;
            end;
            l__startPassiveEffectTimer__61();
            local v185, v186 = xpcall(u53, l__describeError__51, bit32.bor(l__Passive__88, l__HasEffect__86), p184);
            l__recordPassiveEffectDuration__59(p184);
            if not v185 then
                error(v186);
            end;
        elseif p184.tag == l__Profiler__23 then
            commitProfilerPassiveEffect(p183, p184);
        end;
    end,
    invokeLayoutEffectMountInDEV = invokeLayoutEffectMountInDEV,
    invokeLayoutEffectUnmountInDEV = invokeLayoutEffectUnmountInDEV,
    invokePassiveEffectMountInDEV = invokePassiveEffectMountInDEV,
    invokePassiveEffectUnmountInDEV = invokePassiveEffectUnmountInDEV,
    isSuspenseBoundaryBeingHidden = isSuspenseBoundaryBeingHidden,
    recursivelyCommitLayoutEffects = u75
};