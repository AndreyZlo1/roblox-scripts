-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberHydrationContext.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__console__1 = require(script.Parent.Parent:WaitForChild("shared")).console;
require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__ReactFiberHostConfig__2 = require(script.Parent:WaitForChild("ReactFiberHostConfig"));
require(script.Parent:WaitForChild("ReactFiberSuspenseComponent.new"));
local l__ReactWorkTags__3 = require(script.Parent:WaitForChild("ReactWorkTags"));
local l__HostComponent__4 = l__ReactWorkTags__3.HostComponent;
local l__HostText__5 = l__ReactWorkTags__3.HostText;
local l__HostRoot__6 = l__ReactWorkTags__3.HostRoot;
local l__SuspenseComponent__7 = l__ReactWorkTags__3.SuspenseComponent;
local l__ReactFiberFlags__8 = require(script.Parent:WaitForChild("ReactFiberFlags"));
local l__Placement__9 = l__ReactFiberFlags__8.Placement;
local l__Hydrating__10 = l__ReactFiberFlags__8.Hydrating;
local l__invariant__11 = require(script.Parent.Parent:WaitForChild("shared")).invariant;
local l__createFiberFromDehydratedFragment__12 = require(script.Parent:WaitForChild("ReactFiber.new")).createFiberFromDehydratedFragment;
local l__supportsHydration__13 = l__ReactFiberHostConfig__2.supportsHydration;
local l__getNextHydratableSibling__14 = l__ReactFiberHostConfig__2.getNextHydratableSibling;
local l__getFirstHydratableChild__15 = l__ReactFiberHostConfig__2.getFirstHydratableChild;
local l__canHydrateInstance__16 = l__ReactFiberHostConfig__2.canHydrateInstance;
local l__canHydrateTextInstance__17 = l__ReactFiberHostConfig__2.canHydrateTextInstance;
local l__canHydrateSuspenseInstance__18 = l__ReactFiberHostConfig__2.canHydrateSuspenseInstance;
local l__hydrateInstance__19 = l__ReactFiberHostConfig__2.hydrateInstance;
local l__hydrateTextInstance__20 = l__ReactFiberHostConfig__2.hydrateTextInstance;
local l__hydrateSuspenseInstance__21 = l__ReactFiberHostConfig__2.hydrateSuspenseInstance;
local l__getNextHydratableInstanceAfterSuspenseInstance__22 = l__ReactFiberHostConfig__2.getNextHydratableInstanceAfterSuspenseInstance;
local l__didNotMatchHydratedContainerTextInstance__23 = l__ReactFiberHostConfig__2.didNotMatchHydratedContainerTextInstance;
local l__didNotMatchHydratedTextInstance__24 = l__ReactFiberHostConfig__2.didNotMatchHydratedTextInstance;
local l__shouldSetTextContent__25 = l__ReactFiberHostConfig__2.shouldSetTextContent;
local l__enableSuspenseServerRenderer__26 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags.enableSuspenseServerRenderer;
local l__OffscreenLane__27 = require(script.Parent:WaitForChild("ReactFiberLane")).OffscreenLane;
local u1 = nil;
local u2 = nil;
local u3 = false;
function warnIfHydrating()
    -- upvalues: u3 (ref), l__console__1 (copy)
    if _G.__DEV__ and u3 then
        l__console__1.error("We should not be hydrating here. This is a bug in React. Please file a bug.");
    end;
end;
function enterHydrationState(p4)
    -- upvalues: l__supportsHydration__13 (copy), u2 (ref), l__getFirstHydratableChild__15 (copy), u1 (ref), u3 (ref)
    if not l__supportsHydration__13 then
        return false;
    end;
    u2 = l__getFirstHydratableChild__15(p4.stateNode.containerInfo);
    u1 = p4;
    u3 = true;
    return true;
end;
function reenterHydrationStateFromDehydratedSuspenseInstance(p5, p6)
    -- upvalues: l__supportsHydration__13 (copy), u2 (ref), l__getNextHydratableSibling__14 (copy), u3 (ref)
    if not l__supportsHydration__13 then
        return false;
    end;
    u2 = l__getNextHydratableSibling__14(p6);
    popToNextHostParent(p5);
    u3 = true;
    return true;
end;
function deleteHydratableInstance(_, _)
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("UNIMPLEMENTED ERROR: deleteHydratableInstance");
    error("FIXME (roblox): deleteHydratableInstance is unimplemented", 2);
end;
function insertNonHydratedInstance(_, p7)
    -- upvalues: l__Hydrating__10 (copy), l__Placement__9 (copy)
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("UNIMPLEMENTED ERROR: insertNonHydratedInstance");
    error("FIXME (roblox): insertNonHydratedInstance is unimplemented", 2);
    local l__flags__28 = p7.flags;
    local v8 = bit32.bnot(l__Hydrating__10);
    local v9 = bit32.band(l__flags__28, v8);
    p7.flags = bit32.bor(v9, l__Placement__9);
    local _ = _G.__DEV__;
end;
function tryHydrate(p10, p11)
    -- upvalues: l__HostComponent__4 (copy), l__canHydrateInstance__16 (copy), l__HostText__5 (copy), l__canHydrateTextInstance__17 (copy), l__SuspenseComponent__7 (copy), l__enableSuspenseServerRenderer__26 (copy), l__canHydrateSuspenseInstance__18 (copy), l__OffscreenLane__27 (copy), l__createFiberFromDehydratedFragment__12 (copy)
    if p10.tag == l__HostComponent__4 then
        local v12 = l__canHydrateInstance__16(p11, p10.type, p10.pendingProps);
        if v12 == nil then
            return false;
        end;
        p10.stateNode = v12;
        return true;
    end;
    if p10.tag ~= l__HostText__5 then
        if p10.tag ~= l__SuspenseComponent__7 then
            return false;
        end;
        if l__enableSuspenseServerRenderer__26 then
            local v13 = l__canHydrateSuspenseInstance__18(p11);
            if v13 ~= nil then
                p10.memoizedState = {
                    dehydrated = v13,
                    retryLane = l__OffscreenLane__27
                };
                local v14 = l__createFiberFromDehydratedFragment__12(v13);
                v14.return_ = p10;
                p10.child = v14;
                return true;
            end;
        end;
        return false;
    end;
    local v15 = l__canHydrateTextInstance__17(p11, p10.pendingProps);
    if v15 == nil then
        return false;
    end;
    p10.stateNode = v15;
    return true;
end;
function tryToClaimNextHydratableInstance(p16)
    -- upvalues: u3 (ref), u2 (ref), u1 (ref), l__getNextHydratableSibling__14 (copy), l__getFirstHydratableChild__15 (copy)
    if u3 then
        local v17 = u2;
        if v17 then
            local v18;
            if tryHydrate(p16, v17) then
                v18 = v17;
            else
                v18 = l__getNextHydratableSibling__14(v17);
                if not (v18 and tryHydrate(p16, v18)) then
                    insertNonHydratedInstance(u1, p16);
                    u3 = false;
                    u1 = p16;
                    return;
                end;
                deleteHydratableInstance(u1, v17);
            end;
            u1 = p16;
            u2 = l__getFirstHydratableChild__15(v18);
        else
            insertNonHydratedInstance(u1, p16);
            u3 = false;
            u1 = p16;
        end;
    end;
end;
function prepareToHydrateHostInstance(p19, p20, p21)
    -- upvalues: l__supportsHydration__13 (copy), l__invariant__11 (copy), l__hydrateInstance__19 (copy)
    if not l__supportsHydration__13 then
        l__invariant__11(false, "Expected prepareToHydrateHostInstance() to never be called. This error is likely caused by a bug in React. Please file an issue.");
    end;
    local v22 = l__hydrateInstance__19(p19.stateNode, p19.type, p19.memoizedProps, p20, p21, p19);
    p19.updateQueue = v22;
    return v22 ~= nil;
end;
function prepareToHydrateHostTextInstance(p23)
    -- upvalues: l__supportsHydration__13 (copy), l__invariant__11 (copy), l__hydrateTextInstance__20 (copy), u1 (ref), l__HostRoot__6 (copy), l__didNotMatchHydratedContainerTextInstance__23 (copy), l__HostComponent__4 (copy), l__didNotMatchHydratedTextInstance__24 (copy)
    if not l__supportsHydration__13 then
        l__invariant__11(false, "Expected prepareToHydrateHostTextInstance() to never be called. This error is likely caused by a bug in React. Please file an issue.");
    end;
    local l__stateNode__29 = p23.stateNode;
    local l__memoizedProps__30 = p23.memoizedProps;
    local v24 = l__hydrateTextInstance__20(l__stateNode__29, l__memoizedProps__30, p23);
    if _G.__DEV__ and v24 then
        local v25 = u1;
        if v25 ~= nil then
            if v25.tag == l__HostRoot__6 then
                l__didNotMatchHydratedContainerTextInstance__23(v25.stateNode.containerInfo, l__stateNode__29, l__memoizedProps__30);
                return v24;
            end;
            if v25.tag == l__HostComponent__4 then
                l__didNotMatchHydratedTextInstance__24(v25.type, v25.memoizedProps, v25.stateNode, l__stateNode__29, l__memoizedProps__30);
            end;
        end;
    end;
    return v24;
end;
function prepareToHydrateHostSuspenseInstance(p26)
    -- upvalues: l__supportsHydration__13 (copy), l__invariant__11 (copy), l__hydrateSuspenseInstance__21 (copy)
    if not l__supportsHydration__13 then
        l__invariant__11(false, "Expected prepareToHydrateHostSuspenseInstance() to never be called. This error is likely caused by a bug in React. Please file an issue.");
    end;
    local l__memoizedState__31 = p26.memoizedState;
    local v27;
    if l__memoizedState__31 == nil then
        v27 = nil;
    else
        v27 = l__memoizedState__31.dehydrated;
    end;
    l__invariant__11(v27, "Expected to have a hydrated suspense instance. This error is likely caused by a bug in React. Please file an issue.");
    l__hydrateSuspenseInstance__21(v27, p26);
end;
function skipPastDehydratedSuspenseInstance(p28)
    -- upvalues: l__supportsHydration__13 (copy), l__invariant__11 (copy), l__getNextHydratableInstanceAfterSuspenseInstance__22 (copy)
    if not l__supportsHydration__13 then
        l__invariant__11(false, "Expected skipPastDehydratedSuspenseInstance() to never be called. This error is likely caused by a bug in React. Please file an issue.");
    end;
    local l__memoizedState__32 = p28.memoizedState;
    local v29;
    if l__memoizedState__32 == nil then
        v29 = nil;
    else
        v29 = l__memoizedState__32.dehydrated;
    end;
    l__invariant__11(v29, "Expected to have a hydrated suspense instance. This error is likely caused by a bug in React. Please file an issue.");
    return l__getNextHydratableInstanceAfterSuspenseInstance__22(v29);
end;
function popToNextHostParent(p30)
    -- upvalues: l__HostComponent__4 (copy), l__HostRoot__6 (copy), l__SuspenseComponent__7 (copy), u1 (ref)
    local l__return___33 = p30.return_;
    while l__return___33 ~= nil and (l__return___33.tag ~= l__HostComponent__4 and (l__return___33.tag ~= l__HostRoot__6 and l__return___33.tag ~= l__SuspenseComponent__7)) do
        l__return___33 = l__return___33.return_;
    end;
    u1 = l__return___33;
end;
function popHydrationState(p31)
    -- upvalues: l__supportsHydration__13 (copy), u1 (ref), u3 (ref), l__HostComponent__4 (copy), l__shouldSetTextContent__25 (copy), u2 (ref), l__getNextHydratableSibling__14 (copy), l__SuspenseComponent__7 (copy)
    if not l__supportsHydration__13 then
        return false;
    end;
    if p31 ~= u1 then
        return false;
    end;
    if not u3 then
        popToNextHostParent(p31);
        u3 = true;
        return false;
    end;
    local l__type__34 = p31.type;
    if p31.tag ~= l__HostComponent__4 or l__type__34 ~= "head" and (l__type__34 ~= "body" and not l__shouldSetTextContent__25(l__type__34, p31.memoizedProps)) then
        local v32 = u2;
        while v32 do
            deleteHydratableInstance(p31, v32);
            v32 = l__getNextHydratableSibling__14(v32);
        end;
    end;
    popToNextHostParent(p31);
    if p31.tag == l__SuspenseComponent__7 then
        u2 = skipPastDehydratedSuspenseInstance(p31);
    elseif u1 then
        u2 = l__getNextHydratableSibling__14(p31.stateNode);
    else
        u2 = nil;
    end;
    return true;
end;
function resetHydrationState()
    -- upvalues: l__supportsHydration__13 (copy), u1 (ref), u2 (ref), u3 (ref)
    if l__supportsHydration__13 then
        u1 = nil;
        u2 = nil;
        u3 = false;
    end;
end;
function getIsHydrating()
    -- upvalues: u3 (ref)
    return u3;
end;
return {
    warnIfHydrating = warnIfHydrating,
    enterHydrationState = enterHydrationState,
    getIsHydrating = getIsHydrating,
    reenterHydrationStateFromDehydratedSuspenseInstance = reenterHydrationStateFromDehydratedSuspenseInstance,
    resetHydrationState = resetHydrationState,
    tryToClaimNextHydratableInstance = tryToClaimNextHydratableInstance,
    prepareToHydrateHostInstance = prepareToHydrateHostInstance,
    prepareToHydrateHostTextInstance = prepareToHydrateHostTextInstance,
    prepareToHydrateHostSuspenseInstance = prepareToHydrateHostSuspenseInstance,
    popHydrationState = popHydrationState
};