-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberHooks.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
local v1 = require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local l__Array__2 = v1.Array;
local l__Error__3 = v1.Error;
local l__Object__4 = v1.Object;
local l__createRef__5 = require(script.Parent.Parent:WaitForChild("react")).createRef;
local l__createBinding__6 = require(script.Parent.Parent:WaitForChild("react")).createBinding;
local l__console__7 = require(script.Parent.Parent:WaitForChild("shared")).console;
require(script.Parent.Parent:WaitForChild("shared"));
require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__ReactFiberLane__8 = require(script.Parent:WaitForChild("ReactFiberLane"));
local l__ReactHookEffectTags__9 = require(script.Parent:WaitForChild("ReactHookEffectTags"));
local l__ReactSharedInternals__10 = require(script.Parent.Parent:WaitForChild("shared")).ReactSharedInternals;
local l__ReactFeatureFlags__11 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags;
local l__enableDebugTracing__12 = l__ReactFeatureFlags__11.enableDebugTracing;
local l__enableSchedulingProfiler__13 = l__ReactFeatureFlags__11.enableSchedulingProfiler;
local l__enableNewReconciler__14 = l__ReactFeatureFlags__11.enableNewReconciler;
local l__enableDoubleInvokingEffects__15 = l__ReactFeatureFlags__11.enableDoubleInvokingEffects;
local l__DebugTracingMode__16 = require(script.Parent:WaitForChild("ReactTypeOfMode")).DebugTracingMode;
local l__NoLane__17 = l__ReactFiberLane__8.NoLane;
local l__NoLanes__18 = l__ReactFiberLane__8.NoLanes;
local l__isSubsetOfLanes__19 = l__ReactFiberLane__8.isSubsetOfLanes;
local l__mergeLanes__20 = l__ReactFiberLane__8.mergeLanes;
local l__removeLanes__21 = l__ReactFiberLane__8.removeLanes;
local l__markRootEntangled__22 = l__ReactFiberLane__8.markRootEntangled;
local l__markRootMutableRead__23 = l__ReactFiberLane__8.markRootMutableRead;
local l__readContext__24 = require(script.Parent:WaitForChild("ReactFiberNewContext.new")).readContext;
local l__ReactFiberFlags__25 = require(script.Parent:WaitForChild("ReactFiberFlags"));
local l__Update__26 = l__ReactFiberFlags__25.Update;
local l__Passive__27 = l__ReactFiberFlags__25.Passive;
local l__PassiveStatic__28 = l__ReactFiberFlags__25.PassiveStatic;
local l__MountLayoutDev__29 = l__ReactFiberFlags__25.MountLayoutDev;
local l__MountPassiveDev__30 = l__ReactFiberFlags__25.MountPassiveDev;
local l__HasEffect__31 = l__ReactHookEffectTags__9.HasEffect;
local l__Layout__32 = l__ReactHookEffectTags__9.Layout;
local l__Passive__33 = l__ReactHookEffectTags__9.Passive;
local v2 = require(script.Parent:WaitForChild("ReactFiberWorkLoop.new"));
local l__warnIfNotCurrentlyActingUpdatesInDEV__34 = v2.warnIfNotCurrentlyActingUpdatesInDEV;
local l__scheduleUpdateOnFiber__35 = v2.scheduleUpdateOnFiber;
local l__warnIfNotScopedWithMatchingAct__36 = v2.warnIfNotScopedWithMatchingAct;
local l__requestEventTime__37 = v2.requestEventTime;
local l__requestUpdateLane__38 = v2.requestUpdateLane;
local l__markSkippedUpdateLanes__39 = v2.markSkippedUpdateLanes;
local l__getWorkInProgressRoot__40 = v2.getWorkInProgressRoot;
local l__warnIfNotCurrentlyActingEffectsInDEV__41 = v2.warnIfNotCurrentlyActingEffectsInDEV;
local l__invariant__42 = require(script.Parent.Parent:WaitForChild("shared")).invariant;
local l__getComponentName__43 = require(script.Parent.Parent:WaitForChild("shared")).getComponentName;
local l__markWorkInProgressReceivedUpdate__44 = require(script.Parent:WaitForChild("ReactFiberBeginWork.new")).markWorkInProgressReceivedUpdate;
local l__getIsHydrating__45 = require(script.Parent:WaitForChild("ReactFiberHydrationContext.new")).getIsHydrating;
local l__makeClientId__46 = require(script.Parent:WaitForChild("ReactFiberHostConfig")).makeClientId;
local v3 = require(script.Parent:WaitForChild("ReactMutableSource.new"));
local l__warnAboutMultipleRenderersDEV__47 = v3.warnAboutMultipleRenderersDEV;
local l__getWorkInProgressVersion__48 = v3.getWorkInProgressVersion;
local l__setWorkInProgressVersion__49 = v3.setWorkInProgressVersion;
local l__markSourceAsDirty__50 = v3.markSourceAsDirty;
local l__logStateUpdateScheduled__51 = require(script.Parent:WaitForChild("DebugTracing")).logStateUpdateScheduled;
local l__markStateUpdateScheduled__52 = require(script.Parent:WaitForChild("SchedulingProfiler")).markStateUpdateScheduled;
local l__ReactCurrentDispatcher__53 = l__ReactSharedInternals__10.ReactCurrentDispatcher;
local u4 = l____DEV____1 and {} or nil;
local u5 = {};
local u6 = l__NoLanes__18;
local u7 = nil;
local u8 = nil;
local u9 = nil;
local u10 = false;
local u11 = false;
local u12 = nil;
local u13 = nil;
local u14 = 0;
local u15 = nil;
local u16 = nil;
local u17 = nil;
local u18 = nil;
local u19 = nil;
local u20 = nil;
local u21 = nil;
function updateHookTypesDev()
    -- upvalues: l____DEV____1 (copy), u12 (ref), u13 (ref), u14 (ref)
    if l____DEV____1 then
        local v22 = u12;
        if u13 ~= nil then
            u14 = u14 + 1;
            if u13[u14] ~= v22 then
                warnOnHookMismatchInDev(v22);
            end;
        end;
    end;
end;
function warnOnHookMismatchInDev(p23)
    -- upvalues: l____DEV____1 (copy), l__getComponentName__43 (copy), u7 (ref), u4 (ref), u13 (ref), u14 (ref), l__console__7 (copy)
    if l____DEV____1 then
        local v24 = l__getComponentName__43(u7.type) or "Component";
        if not u4[v24] then
            u4[v24] = true;
            if u13 ~= nil then
                local v25 = "";
                for v26 = 1, u14 do
                    local v27 = u13[v26];
                    local v28;
                    if v26 == u14 then
                        v28 = p23;
                    else
                        v28 = v27;
                    end;
                    local v29 = tostring(v26) .. ". " .. (v27 or "undefined");
                    while string.len(v29) < 30 do
                        v29 = v29 .. " ";
                    end;
                    v25 = v25 .. v29 .. v28 .. "\n";
                end;
                l__console__7.error("React has detected a change in the order of Hooks called by %s. This will lead to bugs and errors if not fixed. For more information, read the Rules of Hooks: https://reactjs.org/link/rules-of-hooks\n\n   Previous render            Next render\n   ------------------------------------------------------\n%s   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n", v24, v25);
            end;
        end;
    end;
end;
local function v30() --[[ Line: 372 ]]
    -- upvalues: l__Error__3 (copy)
    error(l__Error__3.new("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem."));
end;
local function u41(p31, p32) --[[ Line: 387 ]]
    -- upvalues: l____DEV____1 (copy), l__console__7 (copy), u12 (ref)
    if p32 == nil then
        if l____DEV____1 then
            l__console__7.error("%s received a final argument during this render, but not during the previous render. Even though the final argument is optional, its type cannot change between renders.", u12);
        end;
        return false;
    end;
    local v33 = 0;
    for v34, _ in p31 do
        if v33 < v34 then
            v33 = v34;
        end;
    end;
    local v35 = 0;
    for v36, _ in p32 do
        if v35 < v36 then
            v35 = v36;
        end;
    end;
    if v33 ~= v35 then
        return false;
    end;
    for v37 = 1, math.min(v35, v33) do
        local v38 = p31[v37];
        local v39 = p32[v37];
        local v40;
        if v38 == v39 and (v38 ~= 0 or 1 / v38 == 1 / v39) then
            v40 = true;
        elseif v38 == v38 then
            v40 = false;
        else
            v40 = v39 ~= v39;
        end;
        if not v40 then
            return false;
        end;
    end;
    return true;
end;
function u5.bailoutHooks(p42, p43, p44) --[[ Line: 451 ]]
    -- upvalues: l____DEV____1 (copy), l__enableDoubleInvokingEffects__15 (copy), l__MountPassiveDev__30 (copy), l__Passive__27 (copy), l__MountLayoutDev__29 (copy), l__Update__26 (copy), l__removeLanes__21 (copy)
    p43.updateQueue = p42.updateQueue;
    if l____DEV____1 and l__enableDoubleInvokingEffects__15 then
        local l__flags__54 = p43.flags;
        local v45 = bit32.bor(l__MountPassiveDev__30, l__Passive__27, l__MountLayoutDev__29, l__Update__26);
        local v46 = bit32.bnot(v45);
        p43.flags = bit32.band(l__flags__54, v46);
    else
        local l__flags__55 = p43.flags;
        local v47 = bit32.bor(l__Passive__27, l__Update__26);
        local v48 = bit32.bnot(v47);
        p43.flags = bit32.band(l__flags__55, v48);
    end;
    p42.lanes = l__removeLanes__21(p42.lanes, p44);
end;
local u49 = false;
function u5.resetHooksAfterThrow() --[[ Line: 476 ]]
    -- upvalues: l__ReactCurrentDispatcher__53 (copy), u5 (copy), u10 (ref), u7 (ref), u6 (ref), l__NoLanes__18 (copy), u8 (ref), u9 (ref), l____DEV____1 (copy), u13 (ref), u14 (ref), u12 (ref), u49 (ref), u11 (ref)
    l__ReactCurrentDispatcher__53.current = u5.ContextOnlyDispatcher;
    if u10 then
        local l__memoizedState__56 = u7.memoizedState;
        while l__memoizedState__56 ~= nil do
            local l__queue__57 = l__memoizedState__56.queue;
            if l__queue__57 ~= nil then
                l__queue__57.pending = nil;
            end;
            l__memoizedState__56 = l__memoizedState__56.next;
        end;
        u10 = false;
    end;
    u6 = l__NoLanes__18;
    u7 = nil;
    u8 = nil;
    u9 = nil;
    if l____DEV____1 then
        u13 = nil;
        u14 = 0;
        u12 = nil;
        u49 = false;
    end;
    u11 = false;
end;
local function u53() --[[ Line: 544 ]]
    -- upvalues: u8 (ref), u7 (ref), u9 (ref), l__Error__3 (copy)
    local v50;
    if u8 == nil then
        local l__alternate__58 = u7.alternate;
        if l__alternate__58 == nil then
            v50 = nil;
        else
            v50 = l__alternate__58.memoizedState;
        end;
    else
        v50 = u8.next;
    end;
    local v51;
    if u9 == nil then
        v51 = u7.memoizedState;
    else
        v51 = u9.next;
    end;
    if v51 == nil then
        if v50 == nil then
            error(l__Error__3.new("Rendered more hooks than during the previous render."));
        end;
        u8 = v50;
        local v52 = {
            next = nil,
            memoizedState = u8.memoizedState,
            baseState = u8.baseState,
            baseQueue = u8.baseQueue,
            queue = u8.queue
        };
        if u9 == nil then
            u9 = v52;
            u7.memoizedState = v52;
        else
            u9.next = v52;
            u9 = v52;
        end;
    else
        u9 = v51;
        local _ = u9.next;
        u8 = v50;
    end;
    return u9;
end;
function basicStateReducer(p54, p55)
    if type(p55) == "function" then
        return p55(p54);
    else
        return p55;
    end;
end;
function mountReducer(p56, p57, p58)
    -- upvalues: u9 (ref), u7 (ref)
    local v59 = {
        memoizedState = nil,
        baseState = nil,
        baseQueue = nil,
        queue = nil,
        next = nil
    };
    if u9 == nil then
        u7.memoizedState = v59;
        u9 = v59;
    else
        u9.next = v59;
        u9 = v59;
    end;
    local v60 = u9;
    if p58 ~= nil then
        p57 = p58(p57);
    end;
    v60.baseState = p57;
    v60.memoizedState = v60.baseState;
    local u61 = {
        pending = nil,
        dispatch = nil,
        lastRenderedReducer = p56,
        lastRenderedState = p57
    };
    v60.queue = u61;
    local u62 = u7;
    local function v64(p63, ...) --[[ Line: 655 ]]
        -- upvalues: u62 (copy), u61 (copy)
        dispatchAction(u62, u61, p63, ...);
    end;
    u61.dispatch = v64;
    return v60.memoizedState, v64;
end;
function updateReducer(p65, _, _)
    -- upvalues: u53 (copy), u8 (ref), u6 (ref), u7 (ref), l__mergeLanes__20 (copy), l__markSkippedUpdateLanes__39 (copy), l__NoLane__17 (copy), l__markWorkInProgressReceivedUpdate__44 (copy)
    local v66 = u53();
    local l__queue__59 = v66.queue;
    assert(l__queue__59 ~= nil, "Should have a queue. This is likely a bug in React. Please file an issue.");
    l__queue__59.lastRenderedReducer = p65;
    local v67 = u8;
    local l__baseQueue__60 = v67.baseQueue;
    local l__pending__61 = l__queue__59.pending;
    if l__pending__61 == nil then
        l__pending__61 = l__baseQueue__60;
    else
        if l__baseQueue__60 ~= nil then
            local l__next__62 = l__baseQueue__60.next;
            l__baseQueue__60.next = l__pending__61.next;
            l__pending__61.next = l__next__62;
        end;
        v67.baseQueue = l__pending__61;
        l__queue__59.pending = nil;
    end;
    if l__pending__61 == nil then
        return v66.memoizedState, l__queue__59.dispatch;
    else
        local l__next__63 = l__pending__61.next;
        local l__baseState__64 = v67.baseState;
        local v68 = l__next__63;
        local v69 = nil;
        local v70 = nil;
        local v71 = nil;
        while true do
            if true then
                local l__lane__65 = l__next__63.lane;
                if bit32.band(u6, l__lane__65) == l__lane__65 then
                    if v69 ~= nil then
                        v69.next = {
                            next = nil,
                            lane = l__NoLane__17,
                            action = l__next__63.action,
                            eagerReducer = l__next__63.eagerReducer,
                            eagerState = l__next__63.eagerState
                        };
                        v69 = v69.next;
                    end;
                    if l__next__63.eagerReducer == p65 then
                        l__baseState__64 = l__next__63.eagerState;
                    else
                        l__baseState__64 = p65(l__baseState__64, l__next__63.action);
                    end;
                else
                    local v72 = {
                        next = nil,
                        lane = l__lane__65,
                        action = l__next__63.action,
                        eagerReducer = l__next__63.eagerReducer,
                        eagerState = l__next__63.eagerState
                    };
                    if v69 == nil then
                        v70 = v72;
                        v69 = v70;
                        v71 = l__baseState__64;
                        local v73 = v70;
                        v70 = v69;
                        v73 = v69;
                        v69 = v70;
                    else
                        v69.next = v72;
                        v69 = v69.next;
                    end;
                    u7.lanes = l__mergeLanes__20(u7.lanes, l__lane__65);
                    l__markSkippedUpdateLanes__39(l__lane__65);
                end;
            end;
            l__next__63 = l__next__63.next;
            if l__next__63 == nil or l__next__63 == v68 then
                if v69 == nil then
                    v71 = l__baseState__64;
                else
                    v69.next = v70;
                end;
                local l__memoizedState__66 = v66.memoizedState;
                local v74;
                if l__baseState__64 == l__memoizedState__66 and (l__baseState__64 ~= 0 or 1 / l__baseState__64 == 1 / l__memoizedState__66) then
                    v74 = true;
                elseif l__baseState__64 == l__baseState__64 then
                    v74 = false;
                else
                    v74 = l__memoizedState__66 ~= l__memoizedState__66;
                end;
                if not v74 then
                    l__markWorkInProgressReceivedUpdate__44();
                end;
                v66.memoizedState = l__baseState__64;
                v66.baseState = v71;
                v66.baseQueue = v69;
                l__queue__59.lastRenderedState = l__baseState__64;
                return v66.memoizedState, l__queue__59.dispatch;
            end;
        end;
    end;
end;
function rerenderReducer(p75, _, _)
    -- upvalues: u53 (copy), l__markWorkInProgressReceivedUpdate__44 (copy)
    local v76 = u53();
    local l__queue__67 = v76.queue;
    assert(l__queue__67 ~= nil, "Should have a queue. This is likely a bug in React. Please file an issue.");
    l__queue__67.lastRenderedReducer = p75;
    local l__dispatch__68 = l__queue__67.dispatch;
    local l__pending__69 = l__queue__67.pending;
    local l__memoizedState__70 = v76.memoizedState;
    if l__pending__69 ~= nil then
        l__queue__67.pending = nil;
        local l__next__71 = l__pending__69.next;
        local v77 = l__next__71;
        repeat
            l__memoizedState__70 = p75(l__memoizedState__70, l__next__71.action);
            l__next__71 = l__next__71.next;
        until l__next__71 == v77;
        local l__memoizedState__72 = v76.memoizedState;
        local v78;
        if l__memoizedState__70 == l__memoizedState__72 and (l__memoizedState__70 ~= 0 or 1 / l__memoizedState__70 == 1 / l__memoizedState__72) then
            v78 = true;
        elseif l__memoizedState__70 == l__memoizedState__70 then
            v78 = false;
        else
            v78 = l__memoizedState__72 ~= l__memoizedState__72;
        end;
        if not v78 then
            l__markWorkInProgressReceivedUpdate__44();
        end;
        v76.memoizedState = l__memoizedState__70;
        if v76.baseQueue == nil then
            v76.baseState = l__memoizedState__70;
        end;
        l__queue__67.lastRenderedState = l__memoizedState__70;
    end;
    return l__memoizedState__70, l__dispatch__68;
end;
function readFromUnsubcribedMutableSource(p79, p80, p81)
    -- upvalues: l____DEV____1 (copy), l__warnAboutMultipleRenderersDEV__47 (copy), l__getWorkInProgressVersion__48 (copy), l__isSubsetOfLanes__19 (copy), u6 (ref), l__setWorkInProgressVersion__49 (copy), l__console__7 (copy), l__markSourceAsDirty__50 (copy), l__Error__3 (copy)
    if l____DEV____1 then
        l__warnAboutMultipleRenderersDEV__47(p80);
    end;
    local v82 = p80._getVersion(p80._source);
    local v83 = l__getWorkInProgressVersion__48(p80);
    local v84;
    if v83 == nil then
        v84 = l__isSubsetOfLanes__19(u6, p79.mutableReadLanes);
        if v84 then
            l__setWorkInProgressVersion__49(p80, v82);
        end;
    else
        v84 = v83 == v82;
    end;
    if v84 then
        local v85 = p81(p80._source);
        if l____DEV____1 and type(v85) == "function" then
            l__console__7.error("Mutable source should not return a function as the snapshot value. Functions may close over mutable values and cause tearing.");
        end;
        return v85;
    end;
    l__markSourceAsDirty__50(p80);
    error(l__Error__3.new("Cannot read from mutable source during the current render without tearing. This is a bug in React. Please file an issue."));
end;
function useMutableSource(p86, u87, u88, u89)
    -- upvalues: l__getWorkInProgressRoot__40 (copy), l__invariant__42 (copy), l__ReactCurrentDispatcher__53 (copy), u9 (ref), u7 (ref), l____DEV____1 (copy), l__console__7 (copy), l__requestUpdateLane__38 (copy), l__markRootMutableRead__23 (copy), l__markRootEntangled__22 (copy)
    local u90 = l__getWorkInProgressRoot__40();
    l__invariant__42(u90 ~= nil, "Expected a work-in-progress root. This is a bug in React. Please file an issue.");
    local l___getVersion__73 = u87._getVersion;
    local u91 = l___getVersion__73(u87._source);
    local l__current__74 = l__ReactCurrentDispatcher__53.current;
    assert(l__current__74 ~= nil, "dispatcher was nil, this is a bug in React");
    local v92, u93 = l__current__74.useState(function() --[[ Line: 979 ]]
        -- upvalues: u90 (copy), u87 (copy), u88 (copy)
        return readFromUnsubcribedMutableSource(u90, u87, u88);
    end);
    local u94 = v92;
    local v95 = u9;
    local l__memoizedState__75 = p86.memoizedState;
    if l__memoizedState__75.refs == nil then
        error((tostring(debug.traceback())));
    end;
    local l__refs__76 = l__memoizedState__75.refs;
    local l__getSnapshot__77 = l__refs__76.getSnapshot;
    local l__source__78 = l__memoizedState__75.source;
    local l__subscribe__79 = l__memoizedState__75.subscribe;
    local u96 = u7;
    p86.memoizedState = {
        refs = l__refs__76,
        source = u87,
        subscribe = u89
    };
    l__current__74.useEffect(function() --[[ Line: 1008 ]]
        -- upvalues: l__refs__76 (copy), u88 (copy), u93 (ref), l___getVersion__73 (copy), u87 (copy), u91 (copy), l____DEV____1 (ref), l__console__7 (ref), u94 (ref), l__requestUpdateLane__38 (ref), u96 (copy), l__markRootMutableRead__23 (ref), u90 (copy), l__markRootEntangled__22 (ref)
        l__refs__76.getSnapshot = u88;
        l__refs__76.setSnapshot = u93;
        local v97 = l___getVersion__73(u87._source);
        local v98 = u91;
        local v99;
        if v98 == v97 and (v98 ~= 0 or 1 / v98 == 1 / v97) then
            v99 = true;
        elseif v98 == v98 then
            v99 = false;
        else
            v99 = v97 ~= v97;
        end;
        if not v99 then
            local v100 = u88(u87._source);
            if l____DEV____1 and type(v100) == "function" then
                l__console__7.error("Mutable source should not return a function as the snapshot value. Functions may close over mutable values and cause tearing.");
            end;
            local v101 = u94;
            local v102;
            if v101 == v100 and (v101 ~= 0 or 1 / v101 == 1 / v100) then
                v102 = true;
            elseif v101 == v101 then
                v102 = false;
            else
                v102 = v100 ~= v100;
            end;
            if not v102 then
                u93(v100);
                l__markRootMutableRead__23(u90, (l__requestUpdateLane__38(u96)));
            end;
            l__markRootEntangled__22(u90, u90.mutableReadLanes);
        end;
    end, { u88, u87, u89 });
    l__current__74.useEffect(function() --[[ Line: 1046 ]]
        -- upvalues: l__refs__76 (copy), u87 (copy), l__requestUpdateLane__38 (ref), u96 (copy), l__markRootMutableRead__23 (ref), u90 (copy), u89 (copy), l____DEV____1 (ref), l__console__7 (ref)
        local v105 = u89(u87._source, function() --[[ Line: 1047 ]]
            -- upvalues: l__refs__76 (ref), u87 (ref), l__requestUpdateLane__38 (ref), u96 (ref), l__markRootMutableRead__23 (ref), u90 (ref)
            local l__getSnapshot__80 = l__refs__76.getSnapshot;
            local l__setSnapshot__81 = l__refs__76.setSnapshot;
            local v103, u104 = pcall(function() --[[ Line: 1052 ]]
                -- upvalues: l__setSnapshot__81 (copy), l__getSnapshot__80 (copy), u87 (ref), l__requestUpdateLane__38 (ref), u96 (ref), l__markRootMutableRead__23 (ref), u90 (ref)
                l__setSnapshot__81(l__getSnapshot__80(u87._source));
                l__markRootMutableRead__23(u90, (l__requestUpdateLane__38(u96)));
            end);
            if not v103 then
                l__setSnapshot__81(function() --[[ Line: 1066 ]]
                    -- upvalues: u104 (copy)
                    error(u104);
                end);
            end;
        end);
        if l____DEV____1 and type(v105) ~= "function" then
            l__console__7.error("Mutable source subscribe function must return an unsubscribe function.");
        end;
        return v105;
    end, { u87, u89 });
    local v106;
    if l__getSnapshot__77 == u88 and (l__getSnapshot__77 ~= 0 or 1 / l__getSnapshot__77 == 1 / u88) then
        v106 = true;
    elseif l__getSnapshot__77 == l__getSnapshot__77 then
        v106 = false;
    else
        v106 = u88 ~= u88;
    end;
    if v106 then
        local v107;
        if l__source__78 == u87 and (l__source__78 ~= 0 or 1 / l__source__78 == 1 / u87) then
            v107 = true;
        elseif l__source__78 == l__source__78 then
            v107 = false;
        else
            v107 = u87 ~= u87;
        end;
        if v107 then
            local v108;
            if l__subscribe__79 == u89 and (l__subscribe__79 ~= 0 or 1 / l__subscribe__79 == 1 / u89) then
                v108 = true;
            elseif l__subscribe__79 == l__subscribe__79 then
                v108 = false;
            else
                v108 = u89 ~= u89;
            end;
            if v108 then
                return u94;
            end;
        end;
    end;
    local u109 = {
        pending = nil,
        dispatch = nil,
        lastRenderedReducer = basicStateReducer,
        lastRenderedState = u94
    };
    local u110 = u7;
    local function v111(...) --[[ Line: 1115 ]]
        -- upvalues: u110 (copy), u109 (copy)
        dispatchAction(u110, u109, ...);
    end;
    u109.dispatch = v111;
    v95.queue = u109;
    v95.baseQueue = nil;
    local v112 = readFromUnsubcribedMutableSource(u90, u87, u88);
    v95.baseState = v112;
    v95.memoizedState = v95.baseState;
    u94 = v112;
    return u94;
end;
function mountMutableSource(p113, p114, p115)
    -- upvalues: u9 (ref), u7 (ref)
    local v116 = {
        memoizedState = nil,
        baseState = nil,
        baseQueue = nil,
        queue = nil,
        next = nil
    };
    if u9 == nil then
        u7.memoizedState = v116;
        u9 = v116;
    else
        u9.next = v116;
        u9 = v116;
    end;
    local v117 = u9;
    v117.memoizedState = {
        refs = {
            setSnapshot = nil,
            getSnapshot = p114
        },
        source = p113,
        subscribe = p115
    };
    return useMutableSource(v117, p113, p114, p115);
end;
function updateMutableSource(p118, p119, p120)
    -- upvalues: u53 (copy)
    local v121 = u53();
    return useMutableSource(v121, p118, p119, p120);
end;
function mountState(p122)
    -- upvalues: u9 (ref), u7 (ref)
    local v123 = {
        memoizedState = nil,
        baseState = nil,
        baseQueue = nil,
        queue = nil,
        next = nil
    };
    if u9 == nil then
        u7.memoizedState = v123;
        u9 = v123;
    else
        u9.next = v123;
        u9 = v123;
    end;
    local v124 = u9;
    if type(p122) == "function" then
        p122 = p122();
    end;
    v124.baseState = p122;
    v124.memoizedState = v124.baseState;
    local u125 = {
        pending = nil,
        dispatch = nil,
        lastRenderedReducer = nil,
        lastRenderedState = p122,
        lastRenderedReducer = basicStateReducer
    };
    v124.queue = u125;
    local u126 = u7;
    local function v128(p127, ...) --[[ Line: 1189 ]]
        -- upvalues: u126 (copy), u125 (copy)
        dispatchAction(u126, u125, p127, ...);
    end;
    u125.dispatch = v128;
    return v124.memoizedState, v128;
end;
function updateState(p129)
    return updateReducer(basicStateReducer, p129);
end;
function rerenderState(p130)
    return rerenderReducer(basicStateReducer, p130);
end;
local function u137(p131, p132, p133, p134) --[[ Line: 1206 ]]
    -- upvalues: u7 (ref)
    local v135 = {
        next = nil,
        tag = p131,
        create = p132,
        destroy = p133,
        deps = p134
    };
    local l__updateQueue__82 = u7.updateQueue;
    if l__updateQueue__82 == nil then
        local v136 = {
            lastEffect = nil
        };
        u7.updateQueue = v136;
        v135.next = v135;
        v136.lastEffect = v135;
        return v135;
    end;
    local l__lastEffect__83 = l__updateQueue__82.lastEffect;
    if l__lastEffect__83 == nil then
        l__updateQueue__82.lastEffect = v135;
        v135.next = v135;
        return v135;
    end;
    local l__next__84 = l__lastEffect__83.next;
    l__lastEffect__83.next = v135;
    v135.next = l__next__84;
    l__updateQueue__82.lastEffect = v135;
    return v135;
end;
function mountBinding(p138)
    -- upvalues: u9 (ref), u7 (ref), l__createBinding__6 (copy)
    local v139 = {
        memoizedState = nil,
        baseState = nil,
        baseQueue = nil,
        queue = nil,
        next = nil
    };
    if u9 == nil then
        u7.memoizedState = v139;
        u9 = v139;
    else
        u9.next = v139;
        u9 = v139;
    end;
    local v140 = u9;
    local v141, v142 = l__createBinding__6(p138);
    v140.memoizedState = { v141, v142 };
    return v141, v142;
end;
function updateBinding(_)
    -- upvalues: u53 (copy)
    local l__memoizedState__85 = u53().memoizedState;
    return unpack(l__memoizedState__85);
end;
function mountRef(p143)
    -- upvalues: u9 (ref), u7 (ref), l__createRef__5 (copy)
    local v144 = {
        memoizedState = nil,
        baseState = nil,
        baseQueue = nil,
        queue = nil,
        next = nil
    };
    if u9 == nil then
        u7.memoizedState = v144;
        u9 = v144;
    else
        u9.next = v144;
        u9 = v144;
    end;
    local v145 = u9;
    local v146 = l__createRef__5();
    v146.current = p143;
    v145.memoizedState = v146;
    return v146;
end;
function updateRef(_)
    -- upvalues: u53 (copy)
    return u53().memoizedState;
end;
local function u153(p147, p148, p149, p150) --[[ Line: 1276 ]]
    -- upvalues: u9 (ref), u7 (ref), u137 (copy), l__HasEffect__31 (copy)
    local v151 = {
        memoizedState = nil,
        baseState = nil,
        baseQueue = nil,
        queue = nil,
        next = nil
    };
    if u9 == nil then
        u7.memoizedState = v151;
        u9 = v151;
    else
        u9.next = v151;
        u9 = v151;
    end;
    local v152 = u9;
    u7.flags = bit32.bor(u7.flags, p147);
    v152.memoizedState = u137(bit32.bor(l__HasEffect__31, p148), p149, nil, p150);
end;
function updateEffectImpl(p154, p155, p156, p157)
    -- upvalues: u53 (copy), u8 (ref), u41 (copy), u137 (copy), u7 (ref), l__HasEffect__31 (copy)
    local v158 = u53();
    local v159;
    if u8 == nil then
        v159 = nil;
    else
        local l__memoizedState__86 = u8.memoizedState;
        v159 = l__memoizedState__86.destroy;
        if p157 ~= nil and u41(p157, l__memoizedState__86.deps) then
            v158.memoizedState = u137(p155, p156, v159, p157);
            return;
        end;
    end;
    u7.flags = bit32.bor(u7.flags, p154);
    v158.memoizedState = u137(bit32.bor(l__HasEffect__31, p155), p156, v159, p157);
end;
local function u170(p160, p161) --[[ Line: 1314 ]]
    -- upvalues: l____DEV____1 (copy), l__warnIfNotCurrentlyActingEffectsInDEV__41 (copy), u7 (ref), l__enableDoubleInvokingEffects__15 (copy), l__MountPassiveDev__30 (copy), l__Passive__27 (copy), l__PassiveStatic__28 (copy), l__Passive__33 (copy), u9 (ref), u137 (copy), l__HasEffect__31 (copy)
    if l____DEV____1 and (type(_G.jest) ~= "nil" or _G.__TESTEZ_RUNNING_TEST__) then
        l__warnIfNotCurrentlyActingEffectsInDEV__41(u7);
    end;
    if l____DEV____1 and l__enableDoubleInvokingEffects__15 then
        local v162 = bit32.bor(l__MountPassiveDev__30, l__Passive__27, l__PassiveStatic__28);
        local v163 = l__Passive__33;
        local v164 = {
            memoizedState = nil,
            baseState = nil,
            baseQueue = nil,
            queue = nil,
            next = nil
        };
        if u9 == nil then
            u7.memoizedState = v164;
            u9 = v164;
        else
            u9.next = v164;
            u9 = v164;
        end;
        local v165 = u9;
        u7.flags = bit32.bor(u7.flags, v162);
        v165.memoizedState = u137(bit32.bor(l__HasEffect__31, v163), p160, nil, p161);
    else
        local v166 = bit32.bor(l__Passive__27, l__PassiveStatic__28);
        local v167 = l__Passive__33;
        local v168 = {
            memoizedState = nil,
            baseState = nil,
            baseQueue = nil,
            queue = nil,
            next = nil
        };
        if u9 == nil then
            u7.memoizedState = v168;
            u9 = v168;
        else
            u9.next = v168;
            u9 = v168;
        end;
        local v169 = u9;
        u7.flags = bit32.bor(u7.flags, v166);
        v169.memoizedState = u137(bit32.bor(l__HasEffect__31, v167), p160, nil, p161);
    end;
end;
local function u173(p171, p172) --[[ Line: 1344 ]]
    -- upvalues: l____DEV____1 (copy), l__warnIfNotCurrentlyActingEffectsInDEV__41 (copy), u7 (ref), l__Passive__27 (copy), l__Passive__33 (copy)
    if l____DEV____1 and (type(_G.jest) ~= "nil" or _G.__TESTEZ_RUNNING_TEST__) then
        l__warnIfNotCurrentlyActingEffectsInDEV__41(u7);
    end;
    updateEffectImpl(l__Passive__27, l__Passive__33, p171, p172);
end;
local function u184(p174, p175) --[[ Line: 1359 ]]
    -- upvalues: l____DEV____1 (copy), l__enableDoubleInvokingEffects__15 (copy), l__MountLayoutDev__29 (copy), l__Update__26 (copy), l__Layout__32 (copy), u9 (ref), u7 (ref), u137 (copy), l__HasEffect__31 (copy)
    if l____DEV____1 and l__enableDoubleInvokingEffects__15 then
        local v176 = bit32.bor(l__MountLayoutDev__29, l__Update__26);
        local v177 = l__Layout__32;
        local v178 = {
            memoizedState = nil,
            baseState = nil,
            baseQueue = nil,
            queue = nil,
            next = nil
        };
        if u9 == nil then
            u7.memoizedState = v178;
            u9 = v178;
        else
            u9.next = v178;
            u9 = v178;
        end;
        local v179 = u9;
        u7.flags = bit32.bor(u7.flags, v176);
        v179.memoizedState = u137(bit32.bor(l__HasEffect__31, v177), p174, nil, p175);
    else
        local v180 = l__Update__26;
        local v181 = l__Layout__32;
        local v182 = {
            memoizedState = nil,
            baseState = nil,
            baseQueue = nil,
            queue = nil,
            next = nil
        };
        if u9 == nil then
            u7.memoizedState = v182;
            u9 = v182;
        else
            u9.next = v182;
            u9 = v182;
        end;
        local v183 = u9;
        u7.flags = bit32.bor(u7.flags, v180);
        v183.memoizedState = u137(bit32.bor(l__HasEffect__31, v181), p174, nil, p175);
    end;
end;
local function u187(p185, p186) --[[ Line: 1376 ]]
    -- upvalues: l__Update__26 (copy), l__Layout__32 (copy)
    updateEffectImpl(l__Update__26, l__Layout__32, p185, p186);
end;
function imperativeHandleEffect(p188, u189)
    -- upvalues: l____DEV____1 (copy), l__Object__4 (copy), l__console__7 (copy), l__Array__2 (copy)
    if u189 ~= nil and type(u189) == "function" then
        u189((p188()));
        return function() --[[ Line: 1393 ]]
            -- upvalues: u189 (copy)
            return u189(nil);
        end;
    end;
    if u189 == nil then
        return nil;
    end;
    if l____DEV____1 then
        local v190;
        if getmetatable(u189) == nil then
            v190 = false;
        else
            v190 = #l__Object__4.keys(u189) == 0;
        end;
        if not v190 then
            l__console__7.error("Expected useImperativeHandle() first argument to either be a ref callback or React.createRef() object. Instead received: %s.", "an object with keys {" .. l__Array__2.join(l__Object__4.keys(u189), ", ") .. "}");
        end;
    end;
    u189.current = p188();
    return function() --[[ Line: 1418 ]]
        -- upvalues: u189 (copy)
        u189.current = nil;
    end;
end;
function mountImperativeHandle(u191, u192, p193)
    -- upvalues: l____DEV____1 (copy), l__console__7 (copy), l__Array__2 (copy), l__enableDoubleInvokingEffects__15 (copy), u153 (copy), l__MountLayoutDev__29 (copy), l__Update__26 (copy), l__Layout__32 (copy)
    if l____DEV____1 and type(u192) ~= "function" then
        l__console__7.error("Expected useImperativeHandle() second argument to be a function that creates a handle. Instead received: %s.", u192 == nil and "nil" or type(u192));
    end;
    local v194;
    if p193 == nil then
        v194 = nil;
    else
        v194 = l__Array__2.concat(p193, { u191 });
    end;
    if l____DEV____1 and l__enableDoubleInvokingEffects__15 then
        return u153(bit32.bor(l__MountLayoutDev__29, l__Update__26), l__Layout__32, function() --[[ Line: 1450 ]]
            -- upvalues: u192 (copy), u191 (copy)
            return imperativeHandleEffect(u192, u191);
        end, v194);
    else
        return u153(l__Update__26, l__Layout__32, function() --[[ Line: 1456 ]]
            -- upvalues: u192 (copy), u191 (copy)
            return imperativeHandleEffect(u192, u191);
        end, v194);
    end;
end;
function updateImperativeHandle(u195, u196, p197)
    -- upvalues: l____DEV____1 (copy), l__console__7 (copy), l__Update__26 (copy), l__Layout__32 (copy)
    if l____DEV____1 and type(u196) ~= "function" then
        local v198 = not u196 and "nil" or type(u196);
        l__console__7.error("Expected useImperativeHandle() second argument to be a function that creates a handle. Instead received: %s.", v198);
    end;
    local v199;
    if p197 == nil then
        v199 = nil;
    else
        v199 = table.clone(p197);
        table.insert(v199, u195);
    end;
    return updateEffectImpl(l__Update__26, l__Layout__32, function() --[[ Line: 1489 ]]
        -- upvalues: u196 (copy), u195 (copy)
        return imperativeHandleEffect(u196, u195);
    end, v199);
end;
function mountDebugValue(_, _) end;
local u200 = mountDebugValue;
function mountCallback(p201, p202)
    -- upvalues: u9 (ref), u7 (ref)
    local v203 = {
        memoizedState = nil,
        baseState = nil,
        baseQueue = nil,
        queue = nil,
        next = nil
    };
    if u9 == nil then
        u7.memoizedState = v203;
        u9 = v203;
    else
        u9.next = v203;
        u9 = v203;
    end;
    u9.memoizedState = { p201, p202 };
    return p201;
end;
function updateCallback(p204, p205)
    -- upvalues: u53 (copy), u41 (copy)
    local v206 = u53();
    local l__memoizedState__87 = v206.memoizedState;
    if l__memoizedState__87 ~= nil and (p205 ~= nil and u41(p205, l__memoizedState__87[2])) then
        return l__memoizedState__87[1];
    end;
    v206.memoizedState = { p204, p205 };
    return p204;
end;
function mountMemo(p207, p208)
    -- upvalues: u9 (ref), u7 (ref)
    local v209 = {
        memoizedState = nil,
        baseState = nil,
        baseQueue = nil,
        queue = nil,
        next = nil
    };
    if u9 == nil then
        u7.memoizedState = v209;
        u9 = v209;
    else
        u9.next = v209;
        u9 = v209;
    end;
    local v210 = u9;
    local v211 = { p207() };
    v210.memoizedState = { v211, p208 };
    return unpack(v211);
end;
function updateMemo(p212, p213)
    -- upvalues: u53 (copy), u41 (copy)
    local v214 = u53();
    local l__memoizedState__88 = v214.memoizedState;
    if l__memoizedState__88 ~= nil and (p213 ~= nil and u41(p213, l__memoizedState__88[2])) then
        return unpack(l__memoizedState__88[1]);
    end;
    local v215 = { p212() };
    v214.memoizedState = { v215, p213 };
    return unpack(v215);
end;
function u5.getIsUpdatingOpaqueValueInRenderPhaseInDEV() --[[ Line: 1691 ]]
    -- upvalues: l____DEV____1 (copy)
    if l____DEV____1 then
        return false;
    else
        return nil;
    end;
end;
function mountOpaqueIdentifier()
    -- upvalues: l____DEV____1 (copy), l__console__7 (copy), l__makeClientId__46 (copy), l__getIsHydrating__45 (copy)
    local v216 = nil;
    if l____DEV____1 then
        l__console__7.warn("!!! unimplemented: warnOnOpaqueIdentifierAccessInDEV");
    else
        v216 = l__makeClientId__46;
    end;
    if not l__getIsHydrating__45() then
        local v217 = v216();
        mountState(v217);
        return v217;
    end;
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("UNIMPLEMENTED ERROR: ReactFiberHooks: getIsHydrating() true");
    error("FIXME (roblox): ReactFiberHooks: getIsHydrating() true is unimplemented");
    return nil;
end;
function updateOpaqueIdentifier()
    local v218, _ = updateState(nil);
    return v218;
end;
function rerenderOpaqueIdentifier()
    local v219, _ = rerenderState(nil);
    return v219;
end;
function dispatchAction(p220, p221, p222, ...)
    -- upvalues: l____DEV____1 (copy), l__console__7 (copy), l__requestEventTime__37 (copy), l__requestUpdateLane__38 (copy), u7 (ref), u10 (ref), u11 (ref), l__NoLanes__18 (copy), l__ReactCurrentDispatcher__53 (copy), u20 (ref), l__warnIfNotScopedWithMatchingAct__36 (copy), l__warnIfNotCurrentlyActingUpdatesInDEV__34 (copy), l__scheduleUpdateOnFiber__35 (copy), l__enableDebugTracing__12 (copy), l__DebugTracingMode__16 (copy), l__getComponentName__43 (copy), l__logStateUpdateScheduled__51 (copy), l__enableSchedulingProfiler__13 (copy), l__markStateUpdateScheduled__52 (copy)
    if l____DEV____1 then
        local v223;
        if select("#", ...) == 1 then
            v223 = select(1, ...);
        else
            v223 = nil;
        end;
        if type(v223) == "function" then
            l__console__7.error("State updates from the useState() and useReducer() Hooks don\'t support the second callback argument. To execute a side effect after rendering, declare it in the component body with useEffect().");
        end;
    end;
    local v224 = l__requestEventTime__37();
    local v225 = l__requestUpdateLane__38(p220);
    local v226 = {
        eagerReducer = nil,
        eagerState = nil,
        next = nil,
        lane = v225,
        action = p222
    };
    local l__pending__89 = p221.pending;
    if l__pending__89 == nil then
        v226.next = v226;
    else
        v226.next = l__pending__89.next;
        l__pending__89.next = v226;
    end;
    p221.pending = v226;
    local l__alternate__90 = p220.alternate;
    if p220 == u7 or l__alternate__90 ~= nil and l__alternate__90 == u7 then
        u10 = true;
        u11 = true;
    else
        if p220.lanes == l__NoLanes__18 and (l__alternate__90 == nil or l__alternate__90.lanes == l__NoLanes__18) then
            local l__lastRenderedReducer__91 = p221.lastRenderedReducer;
            if l__lastRenderedReducer__91 ~= nil then
                local v227;
                if l____DEV____1 then
                    v227 = l__ReactCurrentDispatcher__53.current;
                    l__ReactCurrentDispatcher__53.current = u20;
                else
                    v227 = nil;
                end;
                local l__lastRenderedState__92 = p221.lastRenderedState;
                local v228, v229 = pcall(l__lastRenderedReducer__91, l__lastRenderedState__92, p222);
                if v228 then
                    v226.eagerReducer = l__lastRenderedReducer__91;
                    v226.eagerState = v229;
                end;
                if l____DEV____1 then
                    l__ReactCurrentDispatcher__53.current = v227;
                end;
                local v230;
                if v229 == l__lastRenderedState__92 and (v229 ~= 0 or 1 / v229 == 1 / l__lastRenderedState__92) then
                    v230 = true;
                elseif v229 == v229 then
                    v230 = false;
                else
                    v230 = l__lastRenderedState__92 ~= l__lastRenderedState__92;
                end;
                if v230 then
                    return;
                end;
            end;
        end;
        if l____DEV____1 and (type(_G.jest) ~= "nil" or _G.__TESTEZ_RUNNING_TEST__) then
            l__warnIfNotScopedWithMatchingAct__36(p220);
            l__warnIfNotCurrentlyActingUpdatesInDEV__34(p220);
        end;
        l__scheduleUpdateOnFiber__35(p220, v225, v224);
    end;
    if l____DEV____1 and (l__enableDebugTracing__12 and bit32.band(p220.mode, l__DebugTracingMode__16) ~= 0) then
        l__logStateUpdateScheduled__51(l__getComponentName__43(p220.type) or "Unknown", v225, p222);
    end;
    if l__enableSchedulingProfiler__13 then
        l__markStateUpdateScheduled__52(p220, v225);
    end;
end;
local u231 = {
    readContext = l__readContext__24,
    useCallback = v30,
    useContext = v30,
    useEffect = v30,
    useImperativeHandle = v30,
    useLayoutEffect = v30,
    useMemo = v30,
    useReducer = v30,
    useRef = v30,
    useBinding = v30,
    useState = v30,
    useDebugValue = v30,
    useMutableSource = v30,
    useOpaqueIdentifier = v30,
    unstable_isNewReconciler = l__enableNewReconciler__14
};
u5.ContextOnlyDispatcher = u231;
local u232 = {
    readContext = l__readContext__24,
    useCallback = mountCallback,
    useContext = l__readContext__24,
    useEffect = u170,
    useImperativeHandle = mountImperativeHandle,
    useLayoutEffect = u184,
    useMemo = mountMemo,
    useReducer = mountReducer,
    useRef = mountRef,
    useBinding = mountBinding,
    useState = mountState,
    useDebugValue = mountDebugValue,
    useMutableSource = mountMutableSource,
    useOpaqueIdentifier = mountOpaqueIdentifier,
    unstable_isNewReconciler = l__enableNewReconciler__14
};
local u233 = {
    readContext = l__readContext__24,
    useCallback = updateCallback,
    useContext = l__readContext__24,
    useEffect = u173,
    useImperativeHandle = updateImperativeHandle,
    useLayoutEffect = u187,
    useMemo = updateMemo,
    useReducer = updateReducer,
    useRef = updateRef,
    useBinding = updateBinding,
    useState = updateState,
    useDebugValue = u200,
    useMutableSource = updateMutableSource,
    useOpaqueIdentifier = updateOpaqueIdentifier,
    unstable_isNewReconciler = l__enableNewReconciler__14
};
local u234 = {
    readContext = l__readContext__24,
    useCallback = updateCallback,
    useContext = l__readContext__24,
    useEffect = u173,
    useImperativeHandle = updateImperativeHandle,
    useLayoutEffect = u187,
    useMemo = updateMemo,
    useReducer = rerenderReducer,
    useRef = updateRef,
    useBinding = updateBinding,
    useState = rerenderState,
    useDebugValue = u200,
    useMutableSource = updateMutableSource,
    useOpaqueIdentifier = rerenderOpaqueIdentifier,
    unstable_isNewReconciler = l__enableNewReconciler__14
};
if l____DEV____1 then
    u15 = {
        readContext = function(p235, p236) --[[ Name: readContext, Line 2024 ]]
            -- upvalues: l__readContext__24 (copy)
            return l__readContext__24(p235, p236);
        end,
        useCallback = function(p237, p238) --[[ Name: useCallback, Line 2027 ]]
            -- upvalues: u12 (ref), l____DEV____1 (copy), u13 (ref), l__console__7 (copy)
            u12 = "useCallback";
            if l____DEV____1 then
                local v239 = u12;
                if u13 == nil then
                    u13 = { v239 };
                else
                    table.insert(u13, v239);
                end;
            end;
            if not l____DEV____1 or p238 == nil then
                return mountCallback(p237, p238);
            end;
            local v240;
            if type(p238) == "table" then
                for v241, _ in p238 do
                    if type(v241) ~= "number" then
                        v240 = false;
                        if not v240 then
                            l__console__7.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", u12, (type(p238)));
                        end;
                        return mountCallback(p237, p238);
                    end;
                end;
                v240 = true;
                if not v240 then
                    l__console__7.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", u12, (type(p238)));
                end;
                return mountCallback(p237, p238);
            else
                v240 = false;
                if not v240 then
                    l__console__7.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", u12, (type(p238)));
                end;
                return mountCallback(p237, p238);
            end;
        end,
        useContext = function(p242, p243) --[[ Name: useContext, Line 2033 ]]
            -- upvalues: u12 (ref), l____DEV____1 (copy), u13 (ref), l__readContext__24 (copy)
            u12 = "useContext";
            if l____DEV____1 then
                local v244 = u12;
                if u13 == nil then
                    u13 = { v244 };
                else
                    table.insert(u13, v244);
                end;
            end;
            return l__readContext__24(p242, p243);
        end,
        useEffect = function(p245, p246) --[[ Name: useEffect, Line 2038 ]]
            -- upvalues: u12 (ref), l____DEV____1 (copy), u13 (ref), l__console__7 (copy), u170 (copy)
            u12 = "useEffect";
            if l____DEV____1 then
                local v247 = u12;
                if u13 == nil then
                    u13 = { v247 };
                else
                    table.insert(u13, v247);
                end;
            end;
            if not l____DEV____1 or p246 == nil then
                return u170(p245, p246);
            end;
            local v248;
            if type(p246) == "table" then
                for v249, _ in p246 do
                    if type(v249) ~= "number" then
                        v248 = false;
                        if not v248 then
                            l__console__7.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", u12, (type(p246)));
                        end;
                        return u170(p245, p246);
                    end;
                end;
                v248 = true;
                if not v248 then
                    l__console__7.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", u12, (type(p246)));
                end;
                return u170(p245, p246);
            else
                v248 = false;
                if not v248 then
                    l__console__7.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", u12, (type(p246)));
                end;
                return u170(p245, p246);
            end;
        end,
        useImperativeHandle = function(p250, p251, p252) --[[ Name: useImperativeHandle, Line 2048 ]]
            -- upvalues: u12 (ref), l____DEV____1 (copy), u13 (ref), l__console__7 (copy)
            u12 = "useImperativeHandle";
            if l____DEV____1 then
                local v253 = u12;
                if u13 == nil then
                    u13 = { v253 };
                else
                    table.insert(u13, v253);
                end;
            end;
            if not l____DEV____1 or p252 == nil then
                return mountImperativeHandle(p250, p251, p252);
            end;
            local v254;
            if type(p252) == "table" then
                for v255, _ in p252 do
                    if type(v255) ~= "number" then
                        v254 = false;
                        if not v254 then
                            l__console__7.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", u12, (type(p252)));
                        end;
                        return mountImperativeHandle(p250, p251, p252);
                    end;
                end;
                v254 = true;
                if not v254 then
                    l__console__7.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", u12, (type(p252)));
                end;
                return mountImperativeHandle(p250, p251, p252);
            else
                v254 = false;
                if not v254 then
                    l__console__7.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", u12, (type(p252)));
                end;
                return mountImperativeHandle(p250, p251, p252);
            end;
        end,
        useLayoutEffect = function(p256, p257) --[[ Name: useLayoutEffect, Line 2058 ]]
            -- upvalues: u12 (ref), l____DEV____1 (copy), u13 (ref), l__console__7 (copy), u184 (copy)
            u12 = "useLayoutEffect";
            if l____DEV____1 then
                local v258 = u12;
                if u13 == nil then
                    u13 = { v258 };
                else
                    table.insert(u13, v258);
                end;
            end;
            if not l____DEV____1 or p257 == nil then
                return u184(p256, p257);
            end;
            local v259;
            if type(p257) == "table" then
                for v260, _ in p257 do
                    if type(v260) ~= "number" then
                        v259 = false;
                        if not v259 then
                            l__console__7.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", u12, (type(p257)));
                        end;
                        return u184(p256, p257);
                    end;
                end;
                v259 = true;
                if not v259 then
                    l__console__7.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", u12, (type(p257)));
                end;
                return u184(p256, p257);
            else
                v259 = false;
                if not v259 then
                    l__console__7.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", u12, (type(p257)));
                end;
                return u184(p256, p257);
            end;
        end,
        useMemo = function(p261, p262) --[[ Line: 2069 ]]
            -- upvalues: u12 (ref), l____DEV____1 (copy), u13 (ref), l__console__7 (copy), l__ReactCurrentDispatcher__53 (copy), u19 (ref)
            u12 = "useMemo";
            if l____DEV____1 then
                local v263 = u12;
                if u13 == nil then
                    u13 = { v263 };
                else
                    table.insert(u13, v263);
                end;
            end;
            local v264, v265;
            if not l____DEV____1 or p262 == nil then
                v264 = l__ReactCurrentDispatcher__53.current;
                l__ReactCurrentDispatcher__53.current = u19;
                v265 = { pcall(mountMemo, p261, p262) };
                l__ReactCurrentDispatcher__53.current = v264;
                if not v265[1] then
                    error(v265[2]);
                end;
                return unpack(v265, 2);
            end;
            local v266;
            if type(p262) == "table" then
                for v267, _ in p262 do
                    if type(v267) ~= "number" then
                        v266 = false;
                        if not v266 then
                            l__console__7.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", u12, (type(p262)));
                        end;
                        v264 = l__ReactCurrentDispatcher__53.current;
                        l__ReactCurrentDispatcher__53.current = u19;
                        v265 = { pcall(mountMemo, p261, p262) };
                        l__ReactCurrentDispatcher__53.current = v264;
                        if not v265[1] then
                            error(v265[2]);
                        end;
                        return unpack(v265, 2);
                    end;
                end;
                v266 = true;
                if not v266 then
                    l__console__7.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", u12, (type(p262)));
                end;
                v264 = l__ReactCurrentDispatcher__53.current;
                l__ReactCurrentDispatcher__53.current = u19;
                v265 = { pcall(mountMemo, p261, p262) };
                l__ReactCurrentDispatcher__53.current = v264;
                if not v265[1] then
                    error(v265[2]);
                end;
                return unpack(v265, 2);
            else
                v266 = false;
                if not v266 then
                    l__console__7.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", u12, (type(p262)));
                end;
                v264 = l__ReactCurrentDispatcher__53.current;
                l__ReactCurrentDispatcher__53.current = u19;
                v265 = { pcall(mountMemo, p261, p262) };
                l__ReactCurrentDispatcher__53.current = v264;
                if not v265[1] then
                    error(v265[2]);
                end;
                return unpack(v265, 2);
            end;
        end,
        useReducer = function(p268, p269, p270) --[[ Name: useReducer, Line 2087 ]]
            -- upvalues: u12 (ref), l____DEV____1 (copy), u13 (ref), l__ReactCurrentDispatcher__53 (copy), u19 (ref)
            u12 = "useReducer";
            if l____DEV____1 then
                local v271 = u12;
                if u13 == nil then
                    u13 = { v271 };
                else
                    table.insert(u13, v271);
                end;
            end;
            local l__current__93 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u19;
            local v272, v273, v274 = pcall(mountReducer, p268, p269, p270);
            l__ReactCurrentDispatcher__53.current = l__current__93;
            if not v272 then
                error(v273);
            end;
            return v273, v274;
        end,
        useRef = function(p275) --[[ Name: useRef, Line 2106 ]]
            -- upvalues: u12 (ref), l____DEV____1 (copy), u13 (ref)
            u12 = "useRef";
            if l____DEV____1 then
                local v276 = u12;
                if u13 == nil then
                    u13 = { v276 };
                else
                    table.insert(u13, v276);
                end;
            end;
            return mountRef(p275);
        end,
        useBinding = function(p277) --[[ Name: useBinding, Line 2112 ]]
            -- upvalues: u12 (ref), l____DEV____1 (copy), u13 (ref)
            u12 = "useBinding";
            if l____DEV____1 then
                local v278 = u12;
                if u13 == nil then
                    u13 = { v278 };
                else
                    table.insert(u13, v278);
                end;
            end;
            return mountBinding(p277);
        end,
        useState = function(p279) --[[ Name: useState, Line 2117 ]]
            -- upvalues: u12 (ref), l____DEV____1 (copy), u13 (ref), l__ReactCurrentDispatcher__53 (copy), u19 (ref)
            u12 = "useState";
            if l____DEV____1 then
                local v280 = u12;
                if u13 == nil then
                    u13 = { v280 };
                else
                    table.insert(u13, v280);
                end;
            end;
            local l__current__94 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u19;
            local v281, v282, v283 = pcall(mountState, p279);
            l__ReactCurrentDispatcher__53.current = l__current__94;
            if not v281 then
                error(v282);
            end;
            return v282, v283;
        end,
        useDebugValue = function(p284, p285) --[[ Name: useDebugValue, Line 2131 ]]
            -- upvalues: u12 (ref), l____DEV____1 (copy), u13 (ref)
            u12 = "useDebugValue";
            if l____DEV____1 then
                local v286 = u12;
                if u13 == nil then
                    u13 = { v286 };
                else
                    table.insert(u13, v286);
                end;
            end;
            return mountDebugValue(p284, p285);
        end,
        useMutableSource = function(p287, p288, p289) --[[ Name: useMutableSource, Line 2146 ]]
            -- upvalues: u12 (ref), l____DEV____1 (copy), u13 (ref)
            u12 = "useMutableSource";
            if l____DEV____1 then
                local v290 = u12;
                if u13 == nil then
                    u13 = { v290 };
                else
                    table.insert(u13, v290);
                end;
            end;
            return mountMutableSource(p287, p288, p289);
        end,
        useOpaqueIdentifier = function() --[[ Name: useOpaqueIdentifier, Line 2161 ]]
            -- upvalues: u12 (ref), l____DEV____1 (copy), u13 (ref)
            u12 = "useOpaqueIdentifier";
            if l____DEV____1 then
                local v291 = u12;
                if u13 == nil then
                    u13 = { v291 };
                else
                    table.insert(u13, v291);
                end;
            end;
            return mountOpaqueIdentifier();
        end,
        unstable_isNewReconciler = l__enableNewReconciler__14
    };
    u16 = {
        readContext = function(p292, p293) --[[ Name: readContext, Line 2171 ]]
            -- upvalues: l__readContext__24 (copy)
            return l__readContext__24(p292, p293);
        end,
        useCallback = function(p294, p295) --[[ Name: useCallback, Line 2174 ]]
            -- upvalues: u12 (ref), l____DEV____1 (copy), l__console__7 (copy)
            u12 = "useCallback";
            updateHookTypesDev();
            if not l____DEV____1 or p295 == nil then
                return mountCallback(p294, p295);
            end;
            local v296;
            if type(p295) == "table" then
                for v297, _ in p295 do
                    if type(v297) ~= "number" then
                        v296 = false;
                        if not v296 then
                            l__console__7.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", u12, (type(p295)));
                        end;
                        return mountCallback(p294, p295);
                    end;
                end;
                v296 = true;
                if not v296 then
                    l__console__7.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", u12, (type(p295)));
                end;
                return mountCallback(p294, p295);
            else
                v296 = false;
                if not v296 then
                    l__console__7.error("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", u12, (type(p295)));
                end;
                return mountCallback(p294, p295);
            end;
        end,
        useContext = function(p298, p299) --[[ Name: useContext, Line 2180 ]]
            -- upvalues: u12 (ref), l__readContext__24 (copy)
            u12 = "useContext";
            updateHookTypesDev();
            return l__readContext__24(p298, p299);
        end,
        useEffect = function(p300, p301) --[[ Name: useEffect, Line 2185 ]]
            -- upvalues: u12 (ref), u170 (copy)
            u12 = "useEffect";
            updateHookTypesDev();
            return u170(p300, p301);
        end,
        useImperativeHandle = function(p302, p303, p304) --[[ Name: useImperativeHandle, Line 2194 ]]
            -- upvalues: u12 (ref)
            u12 = "useImperativeHandle";
            updateHookTypesDev();
            return mountImperativeHandle(p302, p303, p304);
        end,
        useLayoutEffect = function(p305, p306) --[[ Name: useLayoutEffect, Line 2203 ]]
            -- upvalues: u12 (ref), u184 (copy)
            u12 = "useLayoutEffect";
            updateHookTypesDev();
            return u184(p305, p306);
        end,
        useMemo = function(p307, p308) --[[ Line: 2213 ]]
            -- upvalues: u12 (ref), l__ReactCurrentDispatcher__53 (copy), u19 (ref)
            u12 = "useMemo";
            updateHookTypesDev();
            local l__current__95 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u19;
            local v309 = { pcall(mountMemo, p307, p308) };
            l__ReactCurrentDispatcher__53.current = l__current__95;
            if not v309[1] then
                error(v309[2]);
            end;
            return unpack(v309, 2);
        end,
        useReducer = function(p310, p311, p312) --[[ Name: useReducer, Line 2229 ]]
            -- upvalues: u12 (ref), l__ReactCurrentDispatcher__53 (copy), u19 (ref)
            u12 = "useReducer";
            updateHookTypesDev();
            local l__current__96 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u19;
            local v313, v314, v315 = pcall(mountReducer, p310, p311, p312);
            l__ReactCurrentDispatcher__53.current = l__current__96;
            if not v313 then
                error(v314);
            end;
            return v314, v315;
        end,
        useRef = function(p316) --[[ Name: useRef, Line 2248 ]]
            -- upvalues: u12 (ref)
            u12 = "useRef";
            updateHookTypesDev();
            return mountRef(p316);
        end,
        useBinding = function(p317) --[[ Name: useBinding, Line 2254 ]]
            -- upvalues: u12 (ref)
            u12 = "useBinding";
            updateHookTypesDev();
            return mountBinding(p317);
        end,
        useState = function(p318) --[[ Name: useState, Line 2259 ]]
            -- upvalues: u12 (ref), l__ReactCurrentDispatcher__53 (copy), u19 (ref)
            u12 = "useState";
            updateHookTypesDev();
            local l__current__97 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u19;
            local v319, v320, v321 = pcall(mountState, p318);
            l__ReactCurrentDispatcher__53.current = l__current__97;
            if not v319 then
                error(v320);
            end;
            return v320, v321;
        end,
        useDebugValue = function(p322, p323) --[[ Name: useDebugValue, Line 2273 ]]
            -- upvalues: u12 (ref)
            u12 = "useDebugValue";
            updateHookTypesDev();
            return mountDebugValue(p322, p323);
        end,
        useMutableSource = function(p324, p325, p326) --[[ Name: useMutableSource, Line 2288 ]]
            -- upvalues: u12 (ref)
            u12 = "useMutableSource";
            updateHookTypesDev();
            return mountMutableSource(p324, p325, p326);
        end,
        useOpaqueIdentifier = function() --[[ Name: useOpaqueIdentifier, Line 2303 ]]
            -- upvalues: u12 (ref)
            u12 = "useOpaqueIdentifier";
            updateHookTypesDev();
            return mountOpaqueIdentifier();
        end,
        unstable_isNewReconciler = l__enableNewReconciler__14
    };
    u17 = {
        readContext = function(p327, p328) --[[ Name: readContext, Line 2313 ]]
            -- upvalues: l__readContext__24 (copy)
            return l__readContext__24(p327, p328);
        end,
        useCallback = function(p329, p330) --[[ Name: useCallback, Line 2316 ]]
            -- upvalues: u12 (ref)
            u12 = "useCallback";
            updateHookTypesDev();
            return updateCallback(p329, p330);
        end,
        useContext = function(p331, p332) --[[ Name: useContext, Line 2321 ]]
            -- upvalues: u12 (ref), l__readContext__24 (copy)
            u12 = "useContext";
            updateHookTypesDev();
            return l__readContext__24(p331, p332);
        end,
        useEffect = function(p333, p334) --[[ Name: useEffect, Line 2326 ]]
            -- upvalues: u12 (ref), u173 (copy)
            u12 = "useEffect";
            updateHookTypesDev();
            return u173(p333, p334);
        end,
        useImperativeHandle = function(p335, p336, p337) --[[ Name: useImperativeHandle, Line 2335 ]]
            -- upvalues: u12 (ref)
            u12 = "useImperativeHandle";
            updateHookTypesDev();
            return updateImperativeHandle(p335, p336, p337);
        end,
        useLayoutEffect = function(p338, p339) --[[ Name: useLayoutEffect, Line 2344 ]]
            -- upvalues: u12 (ref), u187 (copy)
            u12 = "useLayoutEffect";
            updateHookTypesDev();
            return u187(p338, p339);
        end,
        useMemo = function(p340, p341) --[[ Line: 2354 ]]
            -- upvalues: u12 (ref), l__ReactCurrentDispatcher__53 (copy), u20 (ref)
            u12 = "useMemo";
            updateHookTypesDev();
            local l__current__98 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u20;
            local v342 = { pcall(updateMemo, p340, p341) };
            l__ReactCurrentDispatcher__53.current = l__current__98;
            if not v342[1] then
                error(v342[2]);
            end;
            return unpack(v342, 2);
        end,
        useReducer = function(p343, p344, p345) --[[ Name: useReducer, Line 2370 ]]
            -- upvalues: u12 (ref), l__ReactCurrentDispatcher__53 (copy), u20 (ref)
            u12 = "useReducer";
            updateHookTypesDev();
            local l__current__99 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u20;
            local v346, v347, v348 = pcall(updateReducer, p343, p344, p345);
            l__ReactCurrentDispatcher__53.current = l__current__99;
            if not v346 then
                error(v347);
            end;
            return v347, v348;
        end,
        useRef = function(p349) --[[ Name: useRef, Line 2389 ]]
            -- upvalues: u12 (ref)
            u12 = "useRef";
            updateHookTypesDev();
            return updateRef(p349);
        end,
        useBinding = function(p350) --[[ Name: useBinding, Line 2395 ]]
            -- upvalues: u12 (ref)
            u12 = "useBinding";
            updateHookTypesDev();
            return updateBinding(p350);
        end,
        useState = function(p351) --[[ Name: useState, Line 2400 ]]
            -- upvalues: u12 (ref), l__ReactCurrentDispatcher__53 (copy), u20 (ref)
            u12 = "useState";
            updateHookTypesDev();
            local l__current__100 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u20;
            local v352, v353, v354 = pcall(updateState, p351);
            l__ReactCurrentDispatcher__53.current = l__current__100;
            if not v352 then
                error(v353);
            end;
            return v353, v354;
        end,
        useDebugValue = function(p355, p356) --[[ Name: useDebugValue, Line 2414 ]]
            -- upvalues: u12 (ref), u200 (copy)
            u12 = "useDebugValue";
            updateHookTypesDev();
            return u200(p355, p356);
        end,
        useMutableSource = function(p357, p358, p359) --[[ Name: useMutableSource, Line 2429 ]]
            -- upvalues: u12 (ref)
            u12 = "useMutableSource";
            updateHookTypesDev();
            return updateMutableSource(p357, p358, p359);
        end,
        useOpaqueIdentifier = function() --[[ Name: useOpaqueIdentifier, Line 2444 ]]
            -- upvalues: u12 (ref)
            u12 = "useOpaqueIdentifier";
            updateHookTypesDev();
            return updateOpaqueIdentifier();
        end,
        unstable_isNewReconciler = l__enableNewReconciler__14
    };
    u18 = {
        readContext = function(p360, p361) --[[ Name: readContext, Line 2454 ]]
            -- upvalues: l__readContext__24 (copy)
            return l__readContext__24(p360, p361);
        end,
        useCallback = function(p362, p363) --[[ Name: useCallback, Line 2457 ]]
            -- upvalues: u12 (ref)
            u12 = "useCallback";
            updateHookTypesDev();
            return mountCallback(p362, p363);
        end,
        useContext = function(p364, p365) --[[ Name: useContext, Line 2462 ]]
            -- upvalues: u12 (ref), l__readContext__24 (copy)
            u12 = "useContext";
            updateHookTypesDev();
            return l__readContext__24(p364, p365);
        end,
        useEffect = function(p366, p367) --[[ Name: useEffect, Line 2467 ]]
            -- upvalues: u12 (ref), u173 (copy)
            u12 = "useEffect";
            updateHookTypesDev();
            return u173(p366, p367);
        end,
        useImperativeHandle = function(p368, p369, p370) --[[ Name: useImperativeHandle, Line 2476 ]]
            -- upvalues: u12 (ref)
            u12 = "useImperativeHandle";
            updateHookTypesDev();
            return updateImperativeHandle(p368, p369, p370);
        end,
        useLayoutEffect = function(p371, p372) --[[ Name: useLayoutEffect, Line 2485 ]]
            -- upvalues: u12 (ref), u187 (copy)
            u12 = "useLayoutEffect";
            updateHookTypesDev();
            return u187(p371, p372);
        end,
        useMemo = function(p373, p374) --[[ Line: 2495 ]]
            -- upvalues: u12 (ref), l__ReactCurrentDispatcher__53 (copy), u21 (ref)
            u12 = "useMemo";
            updateHookTypesDev();
            local l__current__101 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u21;
            local v375 = { pcall(updateMemo, p373, p374) };
            l__ReactCurrentDispatcher__53.current = l__current__101;
            if not v375[1] then
                error(v375[2]);
            end;
            return unpack(v375, 2);
        end,
        useReducer = function(p376, p377, p378) --[[ Name: useReducer, Line 2511 ]]
            -- upvalues: u12 (ref), l__ReactCurrentDispatcher__53 (copy), u21 (ref)
            u12 = "useReducer";
            updateHookTypesDev();
            local l__current__102 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u21;
            local v379, v380, v381 = pcall(rerenderReducer, p376, p377, p378);
            l__ReactCurrentDispatcher__53.current = l__current__102;
            if not v379 then
                error(v380);
            end;
            return v380, v381;
        end,
        useRef = function(p382) --[[ Name: useRef, Line 2531 ]]
            -- upvalues: u12 (ref)
            u12 = "useRef";
            updateHookTypesDev();
            return updateRef(p382);
        end,
        useBinding = function(p383) --[[ Name: useBinding, Line 2537 ]]
            -- upvalues: u12 (ref)
            u12 = "useBinding";
            updateHookTypesDev();
            return updateBinding(p383);
        end,
        useState = function(p384) --[[ Name: useState, Line 2542 ]]
            -- upvalues: u12 (ref), l__ReactCurrentDispatcher__53 (copy), u21 (ref)
            u12 = "useState";
            updateHookTypesDev();
            local l__current__103 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u21;
            local v385, v386, v387 = pcall(rerenderState, p384);
            l__ReactCurrentDispatcher__53.current = l__current__103;
            if not v385 then
                error(v386);
            end;
            return v386, v387;
        end,
        useDebugValue = function(p388, p389) --[[ Name: useDebugValue, Line 2556 ]]
            -- upvalues: u12 (ref), u200 (copy)
            u12 = "useDebugValue";
            updateHookTypesDev();
            return u200(p388, p389);
        end,
        useMutableSource = function(p390, p391, p392) --[[ Name: useMutableSource, Line 2571 ]]
            -- upvalues: u12 (ref)
            u12 = "useMutableSource";
            updateHookTypesDev();
            return updateMutableSource(p390, p391, p392);
        end,
        useOpaqueIdentifier = function() --[[ Name: useOpaqueIdentifier, Line 2586 ]]
            -- upvalues: u12 (ref)
            u12 = "useOpaqueIdentifier";
            updateHookTypesDev();
            return rerenderOpaqueIdentifier();
        end,
        unstable_isNewReconciler = l__enableNewReconciler__14
    };
    local _ = {
        readContext = function(p393, p394) --[[ Name: readContext, Line 2596 ]]
            -- upvalues: l__console__7 (copy), l__readContext__24 (copy)
            l__console__7.error("Context can only be read while React is rendering. In classes, you can read it in the render method or getDerivedStateFromProps. In function components, you can read it directly in the function body, but not inside Hooks like useReducer() or useMemo().");
            return l__readContext__24(p393, p394);
        end,
        useCallback = function(p395, p396) --[[ Name: useCallback, Line 2600 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l____DEV____1 (copy), u13 (ref)
            u12 = "useCallback";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            if l____DEV____1 then
                local v397 = u12;
                if u13 == nil then
                    u13 = { v397 };
                else
                    table.insert(u13, v397);
                end;
            end;
            return mountCallback(p395, p396);
        end,
        useContext = function(p398, p399) --[[ Name: useContext, Line 2606 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l____DEV____1 (copy), u13 (ref), l__readContext__24 (copy)
            u12 = "useContext";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            if l____DEV____1 then
                local v400 = u12;
                if u13 == nil then
                    u13 = { v400 };
                else
                    table.insert(u13, v400);
                end;
            end;
            return l__readContext__24(p398, p399);
        end,
        useEffect = function(p401, p402) --[[ Name: useEffect, Line 2612 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l____DEV____1 (copy), u13 (ref), u170 (copy)
            u12 = "useEffect";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            if l____DEV____1 then
                local v403 = u12;
                if u13 == nil then
                    u13 = { v403 };
                else
                    table.insert(u13, v403);
                end;
            end;
            return u170(p401, p402);
        end,
        useImperativeHandle = function(p404, p405, p406) --[[ Name: useImperativeHandle, Line 2622 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l____DEV____1 (copy), u13 (ref)
            u12 = "useImperativeHandle";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            if l____DEV____1 then
                local v407 = u12;
                if u13 == nil then
                    u13 = { v407 };
                else
                    table.insert(u13, v407);
                end;
            end;
            return mountImperativeHandle(p404, p405, p406);
        end,
        useLayoutEffect = function(p408, p409) --[[ Name: useLayoutEffect, Line 2632 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l____DEV____1 (copy), u13 (ref), u184 (copy)
            u12 = "useLayoutEffect";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            if l____DEV____1 then
                local v410 = u12;
                if u13 == nil then
                    u13 = { v410 };
                else
                    table.insert(u13, v410);
                end;
            end;
            return u184(p408, p409);
        end,
        useMemo = function(p411, p412) --[[ Line: 2643 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l____DEV____1 (copy), u13 (ref), l__ReactCurrentDispatcher__53 (copy), u19 (ref)
            u12 = "useMemo";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            if l____DEV____1 then
                local v413 = u12;
                if u13 == nil then
                    u13 = { v413 };
                else
                    table.insert(u13, v413);
                end;
            end;
            local l__current__104 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u19;
            local v414 = { pcall(mountMemo, p411, p412) };
            l__ReactCurrentDispatcher__53.current = l__current__104;
            if not v414[1] then
                error(v414[2]);
            end;
            return unpack(v414, 2);
        end,
        useReducer = function(p415, p416, p417) --[[ Name: useReducer, Line 2660 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l____DEV____1 (copy), u13 (ref), l__ReactCurrentDispatcher__53 (copy), u19 (ref)
            u12 = "useReducer";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            if l____DEV____1 then
                local v418 = u12;
                if u13 == nil then
                    u13 = { v418 };
                else
                    table.insert(u13, v418);
                end;
            end;
            local l__current__105 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u19;
            local v419, v420, v421 = pcall(mountReducer, p415, p416, p417);
            l__ReactCurrentDispatcher__53.current = l__current__105;
            if not v419 then
                error(v420);
            end;
            return v420, v421;
        end,
        useRef = function(p422) --[[ Name: useRef, Line 2680 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l____DEV____1 (copy), u13 (ref)
            u12 = "useRef";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            if l____DEV____1 then
                local v423 = u12;
                if u13 == nil then
                    u13 = { v423 };
                else
                    table.insert(u13, v423);
                end;
            end;
            return mountRef(p422);
        end,
        useBinding = function(p424) --[[ Name: useBinding, Line 2687 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l____DEV____1 (copy), u13 (ref)
            u12 = "useBinding";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            if l____DEV____1 then
                local v425 = u12;
                if u13 == nil then
                    u13 = { v425 };
                else
                    table.insert(u13, v425);
                end;
            end;
            return mountBinding(p424);
        end,
        useState = function(p426) --[[ Name: useState, Line 2693 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l____DEV____1 (copy), u13 (ref), l__ReactCurrentDispatcher__53 (copy), u19 (ref)
            u12 = "useState";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            if l____DEV____1 then
                local v427 = u12;
                if u13 == nil then
                    u13 = { v427 };
                else
                    table.insert(u13, v427);
                end;
            end;
            local l__current__106 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u19;
            local v428, v429, v430 = pcall(mountState, p426);
            l__ReactCurrentDispatcher__53.current = l__current__106;
            if not v428 then
                error(v429);
            end;
            return v429, v430;
        end,
        useDebugValue = function(p431, p432) --[[ Name: useDebugValue, Line 2708 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l____DEV____1 (copy), u13 (ref)
            u12 = "useDebugValue";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            if l____DEV____1 then
                local v433 = u12;
                if u13 == nil then
                    u13 = { v433 };
                else
                    table.insert(u13, v433);
                end;
            end;
            return mountDebugValue(p431, p432);
        end,
        useMutableSource = function(p434, p435, p436) --[[ Name: useMutableSource, Line 2726 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l____DEV____1 (copy), u13 (ref)
            u12 = "useMutableSource";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            if l____DEV____1 then
                local v437 = u12;
                if u13 == nil then
                    u13 = { v437 };
                else
                    table.insert(u13, v437);
                end;
            end;
            return mountMutableSource(p434, p435, p436);
        end,
        useOpaqueIdentifier = function() --[[ Name: useOpaqueIdentifier, Line 2742 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l____DEV____1 (copy), u13 (ref)
            u12 = "useOpaqueIdentifier";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            if l____DEV____1 then
                local v438 = u12;
                if u13 == nil then
                    u13 = { v438 };
                else
                    table.insert(u13, v438);
                end;
            end;
            return mountOpaqueIdentifier();
        end,
        unstable_isNewReconciler = l__enableNewReconciler__14
    };
    u20 = {
        readContext = function(p439, p440) --[[ Name: readContext, Line 2753 ]]
            -- upvalues: l__console__7 (copy), l__readContext__24 (copy)
            l__console__7.error("Context can only be read while React is rendering. In classes, you can read it in the render method or getDerivedStateFromProps. In function components, you can read it directly in the function body, but not inside Hooks like useReducer() or useMemo().");
            return l__readContext__24(p439, p440);
        end,
        useCallback = function(p441, p442) --[[ Name: useCallback, Line 2757 ]]
            -- upvalues: u12 (ref), l__console__7 (copy)
            u12 = "useCallback";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return mountCallback(p441, p442);
        end,
        useContext = function(p443, p444) --[[ Name: useContext, Line 2763 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l__readContext__24 (copy)
            u12 = "useContext";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return l__readContext__24(p443, p444);
        end,
        useEffect = function(p445, p446) --[[ Name: useEffect, Line 2769 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), u173 (copy)
            u12 = "useEffect";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return u173(p445, p446);
        end,
        useImperativeHandle = function(p447, p448, p449) --[[ Name: useImperativeHandle, Line 2779 ]]
            -- upvalues: u12 (ref), l__console__7 (copy)
            u12 = "useImperativeHandle";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return updateImperativeHandle(p447, p448, p449);
        end,
        useLayoutEffect = function(p450, p451) --[[ Name: useLayoutEffect, Line 2789 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), u187 (copy)
            u12 = "useLayoutEffect";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return u187(p450, p451);
        end,
        useMemo = function(p452, p453) --[[ Line: 2800 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l__ReactCurrentDispatcher__53 (copy), u20 (ref)
            u12 = "useMemo";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            local l__current__107 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u20;
            local v454 = { pcall(updateMemo, p452, p453) };
            l__ReactCurrentDispatcher__53.current = l__current__107;
            if not v454[1] then
                error(v454[2]);
            end;
            return unpack(v454, 2);
        end,
        useReducer = function(p455, p456, p457) --[[ Name: useReducer, Line 2817 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l__ReactCurrentDispatcher__53 (copy), u20 (ref)
            u12 = "useReducer";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            local l__current__108 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u20;
            local v458, v459, v460 = pcall(updateReducer, p455, p456, p457);
            l__ReactCurrentDispatcher__53.current = l__current__108;
            if not v458 then
                error(v459);
            end;
            return v459, v460;
        end,
        useRef = function(p461) --[[ Name: useRef, Line 2838 ]]
            -- upvalues: u12 (ref), l__console__7 (copy)
            u12 = "useRef";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return updateRef(p461);
        end,
        useBinding = function(p462) --[[ Name: useBinding, Line 2845 ]]
            -- upvalues: u12 (ref), l__console__7 (copy)
            u12 = "useBinding";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return updateBinding(p462);
        end,
        useState = function(p463) --[[ Name: useState, Line 2851 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l__ReactCurrentDispatcher__53 (copy), u20 (ref)
            u12 = "useState";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            local l__current__109 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u20;
            local v464, v465, v466 = pcall(updateState, p463);
            l__ReactCurrentDispatcher__53.current = l__current__109;
            if not v464 then
                error(v465);
            end;
            return v465, v466;
        end,
        useDebugValue = function(p467, p468) --[[ Name: useDebugValue, Line 2866 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), u200 (copy)
            u12 = "useDebugValue";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return u200(p467, p468);
        end,
        useMutableSource = function(p469, p470, p471) --[[ Name: useMutableSource, Line 2884 ]]
            -- upvalues: u12 (ref), l__console__7 (copy)
            u12 = "useMutableSource";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return updateMutableSource(p469, p470, p471);
        end,
        useOpaqueIdentifier = function() --[[ Name: useOpaqueIdentifier, Line 2900 ]]
            -- upvalues: u12 (ref), l__console__7 (copy)
            u12 = "useOpaqueIdentifier";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return updateOpaqueIdentifier();
        end,
        unstable_isNewReconciler = l__enableNewReconciler__14
    };
    local _ = {
        readContext = function(p472, p473) --[[ Name: readContext, Line 2911 ]]
            -- upvalues: l__console__7 (copy), l__readContext__24 (copy)
            l__console__7.error("Context can only be read while React is rendering. In classes, you can read it in the render method or getDerivedStateFromProps. In function components, you can read it directly in the function body, but not inside Hooks like useReducer() or useMemo().");
            return l__readContext__24(p472, p473);
        end,
        useCallback = function(p474, p475) --[[ Name: useCallback, Line 2915 ]]
            -- upvalues: u12 (ref), l__console__7 (copy)
            u12 = "useCallback";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return updateCallback(p474, p475);
        end,
        useContext = function(p476, p477) --[[ Name: useContext, Line 2921 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l__readContext__24 (copy)
            u12 = "useContext";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return l__readContext__24(p476, p477);
        end,
        useEffect = function(p478, p479) --[[ Name: useEffect, Line 2927 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), u173 (copy)
            u12 = "useEffect";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return u173(p478, p479);
        end,
        useImperativeHandle = function(p480, p481, p482) --[[ Name: useImperativeHandle, Line 2937 ]]
            -- upvalues: u12 (ref), l__console__7 (copy)
            u12 = "useImperativeHandle";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return updateImperativeHandle(p480, p481, p482);
        end,
        useLayoutEffect = function(p483, p484) --[[ Name: useLayoutEffect, Line 2947 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), u187 (copy)
            u12 = "useLayoutEffect";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return u187(p483, p484);
        end,
        useMemo = function(p485, p486) --[[ Line: 2958 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l__ReactCurrentDispatcher__53 (copy), u20 (ref)
            u12 = "useMemo";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            local l__current__110 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u20;
            local v487 = { pcall(updateMemo, p485, p486) };
            l__ReactCurrentDispatcher__53.current = l__current__110;
            if not v487[1] then
                error(v487[2]);
            end;
            return unpack(v487, 2);
        end,
        useReducer = function(p488, p489, p490) --[[ Name: useReducer, Line 2975 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l__ReactCurrentDispatcher__53 (copy), u20 (ref)
            u12 = "useReducer";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            local l__current__111 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u20;
            local v491, v492, v493 = pcall(rerenderReducer, p488, p489, p490);
            l__ReactCurrentDispatcher__53.current = l__current__111;
            if not v491 then
                error(v492);
            end;
            return v492, v493;
        end,
        useRef = function(p494) --[[ Name: useRef, Line 2996 ]]
            -- upvalues: u12 (ref), l__console__7 (copy)
            u12 = "useRef";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return updateRef(p494);
        end,
        useBinding = function(p495) --[[ Name: useBinding, Line 3003 ]]
            -- upvalues: u12 (ref), l__console__7 (copy)
            u12 = "useBinding";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return updateBinding(p495);
        end,
        useState = function(p496) --[[ Name: useState, Line 3009 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), l__ReactCurrentDispatcher__53 (copy), u20 (ref)
            u12 = "useState";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            local l__current__112 = l__ReactCurrentDispatcher__53.current;
            l__ReactCurrentDispatcher__53.current = u20;
            local v497, v498, v499 = pcall(rerenderState, p496);
            l__ReactCurrentDispatcher__53.current = l__current__112;
            if not v497 then
                error(v498);
            end;
            return v498, v499;
        end,
        useDebugValue = function(p500, p501) --[[ Name: useDebugValue, Line 3024 ]]
            -- upvalues: u12 (ref), l__console__7 (copy), u200 (copy)
            u12 = "useDebugValue";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return u200(p500, p501);
        end,
        useMutableSource = function(p502, p503, p504) --[[ Name: useMutableSource, Line 3042 ]]
            -- upvalues: u12 (ref), l__console__7 (copy)
            u12 = "useMutableSource";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return updateMutableSource(p502, p503, p504);
        end,
        useOpaqueIdentifier = function() --[[ Name: useOpaqueIdentifier, Line 3058 ]]
            -- upvalues: u12 (ref), l__console__7 (copy)
            u12 = "useOpaqueIdentifier";
            l__console__7.error("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
            updateHookTypesDev();
            return rerenderOpaqueIdentifier();
        end,
        unstable_isNewReconciler = l__enableNewReconciler__14
    };
end;
function u5.renderWithHooks(p505, p506, p507, p508, p509, p510) --[[ Line: 3069 ]]
    -- upvalues: u6 (ref), u7 (ref), l____DEV____1 (copy), u13 (ref), u14 (ref), l__NoLanes__18 (copy), l__ReactCurrentDispatcher__53 (copy), u17 (ref), u16 (ref), u15 (ref), u232 (copy), u233 (copy), u11 (ref), l__Error__3 (copy), u8 (ref), u9 (ref), u18 (ref), u234 (copy), u231 (copy), u12 (ref), u10 (ref)
    u6 = p510;
    u7 = p506;
    if l____DEV____1 then
        local v511;
        if p505 == nil then
            v511 = nil;
        else
            v511 = p505._debugHookTypes;
        end;
        u13 = v511;
        u14 = 0;
    end;
    p506.memoizedState = nil;
    p506.updateQueue = nil;
    p506.lanes = l__NoLanes__18;
    if l____DEV____1 then
        if p505 == nil or p505.memoizedState == nil then
            if u13 == nil then
                l__ReactCurrentDispatcher__53.current = u15;
            else
                l__ReactCurrentDispatcher__53.current = u16;
            end;
        else
            l__ReactCurrentDispatcher__53.current = u17;
        end;
    else
        l__ReactCurrentDispatcher__53.current = (p505 == nil or p505.memoizedState == nil) and u232 or u233;
    end;
    local v512 = p507(p508, p509);
    local v513;
    if u11 then
        local v514 = 0;
        while true do
            u11 = false;
            if v514 >= 25 then
                error(l__Error__3.new("Too many re-renders. React limits the number of renders to prevent an infinite loop."));
            end;
            v514 = v514 + 1;
            u8 = nil;
            u9 = nil;
            p506.updateQueue = nil;
            if l____DEV____1 then
                u14 = 0;
            end;
            l__ReactCurrentDispatcher__53.current = l____DEV____1 and u18 or u234;
            v512 = p507(p508, p509);
            if not u11 then
                l__ReactCurrentDispatcher__53.current = u231;
                if l____DEV____1 then
                    p506._debugHookTypes = u13;
                end;
                if u8 == nil then
                    v513 = false;
                else
                    v513 = u8.next ~= nil;
                end;
                u6 = l__NoLanes__18;
                u7 = nil;
                u8 = nil;
                u9 = nil;
                if l____DEV____1 then
                    u12 = nil;
                    u13 = nil;
                    u14 = 0;
                end;
                u10 = false;
                if v513 then
                    error(l__Error__3.new("Rendered fewer hooks than expected. This may be caused by an accidental early return statement."));
                end;
                return v512;
            end;
        end;
    else
        l__ReactCurrentDispatcher__53.current = u231;
        if l____DEV____1 then
            p506._debugHookTypes = u13;
        end;
        if u8 == nil then
            v513 = false;
        else
            v513 = u8.next ~= nil;
        end;
        u6 = l__NoLanes__18;
        u7 = nil;
        u8 = nil;
        u9 = nil;
        if l____DEV____1 then
            u12 = nil;
            u13 = nil;
            u14 = 0;
        end;
        u10 = false;
        if v513 then
            error(l__Error__3.new("Rendered fewer hooks than expected. This may be caused by an accidental early return statement."));
        end;
        return v512;
    end;
end;
return u5;