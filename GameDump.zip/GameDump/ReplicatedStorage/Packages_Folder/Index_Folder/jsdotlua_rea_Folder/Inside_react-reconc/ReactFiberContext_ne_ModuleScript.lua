-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberContext.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
local l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2 = _G.__DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION__;
local v1 = require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local l__Object__3 = v1.Object;
local l__Error__4 = v1.Error;
local l__console__5 = require(script.Parent.Parent:WaitForChild("shared")).console;
require(script.Parent:WaitForChild("ReactInternalTypes"));
local v2 = require(script.Parent:WaitForChild("ReactFiberStack.new"));
local l__isFiberMounted__6 = require(script.Parent:WaitForChild("ReactFiberTreeReflection")).isFiberMounted;
local l__disableLegacyContext__7 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags.disableLegacyContext;
local l__ReactWorkTags__8 = require(script.Parent:WaitForChild("ReactWorkTags"));
local l__ClassComponent__9 = l__ReactWorkTags__8.ClassComponent;
local l__HostRoot__10 = l__ReactWorkTags__8.HostRoot;
local l__getComponentName__11 = require(script.Parent.Parent:WaitForChild("shared")).getComponentName;
local l__checkPropTypes__12 = require(script.Parent.Parent:WaitForChild("shared")).checkPropTypes;
local l__createCursor__13 = v2.createCursor;
local l__push__14 = v2.push;
local l__pop__15 = v2.pop;
local u3 = l____DEV____1 and {} or nil;
local u4 = {};
if l____DEV____1 then
    l__Object__3.freeze(u4);
end;
local u5 = l__createCursor__13(u4);
local u6 = l__createCursor__13(false);
local u7 = u4;
local u8 = nil;
local function v11(_, p9, p10) --[[ Line: 67 ]]
    -- upvalues: u8 (ref), u7 (ref), u5 (copy)
    if p10 and u8(p9) then
        return u7;
    else
        return u5.current;
    end;
end;
u8 = function(p12) --[[ Name: isContextProvider, Line 160 ]]
    if type(p12) == "function" then
        return false;
    else
        return p12.childContextTypes ~= nil;
    end;
end;
local function u20(p13, p14, p15) --[[ Line: 218 ]]
    -- upvalues: l____DEV____1 (copy), l__getComponentName__11 (copy), u3 (ref), l__console__5 (copy), l__Error__4 (copy), l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2 (copy), l__checkPropTypes__12 (copy), l__Object__3 (copy)
    local l__stateNode__16 = p13.stateNode;
    local l__childContextTypes__17 = p14.childContextTypes;
    if l__stateNode__16.getChildContext == nil or type(l__stateNode__16.getChildContext) ~= "function" then
        if l____DEV____1 then
            local v16 = l__getComponentName__11(p14) or "Unknown";
            if not u3[v16] then
                u3[v16] = true;
                l__console__5.error("%s.childContextTypes is specified but there is no getChildContext() method on the instance. You can either define getChildContext() on %s or remove childContextTypes from it.", v16, v16);
            end;
        end;
        return p15;
    end;
    local v17 = l__stateNode__16:getChildContext();
    for v18, _ in v17 do
        if l__childContextTypes__17[v18] == nil then
            local v19 = l__getComponentName__11(p14) or "Unknown";
            error(l__Error__4.new(string.format("%s.getChildContext(): key \"%s\" is not defined in childContextTypes.", v19, v18)));
        end;
    end;
    if l____DEV____1 or l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2 then
        l__checkPropTypes__12(l__childContextTypes__17, nil, v17, "child context", l__getComponentName__11(p14) or "Unknown");
    end;
    return l__Object__3.assign({}, p15, v17);
end;
return {
    emptyContextObject = u4,
    getUnmaskedContext = v11,
    cacheContext = function(p21, p22, p23) --[[ Name: cacheContext, Line 87 ]]
        local l__stateNode__18 = p21.stateNode;
        l__stateNode__18.__reactInternalMemoizedUnmaskedChildContext = p22;
        l__stateNode__18.__reactInternalMemoizedMaskedChildContext = p23;
    end,
    getMaskedContext = function(p24, p25) --[[ Name: getMaskedContext, Line 102 ]]
        -- upvalues: u4 (copy), l____DEV____1 (copy), l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2 (copy), l__getComponentName__11 (copy), l__checkPropTypes__12 (copy)
        local l__type__19 = p24.type;
        if type(l__type__19) == "function" then
            return p25;
        end;
        local l__contextTypes__20 = l__type__19.contextTypes;
        if not l__contextTypes__20 then
            return u4;
        end;
        local l__stateNode__21 = p24.stateNode;
        if l__stateNode__21 and l__stateNode__21.__reactInternalMemoizedUnmaskedChildContext == p25 then
            return l__stateNode__21.__reactInternalMemoizedMaskedChildContext;
        end;
        local v26 = {};
        for v27, _ in l__contextTypes__20 do
            v26[v27] = p25[v27];
        end;
        if l____DEV____1 or l____DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION____2 then
            l__checkPropTypes__12(l__contextTypes__20, nil, v26, "context", l__getComponentName__11(l__type__19) or "Unknown");
        end;
        if l__stateNode__21 then
            local l__stateNode__22 = p24.stateNode;
            l__stateNode__22.__reactInternalMemoizedUnmaskedChildContext = p25;
            l__stateNode__22.__reactInternalMemoizedMaskedChildContext = v26;
        end;
        return v26;
    end,
    hasContextChanged = function() --[[ Name: hasContextChanged, Line 151 ]]
        -- upvalues: l__disableLegacyContext__7 (copy), u6 (copy)
        if l__disableLegacyContext__7 then
            return false;
        else
            return u6.current;
        end;
    end,
    popContext = function(p28) --[[ Name: popContext, Line 175 ]]
        -- upvalues: l__pop__15 (copy), u6 (copy), u5 (copy)
        l__pop__15(u6, p28);
        l__pop__15(u5, p28);
    end,
    popTopLevelContextObject = function(p29) --[[ Name: popTopLevelContextObject, Line 185 ]]
        -- upvalues: l__pop__15 (copy), u6 (copy), u5 (copy)
        l__pop__15(u6, p29);
        l__pop__15(u5, p29);
    end,
    pushTopLevelContextObject = function(p30, p31, p32) --[[ Name: pushTopLevelContextObject, Line 195 ]]
        -- upvalues: u5 (copy), u4 (copy), l__Error__4 (copy), l__push__14 (copy), u6 (copy)
        if u5.current ~= u4 then
            error(l__Error__4.new("Unexpected context found on stack. This error is likely caused by a bug in React. Please file an issue."));
        end;
        l__push__14(u5, p31, p30);
        l__push__14(u6, p32, p30);
    end,
    processChildContext = u20,
    isContextProvider = u8,
    pushContextProvider = function(p33) --[[ Name: pushContextProvider, Line 278 ]]
        -- upvalues: u4 (copy), u7 (ref), u5 (copy), l__push__14 (copy), u6 (copy)
        local l__stateNode__23 = p33.stateNode;
        local v34 = l__stateNode__23 and l__stateNode__23.__reactInternalMemoizedMergedChildContext or u4;
        u7 = u5.current;
        l__push__14(u5, v34, p33);
        l__push__14(u6, u6.current, p33);
        return true;
    end,
    invalidateContextProvider = function(p35, p36, p37) --[[ Name: invalidateContextProvider, Line 301 ]]
        -- upvalues: l__Error__4 (copy), u20 (copy), u7 (ref), l__pop__15 (copy), u6 (copy), u5 (copy), l__push__14 (copy)
        local l__stateNode__24 = p35.stateNode;
        if not l__stateNode__24 then
            error(l__Error__4.new("Expected to have an instance by this point. This error is likely caused by a bug in React. Please file an issue."));
        end;
        if p37 then
            local v38 = u20(p35, p36, u7);
            l__stateNode__24.__reactInternalMemoizedMergedChildContext = v38;
            l__pop__15(u6, p35);
            l__pop__15(u5, p35);
            l__push__14(u5, v38, p35);
            l__push__14(u6, p37, p35);
        else
            l__pop__15(u6, p35);
            l__push__14(u6, p37, p35);
        end;
    end,
    findCurrentUnmaskedContext = function(p39) --[[ Name: findCurrentUnmaskedContext, Line 342 ]]
        -- upvalues: l__ClassComponent__9 (copy), l__isFiberMounted__6 (copy), l__Error__4 (copy), l__HostRoot__10 (copy)
        if p39.tag ~= l__ClassComponent__9 or not l__isFiberMounted__6(p39) then
            error(l__Error__4.new("Expected subtree parent to be a mounted class component. This error is likely caused by a bug in React. Please file an issue."));
        end;
        while p39.tag ~= l__HostRoot__10 do
            if p39.tag == l__ClassComponent__9 and p39.type.childContextTypes ~= nil then
                return p39.stateNode.__reactInternalMemoizedMergedChildContext;
            end;
            p39 = p39.return_;
            if p39 == nil then
                error(l__Error__4.new("Found unexpected detached subtree parent. This error is likely caused by a bug in React. Please file an issue."));
                return;
            end;
        end;
        return p39.stateNode.context;
    end
};