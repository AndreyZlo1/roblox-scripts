-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberCompleteWork.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__ReactFiberLane__1 = require(script.Parent:WaitForChild("ReactFiberLane"));
local l__OffscreenLane__2 = l__ReactFiberLane__1.OffscreenLane;
local l__ReactFiberHostConfig__3 = require(script.Parent:WaitForChild("ReactFiberHostConfig"));
require(script.Parent:WaitForChild("ReactFiberOffscreenComponent"));
local l__resetWorkInProgressVersions__4 = require(script.Parent:WaitForChild("ReactMutableSource.new")).resetWorkInProgressVersions;
local l__ReactWorkTags__5 = require(script.Parent:WaitForChild("ReactWorkTags"));
local l__IndeterminateComponent__6 = l__ReactWorkTags__5.IndeterminateComponent;
local l__FunctionComponent__7 = l__ReactWorkTags__5.FunctionComponent;
local l__ClassComponent__8 = l__ReactWorkTags__5.ClassComponent;
local l__HostRoot__9 = l__ReactWorkTags__5.HostRoot;
local l__HostComponent__10 = l__ReactWorkTags__5.HostComponent;
local l__HostText__11 = l__ReactWorkTags__5.HostText;
local l__HostPortal__12 = l__ReactWorkTags__5.HostPortal;
local l__ContextProvider__13 = l__ReactWorkTags__5.ContextProvider;
local l__ContextConsumer__14 = l__ReactWorkTags__5.ContextConsumer;
local l__ForwardRef__15 = l__ReactWorkTags__5.ForwardRef;
local l__Fragment__16 = l__ReactWorkTags__5.Fragment;
local l__Mode__17 = l__ReactWorkTags__5.Mode;
local l__Profiler__18 = l__ReactWorkTags__5.Profiler;
local l__SuspenseComponent__19 = l__ReactWorkTags__5.SuspenseComponent;
local l__SuspenseListComponent__20 = l__ReactWorkTags__5.SuspenseListComponent;
local l__MemoComponent__21 = l__ReactWorkTags__5.MemoComponent;
local l__SimpleMemoComponent__22 = l__ReactWorkTags__5.SimpleMemoComponent;
local l__LazyComponent__23 = l__ReactWorkTags__5.LazyComponent;
local l__IncompleteClassComponent__24 = l__ReactWorkTags__5.IncompleteClassComponent;
local l__FundamentalComponent__25 = l__ReactWorkTags__5.FundamentalComponent;
local l__ScopeComponent__26 = l__ReactWorkTags__5.ScopeComponent;
local l__Block__27 = l__ReactWorkTags__5.Block;
local l__OffscreenComponent__28 = l__ReactWorkTags__5.OffscreenComponent;
local l__LegacyHiddenComponent__29 = l__ReactWorkTags__5.LegacyHiddenComponent;
require(script.Parent:WaitForChild("ReactFiberSuspenseComponent.new"));
local l__ReactTypeOfMode__30 = require(script.Parent:WaitForChild("ReactTypeOfMode"));
local l__NoMode__31 = l__ReactTypeOfMode__30.NoMode;
local l__ConcurrentMode__32 = l__ReactTypeOfMode__30.ConcurrentMode;
local l__BlockingMode__33 = l__ReactTypeOfMode__30.BlockingMode;
local l__ProfileMode__34 = l__ReactTypeOfMode__30.ProfileMode;
local l__ReactFiberFlags__35 = require(script.Parent:WaitForChild("ReactFiberFlags"));
local l__Ref__36 = l__ReactFiberFlags__35.Ref;
local l__Update__37 = l__ReactFiberFlags__35.Update;
local l__Callback__38 = l__ReactFiberFlags__35.Callback;
local l__Passive__39 = l__ReactFiberFlags__35.Passive;
local l__Deletion__40 = l__ReactFiberFlags__35.Deletion;
local l__NoFlags__41 = l__ReactFiberFlags__35.NoFlags;
local l__DidCapture__42 = l__ReactFiberFlags__35.DidCapture;
local l__Snapshot__43 = l__ReactFiberFlags__35.Snapshot;
local l__MutationMask__44 = l__ReactFiberFlags__35.MutationMask;
local l__LayoutMask__45 = l__ReactFiberFlags__35.LayoutMask;
local l__PassiveMask__46 = l__ReactFiberFlags__35.PassiveMask;
local l__StaticMask__47 = l__ReactFiberFlags__35.StaticMask;
local l__PerformedWork__48 = l__ReactFiberFlags__35.PerformedWork;
local l__invariant__49 = require(script.Parent.Parent:WaitForChild("shared")).invariant;
local l__createInstance__50 = l__ReactFiberHostConfig__3.createInstance;
local l__createTextInstance__51 = l__ReactFiberHostConfig__3.createTextInstance;
local l__appendInitialChild__52 = l__ReactFiberHostConfig__3.appendInitialChild;
local l__finalizeInitialChildren__53 = l__ReactFiberHostConfig__3.finalizeInitialChildren;
local l__prepareUpdate__54 = l__ReactFiberHostConfig__3.prepareUpdate;
local l__supportsMutation__55 = l__ReactFiberHostConfig__3.supportsMutation;
local l__supportsPersistence__56 = l__ReactFiberHostConfig__3.supportsPersistence;
local l__createContainerChildSet__57 = l__ReactFiberHostConfig__3.createContainerChildSet;
local l__finalizeContainerChildren__58 = l__ReactFiberHostConfig__3.finalizeContainerChildren;
local l__preparePortalMount__59 = l__ReactFiberHostConfig__3.preparePortalMount;
local v1 = require(script.Parent:WaitForChild("ReactFiberHostContext.new"));
local l__getRootHostContainer__60 = v1.getRootHostContainer;
local l__popHostContext__61 = v1.popHostContext;
local l__getHostContext__62 = v1.getHostContext;
local l__popHostContainer__63 = v1.popHostContainer;
local v2 = require(script.Parent:WaitForChild("ReactFiberSuspenseContext.new"));
local l__popSuspenseContext__64 = v2.popSuspenseContext;
local l__suspenseStackCursor__65 = v2.suspenseStackCursor;
local l__InvisibleParentSuspenseContext__66 = v2.InvisibleParentSuspenseContext;
local l__hasSuspenseContext__67 = v2.hasSuspenseContext;
local v3 = require(script.Parent:WaitForChild("ReactFiberContext.new"));
local l__isContextProvider__68 = v3.isContextProvider;
local l__popContext__69 = v3.popContext;
local l__popTopLevelContextObject__70 = v3.popTopLevelContextObject;
local l__popProvider__71 = require(script.Parent:WaitForChild("ReactFiberNewContext.new")).popProvider;
local v4 = require(script.Parent:WaitForChild("ReactFiberHydrationContext.new"));
local l__prepareToHydrateHostSuspenseInstance__72 = v4.prepareToHydrateHostSuspenseInstance;
local l__popHydrationState__73 = v4.popHydrationState;
local l__resetHydrationState__74 = v4.resetHydrationState;
local l__prepareToHydrateHostInstance__75 = v4.prepareToHydrateHostInstance;
local l__prepareToHydrateHostTextInstance__76 = v4.prepareToHydrateHostTextInstance;
local l__ReactFeatureFlags__77 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags;
local l__enableSchedulerTracing__78 = l__ReactFeatureFlags__77.enableSchedulerTracing;
local l__enableSuspenseCallback__79 = l__ReactFeatureFlags__77.enableSuspenseCallback;
local l__enableSuspenseServerRenderer__80 = l__ReactFeatureFlags__77.enableSuspenseServerRenderer;
local l__enableFundamentalAPI__81 = l__ReactFeatureFlags__77.enableFundamentalAPI;
local l__enableProfilerTimer__82 = l__ReactFeatureFlags__77.enableProfilerTimer;
local u5 = require(script.Parent:WaitForChild("ReactFiberWorkLoop.new"));
local l__popRenderLanes__83 = u5.popRenderLanes;
local l__markSpawnedWork__84 = u5.markSpawnedWork;
local l__renderDidSuspend__85 = u5.renderDidSuspend;
local l__renderDidSuspendDelayIfPossible__86 = u5.renderDidSuspendDelayIfPossible;
local l__NoLanes__87 = l__ReactFiberLane__1.NoLanes;
local l__includesSomeLane__88 = l__ReactFiberLane__1.includesSomeLane;
local l__mergeLanes__89 = l__ReactFiberLane__1.mergeLanes;
local l__transferActualDuration__90 = require(script.Parent:WaitForChild("ReactProfilerTimer.new")).transferActualDuration;
local function u9(p6, p7) --[[ Line: 197 ]]
    -- upvalues: l__MutationMask__44 (copy), l__NoFlags__41 (copy)
    local v8;
    if p6 == nil then
        v8 = false;
    else
        v8 = p6.child == p7.child;
    end;
    if v8 then
        return true;
    end;
    local l__child__91 = p7.child;
    while l__child__91 ~= nil do
        if bit32.band(l__child__91.flags, l__MutationMask__44) ~= l__NoFlags__41 then
            return false;
        end;
        if bit32.band(l__child__91.subtreeFlags, l__MutationMask__44) ~= l__NoFlags__41 then
            return false;
        end;
        l__child__91 = l__child__91.sibling;
    end;
    return true;
end;
local u10 = nil;
local u11 = nil;
local u12 = nil;
local u13;
if l__supportsMutation__55 then
    u12 = function(_, p14, p15, p16) --[[ Name: updateHostText, Line 305 ]]
        -- upvalues: l__Update__37 (copy)
        if p15 ~= p16 then
            p14.flags = bit32.bor(p14.flags, l__Update__37);
        end;
    end;
    u11 = function(p17, p18, p19, p20, p21) --[[ Name: updateHostComponent, Line 264 ]]
        -- upvalues: l__getHostContext__62 (copy), l__prepareUpdate__54 (copy), l__Update__37 (copy)
        local l__memoizedProps__92 = p17.memoizedProps;
        if l__memoizedProps__92 == p20 then
        else
            local v22 = l__prepareUpdate__54(p18.stateNode, p19, l__memoizedProps__92, p20, p21, (l__getHostContext__62()));
            p18.updateQueue = v22;
            if v22 then
                p18.flags = bit32.bor(p18.flags, l__Update__37);
            end;
        end;
    end;
    u13 = function(_, _) --[[ Line: 261 ]] end;
    u10 = function(p23, p24, _, _) --[[ Line: 223 ]]
        -- upvalues: l__HostComponent__10 (copy), l__HostText__11 (copy), l__appendInitialChild__52 (copy), l__enableFundamentalAPI__81 (copy), l__FundamentalComponent__25 (copy), l__HostPortal__12 (copy)
        local l__child__93 = p24.child;
        while true do
            while true do
                if l__child__93 == nil then
                    return;
                end;
                if l__child__93.tag == l__HostComponent__10 or l__child__93.tag == l__HostText__11 then
                    break;
                end;
                if l__enableFundamentalAPI__81 and l__child__93.tag == l__FundamentalComponent__25 then
                    l__appendInitialChild__52(p23, l__child__93.stateNode.instance);
                    if l__child__93 == p24 then
                        return;
                    end;
                    while l__child__93.sibling == nil do
                        if l__child__93.return_ == nil or l__child__93.return_ == p24 then
                            return;
                        end;
                        l__child__93 = l__child__93.return_;
                    end;
                    l__child__93.sibling.return_ = l__child__93.return_;
                    l__child__93 = l__child__93.sibling;
                end;
                if l__child__93.tag == l__HostPortal__12 or l__child__93.child == nil then
                    if l__child__93 == p24 then
                        return;
                    end;
                    while l__child__93.sibling == nil do
                        if l__child__93.return_ == nil or l__child__93.return_ == p24 then
                            return;
                        end;
                        l__child__93 = l__child__93.return_;
                    end;
                    l__child__93.sibling.return_ = l__child__93.return_;
                    l__child__93 = l__child__93.sibling;
                end;
                l__child__93.child.return_ = l__child__93;
                l__child__93 = l__child__93.child;
            end;
            l__appendInitialChild__52(p23, l__child__93.stateNode);
            if l__child__93 == p24 then
                return;
            end;
            while l__child__93.sibling == nil do
                if l__child__93.return_ == nil or l__child__93.return_ == p24 then
                    return;
                end;
                l__child__93 = l__child__93.return_;
            end;
            l__child__93.sibling.return_ = l__child__93.return_;
            l__child__93 = l__child__93.sibling;
        end;
    end;
elseif l__supportsPersistence__56 then
    u13 = function(p25, p26) --[[ Name: updateHostContainer, Line 507 ]]
        -- upvalues: u9 (copy), l__createContainerChildSet__57 (copy), l__Update__37 (copy), l__finalizeContainerChildren__58 (copy)
        local l__stateNode__94 = p26.stateNode;
        if u9(p25, p26) then
        else
            local l__containerInfo__95 = l__stateNode__94.containerInfo;
            local v27 = l__createContainerChildSet__57(l__containerInfo__95);
            print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            print("UNIMPLEMENTED ERROR: " .. tostring("appendAllChildrenToContainer"));
            error("FIXME (roblox): appendAllChildrenToContainer is unimplemented", 2);
            l__stateNode__94.pendingChildren = v27;
            p26.flags = bit32.bor(p26.flags, l__Update__37);
            l__finalizeContainerChildren__58(l__containerInfo__95, v27);
        end;
    end;
    u10 = function(_, _, _, _) --[[ Line: 318 ]]
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        print("UNIMPLEMENTED ERROR: " .. tostring("appendAllChildren"));
        error("FIXME (roblox): appendAllChildren is unimplemented", 2);
    end;
else
    u13 = function(_, _) --[[ Line: 623 ]] end;
end;
local function u42(p28) --[[ Line: 716 ]]
    -- upvalues: l__NoLanes__87 (copy), l__NoFlags__41 (copy), l__enableProfilerTimer__82 (copy), l__ProfileMode__34 (copy), l__NoMode__31 (copy), l__mergeLanes__89 (copy), l__StaticMask__47 (copy)
    local v29;
    if p28.alternate == nil then
        v29 = false;
    else
        v29 = p28.alternate.child == p28.child;
    end;
    local v30 = l__NoLanes__87;
    local v31 = l__NoFlags__41;
    if v29 then
        if l__enableProfilerTimer__82 and bit32.band(p28.mode, l__ProfileMode__34) ~= l__NoMode__31 then
            local l__selfBaseDuration__96 = p28.selfBaseDuration;
            local l__child__97 = p28.child;
            while l__child__97 ~= nil do
                v30 = l__mergeLanes__89(v30, l__mergeLanes__89(l__child__97.lanes, l__child__97.childLanes));
                local v32 = bit32.band(l__child__97.subtreeFlags, l__StaticMask__47);
                local v33 = bit32.bor(v31, v32);
                local v34 = bit32.band(l__child__97.flags, l__StaticMask__47);
                v31 = bit32.bor(v33, v34);
                l__selfBaseDuration__96 = l__selfBaseDuration__96 + l__child__97.treeBaseDuration;
                l__child__97 = l__child__97.sibling;
            end;
            p28.treeBaseDuration = l__selfBaseDuration__96;
        else
            local l__child__98 = p28.child;
            while l__child__98 ~= nil do
                local v35 = bit32.bor(l__child__98.lanes, l__child__98.childLanes);
                v30 = bit32.bor(v30, v35);
                local v36 = bit32.band(l__child__98.subtreeFlags, l__StaticMask__47);
                local v37 = bit32.bor(v31, v36);
                local v38 = bit32.band(l__child__98.flags, l__StaticMask__47);
                v31 = bit32.bor(v37, v38);
                l__child__98.return_ = p28;
                l__child__98 = l__child__98.sibling;
            end;
        end;
        p28.subtreeFlags = bit32.bor(p28.subtreeFlags, v31);
    else
        if l__enableProfilerTimer__82 and bit32.band(p28.mode, l__ProfileMode__34) ~= l__NoMode__31 then
            local l__actualDuration__99 = p28.actualDuration;
            local l__selfBaseDuration__100 = p28.selfBaseDuration;
            local l__child__101 = p28.child;
            while l__child__101 ~= nil do
                v30 = l__mergeLanes__89(v30, l__mergeLanes__89(l__child__101.lanes, l__child__101.childLanes));
                local v39 = bit32.bor(v31, l__child__101.subtreeFlags);
                v31 = bit32.bor(v39, l__child__101.flags);
                l__actualDuration__99 = l__actualDuration__99 + l__child__101.actualDuration;
                l__selfBaseDuration__100 = l__selfBaseDuration__100 + l__child__101.treeBaseDuration;
                l__child__101 = l__child__101.sibling;
            end;
            p28.actualDuration = l__actualDuration__99;
            p28.treeBaseDuration = l__selfBaseDuration__100;
        else
            local l__child__102 = p28.child;
            while l__child__102 ~= nil do
                local v40 = bit32.bor(l__child__102.lanes, l__child__102.childLanes);
                v30 = bit32.bor(v30, v40);
                local v41 = bit32.bor(v31, l__child__102.subtreeFlags);
                v31 = bit32.bor(v41, l__child__102.flags);
                l__child__102.return_ = p28;
                l__child__102 = l__child__102.sibling;
            end;
        end;
        p28.subtreeFlags = bit32.bor(p28.subtreeFlags, v31);
    end;
    p28.childLanes = v30;
    return v29;
end;
return {
    completeWork = function(p43, p44, p45) --[[ Name: completeWork, Line 855 ]]
        -- upvalues: l__IndeterminateComponent__6 (copy), l__LazyComponent__23 (copy), l__SimpleMemoComponent__22 (copy), l__FunctionComponent__7 (copy), l__ForwardRef__15 (copy), l__Fragment__16 (copy), l__Mode__17 (copy), l__ContextConsumer__14 (copy), l__MemoComponent__21 (copy), u42 (copy), l__ClassComponent__8 (copy), l__isContextProvider__68 (copy), l__popContext__69 (copy), l__HostRoot__9 (copy), l__popHostContainer__63 (copy), l__popTopLevelContextObject__70 (copy), l__resetWorkInProgressVersions__4 (copy), l__popHydrationState__73 (copy), l__Update__37 (copy), l__Snapshot__43 (copy), u13 (ref), l__HostComponent__10 (copy), l__popHostContext__61 (copy), l__getRootHostContainer__60 (copy), u11 (ref), l__Ref__36 (copy), l__invariant__49 (copy), l__getHostContext__62 (copy), l__prepareToHydrateHostInstance__75 (copy), l__createInstance__50 (copy), u10 (ref), l__finalizeInitialChildren__53 (copy), l__HostText__11 (copy), u12 (ref), l__prepareToHydrateHostTextInstance__76 (copy), l__createTextInstance__51 (copy), l__Profiler__18 (copy), l__Callback__38 (copy), l__Passive__39 (copy), l__PerformedWork__48 (copy), l__NoFlags__41 (copy), l__LayoutMask__45 (copy), l__Deletion__40 (copy), l__PassiveMask__46 (copy), l__SuspenseComponent__19 (copy), l__popSuspenseContext__64 (copy), l__enableSuspenseServerRenderer__80 (copy), l__prepareToHydrateHostSuspenseInstance__72 (copy), l__enableSchedulerTracing__78 (copy), l__markSpawnedWork__84 (copy), l__OffscreenLane__2 (copy), l__enableProfilerTimer__82 (copy), l__ProfileMode__34 (copy), l__NoMode__31 (copy), l__resetHydrationState__74 (copy), l__DidCapture__42 (copy), l__transferActualDuration__90 (copy), l__BlockingMode__33 (copy), l__hasSuspenseContext__67 (copy), l__suspenseStackCursor__65 (copy), l__InvisibleParentSuspenseContext__66 (copy), l__renderDidSuspend__85 (copy), l__renderDidSuspendDelayIfPossible__86 (copy), l__supportsPersistence__56 (copy), l__supportsMutation__55 (copy), l__enableSuspenseCallback__79 (copy), l__HostPortal__12 (copy), l__preparePortalMount__59 (copy), l__ContextProvider__13 (copy), l__popProvider__71 (copy), l__IncompleteClassComponent__24 (copy), l__SuspenseListComponent__20 (copy), l__FundamentalComponent__25 (copy), l__ScopeComponent__26 (copy), l__Block__27 (copy), l__OffscreenComponent__28 (copy), l__LegacyHiddenComponent__29 (copy), l__popRenderLanes__83 (copy), l__includesSomeLane__88 (copy), u5 (copy), l__ConcurrentMode__32 (copy)
        local l__pendingProps__103 = p44.pendingProps;
        if p44.tag == l__IndeterminateComponent__6 or (p44.tag == l__LazyComponent__23 or (p44.tag == l__SimpleMemoComponent__22 or (p44.tag == l__FunctionComponent__7 or (p44.tag == l__ForwardRef__15 or (p44.tag == l__Fragment__16 or (p44.tag == l__Mode__17 or (p44.tag == l__ContextConsumer__14 or p44.tag == l__MemoComponent__21))))))) then
            u42(p44);
            return nil;
        end;
        if p44.tag == l__ClassComponent__8 then
            if l__isContextProvider__68(p44.type) then
                l__popContext__69(p44);
            end;
            u42(p44);
            return nil;
        end;
        if p44.tag == l__HostRoot__9 then
            l__popHostContainer__63(p44);
            l__popTopLevelContextObject__70(p44);
            l__resetWorkInProgressVersions__4();
            local l__stateNode__104 = p44.stateNode;
            if l__stateNode__104.pendingContext then
                l__stateNode__104.context = l__stateNode__104.pendingContext;
                l__stateNode__104.pendingContext = nil;
            end;
            if p43 == nil or p43.child == nil then
                if l__popHydrationState__73(p44) then
                    p44.flags = bit32.bor(p44.flags, l__Update__37);
                elseif not l__stateNode__104.hydrate then
                    p44.flags = bit32.bor(p44.flags, l__Snapshot__43);
                end;
            end;
            u13(p43, p44);
            u42(p44);
            return nil;
        end;
        if p44.tag == l__HostComponent__10 then
            l__popHostContext__61(p44);
            local v46 = l__getRootHostContainer__60();
            local l__type__105 = p44.type;
            if p43 == nil or p44.stateNode == nil then
                if not l__pendingProps__103 then
                    l__invariant__49(p44.stateNode ~= nil, "We must have new props for new mounts. This error is likely caused by a bug in React. Please file an issue.");
                    u42(p44);
                    return nil;
                end;
                local v47 = l__getHostContext__62();
                if l__popHydrationState__73(p44) then
                    if l__prepareToHydrateHostInstance__75(p44, v46, v47) then
                        p44.flags = bit32.bor(p44.flags, l__Update__37);
                    end;
                else
                    local v48 = l__createInstance__50(l__type__105, l__pendingProps__103, v46, v47, p44);
                    u10(v48, p44, false, false);
                    p44.stateNode = v48;
                    if l__finalizeInitialChildren__53(v48, l__type__105, l__pendingProps__103, v46, v47) then
                        p44.flags = bit32.bor(p44.flags, l__Update__37);
                    end;
                end;
                if p44.ref ~= nil then
                    p44.flags = bit32.bor(p44.flags, l__Ref__36);
                end;
            else
                u11(p43, p44, l__type__105, l__pendingProps__103, v46);
                if p43.ref ~= p44.ref then
                    p44.flags = bit32.bor(p44.flags, l__Ref__36);
                end;
            end;
            u42(p44);
            return nil;
        end;
        if p44.tag == l__HostText__11 then
            if p43 and p44.stateNode ~= nil then
                u12(p43, p44, p43.memoizedProps, l__pendingProps__103);
            else
                if typeof(l__pendingProps__103) ~= "string" then
                    l__invariant__49(p44.stateNode ~= nil, "We must have new props for new mounts. This error is likely caused by a bug in React. Please file an issue.");
                end;
                local v49 = l__getRootHostContainer__60();
                local v50 = l__getHostContext__62();
                if l__popHydrationState__73(p44) then
                    if l__prepareToHydrateHostTextInstance__76(p44) then
                        p44.flags = bit32.bor(p44.flags, l__Update__37);
                    end;
                else
                    p44.stateNode = l__createTextInstance__51(l__pendingProps__103, v49, v50, p44);
                end;
            end;
            u42(p44);
            return nil;
        end;
        if p44.tag ~= l__Profiler__18 then
            if p44.tag == l__SuspenseComponent__19 then
                l__popSuspenseContext__64(p44);
                local l__memoizedState__106 = p44.memoizedState;
                if l__enableSuspenseServerRenderer__80 and (l__memoizedState__106 ~= nil and l__memoizedState__106.dehydrated ~= nil) then
                    if p43 == nil then
                        l__invariant__49(l__popHydrationState__73(p44), "A dehydrated suspense component was completed without a hydrated node. This is probably a bug in React.");
                        l__prepareToHydrateHostSuspenseInstance__72(p44);
                        if l__enableSchedulerTracing__78 then
                            l__markSpawnedWork__84(l__OffscreenLane__2);
                        end;
                        u42(p44);
                        if l__enableProfilerTimer__82 and bit32.band(p44.mode, l__ProfileMode__34) ~= l__NoMode__31 and l__memoizedState__106 ~= nil then
                            local l__child__107 = p44.child;
                            if l__child__107 ~= nil then
                                p44.treeBaseDuration = l__child__107.treeBaseDuration;
                            end;
                        end;
                        return nil;
                    else
                        l__resetHydrationState__74();
                        if bit32.band(p44.flags, l__DidCapture__42) == l__NoFlags__41 then
                            p44.memoizedState = nil;
                        end;
                        p44.flags = bit32.bor(p44.flags, l__Update__37);
                        u42(p44);
                        if l__enableProfilerTimer__82 and bit32.band(p44.mode, l__ProfileMode__34) ~= l__NoMode__31 and l__memoizedState__106 ~= nil then
                            local l__child__108 = p44.child;
                            if l__child__108 ~= nil then
                                p44.treeBaseDuration = p44.treeBaseDuration - l__child__108.treeBaseDuration;
                            end;
                        end;
                        return nil;
                    end;
                else
                    if bit32.band(p44.flags, l__DidCapture__42) ~= l__NoFlags__41 then
                        p44.lanes = p45;
                        if l__enableProfilerTimer__82 and bit32.band(p44.mode, l__ProfileMode__34) ~= l__NoMode__31 then
                            l__transferActualDuration__90(p44);
                        end;
                        return p44;
                    end;
                    local v51 = l__memoizedState__106 ~= nil;
                    local v52 = false;
                    if p43 == nil then
                        if p44.memoizedProps.fallback ~= nil then
                            l__popHydrationState__73(p44);
                        end;
                    else
                        v52 = p43.memoizedState ~= nil;
                    end;
                    if v51 and (not v52 and bit32.band(p44.mode, l__BlockingMode__33) ~= l__NoMode__31) then
                        local v53;
                        if p43 == nil then
                            v53 = p44.memoizedProps.unstable_avoidThisFallback ~= true;
                        else
                            v53 = false;
                        end;
                        if v53 or l__hasSuspenseContext__67(l__suspenseStackCursor__65.current, l__InvisibleParentSuspenseContext__66) then
                            l__renderDidSuspend__85();
                        else
                            l__renderDidSuspendDelayIfPossible__86();
                        end;
                    end;
                    if l__supportsPersistence__56 and v51 then
                        p44.flags = bit32.bor(p44.flags, l__Update__37);
                    end;
                    if l__supportsMutation__55 and (v51 or v52) then
                        p44.flags = bit32.bor(p44.flags, l__Update__37);
                    end;
                    if l__enableSuspenseCallback__79 and (p44.updateQueue ~= nil and p44.memoizedProps.suspenseCallback ~= nil) then
                        p44.flags = bit32.bor(p44.flags, l__Update__37);
                    end;
                    u42(p44);
                    if l__enableProfilerTimer__82 and (bit32.band(p44.mode, l__ProfileMode__34) ~= l__NoMode__31 and v51) then
                        local l__child__109 = p44.child;
                        if l__child__109 ~= nil then
                            p44.treeBaseDuration = p44.treeBaseDuration - l__child__109.treeBaseDuration;
                        end;
                    end;
                    return nil;
                end;
            elseif p44.tag == l__HostPortal__12 then
                l__popHostContainer__63(p44);
                u13(p43, p44);
                if p43 == nil then
                    l__preparePortalMount__59(p44.stateNode.containerInfo);
                end;
                u42(p44);
                return nil;
            elseif p44.tag == l__ContextProvider__13 then
                l__popProvider__71(p44);
                u42(p44);
                return nil;
            elseif p44.tag == l__IncompleteClassComponent__24 then
                if l__isContextProvider__68(p44.type) then
                    l__popContext__69(p44);
                end;
                u42(p44);
                return nil;
            else
                if p44.tag == l__SuspenseListComponent__20 then
                    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    print("UNIMPLEMENTED ERROR: " .. tostring("SuspenseListComponent"));
                    error("FIXME (roblox): SuspenseListComponent is unimplemented", 2);
                elseif p44.tag == l__FundamentalComponent__25 then
                    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    print("UNIMPLEMENTED ERROR: " .. tostring("FundamentalComponent"));
                    error("FIXME (roblox): FundamentalComponent is unimplemented", 2);
                elseif p44.tag == l__ScopeComponent__26 then
                    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    print("UNIMPLEMENTED ERROR: " .. tostring("ScopeComponent"));
                    error("FIXME (roblox): ScopeComponent is unimplemented", 2);
                elseif p44.tag == l__Block__27 then
                    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    print("UNIMPLEMENTED ERROR: " .. tostring("Block"));
                    error("FIXME (roblox): Block is unimplemented", 2);
                elseif p44.tag == l__OffscreenComponent__28 or p44.tag == l__LegacyHiddenComponent__29 then
                    l__popRenderLanes__83(p44);
                    local v54 = p44.memoizedState ~= nil;
                    if p43 ~= nil and (p43.memoizedState ~= nil ~= v54 and l__pendingProps__103.mode ~= "unstable-defer-without-hiding") then
                        p44.flags = bit32.bor(p44.flags, l__Update__37);
                    end;
                    if not v54 or (l__includesSomeLane__88(u5.subtreeRenderLanes, l__OffscreenLane__2) or bit32.band(p44.mode, l__ConcurrentMode__32) == l__NoMode__31) then
                        u42(p44);
                    end;
                    return nil;
                end;
                l__invariant__49(false, "Unknown unit of work tag (%s). This error is likely caused by a bug in React. Please file an issue.", (tostring(p44.tag)));
                return nil;
            end;
        end;
        if not u42(p44) then
            local v55 = l__Update__37;
            local v56 = l__Callback__38;
            local v57 = l__Passive__39;
            local l__subtreeFlags__110 = p44.subtreeFlags;
            local l__flags__111 = p44.flags;
            local v58;
            if bit32.band(l__flags__111, l__PerformedWork__48) == l__NoFlags__41 and bit32.band(l__subtreeFlags__110, l__PerformedWork__48) == l__NoFlags__41 then
                v58 = l__flags__111;
            else
                v58 = bit32.bor(l__flags__111, v55);
            end;
            local v59 = bit32.bor(l__LayoutMask__45, l__Deletion__40);
            if bit32.band(l__flags__111, v59) == l__NoFlags__41 then
                local v60 = bit32.bor(l__LayoutMask__45, l__Deletion__40);
                if bit32.band(l__subtreeFlags__110, v60) == l__NoFlags__41 then
                    if bit32.band(l__flags__111, l__PassiveMask__46) ~= l__NoFlags__41 or bit32.band(l__subtreeFlags__110, l__PassiveMask__46) ~= l__NoFlags__41 then
                        v58 = bit32.bor(v58, v57);
                    end;
                    p44.flags = v58;
                end;
            end;
            v58 = bit32.bor(v58, v56);
            if bit32.band(l__flags__111, l__PassiveMask__46) ~= l__NoFlags__41 or bit32.band(l__subtreeFlags__110, l__PassiveMask__46) ~= l__NoFlags__41 then
                v58 = bit32.bor(v58, v57);
            end;
            p44.flags = v58;
        end;
        return nil;
    end
};