-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactCurrentFiber
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__ReactSharedInternals__2 = require(script.Parent.Parent:WaitForChild("shared")).ReactSharedInternals;
local l__getStackByFiberInDevAndProd__3 = require(script.Parent:WaitForChild("ReactFiberComponentStack")).getStackByFiberInDevAndProd;
local l__getComponentName__4 = require(script.Parent.Parent:WaitForChild("shared")).getComponentName;
local l__ReactDebugCurrentFrame__5 = l__ReactSharedInternals__2.ReactDebugCurrentFrame;
local u1 = {
    current = nil,
    isRendering = false
};
function u1.getCurrentFiberOwnerNameInDevOrNull() --[[ Line: 36 ]]
    -- upvalues: l____DEV____1 (copy), u1 (copy), l__getComponentName__4 (copy)
    if l____DEV____1 then
        if u1.current == nil then
            return nil;
        end;
        local l___debugOwner__6 = u1.current._debugOwner;
        if l___debugOwner__6 then
            return l__getComponentName__4(l___debugOwner__6.type);
        end;
    end;
    return nil;
end;
local function u2() --[[ Line: 50 ]]
    -- upvalues: l____DEV____1 (copy), u1 (copy), l__getStackByFiberInDevAndProd__3 (copy)
    return not l____DEV____1 and "" or (u1.current == nil and "" or l__getStackByFiberInDevAndProd__3(u1.current));
end;
function u1.resetCurrentFiber() --[[ Line: 63 ]]
    -- upvalues: l____DEV____1 (copy), l__ReactDebugCurrentFrame__5 (copy), u1 (copy)
    if l____DEV____1 then
        l__ReactDebugCurrentFrame__5.getCurrentStack = nil;
        u1.current = nil;
        u1.isRendering = false;
    end;
end;
function u1.setCurrentFiber(p3) --[[ Line: 72 ]]
    -- upvalues: l____DEV____1 (copy), l__ReactDebugCurrentFrame__5 (copy), u2 (copy), u1 (copy)
    if l____DEV____1 then
        l__ReactDebugCurrentFrame__5.getCurrentStack = u2;
        u1.current = p3;
        u1.isRendering = false;
    end;
end;
function u1.setIsRendering(p4) --[[ Line: 81 ]]
    -- upvalues: l____DEV____1 (copy), u1 (copy)
    if l____DEV____1 then
        u1.isRendering = p4;
    end;
end;
function u1.getIsRendering() --[[ Line: 87 ]]
    -- upvalues: l____DEV____1 (copy), u1 (copy)
    if l____DEV____1 then
        return u1.isRendering;
    else
        return false;
    end;
end;
return u1;