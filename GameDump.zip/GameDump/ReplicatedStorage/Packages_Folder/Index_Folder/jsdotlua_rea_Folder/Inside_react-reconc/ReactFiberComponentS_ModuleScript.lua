-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberComponentStack
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent:WaitForChild("luau-polyfill"));
require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__ReactWorkTags__1 = require(script.Parent:WaitForChild("ReactWorkTags"));
local l__HostComponent__2 = l__ReactWorkTags__1.HostComponent;
local l__LazyComponent__3 = l__ReactWorkTags__1.LazyComponent;
local l__SuspenseComponent__4 = l__ReactWorkTags__1.SuspenseComponent;
local l__SuspenseListComponent__5 = l__ReactWorkTags__1.SuspenseListComponent;
local l__FunctionComponent__6 = l__ReactWorkTags__1.FunctionComponent;
local l__IndeterminateComponent__7 = l__ReactWorkTags__1.IndeterminateComponent;
local l__ForwardRef__8 = l__ReactWorkTags__1.ForwardRef;
local l__SimpleMemoComponent__9 = l__ReactWorkTags__1.SimpleMemoComponent;
local l__ClassComponent__10 = l__ReactWorkTags__1.ClassComponent;
local l__ReactComponentStackFrame__11 = require(script.Parent.Parent:WaitForChild("shared")).ReactComponentStackFrame;
local l__describeBuiltInComponentFrame__12 = l__ReactComponentStackFrame__11.describeBuiltInComponentFrame;
local l__describeFunctionComponentFrame__13 = l__ReactComponentStackFrame__11.describeFunctionComponentFrame;
local l__describeClassComponentFrame__14 = l__ReactComponentStackFrame__11.describeClassComponentFrame;
local function u4(p1) --[[ Line: 37 ]]
    -- upvalues: l__HostComponent__2 (copy), l__describeBuiltInComponentFrame__12 (copy), l__LazyComponent__3 (copy), l__SuspenseComponent__4 (copy), l__SuspenseListComponent__5 (copy), l__FunctionComponent__6 (copy), l__IndeterminateComponent__7 (copy), l__SimpleMemoComponent__9 (copy), l__describeFunctionComponentFrame__13 (copy), l__ForwardRef__8 (copy), l__ClassComponent__10 (copy), l__describeClassComponentFrame__14 (copy)
    local v2 = nil;
    if _G.__DEV__ then
        local l___debugOwner__15 = p1._debugOwner;
        if l___debugOwner__15 then
            v2 = l___debugOwner__15.type;
        end;
    end;
    local v3;
    if _G.__DEV__ then
        v3 = p1._debugSource;
    else
        v3 = nil;
    end;
    if p1.tag == l__HostComponent__2 then
        return l__describeBuiltInComponentFrame__12(p1.type, v3, v2);
    elseif p1.tag == l__LazyComponent__3 then
        return l__describeBuiltInComponentFrame__12("Lazy", v3, v2);
    elseif p1.tag == l__SuspenseComponent__4 then
        return l__describeBuiltInComponentFrame__12("Suspense", v3, v2);
    elseif p1.tag == l__SuspenseListComponent__5 then
        return l__describeBuiltInComponentFrame__12("SuspenseList", v3, v2);
    elseif p1.tag == l__FunctionComponent__6 or (p1.tag == l__IndeterminateComponent__7 or p1.tag == l__SimpleMemoComponent__9) then
        return l__describeFunctionComponentFrame__13(p1.type, v3, v2);
    elseif p1.tag == l__ForwardRef__8 then
        return l__describeFunctionComponentFrame__13(p1.type.render, v3, v2);
    else
        return p1.tag ~= l__ClassComponent__10 and "" or l__describeClassComponentFrame__14(p1.type, v3, v2);
    end;
end;
return {
    getStackByFiberInDevAndProd = function(u5) --[[ Name: getStackByFiberInDevAndProd, Line 75 ]]
        -- upvalues: u4 (copy)
        local v8, v9 = pcall(function() --[[ Line: 76 ]]
            -- upvalues: u5 (copy), u4 (ref)
            local v6 = u5;
            local v7 = "";
            repeat
                v7 = v7 .. u4(v6);
                v6 = v6.return_;
            until v6 == nil;
            return v7;
        end);
        if v8 then
            return v9;
        elseif typeof(v9) == "table" and (v9.message and v9.stack) then
            return "\nError generating stack: " .. v9.message .. "\n" .. tostring(v9.stack);
        else
            return "\nError generating stack: " .. tostring(v9);
        end;
    end
};