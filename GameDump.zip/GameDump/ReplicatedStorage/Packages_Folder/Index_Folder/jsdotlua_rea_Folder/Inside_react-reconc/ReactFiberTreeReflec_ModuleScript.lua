-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberTreeReflection
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__console__1 = require(script.Parent.Parent:WaitForChild("shared")).console;
require(script.Parent:WaitForChild("ReactInternalTypes"));
require(script.Parent:WaitForChild("ReactFiberHostConfig"));
require(script.Parent:WaitForChild("ReactFiberSuspenseComponent.new"));
local l__invariant__2 = require(script.Parent.Parent:WaitForChild("shared")).invariant;
local l__get__3 = require(script.Parent.Parent:WaitForChild("shared")).ReactInstanceMap.get;
local l__ReactSharedInternals__4 = require(script.Parent.Parent:WaitForChild("shared")).ReactSharedInternals;
local l__getComponentName__5 = require(script.Parent.Parent:WaitForChild("shared")).getComponentName;
local l__ReactWorkTags__6 = require(script.Parent:WaitForChild("ReactWorkTags"));
local l__ClassComponent__7 = l__ReactWorkTags__6.ClassComponent;
local l__HostComponent__8 = l__ReactWorkTags__6.HostComponent;
local l__HostRoot__9 = l__ReactWorkTags__6.HostRoot;
local l__HostPortal__10 = l__ReactWorkTags__6.HostPortal;
local l__HostText__11 = l__ReactWorkTags__6.HostText;
local l__FundamentalComponent__12 = l__ReactWorkTags__6.FundamentalComponent;
local l__SuspenseComponent__13 = l__ReactWorkTags__6.SuspenseComponent;
local l__ReactFiberFlags__14 = require(script.Parent:WaitForChild("ReactFiberFlags"));
local l__NoFlags__15 = l__ReactFiberFlags__14.NoFlags;
local l__Placement__16 = l__ReactFiberFlags__14.Placement;
local l__Hydrating__17 = l__ReactFiberFlags__14.Hydrating;
local l__enableFundamentalAPI__18 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags.enableFundamentalAPI;
local l__ReactCurrentOwner__19 = l__ReactSharedInternals__4.ReactCurrentOwner;
local v1 = {};
local function u5(p2) --[[ Line: 47 ]]
    -- upvalues: l__Placement__16 (copy), l__Hydrating__17 (copy), l__NoFlags__15 (copy), l__HostRoot__9 (copy)
    local v3;
    if p2.alternate then
        v3 = p2;
        while p2.return_ do
            p2 = p2.return_;
        end;
    else
        v3 = p2;
        while true do
            local l__flags__20 = p2.flags;
            local v4 = bit32.bor(l__Placement__16, l__Hydrating__17);
            if bit32.band(l__flags__20, v4) ~= l__NoFlags__15 then
                v3 = p2.return_;
            end;
            local l__return___21 = p2.return_;
            if not l__return___21 then
                break;
            end;
            p2 = l__return___21;
        end;
    end;
    if p2.tag == l__HostRoot__9 then
        return v3;
    else
        return nil;
    end;
end;
v1.getNearestMountedFiber = u5;
function v1.getSuspenseInstanceFromFiber(p6) --[[ Line: 81 ]]
    -- upvalues: l__SuspenseComponent__13 (copy)
    if p6.tag == l__SuspenseComponent__13 then
        local l__memoizedState__22 = p6.memoizedState;
        if l__memoizedState__22 == nil then
            local l__alternate__23 = p6.alternate;
            if l__alternate__23 ~= nil then
                l__memoizedState__22 = l__alternate__23.memoizedState;
            end;
        end;
        if l__memoizedState__22 then
            return l__memoizedState__22.dehydrated;
        end;
    end;
    return nil;
end;
function v1.getContainerFromFiber(p7) --[[ Line: 97 ]]
    -- upvalues: l__HostRoot__9 (copy)
    if p7.tag == l__HostRoot__9 then
        return p7.stateNode.containerInfo;
    else
        return nil;
    end;
end;
function v1.isFiberMounted(p8) --[[ Line: 101 ]]
    -- upvalues: u5 (copy)
    return u5(p8) == p8;
end;
function v1.isMounted(p9) --[[ Line: 107 ]]
    -- upvalues: l__ReactCurrentOwner__19 (copy), l__ClassComponent__7 (copy), l__console__1 (copy), l__getComponentName__5 (copy), l__get__3 (copy), u5 (copy)
    if _G.__DEV__ then
        local l__current__24 = l__ReactCurrentOwner__19.current;
        if l__current__24 ~= nil and l__current__24.tag == l__ClassComponent__7 then
            local l__stateNode__25 = l__current__24.stateNode;
            if not l__stateNode__25._warnedAboutRefsInRender then
                l__console__1.error("%s is accessing isMounted inside its render() function. render() should be a pure function of props and state. It should never access something that requires stale data from the previous render, such as refs. Move this logic to componentDidMount and componentDidUpdate instead.", l__getComponentName__5(l__current__24.type) or "A component");
            end;
            l__stateNode__25._warnedAboutRefsInRender = true;
        end;
    end;
    local v10 = l__get__3(p9);
    if v10 then
        return u5(v10) == v10;
    else
        return false;
    end;
end;
local function u17(p11) --[[ Line: 144 ]]
    -- upvalues: u5 (copy), l__invariant__2 (copy), l__HostRoot__9 (copy)
    local l__alternate__26 = p11.alternate;
    if not l__alternate__26 then
        local v12 = u5(p11);
        l__invariant__2(v12 ~= nil, "Unable to find node on an unmounted component.");
        if v12 == p11 then
            return p11;
        else
            return nil;
        end;
    end;
    local v13 = l__alternate__26;
    local v14 = p11;
    while true do
        local l__return___27 = p11.return_;
        if l__return___27 == nil then
            break;
        end;
        local l__alternate__28 = l__return___27.alternate;
        if l__alternate__28 == nil then
            l__return___27 = l__return___27.return_;
            if l__return___27 == nil then
                break;
            end;
            l__alternate__28 = l__return___27;
        else
            if l__return___27.child == l__alternate__28.child then
                local l__child__29 = l__return___27.child;
                while l__child__29 do
                    if l__child__29 == p11 then
                        l__invariant__2(u5(l__return___27) == l__return___27, "Unable to find node on an unmounted component.");
                        return v14;
                    end;
                    if l__child__29 == l__alternate__26 then
                        l__invariant__2(u5(l__return___27) == l__return___27, "Unable to find node on an unmounted component.");
                        return v13;
                    end;
                    l__child__29 = l__child__29.sibling;
                end;
                l__invariant__2(false, "Unable to find node on an unmounted component.");
            end;
            if p11.return_ == l__alternate__26.return_ then
                local l__child__30 = l__return___27.child;
                local v15 = false;
                while l__child__30 do
                    if l__child__30 == p11 then
                        l__alternate__26 = l__alternate__28;
                        p11 = l__return___27;
                        v15 = true;
                        break;
                    end;
                    if l__child__30 == l__alternate__26 then
                        l__alternate__26 = l__return___27;
                        p11 = l__alternate__28;
                        v15 = true;
                        break;
                    end;
                    l__child__30 = l__child__30.sibling;
                end;
                if v15 then
                    l__alternate__28 = l__alternate__26;
                    l__return___27 = p11;
                else
                    local l__child__31 = l__alternate__28.child;
                    while true do
                        if not l__child__31 then
                            l__alternate__28 = l__alternate__26;
                            l__return___27 = p11;
                            break;
                        end;
                        if l__child__31 == p11 then
                            local v16 = l__alternate__28;
                            l__alternate__28 = l__return___27;
                            l__return___27 = v16;
                            v15 = true;
                            break;
                        end;
                        if l__child__31 == l__alternate__26 then
                            v15 = true;
                            break;
                        end;
                        l__child__31 = l__child__31.sibling;
                    end;
                    l__invariant__2(v15, "Child was not found in either parent set. This indicates a bug in React related to the return pointer. Please file an issue.");
                end;
            end;
            l__invariant__2(l__return___27.alternate == l__alternate__28, "Return fibers should always be each others\' alternates. This error is likely caused by a bug in React. Please file an issue.");
        end;
        l__alternate__26 = l__alternate__28;
        p11 = l__return___27;
    end;
    l__invariant__2(p11.tag == l__HostRoot__9, "Unable to find node on an unmounted component.");
    if p11.stateNode.current == p11 then
        return v14;
    else
        return v13;
    end;
end;
v1.findCurrentFiberUsingSlowPath = u17;
function v1.findCurrentHostFiber(p18) --[[ Line: 279 ]]
    -- upvalues: u17 (copy), l__HostComponent__8 (copy), l__HostText__11 (copy)
    local v19 = u17(p18);
    if not v19 then
        return nil;
    end;
    local v20 = v19;
    while true do
        local l__child__32 = v19.child;
        if v19.tag == l__HostComponent__8 or v19.tag == l__HostText__11 then
            break;
        end;
        if l__child__32 then
            l__child__32.return_ = v19;
        else
            if v19 == v20 then
                return nil;
            end;
            local l__return___33 = v19.return_;
            l__child__32 = v19.sibling;
            while not l__child__32 do
                if not l__return___33 or l__return___33 == v20 then
                    return nil;
                end;
            end;
            l__child__32.return_ = l__return___33;
        end;
        v19 = l__child__32;
    end;
    return v19;
end;
function v1.findCurrentHostFiberWithNoPortals(p21) --[[ Line: 318 ]]
    -- upvalues: u17 (copy), l__HostComponent__8 (copy), l__HostText__11 (copy), l__enableFundamentalAPI__18 (copy), l__FundamentalComponent__12 (copy), l__HostPortal__10 (copy)
    local v22 = u17(p21);
    if not v22 then
        return nil;
    end;
    local v23 = v22;
    while true do
        local l__child__34 = v22.child;
        if v22.tag == l__HostComponent__8 or (v22.tag == l__HostText__11 or l__enableFundamentalAPI__18 and v22.tag == l__FundamentalComponent__12) then
            break;
        end;
        if l__child__34 and v22.tag ~= l__HostPortal__10 then
            l__child__34.return_ = v22;
            v22 = l__child__34;
        else
            if v22 == v23 then
                return nil;
            end;
            local l__return___35 = v22.return_;
            v22 = v22.sibling;
            while not v22 do
                if not l__return___35 or l__return___35 == v23 then
                    return nil;
                end;
            end;
            v22.return_ = l__return___35;
        end;
    end;
    return v22;
end;
function v1.isFiberSuspenseAndTimedOut(p24) --[[ Line: 360 ]]
    -- upvalues: l__SuspenseComponent__13 (copy)
    local l__memoizedState__36 = p24.memoizedState;
    local v25;
    if p24.tag == l__SuspenseComponent__13 and l__memoizedState__36 ~= nil then
        v25 = l__memoizedState__36.dehydrated == nil;
    else
        v25 = false;
    end;
    return v25;
end;
function v1.doesFiberContain(p26, p27) --[[ Line: 367 ]]
    local l__alternate__37 = p26.alternate;
    while p27 ~= nil do
        if p27 == p26 or p27 == l__alternate__37 then
            return true;
        end;
        p27 = p27.return_;
    end;
    return false;
end;
return v1;