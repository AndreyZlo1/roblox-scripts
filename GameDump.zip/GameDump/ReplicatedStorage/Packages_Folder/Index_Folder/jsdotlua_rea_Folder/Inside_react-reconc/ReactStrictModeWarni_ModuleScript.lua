-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactStrictModeWarnings.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__console__1 = require(script.Parent.Parent:WaitForChild("shared")).console;
require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__ReactCurrentFiber__2 = require(script.Parent:WaitForChild("ReactCurrentFiber"));
local l__resetCurrentFiber__3 = l__ReactCurrentFiber__2.resetCurrentFiber;
local l__setCurrentFiber__4 = l__ReactCurrentFiber__2.setCurrentFiber;
local l__getComponentName__5 = require(script.Parent.Parent:WaitForChild("shared")).getComponentName;
local l__StrictMode__6 = require(script.Parent:WaitForChild("ReactTypeOfMode")).StrictMode;
local v1 = {
    recordUnsafeLifecycleWarnings = function(_, _) --[[ Name: recordUnsafeLifecycleWarnings, Line 30 ]] end,
    flushPendingUnsafeLifecycleWarnings = function() --[[ Name: flushPendingUnsafeLifecycleWarnings, Line 31 ]] end,
    recordLegacyContextWarning = function(_, _) --[[ Name: recordLegacyContextWarning, Line 32 ]] end,
    flushLegacyContextWarning = function() --[[ Name: flushLegacyContextWarning, Line 33 ]] end,
    discardPendingWarnings = function() --[[ Name: discardPendingWarnings, Line 34 ]] end
};
if _G.__DEV__ then
    local function u5(p2) --[[ Line: 53 ]]
        local v3 = {};
        for v4, _ in p2 do
            table.insert(v3, v4);
        end;
        table.sort(v3);
        return table.concat(v3, ", ");
    end;
    local u6 = {};
    local u7 = {};
    local u8 = {};
    local u9 = {};
    local u10 = {};
    local u11 = {};
    local u12 = {};
    function v1.recordUnsafeLifecycleWarnings(p13, p14) --[[ Line: 73 ]]
        -- upvalues: u12 (copy), u6 (copy), l__StrictMode__6 (copy), u7 (copy), u8 (copy), u9 (copy), u10 (copy), u11 (copy)
        if u12[p13.type] then
        else
            if typeof(p14.componentWillMount) == "function" then
                table.insert(u6, p13);
            end;
            if bit32.band(p13.mode, l__StrictMode__6) ~= 0 and typeof(p14.UNSAFE_componentWillMount) == "function" then
                table.insert(u7, p13);
            end;
            if typeof(p14.componentWillReceiveProps) == "function" then
                table.insert(u8, p13);
            end;
            if bit32.band(p13.mode, l__StrictMode__6) ~= 0 and typeof(p14.UNSAFE_componentWillReceiveProps) == "function" then
                table.insert(u9, p13);
            end;
            if typeof(p14.componentWillUpdate) == "function" then
                table.insert(u10, p13);
            end;
            if bit32.band(p13.mode, l__StrictMode__6) ~= 0 and typeof(p14.UNSAFE_componentWillUpdate) == "function" then
                table.insert(u11, p13);
            end;
        end;
    end;
    function v1.flushPendingUnsafeLifecycleWarnings() --[[ Line: 126 ]]
        -- upvalues: u6 (copy), l__getComponentName__5 (copy), u12 (copy), u7 (copy), u8 (copy), u9 (copy), u10 (copy), u11 (copy), u5 (copy), l__console__1 (copy)
        local v15 = {};
        if #u6 > 0 then
            for _, v16 in u6 do
                v15[l__getComponentName__5(v16.type) or "Component"] = true;
                u12[v16.type] = true;
            end;
            table.clear(u6);
        end;
        local v17 = {};
        if #u7 > 0 then
            for _, v18 in u7 do
                v17[l__getComponentName__5(v18.type) or "Component"] = true;
                u12[v18.type] = true;
            end;
            table.clear(u7);
        end;
        local v19 = {};
        if #u8 > 0 then
            for _, v20 in u8 do
                v19[l__getComponentName__5(v20.type) or "Component"] = true;
                u12[v20.type] = true;
            end;
            table.clear(u8);
        end;
        local v21 = {};
        if #u9 > 0 then
            for _, v22 in u9 do
                v21[l__getComponentName__5(v22.type) or "Component"] = true;
                u12[v22.type] = true;
            end;
            table.clear(u9);
        end;
        local v23 = {};
        if #u10 > 0 then
            for _, v24 in u10 do
                v23[l__getComponentName__5(v24.type) or "Component"] = true;
                u12[v24.type] = true;
            end;
            table.clear(u10);
        end;
        local v25 = {};
        if #u11 > 0 then
            for _, v26 in u11 do
                v25[l__getComponentName__5(v26.type) or "Component"] = true;
                u12[v26.type] = true;
            end;
            table.clear(u11);
        end;
        if next(v17) ~= nil then
            local v27 = u5(v17);
            l__console__1.error("Using UNSAFE_componentWillMount in strict mode is not recommended and may indicate bugs in your code. See https://reactjs.org/link/unsafe-component-lifecycles for details.\n\n* Move code with side effects to componentDidMount, and set initial state in the constructor.\n\nPlease update the following components: %s", v27);
        end;
        if next(v21) ~= nil then
            local v28 = u5(v21);
            l__console__1.error("Using UNSAFE_componentWillReceiveProps in strict mode is not recommended and may indicate bugs in your code. See https://reactjs.org/link/unsafe-component-lifecycles for details.\n\n* Move data fetching code or side effects to componentDidUpdate.\n* If you\'re updating state whenever props change, refactor your code to use memoization techniques or move it to static getDerivedStateFromProps. Learn more at: https://reactjs.org/link/derived-state\n\nPlease update the following components: %s", v28);
        end;
        if next(v25) ~= nil then
            local v29 = u5(v25);
            l__console__1.error("Using UNSAFE_componentWillUpdate in strict mode is not recommended and may indicate bugs in your code. See https://reactjs.org/link/unsafe-component-lifecycles for details.\n\n* Move data fetching code or side effects to componentDidUpdate.\n\nPlease update the following components: %s", v29);
        end;
        if next(v15) ~= nil then
            local v30 = u5(v15);
            l__console__1.warn("componentWillMount has been renamed, and is not recommended for use. See https://reactjs.org/link/unsafe-component-lifecycles for details.\n\n* Move code with side effects to componentDidMount, and set initial state in the constructor.\n* Rename componentWillMount to UNSAFE_componentWillMount to suppress this warning in non-strict mode. In React 18.x, only the UNSAFE_ name will work.\n\nPlease update the following components: %s", v30);
        end;
        if next(v19) ~= nil then
            local v31 = u5(v19);
            l__console__1.warn("componentWillReceiveProps has been renamed, and is not recommended for use. See https://reactjs.org/link/unsafe-component-lifecycles for details.\n\n* Move data fetching code or side effects to componentDidUpdate.\n* If you\'re updating state whenever props change, refactor your code to use memoization techniques or move it to static getDerivedStateFromProps. Learn more at: https://reactjs.org/link/derived-state\n* Rename componentWillReceiveProps to UNSAFE_componentWillReceiveProps to suppress this warning in non-strict mode. In React 18.x, only the UNSAFE_ name will work.\n\nPlease update the following components: %s", v31);
        end;
        if next(v23) ~= nil then
            local v32 = u5(v23);
            l__console__1.warn("componentWillUpdate has been renamed, and is not recommended for use. See https://reactjs.org/link/unsafe-component-lifecycles for details.\n\n* Move data fetching code or side effects to componentDidUpdate.\n* Rename componentWillUpdate to UNSAFE_componentWillUpdate to suppress this warning in non-strict mode. In React 18.x, only the UNSAFE_ name will work.\n\nPlease update the following components: %s", v32);
        end;
    end;
    local u33 = {};
    local u34 = {};
    function v1.recordLegacyContextWarning(p35, p36) --[[ Line: 300 ]]
        -- upvalues: l__StrictMode__6 (copy), l__console__1 (copy), u34 (copy), u33 (copy)
        local v37 = p35;
        local v38 = nil;
        while p35 ~= nil do
            if bit32.band(p35.mode, l__StrictMode__6) ~= 0 then
                v38 = p35;
            end;
            p35 = p35.return_;
        end;
        if v38 == nil then
            l__console__1.error("Expected to find a StrictMode component in a strict mode tree. This error is likely caused by a bug in React. Please file an issue.");
        elseif u34[v37.type] then
        else
            local v39 = u33[v38];
            if typeof(v37.type) ~= "function" and (v37.type.contextTypes ~= nil or (v37.type.childContextTypes ~= nil or p36 ~= nil and typeof(p36.getChildContext) == "function")) then
                if v39 == nil then
                    v39 = {};
                    u33[v38] = v39;
                end;
                table.insert(v39, v37);
            end;
        end;
    end;
    function v1.flushLegacyContextWarning() --[[ Line: 339 ]]
        -- upvalues: u33 (copy), l__getComponentName__5 (copy), u34 (copy), u5 (copy), l__setCurrentFiber__4 (copy), l__console__1 (copy), l__resetCurrentFiber__3 (copy)
        for _, v40 in u33 do
            if #v40 == 0 then
                return;
            end;
            local u41 = v40[1];
            local v42 = {};
            for _, v43 in v40 do
                v42[l__getComponentName__5(v43.type) or "Component"] = true;
                u34[v43.type] = true;
            end;
            local u44 = u5(v42);
            local v45, v46 = pcall(function() --[[ Line: 354 ]]
                -- upvalues: l__setCurrentFiber__4 (ref), u41 (copy), l__console__1 (ref), u44 (copy)
                l__setCurrentFiber__4(u41);
                l__console__1.error("Legacy context API has been detected within a strict-mode tree.\n\nThe old API will be supported in all 16.x releases, but applications using it should migrate to the new version.\n\nPlease update the following components: %s\n\nLearn more about this warning here: https://reactjs.org/link/legacy-context", u44);
            end);
            l__resetCurrentFiber__3();
            if not v45 then
                error(v46);
            end;
        end;
    end;
    function v1.discardPendingWarnings() --[[ Line: 377 ]]
        -- upvalues: u6 (copy), u7 (copy), u8 (copy), u9 (copy), u10 (copy), u11 (copy), u33 (copy)
        table.clear(u6);
        table.clear(u7);
        table.clear(u8);
        table.clear(u9);
        table.clear(u10);
        table.clear(u11);
        table.clear(u33);
    end;
end;
return v1;