-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactTestSelectors
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local l__supportsTestSelectors__1 = require(script.Parent:WaitForChild("ReactFiberHostConfig")).supportsTestSelectors;
local v1 = {};
local u2 = {};
function v1.onCommitRoot() --[[ Line: 511 ]]
    -- upvalues: l__supportsTestSelectors__1 (copy), u2 (copy)
    if l__supportsTestSelectors__1 then
        for _, v3 in u2 do
            v3();
        end;
    end;
end;
return v1;