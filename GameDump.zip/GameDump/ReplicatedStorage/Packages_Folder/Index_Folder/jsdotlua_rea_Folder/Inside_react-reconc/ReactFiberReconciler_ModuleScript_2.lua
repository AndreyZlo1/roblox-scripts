-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberReconciler.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
require(script.Parent.Parent:WaitForChild("shared"));
local v1 = require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local l__Array__2 = v1.Array;
local l__Object__3 = v1.Object;
local l__console__4 = require(script.Parent.Parent:WaitForChild("shared")).console;
require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__ReactRootTags__5 = require(script.Parent:WaitForChild("ReactRootTags"));
local l__ReactFiberFlags__6 = require(script.Parent:WaitForChild("ReactFiberFlags"));
require(script.Parent:WaitForChild("ReactFiberHostConfig"));
local l__ReactWorkTags__7 = require(script.Parent:WaitForChild("ReactWorkTags"));
local l__FundamentalComponent__8 = l__ReactWorkTags__7.FundamentalComponent;
require(script.Parent.Parent:WaitForChild("shared"));
local l__ReactFiberLane__9 = require(script.Parent:WaitForChild("ReactFiberLane"));
require(script.Parent:WaitForChild("ReactFiberSuspenseComponent.new"));
local l__ReactFiberTreeReflection__10 = require(script.Parent:WaitForChild("ReactFiberTreeReflection"));
local l__findCurrentHostFiber__11 = l__ReactFiberTreeReflection__10.findCurrentHostFiber;
local l__findCurrentHostFiberWithNoPortals__12 = l__ReactFiberTreeReflection__10.findCurrentHostFiberWithNoPortals;
local l__get__13 = require(script.Parent.Parent:WaitForChild("shared")).ReactInstanceMap.get;
local l__HostComponent__14 = l__ReactWorkTags__7.HostComponent;
local l__ClassComponent__15 = l__ReactWorkTags__7.ClassComponent;
local l__HostRoot__16 = l__ReactWorkTags__7.HostRoot;
local l__SuspenseComponent__17 = l__ReactWorkTags__7.SuspenseComponent;
local l__getComponentName__18 = require(script.Parent.Parent:WaitForChild("shared")).getComponentName;
local l__invariant__19 = require(script.Parent.Parent:WaitForChild("shared")).invariant;
local l__describeError__20 = require(script.Parent.Parent:WaitForChild("shared")).describeError;
local l__enableSchedulingProfiler__21 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags.enableSchedulingProfiler;
local l__ReactSharedInternals__22 = require(script.Parent.Parent:WaitForChild("shared")).ReactSharedInternals;
local l__getPublicInstance__23 = require(script.Parent:WaitForChild("ReactFiberHostConfig")).getPublicInstance;
local v2 = require(script.Parent:WaitForChild("ReactFiberContext.new"));
local l__findCurrentUnmaskedContext__24 = v2.findCurrentUnmaskedContext;
local l__processChildContext__25 = v2.processChildContext;
local l__emptyContextObject__26 = v2.emptyContextObject;
local l__isContextProvider__27 = v2.isContextProvider;
local l__createFiberRoot__28 = require(script.Parent:WaitForChild("ReactFiberRoot.new")).createFiberRoot;
local v3 = require(script.Parent:WaitForChild("ReactFiberDevToolsHook.new"));
local l__injectInternals__29 = v3.injectInternals;
local l__onScheduleRoot__30 = v3.onScheduleRoot;
local v4 = require(script.Parent:WaitForChild("ReactFiberWorkLoop.new"));
local l__requestEventTime__31 = v4.requestEventTime;
local l__requestUpdateLane__32 = v4.requestUpdateLane;
local l__scheduleUpdateOnFiber__33 = v4.scheduleUpdateOnFiber;
local l__flushRoot__34 = v4.flushRoot;
local l__batchedEventUpdates__35 = v4.batchedEventUpdates;
local l__batchedUpdates__36 = v4.batchedUpdates;
local l__unbatchedUpdates__37 = v4.unbatchedUpdates;
local l__flushSync__38 = v4.flushSync;
local l__flushControlled__39 = v4.flushControlled;
local l__deferredUpdates__40 = v4.deferredUpdates;
local l__discreteUpdates__41 = v4.discreteUpdates;
local l__flushDiscreteUpdates__42 = v4.flushDiscreteUpdates;
local l__flushPassiveEffects__43 = v4.flushPassiveEffects;
local l__warnIfNotScopedWithMatchingAct__44 = v4.warnIfNotScopedWithMatchingAct;
local l__warnIfUnmockedScheduler__45 = v4.warnIfUnmockedScheduler;
local l__IsThisRendererActing__46 = v4.IsThisRendererActing;
local l__act__47 = v4.act;
local v5 = require(script.Parent:WaitForChild("ReactUpdateQueue.new"));
local l__createUpdate__48 = v5.createUpdate;
local l__enqueueUpdate__49 = v5.enqueueUpdate;
local l__ReactCurrentFiber__50 = require(script.Parent:WaitForChild("ReactCurrentFiber"));
local l__isRendering__51 = l__ReactCurrentFiber__50.isRendering;
local l__resetCurrentFiber__52 = l__ReactCurrentFiber__50.resetCurrentFiber;
local l__setCurrentFiber__53 = l__ReactCurrentFiber__50.setCurrentFiber;
local l__ReactTypeOfMode__54 = require(script.Parent:WaitForChild("ReactTypeOfMode"));
local l__StrictMode__55 = l__ReactTypeOfMode__54.StrictMode;
local l__SyncLane__56 = l__ReactFiberLane__9.SyncLane;
local l__InputDiscreteHydrationLane__57 = l__ReactFiberLane__9.InputDiscreteHydrationLane;
local l__SelectiveHydrationLane__58 = l__ReactFiberLane__9.SelectiveHydrationLane;
local l__NoTimestamp__59 = l__ReactFiberLane__9.NoTimestamp;
local l__getHighestPriorityPendingLanes__60 = l__ReactFiberLane__9.getHighestPriorityPendingLanes;
local l__higherPriorityLane__61 = l__ReactFiberLane__9.higherPriorityLane;
local l__getCurrentUpdateLanePriority__62 = l__ReactFiberLane__9.getCurrentUpdateLanePriority;
local l__setCurrentUpdateLanePriority__63 = l__ReactFiberLane__9.setCurrentUpdateLanePriority;
local l__markRenderScheduled__64 = require(script.Parent:WaitForChild("SchedulingProfiler")).markRenderScheduled;
local v6 = {
    ReactRootTags = l__ReactRootTags__5,
    ReactWorkTags = l__ReactWorkTags__7,
    ReactTypeOfMode = l__ReactTypeOfMode__54,
    ReactFiberFlags = l__ReactFiberFlags__6,
    getNearestMountedFiber = l__ReactFiberTreeReflection__10.getNearestMountedFiber,
    findCurrentFiberUsingSlowPath = l__ReactFiberTreeReflection__10.findCurrentFiberUsingSlowPath,
    createPortal = require(script.Parent:WaitForChild("ReactPortal")).createPortal
};
local u7, u8;
if l____DEV____1 then
    u7 = {};
    u8 = false;
else
    u7 = nil;
    u8 = nil;
end;
local function u12(p9) --[[ Line: 194 ]]
    -- upvalues: l__get__13 (copy), l__invariant__19 (copy), l__Object__3 (copy), l__findCurrentHostFiber__11 (copy)
    local v10 = l__get__13(p9);
    if v10 == nil then
        if typeof(p9.render) == "function" then
            l__invariant__19(false, "Unable to find node on an unmounted component.");
        else
            l__invariant__19(false, "Argument appears to not be a ReactComponent. Keys: %s", table.concat(l__Object__3.keys(p9)));
        end;
    end;
    local v11 = l__findCurrentHostFiber__11(v10);
    if v11 == nil then
        return nil;
    else
        return v11.stateNode;
    end;
end;
local function v20(p13, u14) --[[ Line: 215 ]]
    -- upvalues: l____DEV____1 (copy), l__get__13 (copy), l__invariant__19 (copy), l__Object__3 (copy), l__findCurrentHostFiber__11 (copy), l__StrictMode__55 (copy), l__getComponentName__18 (copy), u7 (ref), l__ReactCurrentFiber__50 (copy), l__setCurrentFiber__53 (copy), l__console__4 (copy), l__describeError__20 (copy), l__resetCurrentFiber__52 (copy), u12 (copy)
    if not l____DEV____1 then
        return u12(p13);
    end;
    local u15 = l__get__13(p13);
    if u15 == nil then
        if typeof(p13.render) == "function" then
            l__invariant__19(false, "Unable to find node on an unmounted component.");
        else
            l__invariant__19(false, "Argument appears to not be a ReactComponent. Keys: %s", table.concat(l__Object__3.keys(p13)));
        end;
    end;
    local u16 = l__findCurrentHostFiber__11(u15);
    if u16 == nil then
        return nil;
    end;
    if bit32.band(u16.mode, l__StrictMode__55) ~= 0 then
        local u17 = l__getComponentName__18(u15.type) or "Component";
        if not u7[u17] then
            u7[u17] = true;
            local l__current__65 = l__ReactCurrentFiber__50.current;
            local v18, v19 = xpcall(function() --[[ Line: 243 ]]
                -- upvalues: l__setCurrentFiber__53 (ref), u16 (copy), u15 (copy), l__StrictMode__55 (ref), l__console__4 (ref), u14 (copy), u17 (copy)
                l__setCurrentFiber__53(u16);
                if bit32.band(u15.mode, l__StrictMode__55) == 0 then
                    l__console__4.error("%s is deprecated in StrictMode. %s was passed an instance of %s which renders StrictMode children. Instead, add a ref directly to the element you want to reference. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-find-node", u14, u14, u17);
                else
                    l__console__4.error("%s is deprecated in StrictMode. %s was passed an instance of %s which is inside StrictMode. Instead, add a ref directly to the element you want to reference. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-find-node", u14, u14, u17);
                end;
            end, l__describeError__20);
            if l__current__65 then
                l__setCurrentFiber__53(l__current__65);
            else
                l__resetCurrentFiber__52();
            end;
            if not v18 then
                error(v19);
            end;
        end;
    end;
    return u16.stateNode;
end;
function v6.createContainer(p21, p22, p23, p24) --[[ Line: 288 ]]
    -- upvalues: l__createFiberRoot__28 (copy)
    return l__createFiberRoot__28(p21, p22, p23, p24);
end;
function v6.updateContainer(p25, p26, p27, p28) --[[ Line: 297 ]]
    -- upvalues: l____DEV____1 (copy), l__onScheduleRoot__30 (copy), l__requestEventTime__31 (copy), l__warnIfUnmockedScheduler__45 (copy), l__warnIfNotScopedWithMatchingAct__44 (copy), l__requestUpdateLane__32 (copy), l__enableSchedulingProfiler__21 (copy), l__markRenderScheduled__64 (copy), l__emptyContextObject__26 (copy), l__get__13 (copy), l__findCurrentUnmaskedContext__24 (copy), l__ClassComponent__15 (copy), l__isContextProvider__27 (copy), l__processChildContext__25 (copy), l__isRendering__51 (copy), l__ReactCurrentFiber__50 (copy), u8 (ref), l__console__4 (copy), l__getComponentName__18 (copy), l__createUpdate__48 (copy), l__Object__3 (copy), l__enqueueUpdate__49 (copy), l__scheduleUpdateOnFiber__33 (copy)
    if l____DEV____1 then
        l__onScheduleRoot__30(p26, p25);
    end;
    local l__current__66 = p26.current;
    local v29 = l__requestEventTime__31();
    if l____DEV____1 and _G.__TESTEZ_RUNNING_TEST__ then
        l__warnIfUnmockedScheduler__45(l__current__66);
        l__warnIfNotScopedWithMatchingAct__44(l__current__66);
    end;
    local v30 = l__requestUpdateLane__32(l__current__66);
    if l__enableSchedulingProfiler__21 then
        l__markRenderScheduled__64(v30);
    end;
    local v31;
    if p27 then
        local v32 = l__get__13(p27);
        v31 = l__findCurrentUnmaskedContext__24(v32);
        if v32.tag == l__ClassComponent__15 then
            local l__type__67 = v32.type;
            if l__isContextProvider__27(l__type__67) then
                v31 = l__processChildContext__25(v32, l__type__67, v31);
            end;
        end;
    else
        v31 = l__emptyContextObject__26;
    end;
    if p26.context == nil then
        p26.context = v31;
    else
        p26.pendingContext = v31;
    end;
    if l____DEV____1 and (l__isRendering__51 and (l__ReactCurrentFiber__50.current ~= nil and not u8)) then
        u8 = true;
        l__console__4.error("Render methods should be a pure function of props and state; triggering nested component updates from render is not allowed. If necessary, trigger nested updates in componentDidUpdate.\n\nCheck the render method of %s.", l__getComponentName__18(l__ReactCurrentFiber__50.current.type) or "Unknown");
    end;
    local v33 = l__createUpdate__48(v29, v30);
    if p25 == nil then
        p25 = l__Object__3.None;
    end;
    v33.payload = {
        element = p25
    };
    if p28 ~= nil then
        if l____DEV____1 and typeof(p28) ~= "function" then
            l__console__4.error("render(...): Expected the last optional `callback` argument to be a function. Instead received: %s.", (tostring(p28)));
        end;
        v33.callback = p28;
    end;
    l__enqueueUpdate__49(l__current__66, v33);
    l__scheduleUpdateOnFiber__33(l__current__66, v30, v29);
    return v30;
end;
v6.batchedEventUpdates = l__batchedEventUpdates__35;
v6.batchedUpdates = l__batchedUpdates__36;
v6.unbatchedUpdates = l__unbatchedUpdates__37;
v6.deferredUpdates = l__deferredUpdates__40;
v6.discreteUpdates = l__discreteUpdates__41;
v6.flushDiscreteUpdates = l__flushDiscreteUpdates__42;
v6.flushControlled = l__flushControlled__39;
v6.flushSync = l__flushSync__38;
v6.flushPassiveEffects = l__flushPassiveEffects__43;
v6.IsThisRendererActing = l__IsThisRendererActing__46;
v6.act = l__act__47;
function v6.getPublicRootInstance(p34) --[[ Line: 393 ]]
    -- upvalues: l__HostComponent__14 (copy), l__getPublicInstance__23 (copy)
    local l__current__68 = p34.current;
    if l__current__68.child then
        if l__current__68.child.tag == l__HostComponent__14 then
            return l__getPublicInstance__23(l__current__68.child.stateNode);
        else
            return l__current__68.child.stateNode;
        end;
    else
        return nil;
    end;
end;
local u35 = nil;
function v6.attemptSynchronousHydration(u36) --[[ Line: 408 ]]
    -- upvalues: l__HostRoot__16 (copy), l__getHighestPriorityPendingLanes__60 (copy), l__flushRoot__34 (copy), l__SuspenseComponent__17 (copy), l__requestEventTime__31 (copy), l__flushSync__38 (copy), l__scheduleUpdateOnFiber__33 (copy), l__SyncLane__56 (copy), l__InputDiscreteHydrationLane__57 (copy), u35 (ref)
    if u36.tag == l__HostRoot__16 then
        local l__stateNode__69 = u36.stateNode;
        if l__stateNode__69.hydrate then
            l__flushRoot__34(l__stateNode__69, (l__getHighestPriorityPendingLanes__60(l__stateNode__69)));
        end;
    elseif u36.tag == l__SuspenseComponent__17 then
        local u37 = l__requestEventTime__31();
        l__flushSync__38(function() --[[ Line: 418 ]]
            -- upvalues: l__scheduleUpdateOnFiber__33 (ref), u36 (copy), l__SyncLane__56 (ref), u37 (copy)
            return l__scheduleUpdateOnFiber__33(u36, l__SyncLane__56, u37);
        end);
        u35(u36, l__InputDiscreteHydrationLane__57);
    end;
end;
u35 = function(p38, p39) --[[ Line: 440 ]]
    -- upvalues: l__higherPriorityLane__61 (copy)
    local l__memoizedState__70 = p38.memoizedState;
    if l__memoizedState__70 and (l__memoizedState__70 ~= nil and l__memoizedState__70.dehydrated ~= nil) then
        l__memoizedState__70.retryLane = l__higherPriorityLane__61(l__memoizedState__70.retryLane, p39);
    end;
    local l__alternate__71 = p38.alternate;
    if l__alternate__71 then
        local l__memoizedState__72 = l__alternate__71.memoizedState;
        if l__memoizedState__72 and (l__memoizedState__72 ~= nil and l__memoizedState__72.dehydrated ~= nil) then
            l__memoizedState__72.retryLane = l__higherPriorityLane__61(l__memoizedState__72.retryLane, p39);
        end;
    end;
end;
function v6.attemptUserBlockingHydration(p40) --[[ Line: 449 ]]
    -- upvalues: l__SuspenseComponent__17 (copy), l__requestEventTime__31 (copy), l__InputDiscreteHydrationLane__57 (copy), l__scheduleUpdateOnFiber__33 (copy), u35 (ref)
    if p40.tag == l__SuspenseComponent__17 then
        local v41 = l__InputDiscreteHydrationLane__57;
        l__scheduleUpdateOnFiber__33(p40, v41, (l__requestEventTime__31()));
        u35(p40, v41);
    end;
end;
function v6.attemptContinuousHydration(p42) --[[ Line: 463 ]]
    -- upvalues: l__SuspenseComponent__17 (copy), l__requestEventTime__31 (copy), l__SelectiveHydrationLane__58 (copy), l__scheduleUpdateOnFiber__33 (copy), u35 (ref)
    if p42.tag == l__SuspenseComponent__17 then
        local v43 = l__SelectiveHydrationLane__58;
        l__scheduleUpdateOnFiber__33(p42, v43, (l__requestEventTime__31()));
        u35(p42, v43);
    end;
end;
function v6.attemptHydrationAtCurrentPriority(p44) --[[ Line: 477 ]]
    -- upvalues: l__SuspenseComponent__17 (copy), l__requestEventTime__31 (copy), l__requestUpdateLane__32 (copy), l__scheduleUpdateOnFiber__33 (copy), u35 (ref)
    if p44.tag == l__SuspenseComponent__17 then
        local v45 = l__requestEventTime__31();
        local v46 = l__requestUpdateLane__32(p44);
        l__scheduleUpdateOnFiber__33(p44, v46, v45);
        u35(p44, v46);
    end;
end;
function v6.runWithPriority(p47, p48) --[[ Line: 489 ]]
    -- upvalues: l__getCurrentUpdateLanePriority__62 (copy), l__setCurrentUpdateLanePriority__63 (copy), l__describeError__20 (copy)
    local v49 = l__getCurrentUpdateLanePriority__62();
    l__setCurrentUpdateLanePriority__63(p47);
    local v50, v51 = xpcall(p48, l__describeError__20);
    l__setCurrentUpdateLanePriority__63(v49);
    if not v50 then
        error(v51);
    end;
    return v51;
end;
v6.getCurrentUpdateLanePriority = l__getCurrentUpdateLanePriority__62;
v6.findHostInstance = u12;
v6.findHostInstanceWithWarning = v20;
function v6.findHostInstanceWithNoPortals(p52) --[[ Line: 507 ]]
    -- upvalues: l__findCurrentHostFiberWithNoPortals__12 (copy), l__FundamentalComponent__8 (copy)
    local v53 = l__findCurrentHostFiberWithNoPortals__12(p52);
    if v53 == nil then
        return nil;
    elseif v53.tag == l__FundamentalComponent__8 then
        return v53.stateNode.instance;
    else
        return v53.stateNode;
    end;
end;
local function u54(_) --[[ Line: 518 ]]
    return false;
end;
function v6.shouldSuspend(p55) --[[ Line: 522 ]]
    -- upvalues: u54 (ref)
    return u54(p55);
end;
local u56, u57, u58, u59, u60, u61, u62, u63;
if l____DEV____1 then
    local function u69(p64, p65, p66) --[[ Line: 537 ]]
        -- upvalues: l__Array__2 (copy), u69 (copy)
        local v67 = p65[p66];
        local v68;
        if l__Array__2.isArray(p64) then
            v68 = l__Array__2.slice(p64);
        else
            v68 = table.clone(p64);
        end;
        if p66 + 1 == #p65 then
            if l__Array__2.isArray(v68) then
                l__Array__2.splice(v68, v67, 1);
                return v68;
            else
                v68[v67] = nil;
                return v68;
            end;
        else
            v68[v67] = u69(p64[v67], p65, p66 + 1);
            return v68;
        end;
    end;
    local function u76(p70, p71, p72, p73) --[[ Line: 573 ]]
        -- upvalues: l__Array__2 (copy), u76 (copy)
        local v74 = p71[p73];
        local v75;
        if l__Array__2.isArray(p70) then
            v75 = l__Array__2.slice(p70);
        else
            v75 = table.clone(p70);
        end;
        if p73 + 1 == #p71 then
            v75[p72[p73]] = v75[v74];
            if l__Array__2.isArray(v75) then
                l__Array__2.splice(v75, v74, 1);
                return v75;
            else
                v75[v74] = nil;
                return v75;
            end;
        else
            v75[v74] = u76(p70[v74], p71, p72, p73 + 1);
            return v75;
        end;
    end;
    local function u81(p77, p78, p79) --[[ Line: 609 ]]
        -- upvalues: l__console__4 (copy), u76 (copy)
        if #p78 == #p79 then
            for v80 = 1, #p79 do
                if p78[v80] ~= p79[v80] then
                    l__console__4.warn("copyWithRename() expects paths to be the same except for the deepest key");
                    return nil;
                end;
            end;
            return u76(p77, p78, p79, 0);
        else
            l__console__4.warn("copyWithRename() expects paths of the same length");
            return nil;
        end;
    end;
    local function u88(p82, p83, p84, p85) --[[ Line: 631 ]]
        -- upvalues: l__Array__2 (copy), u88 (copy)
        if #p83 + 1 <= p84 then
            return p85;
        end;
        local v86 = p83[p84];
        local v87;
        if l__Array__2.isArray(p82) then
            v87 = l__Array__2.slice(p82);
        else
            v87 = table.clone(p82);
        end;
        v87[v86] = u88(p82[v86], p83, p84 + 2, p85);
        return v87;
    end;
    u56 = function(p89) --[[ Line: 769 ]]
        -- upvalues: u54 (ref)
        u54 = p89;
    end;
    u57 = function(p90, p91, p92) --[[ Line: 733 ]]
        -- upvalues: u88 (copy), l__scheduleUpdateOnFiber__33 (copy), l__SyncLane__56 (copy), l__NoTimestamp__59 (copy)
        p90.pendingProps = u88(p90.memoizedProps, p91, 1, p92);
        local l__alternate__73 = p90.alternate;
        if l__alternate__73 then
            l__alternate__73.pendingProps = p90.pendingProps;
        end;
        l__scheduleUpdateOnFiber__33(p90, l__SyncLane__56, l__NoTimestamp__59);
    end;
    u58 = function(p93, p94) --[[ Line: 742 ]]
        -- upvalues: u69 (copy), l__scheduleUpdateOnFiber__33 (copy), l__SyncLane__56 (copy), l__NoTimestamp__59 (copy)
        p93.pendingProps = u69(p93.memoizedProps, p94, 0);
        local l__alternate__74 = p93.alternate;
        if l__alternate__74 then
            l__alternate__74.pendingProps = p93.pendingProps;
        end;
        l__scheduleUpdateOnFiber__33(p93, l__SyncLane__56, l__NoTimestamp__59);
    end;
    u59 = function(p95, p96, p97) --[[ Line: 751 ]]
        -- upvalues: u81 (copy), l__scheduleUpdateOnFiber__33 (copy), l__SyncLane__56 (copy), l__NoTimestamp__59 (copy)
        p95.pendingProps = u81(p95.memoizedProps, p96, p97);
        local l__alternate__75 = p95.alternate;
        if l__alternate__75 then
            l__alternate__75.pendingProps = p95.pendingProps;
        end;
        l__scheduleUpdateOnFiber__33(p95, l__SyncLane__56, l__NoTimestamp__59);
    end;
    u60 = function(p98) --[[ Line: 765 ]]
        -- upvalues: l__scheduleUpdateOnFiber__33 (copy), l__SyncLane__56 (copy), l__NoTimestamp__59 (copy)
        l__scheduleUpdateOnFiber__33(p98, l__SyncLane__56, l__NoTimestamp__59);
    end;
    u61 = function(p99, p100, p101, p102) --[[ Line: 674 ]]
        -- upvalues: u88 (copy), l__scheduleUpdateOnFiber__33 (copy), l__SyncLane__56 (copy), l__NoTimestamp__59 (copy)
        local l__memoizedState__76 = p99.memoizedState;
        while l__memoizedState__76 ~= nil and p100 > 1 do
            l__memoizedState__76 = l__memoizedState__76.next;
            p100 = p100 - 1;
        end;
        if l__memoizedState__76 ~= nil then
            local v103 = u88(l__memoizedState__76.memoizedState, p101, 1, p102);
            l__memoizedState__76.memoizedState = v103;
            l__memoizedState__76.baseState = v103;
            p99.memoizedProps = table.clone(p99.memoizedProps);
            l__scheduleUpdateOnFiber__33(p99, l__SyncLane__56, l__NoTimestamp__59);
        end;
    end;
    u62 = function(p104, p105, p106) --[[ Line: 692 ]]
        -- upvalues: u69 (copy), l__scheduleUpdateOnFiber__33 (copy), l__SyncLane__56 (copy), l__NoTimestamp__59 (copy)
        local l__memoizedState__77 = p104.memoizedState;
        while l__memoizedState__77 ~= nil and p105 > 1 do
            l__memoizedState__77 = l__memoizedState__77.next;
            p105 = p105 - 1;
        end;
        if l__memoizedState__77 ~= nil then
            local v107 = u69(l__memoizedState__77.memoizedState, p106, 0);
            l__memoizedState__77.memoizedState = v107;
            l__memoizedState__77.baseState = v107;
            p104.memoizedProps = table.clone(p104.memoizedProps);
            l__scheduleUpdateOnFiber__33(p104, l__SyncLane__56, l__NoTimestamp__59);
        end;
    end;
    u63 = function(p108, p109, p110, p111) --[[ Line: 709 ]]
        -- upvalues: u81 (copy), l__scheduleUpdateOnFiber__33 (copy), l__SyncLane__56 (copy), l__NoTimestamp__59 (copy)
        local l__memoizedState__78 = p108.memoizedState;
        while l__memoizedState__78 ~= nil and p109 > 1 do
            l__memoizedState__78 = l__memoizedState__78.next;
            p109 = p109 - 1;
        end;
        if l__memoizedState__78 ~= nil then
            local v112 = u81(l__memoizedState__78.memoizedState, p110, p111);
            l__memoizedState__78.memoizedState = v112;
            l__memoizedState__78.baseState = v112;
            p108.memoizedProps = table.clone(p108.memoizedProps);
            l__scheduleUpdateOnFiber__33(p108, l__SyncLane__56, l__NoTimestamp__59);
        end;
    end;
else
    u57 = nil;
    u58 = nil;
    u59 = nil;
    u56 = nil;
    u60 = nil;
    u61 = nil;
    u62 = nil;
    u63 = nil;
end;
function findHostInstanceByFiber(p113)
    -- upvalues: l__findCurrentHostFiber__11 (copy)
    local v114 = l__findCurrentHostFiber__11(p113);
    if v114 == nil then
        return nil;
    else
        return v114.stateNode;
    end;
end;
function emptyFindFiberByHostInstance(_)
    return nil;
end;
function getCurrentFiberForDevTools()
    -- upvalues: l__ReactCurrentFiber__50 (copy)
    return l__ReactCurrentFiber__50.current;
end;
function v6.injectIntoDevTools(p115) --[[ Line: 790 ]]
    -- upvalues: l__ReactSharedInternals__22 (copy), l____DEV____1 (copy), l__injectInternals__29 (copy), u61 (ref), u62 (ref), u63 (ref), u57 (ref), u58 (ref), u59 (ref), u56 (ref), u60 (ref)
    local l__findFiberByHostInstance__79 = p115.findFiberByHostInstance;
    local l__ReactCurrentDispatcher__80 = l__ReactSharedInternals__22.ReactCurrentDispatcher;
    local v116;
    if l____DEV____1 then
        v116 = getCurrentFiberForDevTools;
    else
        v116 = nil;
    end;
    return l__injectInternals__29({
        bundleType = p115.bundleType,
        version = p115.version,
        rendererPackageName = p115.rendererPackageName,
        rendererConfig = p115.rendererConfig,
        overrideHookState = u61,
        overrideHookStateDeletePath = u62,
        overrideHookStateRenamePath = u63,
        overrideProps = u57,
        overridePropsDeletePath = u58,
        overridePropsRenamePath = u59,
        setSuspenseHandler = u56,
        scheduleUpdate = u60,
        currentDispatcherRef = l__ReactCurrentDispatcher__80,
        findHostInstanceByFiber = findHostInstanceByFiber,
        findFiberByHostInstance = l__findFiberByHostInstance__79 or emptyFindFiberByHostInstance,
        getCurrentFiber = v116
    });
end;
return v6;