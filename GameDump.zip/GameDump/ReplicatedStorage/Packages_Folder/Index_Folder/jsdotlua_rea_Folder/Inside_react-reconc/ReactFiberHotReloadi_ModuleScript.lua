-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberHotReloading.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent:WaitForChild("shared"));
require(script.Parent:WaitForChild("ReactInternalTypes"));
local _ = require(script.Parent.Parent:WaitForChild("shared")).ReactSymbols.REACT_FORWARD_REF_TYPE;
return {
    resolveFunctionForHotReloading = function(p1) --[[ Name: resolveFunctionForHotReloading, Line 82 ]]
        if _G.__DEV__ then
            return p1;
        else
            return p1;
        end;
    end,
    resolveClassForHotReloading = function(p2) --[[ Name: resolveClassForHotReloading, Line 100 ]]
        if _G.__DEV__ then
            return p2;
        else
            return p2;
        end;
    end,
    resolveForwardRefForHotReloading = function(p3) --[[ Name: resolveForwardRefForHotReloading, Line 106 ]]
        if _G.__DEV__ then
            return p3;
        else
            return p3;
        end;
    end,
    isCompatibleFamilyForHotReloading = function(_, _) --[[ Line: 144 ]]
        warn("isCompatibleFamilyForHotReloading is stubbed (returns false)");
        return false;
    end,
    markFailedErrorBoundaryForHotReloading = function(_) --[[ Line: 224 ]]
        if _G.__DEV__ then
        end;
    end
};