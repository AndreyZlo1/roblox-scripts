-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberHostConfig
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {};