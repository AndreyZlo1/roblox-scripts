-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberSchedulerPriorities.roblox
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    ImmediatePriority = 99,
    UserBlockingPriority = 98,
    NormalPriority = 97,
    LowPriority = 96,
    IdlePriority = 95,
    NoPriority = 90
};