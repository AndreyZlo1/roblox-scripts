-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactChildFiber.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
local v1 = require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local l__Array__2 = v1.Array;
local l__Error__3 = v1.Error;
local l__console__4 = require(script.Parent.Parent:WaitForChild("shared")).console;
local l__describeError__5 = require(script.Parent.Parent:WaitForChild("shared")).describeError;
require(script.Parent.Parent:WaitForChild("shared"));
require(script.Parent.Parent:WaitForChild("react"));
require(script.Parent:WaitForChild("ReactInternalTypes"));
require(script.Parent:WaitForChild("ReactFiberLane"));
local l__getComponentName__6 = require(script.Parent.Parent:WaitForChild("shared")).getComponentName;
local l__ReactFiberFlags__7 = require(script.Parent:WaitForChild("ReactFiberFlags"));
local l__Placement__8 = l__ReactFiberFlags__7.Placement;
local l__Deletion__9 = l__ReactFiberFlags__7.Deletion;
local l__ReactSymbols__10 = require(script.Parent.Parent:WaitForChild("shared")).ReactSymbols;
local l__getIteratorFn__11 = l__ReactSymbols__10.getIteratorFn;
local l__REACT_ELEMENT_TYPE__12 = l__ReactSymbols__10.REACT_ELEMENT_TYPE;
local l__REACT_FRAGMENT_TYPE__13 = l__ReactSymbols__10.REACT_FRAGMENT_TYPE;
local l__REACT_PORTAL_TYPE__14 = l__ReactSymbols__10.REACT_PORTAL_TYPE;
local l__REACT_LAZY_TYPE__15 = l__ReactSymbols__10.REACT_LAZY_TYPE;
local l__REACT_BLOCK_TYPE__16 = l__ReactSymbols__10.REACT_BLOCK_TYPE;
local l__ReactWorkTags__17 = require(script.Parent:WaitForChild("ReactWorkTags"));
local _ = l__ReactWorkTags__17.FunctionComponent;
local _ = l__ReactWorkTags__17.ClassComponent;
local l__HostText__18 = l__ReactWorkTags__17.HostText;
local l__HostPortal__19 = l__ReactWorkTags__17.HostPortal;
local _ = l__ReactWorkTags__17.ForwardRef;
local l__Fragment__20 = l__ReactWorkTags__17.Fragment;
local _ = l__ReactWorkTags__17.SimpleMemoComponent;
local l__Block__21 = l__ReactWorkTags__17.Block;
local l__invariant__22 = require(script.Parent.Parent:WaitForChild("shared")).invariant;
local l__ReactFeatureFlags__23 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags;
local l__enableLazyElements__24 = l__ReactFeatureFlags__23.enableLazyElements;
local l__enableBlocksAPI__25 = l__ReactFeatureFlags__23.enableBlocksAPI;
local v2 = require(script.Parent:WaitForChild("ReactFiber.new"));
local l__createWorkInProgress__26 = v2.createWorkInProgress;
local l__resetWorkInProgress__27 = v2.resetWorkInProgress;
local l__createFiberFromElement__28 = v2.createFiberFromElement;
local l__createFiberFromFragment__29 = v2.createFiberFromFragment;
local l__createFiberFromText__30 = v2.createFiberFromText;
local l__createFiberFromPortal__31 = v2.createFiberFromPortal;
local v3 = {};
local u4, u5, u6;
if l____DEV____1 then
    u4 = false;
    local u7 = {};
    u5 = function(p8, p9) --[[ Line: 112 ]]
        -- upvalues: l__invariant__22 (copy), l__getComponentName__6 (copy), u7 (ref), l__console__4 (copy)
        if p8 == nil or type(p8) ~= "table" then
        elseif p8._store and (not p8._store.validated and p8.key == nil) then
            local v10 = l__invariant__22;
            local v11;
            if p8._store == nil then
                v11 = false;
            else
                v11 = type(p8._store) == "table";
            end;
            v10(v11, "React Component in warnForMissingKey should have a _store. This error is likely caused by a bug in React. Please file an issue.");
            p8._store.validated = true;
            local v12 = l__getComponentName__6(p9.type) or "Component";
            if u7[v12] then
            else
                u7[v12] = true;
                l__console__4.error("Each child in a list should have a unique \"key\" prop. See https://reactjs.org/link/warning-keys for more information.");
            end;
        end;
    end;
    u6 = {};
else
    u6 = nil;
    u5 = function(_, _) --[[ Line: 90 ]] end;
    u4 = nil;
end;
local l__isArray__32 = l__Array__2.isArray;
function coerceRef(p13, _, p14)
    -- upvalues: l____DEV____1 (copy), l__getComponentName__6 (copy), l__Error__3 (copy)
    local l__ref__33 = p14.ref;
    if l__ref__33 ~= nil and type(l__ref__33) == "string" then
        if not p14._owner or (not p14._self or p14._owner.stateNode == p14._self) then
            local v15 = l____DEV____1 and (l__getComponentName__6(p13.type) or "Component") or "<enable __DEV__ mode for component names>";
            error(l__Error__3.new(string.format("Component \"%s\" contains the string ref \"%s\". Support for string refs has been removed. We recommend using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref", v15, (tostring(l__ref__33)))));
        end;
        if not p14._owner then
            error("Expected ref to be a function or an object returned by React.createRef(), or nil.");
        end;
    end;
    return l__ref__33;
end;
function resolveLazyType(p16)
    -- upvalues: l__describeError__5 (copy)
    local v17, v18 = xpcall(p16._init, l__describeError__5, p16._payload);
    if v17 then
        return v18;
    else
        return p16;
    end;
end;
local function v176(u19) --[[ Line: 353 ]]
    -- upvalues: l__Deletion__9 (copy), l__createWorkInProgress__26 (copy), l__Placement__8 (copy), l__HostText__18 (copy), l__createFiberFromText__30 (copy), l____DEV____1 (copy), l__enableBlocksAPI__25 (copy), l__Block__21 (copy), l__REACT_LAZY_TYPE__15 (copy), l__REACT_BLOCK_TYPE__16 (copy), l__createFiberFromElement__28 (copy), l__HostPortal__19 (copy), l__createFiberFromPortal__31 (copy), l__Fragment__20 (copy), l__createFiberFromFragment__29 (copy), l__REACT_ELEMENT_TYPE__12 (copy), l__REACT_PORTAL_TYPE__14 (copy), l__enableLazyElements__24 (copy), l__getComponentName__6 (copy), u6 (ref), l__console__4 (copy), l__REACT_FRAGMENT_TYPE__13 (copy), u5 (ref), u4 (ref), l__isArray__32 (copy), l__getIteratorFn__11 (copy)
    local function u22(_, p20) --[[ Line: 387 ]]
        local v21 = {};
        while p20 ~= nil do
            if p20.key == nil then
                v21[p20.index] = p20;
            else
                v21[p20.key] = p20;
            end;
            p20 = p20.sibling;
        end;
        return v21;
    end;
    local function u30(p23, p24, p25, p26) --[[ Line: 476 ]]
        -- upvalues: l__createWorkInProgress__26 (ref), l____DEV____1 (ref), l__enableBlocksAPI__25 (ref), l__Block__21 (ref), l__REACT_LAZY_TYPE__15 (ref), l__REACT_BLOCK_TYPE__16 (ref), l__createFiberFromElement__28 (ref)
        if p24 ~= nil then
            if p24.elementType == p25.type then
                local v27 = l__createWorkInProgress__26(p24, p25.props);
                v27.index = 1;
                v27.sibling = nil;
                v27.ref = coerceRef(p23, p24, p25);
                v27.return_ = p23;
                if l____DEV____1 then
                    v27._debugSource = p25._source;
                    v27._debugOwner = p25._owner;
                end;
                return v27;
            end;
            if l__enableBlocksAPI__25 and p24.tag == l__Block__21 then
                local l__type__34 = p25.type;
                if type(l__type__34) == "table" and l__type__34["$$typeof"] == l__REACT_LAZY_TYPE__15 then
                    l__type__34 = resolveLazyType(l__type__34);
                end;
                if l__type__34["$$typeof"] == l__REACT_BLOCK_TYPE__16 and l__type__34._render == p24.type._render then
                    local v28 = l__createWorkInProgress__26(p24, p25.props);
                    v28.index = 1;
                    v28.sibling = nil;
                    v28.return_ = p23;
                    v28.type = l__type__34;
                    if l____DEV____1 then
                        v28._debugSource = p25._source;
                        v28._debugOwner = p25._owner;
                    end;
                    return v28;
                end;
            end;
        end;
        local v29 = l__createFiberFromElement__28(p25, p23.mode, p26);
        v29.ref = coerceRef(p23, p24, p25);
        v29.return_ = p23;
        return v29;
    end;
    local function u37(p31, p32, p33, p34) --[[ Line: 529 ]]
        -- upvalues: l__HostPortal__19 (ref), l__createFiberFromPortal__31 (ref), l__createWorkInProgress__26 (ref)
        if p32 == nil or (p32.tag ~= l__HostPortal__19 or (p32.stateNode.containerInfo ~= p33.containerInfo or p32.stateNode.implementation ~= p33.implementation)) then
            local v35 = l__createFiberFromPortal__31(p33, p31.mode, p34);
            v35.return_ = p31;
            return v35;
        end;
        local v36 = l__createWorkInProgress__26(p32, p33.children or {});
        v36.index = 1;
        v36.sibling = nil;
        v36.return_ = p31;
        return v36;
    end;
    local function u50(p38, p39, p40, p41) --[[ Line: 600 ]]
        -- upvalues: l__REACT_ELEMENT_TYPE__12 (ref), l__createFiberFromElement__28 (ref), l__REACT_PORTAL_TYPE__14 (ref), l__createFiberFromPortal__31 (ref), l__REACT_LAZY_TYPE__15 (ref), l__enableLazyElements__24 (ref), u50 (copy), l__createFiberFromFragment__29 (ref), l__createFiberFromText__30 (ref), l____DEV____1 (ref), l__getComponentName__6 (ref), u6 (ref), l__console__4 (ref)
        if p39 == nil then
            return nil;
        end;
        local v42 = type(p39);
        if v42 ~= "table" then
            if v42 ~= "string" and v42 ~= "number" then
                if l____DEV____1 and (v42 == "function" and l____DEV____1) then
                    local v43 = l__getComponentName__6(p38.type) or "Component";
                    if not u6[v43] then
                        u6[v43] = true;
                        l__console__4.error("Functions are not valid as a React child. This may happen if you return a Component instead of <Component /> from render. Or maybe you meant to call this function rather than return it.");
                    end;
                end;
                return nil;
            end;
            local v44 = l__createFiberFromText__30(tostring(p39), p38.mode, p40);
            v44.return_ = p38;
            return v44;
        end;
        if p39.key == nil then
            local v45 = type(p41);
            if v45 == "string" or v45 == "number" then
                p39.key = p41;
            elseif v45 == "table" then
                p39.key = tostring(p41);
            end;
        end;
        local v46 = p39["$$typeof"];
        if v46 == l__REACT_ELEMENT_TYPE__12 then
            local v47 = l__createFiberFromElement__28(p39, p38.mode, p40);
            v47.ref = coerceRef(p38, nil, p39);
            v47.return_ = p38;
            return v47;
        end;
        if v46 == l__REACT_PORTAL_TYPE__14 then
            local v48 = l__createFiberFromPortal__31(p39, p38.mode, p40);
            v48.return_ = p38;
            return v48;
        end;
        if v46 == l__REACT_LAZY_TYPE__15 and l__enableLazyElements__24 then
            return u50(p38, p39._init(p39._payload), p40);
        end;
        local v49 = l__createFiberFromFragment__29(p39, p38.mode, p40, nil);
        v49.return_ = p38;
        return v49;
    end;
    local function u68(p51, p52, p53, p54, p55) --[[ Line: 671 ]]
        -- upvalues: l__REACT_ELEMENT_TYPE__12 (ref), l__REACT_FRAGMENT_TYPE__13 (ref), l__Fragment__20 (ref), l__createFiberFromFragment__29 (ref), l__createWorkInProgress__26 (ref), u30 (copy), l__REACT_PORTAL_TYPE__14 (ref), u37 (copy), l__REACT_LAZY_TYPE__15 (ref), l__enableLazyElements__24 (ref), u68 (copy), l__HostText__18 (ref), l__createFiberFromText__30 (ref), l____DEV____1 (ref), l__getComponentName__6 (ref), u6 (ref), l__console__4 (ref)
        if p53 == nil then
            return nil;
        else
            local v56;
            if p52 == nil then
                v56 = nil;
            else
                v56 = p52.key;
            end;
            local v57 = type(p53);
            if v57 == "table" then
                if p53.key == nil then
                    local v58 = type(p55);
                    if v58 == "string" or v58 == "number" then
                        p53.key = p55;
                    elseif v58 == "table" then
                        p53.key = tostring(p55);
                    end;
                end;
                local v59 = p53["$$typeof"];
                if v59 == l__REACT_ELEMENT_TYPE__12 then
                    if p53.key ~= v56 then
                        return nil;
                    end;
                    if p53.type ~= l__REACT_FRAGMENT_TYPE__13 then
                        return u30(p51, p52, p53, p54);
                    end;
                    local l__children__35 = p53.props.children;
                    if p52 == nil or p52.tag ~= l__Fragment__20 then
                        local v60 = l__createFiberFromFragment__29(l__children__35, p51.mode, p54, v56);
                        v60.return_ = p51;
                        return v60;
                    end;
                    local v61 = l__createWorkInProgress__26(p52, l__children__35);
                    v61.index = 1;
                    v61.sibling = nil;
                    v61.return_ = p51;
                    return v61;
                elseif v59 == l__REACT_PORTAL_TYPE__14 then
                    if p53.key == v56 then
                        return u37(p51, p52, p53, p54);
                    else
                        return nil;
                    end;
                else
                    if v59 == l__REACT_LAZY_TYPE__15 and l__enableLazyElements__24 then
                        return u68(p51, p52, p53._init(p53._payload), p54);
                    end;
                    if v56 ~= nil then
                        return nil;
                    end;
                    if p52 == nil or p52.tag ~= l__Fragment__20 then
                        local v62 = l__createFiberFromFragment__29(p53, p51.mode, p54, nil);
                        v62.return_ = p51;
                        return v62;
                    end;
                    local v63 = l__createWorkInProgress__26(p52, p53);
                    v63.index = 1;
                    v63.sibling = nil;
                    v63.return_ = p51;
                    return v63;
                end;
            else
                if v57 ~= "string" and v57 ~= "number" then
                    if l____DEV____1 and (v57 == "function" and l____DEV____1) then
                        local v64 = l__getComponentName__6(p51.type) or "Component";
                        if not u6[v64] then
                            u6[v64] = true;
                            l__console__4.error("Functions are not valid as a React child. This may happen if you return a Component instead of <Component /> from render. Or maybe you meant to call this function rather than return it.");
                        end;
                    end;
                    return nil;
                end;
                if v56 ~= nil then
                    return nil;
                end;
                local v65 = tostring(p53);
                if p52 == nil or p52.tag ~= l__HostText__18 then
                    local v66 = l__createFiberFromText__30(v65, p51.mode, p54);
                    v66.return_ = p51;
                    return v66;
                end;
                local v67 = l__createWorkInProgress__26(p52, v65);
                v67.index = 1;
                v67.sibling = nil;
                v67.return_ = p51;
                return v67;
            end;
        end;
    end;
    local function u89(p69, p70, p71, p72, p73, p74) --[[ Line: 759 ]]
        -- upvalues: l__REACT_ELEMENT_TYPE__12 (ref), l__REACT_FRAGMENT_TYPE__13 (ref), l__Fragment__20 (ref), l__createFiberFromFragment__29 (ref), l__createWorkInProgress__26 (ref), u30 (copy), l__REACT_PORTAL_TYPE__14 (ref), u37 (copy), l__REACT_LAZY_TYPE__15 (ref), l__enableLazyElements__24 (ref), u89 (copy), l__HostText__18 (ref), l__createFiberFromText__30 (ref), l____DEV____1 (ref), l__getComponentName__6 (ref), u6 (ref), l__console__4 (ref)
        if p72 == nil then
            return nil;
        end;
        local v75 = type(p72);
        if v75 ~= "table" then
            if v75 ~= "string" and v75 ~= "number" then
                if l____DEV____1 and (v75 == "function" and l____DEV____1) then
                    local v76 = l__getComponentName__6(p70.type) or "Component";
                    if not u6[v76] then
                        u6[v76] = true;
                        l__console__4.error("Functions are not valid as a React child. This may happen if you return a Component instead of <Component /> from render. Or maybe you meant to call this function rather than return it.");
                    end;
                end;
                return nil;
            end;
            local v77 = p69[p71] or nil;
            local v78 = tostring(p72);
            if v77 == nil or v77.tag ~= l__HostText__18 then
                local v79 = l__createFiberFromText__30(v78, p70.mode, p73);
                v79.return_ = p70;
                return v79;
            end;
            local v80 = l__createWorkInProgress__26(v77, v78);
            v80.index = 1;
            v80.sibling = nil;
            v80.return_ = p70;
            return v80;
        end;
        if p72.key == nil then
            local v81 = type(p74);
            if v81 == "string" or v81 == "number" then
                p72.key = p74;
            elseif v81 == "table" then
                p72.key = tostring(p74);
            end;
        end;
        local v82 = p72["$$typeof"];
        if v82 ~= l__REACT_ELEMENT_TYPE__12 then
            if v82 == l__REACT_PORTAL_TYPE__14 then
                if p72.key ~= nil then
                    p71 = p72.key;
                end;
                return u37(p70, p69[p71], p72, p73);
            end;
            if v82 == l__REACT_LAZY_TYPE__15 and l__enableLazyElements__24 then
                return u89(p69, p70, p71, p72._init(p72._payload), p73);
            end;
            local v83 = p69[p71];
            if v83 == nil or v83.tag ~= l__Fragment__20 then
                local v84 = l__createFiberFromFragment__29(p72, p70.mode, p73, nil);
                v84.return_ = p70;
                return v84;
            end;
            local v85 = l__createWorkInProgress__26(v83, p72);
            v85.index = 1;
            v85.sibling = nil;
            v85.return_ = p70;
            return v85;
        end;
        if p72.key ~= nil then
            p71 = p72.key;
        end;
        local v86 = p69[p71];
        if p72.type ~= l__REACT_FRAGMENT_TYPE__13 then
            return u30(p70, v86, p72, p73);
        end;
        local l__children__36 = p72.props.children;
        local l__key__37 = p72.key;
        if v86 == nil or v86.tag ~= l__Fragment__20 then
            local v87 = l__createFiberFromFragment__29(l__children__36, p70.mode, p73, l__key__37);
            v87.return_ = p70;
            return v87;
        end;
        local v88 = l__createWorkInProgress__26(v86, l__children__36);
        v88.index = 1;
        v88.sibling = nil;
        v88.return_ = p70;
        return v88;
    end;
    local function u94(p90, p91, p92) --[[ Line: 853 ]]
        -- upvalues: l____DEV____1 (ref), l__REACT_ELEMENT_TYPE__12 (ref), l__REACT_PORTAL_TYPE__14 (ref), u5 (ref), l__console__4 (ref), l__REACT_LAZY_TYPE__15 (ref), l__enableLazyElements__24 (ref), u94 (copy)
        if l____DEV____1 then
            if p90 == nil or type(p90) ~= "table" then
                return p91;
            end;
            local v93 = p90["$$typeof"];
            if v93 == l__REACT_ELEMENT_TYPE__12 or v93 == l__REACT_PORTAL_TYPE__14 then
                u5(p90, p92);
                local l__key__38 = p90.key;
                if type(l__key__38) == "string" then
                    if p91 == nil then
                        return {
                            [l__key__38] = true
                        };
                    elseif p91[l__key__38] then
                        l__console__4.error("Encountered two children with the same key, `%s`. Keys should be unique so that components maintain their identity across updates. Non-unique keys may cause children to be duplicated and/or omitted — the behavior is unsupported and could change in a future version.", l__key__38);
                        return p91;
                    else
                        p91[l__key__38] = true;
                        return p91;
                    end;
                else
                    return p91;
                end;
            end;
            if v93 == l__REACT_LAZY_TYPE__15 and l__enableLazyElements__24 then
                u94(p90._init(p90._payload), p91, p92);
            end;
        end;
        return p91;
    end;
    local function u115(p95, p96, p97, p98) --[[ Line: 895 ]]
        -- upvalues: l____DEV____1 (ref), u94 (copy), u68 (copy), u19 (copy), l__Deletion__9 (ref), l__Placement__8 (ref), u50 (copy), u22 (copy), u89 (copy)
        if l____DEV____1 then
            local v99 = nil;
            for _, v100 in p97 do
                v99 = u94(v100, v99, p95);
            end;
        end;
        local v101 = #p97;
        local v102 = 1;
        local v103 = nil;
        local v104 = nil;
        local v105 = 1;
        local v106;
        while true do
            if p96 == nil or v102 > v101 then
                v106 = p96;
                break;
            end;
            if v102 < p96.index then
                v106 = p96;
                p96 = nil;
            else
                v106 = p96.sibling;
            end;
            local v107 = p97[v102];
            local v108;
            if v107 == nil or (type(v107) ~= "table" or v107["$$typeof"] == nil) then
                v108 = u68(p95, p96, v107, p98);
            else
                v108 = u68(p95, p96, v107, p98, v102);
            end;
            if v108 == nil then
                if p96 ~= nil then
                    v106 = p96;
                end;
                break;
            end;
            if u19 and (p96 and (v108.alternate == nil and u19)) then
                local l__deletions__39 = p95.deletions;
                if l__deletions__39 == nil then
                    p95.deletions = { p96 };
                    p95.flags = bit32.bor(p95.flags, l__Deletion__9);
                else
                    table.insert(l__deletions__39, p96);
                end;
            end;
            v108.index = v102;
            if u19 then
                local l__alternate__40 = v108.alternate;
                if l__alternate__40 == nil then
                    v108.flags = bit32.bor(v108.flags, l__Placement__8);
                else
                    local l__index__41 = l__alternate__40.index;
                    if l__index__41 < v105 then
                        v108.flags = bit32.bor(v108.flags, l__Placement__8);
                    else
                        v105 = l__index__41;
                    end;
                end;
            end;
            if v103 == nil then
                v104 = v108;
            else
                v103.sibling = v108;
            end;
            v102 = v102 + 1;
            v103 = v108;
            p96 = v106;
        end;
        if v101 < v102 then
            if not u19 then
                return v104;
            end;
            while v106 ~= nil do
                if u19 then
                    local l__deletions__42 = p95.deletions;
                    if l__deletions__42 == nil then
                        p95.deletions = { v106 };
                        p95.flags = bit32.bor(p95.flags, l__Deletion__9);
                    else
                        table.insert(l__deletions__42, v106);
                    end;
                end;
                v106 = v106.sibling;
            end;
            return v104;
        end;
        if v106 == nil then
            while v102 <= v101 do
                local v109 = p97[v102];
                local v110;
                if v109 == nil or (type(v109) ~= "table" or v109["$$typeof"] == nil) then
                    v110 = u50(p95, v109, p98);
                else
                    v110 = u50(p95, v109, p98, v102);
                end;
                if v110 == nil then
                    v102 = v102 + 1;
                    v110 = v103;
                else
                    v110.index = v102;
                    if u19 then
                        local l__alternate__43 = v110.alternate;
                        if l__alternate__43 == nil then
                            v110.flags = bit32.bor(v110.flags, l__Placement__8);
                        else
                            local l__index__44 = l__alternate__43.index;
                            if l__index__44 < v105 then
                                v110.flags = bit32.bor(v110.flags, l__Placement__8);
                            else
                                v105 = l__index__44;
                            end;
                        end;
                    end;
                    if v103 == nil then
                        v104 = v110;
                    else
                        v103.sibling = v110;
                    end;
                    v102 = v102 + 1;
                end;
                v103 = v110;
            end;
            return v104;
        end;
        local v111 = u22(p95, v106);
        while v102 <= v101 do
            local v112 = u89(v111, p95, v102, p97[v102], p98, v102);
            if v112 == nil then
                v112 = v103;
            else
                if u19 and v112.alternate ~= nil then
                    local v113;
                    if v112.key == nil then
                        v113 = v102;
                    else
                        v113 = v112.key;
                    end;
                    v111[v113] = nil;
                end;
                v112.index = v102;
                if u19 then
                    local l__alternate__45 = v112.alternate;
                    if l__alternate__45 == nil then
                        v112.flags = bit32.bor(v112.flags, l__Placement__8);
                    else
                        local l__index__46 = l__alternate__45.index;
                        if l__index__46 < v105 then
                            v112.flags = bit32.bor(v112.flags, l__Placement__8);
                        else
                            v105 = l__index__46;
                        end;
                    end;
                end;
                if v103 == nil then
                    v104 = v112;
                else
                    v103.sibling = v112;
                end;
            end;
            v102 = v102 + 1;
            v103 = v112;
        end;
        if u19 then
            for _, v114 in v111 do
                if u19 then
                    local l__deletions__47 = p95.deletions;
                    if l__deletions__47 == nil then
                        p95.deletions = { v114 };
                        p95.flags = bit32.bor(p95.flags, l__Deletion__9);
                    else
                        table.insert(l__deletions__47, v114);
                    end;
                end;
            end;
        end;
        return v104;
    end;
    local function u136(p116, p117, p118, p119, p120) --[[ Line: 1102 ]]
        -- upvalues: l____DEV____1 (ref), u4 (ref), l__console__4 (ref), u94 (copy), u68 (copy), u19 (copy), l__Deletion__9 (ref), l__Placement__8 (ref), u50 (copy), u22 (copy), u89 (copy)
        if l____DEV____1 then
            if p118.entries == p120 then
                if not u4 then
                    l__console__4.error("Using Maps as children is not supported. Use an array of keyed ReactElements instead.");
                end;
                u4 = true;
            end;
            local v121 = p120(p118);
            if v121 then
                local v122 = v121.next();
                local v123 = nil;
                while not v122.done do
                    v122 = v121.next();
                    v123 = u94(v122.value, v123, p116);
                end;
            end;
        end;
        local v124 = p120(p118);
        local v125 = v124.next();
        local v126 = 1;
        local v127 = nil;
        local v128 = 1;
        local v129 = nil;
        local v130;
        while true do
            if p117 == nil or v125.done then
                v130 = p117;
                break;
            end;
            if v126 < p117.index then
                v130 = p117;
                p117 = nil;
            else
                v130 = p117.sibling;
            end;
            local v131 = u68(p116, p117, v125.value, p119, v125.key);
            if v131 == nil then
                if p117 ~= nil then
                    v130 = p117;
                end;
                break;
            end;
            if u19 and (p117 and (v131.alternate == nil and u19)) then
                local l__deletions__48 = p116.deletions;
                if l__deletions__48 == nil then
                    p116.deletions = { p117 };
                    p116.flags = bit32.bor(p116.flags, l__Deletion__9);
                else
                    table.insert(l__deletions__48, p117);
                end;
            end;
            v131.index = v126;
            if u19 then
                local l__alternate__49 = v131.alternate;
                if l__alternate__49 == nil then
                    v131.flags = bit32.bor(v131.flags, l__Placement__8);
                else
                    local l__index__50 = l__alternate__49.index;
                    if l__index__50 < v128 then
                        v131.flags = bit32.bor(v131.flags, l__Placement__8);
                    else
                        v128 = l__index__50;
                    end;
                end;
            end;
            if v129 == nil then
                v127 = v131;
            else
                v129.sibling = v131;
            end;
            v126 = v126 + 1;
            v125 = v124.next();
            v129 = v131;
            p117 = v130;
        end;
        if v125.done then
            if not u19 then
                return v127;
            end;
            while v130 ~= nil do
                if u19 then
                    local l__deletions__51 = p116.deletions;
                    if l__deletions__51 == nil then
                        p116.deletions = { v130 };
                        p116.flags = bit32.bor(p116.flags, l__Deletion__9);
                    else
                        table.insert(l__deletions__51, v130);
                    end;
                end;
                v130 = v130.sibling;
            end;
            return v127;
        end;
        if v130 == nil then
            while not v125.done do
                local v132 = u50(p116, v125.value, p119, v125.key);
                if v132 == nil then
                    v126 = v126 + 1;
                    v125 = v124.next();
                    v132 = v129;
                else
                    v132.index = v126;
                    if u19 then
                        local l__alternate__52 = v132.alternate;
                        if l__alternate__52 == nil then
                            v132.flags = bit32.bor(v132.flags, l__Placement__8);
                        else
                            local l__index__53 = l__alternate__52.index;
                            if l__index__53 < v128 then
                                v132.flags = bit32.bor(v132.flags, l__Placement__8);
                            else
                                v128 = l__index__53;
                            end;
                        end;
                    end;
                    if v129 == nil then
                        v127 = v132;
                    else
                        v129.sibling = v132;
                    end;
                    v126 = v126 + 1;
                    v125 = v124.next();
                end;
                v129 = v132;
            end;
            return v127;
        end;
        local v133 = nil;
        while not v125.done do
            v133 = v133 or u22(p116, v130);
            local v134 = u89(v133, p116, v126, v125.value, p119, v125.key);
            if v134 == nil then
                v134 = v129;
            else
                if u19 and v134.alternate ~= nil then
                    if v134.key == nil then
                        v133[v126] = nil;
                    else
                        v133[v134.key] = nil;
                    end;
                end;
                v134.index = v126;
                if u19 then
                    local l__alternate__54 = v134.alternate;
                    if l__alternate__54 == nil then
                        v134.flags = bit32.bor(v134.flags, l__Placement__8);
                    else
                        local l__index__55 = l__alternate__54.index;
                        if l__index__55 < v128 then
                            v134.flags = bit32.bor(v134.flags, l__Placement__8);
                        else
                            v128 = l__index__55;
                        end;
                    end;
                end;
                if v129 == nil then
                    v127 = v134;
                else
                    v129.sibling = v134;
                end;
            end;
            v126 = v126 + 1;
            v125 = v124.next();
            v129 = v134;
        end;
        if u19 then
            for _, v135 in v133 do
                if u19 then
                    local l__deletions__56 = p116.deletions;
                    if l__deletions__56 == nil then
                        p116.deletions = { v135 };
                        p116.flags = bit32.bor(p116.flags, l__Deletion__9);
                    else
                        table.insert(l__deletions__56, v135);
                    end;
                end;
            end;
        end;
        return v127;
    end;
    local function u143(p137, p138, p139, p140) --[[ Line: 1315 ]]
        -- upvalues: l__HostText__18 (ref), u19 (copy), l__Deletion__9 (ref), l__createWorkInProgress__26 (ref), l__createFiberFromText__30 (ref)
        if p138 == nil or p138.tag ~= l__HostText__18 then
            if u19 then
                while p138 ~= nil do
                    if u19 then
                        local l__deletions__57 = p137.deletions;
                        if l__deletions__57 == nil then
                            p137.deletions = { p138 };
                            p137.flags = bit32.bor(p137.flags, l__Deletion__9);
                        else
                            table.insert(l__deletions__57, p138);
                        end;
                    end;
                    p138 = p138.sibling;
                end;
            end;
            local v141 = l__createFiberFromText__30(p139, p137.mode, p140);
            v141.return_ = p137;
            return v141;
        end;
        local l__sibling__58 = p138.sibling;
        if u19 then
            while l__sibling__58 ~= nil do
                if u19 then
                    local l__deletions__59 = p137.deletions;
                    if l__deletions__59 == nil then
                        p137.deletions = { l__sibling__58 };
                        p137.flags = bit32.bor(p137.flags, l__Deletion__9);
                    else
                        table.insert(l__deletions__59, l__sibling__58);
                    end;
                end;
                l__sibling__58 = l__sibling__58.sibling;
            end;
        end;
        local v142 = l__createWorkInProgress__26(p138, p139);
        v142.index = 1;
        v142.sibling = nil;
        v142.return_ = p137;
        return v142;
    end;
    local function u153(p144, p145, p146, p147) --[[ Line: 1340 ]]
        -- upvalues: l__Fragment__20 (ref), l__REACT_FRAGMENT_TYPE__13 (ref), u19 (copy), l__Deletion__9 (ref), l__createWorkInProgress__26 (ref), l____DEV____1 (ref), l__createFiberFromFragment__29 (ref), l__createFiberFromElement__28 (ref)
        local l__key__60 = p146.key;
        local v148 = p145;
        while p145 ~= nil do
            if p145.key == l__key__60 then
                if p145.tag == l__Fragment__20 then
                    if p146.type == l__REACT_FRAGMENT_TYPE__13 then
                        local l__sibling__61 = p145.sibling;
                        if u19 then
                            while l__sibling__61 ~= nil do
                                if u19 then
                                    local l__deletions__62 = p144.deletions;
                                    if l__deletions__62 == nil then
                                        p144.deletions = { l__sibling__61 };
                                        p144.flags = bit32.bor(p144.flags, l__Deletion__9);
                                    else
                                        table.insert(l__deletions__62, l__sibling__61);
                                    end;
                                end;
                                l__sibling__61 = l__sibling__61.sibling;
                            end;
                        end;
                        local v149 = l__createWorkInProgress__26(p145, p146.props.children);
                        v149.index = 1;
                        v149.sibling = nil;
                        v149.return_ = p144;
                        if l____DEV____1 then
                            v149._debugSource = p146._source;
                            v149._debugOwner = p146._owner;
                        end;
                        return v149;
                    end;
                elseif p145.elementType == p146.type then
                    local l__sibling__63 = p145.sibling;
                    if u19 then
                        while l__sibling__63 ~= nil do
                            if u19 then
                                local l__deletions__64 = p144.deletions;
                                if l__deletions__64 == nil then
                                    p144.deletions = { l__sibling__63 };
                                    p144.flags = bit32.bor(p144.flags, l__Deletion__9);
                                else
                                    table.insert(l__deletions__64, l__sibling__63);
                                end;
                            end;
                            l__sibling__63 = l__sibling__63.sibling;
                        end;
                    end;
                    local v150 = l__createWorkInProgress__26(p145, p146.props);
                    v150.index = 1;
                    v150.sibling = nil;
                    v150.ref = coerceRef(p144, p145, p146);
                    v150.return_ = p144;
                    if l____DEV____1 then
                        v150._debugSource = p146._source;
                        v150._debugOwner = p146._owner;
                    end;
                    return v150;
                end;
                if u19 then
                    while p145 ~= nil do
                        if u19 then
                            local l__deletions__65 = p144.deletions;
                            if l__deletions__65 == nil then
                                p144.deletions = { p145 };
                                p144.flags = bit32.bor(p144.flags, l__Deletion__9);
                            else
                                table.insert(l__deletions__65, p145);
                            end;
                        end;
                        p145 = p145.sibling;
                    end;
                end;
                break;
            end;
            if u19 then
                local l__deletions__66 = p144.deletions;
                if l__deletions__66 == nil then
                    p144.deletions = { p145 };
                    p144.flags = bit32.bor(p144.flags, l__Deletion__9);
                else
                    table.insert(l__deletions__66, p145);
                end;
            end;
            p145 = p145.sibling;
        end;
        if p146.type == l__REACT_FRAGMENT_TYPE__13 then
            local v151 = l__createFiberFromFragment__29(p146.props.children, p144.mode, p147, p146.key);
            v151.return_ = p144;
            return v151;
        end;
        local v152 = l__createFiberFromElement__28(p146, p144.mode, p147);
        v152.ref = coerceRef(p144, v148, p146);
        v152.return_ = p144;
        return v152;
    end;
    local function u160(p154, p155, p156, p157) --[[ Line: 1440 ]]
        -- upvalues: l__HostPortal__19 (ref), u19 (copy), l__Deletion__9 (ref), l__createWorkInProgress__26 (ref), l__createFiberFromPortal__31 (ref)
        local l__key__67 = p156.key;
        while p155 ~= nil do
            if p155.key == l__key__67 then
                if p155.tag == l__HostPortal__19 and (p155.stateNode.containerInfo == p156.containerInfo and p155.stateNode.implementation == p156.implementation) then
                    local l__sibling__68 = p155.sibling;
                    if u19 then
                        while l__sibling__68 ~= nil do
                            if u19 then
                                local l__deletions__69 = p154.deletions;
                                if l__deletions__69 == nil then
                                    p154.deletions = { l__sibling__68 };
                                    p154.flags = bit32.bor(p154.flags, l__Deletion__9);
                                else
                                    table.insert(l__deletions__69, l__sibling__68);
                                end;
                            end;
                            l__sibling__68 = l__sibling__68.sibling;
                        end;
                    end;
                    local v158 = l__createWorkInProgress__26(p155, p156.children or {});
                    v158.index = 1;
                    v158.sibling = nil;
                    v158.return_ = p154;
                    return v158;
                end;
                if u19 then
                    while p155 ~= nil do
                        if u19 then
                            local l__deletions__70 = p154.deletions;
                            if l__deletions__70 == nil then
                                p154.deletions = { p155 };
                                p154.flags = bit32.bor(p154.flags, l__Deletion__9);
                            else
                                table.insert(l__deletions__70, p155);
                            end;
                        end;
                        p155 = p155.sibling;
                    end;
                end;
                break;
            end;
            if u19 then
                local l__deletions__71 = p154.deletions;
                if l__deletions__71 == nil then
                    p154.deletions = { p155 };
                    p154.flags = bit32.bor(p154.flags, l__Deletion__9);
                else
                    table.insert(l__deletions__71, p155);
                end;
            end;
            p155 = p155.sibling;
        end;
        local v159 = l__createFiberFromPortal__31(p156, p154.mode, p157);
        v159.return_ = p154;
        return v159;
    end;
    local function u175(p161, p162, p163, p164) --[[ Line: 1479 ]]
        -- upvalues: l__REACT_FRAGMENT_TYPE__13 (ref), l__isArray__32 (ref), l__REACT_ELEMENT_TYPE__12 (ref), u153 (copy), u19 (copy), l__Placement__8 (ref), l__REACT_PORTAL_TYPE__14 (ref), u160 (copy), l__REACT_LAZY_TYPE__15 (ref), l__enableLazyElements__24 (ref), u175 (copy), u115 (copy), u143 (copy), l__getIteratorFn__11 (ref), u136 (copy), l____DEV____1 (ref), l__getComponentName__6 (ref), u6 (ref), l__console__4 (ref), l__Deletion__9 (ref)
        local v165 = type(p163);
        local v166;
        if p163 == nil or (v165 ~= "table" or p163.type ~= l__REACT_FRAGMENT_TYPE__13) then
            v166 = false;
        else
            v166 = p163.key == nil;
        end;
        if v166 then
            p163 = p163.props.children;
            v165 = type(p163);
        end;
        local v167 = l__isArray__32(p163);
        local v168;
        if p163 == nil or v165 ~= "table" then
            v168 = false;
        else
            v168 = not v167;
        end;
        if v168 then
            local v169 = p163["$$typeof"];
            if v169 == l__REACT_ELEMENT_TYPE__12 then
                local v170 = u153(p161, p162, p163, p164);
                if u19 and v170.alternate == nil then
                    v170.flags = bit32.bor(v170.flags, l__Placement__8);
                end;
                return v170;
            end;
            if v169 == l__REACT_PORTAL_TYPE__14 then
                local v171 = u160(p161, p162, p163, p164);
                if u19 and v171.alternate == nil then
                    v171.flags = bit32.bor(v171.flags, l__Placement__8);
                end;
                return v171;
            end;
            if v169 == l__REACT_LAZY_TYPE__15 and l__enableLazyElements__24 then
                return u175(p161, p162, p163._init(p163._payload), p164);
            end;
        else
            if v167 then
                return u115(p161, p162, p163, p164);
            end;
            if v165 == "string" or v165 == "number" then
                local v172 = u143(p161, p162, tostring(p163), p164);
                if u19 and v172.alternate == nil then
                    v172.flags = bit32.bor(v172.flags, l__Placement__8);
                end;
                return v172;
            end;
        end;
        local v173 = l__getIteratorFn__11(p163);
        if v173 then
            return u136(p161, p162, p163, p164, v173);
        end;
        if l____DEV____1 and (v165 == "function" and l____DEV____1) then
            local v174 = l__getComponentName__6(p161.type) or "Component";
            if not u6[v174] then
                u6[v174] = true;
                l__console__4.error("Functions are not valid as a React child. This may happen if you return a Component instead of <Component /> from render. Or maybe you meant to call this function rather than return it.");
            end;
        end;
        local _ = p163 == nil;
        if not u19 then
            return nil;
        end;
        while p162 ~= nil do
            if u19 then
                local l__deletions__72 = p161.deletions;
                if l__deletions__72 == nil then
                    p161.deletions = { p162 };
                    p161.flags = bit32.bor(p161.flags, l__Deletion__9);
                else
                    table.insert(l__deletions__72, p162);
                end;
            end;
            p162 = p162.sibling;
        end;
        return nil;
    end;
    return u175;
end;
v3.reconcileChildFibers = v176(true);
v3.mountChildFibers = v176(false);
function v3.cloneChildFibers(_, p177) --[[ Line: 1627 ]]
    -- upvalues: l__createWorkInProgress__26 (copy)
    if p177.child == nil then
    else
        local l__child__73 = p177.child;
        local v178 = l__createWorkInProgress__26(l__child__73, l__child__73.pendingProps);
        p177.child = v178;
        v178.return_ = p177;
        while l__child__73.sibling ~= nil do
            l__child__73 = l__child__73.sibling;
            v178.sibling = l__createWorkInProgress__26(l__child__73, l__child__73.pendingProps);
            v178 = v178.sibling;
            v178.return_ = p177;
        end;
        v178.sibling = nil;
    end;
end;
function v3.resetChildFibers(p179, p180) --[[ Line: 1654 ]]
    -- upvalues: l__resetWorkInProgress__27 (copy)
    local l__child__74 = p179.child;
    while l__child__74 ~= nil do
        l__resetWorkInProgress__27(l__child__74, p180);
        l__child__74 = l__child__74.sibling;
    end;
end;
return v3;