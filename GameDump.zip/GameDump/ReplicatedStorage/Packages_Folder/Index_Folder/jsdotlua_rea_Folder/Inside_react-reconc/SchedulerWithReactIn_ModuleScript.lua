-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.SchedulerWithReactIntegration.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Array__1 = require(script.Parent.Parent:WaitForChild("luau-polyfill")).Array;
require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__scheduler__2 = require(script.Parent.Parent:WaitForChild("scheduler"));
local l__decoupleUpdatePriorityFromScheduler__3 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags.decoupleUpdatePriorityFromScheduler;
local l__invariant__4 = require(script.Parent.Parent:WaitForChild("shared")).invariant;
local l__describeError__5 = require(script.Parent.Parent:WaitForChild("shared")).describeError;
local l__ReactFiberLane__6 = require(script.Parent:WaitForChild("ReactFiberLane"));
local l__SyncLanePriority__7 = l__ReactFiberLane__6.SyncLanePriority;
local l__getCurrentUpdateLanePriority__8 = l__ReactFiberLane__6.getCurrentUpdateLanePriority;
local l__setCurrentUpdateLanePriority__9 = l__ReactFiberLane__6.setCurrentUpdateLanePriority;
local l__unstable_runWithPriority__10 = l__scheduler__2.unstable_runWithPriority;
local l__unstable_scheduleCallback__11 = l__scheduler__2.unstable_scheduleCallback;
local l__unstable_cancelCallback__12 = l__scheduler__2.unstable_cancelCallback;
local l__unstable_shouldYield__13 = l__scheduler__2.unstable_shouldYield;
local l__unstable_requestPaint__14 = l__scheduler__2.unstable_requestPaint;
local l__unstable_now__15 = l__scheduler__2.unstable_now;
local l__unstable_getCurrentPriorityLevel__16 = l__scheduler__2.unstable_getCurrentPriorityLevel;
local l__unstable_ImmediatePriority__17 = l__scheduler__2.unstable_ImmediatePriority;
local l__unstable_UserBlockingPriority__18 = l__scheduler__2.unstable_UserBlockingPriority;
local l__unstable_NormalPriority__19 = l__scheduler__2.unstable_NormalPriority;
local l__unstable_LowPriority__20 = l__scheduler__2.unstable_LowPriority;
local l__unstable_IdlePriority__21 = l__scheduler__2.unstable_IdlePriority;
local v1 = require(script.Parent:WaitForChild("ReactFiberSchedulerPriorities.roblox"));
local l__ImmediatePriority__22 = v1.ImmediatePriority;
local l__UserBlockingPriority__23 = v1.UserBlockingPriority;
local l__NormalPriority__24 = v1.NormalPriority;
local l__LowPriority__25 = v1.LowPriority;
local l__IdlePriority__26 = v1.IdlePriority;
local l__NoPriority__27 = v1.NoPriority;
local u2 = nil;
local u3 = {};
local v4 = l__unstable_requestPaint__14 == nil and function() --[[ Line: 92 ]] end or l__unstable_requestPaint__14;
local u5 = nil;
local u6 = nil;
local u7 = false;
local u8 = l__unstable_now__15();
function reactPriorityToSchedulerPriority(p9)
    -- upvalues: l__ImmediatePriority__22 (copy), l__unstable_ImmediatePriority__17 (copy), l__UserBlockingPriority__23 (copy), l__unstable_UserBlockingPriority__18 (copy), l__NormalPriority__24 (copy), l__unstable_NormalPriority__19 (copy), l__LowPriority__25 (copy), l__unstable_LowPriority__20 (copy), l__IdlePriority__26 (copy), l__unstable_IdlePriority__21 (copy), l__invariant__4 (copy)
    if p9 == l__ImmediatePriority__22 then
        return l__unstable_ImmediatePriority__17;
    end;
    if p9 == l__UserBlockingPriority__23 then
        return l__unstable_UserBlockingPriority__18;
    end;
    if p9 == l__NormalPriority__24 then
        return l__unstable_NormalPriority__19;
    end;
    if p9 == l__LowPriority__25 then
        return l__unstable_LowPriority__20;
    end;
    if p9 == l__IdlePriority__26 then
        return l__unstable_IdlePriority__21;
    end;
    l__invariant__4(false, "Unknown priority level.");
    return nil;
end;
local function u12(p10, p11) --[[ Line: 158 ]]
    -- upvalues: l__unstable_runWithPriority__10 (copy)
    return l__unstable_runWithPriority__10(reactPriorityToSchedulerPriority(p10), p11);
end;
local function v14(p13) --[[ Line: 175 ]]
    -- upvalues: u5 (ref), u6 (ref), l__unstable_scheduleCallback__11 (copy), l__unstable_ImmediatePriority__17 (copy), u2 (ref), u3 (copy)
    if u5 == nil then
        u5 = { p13 };
        u6 = l__unstable_scheduleCallback__11(l__unstable_ImmediatePriority__17, u2);
    else
        table.insert(u5, p13);
    end;
    return u3;
end;
local function u16() --[[ Line: 200 ]]
    -- upvalues: u6 (ref), l__unstable_cancelCallback__12 (copy), u2 (ref)
    if u6 ~= nil then
        local v15 = u6;
        u6 = nil;
        l__unstable_cancelCallback__12(v15);
    end;
    return u2();
end;
local function _() --[[ Line: 209 ]]
    -- upvalues: u7 (ref), u5 (ref), l__decoupleUpdatePriorityFromScheduler__3 (copy), l__getCurrentUpdateLanePriority__8 (copy), l__setCurrentUpdateLanePriority__9 (copy), l__SyncLanePriority__7 (copy), u12 (copy), l__describeError__5 (copy), l__ImmediatePriority__22 (copy), l__unstable_runWithPriority__10 (copy), l__Array__1 (copy), l__unstable_scheduleCallback__11 (copy), l__unstable_ImmediatePriority__17 (copy), u16 (copy)
    if u7 or u5 == nil then
        return false;
    end;
    u7 = true;
    local u17 = 1;
    if l__decoupleUpdatePriorityFromScheduler__3 then
        local v18 = l__getCurrentUpdateLanePriority__8();
        local v19 = nil;
        local v20;
        if _G.__YOLO__ then
            v20 = true;
            local u21 = u5;
            l__setCurrentUpdateLanePriority__9(l__SyncLanePriority__7);
            l__unstable_runWithPriority__10(reactPriorityToSchedulerPriority(l__ImmediatePriority__22), function() --[[ Line: 248 ]]
                -- upvalues: u21 (copy), u17 (ref)
                for v22, v24 in u21 do
                    u17 = v22;
                    repeat
                        local v24 = v24(true);
                    until v24 == nil;
                    u17 = u17 + 1;
                end;
            end);
            u5 = nil;
        else
            local u25 = u5;
            l__setCurrentUpdateLanePriority__9(l__SyncLanePriority__7);
            v20, v19 = xpcall(u12, l__describeError__5, l__ImmediatePriority__22, function() --[[ Line: 230 ]]
                -- upvalues: u25 (copy), u17 (ref)
                for v26, v28 in u25 do
                    u17 = v26;
                    repeat
                        local v28 = v28(true);
                    until v28 == nil;
                end;
            end);
            u5 = nil;
        end;
        l__setCurrentUpdateLanePriority__9(v18);
        u7 = false;
        if not v20 then
            if u5 ~= nil then
                u5 = l__Array__1.slice(u5, u17 + 1);
            end;
            l__unstable_scheduleCallback__11(l__unstable_ImmediatePriority__17, u16);
            error(v19);
        end;
    else
        local v29 = nil;
        local v30;
        if _G.__YOLO__ then
            v30 = true;
            local u31 = u5;
            l__unstable_runWithPriority__10(reactPriorityToSchedulerPriority(l__ImmediatePriority__22), function() --[[ Line: 306 ]]
                -- upvalues: u31 (copy), u17 (ref)
                for v32, v34 in u31 do
                    u17 = v32;
                    repeat
                        local v34 = v34(true);
                    until v34 == nil;
                end;
            end);
            u5 = nil;
        else
            local u35 = u5;
            v30, v29 = xpcall(u12, l__describeError__5, l__ImmediatePriority__22, function() --[[ Line: 290 ]]
                -- upvalues: u35 (copy), u17 (ref)
                for v36, v38 in u35 do
                    u17 = v36;
                    repeat
                        local v38 = v38(true);
                    until v38 == nil;
                end;
            end);
            u5 = nil;
        end;
        u7 = false;
        if not v30 then
            if u5 ~= nil then
                u5 = l__Array__1.slice(u5, u17 + 1);
            end;
            l__unstable_scheduleCallback__11(l__unstable_ImmediatePriority__17, u16);
            error(v29);
        end;
    end;
    return true;
end;
return {
    ImmediatePriority = l__ImmediatePriority__22,
    UserBlockingPriority = l__UserBlockingPriority__23,
    NormalPriority = l__NormalPriority__24,
    LowPriority = l__LowPriority__25,
    IdlePriority = l__IdlePriority__26,
    NoPriority = l__NoPriority__27,
    getCurrentPriorityLevel = function() --[[ Name: getCurrentPriorityLevel, Line 120 ]]
        -- upvalues: l__unstable_getCurrentPriorityLevel__16 (copy), l__unstable_ImmediatePriority__17 (copy), l__ImmediatePriority__22 (copy), l__unstable_UserBlockingPriority__18 (copy), l__UserBlockingPriority__23 (copy), l__unstable_NormalPriority__19 (copy), l__NormalPriority__24 (copy), l__unstable_LowPriority__20 (copy), l__LowPriority__25 (copy), l__unstable_IdlePriority__21 (copy), l__IdlePriority__26 (copy), l__invariant__4 (copy), l__NoPriority__27 (copy)
        local v39 = l__unstable_getCurrentPriorityLevel__16();
        if v39 == l__unstable_ImmediatePriority__17 then
            return l__ImmediatePriority__22;
        end;
        if v39 == l__unstable_UserBlockingPriority__18 then
            return l__UserBlockingPriority__23;
        end;
        if v39 == l__unstable_NormalPriority__19 then
            return l__NormalPriority__24;
        end;
        if v39 == l__unstable_LowPriority__20 then
            return l__LowPriority__25;
        end;
        if v39 == l__unstable_IdlePriority__21 then
            return l__IdlePriority__26;
        end;
        l__invariant__4(false, "Unknown priority level.");
        return l__NoPriority__27;
    end,
    flushSyncCallbackQueue = u16,
    runWithPriority = u12,
    scheduleCallback = function(p40, p41, p42) --[[ Name: scheduleCallback, Line 166 ]]
        -- upvalues: l__unstable_scheduleCallback__11 (copy)
        return l__unstable_scheduleCallback__11(reactPriorityToSchedulerPriority(p40), p41, p42);
    end,
    scheduleSyncCallback = v14,
    cancelCallback = function(p43) --[[ Name: cancelCallback, Line 194 ]]
        -- upvalues: u3 (copy), l__unstable_cancelCallback__12 (copy)
        if p43 ~= u3 then
            l__unstable_cancelCallback__12(p43);
        end;
    end,
    now = function() --[[ Name: now, Line 116 ]]
        -- upvalues: l__unstable_now__15 (copy), u8 (copy)
        return l__unstable_now__15() - u8;
    end,
    requestPaint = v4,
    shouldYield = l__unstable_shouldYield__13
};