-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactCapturedValue
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__getStackByFiberInDevAndProd__1 = require(script.Parent:WaitForChild("ReactFiberComponentStack")).getStackByFiberInDevAndProd;
return {
    createCapturedValue = function(p1, p2) --[[ Line: 26 ]]
        -- upvalues: l__getStackByFiberInDevAndProd__1 (copy)
        return {
            value = p1,
            source = p2,
            stack = l__getStackByFiberInDevAndProd__1(p2)
        };
    end
};