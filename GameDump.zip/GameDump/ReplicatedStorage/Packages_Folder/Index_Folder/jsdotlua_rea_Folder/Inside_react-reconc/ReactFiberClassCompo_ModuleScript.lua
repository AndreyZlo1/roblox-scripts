-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberClassComponent.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
local l__Object__2 = require(script.Parent.Parent:WaitForChild("luau-polyfill")).Object;
local l__console__3 = require(script.Parent.Parent:WaitForChild("shared")).console;
require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__ReactFiberLane__4 = require(script.Parent:WaitForChild("ReactFiberLane"));
local v1 = require(script.Parent:WaitForChild("ReactUpdateQueue.new"));
require(script.Parent.Parent:WaitForChild("shared"));
local l__react__5 = require(script.Parent.Parent:WaitForChild("react"));
local l__ReactFiberFlags__6 = require(script.Parent:WaitForChild("ReactFiberFlags"));
local l__Update__7 = l__ReactFiberFlags__6.Update;
local l__Snapshot__8 = l__ReactFiberFlags__6.Snapshot;
local l__MountLayoutDev__9 = l__ReactFiberFlags__6.MountLayoutDev;
local l__ReactFeatureFlags__10 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags;
local l__debugRenderPhaseSideEffectsForStrictMode__11 = l__ReactFeatureFlags__10.debugRenderPhaseSideEffectsForStrictMode;
local l__disableLegacyContext__12 = l__ReactFeatureFlags__10.disableLegacyContext;
local l__enableDebugTracing__13 = l__ReactFeatureFlags__10.enableDebugTracing;
local l__enableSchedulingProfiler__14 = l__ReactFeatureFlags__10.enableSchedulingProfiler;
local l__warnAboutDeprecatedLifecycles__15 = l__ReactFeatureFlags__10.warnAboutDeprecatedLifecycles;
local l__enableDoubleInvokingEffects__16 = l__ReactFeatureFlags__10.enableDoubleInvokingEffects;
local u2 = require(script.Parent:WaitForChild("ReactStrictModeWarnings.new"));
local l__isMounted__17 = require(script.Parent:WaitForChild("ReactFiberTreeReflection")).isMounted;
local l__ReactInstanceMap__18 = require(script.Parent.Parent:WaitForChild("shared")).ReactInstanceMap;
local l__get__19 = l__ReactInstanceMap__18.get;
local l__set__20 = l__ReactInstanceMap__18.set;
local l__shallowEqual__21 = require(script.Parent.Parent:WaitForChild("shared")).shallowEqual;
local l__getComponentName__22 = require(script.Parent.Parent:WaitForChild("shared")).getComponentName;
local l__UninitializedState__23 = require(script.Parent.Parent:WaitForChild("shared")).UninitializedState;
local l__describeError__24 = require(script.Parent.Parent:WaitForChild("shared")).describeError;
local l__ReactSymbols__25 = require(script.Parent.Parent:WaitForChild("shared")).ReactSymbols;
local l__REACT_CONTEXT_TYPE__26 = l__ReactSymbols__25.REACT_CONTEXT_TYPE;
local l__REACT_PROVIDER_TYPE__27 = l__ReactSymbols__25.REACT_PROVIDER_TYPE;
local l__resolveDefaultProps__28 = require(script.Parent:WaitForChild("ReactFiberLazyComponent.new")).resolveDefaultProps;
local l__ReactTypeOfMode__29 = require(script.Parent:WaitForChild("ReactTypeOfMode"));
local l__DebugTracingMode__30 = l__ReactTypeOfMode__29.DebugTracingMode;
local l__StrictMode__31 = l__ReactTypeOfMode__29.StrictMode;
local l__enqueueUpdate__32 = v1.enqueueUpdate;
local l__processUpdateQueue__33 = v1.processUpdateQueue;
local l__checkHasForceUpdateAfterProcessing__34 = v1.checkHasForceUpdateAfterProcessing;
local l__resetHasForceUpdateBeforeProcessing__35 = v1.resetHasForceUpdateBeforeProcessing;
local l__createUpdate__36 = v1.createUpdate;
local l__ReplaceState__37 = v1.ReplaceState;
local l__ForceUpdate__38 = v1.ForceUpdate;
local l__initializeUpdateQueue__39 = v1.initializeUpdateQueue;
local l__cloneUpdateQueue__40 = v1.cloneUpdateQueue;
local l__NoLanes__41 = l__ReactFiberLane__4.NoLanes;
local v3 = require(script.Parent:WaitForChild("ReactFiberContext.new"));
local l__cacheContext__42 = v3.cacheContext;
local l__getMaskedContext__43 = v3.getMaskedContext;
local l__getUnmaskedContext__44 = v3.getUnmaskedContext;
local l__hasContextChanged__45 = v3.hasContextChanged;
local l__emptyContextObject__46 = v3.emptyContextObject;
local l__readContext__47 = require(script.Parent:WaitForChild("ReactFiberNewContext.new")).readContext;
local l__DebugTracing__48 = require(script.Parent:WaitForChild("DebugTracing"));
local l__logForceUpdateScheduled__49 = l__DebugTracing__48.logForceUpdateScheduled;
local l__logStateUpdateScheduled__50 = l__DebugTracing__48.logStateUpdateScheduled;
local l__ConsolePatchingDev__51 = require(script.Parent.Parent:WaitForChild("shared")).ConsolePatchingDev;
local l__disableLogs__52 = l__ConsolePatchingDev__51.disableLogs;
local l__reenableLogs__53 = l__ConsolePatchingDev__51.reenableLogs;
local l__SchedulingProfiler__54 = require(script.Parent:WaitForChild("SchedulingProfiler"));
local l__markForceUpdateScheduled__55 = l__SchedulingProfiler__54.markForceUpdateScheduled;
local l__markStateUpdateScheduled__56 = l__SchedulingProfiler__54.markStateUpdateScheduled;
local u4 = {};
local l____refs__57 = l__react__5.Component:extend("").__refs;
local u5, u6, u7, u8, u9, u10, u11, u12, u13;
if l____DEV____1 then
    local u14 = {};
    u5 = {};
    u6 = {};
    u7 = function(p15, p16) --[[ Name: warnOnInvalidCallback, Line 137 ]]
        -- upvalues: u14 (copy), l__console__3 (copy)
        if p15 == nil or type(p15) == "function" then
        else
            local v17 = p16 .. "_" .. tostring(p15);
            if not u14[v17] then
                u14[v17] = true;
                l__console__3.error("%s(...): Expected the last optional `callback` argument to be a function. Instead received: %s.", p16, (tostring(p15)));
            end;
        end;
    end;
    u8 = {};
    u9 = {};
    u10 = function(_, _) --[[ Name: warnOnUndefinedDerivedState, Line 153 ]] end;
    u11 = {};
    u12 = {};
    u13 = {};
else
    u5 = nil;
    u6 = nil;
    u7 = nil;
    u8 = nil;
    u9 = nil;
    u10 = nil;
    u11 = nil;
    u12 = nil;
    u13 = nil;
end;
local function u25(p18, p19, p20, p21) --[[ Line: 196 ]]
    -- upvalues: l____DEV____1 (copy), l__debugRenderPhaseSideEffectsForStrictMode__11 (copy), l__StrictMode__31 (copy), l__disableLogs__52 (copy), l__describeError__24 (copy), l__reenableLogs__53 (copy), u10 (ref), l__Object__2 (copy), l__NoLanes__41 (copy)
    local l__memoizedState__58 = p18.memoizedState;
    if l____DEV____1 and (l__debugRenderPhaseSideEffectsForStrictMode__11 and bit32.band(p18.mode, l__StrictMode__31) ~= 0) then
        l__disableLogs__52();
        local v22, v23 = xpcall(p20, l__describeError__24, p21, l__memoizedState__58);
        l__reenableLogs__53();
        if not v22 then
            error(v23);
        end;
    end;
    local v24 = p20(p21, l__memoizedState__58);
    if l____DEV____1 then
        u10(p19, v24);
    end;
    if v24 ~= nil then
        l__memoizedState__58 = l__Object__2.assign({}, l__memoizedState__58, v24);
    end;
    p18.memoizedState = l__memoizedState__58;
    if p18.lanes == l__NoLanes__41 then
        p18.updateQueue.baseState = l__memoizedState__58;
    end;
end;
local u26 = nil;
local function u48() --[[ Line: 244 ]]
    -- upvalues: u26 (ref), l__isMounted__17 (copy), l__get__19 (copy), l__createUpdate__36 (copy), l____DEV____1 (copy), u7 (ref), l__enqueueUpdate__32 (copy), l__enableDebugTracing__13 (copy), l__DebugTracingMode__30 (copy), l__getComponentName__22 (copy), l__logStateUpdateScheduled__50 (copy), l__enableSchedulingProfiler__14 (copy), l__markStateUpdateScheduled__56 (copy), l__ReplaceState__37 (copy), l__ForceUpdate__38 (copy), l__logForceUpdateScheduled__49 (copy), l__markForceUpdateScheduled__55 (copy)
    local v27 = require(script.Parent:WaitForChild("ReactFiberWorkLoop.new"));
    local l__requestEventTime__59 = v27.requestEventTime;
    local l__requestUpdateLane__60 = v27.requestUpdateLane;
    local l__scheduleUpdateOnFiber__61 = v27.scheduleUpdateOnFiber;
    u26 = {
        isMounted = l__isMounted__17,
        enqueueSetState = function(p28, p29, p30) --[[ Name: enqueueSetState, Line 252 ]]
            -- upvalues: l__get__19 (ref), l__requestEventTime__59 (copy), l__requestUpdateLane__60 (copy), l__createUpdate__36 (ref), l____DEV____1 (ref), u7 (ref), l__enqueueUpdate__32 (ref), l__scheduleUpdateOnFiber__61 (copy), l__enableDebugTracing__13 (ref), l__DebugTracingMode__30 (ref), l__getComponentName__22 (ref), l__logStateUpdateScheduled__50 (ref), l__enableSchedulingProfiler__14 (ref), l__markStateUpdateScheduled__56 (ref)
            local v31 = l__get__19(p28);
            local v32 = l__requestEventTime__59();
            local v33 = l__requestUpdateLane__60(v31);
            local v34 = l__createUpdate__36(v32, v33, p29, p30);
            if p30 ~= nil and l____DEV____1 then
                u7(p30, "setState");
            end;
            l__enqueueUpdate__32(v31, v34);
            l__scheduleUpdateOnFiber__61(v31, v33, v32);
            if l____DEV____1 and (l__enableDebugTracing__13 and bit32.band(v31.mode, l__DebugTracingMode__30) ~= 0) then
                l__logStateUpdateScheduled__50(l__getComponentName__22(v31.type) or "Unknown", v33, p29);
            end;
            if l__enableSchedulingProfiler__14 then
                l__markStateUpdateScheduled__56(v31, v33);
            end;
        end,
        enqueueReplaceState = function(p35, p36, p37) --[[ Name: enqueueReplaceState, Line 282 ]]
            -- upvalues: l__get__19 (ref), l__requestEventTime__59 (copy), l__requestUpdateLane__60 (copy), l__createUpdate__36 (ref), l__ReplaceState__37 (ref), l____DEV____1 (ref), u7 (ref), l__enqueueUpdate__32 (ref), l__scheduleUpdateOnFiber__61 (copy), l__enableDebugTracing__13 (ref), l__DebugTracingMode__30 (ref), l__getComponentName__22 (ref), l__logStateUpdateScheduled__50 (ref), l__enableSchedulingProfiler__14 (ref), l__markStateUpdateScheduled__56 (ref)
            local v38 = l__get__19(p35);
            local v39 = l__requestEventTime__59();
            local v40 = l__requestUpdateLane__60(v38);
            local v41 = l__createUpdate__36(v39, v40, p36, p37);
            v41.tag = l__ReplaceState__37;
            if p37 ~= nil and l____DEV____1 then
                u7(p37, "replaceState");
            end;
            l__enqueueUpdate__32(v38, v41);
            l__scheduleUpdateOnFiber__61(v38, v40, v39);
            if l____DEV____1 and (l__enableDebugTracing__13 and bit32.band(v38.mode, l__DebugTracingMode__30) ~= 0) then
                l__logStateUpdateScheduled__50(l__getComponentName__22(v38.type) or "Unknown", v40, p36);
            end;
            if l__enableSchedulingProfiler__14 then
                l__markStateUpdateScheduled__56(v38, v40);
            end;
        end,
        enqueueForceUpdate = function(p42, p43) --[[ Name: enqueueForceUpdate, Line 314 ]]
            -- upvalues: l__get__19 (ref), l__requestEventTime__59 (copy), l__requestUpdateLane__60 (copy), l__createUpdate__36 (ref), l__ForceUpdate__38 (ref), l____DEV____1 (ref), u7 (ref), l__enqueueUpdate__32 (ref), l__scheduleUpdateOnFiber__61 (copy), l__enableDebugTracing__13 (ref), l__DebugTracingMode__30 (ref), l__getComponentName__22 (ref), l__logForceUpdateScheduled__49 (ref), l__enableSchedulingProfiler__14 (ref), l__markForceUpdateScheduled__55 (ref)
            local v44 = l__get__19(p42);
            local v45 = l__requestEventTime__59();
            local v46 = l__requestUpdateLane__60(v44);
            local v47 = l__createUpdate__36(v45, v46, nil, p43);
            v47.tag = l__ForceUpdate__38;
            if p43 ~= nil and l____DEV____1 then
                u7(p43, "forceUpdate");
            end;
            l__enqueueUpdate__32(v44, v47);
            l__scheduleUpdateOnFiber__61(v44, v46, v45);
            if l____DEV____1 and (l__enableDebugTracing__13 and bit32.band(v44.mode, l__DebugTracingMode__30) ~= 0) then
                l__logForceUpdateScheduled__49(l__getComponentName__22(v44.type) or "Unknown", v46);
            end;
            if l__enableSchedulingProfiler__14 then
                l__markForceUpdateScheduled__55(v44, v46);
            end;
        end
    };
end;
function checkShouldComponentUpdate(p49, p50, p51, p52, p53, p54, p55)
    -- upvalues: l____DEV____1 (copy), l__debugRenderPhaseSideEffectsForStrictMode__11 (copy), l__StrictMode__31 (copy), l__disableLogs__52 (copy), l__describeError__24 (copy), l__reenableLogs__53 (copy), l__console__3 (copy), l__getComponentName__22 (copy), l__shallowEqual__21 (copy)
    local l__stateNode__62 = p49.stateNode;
    if l__stateNode__62.shouldComponentUpdate == nil or type(l__stateNode__62.shouldComponentUpdate) ~= "function" then
        return (type(p50) ~= "table" or not p50.isPureReactComponent) and true or not (l__shallowEqual__21(p51, p52) and l__shallowEqual__21(p53, p54));
    end;
    if l____DEV____1 and (l__debugRenderPhaseSideEffectsForStrictMode__11 and bit32.band(p49.mode, l__StrictMode__31) ~= 0) then
        l__disableLogs__52();
        local v56, v57 = xpcall(l__stateNode__62.shouldComponentUpdate, l__describeError__24, l__stateNode__62, p52, p54, p55);
        l__reenableLogs__53();
        if not v56 then
            error(v57);
        end;
    end;
    local v58 = l__stateNode__62:shouldComponentUpdate(p52, p54, p55);
    if l____DEV____1 and v58 == nil then
        l__console__3.error("%s.shouldComponentUpdate(): Returned nil instead of a boolean value. Make sure to return true or false.", l__getComponentName__22(p50) or "Component");
    end;
    return v58;
end;
local function u63(p59, p60, p61) --[[ Line: 420 ]]
    -- upvalues: l____DEV____1 (copy), l__getComponentName__22 (copy), l__console__3 (copy), l__disableLegacyContext__12 (copy), u6 (ref), u11 (ref)
    local l__stateNode__63 = p59.stateNode;
    if l____DEV____1 then
        local v62 = l__getComponentName__22(p60) or "Component";
        if not l__stateNode__63.render then
            if type(p60.render) == "function" then
                l__console__3.error("%s(...): No `render` method found on the returned component instance: did you accidentally return an object from the constructor?", v62);
            else
                l__console__3.error("%s(...): No `render` method found on the returned component instance: you may have forgotten to define `render`.", v62);
            end;
        end;
        if l__stateNode__63.getInitialState and not (l__stateNode__63.getInitialState.isReactClassApproved or l__stateNode__63.state) then
            l__console__3.error("getInitialState was defined on %s, a plain JavaScript class. This is only supported for classes created using React.createClass. Did you mean to define a state property instead?", v62);
        end;
        if l__stateNode__63.getDefaultProps and not l__stateNode__63.getDefaultProps.isReactClassApproved then
            l__console__3.error("getDefaultProps was defined on %s, a plain JavaScript class. This is only supported for classes created using React.createClass. Use a static property to define defaultProps instead.", v62);
        end;
        if l__stateNode__63.propTypes and not p60.propTypes then
            l__console__3.error("propTypes was defined as an instance property on %s. Use a static property to define propTypes instead.", v62);
        end;
        if l__stateNode__63.contextType and not p60.contextType then
            l__console__3.error("contextType was defined as an instance property on %s. Use a static property to define contextType instead.", v62);
        end;
        if l__disableLegacyContext__12 then
            if p60.childContextTypes then
                l__console__3.error("%s uses the legacy childContextTypes API which is no longer supported. Use React.createContext() instead.", v62);
            end;
            if p60.contextTypes then
                l__console__3.error("%s uses the legacy contextTypes API which is no longer supported. Use React.createContext() with static contextType instead.", v62);
            end;
        else
            if l__stateNode__63.contextTypes and not p60.contextTypes then
                l__console__3.error("contextTypes was defined as an instance property on %s. Use a static property to define contextTypes instead.", v62);
            end;
            if type(p60) == "table" and (p60.contextType and (p60.contextTypes and not u6[p60])) then
                u6[p60] = true;
                l__console__3.error("%s declares both contextTypes and contextType static properties. The legacy contextTypes property will be ignored.", v62);
            end;
        end;
        if type(l__stateNode__63.componentShouldUpdate) == "function" then
            l__console__3.error("%s has a method called componentShouldUpdate(). Did you mean shouldComponentUpdate()? The name is phrased as a question because the function is expected to return a value.", v62);
        end;
        if type(p60) == "table" and (p60.isPureReactComponent and l__stateNode__63.shouldComponentUpdate ~= nil) then
            l__console__3.error("%s has a method called shouldComponentUpdate(). shouldComponentUpdate should not be used when extending React.PureComponent. Please extend React.Component if shouldComponentUpdate is used.", l__getComponentName__22(p60) or "A pure component");
        end;
        if type(l__stateNode__63.componentDidUnmount) == "function" then
            l__console__3.error("%s has a method called componentDidUnmount(). But there is no such lifecycle method. Did you mean componentWillUnmount()?", v62);
        end;
        if type(l__stateNode__63.componentDidReceiveProps) == "function" then
            l__console__3.error("%s has a method called componentDidReceiveProps(). But there is no such lifecycle method. If you meant to update the state in response to changing props, use componentWillReceiveProps(). If you meant to fetch data or run side-effects or mutations after React has updated the UI, use componentDidUpdate().", v62);
        end;
        if type(l__stateNode__63.componentWillRecieveProps) == "function" then
            l__console__3.error("%s has a method called componentWillRecieveProps(). Did you mean componentWillReceiveProps()?", v62);
        end;
        if type(l__stateNode__63.UNSAFE_componentWillRecieveProps) == "function" then
            l__console__3.error("%s has a method called UNSAFE_componentWillRecieveProps(). Did you mean UNSAFE_componentWillReceiveProps()?", v62);
        end;
        if l__stateNode__63.props ~= nil and l__stateNode__63.props ~= p61 then
            l__console__3.error("%s(...): When calling super() in `%s`, make sure to pass up the same props that your component\'s constructor was passed.", v62, v62);
        end;
        if rawget(l__stateNode__63, "defaultProps") then
            l__console__3.error("Setting defaultProps as an instance property on %s is not supported and will be ignored. Instead, define defaultProps as a static property on %s.", v62, v62);
        end;
        if type(l__stateNode__63.getSnapshotBeforeUpdate) == "function" and (type(l__stateNode__63.componentDidUpdate) ~= "function" and not u11[p60]) then
            u11[p60] = true;
            l__console__3.error("%s: getSnapshotBeforeUpdate() should be used with componentDidUpdate(). This component defines getSnapshotBeforeUpdate() only.", l__getComponentName__22(p60));
        end;
        local l__state__64 = l__stateNode__63.state;
        if l__state__64 ~= nil and type(l__state__64) ~= "table" then
            l__console__3.error("%s.state: must be set to an object or nil", v62);
        end;
        if type(p60) == "table" and (type(l__stateNode__63.getChildContext) == "function" and type(p60.childContextTypes) ~= "table") then
            l__console__3.error("%s.getChildContext(): childContextTypes must be defined in order to use getChildContext().", v62);
        end;
    end;
end;
local function v66(p64, p65) --[[ Line: 654 ]]
    -- upvalues: u26 (ref), u48 (copy), l__set__20 (copy), l____DEV____1 (copy), u4 (copy)
    if u26 == nil then
        u48();
    end;
    p65.__updater = u26;
    p64.stateNode = p65;
    l__set__20(p65, p64);
    if l____DEV____1 then
        p65._reactInternalInstance = u4;
    end;
end;
local function v90(p67, p68, p69) --[[ Line: 665 ]]
    -- upvalues: l__emptyContextObject__46 (copy), l____DEV____1 (copy), l__REACT_CONTEXT_TYPE__26 (copy), u12 (ref), l__REACT_PROVIDER_TYPE__27 (copy), l__console__3 (copy), l__getComponentName__22 (copy), l__readContext__47 (copy), l__disableLegacyContext__12 (copy), l__getUnmaskedContext__44 (copy), l__getMaskedContext__43 (copy), l__debugRenderPhaseSideEffectsForStrictMode__11 (copy), l__StrictMode__31 (copy), l__disableLogs__52 (copy), l__describeError__24 (copy), l__reenableLogs__53 (copy), u26 (ref), u48 (copy), l__set__20 (copy), u4 (copy), l__UninitializedState__23 (copy), u8 (ref), u13 (ref), l__cacheContext__42 (copy)
    local v70 = false;
    local v71 = l__emptyContextObject__46;
    local v72 = l__emptyContextObject__46;
    local l__contextType__65 = p68.contextType;
    if l____DEV____1 and p68.contextType ~= nil then
        local v73;
        if l__contextType__65 == nil then
            v73 = true;
        elseif l__contextType__65["$$typeof"] == l__REACT_CONTEXT_TYPE__26 then
            v73 = l__contextType__65._context == nil;
        else
            v73 = false;
        end;
        if not (v73 or u12[p68]) then
            u12[p68] = true;
            local v74 = "";
            local v75;
            if l__contextType__65 == nil then
                v75 = " However, it is set to nil. This can be caused by a typo or by mixing up named and default imports. This can also happen due to a circular dependency, so try moving the createContext() call to a separate file.";
            elseif type(l__contextType__65) == "table" then
                if l__contextType__65["$$typeof"] == l__REACT_PROVIDER_TYPE__27 then
                    v75 = " Did you accidentally pass the Context.Provider instead?";
                elseif l__contextType__65._context == nil then
                    local v76 = v74 .. " However, it is set to an object with keys {";
                    for v77, _ in l__contextType__65 do
                        v76 = v76 .. v77 .. ", ";
                    end;
                    v75 = v76 .. "}.";
                else
                    v75 = " Did you accidentally pass the Context.Consumer instead?";
                end;
            else
                v75 = " However, it is set to a " .. type(l__contextType__65) .. ".";
            end;
            l__console__3.error("%s defines an invalid contextType. contextType should point to the Context object returned by React.createContext().%s", l__getComponentName__22(p68) or "Component", v75);
        end;
    end;
    if l__contextType__65 == nil or type(l__contextType__65) ~= "table" then
        if not l__disableLegacyContext__12 then
            v71 = l__getUnmaskedContext__44(p67, p68, true);
            v70 = p68.contextTypes ~= nil;
            v72 = v70 and l__getMaskedContext__43(p67, v71) or l__emptyContextObject__46;
        end;
    else
        v72 = l__readContext__47(l__contextType__65);
    end;
    if l____DEV____1 and (l__debugRenderPhaseSideEffectsForStrictMode__11 and bit32.band(p67.mode, l__StrictMode__31) ~= 0) then
        l__disableLogs__52();
        local v78, v79 = xpcall(p68.__ctor, l__describeError__24, p69, v72);
        l__reenableLogs__53();
        if not v78 then
            error(v79);
        end;
    end;
    local v80 = p68.__ctor(p69, v72);
    p67.memoizedState = v80.state;
    local l__memoizedState__66 = p67.memoizedState;
    if u26 == nil then
        u48();
    end;
    v80.__updater = u26;
    p67.stateNode = v80;
    l__set__20(v80, p67);
    if l____DEV____1 then
        v80._reactInternalInstance = u4;
    end;
    if l____DEV____1 then
        if type(p68.getDerivedStateFromProps) == "function" and l__memoizedState__66 == l__UninitializedState__23 then
            local v81 = l__getComponentName__22(p68) or "Component";
            if not u8[v81] then
                u8[v81] = true;
                l__console__3.error("`%s` uses `getDerivedStateFromProps` but its initial state has not been initialized. This is not recommended. Instead, define the initial state by passing an object to `self:setState` in the `init` method of `%s`. This ensures that `getDerivedStateFromProps` arguments have a consistent shape.", v81, v81);
            end;
        end;
        if type(p68.getDerivedStateFromProps) == "function" or type(v80.getSnapshotBeforeUpdate) == "function" then
            local v82 = type(v80.componentWillMount) == "function" and "componentWillMount" or (type(v80.UNSAFE_componentWillMount) == "function" and "UNSAFE_componentWillMount" or nil);
            local v83 = type(v80.componentWillReceiveProps) == "function" and "componentWillReceiveProps" or (type(v80.UNSAFE_componentWillReceiveProps) == "function" and "UNSAFE_componentWillReceiveProps" or nil);
            local v84 = type(v80.componentWillUpdate) == "function" and "componentWillUpdate" or (type(v80.UNSAFE_componentWillUpdate) == "function" and "UNSAFE_componentWillUpdate" or nil);
            if v82 ~= nil or (v83 ~= nil or v84 ~= nil) then
                local v85 = l__getComponentName__22(p68) or "Component";
                local v86 = type(p68.getDerivedStateFromProps) == "function" and "getDerivedStateFromProps()" or "getSnapshotBeforeUpdate()";
                local v87 = v82 == nil and "" or "\n  " .. tostring(v82);
                local v88 = v83 == nil and "" or "\n  " .. tostring(v83);
                local v89 = v84 == nil and "" or "\n  " .. tostring(v84);
                if not u13[v85] then
                    u13[v85] = true;
                    l__console__3.error("Unsafe legacy lifecycles will not be called for components using new component APIs.\n\n%s uses %s but also contains the following legacy lifecycles:%s%s%s\n\nThe above lifecycles should be removed. Learn more about this warning here:\nhttps://reactjs.org/link/unsafe-component-lifecycles", v85, v86, v87, v88, v89);
                end;
            end;
        end;
    end;
    if v70 then
        l__cacheContext__42(p67, v71, v72);
    end;
    return v80;
end;
local function u93(p91, p92) --[[ Line: 880 ]]
    -- upvalues: l____DEV____1 (copy), l__console__3 (copy), l__getComponentName__22 (copy), u26 (ref), u48 (copy)
    local l__state__67 = p92.state;
    if p92.componentWillMount ~= nil and type(p92.componentWillMount) == "function" then
        p92:componentWillMount();
    end;
    if p92.UNSAFE_componentWillMount ~= nil and type(p92.UNSAFE_componentWillMount) == "function" then
        p92:UNSAFE_componentWillMount();
    end;
    if l__state__67 ~= p92.state then
        if l____DEV____1 then
            l__console__3.error("%s.componentWillMount(): Assigning directly to this.state is deprecated (except inside a component\'s constructor). Use setState instead.", l__getComponentName__22(p91.type) or "Component");
        end;
        if u26 == nil then
            u48();
        end;
        u26.enqueueReplaceState(p92, p92.state);
    end;
end;
function callComponentWillReceiveProps(p94, p95, p96, p97)
    -- upvalues: l____DEV____1 (copy), l__getComponentName__22 (copy), u9 (ref), l__console__3 (copy), u26 (ref), u48 (copy)
    local l__state__68 = p95.state;
    if p95.componentWillReceiveProps ~= nil and type(p95.componentWillReceiveProps) == "function" then
        p95:componentWillReceiveProps(p96, p97);
    end;
    if p95.UNSAFE_componentWillReceiveProps ~= nil and type(p95.UNSAFE_componentWillReceiveProps) == "function" then
        p95:UNSAFE_componentWillReceiveProps(p96, p97);
    end;
    if p95.state ~= l__state__68 then
        if l____DEV____1 then
            local v98 = l__getComponentName__22(p94.type) or "Component";
            if not u9[v98] then
                u9[v98] = true;
                l__console__3.error("%s.componentWillReceiveProps(): Assigning directly to this.state is deprecated (except inside a component\'s constructor). Use setState instead.", v98);
            end;
        end;
        if u26 == nil then
            u48();
        end;
        u26.enqueueReplaceState(p95, p95.state);
    end;
end;
local function v108(p99, p100, p101, p102) --[[ Line: 945 ]]
    -- upvalues: l____DEV____1 (copy), u63 (copy), l____refs__57 (copy), l__initializeUpdateQueue__39 (copy), l__readContext__47 (copy), l__disableLegacyContext__12 (copy), l__emptyContextObject__46 (copy), l__getUnmaskedContext__44 (copy), l__getMaskedContext__43 (copy), l__getComponentName__22 (copy), u5 (ref), l__console__3 (copy), l__StrictMode__31 (copy), u2 (copy), l__warnAboutDeprecatedLifecycles__15 (copy), l__processUpdateQueue__33 (copy), u25 (copy), u93 (copy), l__enableDoubleInvokingEffects__16 (copy), l__MountLayoutDev__9 (copy), l__Update__7 (copy)
    if l____DEV____1 then
        u63(p99, p100, p101);
    end;
    local l__stateNode__69 = p99.stateNode;
    l__stateNode__69.props = p101;
    l__stateNode__69.state = p99.memoizedState;
    l__stateNode__69.__refs = l____refs__57;
    l__initializeUpdateQueue__39(p99);
    local v103;
    if type(p100) == "table" then
        v103 = p100.contextType;
    else
        v103 = nil;
    end;
    if v103 == nil or type(v103) ~= "table" then
        if l__disableLegacyContext__12 then
            l__stateNode__69.context = l__emptyContextObject__46;
        else
            l__stateNode__69.context = l__getMaskedContext__43(p99, (l__getUnmaskedContext__44(p99, p100, true)));
        end;
    else
        l__stateNode__69.context = l__readContext__47(v103);
    end;
    if l____DEV____1 then
        if l__stateNode__69.state == p101 then
            local v104 = l__getComponentName__22(p100) or "Component";
            if not u5[v104] then
                u5[v104] = true;
                l__console__3.error("%s: It is not recommended to assign props directly to state because updates to props won\'t be reflected in state. In most cases, it is better to use props directly.", v104);
            end;
        end;
        if bit32.band(p99.mode, l__StrictMode__31) ~= 0 then
            u2.recordLegacyContextWarning(p99, l__stateNode__69);
        end;
        if l__warnAboutDeprecatedLifecycles__15 then
            u2.recordUnsafeLifecycleWarnings(p99, l__stateNode__69);
        end;
    end;
    l__processUpdateQueue__33(p99, p101, l__stateNode__69, p102);
    l__stateNode__69.state = p99.memoizedState;
    local v105 = type(p100);
    local v106;
    if type(p100) == "table" then
        v106 = p100.getDerivedStateFromProps;
    else
        v106 = nil;
    end;
    if v106 ~= nil and type(v106) == "function" then
        u25(p99, p100, v106, p101);
        l__stateNode__69.state = p99.memoizedState;
    end;
    if v105 == "table" and (type(p100.getDerivedStateFromProps) ~= "function" and (type(l__stateNode__69.getSnapshotBeforeUpdate) ~= "function" and (type(l__stateNode__69.UNSAFE_componentWillMount) == "function" or type(l__stateNode__69.componentWillMount) == "function"))) then
        u93(p99, l__stateNode__69);
        l__processUpdateQueue__33(p99, p101, l__stateNode__69, p102);
        l__stateNode__69.state = p99.memoizedState;
    end;
    if type(l__stateNode__69.componentDidMount) == "function" then
        if l____DEV____1 and l__enableDoubleInvokingEffects__16 then
            local l__flags__70 = p99.flags;
            local v107 = bit32.bor(l__MountLayoutDev__9, l__Update__7);
            p99.flags = bit32.bor(l__flags__70, v107);
            return;
        end;
        p99.flags = bit32.bor(p99.flags, l__Update__7);
    end;
end;
function resumeMountClassInstance(p109, p110, p111, p112)
    -- upvalues: l__emptyContextObject__46 (copy), l__readContext__47 (copy), l__disableLegacyContext__12 (copy), l__getUnmaskedContext__44 (copy), l__getMaskedContext__43 (copy), l__resetHasForceUpdateBeforeProcessing__35 (copy), l__processUpdateQueue__33 (copy), l__hasContextChanged__45 (copy), l__checkHasForceUpdateAfterProcessing__34 (copy), l____DEV____1 (copy), l__enableDoubleInvokingEffects__16 (copy), l__MountLayoutDev__9 (copy), l__Update__7 (copy), u25 (copy)
    local l__stateNode__71 = p109.stateNode;
    local l__memoizedProps__72 = p109.memoizedProps;
    l__stateNode__71.props = l__memoizedProps__72;
    local l__context__73 = l__stateNode__71.context;
    local l__contextType__74 = p110.contextType;
    local v113 = l__emptyContextObject__46;
    if l__contextType__74 == nil or type(l__contextType__74) ~= "table" then
        if not l__disableLegacyContext__12 then
            v113 = l__getMaskedContext__43(p109, (l__getUnmaskedContext__44(p109, p110, true)));
        end;
    else
        v113 = l__readContext__47(l__contextType__74);
    end;
    local l__getDerivedStateFromProps__75 = p110.getDerivedStateFromProps;
    local v114 = type(l__getDerivedStateFromProps__75) == "function" and true or type(l__stateNode__71.getSnapshotBeforeUpdate) == "function";
    if not v114 and (type(l__stateNode__71.UNSAFE_componentWillReceiveProps) == "function" or type(l__stateNode__71.componentWillReceiveProps) == "function") and (l__memoizedProps__72 ~= p111 or l__context__73 ~= v113) then
        callComponentWillReceiveProps(p109, l__stateNode__71, p111, v113);
    end;
    l__resetHasForceUpdateBeforeProcessing__35();
    local l__memoizedState__76 = p109.memoizedState;
    l__stateNode__71.state = l__memoizedState__76;
    l__processUpdateQueue__33(p109, p111, l__stateNode__71, p112);
    local l__memoizedState__77 = p109.memoizedState;
    if l__memoizedProps__72 == p111 and (l__memoizedState__76 == l__memoizedState__77 and not (l__hasContextChanged__45() or l__checkHasForceUpdateAfterProcessing__34())) then
        if type(l__stateNode__71.componentDidMount) == "function" then
            if l____DEV____1 and l__enableDoubleInvokingEffects__16 then
                p109.flags = bit32.bor(p109.flags, l__MountLayoutDev__9, l__Update__7);
            else
                p109.flags = bit32.bor(p109.flags, l__Update__7);
            end;
        end;
        return false;
    end;
    if l__getDerivedStateFromProps__75 ~= nil and type(l__getDerivedStateFromProps__75) == "function" then
        u25(p109, p110, l__getDerivedStateFromProps__75, p111);
        l__memoizedState__77 = p109.memoizedState;
    end;
    local v115 = l__checkHasForceUpdateAfterProcessing__34() or checkShouldComponentUpdate(p109, p110, l__memoizedProps__72, p111, l__memoizedState__76, l__memoizedState__77, v113);
    if v115 then
        if not v114 and (type(l__stateNode__71.UNSAFE_componentWillMount) == "function" or type(l__stateNode__71.componentWillMount) == "function") then
            if type(l__stateNode__71.componentWillMount) == "function" then
                l__stateNode__71:componentWillMount();
            end;
            if type(l__stateNode__71.UNSAFE_componentWillMount) == "function" then
                l__stateNode__71:UNSAFE_componentWillMount();
            end;
        end;
        if type(l__stateNode__71.componentDidMount) == "function" then
            if l____DEV____1 and l__enableDoubleInvokingEffects__16 then
                p109.flags = bit32.bor(p109.flags, l__MountLayoutDev__9, l__Update__7);
            else
                p109.flags = bit32.bor(p109.flags, l__Update__7);
            end;
        end;
    else
        if type(l__stateNode__71.componentDidMount) == "function" then
            if l____DEV____1 and l__enableDoubleInvokingEffects__16 then
                p109.flags = bit32.bor(p109.flags, l__MountLayoutDev__9, l__Update__7);
            else
                p109.flags = bit32.bor(p109.flags, l__Update__7);
            end;
        end;
        p109.memoizedProps = p111;
        p109.memoizedState = l__memoizedState__77;
    end;
    l__stateNode__71.props = p111;
    l__stateNode__71.state = l__memoizedState__77;
    l__stateNode__71.context = v113;
    return v115;
end;
return {
    adoptClassInstance = v66,
    constructClassInstance = v90,
    mountClassInstance = v108,
    resumeMountClassInstance = resumeMountClassInstance,
    updateClassInstance = function(p116, p117, p118, p119, p120) --[[ Name: updateClassInstance, Line 1204 ]]
        -- upvalues: l__cloneUpdateQueue__40 (copy), l__resolveDefaultProps__28 (copy), l__emptyContextObject__46 (copy), l__readContext__47 (copy), l__disableLegacyContext__12 (copy), l__getUnmaskedContext__44 (copy), l__getMaskedContext__43 (copy), l__resetHasForceUpdateBeforeProcessing__35 (copy), l__processUpdateQueue__33 (copy), l__hasContextChanged__45 (copy), l__checkHasForceUpdateAfterProcessing__34 (copy), l__Update__7 (copy), l__Snapshot__8 (copy), u25 (copy)
        local l__stateNode__78 = p117.stateNode;
        l__cloneUpdateQueue__40(p116, p117);
        local l__memoizedProps__79 = p117.memoizedProps;
        local v121;
        if p117.type == p117.elementType then
            v121 = l__memoizedProps__79;
        else
            v121 = l__resolveDefaultProps__28(p117.type, l__memoizedProps__79);
        end;
        l__stateNode__78.props = v121;
        local l__pendingProps__80 = p117.pendingProps;
        local l__context__81 = l__stateNode__78.context;
        local v122, v123;
        if type(p118) == "table" then
            v122 = p118.contextType;
            v123 = p118.getDerivedStateFromProps;
        else
            v122 = nil;
            v123 = nil;
        end;
        local v124 = l__emptyContextObject__46;
        if type(v122) == "table" then
            v124 = l__readContext__47(v122);
        elseif not l__disableLegacyContext__12 then
            v124 = l__getMaskedContext__43(p117, (l__getUnmaskedContext__44(p117, p118, true)));
        end;
        local v125;
        if v123 == nil or type(v123) ~= "function" then
            if l__stateNode__78.getSnapshotBeforeUpdate == nil then
                v125 = false;
            else
                v125 = type(l__stateNode__78.getSnapshotBeforeUpdate) == "function";
            end;
        else
            v125 = true;
        end;
        if not v125 and (l__stateNode__78.UNSAFE_componentWillReceiveProps ~= nil and type(l__stateNode__78.UNSAFE_componentWillReceiveProps) == "function" or l__stateNode__78.componentWillReceiveProps ~= nil and type(l__stateNode__78.componentWillReceiveProps) == "function") and (l__memoizedProps__79 ~= l__pendingProps__80 or l__context__81 ~= v124) then
            callComponentWillReceiveProps(p117, l__stateNode__78, p119, v124);
        end;
        l__resetHasForceUpdateBeforeProcessing__35();
        local l__memoizedState__82 = p117.memoizedState;
        l__stateNode__78.state = l__memoizedState__82;
        local _ = l__stateNode__78.state;
        l__processUpdateQueue__33(p117, p119, l__stateNode__78, p120);
        local l__memoizedState__83 = p117.memoizedState;
        if l__memoizedProps__79 == l__pendingProps__80 and (l__memoizedState__82 == l__memoizedState__83 and not (l__hasContextChanged__45() or l__checkHasForceUpdateAfterProcessing__34())) then
            if l__stateNode__78.componentDidUpdate ~= nil and (type(l__stateNode__78.componentDidUpdate) == "function" and (l__memoizedProps__79 ~= p116.memoizedProps or l__memoizedState__82 ~= p116.memoizedState)) then
                p117.flags = bit32.bor(p117.flags, l__Update__7);
            end;
            if l__stateNode__78.getSnapshotBeforeUpdate ~= nil and (type(l__stateNode__78.getSnapshotBeforeUpdate) == "function" and (l__memoizedProps__79 ~= p116.memoizedProps or l__memoizedState__82 ~= p116.memoizedState)) then
                p117.flags = bit32.bor(p117.flags, l__Snapshot__8);
            end;
            return false;
        end;
        if v123 ~= nil and type(v123) == "function" then
            u25(p117, p118, v123, p119);
            l__memoizedState__83 = p117.memoizedState;
        end;
        local v126 = l__checkHasForceUpdateAfterProcessing__34() or checkShouldComponentUpdate(p117, p118, v121, p119, l__memoizedState__82, l__memoizedState__83, v124);
        if v126 then
            if not v125 and (l__stateNode__78.UNSAFE_componentWillUpdate ~= nil and type(l__stateNode__78.UNSAFE_componentWillUpdate) == "function" or l__stateNode__78.componentWillUpdate ~= nil and type(l__stateNode__78.componentWillUpdate) == "function") then
                if l__stateNode__78.componentWillUpdate ~= nil and type(l__stateNode__78.componentWillUpdate) == "function" then
                    l__stateNode__78:componentWillUpdate(p119, l__memoizedState__83, v124);
                end;
                if l__stateNode__78.UNSAFE_componentWillUpdate ~= nil and type(l__stateNode__78.UNSAFE_componentWillUpdate) == "function" then
                    l__stateNode__78:UNSAFE_componentWillUpdate(p119, l__memoizedState__83, v124);
                end;
            end;
            if l__stateNode__78.componentDidUpdate ~= nil and type(l__stateNode__78.componentDidUpdate) == "function" then
                p117.flags = bit32.bor(p117.flags, l__Update__7);
            end;
            if l__stateNode__78.getSnapshotBeforeUpdate ~= nil and type(l__stateNode__78.getSnapshotBeforeUpdate) == "function" then
                p117.flags = bit32.bor(p117.flags, l__Snapshot__8);
            end;
        else
            if l__stateNode__78.componentDidUpdate ~= nil and (type(l__stateNode__78.componentDidUpdate) == "function" and (l__memoizedProps__79 ~= p116.memoizedProps or l__memoizedState__82 ~= p116.memoizedState)) then
                p117.flags = bit32.bor(p117.flags, l__Update__7);
            end;
            if l__stateNode__78.getSnapshotBeforeUpdate ~= nil and (type(l__stateNode__78.getSnapshotBeforeUpdate) == "function" and (l__memoizedProps__79 ~= p116.memoizedProps or l__memoizedState__82 ~= p116.memoizedState)) then
                p117.flags = bit32.bor(p117.flags, l__Snapshot__8);
            end;
            p117.memoizedProps = p119;
            p117.memoizedState = l__memoizedState__83;
        end;
        l__stateNode__78.props = p119;
        l__stateNode__78.state = l__memoizedState__83;
        l__stateNode__78.context = v124;
        return v126;
    end,
    applyDerivedStateFromProps = u25,
    emptyRefsObject = l____refs__57
};