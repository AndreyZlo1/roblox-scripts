-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberTransition
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReactCurrentBatchConfig__1 = require(script.Parent.Parent:WaitForChild("shared")).ReactSharedInternals.ReactCurrentBatchConfig;
return {
    NoTransition = 0,
    requestCurrentTransition = function() --[[ Name: requestCurrentTransition, Line 18 ]]
        -- upvalues: l__ReactCurrentBatchConfig__1 (copy)
        return l__ReactCurrentBatchConfig__1.transition;
    end
};