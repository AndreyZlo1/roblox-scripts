-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberLane
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__console__1 = require(script.Parent.Parent:WaitForChild("shared")).console;
local v1 = require(script.Parent:WaitForChild("ReactFiberSchedulerPriorities.roblox"));
local l__invariant__2 = require(script.Parent.Parent:WaitForChild("shared")).invariant;
local l__ImmediatePriority__3 = v1.ImmediatePriority;
local l__UserBlockingPriority__4 = v1.UserBlockingPriority;
local l__NormalPriority__5 = v1.NormalPriority;
local l__LowPriority__6 = v1.LowPriority;
local l__IdlePriority__7 = v1.IdlePriority;
local l__NoPriority__8 = v1.NoPriority;
local v2 = {
    SyncLanePriority = 15,
    SyncBatchedLanePriority = 14,
    InputDiscreteLanePriority = 12,
    InputContinuousLanePriority = 10,
    DefaultLanePriority = 8,
    TransitionPriority = 6,
    NoLanePriority = 0,
    NoLanes = 0,
    NoLane = 0,
    SyncLane = 1,
    SyncBatchedLane = 2,
    InputDiscreteHydrationLane = 4,
    DefaultHydrationLane = 256,
    DefaultLanes = 3584,
    RetryLanes = 62914560,
    SomeRetryLane = 33554432,
    SelectiveHydrationLane = 67108864,
    IdleHydrationLane = 134217728,
    OffscreenLane = 1073741824,
    NoTimestamp = -1
};
local l__NoLanePriority__9 = v2.NoLanePriority;
function v2.getCurrentUpdateLanePriority() --[[ Line: 141 ]]
    -- upvalues: l__NoLanePriority__9 (ref)
    return l__NoLanePriority__9;
end;
function v2.setCurrentUpdateLanePriority(p3) --[[ Line: 145 ]]
    -- upvalues: l__NoLanePriority__9 (ref)
    l__NoLanePriority__9 = p3;
end;
local l__DefaultLanePriority__10 = v2.DefaultLanePriority;
local function u11(p4) --[[ Line: 153 ]]
    -- upvalues: l__DefaultLanePriority__10 (ref), l__console__1 (copy)
    if bit32.band(1, p4) ~= 0 then
        l__DefaultLanePriority__10 = 15;
        return 1;
    end;
    if bit32.band(2, p4) ~= 0 then
        l__DefaultLanePriority__10 = 14;
        return 2;
    end;
    if bit32.band(4, p4) ~= 0 then
        l__DefaultLanePriority__10 = 13;
        return 4;
    end;
    local v5 = bit32.band(24, p4);
    if v5 ~= 0 then
        l__DefaultLanePriority__10 = 12;
        return v5;
    end;
    if bit32.band(p4, 32) ~= 0 then
        l__DefaultLanePriority__10 = 11;
        return 32;
    end;
    local v6 = bit32.band(192, p4);
    if v6 ~= 0 then
        l__DefaultLanePriority__10 = 10;
        return v6;
    end;
    if bit32.band(p4, 256) ~= 0 then
        l__DefaultLanePriority__10 = 9;
        return 256;
    end;
    local v7 = bit32.band(3584, p4);
    if v7 ~= 0 then
        l__DefaultLanePriority__10 = 8;
        return v7;
    end;
    if bit32.band(p4, 4096) ~= 0 then
        l__DefaultLanePriority__10 = 7;
        return 4096;
    end;
    local v8 = bit32.band(4186112, p4);
    if v8 ~= 0 then
        l__DefaultLanePriority__10 = 6;
        return v8;
    end;
    local v9 = bit32.band(62914560, p4);
    if v9 ~= 0 then
        l__DefaultLanePriority__10 = 5;
        return v9;
    end;
    if bit32.band(p4, 67108864) ~= 0 then
        l__DefaultLanePriority__10 = 4;
        return 67108864;
    end;
    if bit32.band(p4, 134217728) ~= 0 then
        l__DefaultLanePriority__10 = 3;
        return 134217728;
    end;
    local v10 = bit32.band(805306368, p4);
    if v10 ~= 0 then
        l__DefaultLanePriority__10 = 2;
        return v10;
    end;
    if bit32.band(1073741824, p4) ~= 0 then
        l__DefaultLanePriority__10 = 1;
        return 1073741824;
    end;
    if _G.__DEV__ then
        l__console__1.error("Should have found matching lanes. This is a bug in React.");
    end;
    l__DefaultLanePriority__10 = 8;
    return p4;
end;
function v2.schedulerPriorityToLanePriority(p12) --[[ Line: 228 ]]
    -- upvalues: l__ImmediatePriority__3 (copy), l__UserBlockingPriority__4 (copy), l__NormalPriority__5 (copy), l__LowPriority__6 (copy), l__IdlePriority__7 (copy)
    return p12 == l__ImmediatePriority__3 and 15 or (p12 == l__UserBlockingPriority__4 and 10 or ((p12 == l__NormalPriority__5 or p12 == l__LowPriority__6) and 8 or (p12 == l__IdlePriority__7 and 2 or 0)));
end;
function v2.lanePriorityToSchedulerPriority(p13) --[[ Line: 249 ]]
    -- upvalues: l__ImmediatePriority__3 (copy), l__UserBlockingPriority__4 (copy), l__NormalPriority__5 (copy), l__IdlePriority__7 (copy), l__NoPriority__8 (copy), l__invariant__2 (copy)
    if p13 == 15 or p13 == 14 then
        return l__ImmediatePriority__3;
    end;
    if p13 == 13 or (p13 == 12 or (p13 == 11 or p13 == 10)) then
        return l__UserBlockingPriority__4;
    end;
    if p13 == 9 or (p13 == 8 or (p13 == 7 or (p13 == 6 or (p13 == 4 or p13 == 5)))) then
        return l__NormalPriority__5;
    end;
    if p13 == 3 or (p13 == 2 or p13 == 1) then
        return l__IdlePriority__7;
    end;
    if p13 == 0 then
        return l__NoPriority__8;
    end;
    l__invariant__2(false, "Invalid update priority: %s. This is a bug in React.", p13);
    error("unreachable");
end;
local u14 = nil;
local u15 = nil;
function v2.getNextLanes(p16, p17) --[[ Line: 293 ]]
    -- upvalues: l__DefaultLanePriority__10 (ref), u11 (copy), u15 (ref), u14 (ref)
    local l__pendingLanes__11 = p16.pendingLanes;
    if l__pendingLanes__11 == 0 then
        l__DefaultLanePriority__10 = 0;
        return 0;
    end;
    local v18 = 0;
    local v19 = 0;
    local l__expiredLanes__12 = p16.expiredLanes;
    local l__suspendedLanes__13 = p16.suspendedLanes;
    local l__pingedLanes__14 = p16.pingedLanes;
    if l__expiredLanes__12 == 0 then
        local v20 = bit32.band(l__pendingLanes__11, 134217727);
        if v20 == 0 then
            local v21 = bit32.bnot(l__suspendedLanes__13);
            local v22 = bit32.band(l__pendingLanes__11, v21);
            if v22 == 0 then
                if l__pingedLanes__14 ~= 0 then
                    v18 = u11(l__pingedLanes__14);
                    v19 = l__DefaultLanePriority__10;
                end;
            else
                v18 = u11(v22);
                v19 = l__DefaultLanePriority__10;
            end;
        else
            local v23 = bit32.bnot(l__suspendedLanes__13);
            local v24 = bit32.band(v20, v23);
            if v24 == 0 then
                local v25 = bit32.band(v20, l__pingedLanes__14);
                if v25 ~= 0 then
                    v18 = u11(v25);
                    v19 = l__DefaultLanePriority__10;
                end;
            else
                v18 = u11(v24);
                v19 = l__DefaultLanePriority__10;
            end;
        end;
    else
        l__DefaultLanePriority__10 = 15;
        v18 = l__expiredLanes__12;
        v19 = 15;
    end;
    if v18 == 0 then
        return 0;
    end;
    local v26 = u15(v18);
    local v27 = bit32.lshift(v26, 1) - 1;
    local v28 = bit32.band(l__pendingLanes__11, v27);
    if p17 ~= 0 and (p17 ~= v28 and bit32.band(p17, l__suspendedLanes__13) == 0) then
        u11(p17);
        if v19 <= l__DefaultLanePriority__10 then
            return p17;
        end;
        l__DefaultLanePriority__10 = v19;
    end;
    local l__entangledLanes__15 = p16.entangledLanes;
    if l__entangledLanes__15 ~= 0 then
        local l__entanglements__16 = p16.entanglements;
        local v29 = bit32.band(v28, l__entangledLanes__15);
        while v29 > 0 do
            local v30 = u14(v29);
            local v31 = bit32.lshift(1, v30);
            v28 = bit32.bor(v28, l__entanglements__16[v30]);
            local v32 = bit32.bnot(v31);
            v29 = bit32.band(v29, v32);
        end;
    end;
    return v28;
end;
function v2.getMostRecentEventTime(p33, p34) --[[ Line: 412 ]]
    -- upvalues: u14 (ref)
    local l__eventTimes__17 = p33.eventTimes;
    local v35 = -1;
    while p34 > 0 do
        local v36 = u14(p34);
        local v37 = bit32.lshift(1, v36);
        local v38 = l__eventTimes__17[v36];
        if v35 >= v38 then
            v38 = v35;
        end;
        local v39 = bit32.bnot(v37);
        p34 = bit32.band(p34, v39);
        v35 = v38;
    end;
    return v35;
end;
function v2.computeExpirationTime(p40, p41) --[[ Line: 432 ]]
    -- upvalues: u11 (copy), l__DefaultLanePriority__10 (ref)
    u11(p40);
    local v42 = l__DefaultLanePriority__10;
    if v42 >= 10 then
        return p41 + 250;
    else
        return v42 < 6 and -1 or p41 + 5000;
    end;
end;
function v2.markStarvedLanesAsExpired(p43, p44) --[[ Line: 462 ]]
    -- upvalues: u14 (ref), u11 (copy), l__DefaultLanePriority__10 (ref)
    local l__pendingLanes__18 = p43.pendingLanes;
    local l__suspendedLanes__19 = p43.suspendedLanes;
    local l__pingedLanes__20 = p43.pingedLanes;
    local l__expirationTimes__21 = p43.expirationTimes;
    while l__pendingLanes__18 > 0 do
        local v45 = u14(l__pendingLanes__18);
        local v46 = bit32.lshift(1, v45);
        local v47 = l__expirationTimes__21[v45];
        if v47 == -1 then
            if bit32.band(v46, l__suspendedLanes__19) == 0 or bit32.band(v46, l__pingedLanes__20) ~= 0 then
                u11(v46);
                local v48 = l__DefaultLanePriority__10;
                local v49;
                if v48 >= 10 then
                    v49 = p44 + 250;
                else
                    v49 = v48 < 6 and -1 or p44 + 5000;
                end;
                l__expirationTimes__21[v45] = v49;
            end;
        elseif v47 <= p44 then
            p43.expiredLanes = bit32.bor(p43.expiredLanes, v46);
        end;
        local v50 = bit32.bnot(v46);
        l__pendingLanes__18 = bit32.band(l__pendingLanes__18, v50);
    end;
end;
function v2.getHighestPriorityPendingLanes(p51) --[[ Line: 504 ]]
    -- upvalues: u11 (copy)
    return u11(p51.pendingLanes);
end;
function v2.getLanesToRetrySynchronouslyOnError(p52) --[[ Line: 509 ]]
    local v53 = bit32.band(p52.pendingLanes, 3221225471);
    return v53 == 0 and (bit32.band(v53, 1073741824) == 0 and 0 or 1073741824) or v53;
end;
function v2.returnNextLanesPriority() --[[ Line: 522 ]]
    -- upvalues: l__DefaultLanePriority__10 (ref)
    return l__DefaultLanePriority__10;
end;
function v2.includesNonIdleWork(p54) --[[ Line: 527 ]]
    return bit32.band(p54, 134217727) ~= 0;
end;
function v2.includesOnlyRetries(p55) --[[ Line: 532 ]]
    return bit32.band(p55, 62914560) == p55;
end;
function v2.includesOnlyTransitions(p56) --[[ Line: 537 ]]
    return bit32.band(p56, 4186112) == p56;
end;
local u57 = nil;
local function u74(p58, p59) --[[ Line: 547 ]]
    -- upvalues: u57 (ref), u74 (copy), l__invariant__2 (copy)
    if p58 ~= 0 then
        if p58 == 15 then
            return 1;
        end;
        if p58 == 14 then
            return 2;
        end;
        if p58 == 12 then
            local v60 = u57;
            local v61 = bit32.bnot(p59);
            local v62 = v60((bit32.band(24, v61)));
            if v62 == 0 then
                return u74(10, p59);
            else
                return v62;
            end;
        end;
        if p58 == 10 then
            local v63 = u57;
            local v64 = bit32.bnot(p59);
            local v65 = v63((bit32.band(192, v64)));
            if v65 == 0 then
                return u74(8, p59);
            else
                return v65;
            end;
        end;
        if p58 == 8 then
            local v66 = u57;
            local v67 = bit32.bnot(p59);
            local v68 = v66((bit32.band(3584, v67)));
            if v68 == 0 then
                local v69 = u57;
                local v70 = bit32.bnot(p59);
                v68 = v69((bit32.band(4186112, v70)));
                if v68 == 0 then
                    v68 = u57(3584);
                end;
            end;
            return v68;
        end;
        if p58 ~= 6 and (p58 ~= 5 and p58 == 2) then
            local v71 = u57;
            local v72 = bit32.bnot(p59);
            local v73 = v71((bit32.band(805306368, v72)));
            if v73 == 0 then
                v73 = u57(805306368);
            end;
            return v73;
        end;
    end;
    l__invariant__2(false, "Invalid update priority: %s. This is a bug in React.", p58);
    error("unreachable");
end;
v2.findUpdateLane = u74;
function v2.findTransitionLane(p75, p76) --[[ Line: 606 ]]
    -- upvalues: u57 (ref)
    local v77 = u57;
    local v78 = bit32.bnot(p76);
    local v79 = v77((bit32.band(4186112, v78)));
    if v79 == 0 then
        local v80 = u57;
        local v81 = bit32.bnot(p75);
        v79 = v80((bit32.band(4186112, v81)));
        if v79 == 0 then
            v79 = u57(4186112);
        end;
    end;
    return v79;
end;
function v2.findRetryLane(p82) --[[ Line: 626 ]]
    -- upvalues: u57 (ref)
    local v83 = u57;
    local v84 = bit32.bnot(p82);
    local v85 = v83((bit32.band(62914560, v84)));
    if v85 == 0 then
        v85 = u57(62914560);
    end;
    return v85;
end;
u15 = function(p86) --[[ Name: getLowestPriorityLane, Line 642 ]]
    local v87 = 31 - bit32.countlz(p86);
    return v87 < 0 and 0 or bit32.lshift(1, v87);
end;
u57 = function(p88) --[[ Name: pickArbitraryLane, Line 656 ]]
    return bit32.band(p88, -p88);
end;
v2.pickArbitraryLane = u57;
u14 = function(p89) --[[ Name: pickArbitraryLaneIndex, Line 665 ]]
    return 31 - bit32.countlz(p89);
end;
function v2.includesSomeLane(p90, p91) --[[ Line: 674 ]]
    return bit32.band(p90, p91) ~= 0;
end;
function v2.isSubsetOfLanes(p92, p93) --[[ Line: 679 ]]
    return bit32.band(p92, p93) == p93;
end;
function v2.mergeLanes(p94, p95) --[[ Line: 684 ]]
    return bit32.bor(p94, p95);
end;
function v2.removeLanes(p96, p97) --[[ Line: 689 ]]
    local v98 = bit32.bnot(p97);
    return bit32.band(p96, v98);
end;
function v2.laneToLanes(p99) --[[ Line: 696 ]]
    return p99;
end;
function v2.higherPriorityLane(p100, p101) --[[ Line: 701 ]]
    if p100 == 0 or p101 == 0 then
        if p100 == 0 then
            return p101;
        else
            return p100;
        end;
    elseif p100 < p101 then
        return p100;
    else
        return p101;
    end;
end;
function v2.higherLanePriority(p102, p103) --[[ Line: 717 ]]
    if p102 == 0 or p103 >= p102 then
        return p103;
    else
        return p102;
    end;
end;
function v2.createLaneMap(p104) --[[ Line: 728 ]]
    return {
        [0] = p104,
        [1] = p104,
        [2] = p104,
        [3] = p104,
        [4] = p104,
        [5] = p104,
        [6] = p104,
        [7] = p104,
        [8] = p104,
        [9] = p104,
        [10] = p104,
        [11] = p104,
        [12] = p104,
        [13] = p104,
        [14] = p104,
        [15] = p104,
        [16] = p104,
        [17] = p104,
        [18] = p104,
        [19] = p104,
        [20] = p104,
        [21] = p104,
        [22] = p104,
        [23] = p104,
        [24] = p104,
        [25] = p104,
        [26] = p104,
        [27] = p104,
        [28] = p104,
        [29] = p104,
        [30] = p104,
        [31] = p104
    };
end;
function v2.markRootUpdated(p105, p106, p107) --[[ Line: 772 ]]
    p105.pendingLanes = bit32.bor(p105.pendingLanes, p106);
    local v108 = p106 - 1;
    p105.suspendedLanes = bit32.band(p105.suspendedLanes, v108);
    p105.pingedLanes = bit32.band(p105.pingedLanes, v108);
    p105.eventTimes[31 - bit32.countlz(p106)] = p107;
end;
function v2.markRootSuspended(p109, p110) --[[ Line: 801 ]]
    -- upvalues: u14 (ref)
    p109.suspendedLanes = bit32.bor(p109.suspendedLanes, p110);
    local l__pingedLanes__22 = p109.pingedLanes;
    local v111 = bit32.bnot(p110);
    p109.pingedLanes = bit32.band(l__pingedLanes__22, v111);
    local l__expirationTimes__23 = p109.expirationTimes;
    while p110 > 0 do
        local v112 = u14(p110);
        local v113 = bit32.lshift(1, v112);
        l__expirationTimes__23[v112] = -1;
        local v114 = bit32.bnot(v113);
        p110 = bit32.band(p110, v114);
    end;
end;
function v2.markRootPinged(p115, p116, _) --[[ Line: 819 ]]
    local l__pingedLanes__24 = p115.pingedLanes;
    local v117 = bit32.band(p115.suspendedLanes, p116);
    p115.pingedLanes = bit32.bor(l__pingedLanes__24, v117);
end;
function v2.markRootExpired(p118, p119) --[[ Line: 825 ]]
    local l__expiredLanes__25 = p118.expiredLanes;
    local v120 = bit32.band(p119, p118.pendingLanes);
    p118.expiredLanes = bit32.bor(l__expiredLanes__25, v120);
end;
function v2.markDiscreteUpdatesExpired(p121) --[[ Line: 831 ]]
    local l__expiredLanes__26 = p121.expiredLanes;
    local v122 = bit32.band(24, p121.pendingLanes);
    p121.expiredLanes = bit32.bor(l__expiredLanes__26, v122);
end;
function v2.hasDiscreteLanes(p123) --[[ Line: 837 ]]
    return bit32.band(p123, 24) ~= 0;
end;
function v2.markRootMutableRead(p124, p125) --[[ Line: 842 ]]
    local l__mutableReadLanes__27 = p124.mutableReadLanes;
    local v126 = bit32.band(p125, p124.pendingLanes);
    p124.mutableReadLanes = bit32.bor(l__mutableReadLanes__27, v126);
end;
function v2.markRootFinished(p127, p128) --[[ Line: 848 ]]
    -- upvalues: u14 (ref)
    local l__pendingLanes__28 = p127.pendingLanes;
    local v129 = bit32.bnot(p128);
    local v130 = bit32.band(l__pendingLanes__28, v129);
    p127.pendingLanes = p128;
    p127.suspendedLanes = 0;
    p127.pingedLanes = 0;
    p127.expiredLanes = bit32.band(p127.expiredLanes, p128);
    p127.mutableReadLanes = bit32.band(p127.mutableReadLanes, p128);
    p127.entangledLanes = bit32.band(p127.entangledLanes, p128);
    local l__entanglements__29 = p127.entanglements;
    local l__eventTimes__30 = p127.eventTimes;
    local l__expirationTimes__31 = p127.expirationTimes;
    while v130 > 0 do
        local v131 = u14(v130);
        local v132 = bit32.lshift(1, v131);
        l__entanglements__29[v131] = 0;
        l__eventTimes__30[v131] = -1;
        l__expirationTimes__31[v131] = -1;
        local v133 = bit32.bnot(v132);
        v130 = bit32.band(v130, v133);
    end;
end;
function v2.markRootEntangled(p134, p135) --[[ Line: 881 ]]
    -- upvalues: u14 (ref)
    p134.entangledLanes = bit32.bor(p134.entangledLanes, p135);
    local l__entanglements__32 = p134.entanglements;
    local v136 = p135;
    while p135 > 0 do
        local v137 = u14(p135);
        local v138 = bit32.lshift(1, v137);
        l__entanglements__32[v137] = bit32.bor(l__entanglements__32[v137], v136);
        local v139 = bit32.bnot(v138);
        p135 = bit32.band(p135, v139);
    end;
end;
function v2.getBumpedLaneForHydration(p140, p141) --[[ Line: 897 ]]
    -- upvalues: u11 (copy), l__DefaultLanePriority__10 (ref), l__invariant__2 (copy)
    u11(p141);
    local v142 = l__DefaultLanePriority__10;
    local v143 = nil;
    if v142 == 15 or v142 == 14 then
        v143 = 0;
    elseif v142 == 13 or v142 == 12 then
        v143 = 4;
    elseif v142 == 11 or v142 == 10 then
        v143 = 32;
    elseif v142 == 9 or v142 == 8 then
        v143 = 256;
    elseif v142 == 7 or v142 == 6 or v142 == 5 then
        v143 = 4096;
    elseif v142 == 4 then
        v143 = 67108864;
    elseif v142 == 3 or v142 == 2 then
        v143 = 134217728;
    elseif v142 == 1 or v142 == 0 then
        v143 = 0;
    else
        l__invariant__2(false, "Invalid lane: %s. This is a bug in React.", (tostring(v143)));
    end;
    local v144 = bit32.bor(p140.suspendedLanes, p141);
    return bit32.band(v143, v144) ~= 0 and 0 or v143;
end;
return v2;