-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberReconciler
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent:WaitForChild("ReactFiberReconciler.new"));