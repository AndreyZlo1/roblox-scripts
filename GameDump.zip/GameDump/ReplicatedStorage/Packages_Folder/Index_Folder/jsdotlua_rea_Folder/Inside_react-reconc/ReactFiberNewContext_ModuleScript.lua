-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberNewContext.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local l__Number__1 = v1.Number;
local l__Error__2 = v1.Error;
local l__console__3 = require(script.Parent.Parent:WaitForChild("shared")).console;
require(script.Parent.Parent:WaitForChild("shared"));
require(script.Parent:WaitForChild("ReactInternalTypes"));
local v2 = require(script.Parent:WaitForChild("ReactFiberStack.new"));
local l__ReactFiberLane__4 = require(script.Parent:WaitForChild("ReactFiberLane"));
local v3 = require(script.Parent:WaitForChild("ReactUpdateQueue.new"));
local l__isPrimaryRenderer__5 = require(script.Parent:WaitForChild("ReactFiberHostConfig")).isPrimaryRenderer;
local l__createCursor__6 = v2.createCursor;
local l__push__7 = v2.push;
local l__pop__8 = v2.pop;
local l__MAX_SIGNED_31_BIT_INT__9 = require(script.Parent:WaitForChild("MaxInts")).MAX_SIGNED_31_BIT_INT;
local l__ReactWorkTags__10 = require(script.Parent:WaitForChild("ReactWorkTags"));
local l__ContextProvider__11 = l__ReactWorkTags__10.ContextProvider;
local l__ClassComponent__12 = l__ReactWorkTags__10.ClassComponent;
local l__NoLanes__13 = l__ReactFiberLane__4.NoLanes;
local l__NoTimestamp__14 = l__ReactFiberLane__4.NoTimestamp;
local l__isSubsetOfLanes__15 = l__ReactFiberLane__4.isSubsetOfLanes;
local l__includesSomeLane__16 = l__ReactFiberLane__4.includesSomeLane;
local l__mergeLanes__17 = l__ReactFiberLane__4.mergeLanes;
local l__pickArbitraryLane__18 = l__ReactFiberLane__4.pickArbitraryLane;
local l__objectIs__19 = require(script.Parent.Parent:WaitForChild("shared")).objectIs;
local l__createUpdate__20 = v3.createUpdate;
local l__ForceUpdate__21 = v3.ForceUpdate;
local u4 = {};
local u5 = l__createCursor__6(nil);
local u6 = _G.__DEV__ and {} or nil;
local u7 = nil;
local u8 = nil;
local u9 = nil;
local u10 = false;
function u4.resetContextDependencies() --[[ Line: 72 ]]
    -- upvalues: u7 (ref), u8 (ref), u9 (ref), u10 (ref)
    u7 = nil;
    u8 = nil;
    u9 = nil;
    if _G.__DEV__ then
        u10 = false;
    end;
end;
function u4.enterDisallowedContextReadInDEV() --[[ Line: 83 ]]
    -- upvalues: u10 (ref)
    if _G.__DEV__ then
        u10 = true;
    end;
end;
function u4.exitDisallowedContextReadInDEV() --[[ Line: 89 ]]
    -- upvalues: u10 (ref)
    if _G.__DEV__ then
        u10 = false;
    end;
end;
function u4.pushProvider(p11, p12) --[[ Line: 95 ]]
    -- upvalues: l__isPrimaryRenderer__5 (copy), l__push__7 (copy), u5 (copy), u6 (ref), l__console__3 (copy)
    local l___context__22 = p11.type._context;
    if l__isPrimaryRenderer__5 then
        l__push__7(u5, l___context__22._currentValue, p11);
        l___context__22._currentValue = p12;
        if _G.__DEV__ then
            if l___context__22._currentRenderer ~= nil and l___context__22._currentRenderer ~= u6 then
                l__console__3.error("Detected multiple renderers concurrently rendering the same context provider. This is currently unsupported.");
            end;
            l___context__22._currentRenderer = u6;
        end;
    else
        l__push__7(u5, l___context__22._currentValue2, p11);
        l___context__22._currentValue2 = p12;
        if _G.__DEV__ then
            if l___context__22._currentRenderer2 ~= nil and l___context__22._currentRenderer2 ~= u6 then
                l__console__3.error("Detected multiple renderers concurrently rendering the same context provider. This is currently unsupported.");
            end;
            l___context__22._currentRenderer2 = u6;
        end;
    end;
end;
function u4.popProvider(p13) --[[ Line: 133 ]]
    -- upvalues: u5 (copy), l__pop__8 (copy), l__isPrimaryRenderer__5 (copy)
    local l__current__23 = u5.current;
    l__pop__8(u5, p13);
    local l___context__24 = p13.type._context;
    if l__isPrimaryRenderer__5 then
        l___context__24._currentValue = l__current__23;
    else
        l___context__24._currentValue2 = l__current__23;
    end;
end;
function u4.calculateChangedBits(p14, p15, p16) --[[ Line: 147 ]]
    -- upvalues: l__objectIs__19 (copy), l__MAX_SIGNED_31_BIT_INT__9 (copy)
    if l__objectIs__19(p16, p15) then
        return 0;
    end;
    local v17 = l__MAX_SIGNED_31_BIT_INT__9;
    if typeof(p14._calculateChangedBits) == "function" then
        v17 = p14._calculateChangedBits(p16, p15);
    end;
    return math.floor(v17);
end;
function u4.scheduleWorkOnParentPath(p18, p19) --[[ Line: 174 ]]
    -- upvalues: l__isSubsetOfLanes__15 (copy), l__mergeLanes__17 (copy)
    while p18 ~= nil do
        local l__alternate__25 = p18.alternate;
        if l__isSubsetOfLanes__15(p18.childLanes, p19) then
            if l__alternate__25 == nil or l__isSubsetOfLanes__15(l__alternate__25.childLanes, p19) then
                break;
            end;
            l__alternate__25.childLanes = l__mergeLanes__17(l__alternate__25.childLanes, p19);
        else
            p18.childLanes = l__mergeLanes__17(p18.childLanes, p19);
            if l__alternate__25 ~= nil then
                l__alternate__25.childLanes = l__mergeLanes__17(l__alternate__25.childLanes, p19);
            end;
        end;
        p18 = p18.return_;
    end;
end;
function u4.propagateContextChange(p20, p21, p22, p23) --[[ Line: 197 ]]
    -- upvalues: l__ClassComponent__12 (copy), l__createUpdate__20 (copy), l__NoTimestamp__14 (copy), l__pickArbitraryLane__18 (copy), l__ForceUpdate__21 (copy), u4 (copy), l__ContextProvider__11 (copy)
    local l__child__26 = p20.child;
    if l__child__26 ~= nil then
        l__child__26.return_ = p20;
    end;
    while true do
        local v24;
        if true then
            if l__child__26 == nil then
                return;
            end;
            local l__dependencies__27 = l__child__26.dependencies;
            if l__dependencies__27 == nil then
                if l__child__26.tag == l__ContextProvider__11 then
                    if l__child__26.type == p20.type then
                        v24 = nil;
                    else
                        v24 = l__child__26.child;
                    end;
                else
                    v24 = l__child__26.child;
                end;
            else
                v24 = l__child__26.child;
                local l__firstContext__28 = l__dependencies__27.firstContext;
                while l__firstContext__28 ~= nil do
                    if l__firstContext__28.context == p21 and bit32.band(l__firstContext__28.observedBits, p22) ~= 0 then
                        if l__child__26.tag == l__ClassComponent__12 then
                            local v25 = l__createUpdate__20(l__NoTimestamp__14, l__pickArbitraryLane__18(p23));
                            v25.tag = l__ForceUpdate__21;
                            local l__updateQueue__29 = l__child__26.updateQueue;
                            if l__updateQueue__29 ~= nil then
                                local l__shared__30 = l__updateQueue__29.shared;
                                local l__pending__31 = l__shared__30.pending;
                                if l__pending__31 == nil then
                                    v25.next = v25;
                                else
                                    v25.next = l__pending__31.next;
                                    l__pending__31.next = v25;
                                end;
                                l__shared__30.pending = v25;
                            end;
                        end;
                        l__child__26.lanes = bit32.bor(l__child__26.lanes, p23);
                        local l__alternate__32 = l__child__26.alternate;
                        if l__alternate__32 ~= nil then
                            l__alternate__32.lanes = bit32.bor(l__alternate__32.lanes, p23);
                        end;
                        u4.scheduleWorkOnParentPath(l__child__26.return_, p23);
                        l__dependencies__27.lanes = bit32.bor(l__dependencies__27.lanes, p23);
                        break;
                    end;
                    l__firstContext__28 = l__firstContext__28.next;
                end;
            end;
        end;
        if v24 == nil then
            while true do
                if l__child__26 == nil then
                    v24 = l__child__26;
                end;
                if l__child__26 == p20 then
                    v24 = nil;
                end;
                v24 = l__child__26.sibling;
                if v24 ~= nil then
                    v24.return_ = l__child__26.return_;
                end;
                l__child__26 = l__child__26.return_;
            end;
        else
            v24.return_ = l__child__26;
        end;
        l__child__26 = v24;
    end;
end;
function u4.prepareToReadContext(p26, p27, p28) --[[ Line: 336 ]]
    -- upvalues: u7 (ref), u8 (ref), u9 (ref), l__includesSomeLane__16 (copy)
    u7 = p26;
    u8 = nil;
    u9 = nil;
    local l__dependencies__33 = p26.dependencies;
    if l__dependencies__33 ~= nil and l__dependencies__33.firstContext ~= nil then
        if l__includesSomeLane__16(l__dependencies__33.lanes, p27) then
            p28();
        end;
        l__dependencies__33.firstContext = nil;
    end;
end;
function u4.readContext(p29, p30) --[[ Line: 360 ]]
    -- upvalues: u10 (ref), l__console__3 (copy), u9 (ref), l__Number__1 (copy), u8 (ref), u7 (ref), l__Error__2 (copy), l__NoLanes__13 (copy), l__isPrimaryRenderer__5 (copy)
    if _G.__DEV__ and u10 then
        l__console__3.error("Context can only be read while React is rendering. In classes, you can read it in the render method or getDerivedStateFromProps. In function components, you can read it directly in the function body, but not inside Hooks like useReducer() or useMemo().");
    end;
    if u9 ~= p29 and (p30 ~= false and p30 ~= 0) then
        if typeof(p30) ~= "number" or p30 == l__Number__1.MAX_SAFE_INTEGER then
            u9 = p29;
            p30 = l__Number__1.MAX_SAFE_INTEGER;
        end;
        local v31 = {
            next = nil,
            context = p29,
            observedBits = p30
        };
        if u8 == nil then
            if u7 == nil then
                error(l__Error__2.new("Context can only be read while React is rendering. In classes, you can read it in the render method or getDerivedStateFromProps. In function components, you can read it directly in the function body, but not inside Hooks like useReducer() or useMemo()."));
            end;
            u8 = v31;
            u7.dependencies = {
                responders = nil,
                lanes = l__NoLanes__13,
                firstContext = v31
            };
        else
            u8.next = v31;
            u8 = v31;
        end;
    end;
    if l__isPrimaryRenderer__5 then
        return p29._currentValue;
    else
        return p29._currentValue2;
    end;
end;
return u4;