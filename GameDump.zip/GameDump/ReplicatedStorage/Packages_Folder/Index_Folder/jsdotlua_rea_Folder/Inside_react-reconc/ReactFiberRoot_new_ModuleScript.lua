-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactFiberRoot.new
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local l__Set__1 = v1.Set;
local l__Map__2 = v1.Map;
require(script.Parent:WaitForChild("ReactInternalTypes"));
local l__ReactRootTags__3 = require(script.Parent:WaitForChild("ReactRootTags"));
local l__ReactFiberHostConfig__4 = require(script.Parent:WaitForChild("ReactFiberHostConfig"));
local l__noTimeout__5 = l__ReactFiberHostConfig__4.noTimeout;
local l__supportsHydration__6 = l__ReactFiberHostConfig__4.supportsHydration;
local l__createHostRootFiber__7 = require(script.Parent:WaitForChild("ReactFiber.new")).createHostRootFiber;
local l__ReactFiberLane__8 = require(script.Parent:WaitForChild("ReactFiberLane"));
local l__NoLanes__9 = l__ReactFiberLane__8.NoLanes;
local l__NoLanePriority__10 = l__ReactFiberLane__8.NoLanePriority;
local l__NoTimestamp__11 = l__ReactFiberLane__8.NoTimestamp;
local l__createLaneMap__12 = l__ReactFiberLane__8.createLaneMap;
local l__ReactFeatureFlags__13 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags;
local l__enableSchedulerTracing__14 = l__ReactFeatureFlags__13.enableSchedulerTracing;
local l__enableSuspenseCallback__15 = l__ReactFeatureFlags__13.enableSuspenseCallback;
local l__unstable_getThreadID__16 = require(script.Parent.Parent:WaitForChild("scheduler")).tracing.unstable_getThreadID;
local l__initializeUpdateQueue__17 = require(script.Parent:WaitForChild("ReactUpdateQueue.new")).initializeUpdateQueue;
local l__LegacyRoot__18 = l__ReactRootTags__3.LegacyRoot;
local l__BlockingRoot__19 = l__ReactRootTags__3.BlockingRoot;
local l__ConcurrentRoot__20 = l__ReactRootTags__3.ConcurrentRoot;
local v2 = {};
local function u7(p3, p4, p5) --[[ Line: 47 ]]
    -- upvalues: l__noTimeout__5 (copy), l__NoLanePriority__10 (copy), l__createLaneMap__12 (copy), l__NoLanes__9 (copy), l__NoTimestamp__11 (copy), l__supportsHydration__6 (copy), l__enableSchedulerTracing__14 (copy), l__unstable_getThreadID__16 (copy), l__Set__1 (copy), l__Map__2 (copy), l__enableSuspenseCallback__15 (copy), l__BlockingRoot__19 (copy), l__ConcurrentRoot__20 (copy), l__LegacyRoot__18 (copy)
    local v6 = {
        pendingChildren = nil,
        current = nil,
        pingCache = nil,
        finishedWork = nil,
        context = nil,
        pendingContext = nil,
        callbackNode = nil,
        tag = p4,
        containerInfo = p3,
        timeoutHandle = l__noTimeout__5,
        hydrate = p5,
        callbackPriority = l__NoLanePriority__10,
        eventTimes = l__createLaneMap__12(l__NoLanes__9),
        expirationTimes = l__createLaneMap__12(l__NoTimestamp__11),
        pendingLanes = l__NoLanes__9,
        suspendedLanes = l__NoLanes__9,
        pingedLanes = l__NoLanes__9,
        expiredLanes = l__NoLanes__9,
        mutableReadLanes = l__NoLanes__9,
        finishedLanes = l__NoLanes__9,
        entangledLanes = l__NoLanes__9,
        entanglements = l__createLaneMap__12(l__NoLanes__9)
    };
    if l__supportsHydration__6 then
        v6.mutableSourceEagerHydrationData = nil;
    end;
    if l__enableSchedulerTracing__14 then
        v6.interactionThreadID = l__unstable_getThreadID__16();
        v6.memoizedInteractions = l__Set__1.new();
        v6.pendingInteractionMap = l__Map__2.new();
    end;
    if l__enableSuspenseCallback__15 then
        v6.hydrationCallbacks = nil;
    end;
    if _G.__DEV__ then
        if p4 == l__BlockingRoot__19 then
            v6._debugRootType = "createBlockingRoot()";
            return v6;
        end;
        if p4 == l__ConcurrentRoot__20 then
            v6._debugRootType = "createRoot()";
            return v6;
        end;
        if p4 == l__LegacyRoot__18 then
            v6._debugRootType = "createLegacyRoot()";
        end;
    end;
    return v6;
end;
function v2.createFiberRoot(p8, p9, p10, p11) --[[ Line: 103 ]]
    -- upvalues: u7 (copy), l__enableSuspenseCallback__15 (copy), l__createHostRootFiber__7 (copy), l__initializeUpdateQueue__17 (copy)
    local v12 = u7(p8, p9, p10);
    if l__enableSuspenseCallback__15 then
        v12.hydrationCallbacks = p11;
    end;
    local v13 = l__createHostRootFiber__7(p9);
    v12.current = v13;
    v13.stateNode = v12;
    l__initializeUpdateQueue__17(v13);
    return v12;
end;
return v2;