-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler.ReactInternalTypes
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent:WaitForChild("luau-polyfill"));
require(script.Parent.Parent:WaitForChild("shared"));
require(script.Parent:WaitForChild("ReactWorkTags"));
require(script.Parent:WaitForChild("ReactTypeOfMode"));
require(script.Parent:WaitForChild("ReactFiberFlags"));
require(script.Parent:WaitForChild("ReactRootTags"));
require(script.Parent.Parent:WaitForChild("shared"));
require(script.Parent.Parent:WaitForChild("scheduler"));
return {};