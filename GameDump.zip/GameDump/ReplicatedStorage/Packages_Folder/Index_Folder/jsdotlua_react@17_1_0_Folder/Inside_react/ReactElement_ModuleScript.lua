-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react@17.1.0.react.ReactElement
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
local l__Error__2 = require(script.Parent.Parent:WaitForChild("luau-polyfill")).Error;
local l__console__3 = require(script.Parent.Parent:WaitForChild("shared")).console;
require(script.Parent.Parent:WaitForChild("shared"));
require(script.Parent:WaitForChild("ReactLazy"));
local l__getComponentName__4 = require(script.Parent.Parent:WaitForChild("shared")).getComponentName;
local l__REACT_ELEMENT_TYPE__5 = require(script.Parent.Parent:WaitForChild("shared")).ReactSymbols.REACT_ELEMENT_TYPE;
local l__ReactCurrentOwner__6 = require(script.Parent.Parent:WaitForChild("shared")).ReactSharedInternals.ReactCurrentOwner;
local u1 = {
    key = true,
    ref = true,
    __self = true,
    __source = true
};
local u2 = nil;
local u3 = nil;
local u4 = l____DEV____1 and {} or nil;
local v5 = {};
local u6 = {
    isReactWarning = true
};
local function u10(p7, u8) --[[ Line: 92 ]]
    -- upvalues: l____DEV____1 (copy), u2 (ref), l__console__3 (copy), u6 (copy)
    p7.key = nil;
    setmetatable(p7, {
        __index = function(_, p9) --[[ Name: __index, Line 112 ]]
            -- upvalues: l____DEV____1 (ref), u2 (ref), l__console__3 (ref), u8 (copy), u6 (ref)
            if p9 ~= "key" then
                return nil;
            end;
            if l____DEV____1 and not u2 then
                u2 = true;
                l__console__3.error("%s: `key` is not a prop. Trying to access it will result in `nil` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", u8);
            end;
            return u6;
        end
    });
end;
local function u14(p11, u12) --[[ Line: 124 ]]
    -- upvalues: l____DEV____1 (copy), u3 (ref), l__console__3 (copy), u6 (copy)
    p11.ref = nil;
    setmetatable(p11, {
        __index = function(_, p13) --[[ Name: __index, Line 146 ]]
            -- upvalues: l____DEV____1 (ref), u3 (ref), l__console__3 (ref), u12 (copy), u6 (ref)
            if p13 ~= "ref" then
                return nil;
            end;
            if l____DEV____1 and not u3 then
                u3 = true;
                l__console__3.error("%s: `ref` is not a prop. Trying to access it will result in `nil` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", u12);
            end;
            return u6;
        end
    });
end;
local function u17(p15) --[[ Line: 158 ]]
    -- upvalues: l____DEV____1 (copy), l__ReactCurrentOwner__6 (copy), l__getComponentName__4 (copy), u4 (ref)
    if l____DEV____1 and (type(p15.ref) == "string" and l__ReactCurrentOwner__6.current) then
        local v16 = l__getComponentName__4(l__ReactCurrentOwner__6.current.type);
        if not u4[v16] then
            error(string.format("Component \"%s\" contains the string ref \"%s\". Support for string refs has been removed. We recommend using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref", v16 or "Unknown", p15.ref));
        end;
    end;
end;
local function u30(p18, p19, p20, p21, p22, p23, p24) --[[ Line: 209 ]]
    -- upvalues: l__REACT_ELEMENT_TYPE__5 (copy), l____DEV____1 (copy)
    local v25 = {
        type = p18,
        key = p19,
        ref = p20,
        props = p24,
        _owner = p23,
        ["$$typeof"] = l__REACT_ELEMENT_TYPE__5
    };
    if l____DEV____1 then
        local u26 = {
            validated = false
        };
        v25._store = setmetatable({}, {
            __index = u26,
            __newindex = function(p27, p28, p29) --[[ Name: __newindex, Line 246 ]]
                -- upvalues: u26 (copy)
                if p28 == "validated" then
                    u26.validated = p29;
                else
                    rawset(p27, p28, p29);
                end;
            end
        });
        setmetatable(v25, {
            __index = {
                _self = p21,
                _source = p22
            }
        });
    end;
    return v25;
end;
function v5.jsx(_, _, _) --[[ Line: 277 ]]
    error("JSX is currently unsupported");
end;
function v5.jsxDEV(_, _, _, _, _) --[[ Line: 332 ]]
    error("JSX is currently unsupported");
    return nil;
end;
function v5.createElement(p31, p32, ...) --[[ Line: 408 ]]
    -- upvalues: l____DEV____1 (copy), u17 (copy), u10 (copy), u14 (copy), u30 (copy), l__ReactCurrentOwner__6 (copy)
    local v33 = p32 == nil and {} or table.clone(p32);
    local v34 = nil;
    local v35 = nil;
    local v36;
    if p32 == nil then
        v36 = nil;
    else
        local v37;
        if l____DEV____1 and (p32.ref ~= nil and (type(p32.ref) == "table" and p32.ref.isReactWarning)) then
            v37 = false;
        else
            v37 = p32.ref ~= nil;
        end;
        if v37 then
            v35 = p32.ref;
            if l____DEV____1 then
                u17(p32);
            end;
        end;
        local v38;
        if l____DEV____1 and (p32.key ~= nil and (type(p32.key) == "table" and p32.key.isReactWarning)) then
            v38 = false;
        else
            v38 = p32.key ~= nil;
        end;
        if v38 then
            v34 = p32.key;
            if type(v34) ~= "number" then
                v34 = tostring(v34);
            end;
        end;
        if p32.__source == nil then
            v36 = nil;
        else
            v36 = p32.__source;
        end;
        if v33.key ~= nil then
            v33.key = nil;
        end;
        if v33.ref ~= nil then
            v33.ref = nil;
        end;
        if v33.__self ~= nil then
            v33.__self = nil;
        end;
        if v33.__source ~= nil then
            v33.__source = nil;
        end;
    end;
    local v39 = select("#", ...);
    if v39 == 1 then
        v33.children = select(1, ...);
    elseif v39 > 1 then
        local v40 = table.create(v39);
        for v41 = 1, v39 do
            local v42 = select(v41, ...);
            table.insert(v40, v42);
        end;
        if l____DEV____1 then
            table.freeze(v40);
        end;
        v33.children = v40;
    end;
    if type(p31) == "table" and p31.defaultProps then
        local l__defaultProps__7 = p31.defaultProps;
        for v43, _ in l__defaultProps__7 do
            if v33[v43] == nil then
                v33[v43] = l__defaultProps__7[v43];
            end;
        end;
    end;
    if l____DEV____1 then
        if v34 or v35 then
            local v44;
            if type(p31) == "function" then
                v44 = debug.info(p31, "n") or "<function>";
            else
                v44 = type(p31) == "table" and (p31.displayName or (p31.name or "Unknown")) or p31;
            end;
            if v34 then
                u10(v33, v44);
            end;
            if v35 then
                u14(v33, v44);
            end;
        end;
        v36 = v36 == nil and {
            fileName = debug.info(3, "s"),
            lineNumber = debug.info(3, "l")
        } or v36;
    end;
    return u30(p31, v34, v35, nil, v36, l__ReactCurrentOwner__6.current, v33);
end;
function v5.cloneAndReplaceKey(p45, p46) --[[ Line: 587 ]]
    -- upvalues: u30 (copy)
    return u30(p45.type, p46, p45.ref, p45._self, p45._source, p45._owner, p45.props);
end;
function v5.cloneElement(p47, p48, ...) --[[ Line: 605 ]]
    -- upvalues: l__Error__2 (copy), l__ReactCurrentOwner__6 (copy), l____DEV____1 (copy), u1 (copy), u30 (copy)
    if p47 == nil then
        error(l__Error__2.new("React.cloneElement(...): The argument must be a React element, but you passed " .. tostring(p47)));
    end;
    local l__props__8 = p47.props;
    local v49 = l__props__8 == nil and {} or table.clone(l__props__8);
    local l__key__9 = p47.key;
    local l__ref__10 = p47.ref;
    local l___source__11 = p47._source;
    local l___owner__12 = p47._owner;
    if p48 ~= nil then
        local l__ref__13 = p48.ref;
        if l__ref__13 == nil then
            if not l____DEV____1 or (p48.ref == nil or (type(p48.ref) ~= "table" or not p48.ref.isReactWarning)) then
                local _ = p48.ref == nil;
            end;
        else
            l___owner__12 = l__ReactCurrentOwner__6.current;
            l__ref__10 = l__ref__13;
        end;
        local l__key__14 = p48.key;
        if l__key__14 == nil then
            if not l____DEV____1 or (p48.key == nil or (type(p48.key) ~= "table" or not p48.key.isReactWarning)) then
                local _ = p48.key == nil;
            end;
        elseif type(l__key__14) == "number" then
            l__key__9 = l__key__14;
        else
            l__key__9 = l__key__14 or "nil";
        end;
    end;
    local l__type__15 = p47.type;
    local v50;
    if type(l__type__15) == "table" then
        v50 = l__type__15.defaultProps;
    else
        v50 = nil;
    end;
    if p48 ~= nil then
        for v51, _ in p48 do
            if p48[v51] ~= nil and not u1[v51] then
                if p48[v51] == nil and v50 ~= nil then
                    v49[v51] = v50[v51];
                else
                    v49[v51] = p48[v51];
                end;
            end;
        end;
    end;
    local v52 = select("#", ...);
    if v52 == 1 then
        v49.children = select(1, ...);
    elseif v52 > 1 then
        v49.children = { ... };
    end;
    return u30(p47.type, l__key__9, l__ref__10, nil, l___source__11, l___owner__12, v49);
end;
function v5.isValidElement(p53) --[[ Line: 721 ]]
    -- upvalues: l__REACT_ELEMENT_TYPE__5 (copy)
    local v54;
    if type(p53) == "table" then
        v54 = p53["$$typeof"] == l__REACT_ELEMENT_TYPE__5;
    else
        v54 = false;
    end;
    return v54;
end;
return v5;