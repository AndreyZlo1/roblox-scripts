-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react@17.1.0.react.createSignal.roblox
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function() --[[ Name: createSignal, Line 36 ]]
    local u1 = {};
    local u2 = {};
    local u3 = false;
    return function(u4) --[[ Name: subscribe, Line 41 ]]
        -- upvalues: u3 (ref), u1 (copy), u2 (copy)
        local v5 = typeof(u4) == "function";
        assert(v5, "Can only subscribe to signals with a function.");
        local u6 = {
            disconnected = false,
            callback = u4
        };
        if u3 and not u1[u4] then
            u2[u4] = u6;
        end;
        u1[u4] = u6;
        return function() --[[ Name: disconnect, Line 60 ]]
            -- upvalues: u6 (copy), u1 (ref), u4 (copy), u2 (ref)
            assert(not u6.disconnected, "Listeners can only be disconnected once.");
            u6.disconnected = true;
            u1[u4] = nil;
            u2[u4] = nil;
        end;
    end, function(...) --[[ Name: fire, Line 74 ]]
        -- upvalues: u3 (ref), u1 (copy), u2 (copy)
        u3 = true;
        for v7, v8 in u1 do
            if not (v8.disconnected or u2[v7]) then
                v7(...);
            end;
        end;
        u3 = false;
        table.clear(u2);
    end;
end;