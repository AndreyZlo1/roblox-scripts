-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react@17.1.0.react.ReactForwardRef
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__console__1 = require(script.Parent.Parent:WaitForChild("shared")).console;
local l__ReactSymbols__2 = require(script.Parent.Parent:WaitForChild("shared")).ReactSymbols;
require(script.Parent.Parent:WaitForChild("shared"));
local l__REACT_FORWARD_REF_TYPE__3 = l__ReactSymbols__2.REACT_FORWARD_REF_TYPE;
local l__REACT_MEMO_TYPE__4 = l__ReactSymbols__2.REACT_MEMO_TYPE;
return {
    forwardRef = function(p1) --[[ Line: 27 ]]
        -- upvalues: l__REACT_MEMO_TYPE__4 (copy), l__console__1 (copy), l__REACT_FORWARD_REF_TYPE__3 (copy)
        if _G.__DEV__ then
            if typeof(p1) == "table" and p1["$$typeof"] == l__REACT_MEMO_TYPE__4 then
                l__console__1.error("forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...)).");
            elseif typeof(p1) == "function" then
                local v2, _ = debug.info(p1, "a");
                if v2 ~= 0 and v2 ~= 2 then
                    l__console__1.error("forwardRef render functions accept exactly two parameters: props and ref. %s", v2 == 1 and "Did you forget to use the ref parameter?" or "Any additional parameter will be undefined.");
                end;
            else
                l__console__1.error("forwardRef requires a render function but was given %s.", (typeof(p1)));
            end;
        end;
        local v3 = {
            ["$$typeof"] = l__REACT_FORWARD_REF_TYPE__3,
            render = p1
        };
        if _G.__DEV__ then
            local u4 = nil;
            setmetatable(v3, {
                __index = function(p5, p6) --[[ Name: __index, Line 84 ]]
                    -- upvalues: u4 (ref)
                    if p6 == "displayName" then
                        return u4;
                    else
                        return rawget(p5, p6);
                    end;
                end,
                __newindex = function(p7, p8, p9) --[[ Name: __newindex, Line 90 ]]
                    -- upvalues: u4 (ref)
                    if p8 == "displayName" then
                        u4 = p9;
                    else
                        rawset(p7, p8, p9);
                    end;
                end
            });
        end;
        return v3;
    end
};