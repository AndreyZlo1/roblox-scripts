-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react@17.1.0.react.ReactContext
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__console__1 = require(script.Parent.Parent:WaitForChild("shared")).console;
local l__ReactSymbols__2 = require(script.Parent.Parent:WaitForChild("shared")).ReactSymbols;
local l__REACT_PROVIDER_TYPE__3 = l__ReactSymbols__2.REACT_PROVIDER_TYPE;
local l__REACT_CONTEXT_TYPE__4 = l__ReactSymbols__2.REACT_CONTEXT_TYPE;
return {
    createContext = function(p1, p2) --[[ Line: 23 ]]
        -- upvalues: l__REACT_CONTEXT_TYPE__4 (copy), l__REACT_PROVIDER_TYPE__3 (copy), l__console__1 (copy)
        local u3 = {
            ["$$typeof"] = l__REACT_CONTEXT_TYPE__4,
            _calculateChangedBits = p2,
            _currentValue = p1,
            _currentValue2 = p1,
            _threadCount = 0,
            Provider = nil,
            Consumer = nil,
            displayName = nil,
            _currentRenderer = nil,
            _currentRenderer2 = nil
        };
        u3.Provider = {
            ["$$typeof"] = l__REACT_PROVIDER_TYPE__3,
            _context = u3
        };
        local u4 = false;
        if _G.__DEV__ then
            local v5 = {
                ["$$typeof"] = l__REACT_CONTEXT_TYPE__4,
                _context = u3,
                _calculateChangedBits = u3._calculateChangedBits
            };
            setmetatable(v5, {
                __index = function(_, p6) --[[ Name: __index, Line 68 ]]
                    -- upvalues: u3 (copy)
                    if p6 == "_currentValue" then
                        return u3._currentValue;
                    elseif p6 == "_currentValue2" then
                        return u3._currentValue2;
                    elseif p6 == "_threadCount" then
                        return u3._threadCount;
                    elseif p6 == "displayName" then
                        return u3.displayName;
                    else
                        return nil;
                    end;
                end,
                __newindex = function(_, p7, p8) --[[ Name: __newindex, Line 81 ]]
                    -- upvalues: u3 (copy), u4 (ref), l__console__1 (ref)
                    if p7 == "_currentValue" then
                        u3._currentValue = p8;
                    elseif p7 == "_currentValue2" then
                        u3._currentValue2 = p8;
                    elseif p7 == "_threadCount" then
                        u3._threadCount = p8;
                    else
                        if p7 == "displayName" and not u4 then
                            l__console__1.warn("Setting `displayName` on Context.Consumer has no effect. " .. "You should set it directly on the context with Context.displayName = " .. p8 .. ".");
                            u4 = true;
                        end;
                    end;
                end
            });
            u3.Consumer = v5;
        else
            u3.Consumer = u3;
        end;
        if _G.__DEV__ then
            u3._currentRenderer = nil;
            u3._currentRenderer2 = nil;
        end;
        return u3;
    end
};