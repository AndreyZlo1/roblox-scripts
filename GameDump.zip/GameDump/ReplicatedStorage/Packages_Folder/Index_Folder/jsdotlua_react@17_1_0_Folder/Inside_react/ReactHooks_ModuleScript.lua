-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react@17.1.0.react.ReactHooks
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Array__1 = require(script.Parent.Parent:WaitForChild("luau-polyfill")).Array;
local l__console__2 = require(script.Parent.Parent:WaitForChild("shared")).console;
require(script.Parent.Parent:WaitForChild("shared"));
require(script.Parent.Parent:WaitForChild("shared"));
local l__ReactCurrentDispatcher__3 = require(script.Parent.Parent:WaitForChild("shared")).ReactSharedInternals.ReactCurrentDispatcher;
return {
    useContext = function(p1, p2, ...) --[[ Name: useContext, Line 67 ]]
        -- upvalues: l__ReactCurrentDispatcher__3 (copy), l__console__2 (copy), l__Array__1 (copy)
        local l__current__4 = l__ReactCurrentDispatcher__3.current;
        if _G.__DEV__ and l__current__4 == nil then
            l__console__2.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.");
        end;
        if _G.__DEV__ then
            if p2 ~= nil then
                l__console__2.error("useContext() second argument is reserved for future use in React. Passing it is not supported. You passed: %s.%s", p2, typeof(p2) == "number" and l__Array__1.isArray({ ... }) and "\n\nDid you call Array.map(useContext)? Calling Hooks inside a loop is not supported. Learn more at https://reactjs.org/link/rules-of-hooks" or "");
            end;
            if p1._context ~= nil then
                local l___context__5 = p1._context;
                if l___context__5.Consumer == p1 then
                    l__console__2.error("Calling useContext(Context.Consumer) is not supported, may cause bugs, and will be removed in a future major release. Did you mean to call useContext(Context) instead?");
                elseif l___context__5.Provider == p1 then
                    l__console__2.error("Calling useContext(Context.Provider) is not supported. Did you mean to call useContext(Context) instead?");
                end;
            end;
        end;
        return l__current__4.useContext(p1, p2);
    end,
    useState = function(p3, ...) --[[ Name: useState, Line 108 ]]
        -- upvalues: l__ReactCurrentDispatcher__3 (copy), l__console__2 (copy)
        local l__current__6 = l__ReactCurrentDispatcher__3.current;
        if _G.__DEV__ and l__current__6 == nil then
            l__console__2.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.");
        end;
        return l__current__6.useState(p3, ...);
    end,
    useReducer = function(p4, p5, p6) --[[ Name: useReducer, Line 117 ]]
        -- upvalues: l__ReactCurrentDispatcher__3 (copy), l__console__2 (copy)
        local l__current__7 = l__ReactCurrentDispatcher__3.current;
        if _G.__DEV__ and l__current__7 == nil then
            l__console__2.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.");
        end;
        return l__current__7.useReducer(p4, p5, p6);
    end,
    useRef = function(p7) --[[ Name: useRef, Line 129 ]]
        -- upvalues: l__ReactCurrentDispatcher__3 (copy), l__console__2 (copy)
        local l__current__8 = l__ReactCurrentDispatcher__3.current;
        if _G.__DEV__ and l__current__8 == nil then
            l__console__2.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.");
        end;
        return l__current__8.useRef(p7);
    end,
    useBinding = function(p8) --[[ Name: useBinding, Line 137 ]]
        -- upvalues: l__ReactCurrentDispatcher__3 (copy), l__console__2 (copy)
        local l__current__9 = l__ReactCurrentDispatcher__3.current;
        if _G.__DEV__ and l__current__9 == nil then
            l__console__2.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.");
        end;
        return l__current__9.useBinding(p8);
    end,
    useEffect = function(p9, p10) --[[ Name: useEffect, Line 149 ]]
        -- upvalues: l__ReactCurrentDispatcher__3 (copy), l__console__2 (copy)
        local l__current__10 = l__ReactCurrentDispatcher__3.current;
        if _G.__DEV__ and l__current__10 == nil then
            l__console__2.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.");
        end;
        return l__current__10.useEffect(p9, p10);
    end,
    useLayoutEffect = function(p11, p12) --[[ Name: useLayoutEffect, Line 159 ]]
        -- upvalues: l__ReactCurrentDispatcher__3 (copy), l__console__2 (copy)
        local l__current__11 = l__ReactCurrentDispatcher__3.current;
        if _G.__DEV__ and l__current__11 == nil then
            l__console__2.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.");
        end;
        return l__current__11.useLayoutEffect(p11, p12);
    end,
    useCallback = function(p13, p14) --[[ Name: useCallback, Line 169 ]]
        -- upvalues: l__ReactCurrentDispatcher__3 (copy), l__console__2 (copy)
        local l__current__12 = l__ReactCurrentDispatcher__3.current;
        if _G.__DEV__ and l__current__12 == nil then
            l__console__2.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.");
        end;
        return l__current__12.useCallback(p13, p14);
    end,
    useMemo = function(p15, p16) --[[ Name: useMemo, Line 175 ]]
        -- upvalues: l__ReactCurrentDispatcher__3 (copy), l__console__2 (copy)
        local l__current__13 = l__ReactCurrentDispatcher__3.current;
        if _G.__DEV__ and l__current__13 == nil then
            l__console__2.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.");
        end;
        return l__current__13.useMemo(p15, p16);
    end,
    useImperativeHandle = function(p17, p18, p19) --[[ Name: useImperativeHandle, Line 181 ]]
        -- upvalues: l__ReactCurrentDispatcher__3 (copy), l__console__2 (copy)
        local l__current__14 = l__ReactCurrentDispatcher__3.current;
        if _G.__DEV__ and l__current__14 == nil then
            l__console__2.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.");
        end;
        return l__current__14.useImperativeHandle(p17, p18, p19);
    end,
    useDebugValue = function(p20, p21) --[[ Name: useDebugValue, Line 191 ]]
        -- upvalues: l__ReactCurrentDispatcher__3 (copy), l__console__2 (copy)
        if not _G.__DEV__ then
            return nil;
        end;
        local l__current__15 = l__ReactCurrentDispatcher__3.current;
        if _G.__DEV__ and l__current__15 == nil then
            l__console__2.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.");
        end;
        return l__current__15.useDebugValue(p20, p21);
    end,
    emptyObject = {},
    useOpaqueIdentifier = function() --[[ Line: 216 ]]
        -- upvalues: l__ReactCurrentDispatcher__3 (copy), l__console__2 (copy)
        local l__current__16 = l__ReactCurrentDispatcher__3.current;
        if _G.__DEV__ and l__current__16 == nil then
            l__console__2.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.");
        end;
        return l__current__16.useOpaqueIdentifier();
    end,
    useMutableSource = function(p22, p23, p24) --[[ Line: 222 ]]
        -- upvalues: l__ReactCurrentDispatcher__3 (copy), l__console__2 (copy)
        local l__current__17 = l__ReactCurrentDispatcher__3.current;
        if _G.__DEV__ and l__current__17 == nil then
            l__console__2.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.");
        end;
        return l__current__17.useMutableSource(p22, p23, p24);
    end
};