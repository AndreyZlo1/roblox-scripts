-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react@17.1.0.react.None.roblox
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent.Parent:WaitForChild("luau-polyfill")).Object.None;