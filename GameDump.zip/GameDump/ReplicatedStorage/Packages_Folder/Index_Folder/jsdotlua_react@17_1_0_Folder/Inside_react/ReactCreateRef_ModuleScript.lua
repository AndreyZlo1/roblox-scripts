-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react@17.1.0.react.ReactCreateRef
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent:WaitForChild("shared"));
local u1 = require(script.Parent:WaitForChild("ReactBinding.roblox"));
return {
    createRef = function() --[[ Line: 24 ]]
        -- upvalues: u1 (copy)
        local u2, _ = u1.create(nil);
        local v3 = {};
        if _G.__DEV__ then
            u2._source = debug.traceback("Ref created at:", 1);
        end;
        setmetatable(v3, {
            __index = function(_, p4) --[[ Name: __index, Line 42 ]]
                -- upvalues: u2 (copy)
                if p4 == "current" then
                    return u2:getValue();
                else
                    return u2[p4];
                end;
            end,
            __newindex = function(_, p5, p6) --[[ Name: __newindex, Line 49 ]]
                -- upvalues: u1 (ref), u2 (copy)
                if p5 == "current" then
                    u1.update(u2, p6);
                end;
                u2[p5] = p6;
            end,
            __tostring = function(_) --[[ Name: __tostring, Line 60 ]]
                -- upvalues: u2 (copy)
                return string.format("Ref(%s)", (tostring(u2:getValue())));
            end
        });
        return v3;
    end
};