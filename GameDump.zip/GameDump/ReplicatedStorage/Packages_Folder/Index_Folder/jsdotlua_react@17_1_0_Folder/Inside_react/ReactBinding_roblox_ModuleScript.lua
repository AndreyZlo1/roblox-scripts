-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react@17.1.0.react.ReactBinding.roblox
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local l__ReactSymbols__1 = require(script.Parent.Parent:WaitForChild("shared")).ReactSymbols;
require(script.Parent.Parent:WaitForChild("shared"));
local l__Symbol__2 = v1.Symbol;
local u2 = require(script.Parent:WaitForChild("createSignal.roblox"));
local u3 = l__Symbol__2("BindingImpl");
local u4 = {};
local u9 = {
    __index = {
        getValue = function(p5) --[[ Name: getValue, Line 45 ]]
            -- upvalues: u4 (copy)
            return u4.getValue(p5);
        end,
        map = function(p6, p7) --[[ Name: map, Line 49 ]]
            -- upvalues: u4 (copy)
            return u4.map(p6, p7);
        end
    },
    __tostring = function(p8) --[[ Name: __tostring, Line 58 ]]
        return string.format("RoactBinding(%s)", (tostring(p8:getValue())));
    end
};
function u4.update(p10, p11) --[[ Line: 63 ]]
    -- upvalues: u3 (copy)
    return p10[u3].update(p11);
end;
function u4.subscribe(p12, p13) --[[ Line: 67 ]]
    -- upvalues: u3 (copy)
    return p12[u3].subscribe(p13);
end;
function u4.getValue(p14) --[[ Line: 71 ]]
    -- upvalues: u3 (copy)
    return p14[u3]:getValue();
end;
function u4.create(p15) --[[ Line: 75 ]]
    -- upvalues: u2 (copy), l__ReactSymbols__1 (copy), u3 (copy), u9 (copy)
    local v16, u17 = u2();
    local u18 = {
        value = p15,
        subscribe = v16
    };
    function u18.update(p19) --[[ Line: 82 ]]
        -- upvalues: u18 (copy), u17 (copy)
        u18.value = p19;
        u17(p19);
    end;
    function u18.getValue() --[[ Line: 87 ]]
        -- upvalues: u18 (copy)
        return u18.value;
    end;
    local v20;
    if _G.__DEV__ then
        v20 = debug.traceback("Binding created at:", 3);
    else
        v20 = nil;
    end;
    return setmetatable({
        ["$$typeof"] = l__ReactSymbols__1.REACT_BINDING_TYPE,
        [u3] = u18,
        _source = v20
    }, u9), u18.update;
end;
function u4.map(u21, u22) --[[ Line: 105 ]]
    -- upvalues: l__ReactSymbols__1 (copy), u4 (copy), u3 (copy), u9 (copy)
    if _G.__DEV__ then
        local v23;
        if typeof(u21) == "table" then
            v23 = u21["$$typeof"] == l__ReactSymbols__1.REACT_BINDING_TYPE;
        else
            v23 = false;
        end;
        assert(v23, "Expected `self` to be a binding");
        local v24 = typeof(u22) == "function";
        assert(v24, "Expected arg #1 to be a function");
    end;
    local v27 = {
        subscribe = function(u25) --[[ Name: subscribe, Line 121 ]]
            -- upvalues: u4 (ref), u21 (copy), u22 (copy)
            return u4.subscribe(u21, function(p26) --[[ Line: 122 ]]
                -- upvalues: u25 (copy), u22 (ref)
                u25(u22(p26));
            end);
        end,
        update = function(_) --[[ Name: update, Line 127 ]]
            error("Bindings created by Binding:map(fn) cannot be updated directly", 2);
        end,
        getValue = function() --[[ Name: getValue, Line 131 ]]
            -- upvalues: u22 (copy), u21 (copy)
            return u22(u21:getValue());
        end
    };
    local v28;
    if _G.__DEV__ then
        v28 = debug.traceback("Mapped binding created at:", 3);
    else
        v28 = nil;
    end;
    return setmetatable({
        ["$$typeof"] = l__ReactSymbols__1.REACT_BINDING_TYPE,
        [u3] = v27,
        _source = v28
    }, u9);
end;
function u4.join(u29) --[[ Line: 152 ]]
    -- upvalues: l__ReactSymbols__1 (copy), u4 (copy), u3 (copy), u9 (copy)
    if _G.__DEV__ then
        local v30 = typeof(u29) == "table";
        assert(v30, "Expected arg #1 to be of type table");
        for v31, v32 in u29 do
            if typeof(v32) ~= "table" or v32["$$typeof"] ~= l__ReactSymbols__1.REACT_BINDING_TYPE then
                local v33 = ("Expected arg #1 to contain only bindings, but key %q had a non-binding value"):format((tostring(v31)));
                error(v33, 2);
            end;
        end;
    end;
    local v34 = {};
    local function u38() --[[ Line: 173 ]]
        -- upvalues: u29 (copy)
        local v35 = {};
        for v36, v37 in pairs(u29) do
            v35[v36] = v37:getValue();
        end;
        return v35;
    end;
    function v34.subscribe(u39) --[[ Line: 184 ]]
        -- upvalues: u29 (copy), u4 (ref), u38 (copy)
        local u40 = {};
        for v41, v42 in u29 do
            u40[v41] = u4.subscribe(v42, function(_) --[[ Line: 189 ]]
                -- upvalues: u39 (copy), u38 (ref)
                u39((u38()));
            end);
        end;
        return function() --[[ Line: 194 ]]
            -- upvalues: u40 (ref)
            if u40 == nil then
            else
                for _, v43 in u40 do
                    v43();
                end;
                u40 = nil;
            end;
        end;
    end;
    function v34.update(_) --[[ Line: 207 ]]
        error("Bindings created by joinBindings(...) cannot be updated directly", 2);
    end;
    function v34.getValue() --[[ Line: 211 ]]
        -- upvalues: u38 (copy)
        return u38();
    end;
    local v44;
    if _G.__DEV__ then
        v44 = debug.traceback("Joined binding created at:", 2);
    else
        v44 = nil;
    end;
    return setmetatable({
        ["$$typeof"] = l__ReactSymbols__1.REACT_BINDING_TYPE,
        [u3] = v34,
        _source = v44
    }, u9);
end;
return u4;