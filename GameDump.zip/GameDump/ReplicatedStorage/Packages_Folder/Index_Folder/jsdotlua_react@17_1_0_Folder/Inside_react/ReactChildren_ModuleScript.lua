-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react@17.1.0.react.ReactChildren
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent:WaitForChild("shared"));
local l__invariant__1 = require(script.Parent.Parent:WaitForChild("shared")).invariant;
local l__ReactSymbols__2 = require(script.Parent.Parent:WaitForChild("shared")).ReactSymbols;
local l__getIteratorFn__3 = l__ReactSymbols__2.getIteratorFn;
local l__REACT_ELEMENT_TYPE__4 = l__ReactSymbols__2.REACT_ELEMENT_TYPE;
local l__REACT_PORTAL_TYPE__5 = l__ReactSymbols__2.REACT_PORTAL_TYPE;
local l__Array__6 = require(script.Parent.Parent:WaitForChild("luau-polyfill")).Array;
local l__ReactElement__7 = require(script.Parent:WaitForChild("ReactElement"));
local l__isValidElement__8 = l__ReactElement__7.isValidElement;
local l__cloneAndReplaceKey__9 = l__ReactElement__7.cloneAndReplaceKey;
local function u30(p1, p2, p3, p4, p5) --[[ Line: 84 ]]
    -- upvalues: l__REACT_ELEMENT_TYPE__4 (copy), l__REACT_PORTAL_TYPE__5 (copy), l__Array__6 (copy), u30 (copy), l__isValidElement__8 (copy), l__cloneAndReplaceKey__9 (copy), l__getIteratorFn__3 (copy)
    local v6 = typeof(p1);
    if v6 == "nil" or (v6 == "boolean" or v6 == "userdata") then
        p1 = nil;
    end;
    local v7 = false;
    if p1 == nil or (v6 == "string" or v6 == "number") then
        v7 = true;
    elseif v6 == "table" then
        local v8 = p1["$$typeof"];
        v7 = (v8 == l__REACT_ELEMENT_TYPE__4 or v8 == l__REACT_PORTAL_TYPE__5) and true or v7;
    end;
    if v7 then
        local v9 = p5(p1);
        if p4 == "" then
            local v10 = ".";
            local v11;
            if typeof(p1) == "table" and (p1 ~= nil and p1.key ~= nil) then
                local v12 = tostring(p1.key);
                local v13 = string.gsub(v12, "=", "=0");
                v11 = "$" .. string.gsub(v13, ":", "=2");
            else
                v11 = tostring(1);
            end;
            p4 = v10 .. v11;
        end;
        if l__Array__6.isArray(v9) then
            u30(v9, p2, p4 == nil and "" or p4 .. "/", "", function(p14) --[[ Line: 133 ]]
                return p14;
            end);
        elseif v9 ~= nil then
            if l__isValidElement__8(v9) then
                local l__key__10 = v9.key;
                v9 = l__cloneAndReplaceKey__9(v9, p3 .. ((not l__key__10 or p1 and p1.key == l__key__10) and "" or tostring(l__key__10) .. "/") .. p4);
            end;
            table.insert(p2, v9);
        end;
        return 1;
    end;
    local v15 = 0;
    local v16 = p4 == "" and "." or p4 .. ":";
    if l__Array__6.isArray(p1) then
        for v17 = 1, #p1 do
            local v18 = p1[v17];
            local v19;
            if typeof(v18) == "table" and (v18 ~= nil and v18.key ~= nil) then
                local v20 = tostring(v18.key);
                local v21 = string.gsub(v20, "=", "=0");
                v19 = "$" .. string.gsub(v21, ":", "=2");
            else
                v19 = tostring(v17);
            end;
            v15 = v15 + u30(v18, p2, p3, v16 .. v19, p5);
        end;
        return v15;
    end;
    local v22 = l__getIteratorFn__3(p1);
    if typeof(v22) == "function" then
        local v23 = v22(p1);
        local v24 = v23.next();
        local v25 = 1;
        while not v24.done do
            local l__value__11 = v24.value;
            local v26;
            if typeof(l__value__11) == "table" and (l__value__11 ~= nil and l__value__11.key ~= nil) then
                local v27 = tostring(l__value__11.key);
                local v28 = string.gsub(v27, "=", "=0");
                v26 = "$" .. string.gsub(v28, ":", "=2");
            else
                v26 = tostring(v25);
            end;
            local v29 = v16 .. v26;
            v25 = v25 + 1;
            v15 = v15 + u30(l__value__11, p2, p3, v29, p5);
            v24 = v23.next();
        end;
    end;
    return v15;
end;
local function u37(p31, u32, _) --[[ Line: 251 ]]
    -- upvalues: u30 (copy)
    if p31 == nil then
        return nil;
    end;
    local v33 = {};
    local u34 = 1;
    u30(p31, v33, "", "", function(p35) --[[ Line: 261 ]]
        -- upvalues: u32 (copy), u34 (ref)
        local v36 = u32(p35, u34);
        u34 = u34 + 1;
        return v36;
    end);
    return v33;
end;
return {
    forEach = function(p38, u39, p40) --[[ Name: forEachChildren, Line 303 ]]
        -- upvalues: u37 (copy)
        u37(p38, function(...) --[[ Line: 308 ]]
            -- upvalues: u39 (copy)
            u39(...);
        end, p40);
    end,
    map = u37,
    count = function(p41) --[[ Name: countChildren, Line 279 ]]
        -- upvalues: u37 (copy)
        local u42 = 0;
        u37(p41, function() --[[ Line: 281 ]]
            -- upvalues: u42 (ref)
            u42 = u42 + 1;
        end);
        return u42;
    end,
    only = function(p43) --[[ Name: onlyChild, Line 343 ]]
        -- upvalues: l__invariant__1 (copy), l__isValidElement__8 (copy)
        l__invariant__1(l__isValidElement__8(p43), "React.Children.only expected to receive a single React element child.");
        return p43;
    end,
    toArray = function(p44) --[[ Name: toArray, Line 322 ]]
        -- upvalues: u37 (copy)
        return u37(p44, function(p45) --[[ Line: 323 ]]
            return p45;
        end) or {};
    end
};