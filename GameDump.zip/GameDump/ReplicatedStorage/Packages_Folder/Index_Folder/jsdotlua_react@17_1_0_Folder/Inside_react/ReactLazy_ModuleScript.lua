-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react@17.1.0.react.ReactLazy
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__console__1 = require(script.Parent.Parent:WaitForChild("shared")).console;
local l__inspect__2 = require(script.Parent.Parent:WaitForChild("luau-polyfill")).util.inspect;
require(script.Parent.Parent:WaitForChild("shared"));
local l__REACT_LAZY_TYPE__3 = require(script.Parent.Parent:WaitForChild("shared")).ReactSymbols.REACT_LAZY_TYPE;
function lazyInitializer(u1)
    -- upvalues: l__console__1 (copy), l__inspect__2 (copy)
    if u1._status == -1 then
        local v2 = u1._result();
        u1._status = 0;
        u1._result = v2;
        v2:andThen(function(p3) --[[ Line: 79 ]]
            -- upvalues: u1 (copy), l__console__1 (ref), l__inspect__2 (ref)
            if u1._status == 0 then
                local l__default__4 = p3.default;
                if _G.__DEV__ and l__default__4 == nil then
                    l__console__1.error("lazy: Expected the result of a dynamic import() call. Instead received: `%s`\n\nYour code should look like: \n  local MyComponent = lazy(function() return reqquire(script.Parent.MyComponent) end)", l__inspect__2(p3));
                end;
                local v4 = u1;
                v4._status = 1;
                v4._result = l__default__4;
            end;
        end, function(p5) --[[ Line: 100 ]]
            -- upvalues: u1 (copy)
            if u1._status == 0 then
                local v6 = u1;
                v6._status = 2;
                v6._result = p5;
            end;
        end);
    end;
    if u1._status == 1 then
        return u1._result;
    end;
    error(u1._result);
end;
return {
    lazy = function(p7) --[[ Line: 118 ]]
        -- upvalues: l__REACT_LAZY_TYPE__3 (copy), l__console__1 (copy)
        local v8 = {
            ["$$typeof"] = l__REACT_LAZY_TYPE__3,
            _payload = {
                _status = -1,
                _result = p7
            },
            _init = lazyInitializer
        };
        if _G.__DEV__ then
            local u9 = nil;
            local u10 = nil;
            setmetatable(v8, {
                __index = function(_, p11) --[[ Name: __index, Line 140 ]]
                    -- upvalues: u9 (ref), u10 (ref)
                    if p11 == "defaultProps" then
                        return u9;
                    end;
                    if p11 == "propTypes" then
                        return u10;
                    end;
                end,
                __newindex = function(p12, p13, p14) --[[ Name: __newindex, Line 149 ]]
                    -- upvalues: l__console__1 (ref), u9 (ref), u10 (ref)
                    if p13 == "defaultProps" then
                        l__console__1.error("React.lazy(...): It is not supported to assign `defaultProps` to a lazy component import. Either specify them where the component is defined, or create a wrapping component around it.");
                        u9 = p14;
                        setmetatable(p12, {
                            __index = function() --[[ Name: __index, Line 160 ]] end,
                            __newindex = function() --[[ Name: __newindex, Line 161 ]] end
                        });
                    end;
                    if p13 == "propTypes" then
                        l__console__1.error("React.lazy(...): It is not supported to assign `propTypes` to a lazy component import. Either specify them where the component is defined, or create a wrapping component around it.");
                        u10 = p14;
                        setmetatable(p12, {
                            __index = function() --[[ Name: __index, Line 174 ]] end,
                            __newindex = function() --[[ Name: __newindex, Line 175 ]] end
                        });
                    end;
                end
            });
        end;
        return v8;
    end
};