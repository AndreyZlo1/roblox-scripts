-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react@17.1.0.react.React
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local l__ReactMutableSource__1 = require(script.Parent:WaitForChild("ReactMutableSource"));
local l__ReactSharedInternals__2 = require(script.Parent.Parent:WaitForChild("shared")).ReactSharedInternals;
local l__ReactBaseClasses__3 = require(script.Parent:WaitForChild("ReactBaseClasses"));
local l__ReactChildren__4 = require(script.Parent:WaitForChild("ReactChildren"));
local l__ReactElementValidator__5 = require(script.Parent:WaitForChild("ReactElementValidator"));
local l__ReactElement__6 = require(script.Parent:WaitForChild("ReactElement"));
local l__ReactCreateRef__7 = require(script.Parent:WaitForChild("ReactCreateRef"));
local l__ReactForwardRef__8 = require(script.Parent:WaitForChild("ReactForwardRef"));
local l__ReactHooks__9 = require(script.Parent:WaitForChild("ReactHooks"));
local l__ReactMemo__10 = require(script.Parent:WaitForChild("ReactMemo"));
local l__ReactContext__11 = require(script.Parent:WaitForChild("ReactContext"));
local l__ReactLazy__12 = require(script.Parent:WaitForChild("ReactLazy"));
local v1 = require(script.Parent:WaitForChild("ReactBinding.roblox"));
local v2 = require(script.Parent:WaitForChild("None.roblox"));
local l__ReactSymbols__13 = require(script.Parent.Parent:WaitForChild("shared")).ReactSymbols;
local v3 = _G.__DEV__ or _G.__DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION__;
require(script.Parent.Parent:WaitForChild("shared"));
local v4;
if v3 then
    v4 = l__ReactElementValidator__5.createElementWithValidation;
else
    v4 = l__ReactElement__6.createElement;
end;
local v5;
if v3 then
    v5 = l__ReactElementValidator__5.cloneElementWithValidation;
else
    v5 = l__ReactElement__6.cloneElement;
end;
return {
    Children = l__ReactChildren__4,
    createMutableSource = l__ReactMutableSource__1,
    createRef = l__ReactCreateRef__7.createRef,
    Component = l__ReactBaseClasses__3.Component,
    PureComponent = l__ReactBaseClasses__3.PureComponent,
    createContext = l__ReactContext__11.createContext,
    forwardRef = l__ReactForwardRef__8.forwardRef,
    lazy = l__ReactLazy__12.lazy,
    memo = l__ReactMemo__10.memo,
    useCallback = l__ReactHooks__9.useCallback,
    useContext = l__ReactHooks__9.useContext,
    useEffect = l__ReactHooks__9.useEffect,
    useImperativeHandle = l__ReactHooks__9.useImperativeHandle,
    useDebugValue = l__ReactHooks__9.useDebugValue,
    useLayoutEffect = l__ReactHooks__9.useLayoutEffect,
    useMemo = l__ReactHooks__9.useMemo,
    useMutableSource = l__ReactHooks__9.useMutableSource,
    useReducer = l__ReactHooks__9.useReducer,
    useRef = l__ReactHooks__9.useRef,
    useBinding = l__ReactHooks__9.useBinding,
    useState = l__ReactHooks__9.useState,
    Fragment = l__ReactSymbols__13.REACT_FRAGMENT_TYPE,
    Profiler = l__ReactSymbols__13.REACT_PROFILER_TYPE,
    StrictMode = l__ReactSymbols__13.REACT_STRICT_MODE_TYPE,
    unstable_DebugTracingMode = l__ReactSymbols__13.REACT_DEBUG_TRACING_MODE_TYPE,
    Suspense = l__ReactSymbols__13.REACT_SUSPENSE_TYPE,
    createElement = v4,
    cloneElement = v5,
    isValidElement = l__ReactElement__6.isValidElement,
    __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = l__ReactSharedInternals__2,
    unstable_LegacyHidden = l__ReactSymbols__13.REACT_LEGACY_HIDDEN_TYPE,
    createBinding = v1.create,
    joinBindings = v1.join,
    None = v2,
    __subscribeToBinding = v1.subscribe,
    Event = require(script.Parent.Parent:WaitForChild("shared")).Event,
    Change = require(script.Parent.Parent:WaitForChild("shared")).Change,
    Tag = require(script.Parent.Parent:WaitForChild("shared")).Tag,
    unstable_parseReactError = require(script.Parent.Parent:WaitForChild("shared")).parseReactError
};