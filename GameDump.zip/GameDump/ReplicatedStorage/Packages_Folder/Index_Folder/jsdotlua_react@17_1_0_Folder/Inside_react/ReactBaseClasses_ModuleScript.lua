-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react@17.1.0.react.ReactBaseClasses
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
local l____COMPAT_WARNINGS____2 = _G.__COMPAT_WARNINGS__;
local l__Object__3 = require(script.Parent.Parent:WaitForChild("luau-polyfill")).Object;
local l__console__4 = require(script.Parent.Parent:WaitForChild("shared")).console;
require(script.Parent.Parent:WaitForChild("shared"));
local l__ReactNoopUpdateQueue__5 = require(script.Parent:WaitForChild("ReactNoopUpdateQueue"));
local u1 = {};
if l____DEV____1 then
    l__Object__3.freeze(u1);
end;
local l__UninitializedState__6 = require(script.Parent.Parent:WaitForChild("shared")).UninitializedState;
local u2 = {
    didMount = "componentDidMount",
    shouldUpdate = "shouldComponentUpdate",
    willUpdate = "UNSAFE_componentWillUpdate",
    didUpdate = "componentDidUpdate",
    willUnmount = "componentWillUnmount"
};
local function v11(p3, p4, p5) --[[ Line: 94 ]]
    -- upvalues: u2 (copy), l__console__4 (copy), l____DEV____1 (copy), l____COMPAT_WARNINGS____2 (copy)
    if u2[p4] ~= nil then
        if p3[u2[p4]] == nil then
            if p4 == "willUpdate" and p3.componentWillUpdate then
                local l____componentName__7 = p3.__componentName;
                l__console__4.warn("%s already defined \'%s\', but it also defining the deprecated Roact method \'%s\'. %s should only implement one of these methods, preferably using the non-deprecated name.", l____componentName__7, "UNSAFE_componentWillUpdate", p4, l____componentName__7);
            else
                local l____componentName__8 = p3.__componentName;
                local v6 = u2[p4];
                if l____DEV____1 and l____COMPAT_WARNINGS____2 then
                    local v7, v8 = debug.info(3, "sln");
                    local l__warn__9 = l__console__4.warn;
                    local v9 = "%s is using method \'%s\', which is no longer supported and should be updated to \'%s\'\nFile: %s:%s";
                    local v10 = string.match(v7, "%.%u[%.%w]-$");
                    if v10 then
                        v7 = string.gsub(v10, "^%.", "");
                    end;
                    l__warn__9(v9, l____componentName__8, p4, v6, v7, (tostring(v8)));
                end;
            end;
        else
            local l____componentName__10 = p3.__componentName;
            l__console__4.warn("%s already defined \'%s\', but it also defining the deprecated Roact method \'%s\'. %s should only implement one of these methods, preferably using the non-deprecated name.", l____componentName__10, u2[p4], p4, l____componentName__10);
        end;
        p4 = u2[p4];
    end;
    rawset(p3, p4, p5);
end;
local v13 = setmetatable({
    __componentName = "Component"
}, {
    __newindex = v11,
    __index = {
        isReactComponent = true
    },
    __tostring = function(p12) --[[ Name: __tostring, Line 124 ]]
        return p12.__componentName;
    end
});
local u14 = _G.__TESTEZ_RUNNING_TEST__ and 0 or 900;
local u15 = table.create(u14);
local u16 = 1;
for _ = 1, u14 do
    table.insert(u15, {
        props = nil,
        context = nil,
        state = l__UninitializedState__6,
        __refs = u1,
        __updater = l__ReactNoopUpdateQueue__5
    });
end;
local function u21(p17, p18, p19) --[[ Line: 160 ]]
    -- upvalues: l____DEV____1 (copy), l__console__4 (copy), l__Object__3 (copy)
    if l____DEV____1 and p19 ~= nil then
        l__console__4.warn("Received a `callback` argument to `setState` during initialization of \"%s\". The callback behavior is not supported when using `setState` in `init`.\n\nConsider defining similar behavior in a `compontentDidMount` method instead.", p17.__componentName);
    end;
    local v20;
    if p18 then
        v20 = type(p18);
    else
        v20 = p18;
    end;
    if p18 == nil or v20 ~= "table" and v20 ~= "function" then
        error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
    end;
    local l__state__11 = p17.state;
    if v20 == "function" then
        p18 = p18(l__state__11, p17.props);
    end;
    p17.state = l__Object__3.assign({}, l__state__11, p18);
end;
function v13.extend(p22, p23) --[[ Line: 200 ]]
    -- upvalues: l____COMPAT_WARNINGS____2 (copy), l__console__4 (copy), u16 (ref), u14 (copy), u15 (copy), l__UninitializedState__6 (copy), u1 (copy), l__ReactNoopUpdateQueue__5 (copy), u21 (copy)
    if p23 == nil then
        if l____COMPAT_WARNINGS____2 then
            l__console__4.warn("Component:extend() accepting no arguments is deprecated, and will not be supported in a future version of Roact. Please provide an explicit name.");
            p23 = "";
        else
            p23 = "";
        end;
    elseif type(p23) ~= "string" then
        error("Component class name must be a string");
    end;
    local u24 = {
        init = nil,
        __componentName = p23,
        setState = p22.setState,
        forceUpdate = p22.forceUpdate
    };
    u24.__index = u24;
    function u24.__ctor(p25, p26, p27) --[[ Line: 234 ]]
        -- upvalues: u16 (ref), u14 (ref), u15 (ref), l__UninitializedState__6 (ref), u1 (ref), l__ReactNoopUpdateQueue__5 (ref), u24 (copy), u21 (ref)
        local v28;
        if u16 <= u14 then
            v28 = u15[u16];
            v28.props = p25;
            v28.context = p26;
            u15[u16] = nil;
            u16 = u16 + 1;
        else
            v28 = {
                props = p25,
                context = p26,
                state = l__UninitializedState__6,
                __refs = u1,
                __updater = p27 or l__ReactNoopUpdateQueue__5
            };
        end;
        local v29 = setmetatable(v28, u24);
        if u24.init and type(u24.init) == "function" then
            v29.setState = u21;
            u24.init(v29, p25, p26);
            v29.setState = nil;
        end;
        return v29;
    end;
    local v30 = getmetatable(p22);
    setmetatable(u24, v30);
    return u24;
end;
function v13.setState(p31, p32, p33) --[[ Line: 326 ]]
    if p32 ~= nil and (type(p32) ~= "table" and type(p32) ~= "function") then
        error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
    end;
    p31.__updater.enqueueSetState(p31, p32, p33, "setState");
end;
function v13.forceUpdate(p34, p35) --[[ Line: 355 ]]
    p34.__updater.enqueueForceUpdate(p34, p35, "forceUpdate");
end;
if l____DEV____1 then
    local v36 = {
        isMounted = { "isMounted", "Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks." },
        replaceState = { "replaceState", "Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)." }
    };
    for v37, _ in v36 do
        if v36[v37] ~= nil then
            local u38 = v36[v37];
            v13[v37] = function() --[[ Line: 380 ]]
                -- upvalues: l__console__4 (copy), u38 (copy)
                l__console__4.warn("%s(...) is deprecated in plain JavaScript React classes. %s", u38[1], u38[2]);
                return nil;
            end;
        end;
    end;
end;
local v39 = v13:extend("PureComponent");
v39.extend = v13.extend;
setmetatable(v39, {
    __newindex = v11,
    __index = {
        isReactComponent = true,
        isPureReactComponent = true
    },
    __tostring = function(p40) --[[ Name: __tostring, Line 427 ]]
        return p40.__componentName;
    end
});
return {
    Component = v13,
    PureComponent = v39
};