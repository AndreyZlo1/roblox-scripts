-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react@17.1.0.react.ReactMemo
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__shared__1 = require(script.Parent.Parent:WaitForChild("shared"));
local l__console__2 = l__shared__1.console;
local v1 = require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local l__Array__3 = v1.Array;
local l__Object__4 = v1.Object;
local l__inspect__5 = v1.util.inspect;
local l__ReactSymbols__6 = l__shared__1.ReactSymbols;
local l__REACT_MEMO_TYPE__7 = l__ReactSymbols__6.REACT_MEMO_TYPE;
local l__REACT_ELEMENT_TYPE__8 = l__ReactSymbols__6.REACT_ELEMENT_TYPE;
local l__isValidElementType__9 = l__shared__1.isValidElementType;
local l__getComponentName__10 = l__shared__1.getComponentName;
return {
    memo = function(u2, p3) --[[ Line: 36 ]]
        -- upvalues: l__isValidElementType__9 (copy), l__Object__4 (copy), l__Array__3 (copy), l__REACT_ELEMENT_TYPE__8 (copy), l__getComponentName__10 (copy), l__inspect__5 (copy), l__console__2 (copy), l__REACT_MEMO_TYPE__7 (copy)
        if _G.__DEV__ and not l__isValidElementType__9(u2) then
            local v4 = "";
            if u2 == nil or typeof(u2) == "table" and #l__Object__4.keys(u2) == 0 then
                v4 = v4 .. " You likely forgot to export your component from the file it\'s defined in, or you might have mixed up default and named imports.";
            end;
            local v5;
            if u2 == nil then
                v5 = "nil";
            elseif l__Array__3.isArray(u2) then
                v5 = "array";
            elseif u2 == nil or (typeof(u2) ~= "table" or u2["$$typeof"] ~= l__REACT_ELEMENT_TYPE__8) then
                v5 = typeof(u2);
                if u2 ~= nil then
                    v4 = "\n" .. l__inspect__5(u2);
                end;
            else
                v5 = string.format("<%s />", l__getComponentName__10(u2.type) or "UNKNOWN");
                v4 = " Did you accidentally export a JSX literal or Element instead of a component?";
            end;
            l__console__2.error("memo: The first argument must be a component. Instead received: `%s`.%s", v5, v4);
        end;
        local v6 = {
            ["$$typeof"] = l__REACT_MEMO_TYPE__7,
            type = u2,
            compare = p3 or nil
        };
        if _G.__DEV__ then
            local u7 = nil;
            setmetatable(v6, {
                __index = function(p8, p9) --[[ Name: __index, Line 101 ]]
                    -- upvalues: u7 (ref)
                    if p9 == "displayName" then
                        return u7;
                    else
                        return rawget(p8, p9);
                    end;
                end,
                __newindex = function(p10, p11, p12) --[[ Name: __newindex, Line 107 ]]
                    -- upvalues: u7 (ref), u2 (copy)
                    if p11 == "displayName" then
                        u7 = p12;
                        if typeof(u2) == "table" and u2.displayName == nil then
                            u2.displayName = u7;
                        end;
                    else
                        rawset(p10, p11, p12);
                    end;
                end
            });
        end;
        return v6;
    end
};