-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react@17.1.0.react.ReactNoopUpdateQueue
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__console__1 = require(script.Parent.Parent:WaitForChild("shared")).console;
local u1 = {};
return {
    isMounted = function(_) --[[ Name: isMounted, Line 49 ]]
        return false;
    end,
    enqueueForceUpdate = function(p2, _, _) --[[ Name: enqueueForceUpdate, Line 67 ]]
        -- upvalues: u1 (copy), l__console__1 (copy)
        if _G.__DEV__ then
            local v3 = p2.__componentName or "ReactClass";
            local v4 = v3 .. ".forceUpdate";
            if u1[v4] then
                return;
            end;
            l__console__1.error("Can\'t call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `self.state` directly with the desired state in the %s component\'s `init` method.", "forceUpdate", v3);
            u1[v4] = true;
        end;
    end,
    enqueueReplaceState = function(p5, _, _, _) --[[ Name: enqueueReplaceState, Line 83 ]]
        -- upvalues: u1 (copy), l__console__1 (copy)
        if _G.__DEV__ then
            local v6 = p5.__componentName or "ReactClass";
            local v7 = v6 .. ".replaceState";
            if u1[v7] then
                return;
            end;
            l__console__1.error("Can\'t call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `self.state` directly with the desired state in the %s component\'s `init` method.", "replaceState", v6);
            u1[v7] = true;
        end;
    end,
    enqueueSetState = function(p8, _, _, _) --[[ Name: enqueueSetState, Line 98 ]]
        -- upvalues: u1 (copy), l__console__1 (copy)
        if _G.__DEV__ then
            local v9 = p8.__componentName or "ReactClass";
            local v10 = v9 .. ".setState";
            if u1[v10] then
                return;
            end;
            l__console__1.error("Can\'t call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `self.state` directly with the desired state in the %s component\'s `init` method.", "setState", v9);
            u1[v10] = true;
        end;
    end
};