-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react@17.1.0.shared
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent.Parent["jsdotlua_shared@17.1.0"].shared);