-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react@17.1.0.react
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent:WaitForChild("luau-polyfill"));
local l__React__1 = require(script:WaitForChild("React"));
require(script:WaitForChild("ReactLazy"));
require(script.Parent:WaitForChild("shared"));
return l__React__1;