-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_instance-of@1.2.7.instance-of
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script:WaitForChild("instanceof"));