-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.ExecutionEnvironment
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    canUseDOM = function() --[[ Line: 13 ]]
        return false;
    end
};