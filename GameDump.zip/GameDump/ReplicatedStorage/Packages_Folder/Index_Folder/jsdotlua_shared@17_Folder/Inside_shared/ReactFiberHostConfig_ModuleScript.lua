-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.ReactFiberHostConfig
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    WithNoHydration = require(script:WaitForChild("WithNoHydration")),
    WithNoPersistence = require(script:WaitForChild("WithNoPersistence")),
    WithNoTestSelectors = require(script:WaitForChild("WithNoTestSelectors"))
};