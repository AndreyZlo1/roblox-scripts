-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.PropMarkers.Tag
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent.Parent:WaitForChild("Symbol.roblox")).named("RobloxTag");