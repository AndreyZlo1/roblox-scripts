-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.ErrorHandling.roblox
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local l__Error__1 = u1.Error;
local l__inspect__2 = u1.util.inspect;
return {
    __ERROR_DIVIDER = "\n------ Error caught by React ------\n",
    describeError = function(p2) --[[ Name: describeError, Line 33 ]]
        -- upvalues: u1 (copy)
        if typeof(p2) ~= "string" then
            return p2;
        end;
        local _, v3 = string.find(p2, ":[%d]+: ");
        if v3 then
            p2 = string.sub(p2, v3 + 1);
        end;
        local v4 = u1.Error.new(p2);
        v4.stack = debug.traceback(nil, 2);
        return v4;
    end,
    errorToString = function(p5) --[[ Name: errorToString, Line 53 ]]
        -- upvalues: l__inspect__2 (copy)
        if typeof(p5) == "table" then
            if p5.message and p5.stack then
                return "\n------ Error caught by React ------\n" .. p5.message .. "\n------ Error caught by React ------\n" .. tostring(p5.stack);
            else
                return l__inspect__2(p5);
            end;
        else
            return l__inspect__2(p5);
        end;
    end,
    parseReactError = function(p6) --[[ Name: parseReactError, Line 79 ]]
        -- upvalues: l__Error__1 (copy)
        local v7 = string.split(p6, "\n------ Error caught by React ------\n");
        if #v7 ~= 3 then
            local v8 = l__Error__1.new(p6);
            v8.stack = nil;
            return v8, "";
        end;
        local v9, v10, v11 = table.unpack(v7);
        local v12 = l__Error__1.new(v10);
        v12.stack = v11;
        return v12, v9;
    end
};