-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.formatProdErrorMessage
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__HttpService__1 = game:GetService("HttpService");
return function(p1, ...) --[[ Name: formatProdErrorMessage, Line 17 ]]
    -- upvalues: l__HttpService__1 (copy)
    local v2 = "https://reactjs.org/docs/error-decoder.html?invariant=" .. tostring(p1);
    for v3 = 1, select("#", ...) do
        v2 = v2 .. "&args[]=" .. l__HttpService__1:UrlEncode(select(v3, ...));
    end;
    return string.format("Minified React error #%d; visit %s for the full message or use the non-minified dev environment for full errors and additional helpful warnings.", p1, v2);
end;