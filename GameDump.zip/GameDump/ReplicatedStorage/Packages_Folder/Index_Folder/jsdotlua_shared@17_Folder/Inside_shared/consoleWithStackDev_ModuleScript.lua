-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.consoleWithStackDev
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local l__console__1 = v1.console;
local l__Array__2 = v1.Array;
local l__ReactSharedInternals__3 = require(script.Parent:WaitForChild("ReactSharedInternals"));
local u2 = nil;
local v5 = {
    warn = function(p3, ...) --[[ Line: 24 ]]
        -- upvalues: u2 (ref)
        if _G.__DEV__ then
            u2("warn", p3, { ... });
        end;
    end,
    error = function(p4, ...) --[[ Line: 29 ]]
        -- upvalues: u2 (ref)
        if _G.__DEV__ then
            u2("error", p4, { ... });
        end;
    end
};
u2 = function(p6, p7, p8) --[[ Name: printWarning, Line 35 ]]
    -- upvalues: l__ReactSharedInternals__3 (copy), l__Array__2 (copy), l__console__1 (copy)
    if _G.__DEV__ then
        local v9 = l__ReactSharedInternals__3.ReactDebugCurrentFrame.getStackAddendum();
        if v9 ~= "" then
            p7 = p7 .. "%s";
            p8 = l__Array__2.slice(p8, 1);
            table.insert(p8, v9);
        end;
        local v10 = l__Array__2.map(p8, tostring);
        table.insert(v10, 1, "Warning: " .. p7);
        l__console__1[p6](unpack(v10));
    end;
end;
return v5;