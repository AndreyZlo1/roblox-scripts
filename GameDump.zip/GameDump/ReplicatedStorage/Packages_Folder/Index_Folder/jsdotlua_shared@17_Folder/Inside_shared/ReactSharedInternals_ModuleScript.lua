-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.ReactSharedInternals
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local _ = require(script.Parent.Parent:WaitForChild("luau-polyfill")).console;
local l__ReactCurrentDispatcher__1 = require(script:WaitForChild("ReactCurrentDispatcher"));
local l__ReactCurrentBatchConfig__2 = require(script:WaitForChild("ReactCurrentBatchConfig"));
local l__ReactCurrentOwner__3 = require(script:WaitForChild("ReactCurrentOwner"));
local l__ReactDebugCurrentFrame__4 = require(script:WaitForChild("ReactDebugCurrentFrame"));
return {
    ReactCurrentDispatcher = l__ReactCurrentDispatcher__1,
    ReactCurrentBatchConfig = l__ReactCurrentBatchConfig__2,
    ReactCurrentOwner = l__ReactCurrentOwner__3,
    IsSomeRendererActing = require(script:WaitForChild("IsSomeRendererActing")),
    ReactDebugCurrentFrame = not _G.__DEV__ and {
        setExtraStackFrame = function(_) --[[ Name: setExtraStackFrame, Line 50 ]] end
    } or l__ReactDebugCurrentFrame__4
};