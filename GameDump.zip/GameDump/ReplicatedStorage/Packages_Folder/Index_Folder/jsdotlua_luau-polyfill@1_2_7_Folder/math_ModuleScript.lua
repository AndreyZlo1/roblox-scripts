-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_luau-polyfill@1.2.7.math
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent.Parent["jsdotlua_math@1.2.7"].math);