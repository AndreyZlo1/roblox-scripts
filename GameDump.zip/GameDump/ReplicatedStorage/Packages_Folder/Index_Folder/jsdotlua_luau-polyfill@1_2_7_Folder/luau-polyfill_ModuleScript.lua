-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_luau-polyfill@1.2.7.luau-polyfill
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__boolean__1 = require(script.Parent:WaitForChild("boolean"));
local l__collections__2 = require(script.Parent:WaitForChild("collections"));
local l__console__3 = require(script.Parent:WaitForChild("console"));
local l__math__4 = require(script.Parent:WaitForChild("math"));
local l__number__5 = require(script.Parent:WaitForChild("number"));
local l__string__6 = require(script.Parent:WaitForChild("string"));
local v1 = require(script.Parent:WaitForChild("symbol-luau"));
local l__timers__7 = require(script.Parent:WaitForChild("timers"));
require(script.Parent:WaitForChild("es7-types"));
local l__AssertionError__8 = require(script:WaitForChild("AssertionError"));
local l__Error__9 = require(script:WaitForChild("Error"));
require(script:WaitForChild("Promise"));
local l__extends__10 = require(script:WaitForChild("extends"));
local v2 = require(script.Parent:WaitForChild("instance-of"));
return {
    Array = l__collections__2.Array,
    AssertionError = l__AssertionError__8,
    Boolean = l__boolean__1,
    console = l__console__3,
    Error = l__Error__9,
    extends = l__extends__10,
    instanceof = v2,
    Math = l__math__4,
    Number = l__number__5,
    Object = l__collections__2.Object,
    Map = l__collections__2.Map,
    coerceToMap = l__collections__2.coerceToMap,
    coerceToTable = l__collections__2.coerceToTable,
    Set = l__collections__2.Set,
    WeakMap = l__collections__2.WeakMap,
    String = l__string__6,
    Symbol = v1,
    setTimeout = l__timers__7.setTimeout,
    clearTimeout = l__timers__7.clearTimeout,
    setInterval = l__timers__7.setInterval,
    clearInterval = l__timers__7.clearInterval,
    util = {
        inspect = l__collections__2.inspect
    }
};