-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.PropMarkers.Change
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = require(script.Parent.Parent:WaitForChild("Type.roblox"));
local u2 = {};
local u4 = {
    __tostring = function(p3) --[[ Name: __tostring, Line 33 ]]
        return string.format("RoactHostChangeEvent(%s)", p3.name);
    end
};
setmetatable(u2, {
    __index = function(_, p5) --[[ Name: __index, Line 39 ]]
        -- upvalues: u1 (copy), u4 (copy), u2 (copy)
        local v6 = {
            [u1] = u1.HostChangeEvent,
            name = p5
        };
        setmetatable(v6, u4);
        u2[p5] = v6;
        return v6;
    end
});
return u2;