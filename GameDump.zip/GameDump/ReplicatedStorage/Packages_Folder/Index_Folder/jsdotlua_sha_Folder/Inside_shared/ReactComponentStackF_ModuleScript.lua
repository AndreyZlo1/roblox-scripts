-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.ReactComponentStackFrame
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent:WaitForChild("ReactElementType"));
require(script.Parent:WaitForChild("flowtypes.roblox"));
local l__ReactSymbols__1 = require(script.Parent:WaitForChild("ReactSymbols"));
local l__REACT_SUSPENSE_TYPE__2 = l__ReactSymbols__1.REACT_SUSPENSE_TYPE;
local l__REACT_SUSPENSE_LIST_TYPE__3 = l__ReactSymbols__1.REACT_SUSPENSE_LIST_TYPE;
local l__REACT_FORWARD_REF_TYPE__4 = l__ReactSymbols__1.REACT_FORWARD_REF_TYPE;
local l__REACT_MEMO_TYPE__5 = l__ReactSymbols__1.REACT_MEMO_TYPE;
local l__REACT_BLOCK_TYPE__6 = l__ReactSymbols__1.REACT_BLOCK_TYPE;
local l__REACT_LAZY_TYPE__7 = l__ReactSymbols__1.REACT_LAZY_TYPE;
local v1 = require(script.Parent:WaitForChild("ConsolePatchingDev.roblox"));
local l__disableLogs__8 = v1.disableLogs;
local l__reenableLogs__9 = v1.reenableLogs;
local l__ReactCurrentDispatcher__10 = require(script.Parent:WaitForChild("ReactSharedInternals")).ReactCurrentDispatcher;
local u2 = nil;
local function u7(p3, p4, p5) --[[ Line: 66 ]]
    -- upvalues: u2 (ref)
    local v6;
    if _G.__DEV__ and p5 then
        if type(p5) == "function" then
            v6 = debug.info(p5, "n");
        elseif type(p5) == "table" then
            v6 = tostring(p5);
        else
            v6 = nil;
        end;
    else
        v6 = nil;
    end;
    return u2(p3, p4, v6);
end;
local u8 = false;
local u9;
if _G.__DEV__ then
    u9 = setmetatable({}, {
        __mode = "k"
    });
else
    u9 = nil;
end;
local function v26(u10, u11) --[[ Line: 113 ]]
    -- upvalues: u8 (ref), u9 (ref), l__ReactCurrentDispatcher__10 (copy), l__disableLogs__8 (copy), l__reenableLogs__9 (copy), u2 (ref)
    if not u10 or u8 then
        return "";
    end;
    if _G.__DEV__ then
        local v12 = u9[u10];
        if v12 ~= nil then
            return v12;
        end;
    end;
    local u13 = nil;
    u8 = true;
    local v14;
    if _G.__DEV__ then
        v14 = l__ReactCurrentDispatcher__10.current;
        l__ReactCurrentDispatcher__10.current = nil;
        l__disableLogs__8();
    else
        v14 = nil;
    end;
    local u15 = nil;
    local _, v18 = xpcall(function() --[[ Line: 153 ]]
        -- upvalues: u11 (copy), u15 (ref), u13 (ref), u10 (copy)
        if u11 then
        else
            local _, v16 = pcall(function() --[[ Line: 159 ]]
                -- upvalues: u15 (ref)
                u15 = debug.traceback();
                error({
                    stack = u15
                });
            end);
            u13 = v16;
            u10();
        end;
    end, function(p17) --[[ Line: 169 ]]
        -- upvalues: u15 (ref)
        return {
            message = p17,
            stack = u15
        };
    end);
    local v19 = nil;
    if v18 and (u13 and type(v18.stack) == "string") then
        local v20 = string.split(v18.stack, "\n");
        local v21 = string.split(u13.stack, "\n");
        local v22 = #v20 - 1;
        local v23 = #v21 - 1;
        while v22 >= 2 and (v23 >= 0 and v20[v22] ~= v21[v23]) do
            v23 = v23 - 1;
        end;
        while v22 >= 3 and v23 >= 1 do
            v22 = v22 - 1;
            v23 = v23 - 1;
            if v20[v22] ~= v21[v23] then
                if v22 == 1 and v23 == 1 then
                    break;
                end;
                while true do
                    v22 = v22 - 1;
                    v23 = v23 - 1;
                    if v23 < 0 or v20[v22] ~= v21[v23] then
                        v19 = "\n" .. "    in " .. v20[v22];
                        if _G.__DEV__ then
                            u9[u10] = v19;
                        end;
                    end;
                    if v22 < 3 or v23 < 1 then
                        break;
                    end;
                end;
            end;
        end;
    end;
    u8 = false;
    if _G.__DEV__ then
        l__ReactCurrentDispatcher__10.current = v14;
        l__reenableLogs__9();
    end;
    if v19 ~= nil then
        return v19;
    end;
    local v24;
    if type(u10) == "function" then
        v24 = debug.info(u10, "n");
    else
        v24 = type(u10) ~= "table" and "" or tostring(u10);
    end;
    local v25;
    if v24 == nil or v24 == "" then
        v25 = "";
    else
        local _ = _G.__DEV__;
        v25 = u2(v24, nil, nil);
    end;
    if _G.__DEV__ then
        u9[u10] = v25;
    end;
    return v25;
end;
u2 = function(p27, p28, p29) --[[ Name: describeComponentFrame, Line 283 ]]
    local v30 = "";
    if _G.__DEV__ and p28 then
        local l__fileName__11 = p28.fileName;
        local v31 = string.gsub(l__fileName__11, "^(.*)[\\/]", "");
        if string.match(v31, "^init%.") then
            local v32 = string.match(l__fileName__11, "^(.*)[\\/]");
            if v32 and #v32 ~= 0 then
                v31 = string.gsub(v32, "^(.*)[\\/]", "") .. "/" .. v31;
            end;
        end;
        v30 = " (at " .. v31 .. ":" .. p28.lineNumber .. ")";
    elseif p29 then
        v30 = " (created by " .. p29 .. ")";
    end;
    return "\n    in " .. (p27 or "Unknown") .. v30;
end;
local function u38(p33, p34, p35) --[[ Line: 316 ]]
    -- upvalues: u2 (ref)
    local v36 = tostring(p33);
    local v37;
    if _G.__DEV__ and p35 then
        if type(p35) == "function" then
            v37 = debug.info(p35, "n");
        elseif type(p35) == "table" then
            v37 = tostring(p35);
        else
            v37 = nil;
        end;
    else
        v37 = nil;
    end;
    return u2(v36, p34, v37);
end;
local function u44(p39, p40, p41) --[[ Line: 340 ]]
    -- upvalues: u2 (ref)
    if not p39 then
        return "";
    end;
    local v42;
    if type(p39) == "function" then
        v42 = debug.info(p39, "n");
    else
        v42 = tostring(p39);
    end;
    local v43;
    if _G.__DEV__ and p41 then
        if type(p41) == "function" then
            v43 = debug.info(p41, "n");
        elseif type(p41) == "table" then
            v43 = tostring(p41);
        else
            v43 = nil;
        end;
    else
        v43 = nil;
    end;
    return u2(v42, p40, v43);
end;
local function u51(p45, u46, u47) --[[ Line: 387 ]]
    -- upvalues: u38 (copy), u44 (ref), u7 (copy), l__REACT_SUSPENSE_TYPE__2 (copy), l__REACT_SUSPENSE_LIST_TYPE__3 (copy), l__REACT_FORWARD_REF_TYPE__4 (copy), l__REACT_MEMO_TYPE__5 (copy), u51 (copy), l__REACT_BLOCK_TYPE__6 (copy), l__REACT_LAZY_TYPE__7 (copy)
    if not _G.__DEV__ then
        return "";
    end;
    if p45 == nil then
        return "";
    end;
    if type(p45) == "table" and type(p45.__ctor) == "function" then
        return u38(p45, u46, u47);
    end;
    if type(p45) == "function" then
        return u44(p45, u46, u47);
    end;
    if type(p45) == "string" then
        return u7(p45, u46, u47);
    end;
    if p45 == l__REACT_SUSPENSE_TYPE__2 then
        return u7("Suspense", u46, u47);
    end;
    if p45 == l__REACT_SUSPENSE_LIST_TYPE__3 then
        return u7("SuspenseList", u46, u47);
    end;
    if type(p45) == "table" then
        local v48 = p45["$$typeof"];
        if v48 == l__REACT_FORWARD_REF_TYPE__4 then
            return u44(p45.render, u46, u47);
        end;
        if v48 == l__REACT_MEMO_TYPE__5 then
            return u51(p45.type, u46, u47);
        end;
        if v48 == l__REACT_BLOCK_TYPE__6 then
            return u44(p45._render, u46, u47);
        end;
        if v48 == l__REACT_LAZY_TYPE__7 then
            local l___payload__12 = p45._payload;
            local l___init__13 = p45._init;
            local v49, v50 = pcall(function() --[[ Line: 446 ]]
                -- upvalues: u51 (ref), l___init__13 (copy), l___payload__12 (copy), u46 (copy), u47 (copy)
                u51(l___init__13(l___payload__12), u46, u47);
            end);
            if v49 then
                return v50;
            end;
        end;
    end;
    return "";
end;
return {
    describeComponentFrame = u2,
    describeBuiltInComponentFrame = u7,
    describeNativeComponentFrame = v26,
    describeClassComponentFrame = u38,
    describeFunctionComponentFrame = u44,
    describeUnknownElementTypeFrameInDEV = u51
};