-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.UninitializedState.roblox
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__console__1 = require(script.Parent:WaitForChild("console"));
local v1 = {};
setmetatable(v1, {
    __metatable = "UninitializedState",
    __index = function(_, _) --[[ Name: __index, Line 23 ]]
        -- upvalues: l__console__1 (copy)
        if _G.__DEV__ then
            l__console__1.warn("Attempted to access uninitialized state. Use setState to initialize state");
        end;
        return nil;
    end,
    __newindex = function(_, _) --[[ Name: __newindex, Line 31 ]]
        -- upvalues: l__console__1 (copy)
        if _G.__DEV__ then
            l__console__1.error("Attempted to directly mutate state. Use setState to assign new values to state.");
        end;
        return nil;
    end,
    __tostring = function(_) --[[ Name: __tostring, Line 39 ]]
        return "<uninitialized component state>";
    end
});
return v1;