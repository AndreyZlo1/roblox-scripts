-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.ConsolePatchingDev.roblox
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__console__1 = require(script.Parent:WaitForChild("console"));
local u1 = 0;
local u2 = nil;
local u3 = nil;
local u4 = nil;
local u5 = nil;
local u6 = nil;
local u7 = nil;
local u8 = nil;
local function u9() --[[ Line: 31 ]] end;
return {
    disabledLog = u9,
    disableLogs = function() --[[ Line: 40 ]]
        -- upvalues: u1 (ref), u2 (ref), l__console__1 (copy), u3 (ref), u4 (ref), u5 (ref), u6 (ref), u7 (ref), u8 (ref), u9 (copy)
        if _G.__DEV__ then
            if u1 == 0 then
                u2 = l__console__1.log;
                u3 = l__console__1.info;
                u4 = l__console__1.warn;
                u5 = l__console__1.error;
                u6 = l__console__1.group;
                u7 = l__console__1.groupCollapsed;
                u8 = l__console__1.groupEnd;
                l__console__1.info = u9;
                l__console__1.log = u9;
                l__console__1.warn = u9;
                l__console__1.error = u9;
                l__console__1.group = u9;
                l__console__1.groupCollapsed = u9;
                l__console__1.groupEnd = u9;
            end;
            u1 = u1 + 1;
        end;
    end,
    reenableLogs = function() --[[ Line: 64 ]]
        -- upvalues: u1 (ref), l__console__1 (copy), u2 (ref), u3 (ref), u4 (ref), u5 (ref), u6 (ref), u7 (ref), u8 (ref)
        if _G.__DEV__ then
            u1 = u1 - 1;
            if u1 == 0 then
                l__console__1.log = u2;
                l__console__1.info = u3;
                l__console__1.warn = u4;
                l__console__1.error = u5;
                l__console__1.group = u6;
                l__console__1.groupCollapsed = u7;
                l__console__1.groupEnd = u8;
            end;
            if u1 < 0 then
                l__console__1.error("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
            end;
        end;
    end
};