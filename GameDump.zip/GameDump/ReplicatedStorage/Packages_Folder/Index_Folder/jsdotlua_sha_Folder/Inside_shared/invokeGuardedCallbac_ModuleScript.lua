-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.invokeGuardedCallbackImpl
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__describeError__1 = require(script.Parent:WaitForChild("ErrorHandling.roblox")).describeError;
local _ = _G.__DEV__;
return function(p1, _, p2, p3, ...) --[[ Name: invokeGuardedCallbackProd, Line 15 ]]
    -- upvalues: l__describeError__1 (copy)
    local v4 = nil;
    local v5;
    if _G.__YOLO__ then
        v5 = true;
        if p3 == nil then
            p2(...);
        else
            p2(p3, ...);
        end;
    elseif p3 == nil then
        v5, v4 = xpcall(p2, l__describeError__1, ...);
    else
        v5, v4 = xpcall(p2, l__describeError__1, p3, ...);
    end;
    if not v5 then
        p1.onError(v4);
    end;
end;