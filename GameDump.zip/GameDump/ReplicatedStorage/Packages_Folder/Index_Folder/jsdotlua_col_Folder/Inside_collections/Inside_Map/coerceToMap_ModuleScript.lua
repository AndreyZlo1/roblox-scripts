-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Map.coerceToMap
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Map__1 = require(script.Parent:WaitForChild("Map"));
local l__Object__2 = require(script.Parent.Parent:WaitForChild("Object"));
local u1 = require(script.Parent.Parent.Parent:WaitForChild("instance-of"));
require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
return function(p2) --[[ Name: coerceToMap, Line 9 ]]
    -- upvalues: u1 (copy), l__Map__1 (copy), l__Object__2 (copy)
    return u1(p2, l__Map__1) and p2 and p2 or l__Map__1.new(l__Object__2.entries(p2));
end;