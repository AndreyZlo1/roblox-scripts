-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Object.assign
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__None__1 = require(script.Parent:WaitForChild("None"));
require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
return function(p1, p2, p3, p4, ...) --[[ Line: 12 ]]
    -- upvalues: l__None__1 (copy)
    if p2 ~= nil and typeof(p2) == "table" then
        for v5, v6 in pairs(p2) do
            if v6 == l__None__1 then
                p1[v5] = nil;
            else
                p1[v5] = v6;
            end;
        end;
    end;
    if p3 ~= nil and typeof(p3) == "table" then
        for v7, v8 in pairs(p3) do
            if v8 == l__None__1 then
                p1[v7] = nil;
            else
                p1[v7] = v8;
            end;
        end;
    end;
    if p4 ~= nil and typeof(p4) == "table" then
        for v9, v10 in pairs(p4) do
            if v10 == l__None__1 then
                p1[v9] = nil;
            else
                p1[v9] = v10;
            end;
        end;
    end;
    for v11 = 1, select("#", ...) do
        local v12 = select(v11, ...);
        if v12 ~= nil and typeof(v12) == "table" then
            for v13, v14 in pairs(v12) do
                if v14 == l__None__1 then
                    p1[v13] = nil;
                else
                    p1[v13] = v14;
                end;
            end;
        end;
    end;
    return p1;
end;