-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Object.None
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = newproxy(true);
getmetatable(v1).__tostring = function() --[[ Line: 6 ]]
    return "Object.None";
end;
return v1;