-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Object.isFrozen
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
return function(p1) --[[ Line: 7 ]]
    -- upvalues: l____DEV____1 (copy)
    if l____DEV____1 then
        print("Luau now has a direct table.isfrozen call that can save the overhead of this library function call");
    end;
    return table.isfrozen(p1);
end;