-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Object.entries
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
return function(p1) --[[ Line: 6 ]]
    assert(p1 ~= nil, "cannot get entries from a nil value");
    local v2 = typeof(p1);
    local v3 = {};
    if v2 == "table" then
        for v4, v5 in pairs(p1) do
            table.insert(v3, { v4, v5 });
        end;
        return v3;
    else
        if v2 == "string" then
            for v6 = 1, string.len(p1) do
                v3[v6] = { tostring(v6), (string.sub(p1, v6, v6)) };
            end;
        end;
        return v3;
    end;
end;