-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Object.keys
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Set__1 = require(script.Parent.Parent:WaitForChild("Set"));
require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
local u1 = require(script.Parent.Parent.Parent:WaitForChild("instance-of"));
return function(p2) --[[ Line: 8 ]]
    -- upvalues: u1 (copy), l__Set__1 (copy)
    if p2 == nil then
        error("cannot extract keys from a nil value");
    end;
    local v3 = typeof(p2);
    local v4 = nil;
    if v3 ~= "table" then
        if v3 == "string" then
            local v5 = p2:len();
            v4 = table.create(v5);
            for v6 = 1, v5 do
                v4[v6] = tostring(v6);
            end;
        end;
        return v4;
    end;
    local v7 = {};
    if u1(p2, l__Set__1) then
        return v7;
    end;
    for v8 in pairs(p2) do
        table.insert(v7, v8);
    end;
    return v7;
end;