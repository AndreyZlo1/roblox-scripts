-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Array.splice
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
return function(p1, p2, p3, ...) --[[ Line: 7 ]]
    if #p1 < p2 then
        for v4 = 1, select("#", ...) do
            local v5 = select(v4, ...);
            table.insert(p1, v5);
        end;
        return {};
    end;
    local v6 = #p1;
    if p2 < 1 then
        local v7 = v6 - math.abs(p2);
        p2 = math.max(v7, 1);
    end;
    local v8 = {};
    local v9 = p3 or v6;
    if v9 > 0 then
        local v10 = p2 + math.max(0, v9 - 1);
        for _ = p2, math.min(v6, v10) do
            local v11 = table.remove(p1, p2);
            table.insert(v8, v11);
        end;
    end;
    for v12 = select("#", ...), 1, -1 do
        local v13 = select(v12, ...);
        table.insert(p1, p2, v13);
    end;
    return v8;
end;