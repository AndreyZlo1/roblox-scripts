-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Array.flatMap
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
local l__flat__2 = require(script.Parent:WaitForChild("flat"));
local l__map__3 = require(script.Parent:WaitForChild("map"));
require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
return function(p1, p2, p3) --[[ Name: flatMap, Line 9 ]]
    -- upvalues: l____DEV____1 (copy), l__flat__2 (copy), l__map__3 (copy)
    if l____DEV____1 then
        if typeof(p1) ~= "table" then
            error(string.format("Array.flatMap called on %s", (typeof(p1))));
        end;
        if typeof(p2) ~= "function" then
            error("callback is not a function");
        end;
    end;
    return l__flat__2(l__map__3(p1, p2, p3));
end;