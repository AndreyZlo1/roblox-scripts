-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Array.concat
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
local l__isArray__2 = require(script.Parent:WaitForChild("isArray"));
require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
return function(p1, ...) --[[ Name: concat, Line 12 ]]
    -- upvalues: l__isArray__2 (copy), l____DEV____1 (copy)
    local v2 = 0;
    local v3, v4;
    if l__isArray__2(p1) then
        v3 = table.clone(p1);
        v4 = #p1;
    else
        v4 = v2 + 1;
        v3 = {
            [v4] = p1
        };
    end;
    for v5 = 1, select("#", ...) do
        local v6 = select(v5, ...);
        local v7 = typeof(v6);
        if v6 ~= nil then
            if v7 == "table" then
                if l____DEV____1 and not l__isArray__2(v6) then
                    error("Array.concat(...) only works with array-like tables but it received an object-like table.\nYou can avoid this error by wrapping the object-like table into an array. Example: `concat({1, 2}, {a = true})` should be `concat({1, 2}, { {a = true} }`");
                end;
                for v8 = 1, #v6 do
                    v4 = v4 + 1;
                    v3[v4] = v6[v8];
                end;
            else
                v4 = v4 + 1;
                v3[v4] = v6;
            end;
        end;
    end;
    return v3;
end;