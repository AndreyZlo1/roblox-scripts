-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Array.includes
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
local l__indexOf__1 = require(script.Parent:WaitForChild("indexOf"));
return function(p1, p2, p3) --[[ Line: 5 ]]
    -- upvalues: l__indexOf__1 (copy)
    return l__indexOf__1(p1, p2, p3) ~= -1;
end;