-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Array.reduce
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
return function(p1, p2, p3) --[[ Line: 9 ]]
    -- upvalues: l____DEV____1 (copy)
    if l____DEV____1 then
        if typeof(p1) ~= "table" then
            error(string.format("Array.reduce called on %s", (typeof(p1))));
        end;
        if typeof(p2) ~= "function" then
            error("callback is not a function");
        end;
    end;
    local v4 = #p1;
    local v5;
    if p3 == nil then
        v5 = 2;
        if v4 == 0 then
            error("reduce of empty array with no initial value");
        end;
        p3 = p1[1];
    else
        v5 = 1;
    end;
    for v6 = v5, v4 do
        p3 = p2(p3, p1[v6], v6, p1);
    end;
    return p3;
end;