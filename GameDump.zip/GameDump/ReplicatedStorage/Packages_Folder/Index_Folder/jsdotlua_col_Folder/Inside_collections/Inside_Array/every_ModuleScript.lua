-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Array.every
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
return function(p1, p2, p3) --[[ Line: 10 ]]
    -- upvalues: l____DEV____1 (copy)
    if l____DEV____1 then
        if typeof(p1) ~= "table" then
            error(string.format("Array.every called on %s", (typeof(p1))));
        end;
        if typeof(p2) ~= "function" then
            error("callback is not a function");
        end;
    end;
    local v4 = #p1;
    local v5 = 1;
    while v5 <= v4 do
        local v6 = p1[v5];
        if v6 ~= nil then
            local v7;
            if p3 == nil then
                v7 = p2(v6, v5, p1);
            else
                v7 = p2(p3, v6, v5, p1);
            end;
            if not v7 then
                return false;
            end;
        end;
        v5 = v5 + 1;
    end;
    return true;
end;