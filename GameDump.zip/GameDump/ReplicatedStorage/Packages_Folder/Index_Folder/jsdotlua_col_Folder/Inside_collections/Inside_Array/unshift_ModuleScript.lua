-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Array.unshift
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
local l__isArray__2 = require(script.Parent:WaitForChild("isArray"));
require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
return function(p1, ...) --[[ Line: 6 ]]
    -- upvalues: l____DEV____1 (copy), l__isArray__2 (copy)
    if l____DEV____1 and not l__isArray__2(p1) then
        error(string.format("Array.unshift called on non-array %s", (typeof(p1))));
    end;
    local v2 = select("#", ...);
    if v2 > 0 then
        for v3 = v2, 1, -1 do
            local v4 = select(v3, ...);
            table.insert(p1, 1, v4);
        end;
    end;
    return #p1;
end;