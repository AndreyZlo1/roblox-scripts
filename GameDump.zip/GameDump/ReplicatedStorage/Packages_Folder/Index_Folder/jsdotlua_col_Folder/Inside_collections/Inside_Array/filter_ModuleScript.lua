-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Array.filter
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
return function(p1, p2, p3) --[[ Line: 10 ]]
    -- upvalues: l____DEV____1 (copy)
    if l____DEV____1 then
        if typeof(p1) ~= "table" then
            error(string.format("Array.filter called on %s", (typeof(p1))));
        end;
        if typeof(p2) ~= "function" then
            error("callback is not a function");
        end;
    end;
    local v4 = #p1;
    local v5 = {};
    local v6 = 1;
    if p3 == nil then
        for v7 = 1, v4 do
            local v8 = p1[v7];
            if v8 ~= nil and p2(v8, v7, p1) then
                v5[v6] = v8;
                v6 = v6 + 1;
            end;
        end;
        return v5;
    else
        for v9 = 1, v4 do
            local v10 = p1[v9];
            if v10 ~= nil and p2(p3, v10, v9, p1) then
                v5[v6] = v10;
                v6 = v6 + 1;
            end;
        end;
        return v5;
    end;
end;