-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Array.shift
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
local l__isArray__2 = require(script.Parent:WaitForChild("isArray"));
require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
return function(p1) --[[ Line: 6 ]]
    -- upvalues: l____DEV____1 (copy), l__isArray__2 (copy)
    if l____DEV____1 and not l__isArray__2(p1) then
        error(string.format("Array.shift called on non-array %s", (typeof(p1))));
    end;
    if #p1 > 0 then
        return table.remove(p1, 1);
    else
        return nil;
    end;
end;