-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_symbol-luau@1.0.1.symbol-luau.Registry.global
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Symbol__1 = require(script.Parent:WaitForChild("Symbol"));
local u1 = {};
return {
    getOrInit = function(p2) --[[ Name: getOrInit, Line 6 ]]
        -- upvalues: u1 (ref), l__Symbol__1 (copy)
        if u1[p2] == nil then
            u1[p2] = l__Symbol__1.new(p2);
        end;
        return u1[p2];
    end,
    __clear = function() --[[ Name: __clear, Line 14 ]]
        -- upvalues: u1 (ref)
        u1 = {};
    end
};