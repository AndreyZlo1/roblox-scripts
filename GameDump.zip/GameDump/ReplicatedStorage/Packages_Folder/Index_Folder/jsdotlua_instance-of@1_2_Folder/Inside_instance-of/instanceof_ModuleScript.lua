-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_instance-of@1.2.7.instance-of.instanceof
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
return function(u1, u2) --[[ Name: instanceof, Line 5 ]]
    -- upvalues: l____DEV____1 (copy)
    if l____DEV____1 then
        local v3 = typeof(u2) == "table";
        assert(v3, "Received a non-table as the second argument for instanceof");
    end;
    if typeof(u1) ~= "table" then
        return false;
    end;
    local v5, v6 = pcall(function() --[[ Line: 14 ]]
        -- upvalues: u2 (copy), u1 (ref)
        local v4;
        if u2.new == nil then
            v4 = false;
        else
            v4 = u1.new == u2.new;
        end;
        return v4;
    end);
    if v5 and v6 then
        return true;
    end;
    local v7 = {
        [u1] = true
    };
    while u1 and typeof(u1) == "table" do
        u1 = getmetatable(u1);
        if typeof(u1) == "table" then
            u1 = u1.__index;
            if u1 == u2 then
                return true;
            end;
        end;
        if typeof(u1) == "table" then
            if v7[u1] then
                return false;
            end;
            v7[u1] = true;
        end;
    end;
    return false;
end;