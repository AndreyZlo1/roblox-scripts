-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_boolean@1.2.7.number
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent.Parent["jsdotlua_number@1.2.7"].number);