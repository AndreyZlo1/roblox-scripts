-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_boolean@1.2.7.boolean.toJSBoolean
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__number__1 = require(script.Parent.Parent:WaitForChild("number"));
return function(p1) --[[ Line: 4 ]]
    -- upvalues: l__number__1 (copy)
    local v2 = p1 and true or false;
    if v2 then
        if p1 == 0 or p1 == "" then
            v2 = false;
        else
            v2 = not l__number__1.isNaN(p1);
        end;
    end;
    return v2;
end;