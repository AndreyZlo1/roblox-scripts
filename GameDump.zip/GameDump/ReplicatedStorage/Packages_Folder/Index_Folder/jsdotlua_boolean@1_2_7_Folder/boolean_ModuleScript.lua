-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_boolean@1.2.7.boolean
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    toJSBoolean = require(script:WaitForChild("toJSBoolean"))
};