-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_timers@1.2.7.timers
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Object__1 = require(script.Parent:WaitForChild("collections")).Object;
local l__makeTimerImpl__2 = require(script:WaitForChild("makeTimerImpl"));
local l__makeIntervalImpl__3 = require(script:WaitForChild("makeIntervalImpl"));
return l__Object__1.assign({}, l__makeTimerImpl__2(task.delay), l__makeIntervalImpl__3(task.delay));