-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-reconciler@17.1.0.react-reconciler
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script:WaitForChild("ReactInternalTypes"));
require(script:WaitForChild("ReactRootTags"));
return function(p1) --[[ Name: initialize, Line 28 ]]
    local l__ReactFiberHostConfig__1 = require(script:WaitForChild("ReactFiberHostConfig"));
    for v2, v3 in p1 do
        l__ReactFiberHostConfig__1[v2] = v3;
    end;
    return require(script:WaitForChild("ReactFiberReconciler"));
end;