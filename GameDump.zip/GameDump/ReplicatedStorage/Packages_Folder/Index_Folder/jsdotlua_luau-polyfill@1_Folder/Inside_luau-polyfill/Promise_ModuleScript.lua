-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_luau-polyfill@1.2.7.luau-polyfill.Promise
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {};