-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_symbol-luau@1.0.1.symbol-luau
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Symbol__1 = require(script:WaitForChild("Symbol"));
local v1 = require(script:WaitForChild("Registry.global"));
local v3 = setmetatable({}, {
    __call = function(_, p2) --[[ Name: __call, Line 15 ]]
        -- upvalues: l__Symbol__1 (copy)
        return l__Symbol__1.new(p2);
    end
});
v3.for_ = v1.getOrInit;
return v3;