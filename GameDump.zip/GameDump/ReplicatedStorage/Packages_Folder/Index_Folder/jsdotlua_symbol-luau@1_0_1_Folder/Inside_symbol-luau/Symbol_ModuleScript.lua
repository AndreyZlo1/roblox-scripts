-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_symbol-luau@1.0.1.symbol-luau.Symbol
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    new = function(p1) --[[ Name: new, Line 15 ]]
        local v2 = newproxy(true);
        local u3 = not p1 and "Symbol()" or ("Symbol(%s)"):format(p1);
        getmetatable(v2).__tostring = function() --[[ Line: 23 ]]
            -- upvalues: u3 (ref)
            return u3;
        end;
        return v2;
    end
};