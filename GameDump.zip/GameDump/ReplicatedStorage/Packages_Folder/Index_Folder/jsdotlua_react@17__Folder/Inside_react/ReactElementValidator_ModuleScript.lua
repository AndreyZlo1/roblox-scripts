-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react@17.1.0.react.ReactElementValidator
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local l__Array__1 = v1.Array;
local l__Boolean__2 = v1.Boolean;
local l__Object__3 = v1.Object;
local l__console__4 = require(script.Parent.Parent:WaitForChild("shared")).console;
local l__inspect__5 = v1.util.inspect;
require(script.Parent.Parent:WaitForChild("shared"));
local l__isValidElementType__6 = require(script.Parent.Parent:WaitForChild("shared")).isValidElementType;
local l__getComponentName__7 = require(script.Parent.Parent:WaitForChild("shared")).getComponentName;
local l__ReactSymbols__8 = require(script.Parent.Parent:WaitForChild("shared")).ReactSymbols;
local l__getIteratorFn__9 = l__ReactSymbols__8.getIteratorFn;
local _ = l__ReactSymbols__8.REACT_FORWARD_REF_TYPE;
local _ = l__ReactSymbols__8.REACT_MEMO_TYPE;
local l__REACT_FRAGMENT_TYPE__10 = l__ReactSymbols__8.REACT_FRAGMENT_TYPE;
local l__REACT_ELEMENT_TYPE__11 = l__ReactSymbols__8.REACT_ELEMENT_TYPE;
local l__warnAboutSpreadingKeyToJSX__12 = require(script.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags.warnAboutSpreadingKeyToJSX;
local l__checkPropTypes__13 = require(script.Parent.Parent:WaitForChild("shared")).checkPropTypes;
local l__ReactCurrentOwner__14 = require(script.Parent.Parent:WaitForChild("shared")).ReactSharedInternals.ReactCurrentOwner;
local l__ReactElement__15 = require(script.Parent:WaitForChild("ReactElement"));
local l__isValidElement__16 = l__ReactElement__15.isValidElement;
local l__createElement__17 = l__ReactElement__15.createElement;
local l__cloneElement__18 = l__ReactElement__15.cloneElement;
local l__jsxDEV__19 = l__ReactElement__15.jsxDEV;
local l__setExtraStackFrame__20 = require(script.Parent.Parent:WaitForChild("shared")).ReactSharedInternals.ReactDebugCurrentFrame.setExtraStackFrame;
local l__describeUnknownElementTypeFrameInDEV__21 = require(script.Parent.Parent:WaitForChild("shared")).ReactComponentStackFrame.describeUnknownElementTypeFrameInDEV;
local v2 = {};
local u3;
if _G.__DEV__ then
    u3 = false;
else
    u3 = nil;
end;
local u4 = {};
local function u9(p5) --[[ Line: 133 ]]
    -- upvalues: l__ReactCurrentOwner__14 (copy), l__getComponentName__7 (copy), l__Boolean__2 (copy)
    local v6 = l__ReactCurrentOwner__14.current and l__getComponentName__7(l__ReactCurrentOwner__14.current.type);
    local v7 = not v6 and "" or "\n\nCheck the render method of `" .. v6 .. "`.";
    if not l__Boolean__2.toJSBoolean(v7) then
        local v8;
        if typeof(p5) == "string" then
            v8 = p5;
        elseif typeof(p5) == "table" then
            v8 = p5.displayName or p5.name;
        else
            v8 = nil;
        end;
        if not v8 and typeof(p5) == "function" then
            v8 = debug.info(p5, "n");
            if v8 == "" then
                v8 = nil;
            end;
        end;
        if v8 then
            v7 = string.format("\n\nCheck the top-level render call using <%s>.", v8);
        end;
    end;
    return v7;
end;
local function u16(p10, p11, p12) --[[ Line: 175 ]]
    -- upvalues: u9 (copy), u4 (copy), l__ReactCurrentOwner__14 (copy), l__getComponentName__7 (copy), l__describeUnknownElementTypeFrameInDEV__21 (copy), l__setExtraStackFrame__20 (copy), l__console__4 (copy)
    if p10._store == nil or p10._store.validated then
    else
        p10._store.validated = true;
        if p10.key ~= nil == (p12 ~= nil) then
            local v13 = u9(p11);
            if u4[v13] then
            else
                u4[v13] = true;
                local v14 = (not p10 or (not p10._owner or p10._owner == l__ReactCurrentOwner__14.current)) and "" or string.format(" It was passed a child from %s.", (tostring(l__getComponentName__7(p10._owner.type))));
                if _G.__DEV__ then
                    if _G.__DEV__ then
                        if p10 then
                            local l___owner__22 = p10._owner;
                            local v15;
                            if l___owner__22 then
                                v15 = l___owner__22.type;
                            else
                                v15 = nil;
                            end;
                            l__setExtraStackFrame__20((l__describeUnknownElementTypeFrameInDEV__21(p10.type, p10._source, v15)));
                        else
                            l__setExtraStackFrame__20(nil);
                        end;
                    end;
                    if p10.key == nil or p12 == nil then
                        l__console__4.error("Each child in a list should have a unique \"key\" prop.%s%s See https://reactjs.org/link/warning-keys for more information.", v13, v14);
                    else
                        l__console__4.error("Child element received a \"key\" prop (\"%s\") in addition to a key in the \"children\" table of its parent (\"%s\"). Please provide only one key definition. When both are present, the \"key\" prop will take precedence.%s%s See https://reactjs.org/link/warning-keys for more information.", tostring(p10.key), tostring(p12), v13, v14);
                    end;
                    if _G.__DEV__ then
                        l__setExtraStackFrame__20(nil);
                    end;
                end;
            end;
        end;
    end;
end;
local function u24(p17, p18) --[[ Line: 250 ]]
    -- upvalues: l__Array__1 (copy), l__isValidElement__16 (copy), u16 (copy), l__getIteratorFn__9 (copy)
    if typeof(p17) == "table" then
        if l__Array__1.isArray(p17) then
            for v19 = 1, #p17 do
                local v20 = p17[v19];
                if l__isValidElement__16(v20) then
                    u16(v20, p18);
                end;
            end;
        else
            if l__isValidElement__16(p17) then
                if p17._store then
                    p17._store.validated = true;
                end;
            elseif p17 then
                local v21 = l__getIteratorFn__9(p17);
                if typeof(v21) == "function" and v21 ~= p17.entries then
                    local v22 = v21(p17);
                    local v23 = v22.next();
                    while not v23.done do
                        if l__isValidElement__16(v23.value) then
                            u16(v23.value, p18, v23.key);
                        end;
                        v23 = v22.next();
                    end;
                end;
            end;
        end;
    end;
end;
local function u28(p25) --[[ Line: 293 ]]
    -- upvalues: l__getComponentName__7 (copy), l__checkPropTypes__13 (copy), u3 (ref), l__console__4 (copy)
    if _G.__DEV__ or _G.__DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION__ then
        local l__type__23 = p25.type;
        if l__type__23 == nil or typeof(l__type__23) == "string" then
            return;
        end;
        if typeof(l__type__23) == "function" then
            return;
        end;
        if typeof(l__type__23) ~= "table" then
            return;
        end;
        local l__propTypes__24 = l__type__23.propTypes;
        local l__validateProps__25 = l__type__23.validateProps;
        if l__propTypes__24 or l__validateProps__25 then
            local v26 = l__getComponentName__7(l__type__23);
            l__checkPropTypes__13(l__propTypes__24, l__validateProps__25, p25.props, "prop", v26, p25);
        elseif l__type__23.PropTypes ~= nil and not u3 then
            u3 = true;
            local v27 = l__getComponentName__7(l__type__23);
            l__console__4.error("Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?", v27 or "Unknown");
        end;
        if l__type__23.getDefaultProps ~= nil then
            l__console__4.error("getDefaultProps is only used on classic React.createClass definitions. Use a static property named `defaultProps` instead.");
        end;
    end;
end;
local function u35(p29) --[[ Line: 343 ]]
    -- upvalues: l__Object__3 (copy), l__describeUnknownElementTypeFrameInDEV__21 (copy), l__setExtraStackFrame__20 (copy), l__console__4 (copy)
    if _G.__DEV__ then
        local v30 = l__Object__3.keys(p29.props);
        for v31 = 1, #v30 do
            local v32 = v30[v31];
            if v32 ~= "children" and v32 ~= "key" then
                if _G.__DEV__ then
                    if p29 then
                        local l___owner__26 = p29._owner;
                        local v33;
                        if l___owner__26 then
                            v33 = l___owner__26.type;
                        else
                            v33 = nil;
                        end;
                        l__setExtraStackFrame__20((l__describeUnknownElementTypeFrameInDEV__21(p29.type, p29._source, v33)));
                    else
                        l__setExtraStackFrame__20(nil);
                    end;
                end;
                l__console__4.error("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.", v32);
                if _G.__DEV__ then
                    l__setExtraStackFrame__20(nil);
                end;
                break;
            end;
        end;
        if p29.ref ~= nil then
            if _G.__DEV__ then
                if p29 then
                    local l___owner__27 = p29._owner;
                    local v34;
                    if l___owner__27 then
                        v34 = l___owner__27.type;
                    else
                        v34 = nil;
                    end;
                    l__setExtraStackFrame__20((l__describeUnknownElementTypeFrameInDEV__21(p29.type, p29._source, v34)));
                else
                    l__setExtraStackFrame__20(nil);
                end;
            end;
            l__console__4.error("Invalid attribute `ref` supplied to `React.Fragment`.");
            if _G.__DEV__ then
                l__setExtraStackFrame__20(nil);
            end;
        end;
    end;
end;
local function u50(p36, p37, p38, p39, p40, p41) --[[ Line: 369 ]]
    -- upvalues: l__isValidElementType__6 (copy), l__Object__3 (copy), l__ReactCurrentOwner__14 (copy), l__getComponentName__7 (copy), l__Array__1 (copy), l__REACT_ELEMENT_TYPE__11 (copy), l__inspect__5 (copy), l__console__4 (copy), l__jsxDEV__19 (copy), u24 (copy), l__warnAboutSpreadingKeyToJSX__12 (copy), l__REACT_FRAGMENT_TYPE__10 (copy), u35 (copy), u28 (copy)
    local v42 = l__isValidElementType__6(p36);
    if not v42 then
        local v43 = "";
        if p36 == nil or typeof(p36) == "table" and #l__Object__3.keys(p36) == 0 then
            v43 = v43 .. " You likely forgot to export your component from the file it\'s defined in, or you might have mixed up default and named imports.";
        end;
        local v44 = p40 == nil and "" or "\n\nCheck your code at " .. string.gsub(p40.fileName, "^.*[\\/]", "") .. ":" .. p40.lineNumber .. ".";
        local v45;
        if v44 then
            v45 = v43 .. v44;
        else
            local v46 = l__ReactCurrentOwner__14.current and l__getComponentName__7(l__ReactCurrentOwner__14.current.type);
            v45 = v43 .. (not v46 and "" or "\n\nCheck the render method of `" .. v46 .. "`.");
        end;
        local v47;
        if p36 == nil then
            v47 = "nil";
        elseif l__Array__1.isArray(p36) then
            v47 = "array";
        elseif typeof(p36) == "table" and p36["$$typeof"] == l__REACT_ELEMENT_TYPE__11 then
            v47 = string.format("<%s />", l__getComponentName__7(p36.type) or "Unknown");
            v45 = v45 .. " Did you accidentally export a JSX literal or Element instead of a component?";
        else
            v47 = typeof(p36);
            v45 = v45 .. "\n" .. l__inspect__5(p36);
        end;
        if _G.__DEV__ then
            l__console__4.error("React.jsx: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", v47, v45);
        end;
    end;
    local v48 = l__jsxDEV__19(p36, p37, p38, p40, p41);
    if v48 == nil then
        return v48;
    else
        if v42 then
            local l__children__28 = p37.children;
            if l__children__28 ~= nil then
                if p39 then
                    if l__Array__1.isArray(l__children__28) then
                        for v49 = 1, #l__children__28 do
                            u24(l__children__28[v49], p36);
                        end;
                        l__Object__3.freeze(l__children__28);
                    elseif _G.__DEV__ then
                        l__console__4.error("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
                    end;
                else
                    u24(l__children__28, p36);
                end;
            end;
        end;
        if _G.__DEV__ and l__warnAboutSpreadingKeyToJSX__12 and p37.key ~= nil then
            l__console__4.error("React.jsx: Spreading a key to JSX is a deprecated pattern. Explicitly pass a key after spreading props in your JSX call. E.g. <%s {...props} key={key} />", l__getComponentName__7(p36) or "ComponentName");
        end;
        if p36 == l__REACT_FRAGMENT_TYPE__10 then
            u35(v48);
            return v48;
        else
            u28(v48);
            return v48;
        end;
    end;
end;
v2.jsxWithValidation = u50;
function v2.jsxWithValidationStatic(p51, p52, p53) --[[ Line: 491 ]]
    -- upvalues: u50 (copy)
    return u50(p51, p52, p53, true);
end;
function v2.jsxWithValidationDynamic(p54, p55, p56) --[[ Line: 495 ]]
    -- upvalues: u50 (copy)
    return u50(p54, p55, p56, false);
end;
function v2.createElementWithValidation(p57, p58, ...) --[[ Line: 500 ]]
    -- upvalues: l__isValidElementType__6 (copy), l__Object__3 (copy), l__ReactCurrentOwner__14 (copy), l__getComponentName__7 (copy), l__Array__1 (copy), l__REACT_ELEMENT_TYPE__11 (copy), l__inspect__5 (copy), l__console__4 (copy), l__createElement__17 (copy), u24 (copy), l__REACT_FRAGMENT_TYPE__10 (copy), u35 (copy), u28 (copy)
    local v59 = l__isValidElementType__6(p57);
    if not v59 then
        local v60 = "";
        if p57 == nil or typeof(p57) == "table" and #l__Object__3.keys(p57) == 0 then
            v60 = v60 .. " You likely forgot to export your component from the file it\'s defined in, or you might have mixed up default and named imports.";
        end;
        local v61;
        if p58 == nil then
            v61 = "";
        else
            local l____source__29 = p58.__source;
            v61 = l____source__29 == nil and "" or "\n\nCheck your code at " .. string.gsub(l____source__29.fileName, "^.*[\\/]", "") .. ":" .. l____source__29.lineNumber .. ".";
        end;
        local v62;
        if v61 then
            v62 = v60 .. v61;
        else
            local v63 = l__ReactCurrentOwner__14.current and l__getComponentName__7(l__ReactCurrentOwner__14.current.type);
            v62 = v60 .. (not v63 and "" or "\n\nCheck the render method of `" .. v63 .. "`.");
        end;
        local v64;
        if p57 == nil then
            v64 = "nil";
        elseif l__Array__1.isArray(p57) then
            v64 = "array";
        elseif p57 == nil or (typeof(p57) ~= "table" or p57["$$typeof"] ~= l__REACT_ELEMENT_TYPE__11) then
            v64 = typeof(p57);
            if p57 ~= nil then
                v62 = v62 .. "\n" .. l__inspect__5(p57);
            end;
        else
            v64 = string.format("<%s />", l__getComponentName__7(p57.type) or "Unknown");
            v62 = v62 .. " Did you accidentally export a JSX literal or Element instead of a component?";
        end;
        if _G.__DEV__ then
            l__console__4.error("React.createElement: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", v64, v62);
        end;
    end;
    local v65 = l__createElement__17(p57, p58, ...);
    if v65 == nil then
        return v65;
    else
        if v59 then
            for v66 = 1, select("#", ...) do
                u24(select(v66, ...), p57);
            end;
        end;
        if p57 == l__REACT_FRAGMENT_TYPE__10 then
            u35(v65);
            return v65;
        else
            u28(v65);
            return v65;
        end;
    end;
end;
function v2.cloneElementWithValidation(p67, p68, ...) --[[ Line: 633 ]]
    -- upvalues: l__cloneElement__18 (copy), u24 (copy), u28 (copy)
    local v69 = { p67, p68, ... };
    local v70 = l__cloneElement__18(p67, p68, ...);
    for v71 = 3, #v69 do
        u24(v69[v71], v70.type);
    end;
    u28(v70);
    return v70;
end;
return v2;