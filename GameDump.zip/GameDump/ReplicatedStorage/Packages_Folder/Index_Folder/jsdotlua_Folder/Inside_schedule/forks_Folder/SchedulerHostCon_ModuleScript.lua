-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_scheduler@17.1.0.scheduler.forks.SchedulerHostConfig.default
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = require(script.Parent.Parent.Parent:WaitForChild("luau-polyfill"));
local l__Object__1 = v1.Object;
local l__shared__2 = require(script.Parent.Parent.Parent:WaitForChild("shared"));
local l__console__3 = l__shared__2.console;
local l__errorToString__4 = l__shared__2.errorToString;
local l__describeError__5 = l__shared__2.describeError;
local l__setTimeout__6 = v1.setTimeout;
local l__clearTimeout__7 = v1.clearTimeout;
local u2 = false;
local u3 = nil;
local l__None__8 = l__Object__1.None;
local u4 = 15;
local u5 = 0;
local function u10() --[[ Line: 69 ]]
    -- upvalues: u3 (ref), u5 (ref), u4 (ref), u2 (ref), u10 (copy), l__describeError__5 (copy), l__errorToString__4 (copy)
    if u3 == nil then
        u2 = false;
    else
        local u6 = os.clock() * 1000;
        u5 = u6 + u4;
        local function v7() --[[ Line: 79 ]]
            -- upvalues: u3 (ref), u6 (copy), u2 (ref), u10 (ref)
            if u3(true, u6) then
                task.delay(0, u10);
            else
                u2 = false;
                u3 = nil;
            end;
            return nil;
        end;
        local v8, v9;
        if _G.__YOLO__ then
            if u3(true, u6) then
                task.delay(0, u10);
                v8 = true;
                v9 = nil;
            else
                u2 = false;
                u3 = nil;
                v8 = true;
                v9 = nil;
            end;
        else
            v8, v9 = xpcall(v7, l__describeError__5);
        end;
        if not v8 then
            task.delay(0, u10);
            error(l__errorToString__4(v9));
        end;
    end;
end;
return {
    requestHostCallback = function(p11) --[[ Name: requestHostCallback, Line 123 ]]
        -- upvalues: u3 (ref), u2 (ref), u10 (copy)
        u3 = p11;
        if not u2 then
            u2 = true;
            task.delay(0, u10);
        end;
    end,
    cancelHostCallback = function() --[[ Name: cancelHostCallback, Line 132 ]]
        -- upvalues: u3 (ref)
        u3 = nil;
    end,
    requestHostTimeout = function(u12, p13) --[[ Name: requestHostTimeout, Line 136 ]]
        -- upvalues: l__None__8 (ref), l__setTimeout__6 (copy)
        l__None__8 = l__setTimeout__6(function() --[[ Line: 137 ]]
            -- upvalues: u12 (copy)
            u12(os.clock() * 1000);
        end, p13);
    end,
    cancelHostTimeout = function() --[[ Name: cancelHostTimeout, Line 142 ]]
        -- upvalues: l__clearTimeout__7 (copy), l__None__8 (ref), l__Object__1 (copy)
        l__clearTimeout__7(l__None__8);
        l__None__8 = l__Object__1.None;
    end,
    shouldYieldToHost = function() --[[ Name: shouldYieldToHost, Line 46 ]]
        -- upvalues: u5 (ref)
        return u5 <= os.clock() * 1000;
    end,
    requestPaint = function() --[[ Name: requestPaint, Line 51 ]] end,
    getCurrentTime = function() --[[ Line: 19 ]]
        return os.clock() * 1000;
    end,
    forceFrameRate = function(p14) --[[ Name: forceFrameRate, Line 53 ]]
        -- upvalues: l__console__3 (copy), u4 (ref)
        if p14 < 0 or p14 > 125 then
            l__console__3.warn("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported");
        elseif p14 > 0 then
            u4 = math.floor(1000 / p14);
        else
            u4 = 5;
        end;
    end
};