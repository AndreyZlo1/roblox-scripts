-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_scheduler@17.1.0.scheduler.forks.SchedulerHostConfig.mock
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {};
local u2 = 0;
local u3 = nil;
local u4 = nil;
local u5 = -1;
local u6 = nil;
local u7 = -1;
local u8 = false;
local u9 = false;
local u10 = false;
local u11 = false;
local l__console__1 = require(script.Parent.Parent.Parent:WaitForChild("shared")).console;
local l__disabledLog__2 = require(script.Parent.Parent.Parent:WaitForChild("shared")).ConsolePatchingDev.disabledLog;
function u1.requestHostCallback(p12) --[[ Line: 27 ]]
    -- upvalues: u3 (ref)
    u3 = p12;
end;
function u1.cancelHostCallback() --[[ Line: 31 ]]
    -- upvalues: u3 (ref)
    u3 = nil;
end;
function u1.requestHostTimeout(p13, p14) --[[ Line: 35 ]]
    -- upvalues: u4 (ref), u5 (ref), u2 (ref)
    u4 = p13;
    u5 = u2 + p14;
end;
function u1.cancelHostTimeout() --[[ Line: 40 ]]
    -- upvalues: u4 (ref), u5 (ref)
    u4 = nil;
    u5 = -1;
end;
function u1.shouldYieldToHost() --[[ Line: 45 ]]
    -- upvalues: u6 (ref), u7 (ref), u11 (ref), u10 (ref), u8 (ref)
    local v15 = u6;
    if (u7 == -1 or (v15 == nil or u7 > #v15)) and not (u11 and u10) then
        return false;
    end;
    u8 = true;
    return true;
end;
function u1.getCurrentTime() --[[ Line: 64 ]]
    -- upvalues: u2 (ref)
    return u2;
end;
function u1.forceFrameRate() --[[ Line: 68 ]] end;
function u1.reset() --[[ Line: 72 ]]
    -- upvalues: u9 (ref), u2 (ref), u3 (ref), u4 (ref), u5 (ref), u6 (ref), u7 (ref), u8 (ref), u10 (ref)
    if u9 then
        error("Cannot reset while already flushing work.");
    end;
    u2 = 0;
    u3 = nil;
    u4 = nil;
    u5 = -1;
    u6 = nil;
    u7 = -1;
    u8 = false;
    u9 = false;
    u10 = false;
end;
function u1.unstable_flushNumberOfYields(p16) --[[ Line: 89 ]]
    -- upvalues: u9 (ref), u3 (ref), u7 (ref), u2 (ref), u8 (ref)
    if u9 then
        error("Already flushing work.");
    end;
    if u3 ~= nil then
        local u17 = u3;
        u7 = p16;
        u9 = true;
        local v19, v20 = pcall(function() --[[ Line: 99 ]]
            -- upvalues: u17 (copy), u2 (ref), u8 (ref), u3 (ref)
            local v18;
            repeat
                v18 = u17(true, u2);
            until not v18 or u8;
            if not v18 then
                u3 = nil;
            end;
        end);
        u7 = -1;
        u8 = false;
        u9 = false;
        if not v19 then
            error(v20);
        end;
    end;
end;
function u1.unstable_flushUntilNextPaint() --[[ Line: 120 ]]
    -- upvalues: u9 (ref), u3 (ref), u11 (ref), u10 (ref), u2 (ref), u8 (ref)
    if u9 then
        error("Already flushing work.");
    end;
    if u3 ~= nil then
        local u21 = u3;
        u11 = true;
        u10 = false;
        u9 = true;
        local v23, v24 = pcall(function() --[[ Line: 131 ]]
            -- upvalues: u21 (copy), u2 (ref), u8 (ref), u3 (ref)
            local v22;
            repeat
                v22 = u21(true, u2);
            until not v22 or u8;
            if not v22 then
                u3 = nil;
            end;
        end);
        u11 = false;
        u8 = false;
        u9 = false;
        if not v23 then
            error(v24);
        end;
    end;
end;
function u1.unstable_flushExpired() --[[ Line: 153 ]]
    -- upvalues: u9 (ref), u3 (ref), u2 (ref)
    if u9 then
        error("Already flushing work.");
    end;
    if u3 ~= nil then
        u9 = true;
        local v25, v26 = pcall(function() --[[ Line: 159 ]]
            -- upvalues: u3 (ref), u2 (ref)
            if not u3(false, u2) then
                u3 = nil;
            end;
        end);
        u9 = false;
        if not v25 then
            error(v26);
        end;
    end;
end;
function u1.unstable_flushAllWithoutAsserting() --[[ Line: 177 ]]
    -- upvalues: u9 (ref), u3 (ref), u2 (ref)
    if u9 then
        error("Already flushing work.");
    end;
    if u3 == nil then
        return false;
    end;
    local u27 = u3;
    u9 = true;
    local v29, v30 = pcall(function() --[[ Line: 185 ]]
        -- upvalues: u27 (copy), u2 (ref), u3 (ref)
        local v28;
        repeat
            v28 = u27(true, u2);
        until not v28;
        if not v28 then
            u3 = nil;
        end;
    end);
    u9 = false;
    if not v29 then
        error(v30);
    end;
    return true;
end;
function u1.unstable_clearYields() --[[ Line: 208 ]]
    -- upvalues: u6 (ref)
    if u6 == nil then
        return {};
    end;
    local v31 = u6;
    u6 = nil;
    return v31;
end;
function u1.unstable_flushAll() --[[ Line: 217 ]]
    -- upvalues: u6 (ref), u1 (copy)
    if u6 ~= nil then
        error("Log is not empty. Assert on the log of yielded values before flushing additional work.");
    end;
    u1.unstable_flushAllWithoutAsserting();
    if u6 ~= nil then
        error("While flushing work, something yielded a value. Use an assertion helper to assert on the log of yielded values, e.g. expect(Scheduler).toFlushAndYield([...])");
    end;
end;
function u1.unstable_yieldValue(p32) --[[ Line: 234 ]]
    -- upvalues: l__console__1 (copy), l__disabledLog__2 (copy), u6 (ref)
    if l__console__1.log == l__disabledLog__2 then
    elseif u6 == nil then
        u6 = { p32 };
    else
        table.insert(u6, p32);
    end;
end;
function u1.unstable_advanceTime(p33) --[[ Line: 251 ]]
    -- upvalues: l__console__1 (copy), l__disabledLog__2 (copy), u2 (ref), u4 (ref), u5 (ref)
    if l__console__1.log == l__disabledLog__2 then
    else
        u2 = u2 + p33;
        if u4 ~= nil and u5 <= u2 then
            u4(u2);
            u5 = -1;
            u4 = nil;
        end;
    end;
end;
function u1.requestPaint() --[[ Line: 270 ]]
    -- upvalues: u10 (ref)
    u10 = true;
end;
return u1;