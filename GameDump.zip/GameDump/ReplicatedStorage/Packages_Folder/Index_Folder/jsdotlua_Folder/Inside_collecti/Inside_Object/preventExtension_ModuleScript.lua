-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Object.preventExtensions
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
return function(p1) --[[ Name: preventExtensions, Line 8 ]]
    local u2 = tostring(p1);
    return setmetatable(p1, {
        __metatable = false,
        __newindex = function(_, p3, _) --[[ Name: __newindex, Line 13 ]]
            -- upvalues: u2 (copy)
            local v4 = ("%q (%s) is not a valid member of %s"):format(tostring(p3), typeof(p3), u2);
            error(v4, 2);
        end
    });
end;