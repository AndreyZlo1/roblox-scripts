-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Map.coerceToTable
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Map__1 = require(script.Parent:WaitForChild("Map"));
local u1 = require(script.Parent.Parent.Parent:WaitForChild("instance-of"));
local l__reduce__2 = require(script.Parent.Parent:WaitForChild("Array"):WaitForChild("reduce"));
require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
return function(p2) --[[ Name: coerceToTable, Line 9 ]]
    -- upvalues: u1 (copy), l__Map__1 (copy), l__reduce__2 (copy)
    if u1(p2, l__Map__1) then
        return l__reduce__2(p2:entries(), function(p3, p4) --[[ Line: 15 ]]
            p3[p4[1]] = p4[2];
            return p3;
        end, {});
    else
        return p2;
    end;
end;