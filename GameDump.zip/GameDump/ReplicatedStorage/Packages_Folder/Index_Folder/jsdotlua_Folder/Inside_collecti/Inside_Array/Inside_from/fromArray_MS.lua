-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Array.from.fromArray
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent.Parent.Parent:WaitForChild("es7-types"));
return function(p1, p2, p3) --[[ Line: 8 ]]
    if not p2 then
        return table.clone(p1);
    end;
    local v4 = #p1;
    local v5 = table.create(v4);
    for v6 = 1, v4 do
        if p3 == nil then
            v5[v6] = p2(p1[v6], v6);
        else
            v5[v6] = p2(p3, p1[v6], v6);
        end;
    end;
    return v5;
end;