-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-roblox@17.1.0.react-roblox.client.ReactRoblox
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent.Parent:WaitForChild("shared"));
require(script.Parent:WaitForChild("ReactRobloxHostTypes.roblox"));
local l__ReactRobloxRoot__1 = require(script.Parent:WaitForChild("ReactRobloxRoot"));
local l__createRoot__2 = l__ReactRobloxRoot__1.createRoot;
local l__createBlockingRoot__3 = l__ReactRobloxRoot__1.createBlockingRoot;
local l__createLegacyRoot__4 = l__ReactRobloxRoot__1.createLegacyRoot;
local l__isValidContainer__5 = l__ReactRobloxRoot__1.isValidContainer;
local v1 = require(script.Parent.Parent:WaitForChild("ReactReconciler.roblox"));
local l__batchedUpdates__6 = v1.batchedUpdates;
local l__injectIntoDevTools__7 = v1.injectIntoDevTools;
local l__flushPassiveEffects__8 = v1.flushPassiveEffects;
local l__IsThisRendererActing__9 = v1.IsThisRendererActing;
local l__createPortal__10 = v1.createPortal;
local l__ReactVersion__11 = require(script.Parent.Parent.Parent:WaitForChild("shared")).ReactVersion;
local l__invariant__12 = require(script.Parent.Parent.Parent:WaitForChild("shared")).invariant;
local l__enableNewReconciler__13 = require(script.Parent.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags.enableNewReconciler;
local l__ReactRobloxComponentTree__14 = require(script.Parent:WaitForChild("ReactRobloxComponentTree"));
local l__getInstanceFromNode__15 = l__ReactRobloxComponentTree__14.getInstanceFromNode;
local l__getNodeFromInstance__16 = l__ReactRobloxComponentTree__14.getNodeFromInstance;
local l__getFiberCurrentPropsFromNode__17 = l__ReactRobloxComponentTree__14.getFiberCurrentPropsFromNode;
local l__getClosestInstanceFromNode__18 = l__ReactRobloxComponentTree__14.getClosestInstanceFromNode;
local v5 = {
    createPortal = function(p2, p3, p4) --[[ Name: createPortal, Line 122 ]]
        -- upvalues: l__invariant__12 (copy), l__isValidContainer__5 (copy), l__createPortal__10 (copy)
        l__invariant__12(l__isValidContainer__5(p3), "Target container is not a Roblox Instance.");
        return l__createPortal__10(p2, p3, nil, p4);
    end,
    unstable_batchedUpdates = l__batchedUpdates__6,
    __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = {
        Events = {
            getInstanceFromNode = l__getInstanceFromNode__15,
            getNodeFromInstance = l__getNodeFromInstance__16,
            getFiberCurrentPropsFromNode = l__getFiberCurrentPropsFromNode__17,
            flushPassiveEffects = l__flushPassiveEffects__8,
            IsThisRendererActing = l__IsThisRendererActing__9
        }
    },
    version = l__ReactVersion__11,
    createRoot = l__createRoot__2,
    createBlockingRoot = l__createBlockingRoot__3,
    createLegacyRoot = l__createLegacyRoot__4,
    Event = require(script.Parent.Parent.Parent:WaitForChild("shared")).Event,
    Change = require(script.Parent.Parent.Parent:WaitForChild("shared")).Change,
    Tag = require(script.Parent.Parent.Parent:WaitForChild("shared")).Tag,
    unstable_isNewReconciler = l__enableNewReconciler__13,
    act = function(_) --[[ Name: act, Line 255 ]]
        error("ReactRoblox.act is only available in testing environments, not production. Enable the `__ROACT_17_MOCK_SCHEDULER__` global in your test configuration in order to use `act`.");
    end
};
if _G.__ROACT_17_MOCK_SCHEDULER__ then
    v5.act = v1.act;
end;
l__injectIntoDevTools__7({
    rendererPackageName = "ReactRoblox",
    findFiberByHostInstance = l__getClosestInstanceFromNode__18,
    bundleType = _G.__DEV__ and 1 or 0,
    version = l__ReactVersion__11
});
local _ = _G.__DEV__;
return v5;