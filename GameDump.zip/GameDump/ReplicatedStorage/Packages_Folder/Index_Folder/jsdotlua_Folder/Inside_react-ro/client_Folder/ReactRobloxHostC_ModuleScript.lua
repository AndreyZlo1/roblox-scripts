-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-roblox@17.1.0.react-roblox.client.ReactRobloxHostConfig
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__CollectionService__1 = game:GetService("CollectionService");
local v1 = require(script.Parent.Parent.Parent:WaitForChild("luau-polyfill"));
local l__inspect__2 = v1.util.inspect;
local l__console__3 = require(script.Parent.Parent.Parent:WaitForChild("shared")).console;
local l__Object__4 = v1.Object;
local l__setTimeout__5 = v1.setTimeout;
local l__clearTimeout__6 = v1.clearTimeout;
require(script.Parent:WaitForChild("ReactRobloxHostTypes.roblox"));
local l__ReactRobloxComponentTree__7 = require(script.Parent:WaitForChild("ReactRobloxComponentTree"));
local l__precacheFiberNode__8 = l__ReactRobloxComponentTree__7.precacheFiberNode;
local l__uncacheFiberNode__9 = l__ReactRobloxComponentTree__7.uncacheFiberNode;
local l__updateFiberProps__10 = l__ReactRobloxComponentTree__7.updateFiberProps;
local l__ReactRobloxComponent__11 = require(script.Parent:WaitForChild("ReactRobloxComponent"));
local l__setInitialProperties__12 = l__ReactRobloxComponent__11.setInitialProperties;
local l__diffProperties__13 = l__ReactRobloxComponent__11.diffProperties;
local l__updateProperties__14 = l__ReactRobloxComponent__11.updateProperties;
local l__cleanupHostComponent__15 = l__ReactRobloxComponent__11.cleanupHostComponent;
local l__enableCreateEventHandleAPI__16 = require(script.Parent.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags.enableCreateEventHandleAPI;
local u2 = {};
l__Object__4.assign(u2, require(script.Parent.Parent.Parent:WaitForChild("shared")).ReactFiberHostConfig.WithNoPersistence);
function u2.getRootHostContext(p3) --[[ Line: 225 ]]
    return p3.ClassName;
end;
function u2.getChildHostContext(p4, _, _) --[[ Line: 263 ]]
    return p4;
end;
function u2.getPublicInstance(p5) --[[ Line: 284 ]]
    return p5;
end;
function u2.prepareForCommit(_) --[[ Line: 288 ]]
    -- upvalues: l__enableCreateEventHandleAPI__16 (copy)
    if l__enableCreateEventHandleAPI__16 then
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        print("UNIMPLEMENTED ERROR: " .. tostring("enableCreateEventHandleAPI"));
        error("FIXME (roblox): enableCreateEventHandleAPI is unimplemented", 2);
    end;
    return nil;
end;
function u2.beforeActiveInstanceBlur() --[[ Line: 303 ]]
    -- upvalues: l__enableCreateEventHandleAPI__16 (copy)
    if l__enableCreateEventHandleAPI__16 then
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        print("UNIMPLEMENTED ERROR: " .. tostring("enableCreateEventHandleAPI"));
        error("FIXME (roblox): enableCreateEventHandleAPI is unimplemented", 2);
    end;
end;
function u2.afterActiveInstanceBlur() --[[ Line: 312 ]]
    -- upvalues: l__enableCreateEventHandleAPI__16 (copy)
    if l__enableCreateEventHandleAPI__16 then
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        print("UNIMPLEMENTED ERROR: " .. tostring("enableCreateEventHandleAPI"));
        error("FIXME (roblox): enableCreateEventHandleAPI is unimplemented", 2);
    end;
end;
function u2.resetAfterCommit(_) --[[ Line: 321 ]] end;
function u2.createInstance(p6, p7, _, _, p8) --[[ Line: 329 ]]
    -- upvalues: l__precacheFiberNode__8 (copy), l__updateFiberProps__10 (copy)
    local v9 = Instance.new(p6);
    if p8.key then
        v9.Name = p8.key;
    else
        local l__return___17 = p8.return_;
        while l__return___17 do
            if l__return___17.key then
                v9.Name = l__return___17.key;
                break;
            end;
            l__return___17 = l__return___17.return_;
        end;
    end;
    l__precacheFiberNode__8(p8, v9);
    l__updateFiberProps__10(v9, p7);
    return v9;
end;
function u2.appendInitialChild(p10, p11) --[[ Line: 396 ]]
    p11.Parent = p10;
end;
function u2.finalizeInitialChildren(p12, p13, p14, p15, _) --[[ Line: 401 ]]
    -- upvalues: l__setInitialProperties__12 (copy)
    l__setInitialProperties__12(p12, p13, p14, p15);
    return false;
end;
function u2.prepareUpdate(p16, p17, p18, p19, p20, _) --[[ Line: 413 ]]
    -- upvalues: l__diffProperties__13 (copy)
    return l__diffProperties__13(p16, p17, p18, p19, p20);
end;
function u2.shouldSetTextContent(_, _) --[[ Line: 440 ]]
    return false;
end;
function u2.createTextInstance(_, _, _, _) --[[ Line: 456 ]]
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("UNIMPLEMENTED ERROR: " .. tostring("createTextInstance"));
    error("FIXME (roblox): createTextInstance is unimplemented", 2);
    return nil;
end;
u2.isPrimaryRenderer = true;
u2.warnsIfNotActing = true;
u2.scheduleTimeout = l__setTimeout__5;
u2.cancelTimeout = l__clearTimeout__6;
u2.noTimeout = -1;
u2.supportsMutation = true;
function u2.commitMount(_, _, _, _) --[[ Line: 482 ]]
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("UNIMPLEMENTED ERROR: " .. tostring("commitMount"));
    error("FIXME (roblox): commitMount is unimplemented", 2);
end;
function u2.commitUpdate(p21, p22, _, p23, p24, _) --[[ Line: 504 ]]
    -- upvalues: l__updateFiberProps__10 (copy), l__updateProperties__14 (copy)
    l__updateFiberProps__10(p21, p24);
    l__updateProperties__14(p21, p22, p23);
end;
local function u26(p25) --[[ Line: 533 ]]
    -- upvalues: l__console__3 (copy), l__inspect__2 (copy), l__CollectionService__1 (copy)
    if typeof(p25) == "Instance" then
        if not p25:IsDescendantOf(game) and #l__CollectionService__1:GetTags(p25) > 0 then
            l__console__3.warn("Tags applied to orphaned %s \"%s\" cannot be accessed via CollectionService:GetTagged. If you\'re relying on tag behavior in a unit test, consider mounting your test root into the DataModel.", p25.ClassName, p25.Name);
        end;
    else
        l__console__3.warn("Could not check tags on non-instance %s.", l__inspect__2(p25));
    end;
end;
function u2.appendChild(p27, p28) --[[ Line: 552 ]]
    -- upvalues: u26 (copy)
    p28.Parent = p27;
    if _G.__DEV__ then
        u26(p28);
    end;
end;
function u2.appendChildToContainer(p29, p30) --[[ Line: 561 ]]
    -- upvalues: u2 (copy)
    u2.appendChild(p29, p30);
end;
function u2.insertBefore(p31, p32, _) --[[ Line: 591 ]]
    -- upvalues: u26 (copy)
    p32.Parent = p31;
    if _G.__DEV__ then
        u26(p32);
    end;
end;
function u2.insertInContainerBefore(p33, p34, p35) --[[ Line: 601 ]]
    -- upvalues: u2 (copy)
    u2.insertBefore(p33, p34, p35);
end;
function u2.removeChild(_, p36) --[[ Line: 639 ]]
    -- upvalues: l__uncacheFiberNode__9 (copy), l__cleanupHostComponent__15 (copy)
    if typeof(p36) == "Instance" then
        l__uncacheFiberNode__9(p36);
        for _, v37 in p36:GetDescendants() do
            l__uncacheFiberNode__9(v37);
        end;
    end;
    l__cleanupHostComponent__15(p36);
    p36.Parent = nil;
    p36:Destroy();
end;
function u2.removeChildFromContainer(p38, p39) --[[ Line: 651 ]]
    -- upvalues: u2 (copy)
    u2.removeChild(p38, p39);
end;
function u2.clearSuspenseBoundary(_, _) --[[ Line: 663 ]]
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("UNIMPLEMENTED ERROR: " .. tostring("clearSuspenseBoundary"));
    error("FIXME (roblox): clearSuspenseBoundary is unimplemented", 2);
end;
function u2.clearSuspenseBoundaryFromContainer(_, _) --[[ Line: 701 ]]
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("UNIMPLEMENTED ERROR: " .. tostring("clearSuspenseBoundaryFromContainer"));
    error("FIXME (roblox): clearSuspenseBoundaryFromContainer is unimplemented", 2);
end;
function u2.hideInstance(_) --[[ Line: 715 ]]
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("UNIMPLEMENTED ERROR: " .. tostring("hideInstance"));
    error("FIXME (roblox): hideInstance is unimplemented", 2);
end;
function u2.hideTextInstance(_) --[[ Line: 729 ]]
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("UNIMPLEMENTED ERROR: " .. tostring("hideTextInstance"));
    error("FIXME (roblox): hideTextInstance is unimplemented", 2);
end;
function u2.unhideInstance(_, _) --[[ Line: 734 ]]
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("UNIMPLEMENTED ERROR: " .. tostring("unhideInstance"));
    error("FIXME (roblox): unhideInstance is unimplemented", 2);
end;
function u2.unhideTextInstance(_, _) --[[ Line: 748 ]]
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    print("UNIMPLEMENTED ERROR: " .. tostring("unhideTextInstance"));
    error("FIXME (roblox): unhideTextInstance is unimplemented", 2);
end;
function u2.clearContainer(p40) --[[ Line: 753 ]]
    -- upvalues: u2 (copy)
    for _, v41 in p40:GetChildren() do
        u2.removeChild(p40, v41);
    end;
end;
function u2.preparePortalMount(_) --[[ Line: 1196 ]] end;
return u2;