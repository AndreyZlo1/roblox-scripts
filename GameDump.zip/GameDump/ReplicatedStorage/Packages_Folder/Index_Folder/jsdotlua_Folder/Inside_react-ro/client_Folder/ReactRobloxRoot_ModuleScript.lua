-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-roblox@17.1.0.react-roblox.client.ReactRobloxRoot
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent:WaitForChild("ReactRobloxHostTypes.roblox"));
require(script.Parent.Parent.Parent:WaitForChild("react-reconciler"));
require(script.Parent.Parent.Parent:WaitForChild("shared"));
require(script.Parent.Parent.Parent:WaitForChild("react-reconciler"));
local l__ReactRobloxComponentTree__1 = require(script.Parent:WaitForChild("ReactRobloxComponentTree"));
local l__markContainerAsRoot__2 = l__ReactRobloxComponentTree__1.markContainerAsRoot;
local l__unmarkContainerAsRoot__3 = l__ReactRobloxComponentTree__1.unmarkContainerAsRoot;
local v1 = require(script.Parent.Parent:WaitForChild("ReactReconciler.roblox"));
local l__createContainer__4 = v1.createContainer;
local l__updateContainer__5 = v1.updateContainer;
local l__invariant__6 = require(script.Parent.Parent.Parent:WaitForChild("shared")).invariant;
local l__enableEagerRootListeners__7 = require(script.Parent.Parent.Parent:WaitForChild("shared")).ReactFeatureFlags.enableEagerRootListeners;
local l__BlockingRoot__8 = v1.ReactRootTags.BlockingRoot;
local l__ConcurrentRoot__9 = v1.ReactRootTags.ConcurrentRoot;
local l__LegacyRoot__10 = v1.ReactRootTags.LegacyRoot;
local u2 = nil;
local u3 = {};
u3.__index = u3;
function u3.new(p4, p5) --[[ Line: 59 ]]
    -- upvalues: u3 (copy), u2 (ref), l__ConcurrentRoot__9 (copy)
    local v6 = setmetatable({}, u3);
    v6._internalRoot = u2(p4, l__ConcurrentRoot__9, p5);
    return v6;
end;
function u3.render(p7, p8) --[[ Line: 78 ]]
    -- upvalues: l__updateContainer__5 (copy)
    l__updateContainer__5(p8, p7._internalRoot, nil);
end;
function u3.unmount(p9) --[[ Line: 106 ]]
    -- upvalues: l__updateContainer__5 (copy), l__unmarkContainerAsRoot__3 (copy)
    local l___internalRoot__11 = p9._internalRoot;
    local l__containerInfo__12 = l___internalRoot__11.containerInfo;
    l__updateContainer__5(nil, l___internalRoot__11, nil, function() --[[ Line: 117 ]]
        -- upvalues: l__unmarkContainerAsRoot__3 (ref), l__containerInfo__12 (copy)
        l__unmarkContainerAsRoot__3(l__containerInfo__12);
    end);
end;
u2 = function(p10, p11, p12) --[[ Line: 128 ]]
    -- upvalues: l__createContainer__4 (copy), l__markContainerAsRoot__2 (copy), l__enableEagerRootListeners__7 (copy)
    local v13;
    if p12 == nil then
        v13 = false;
    else
        v13 = p12.hydrate == true;
    end;
    local v14;
    if p12 == nil then
        v14 = nil;
    else
        v14 = p12.hydrationOptions;
    end;
    local v15;
    if p12 == nil or p12.hydrationOptions == nil then
        v15 = nil;
    else
        v15 = p12.hydrationOptions.mutableSources or nil;
    end;
    local v16 = l__createContainer__4(p10, p11, v13, v14);
    l__markContainerAsRoot__2(v16.current, p10);
    return v16;
end;
local v28 = {
    isValidContainer = function(p17) --[[ Name: isValidContainer, Line 176 ]]
        return typeof(p17) == "Instance";
    end,
    createRoot = function(p18, p19) --[[ Line: 193 ]]
        -- upvalues: l__invariant__6 (copy), u3 (copy)
        l__invariant__6(typeof(p18) == "Instance", "createRoot(...): Target container is not a Roblox Instance.");
        warnIfReactDOMContainerInDEV(p18);
        return u3.new(p18, p19);
    end,
    createBlockingRoot = function(p20, p21) --[[ Line: 204 ]]
        -- upvalues: l__invariant__6 (copy), l__BlockingRoot__8 (copy), u3 (copy), u2 (ref)
        l__invariant__6(typeof(p20) == "Instance", "createRoot(...): Target container is not a Roblox Instance.");
        warnIfReactDOMContainerInDEV(p20);
        local v22 = l__BlockingRoot__8;
        local v23 = setmetatable({}, u3);
        v23._internalRoot = u2(p20, v22, p21);
        return v23;
    end,
    createLegacyRoot = function(p24, p25) --[[ Line: 214 ]]
        -- upvalues: l__LegacyRoot__10 (copy), u3 (copy), u2 (ref)
        local v26 = l__LegacyRoot__10;
        local v27 = setmetatable({}, u3);
        v27._internalRoot = u2(p24, v26, p25);
        return v27;
    end
};
function warnIfReactDOMContainerInDEV(_)
    local _ = _G.__DEV__;
end;
return v28;