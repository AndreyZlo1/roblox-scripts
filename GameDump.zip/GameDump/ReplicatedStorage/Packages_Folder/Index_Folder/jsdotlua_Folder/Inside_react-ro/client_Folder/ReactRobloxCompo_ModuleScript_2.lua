-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-roblox@17.1.0.react-roblox.client.ReactRobloxComponentTree
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent:WaitForChild("ReactRobloxHostTypes.roblox"));
require(script.Parent.Parent.Parent:WaitForChild("react-reconciler"));
local l__shared__1 = require(script.Parent.Parent.Parent:WaitForChild("shared"));
local u1 = nil;
local u2 = nil;
local u3 = nil;
local u4 = nil;
local u5 = nil;
local u6 = nil;
local l__invariant__2 = l__shared__1.invariant;
local v7 = {};
local u8 = {};
local u9 = {};
local u10 = {};
local v11 = tostring(math.random());
local v12 = string.sub(v11, 3);
local u13 = "__reactFiber$" .. v12;
local u14 = "__reactContainer$" .. v12;
function v7.precacheFiberNode(p15, p16) --[[ Line: 65 ]]
    -- upvalues: u9 (copy)
    u9[p16] = p15;
end;
function v7.uncacheFiberNode(p17) --[[ Line: 70 ]]
    -- upvalues: u9 (copy), u10 (copy)
    u9[p17] = nil;
    u10[p17] = nil;
end;
function v7.markContainerAsRoot(p18, p19) --[[ Line: 75 ]]
    -- upvalues: u8 (copy)
    u8[p19] = p18;
end;
function v7.unmarkContainerAsRoot(p20) --[[ Line: 81 ]]
    -- upvalues: u8 (copy)
    u8[p20] = nil;
end;
function v7.isContainerMarkedAsRoot(p21) --[[ Line: 87 ]]
    -- upvalues: u8 (copy)
    return u8[p21] and true or false;
end;
function v7.getClosestInstanceFromNode(p22) --[[ Line: 101 ]]
    -- upvalues: u9 (copy), u6 (ref)
    local v23 = u9[p22];
    if v23 then
        return v23;
    end;
    local l__Parent__3 = p22.Parent;
    while l__Parent__3 do
        local v24 = u9[l__Parent__3];
        if v24 then
            local l__alternate__4 = v24.alternate;
            if v24.child ~= nil or l__alternate__4 ~= nil and l__alternate__4.child ~= nil then
                if u6 == nil then
                    u6 = require(script.Parent.ReactRobloxHostConfig).getParentSuspenseInstance;
                end;
                local v25 = u6(p22);
                while v25 ~= nil do
                    local v26 = u9[v25];
                    if v26 then
                        return v26;
                    end;
                    v25 = u6(v25);
                end;
            end;
            return v24;
        end;
        local l__Parent__5 = l__Parent__3.Parent;
        p22 = l__Parent__3;
        l__Parent__3 = l__Parent__5;
    end;
    return nil;
end;
function v7.getInstanceFromNode(p27) --[[ Line: 185 ]]
    -- upvalues: u1 (ref), u2 (ref), u3 (ref), u4 (ref), u5 (ref), u13 (copy), u14 (copy)
    if u1 == nil then
        u1 = require(script.Parent.Parent:WaitForChild("ReactReconciler.roblox")).ReactWorkTags;
        u2 = u1.HostComponent;
        u3 = u1.HostComponent;
        u4 = u1.HostComponent;
        u5 = u1.HostComponent;
    end;
    local v28 = p27[u13] or p27[u14];
    if v28 then
        if v28.tag == u2 or (v28.tag == u3 or (v28.tag == u5 or v28.tag == u4)) then
            return v28;
        else
            return nil;
        end;
    else
        return nil;
    end;
end;
function v7.getNodeFromInstance(p29) --[[ Line: 218 ]]
    -- upvalues: u2 (ref), u3 (ref), l__invariant__2 (copy)
    if p29.tag == u2 or p29.tag == u3 then
        return p29.stateNode;
    end;
    l__invariant__2(false, "getNodeFromInstance: Invalid argument.");
    error("getNodeFromInstance: Invalid argument.");
end;
function v7.getFiberCurrentPropsFromNode(p30) --[[ Line: 233 ]]
    -- upvalues: u10 (copy)
    return u10[p30];
end;
function v7.updateFiberProps(p31, p32) --[[ Line: 237 ]]
    -- upvalues: u10 (copy)
    u10[p31] = p32;
end;
return v7;