-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-roblox@17.1.0.react-roblox.client.ReactRobloxHostTypes.roblox
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent.Parent:WaitForChild("react-reconciler"));
require(script.Parent.Parent.Parent:WaitForChild("shared"));
return {};