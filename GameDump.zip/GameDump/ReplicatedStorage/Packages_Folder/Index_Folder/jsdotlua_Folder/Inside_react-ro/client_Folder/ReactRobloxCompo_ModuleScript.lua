-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-roblox@17.1.0.react-roblox.client.ReactRobloxComponent
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Object__1 = require(script.Parent.Parent.Parent:WaitForChild("luau-polyfill")).Object;
local l__RobloxComponentProps__2 = require(script.Parent:WaitForChild("roblox"):WaitForChild("RobloxComponentProps"));
require(script.Parent:WaitForChild("ReactRobloxHostTypes.roblox"));
return {
    setInitialProperties = l__RobloxComponentProps__2.setInitialProperties,
    diffProperties = function(_, _, p1, p2, _) --[[ Name: diffProperties, Line 31 ]]
        -- upvalues: l__Object__1 (copy)
        local v3 = nil;
        for v4, _ in p1 do
            if p2[v4] == nil then
                v3 = v3 or table.create(2);
                table.insert(v3, v4);
                table.insert(v3, l__Object__1.None);
            end;
        end;
        for v5, v6 in p2 do
            local v7;
            if p1 == nil then
                v7 = nil;
            else
                v7 = p1[v5];
            end;
            if v6 ~= v7 then
                v3 = v3 or table.create(2);
                table.insert(v3, v5);
                table.insert(v3, v6);
            end;
        end;
        return v3;
    end,
    updateProperties = l__RobloxComponentProps__2.updateProperties,
    cleanupHostComponent = l__RobloxComponentProps__2.cleanupHostComponent
};