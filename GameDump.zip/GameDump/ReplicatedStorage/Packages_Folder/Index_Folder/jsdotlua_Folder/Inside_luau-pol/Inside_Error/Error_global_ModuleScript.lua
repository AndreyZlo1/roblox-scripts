-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_luau-polyfill@1.2.7.luau-polyfill.Error.Error.global
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
local u1 = {};
u1.__index = u1;
function u1.__tostring(p2) --[[ Line: 12 ]]
    -- upvalues: u1 (copy)
    return getmetatable(u1).__tostring(p2);
end;
function u1.new(p3) --[[ Line: 27 ]]
    -- upvalues: u1 (copy)
    local v4 = setmetatable({
        name = "Error",
        message = p3 or ""
    }, u1);
    u1.__captureStackTrace(v4, 4);
    return v4;
end;
function u1.captureStackTrace(p5, p6) --[[ Line: 31 ]]
    -- upvalues: u1 (copy)
    u1.__captureStackTrace(p5, 3, p6);
end;
function u1.__captureStackTrace(p7, p8, p9) --[[ Line: 35 ]]
    -- upvalues: u1 (copy)
    if typeof(p9) == "function" then
        local v10 = debug.traceback(nil, p8);
        local v11 = debug.info(p9, "n");
        local v12 = debug.info(p9, "s");
        local v13 = string.gsub(v12, "([%(%)%.%%%+%-%*%?%[%^%$])", "%%%1") .. ":%d* function " .. v11;
        local v14 = string.find(v10, v13);
        local v15;
        if v14 == nil then
            v15 = nil;
        else
            local v16;
            v16, v15 = string.find(v10, "\n", v14 + 1);
        end;
        if v15 ~= nil then
            v10 = string.sub(v10, v15 + 1);
        end;
        p7.__stack = v10;
    else
        p7.__stack = debug.traceback(nil, p8);
    end;
    u1.__recalculateStacktrace(p7);
end;
function u1.__recalculateStacktrace(p17) --[[ Line: 59 ]]
    local l__message__1 = p17.message;
    p17.stack = ((p17.name or "Error") .. ((l__message__1 == nil or l__message__1 == "") and "" or ": " .. l__message__1)) .. "\n" .. (not p17.__stack and "" or p17.__stack);
end;
return setmetatable(u1, {
    __call = function(_, ...) --[[ Name: __call, Line 71 ]]
        -- upvalues: u1 (copy)
        local v18 = setmetatable({
            name = "Error",
            message = ... or ""
        }, u1);
        u1.__captureStackTrace(v18, 4);
        return v18;
    end,
    __tostring = function(p19) --[[ Name: __tostring, Line 74 ]]
        if p19.name == nil then
            return tostring("Error");
        elseif p19.message and p19.message ~= "" then
            return string.format("%s: %s", tostring(p19.name), (tostring(p19.message)));
        else
            return tostring(p19.name);
        end;
    end
});