-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_luau-polyfill@1.2.7.luau-polyfill.AssertionError.AssertionError.global
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__collections__1 = require(script.Parent.Parent.Parent:WaitForChild("collections"));
local l__Array__2 = l__collections__1.Array;
local l__Object__3 = l__collections__1.Object;
local l__boolean__4 = require(script.Parent.Parent.Parent:WaitForChild("boolean"));
local l__string__5 = require(script.Parent.Parent.Parent:WaitForChild("string"));
require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
local l__inspect__6 = l__collections__1.inspect;
local l__Error__7 = require(script.Parent.Parent:WaitForChild("Error"));
local u1 = require(script.Parent.Parent.Parent:WaitForChild("instance-of"));
local u2 = {
    stderr = {
        isTTY = false,
        columns = 0,
        hasColors = function(...) --[[ Name: hasColors, Line 45 ]]
            return true;
        end
    }
};
function ErrorCaptureStackTrace(p3, ...)
    -- upvalues: l__Error__7 (copy)
    l__Error__7.captureStackTrace(p3, ...);
end;
local u4 = "";
local u5 = "";
local u6 = "";
local u7 = "";
local u8 = {
    deepStrictEqual = "Expected values to be strictly deep-equal:",
    strictEqual = "Expected values to be strictly equal:",
    strictEqualObject = "Expected \"actual\" to be reference-equal to \"expected\":",
    deepEqual = "Expected values to be loosely deep-equal:",
    notDeepStrictEqual = "Expected \"actual\" not to be strictly deep-equal to:",
    notStrictEqual = "Expected \"actual\" to be strictly unequal to:",
    notStrictEqualObject = "Expected \"actual\" not to be reference-equal to \"expected\":",
    notDeepEqual = "Expected \"actual\" not to be loosely deep-equal to:",
    notIdentical = "Values have same structure but are not reference-equal:",
    notDeepEqualUnequal = "Expected values not to be loosely deep-equal:"
};
local function u41(p9, p10, p11) --[[ Line: 111 ]]
    -- upvalues: l__inspect__6 (copy), l__string__5 (copy), l__boolean__4 (copy), u8 (copy), u2 (copy), u4 (ref), u7 (ref), l__Array__2 (copy), u5 (ref), u6 (ref)
    local v12 = "";
    local v13 = "";
    local v14 = "";
    local v15 = false;
    local v16 = l__inspect__6(p9, {
        compact = false,
        customInspect = false,
        depth = 1000,
        maxArrayLength = (1 / 0),
        showHidden = false,
        showProxy = false,
        sorted = true,
        getters = true
    });
    local v17 = l__string__5.split(v16, "\n");
    local v18 = l__string__5.split(l__inspect__6(p10, {
        compact = false,
        customInspect = false,
        depth = 1000,
        maxArrayLength = (1 / 0),
        showHidden = false,
        showProxy = false,
        sorted = true,
        getters = true
    }), "\n");
    local v19 = 0;
    local v20 = "";
    local v21 = p11 == "strictEqual" and (typeof(p9) == "table" and (p9 ~= nil and (typeof(p10) == "table" and p10 ~= nil)) or typeof(p9) == "function" and typeof(p10) == "function") and "strictEqualObject" or p11;
    if #v17 == 1 and (#v18 == 1 and v17[1] ~= v18[1]) then
        local v22 = v17[1];
        local v23;
        if l__boolean__4.toJSBoolean(false) then
            v23 = v18[1];
        else
            v23 = v18[1];
        end;
        local v24 = string.len(v22) + string.len(v23);
        if v24 <= 12 then
            if (typeof(p9) ~= "table" or p9 == nil) and ((typeof(p10) ~= "table" or p10 == nil) and (p9 ~= 0 or p10 ~= 0)) then
                return ("%s\n\n"):format(u8[v21]) .. ("%s !== %s\n"):format(v17[1], v18[1]);
            end;
        elseif v21 ~= "strictEqualObject" and v24 < (not u2.stderr.isTTY and 80 or u2.stderr.columns) then
            while string.sub(v22, v19 + 1, v19 + 1) == string.sub(v23, v19 + 1, v19 + 1) do
                v19 = v19 + 1;
            end;
            if v19 > 2 then
                v20 = ("\n  %s^"):format(string.rep(" ", v19));
                v19 = 0;
            end;
        end;
    end;
    local v25 = v17[#v17];
    local v26 = v18[#v18];
    local v27;
    while true do
        if v25 ~= v26 then
            v27 = v19;
            break;
        end;
        v27 = v19 + 1;
        if v19 < 3 then
            v14 = ("\n  %s%s"):format(v25, v14);
        else
            v12 = v25;
        end;
        table.remove(v17);
        table.remove(v18);
        if #v17 == 0 or #v18 == 0 then
            break;
        end;
        v25 = v17[#v17];
        v26 = v18[#v18];
        v19 = v27;
    end;
    local v28 = math.max(#v17, #v18);
    if v28 == 0 then
        local v29 = l__string__5.split(v16, "\n");
        if #v29 > 50 then
            v29[47] = ("%s...%s"):format(u4, u7);
            while #v29 > 47 do
                table.remove(v29);
            end;
        end;
        return ("%s\n\n"):format("Values have same structure but are not reference-equal:") .. ("%s\n"):format(l__Array__2.join(v29, "\n"));
    end;
    if v27 >= 5 then
        v14 = ("\n%s...%s%s"):format(u4, u7, v14);
        v15 = true;
    end;
    if v12 ~= "" then
        v14 = ("\n  %s%s"):format(v12, v14);
        v12 = "";
    end;
    local v30 = 0;
    local v31 = 0;
    local v32 = u8[v21] .. ("\n%s+ actual%s %s- expected%s"):format(u5, u7, u6, u7);
    local v33 = (" %s...%s Lines skipped"):format(u4, u7);
    local v34 = ("%s+%s"):format(u5, u7);
    local v35 = #v18;
    local v36;
    if #v17 < v28 then
        v34 = ("%s-%s"):format(u6, u7);
        v35 = #v17;
        v36 = v18;
    else
        v36 = v17;
    end;
    for v37 = 1, v28 do
        if v35 < v37 then
            if v31 > 2 then
                if v31 > 3 then
                    if v31 > 4 then
                        if v31 == 5 then
                            v13 = v13 .. ("\n  %s"):format(v36[v37 - 3]);
                            v30 = v30 + 1;
                        else
                            v13 = v13 .. ("\n%s...%s"):format(u4, u7);
                            v15 = true;
                        end;
                    end;
                    v13 = v13 .. ("\n  %s"):format(v36[v37 - 2]);
                    v30 = v30 + 1;
                end;
                v13 = v13 .. ("\n  %s"):format(v36[v37 - 1]);
                v30 = v30 + 1;
            end;
            v31 = 0;
            if v36 == v17 then
                v13 = v13 .. ("\n%s %s"):format(v34, v36[v37]);
            else
                v12 = v12 .. ("\n%s %s"):format(v34, v36[v37]);
            end;
            v30 = v30 + 1;
        else
            local v38 = v18[v37];
            local v39 = v17[v37];
            local v40;
            if v39 == v38 then
                v40 = false;
            else
                v40 = not l__boolean__4.toJSBoolean(l__string__5.endsWith(v39, ",")) or l__string__5.slice(v39, 0, -1) ~= v38;
            end;
            if v40 and (l__string__5.endsWith(v38, ",") and l__string__5.slice(v38, 0, -1) == v39) then
                v39 = v39 .. ",";
                v40 = false;
            end;
            if v40 then
                if v31 > 2 then
                    if v31 > 3 then
                        if v31 > 4 then
                            if v31 == 5 then
                                v13 = v13 .. ("\n  %s"):format(v17[v37 - 3]);
                                v30 = v30 + 1;
                            else
                                v13 = v13 .. ("\n%s...%s"):format(u4, u7);
                                v15 = true;
                            end;
                        end;
                        v13 = v13 .. ("\n  %s"):format(v17[v37 - 2]);
                        v30 = v30 + 1;
                    end;
                    v13 = v13 .. ("\n  %s"):format(v17[v37 - 1]);
                    v30 = v30 + 1;
                end;
                v13 = v13 .. ("\n%s+%s %s"):format(u5, u7, v39);
                v12 = v12 .. ("\n%s-%s %s"):format(u6, u7, v38);
                v30 = v30 + 2;
                v31 = 0;
            else
                v13 = v13 .. v12;
                v12 = "";
                v31 = v31 + 1;
                if v31 <= 2 then
                    v13 = v13 .. ("\n  %s"):format(v39);
                    v30 = v30 + 1;
                end;
            end;
        end;
        if v30 > 50 and v37 < v28 - 2 then
            return ("%s%s\n%s\n%s...%s%s\n"):format(v32, v33, v13, u4, u7, v12) .. ("%s...%s"):format(u4, u7);
        end;
    end;
    return ("%s%s\n%s%s%s%s"):format(v32, not v15 and "" or v33, v13, v12, v14, v20);
end;
local u42 = setmetatable({}, {
    __index = l__Error__7
});
u42.__index = u42;
function u42.__tostring(p43) --[[ Line: 391 ]]
    return p43:toString();
end;
function u42.new(p44) --[[ Line: 404 ]]
    -- upvalues: l__Error__7 (copy), u42 (copy), u2 (copy), u4 (ref), u5 (ref), u7 (ref), u6 (ref), l__Array__2 (copy), l__Object__3 (copy), u1 (copy), u41 (copy), u8 (copy), l__string__5 (copy), l__inspect__6 (copy), l__boolean__4 (copy)
    local l__message__8 = p44.message;
    local l__operator__9 = p44.operator;
    local l__stackStartFn__10 = p44.stackStartFn;
    local l__actual__11 = p44.actual;
    local l__expected__12 = p44.expected;
    local v45;
    if l__message__8 == nil then
        if u2.stderr.isTTY then
            if u2.stderr:hasColors() then
                u4 = "\27[34m";
                u5 = "\27[32m";
                u7 = "\27[39m";
                u6 = "\27[31m";
            else
                u4 = "";
                u5 = "";
                u7 = "";
                u6 = "";
            end;
        end;
        local v46, v47;
        if typeof(l__actual__11) == "table" and (l__actual__11 ~= nil and (typeof(l__expected__12) == "table" and (l__expected__12 ~= nil and (l__Array__2.indexOf(l__Object__3.keys(l__actual__11), "stack") ~= -1 and (u1(l__actual__11, l__Error__7) and (l__Array__2.indexOf(l__Object__3.keys(l__expected__12), "stack") ~= -1 and u1(l__expected__12, l__Error__7))))))) then
            v46 = {};
            for _, v48 in l__Object__3.keys(l__actual__11) do
                v46[v48] = l__actual__11[v48];
            end;
            v46.message = l__actual__11.message;
            v47 = {};
            for _, v49 in l__Object__3.keys(l__expected__12) do
                v47[v49] = l__expected__12[v49];
            end;
            v47.message = l__expected__12.message;
        else
            v47 = l__expected__12;
            v46 = l__actual__11;
        end;
        if l__operator__9 == "deepStrictEqual" or l__operator__9 == "strictEqual" then
            local v50 = l__Error__7.new(u41(v46, v47, l__operator__9));
            v45 = setmetatable(v50, u42);
            l__expected__12 = v47;
            l__actual__11 = v46;
        elseif l__operator__9 == "notDeepStrictEqual" or l__operator__9 == "notStrictEqual" then
            local v51 = u8[l__operator__9];
            local v52 = l__string__5.split(l__inspect__6(v46, {
                compact = false,
                customInspect = false,
                depth = 1000,
                maxArrayLength = (1 / 0),
                showHidden = false,
                showProxy = false,
                sorted = true,
                getters = true
            }), "\n");
            local v53 = l__operator__9 == "notStrictEqual" and (typeof(v46) == "table" and v46 ~= nil or typeof(v46) == "function") and "Expected \"actual\" not to be reference-equal to \"expected\":" or v51;
            if #v52 > 50 then
                v52[47] = ("%s...%s"):format(u4, u7);
                while #v52 > 47 do
                    table.remove(v52);
                end;
            end;
            if #v52 == 1 then
                local v54 = l__Error__7.new(("%s%s%s"):format(v53, string.len(v52[1]) > 5 and "\n\n" or " ", v52[1]));
                v45 = setmetatable(v54, u42);
                l__expected__12 = v47;
                l__actual__11 = v46;
            else
                local v55 = l__Error__7.new(("%s\n\n%s\n"):format(v53, l__Array__2.join(v52, "\n")));
                v45 = setmetatable(v55, u42);
                l__expected__12 = v47;
                l__actual__11 = v46;
            end;
        else
            local v56 = l__inspect__6(v46, {
                compact = false,
                customInspect = false,
                depth = 1000,
                maxArrayLength = (1 / 0),
                showHidden = false,
                showProxy = false,
                sorted = true,
                getters = true
            });
            local v57 = l__inspect__6(v47, {
                compact = false,
                customInspect = false,
                depth = 1000,
                maxArrayLength = (1 / 0),
                showHidden = false,
                showProxy = false,
                sorted = true,
                getters = true
            });
            local v58 = u8[tostring(l__operator__9)];
            if l__operator__9 == "notDeepEqual" and v56 == v57 then
                local v59 = ("%s\n\n%s"):format(v58, v56);
                if string.len(v59) > 1024 then
                    v59 = ("%s..."):format(l__string__5.slice(v59, 0, 1021));
                end;
                local v60 = l__Error__7.new(v59);
                v45 = setmetatable(v60, u42);
                l__expected__12 = v47;
                l__actual__11 = v46;
            else
                if string.len(v56) > 512 then
                    v56 = ("%s..."):format(l__string__5.slice(v56, 0, 509));
                end;
                if string.len(v57) > 512 then
                    v57 = ("%s..."):format(l__string__5.slice(v57, 0, 509));
                end;
                if l__operator__9 == "deepEqual" then
                    v56 = ("%s\n\n%s\n\nshould loosely deep-equal\n\n"):format(v58, v56);
                else
                    local v61 = u8[("%sUnequal"):format((tostring(l__operator__9)))];
                    if l__boolean__4.toJSBoolean(v61) then
                        v56 = ("%s\n\n%s\n\nshould not loosely deep-equal\n\n"):format(v61, v56);
                    else
                        v57 = (" %s %s"):format(tostring(l__operator__9), v57);
                    end;
                end;
                local v62 = l__Error__7.new(("%s%s"):format(v56, v57));
                v45 = setmetatable(v62, u42);
                l__expected__12 = v47;
                l__actual__11 = v46;
            end;
        end;
    else
        local v63 = l__Error__7.new((tostring(l__message__8)));
        v45 = setmetatable(v63, u42);
    end;
    v45.generatedMessage = not l__boolean__4.toJSBoolean(l__message__8);
    v45.name = "AssertionError [ERR_ASSERTION]";
    v45.code = "ERR_ASSERTION";
    v45.actual = l__actual__11;
    v45.expected = l__expected__12;
    v45.operator = l__operator__9;
    ErrorCaptureStackTrace(v45, l__stackStartFn__10 or u42.new);
    v45.name = "AssertionError";
    return v45;
end;
function u42.toString(p64) --[[ Line: 573 ]]
    return ("%s [%s]: %s"):format(p64.name, p64.code, p64.message);
end;
u42.name = "AssertionError";
return {
    AssertionError = u42
};