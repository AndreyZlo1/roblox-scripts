-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.ReactFiberHostConfig.WithNoPersistence
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__invariant__1 = require(script.Parent.Parent:WaitForChild("invariant"));
local function v1(...) --[[ Line: 16 ]]
    -- upvalues: l__invariant__1 (copy)
    l__invariant__1(false, "The current renderer does not support persistence. This error is likely caused by a bug in React. Please file an issue.");
end;
return {
    supportsPersistence = false,
    cloneInstance = v1,
    cloneFundamentalInstance = v1,
    createContainerChildSet = v1,
    appendChildToContainerChildSet = v1,
    finalizeContainerChildren = v1,
    replaceContainerChildren = v1,
    cloneHiddenInstance = v1,
    cloneHiddenTextInstance = v1
};