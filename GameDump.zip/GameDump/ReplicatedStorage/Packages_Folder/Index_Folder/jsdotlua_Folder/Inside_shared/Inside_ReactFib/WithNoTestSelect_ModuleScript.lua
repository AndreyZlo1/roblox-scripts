-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.ReactFiberHostConfig.WithNoTestSelectors
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__invariant__1 = require(script.Parent.Parent:WaitForChild("invariant"));
local function v1(...) --[[ Line: 16 ]]
    -- upvalues: l__invariant__1 (copy)
    l__invariant__1(false, "The current renderer does not support test selectors. This error is likely caused by a bug in React. Please file an issue.");
end;
return {
    supportsTestSelectors = false,
    findFiberRoot = v1,
    getBoundingRect = v1,
    getTextContent = v1,
    isHiddenSubtree = v1,
    matchAccessibilityRole = v1,
    setFocusIfFocusable = v1,
    setupIntersectionObserver = v1
};