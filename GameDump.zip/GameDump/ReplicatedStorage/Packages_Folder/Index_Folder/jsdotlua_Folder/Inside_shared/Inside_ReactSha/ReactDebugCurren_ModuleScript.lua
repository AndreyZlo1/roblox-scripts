-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.ReactSharedInternals.ReactDebugCurrentFrame
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {};
local u2 = nil;
function u1.setExtraStackFrame(p3) --[[ Line: 16 ]]
    -- upvalues: u2 (ref)
    if _G.__DEV__ then
        u2 = p3;
    end;
end;
if _G.__DEV__ then
    u1.getCurrentStack = nil;
    function u1.getStackAddendum() --[[ Line: 33 ]]
        -- upvalues: u2 (ref), u1 (copy)
        local v4 = "";
        if u2 then
            v4 = v4 .. u2;
        end;
        local l__getCurrentStack__1 = u1.getCurrentStack;
        if l__getCurrentStack__1 then
            v4 = v4 .. (l__getCurrentStack__1() or "");
        end;
        return v4;
    end;
end;
return u1;