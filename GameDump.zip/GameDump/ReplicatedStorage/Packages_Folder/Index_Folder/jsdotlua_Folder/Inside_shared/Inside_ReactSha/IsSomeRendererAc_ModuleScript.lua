-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.ReactSharedInternals.IsSomeRendererActing
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    current = false
};