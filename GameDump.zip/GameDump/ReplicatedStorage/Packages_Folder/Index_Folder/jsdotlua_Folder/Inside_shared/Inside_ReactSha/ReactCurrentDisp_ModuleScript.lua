-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.ReactSharedInternals.ReactCurrentDispatcher
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent.Parent:WaitForChild("luau-polyfill"));
require(script.Parent.Parent:WaitForChild("ReactElementType"));
require(script.Parent.Parent:WaitForChild("ReactTypes"));
return {
    current = nil
};