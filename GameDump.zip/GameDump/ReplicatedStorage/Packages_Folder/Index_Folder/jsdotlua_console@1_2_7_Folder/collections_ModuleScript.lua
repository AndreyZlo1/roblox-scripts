-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_console@1.2.7.collections
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent.Parent["jsdotlua_collections@1.2.7"].collections);