-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_console@1.2.7.console
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script:WaitForChild("makeConsoleImpl"))();