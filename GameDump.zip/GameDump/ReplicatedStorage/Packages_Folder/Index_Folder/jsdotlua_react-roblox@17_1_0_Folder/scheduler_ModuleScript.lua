-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-roblox@17.1.0.scheduler
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent.Parent["jsdotlua_scheduler@17.1.0"].scheduler);