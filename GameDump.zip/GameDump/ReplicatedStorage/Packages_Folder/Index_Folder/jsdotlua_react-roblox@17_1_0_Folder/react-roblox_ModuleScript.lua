-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_react-roblox@17.1.0.react-roblox
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script:WaitForChild("client"):WaitForChild("ReactRobloxHostTypes.roblox"));
return require(script:WaitForChild("client"):WaitForChild("ReactRoblox"));