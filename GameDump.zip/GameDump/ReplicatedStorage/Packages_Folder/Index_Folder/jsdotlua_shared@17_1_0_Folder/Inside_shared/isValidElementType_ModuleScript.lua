-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.isValidElementType
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReactSymbols__1 = require(script.Parent:WaitForChild("ReactSymbols"));
local l__REACT_CONTEXT_TYPE__2 = l__ReactSymbols__1.REACT_CONTEXT_TYPE;
local l__REACT_FORWARD_REF_TYPE__3 = l__ReactSymbols__1.REACT_FORWARD_REF_TYPE;
local l__REACT_FRAGMENT_TYPE__4 = l__ReactSymbols__1.REACT_FRAGMENT_TYPE;
local l__REACT_PROFILER_TYPE__5 = l__ReactSymbols__1.REACT_PROFILER_TYPE;
local l__REACT_PROVIDER_TYPE__6 = l__ReactSymbols__1.REACT_PROVIDER_TYPE;
local l__REACT_DEBUG_TRACING_MODE_TYPE__7 = l__ReactSymbols__1.REACT_DEBUG_TRACING_MODE_TYPE;
local l__REACT_STRICT_MODE_TYPE__8 = l__ReactSymbols__1.REACT_STRICT_MODE_TYPE;
local l__REACT_SUSPENSE_TYPE__9 = l__ReactSymbols__1.REACT_SUSPENSE_TYPE;
local l__REACT_MEMO_TYPE__10 = l__ReactSymbols__1.REACT_MEMO_TYPE;
local l__REACT_LAZY_TYPE__11 = l__ReactSymbols__1.REACT_LAZY_TYPE;
local l__REACT_FUNDAMENTAL_TYPE__12 = l__ReactSymbols__1.REACT_FUNDAMENTAL_TYPE;
local l__REACT_BLOCK_TYPE__13 = l__ReactSymbols__1.REACT_BLOCK_TYPE;
local l__REACT_SERVER_BLOCK_TYPE__14 = l__ReactSymbols__1.REACT_SERVER_BLOCK_TYPE;
local l__REACT_LEGACY_HIDDEN_TYPE__15 = l__ReactSymbols__1.REACT_LEGACY_HIDDEN_TYPE;
return function(p1) --[[ Line: 31 ]]
    -- upvalues: l__REACT_FRAGMENT_TYPE__4 (copy), l__REACT_PROFILER_TYPE__5 (copy), l__REACT_DEBUG_TRACING_MODE_TYPE__7 (copy), l__REACT_STRICT_MODE_TYPE__8 (copy), l__REACT_SUSPENSE_TYPE__9 (copy), l__REACT_LEGACY_HIDDEN_TYPE__15 (copy), l__REACT_LAZY_TYPE__11 (copy), l__REACT_MEMO_TYPE__10 (copy), l__REACT_PROVIDER_TYPE__6 (copy), l__REACT_CONTEXT_TYPE__2 (copy), l__REACT_FORWARD_REF_TYPE__3 (copy), l__REACT_FUNDAMENTAL_TYPE__12 (copy), l__REACT_BLOCK_TYPE__13 (copy), l__REACT_SERVER_BLOCK_TYPE__14 (copy)
    local v2 = typeof(p1);
    if v2 == "string" or v2 == "function" then
        return true;
    end;
    if p1 == l__REACT_FRAGMENT_TYPE__4 or (p1 == l__REACT_PROFILER_TYPE__5 or (p1 == l__REACT_DEBUG_TRACING_MODE_TYPE__7 or (p1 == l__REACT_STRICT_MODE_TYPE__8 or (p1 == l__REACT_SUSPENSE_TYPE__9 or p1 == l__REACT_LEGACY_HIDDEN_TYPE__15)))) then
        return true;
    end;
    if v2 == "table" then
        if p1.isReactComponent then
            return true;
        end;
        if p1["$$typeof"] == l__REACT_LAZY_TYPE__11 or (p1["$$typeof"] == l__REACT_MEMO_TYPE__10 or (p1["$$typeof"] == l__REACT_PROVIDER_TYPE__6 or (p1["$$typeof"] == l__REACT_CONTEXT_TYPE__2 or (p1["$$typeof"] == l__REACT_FORWARD_REF_TYPE__3 or (p1["$$typeof"] == l__REACT_FUNDAMENTAL_TYPE__12 or (p1["$$typeof"] == l__REACT_BLOCK_TYPE__13 or p1[1] == l__REACT_SERVER_BLOCK_TYPE__14)))))) then
            return true;
        end;
    end;
    return false;
end;