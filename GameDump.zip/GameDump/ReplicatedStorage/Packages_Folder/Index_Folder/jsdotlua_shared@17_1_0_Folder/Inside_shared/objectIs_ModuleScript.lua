-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.objectIs
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function(p1, p2) --[[ Name: is, Line 16 ]]
    local v3;
    if p1 == p2 and (p1 ~= 0 or 1 / p1 == 1 / p2) then
        v3 = true;
    elseif p1 == p1 then
        v3 = false;
    else
        v3 = p2 ~= p2;
    end;
    return v3;
end;