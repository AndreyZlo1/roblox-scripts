-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.Symbol.roblox
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    named = function(p1) --[[ Name: named, Line 30 ]]
        local v2 = type(p1) == "string";
        assert(v2, "Symbols must be created using a string name!");
        local v3 = newproxy(true);
        local u4 = string.format("Symbol(%s)", p1);
        getmetatable(v3).__tostring = function() --[[ Line: 37 ]]
            -- upvalues: u4 (copy)
            return u4;
        end;
        return v3;
    end
};