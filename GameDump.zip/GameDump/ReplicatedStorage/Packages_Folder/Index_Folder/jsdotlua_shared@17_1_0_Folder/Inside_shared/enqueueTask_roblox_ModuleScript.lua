-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.enqueueTask.roblox
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__setTimeout__1 = require(script.Parent.Parent:WaitForChild("luau-polyfill")).setTimeout;
return function(p1) --[[ Line: 13 ]]
    -- upvalues: l__setTimeout__1 (copy)
    return l__setTimeout__1(p1, 0);
end;