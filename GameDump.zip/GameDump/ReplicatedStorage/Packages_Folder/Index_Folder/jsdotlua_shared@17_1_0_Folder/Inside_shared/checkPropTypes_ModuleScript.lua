-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.checkPropTypes
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Error__1 = require(script.Parent.Parent:WaitForChild("luau-polyfill")).Error;
local l__console__2 = require(script.Parent:WaitForChild("console"));
local u1 = {};
local l__describeUnknownElementTypeFrameInDEV__3 = require(script.Parent:WaitForChild("ReactComponentStackFrame")).describeUnknownElementTypeFrameInDEV;
local l__ReactSharedInternals__4 = require(script.Parent:WaitForChild("ReactSharedInternals"));
local l__describeError__5 = require(script.Parent:WaitForChild("ErrorHandling.roblox")).describeError;
local l__ReactDebugCurrentFrame__6 = l__ReactSharedInternals__4.ReactDebugCurrentFrame;
return function(u2, p3, u4, u5, u6, p7) --[[ Name: checkPropTypes, Line 49 ]]
    -- upvalues: l__console__2 (copy), l__Error__1 (copy), l__describeError__5 (copy), l__describeUnknownElementTypeFrameInDEV__3 (copy), l__ReactDebugCurrentFrame__6 (copy), u1 (copy)
    if _G.__DEV__ or _G.__DISABLE_ALL_WARNINGS_EXCEPT_PROP_VALIDATION__ then
        if u2 and p3 then
            l__console__2.warn("You\'ve defined both propTypes and validateProps on " .. (u6 or "a component"));
        end;
        if p3 then
            if typeof(p3) == "function" then
                local v8, v9 = p3(u4);
                if not v8 then
                    local v10 = string.format("validateProps failed on a %s type in %s: %s", u5, u6 or "<UNKNOWN Component>", (tostring(v9 or "<Validator function did not supply a message>")));
                    error(v10);
                end;
            else
                l__console__2.error(("validateProps must be a function, but it is a %s.\nCheck the definition of the component %q."):format(typeof(p3), u6 or ""));
            end;
        end;
        if u2 then
            local v11 = typeof(u2) == "table";
            assert(v11, "propTypes needs to be a table");
            for u12, _ in u2 do
                local _, v14 = xpcall(function() --[[ Line: 113 ]]
                    -- upvalues: u2 (copy), u12 (copy), l__Error__1 (ref), u6 (copy), u5 (copy), u4 (copy)
                    if typeof(u2[u12]) ~= "function" then
                        local v13 = l__Error__1.new((u6 or "React class") .. ": " .. u5 .. " type `" .. u12 .. "` is invalid; " .. "it must be a function, usually from the `prop-types` package, but received `" .. typeof(u2[u12]) .. "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
                        v13.name = "Invariant Violation";
                        error(v13);
                    end;
                    return u2[u12](u4, u12, u6, u5, nil, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
                end, l__describeError__5);
                local v15 = typeof(v14) == "table";
                if v14 ~= nil and not v15 then
                    if _G.__DEV__ then
                        if p7 then
                            local l___owner__7 = p7._owner;
                            local v16 = l__describeUnknownElementTypeFrameInDEV__3;
                            local l__type__8 = p7.type;
                            local l___source__9 = p7._source;
                            local v17;
                            if l___owner__7 == nil then
                                v17 = nil;
                            else
                                v17 = l___owner__7.type;
                            end;
                            local v18 = v16(l__type__8, l___source__9, v17);
                            l__ReactDebugCurrentFrame__6.setExtraStackFrame(v18);
                        else
                            l__ReactDebugCurrentFrame__6.setExtraStackFrame(nil);
                        end;
                    end;
                    l__console__2.error(string.format("%s: type specification of %s `%s` is invalid; the type checker function must return `nil` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", u6 or "React class", u5, u12, (typeof(v14))));
                    if _G.__DEV__ then
                        l__ReactDebugCurrentFrame__6.setExtraStackFrame(nil);
                    end;
                end;
                if v15 and u1[v14.message] == nil then
                    u1[tostring(v14.message)] = true;
                    if _G.__DEV__ then
                        if p7 then
                            local l___owner__10 = p7._owner;
                            local v19 = l__describeUnknownElementTypeFrameInDEV__3;
                            local l__type__11 = p7.type;
                            local l___source__12 = p7._source;
                            local v20;
                            if l___owner__10 == nil then
                                v20 = nil;
                            else
                                v20 = l___owner__10.type;
                            end;
                            local v21 = v19(l__type__11, l___source__12, v20);
                            l__ReactDebugCurrentFrame__6.setExtraStackFrame(v21);
                        else
                            l__ReactDebugCurrentFrame__6.setExtraStackFrame(nil);
                        end;
                    end;
                    l__console__2.warn(string.format("Failed %s type: %s", u5, (tostring(v14.message))));
                    if _G.__DEV__ then
                        l__ReactDebugCurrentFrame__6.setExtraStackFrame(nil);
                    end;
                end;
            end;
        end;
    end;
end;