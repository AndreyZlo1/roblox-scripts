-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.invariant
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Error__1 = require(script.Parent.Parent:WaitForChild("luau-polyfill")).Error;
return function(p1, p2, ...) --[[ Name: invariant, Line 24 ]]
    -- upvalues: l__Error__1 (copy)
    if not p1 then
        error(l__Error__1(string.format(p2, ...)));
    end;
end;