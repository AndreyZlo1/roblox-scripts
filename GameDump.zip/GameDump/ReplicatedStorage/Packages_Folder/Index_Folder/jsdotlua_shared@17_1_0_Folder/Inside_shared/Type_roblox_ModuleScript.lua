-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.Type.roblox
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = require(script.Parent:WaitForChild("Symbol.roblox"));
local u2 = newproxy(true);
local v4 = {
    HostChangeEvent = v1.named("RoactHostChangeEvent"),
    HostEvent = v1.named("RoactHostEvent"),
    of = function(p3) --[[ Name: of, Line 39 ]]
        -- upvalues: u2 (copy)
        if typeof(p3) == "table" then
            return p3[u2];
        else
            return nil;
        end;
    end
};
getmetatable(u2).__index = v4;
getmetatable(u2).__tostring = function() --[[ Line: 49 ]]
    return "RoactType";
end;
return u2;