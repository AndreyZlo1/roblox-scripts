-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.shallowEqual
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__objectIs__1 = require(script.Parent:WaitForChild("objectIs"));
return function(p1, p2) --[[ Name: shallowEqual, Line 18 ]]
    -- upvalues: l__objectIs__1 (copy)
    if l__objectIs__1(p1, p2) then
        return true;
    end;
    if typeof(p1) ~= "table" or (p1 == nil or (typeof(p2) ~= "table" or p2 == nil)) then
        return false;
    end;
    for v3, v4 in p1 do
        if not l__objectIs__1(p2[v3], v4) then
            return false;
        end;
    end;
    for v5, v6 in p2 do
        if not l__objectIs__1(p1[v5], v6) then
            return false;
        end;
    end;
    return true;
end;