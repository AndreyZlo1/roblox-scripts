-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.ReactFeatureFlags
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {
    enableFilterEmptyStringAttributesDOM = true,
    enableDebugTracing = false
};
local l____PROFILE____1 = _G.__PROFILE__;
if l____PROFILE____1 then
    l____PROFILE____1 = _G.__EXPERIMENTAL__;
end;
v1.enableSchedulingProfiler = l____PROFILE____1;
v1.debugRenderPhaseSideEffectsForStrictMode = _G.__DEV__;
v1.replayFailedUnitOfWorkWithInvokeGuardedCallback = _G.__DEV__;
v1.warnAboutDeprecatedLifecycles = true;
v1.enableProfilerTimer = _G.__PROFILE__;
v1.enableProfilerCommitHooks = false;
v1.enableSchedulerTracing = _G.__PROFILE__;
v1.enableSuspenseServerRenderer = _G.__EXPERIMENTAL__;
v1.enableSelectiveHydration = _G.__EXPERIMENTAL__;
v1.enableBlocksAPI = _G.__EXPERIMENTAL__;
v1.enableLazyElements = _G.__EXPERIMENTAL__;
v1.enableSchedulerDebugging = false;
v1.disableJavaScriptURLs = false;
v1.enableFundamentalAPI = false;
v1.enableScopeAPI = false;
v1.enableCreateEventHandleAPI = false;
v1.warnAboutUnmockedScheduler = false;
v1.enableSuspenseCallback = false;
v1.warnAboutDefaultPropsOnFunctionComponents = false;
v1.disableSchedulerTimeoutBasedOnReactExpirationTime = false;
v1.enableTrustedTypesIntegration = false;
v1.warnAboutSpreadingKeyToJSX = true;
v1.enableComponentStackLocations = true;
v1.enableNewReconciler = true;
v1.skipUnmountedBoundaries = true;
v1.disableInputAttributeSyncing = true;
v1.warnAboutStringRefs = false;
v1.disableLegacyContext = false;
v1.disableTextareaChildren = false;
v1.disableModulePatternComponents = false;
v1.warnUnstableRenderSubtreeIntoContainer = false;
v1.enableLegacyFBSupport = true;
v1.deferRenderPhaseUpdateToNextBatch = false;
v1.decoupleUpdatePriorityFromScheduler = true;
v1.enableDiscreteEventFlushingChange = false;
v1.enableEagerRootListeners = false;
v1.enableDoubleInvokingEffects = false;
return v1;