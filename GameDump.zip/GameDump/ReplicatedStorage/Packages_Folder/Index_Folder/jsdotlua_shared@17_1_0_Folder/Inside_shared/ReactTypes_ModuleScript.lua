-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.ReactTypes
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent:WaitForChild("luau-polyfill"));
require(script.Parent:WaitForChild("flowtypes.roblox"));
return {
    DiscreteEvent = 0,
    UserBlockingEvent = 1,
    ContinuousEvent = 2
};