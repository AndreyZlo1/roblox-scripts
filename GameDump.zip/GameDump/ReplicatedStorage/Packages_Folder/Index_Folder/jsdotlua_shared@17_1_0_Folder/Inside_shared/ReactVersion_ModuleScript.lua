-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.ReactVersion
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return "17.1.0";