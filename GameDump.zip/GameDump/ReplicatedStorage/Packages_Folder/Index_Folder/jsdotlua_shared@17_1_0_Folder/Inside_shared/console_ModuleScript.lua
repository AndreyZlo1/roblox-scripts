-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.console
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__console__1 = require(script.Parent.Parent:WaitForChild("luau-polyfill")).console;
local l__consoleWithStackDev__2 = require(script.Parent:WaitForChild("consoleWithStackDev"));
if _G.__DEV__ then
    return setmetatable({
        warn = l__consoleWithStackDev__2.warn,
        error = l__consoleWithStackDev__2.error
    }, {
        __index = l__console__1
    });
else
    return l__console__1;
end;