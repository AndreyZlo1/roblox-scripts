-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.getComponentName
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__console__1 = require(script.Parent:WaitForChild("console"));
local l__ReactSymbols__2 = require(script.Parent:WaitForChild("ReactSymbols"));
local l__REACT_CONTEXT_TYPE__3 = l__ReactSymbols__2.REACT_CONTEXT_TYPE;
local l__REACT_FORWARD_REF_TYPE__4 = l__ReactSymbols__2.REACT_FORWARD_REF_TYPE;
local l__REACT_FRAGMENT_TYPE__5 = l__ReactSymbols__2.REACT_FRAGMENT_TYPE;
local l__REACT_PORTAL_TYPE__6 = l__ReactSymbols__2.REACT_PORTAL_TYPE;
local l__REACT_MEMO_TYPE__7 = l__ReactSymbols__2.REACT_MEMO_TYPE;
local l__REACT_PROFILER_TYPE__8 = l__ReactSymbols__2.REACT_PROFILER_TYPE;
local l__REACT_PROVIDER_TYPE__9 = l__ReactSymbols__2.REACT_PROVIDER_TYPE;
local l__REACT_STRICT_MODE_TYPE__10 = l__ReactSymbols__2.REACT_STRICT_MODE_TYPE;
local l__REACT_SUSPENSE_TYPE__11 = l__ReactSymbols__2.REACT_SUSPENSE_TYPE;
local l__REACT_SUSPENSE_LIST_TYPE__12 = l__ReactSymbols__2.REACT_SUSPENSE_LIST_TYPE;
local l__REACT_LAZY_TYPE__13 = l__ReactSymbols__2.REACT_LAZY_TYPE;
local l__REACT_BLOCK_TYPE__14 = l__ReactSymbols__2.REACT_BLOCK_TYPE;
require(script.Parent:WaitForChild("ReactTypes"));
local l__describeError__15 = require(script.Parent:WaitForChild("ErrorHandling.roblox")).describeError;
local function u9(p1) --[[ Line: 57 ]]
    -- upvalues: l__console__1 (copy), l__REACT_FRAGMENT_TYPE__5 (copy), l__REACT_PORTAL_TYPE__6 (copy), l__REACT_PROFILER_TYPE__8 (copy), l__REACT_STRICT_MODE_TYPE__10 (copy), l__REACT_SUSPENSE_TYPE__11 (copy), l__REACT_SUSPENSE_LIST_TYPE__12 (copy), l__REACT_CONTEXT_TYPE__3 (copy), l__REACT_PROVIDER_TYPE__9 (copy), l__REACT_FORWARD_REF_TYPE__4 (copy), l__REACT_MEMO_TYPE__7 (copy), u9 (copy), l__REACT_BLOCK_TYPE__14 (copy), l__REACT_LAZY_TYPE__13 (copy), l__describeError__15 (copy)
    if p1 == nil then
        return nil;
    else
        local v2 = typeof(p1);
        if _G.__DEV__ and (v2 == "table" and typeof(p1.tag) == "number") then
            l__console__1.warn("Received an unexpected object in getComponentName(). This is likely a bug in React. Please file an issue.");
        end;
        if v2 == "function" then
            local v3 = debug.info(p1, "n");
            if v3 and string.len(v3) > 0 then
                return v3;
            else
                return nil;
            end;
        else
            if v2 == "string" then
                return p1;
            end;
            if p1 == l__REACT_FRAGMENT_TYPE__5 then
                return "Fragment";
            end;
            if p1 == l__REACT_PORTAL_TYPE__6 then
                return "Portal";
            end;
            if p1 == l__REACT_PROFILER_TYPE__8 then
                return "Profiler";
            end;
            if p1 == l__REACT_STRICT_MODE_TYPE__10 then
                return "StrictMode";
            end;
            if p1 == l__REACT_SUSPENSE_TYPE__11 then
                return "Suspense";
            end;
            if p1 == l__REACT_SUSPENSE_LIST_TYPE__12 then
                return "SuspenseList";
            end;
            if v2 == "table" then
                local v4 = p1["$$typeof"];
                if v4 == l__REACT_CONTEXT_TYPE__3 then
                    return (p1.displayName or "Context") .. ".Consumer";
                end;
                if v4 == l__REACT_PROVIDER_TYPE__9 then
                    return (p1._context.displayName or "Context") .. ".Provider";
                end;
                if v4 == l__REACT_FORWARD_REF_TYPE__4 then
                    local l__render__16 = p1.render;
                    local v5 = typeof(l__render__16) == "table" and (l__render__16.displayName or (l__render__16.name or "")) or "<function>";
                    return p1.displayName or (v5 ~= "" and string.format("%s(%s)", "ForwardRef", v5) or "ForwardRef");
                end;
                if v4 == l__REACT_MEMO_TYPE__7 then
                    return u9(p1.type);
                end;
                if v4 == l__REACT_BLOCK_TYPE__14 then
                    return u9(p1._render);
                end;
                if v4 == l__REACT_LAZY_TYPE__13 then
                    local v6, v7 = xpcall(p1._init, l__describeError__15, p1._payload);
                    if v6 then
                        return u9(v7);
                    else
                        return nil;
                    end;
                end;
                if p1.displayName then
                    return p1.displayName;
                end;
                if p1.name then
                    return p1.name;
                end;
                local v8 = getmetatable(p1);
                if v8 and rawget(v8, "__tostring") then
                    return tostring(p1);
                end;
            end;
            return nil;
        end;
    end;
end;
return u9;