-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.flowtypes.roblox
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent:WaitForChild("luau-polyfill"));
return {};