-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.shared.ReactInstanceMap
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = require(script.Parent.Parent:WaitForChild("luau-polyfill"));
local l__Error__1 = v1.Error;
local l__inspect__2 = v1.util.inspect;
local l__getComponentName__3 = require(script.Parent:WaitForChild("getComponentName"));
return {
    remove = function(p2) --[[ Line: 40 ]]
        p2._reactInternals = nil;
    end,
    get = function(p3) --[[ Line: 44 ]]
        -- upvalues: l__Error__1 (copy), l__getComponentName__3 (copy), l__inspect__2 (copy)
        local l___reactInternals__4 = p3._reactInternals;
        local v4;
        if l___reactInternals__4.tag == nil or (l___reactInternals__4.subtreeFlags == nil or l___reactInternals__4.lanes == nil) then
            v4 = false;
        else
            v4 = l___reactInternals__4.childLanes ~= nil;
        end;
        if v4 then
            if l___reactInternals__4.alternate ~= nil then
                local l__alternate__5 = l___reactInternals__4.alternate;
                local v5;
                if l__alternate__5.tag == nil or (l__alternate__5.subtreeFlags == nil or l__alternate__5.lanes == nil) then
                    v5 = false;
                else
                    v5 = l__alternate__5.childLanes ~= nil;
                end;
                if not v5 then
                    error(l__Error__1.new("invalid alternate fiber (" .. (l__getComponentName__3(p3) or "UNNAMED alternate") .. ") in " .. (l__getComponentName__3(p3) or "UNNAMED Component") .. " during get from ReactInstanceMap! " .. l__inspect__2(l___reactInternals__4.alternate)));
                end;
            end;
            return l___reactInternals__4;
        else
            error(l__Error__1.new("invalid fiber in " .. (l__getComponentName__3(p3) or "UNNAMED Component") .. " during get from ReactInstanceMap! " .. l__inspect__2(l___reactInternals__4)));
            return l___reactInternals__4;
        end;
    end,
    has = function(p6) --[[ Line: 74 ]]
        return p6._reactInternals ~= nil;
    end,
    set = function(p7, p8) --[[ Line: 78 ]]
        -- upvalues: l__getComponentName__3 (copy), l__inspect__2 (copy), l__Error__1 (copy)
        local v9 = p8;
        while p8 ~= nil do
            local v10;
            if p8.tag == nil or (p8.subtreeFlags == nil or p8.lanes == nil) then
                v10 = false;
            else
                v10 = p8.childLanes ~= nil;
            end;
            if v10 then
                if p8.alternate ~= nil then
                    local l__alternate__6 = p8.alternate;
                    local v11;
                    if l__alternate__6.tag == nil or (l__alternate__6.subtreeFlags == nil or l__alternate__6.lanes == nil) then
                        v11 = false;
                    else
                        v11 = l__alternate__6.childLanes ~= nil;
                    end;
                    if not v11 then
                        local v12 = "invalid alternate fiber (" .. (l__getComponentName__3(p7) or "UNNAMED alternate") .. ") in " .. (l__getComponentName__3(p7) or "UNNAMED Component") .. " being set in ReactInstanceMap! " .. l__inspect__2(p8.alternate) .. "\n";
                        if v9 ~= p8 then
                            v12 = v12 .. " (from original fiber " .. (l__getComponentName__3(p7) or "UNNAMED Component") .. ")";
                        end;
                        error(l__Error__1.new(v12));
                    end;
                end;
            else
                local v13 = "invalid fiber in " .. (l__getComponentName__3(p7) or "UNNAMED Component") .. " being set in ReactInstanceMap! " .. l__inspect__2(p8) .. "\n";
                if v9 ~= p8 then
                    v13 = v13 .. " (from original fiber " .. (l__getComponentName__3(p7) or "UNNAMED Component") .. ")";
                end;
                error(l__Error__1.new(v13));
            end;
            p8 = p8.return_;
        end;
        p7._reactInternals = v9;
    end
};