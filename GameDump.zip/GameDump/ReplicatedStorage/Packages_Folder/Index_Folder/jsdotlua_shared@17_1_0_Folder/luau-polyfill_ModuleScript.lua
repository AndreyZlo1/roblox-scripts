-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_shared@17.1.0.luau-polyfill
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent.Parent["jsdotlua_luau-polyfill@1.2.7"]["luau-polyfill"]);