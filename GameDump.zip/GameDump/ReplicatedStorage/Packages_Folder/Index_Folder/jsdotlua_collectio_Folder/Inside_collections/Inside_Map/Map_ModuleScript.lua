-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Map.Map
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
local l__forEach__2 = require(script.Parent.Parent:WaitForChild("Array"):WaitForChild("forEach"));
local l__map__3 = require(script.Parent.Parent:WaitForChild("Array"):WaitForChild("map"));
local l__isArray__4 = require(script.Parent.Parent:WaitForChild("Array"):WaitForChild("isArray"));
local u1 = require(script.Parent.Parent.Parent:WaitForChild("instance-of"));
require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
local u2 = {};
function u2.new(p3) --[[ Line: 22 ]]
    -- upvalues: l__isArray__4 (copy), l____DEV____1 (copy), u1 (copy), u2 (copy)
    local v4 = nil;
    local v5 = nil;
    if p3 == nil then
        v4 = {};
        v5 = {};
    elseif l__isArray__4(p3) then
        if l____DEV____1 and (#p3 > 0 and typeof(p3[1]) ~= "table") then
            error("Value `" .. typeof(p3[1]) .. "` is not an entry object.\n Cannot create Map from {K, V} form, it must be { {K, V}... }");
        end;
        v4 = table.create(#p3);
        v5 = {};
        for _, v6 in p3 do
            local v7 = v6[1];
            if l____DEV____1 and v7 == nil then
                error("cannot create Map from a table that isn\'t an array.");
            end;
            local v8 = v6[2];
            if v5[v7] == nil then
                table.insert(v4, v7);
            end;
            v5[v7] = v8;
        end;
    elseif u1(p3, u2) then
        v4 = table.clone(p3._array);
        v5 = table.clone(p3._map);
    else
        error(("`%s` `%s` is not iterable, cannot make Map using it"):format(typeof(p3), (tostring(p3))));
    end;
    return setmetatable({
        size = #v4,
        _map = v5,
        _array = v4
    }, u2);
end;
function u2.set(p9, p10, p11) --[[ Line: 71 ]]
    if p9._map[p10] == nil then
        p9.size = p9.size + 1;
        table.insert(p9._array, p10);
    end;
    p9._map[p10] = p11;
    return p9;
end;
function u2.get(p12, p13) --[[ Line: 83 ]]
    return p12._map[p13];
end;
function u2.clear(p14) --[[ Line: 87 ]]
    local v15 = table;
    p14.size = 0;
    v15.clear(p14._map);
    v15.clear(p14._array);
end;
function u2.delete(p16, p17) --[[ Line: 94 ]]
    if p16._map[p17] == nil then
        return false;
    end;
    p16.size = p16.size - 1;
    p16._map[p17] = nil;
    local v18 = table.find(p16._array, p17);
    if v18 then
        table.remove(p16._array, v18);
    end;
    return true;
end;
function u2.forEach(u19, u20, u21) --[[ Line: 110 ]]
    -- upvalues: l____DEV____1 (copy), l__forEach__2 (copy)
    if l____DEV____1 and typeof(u20) ~= "function" then
        error("callback is not a function");
    end;
    l__forEach__2(u19._array, function(p22) --[[ Line: 117 ]]
        -- upvalues: u19 (copy), u21 (copy), u20 (copy)
        local v23 = u19._map[p22];
        if u21 == nil then
            u20(v23, p22, u19);
        else
            u20(u21, v23, p22, u19);
        end;
    end);
end;
function u2.has(p24, p25) --[[ Line: 128 ]]
    return p24._map[p25] ~= nil;
end;
function u2.keys(p26) --[[ Line: 132 ]]
    return p26._array;
end;
function u2.values(u27) --[[ Line: 136 ]]
    -- upvalues: l__map__3 (copy)
    return l__map__3(u27._array, function(p28) --[[ Line: 137 ]]
        -- upvalues: u27 (copy)
        return u27._map[p28];
    end);
end;
function u2.entries(u29) --[[ Line: 142 ]]
    -- upvalues: l__map__3 (copy)
    return l__map__3(u29._array, function(p30) --[[ Line: 143 ]]
        -- upvalues: u29 (copy)
        return { p30, u29._map[p30] };
    end);
end;
function u2.ipairs(p31) --[[ Line: 148 ]]
    -- upvalues: l____DEV____1 (copy)
    if l____DEV____1 then
        warn(debug.traceback("`for _,_ in myMap:ipairs() do` is deprecated and will be removed in a future release, please use `for _,_ in myMap do` instead\n", 2));
    end;
    return ipairs(p31:entries());
end;
function u2.__iter(p32) --[[ Line: 160 ]]
    return next, p32:entries();
end;
function u2.__index(p33, p34) --[[ Line: 164 ]]
    -- upvalues: u2 (copy), l____DEV____1 (copy)
    local v35 = rawget(u2, p34);
    if v35 ~= nil then
        return v35;
    end;
    if l____DEV____1 then
        local v36 = rawget(p33, "_map");
        assert(v36, "Map has been corrupted, and is missing private state! Did you accidentally call table.clear() instead of map:clear()?");
    end;
    return u2.get(p33, p34);
end;
function u2.__newindex(p37, p38, p39) --[[ Line: 180 ]]
    p37:set(p38, p39);
end;
return u2;