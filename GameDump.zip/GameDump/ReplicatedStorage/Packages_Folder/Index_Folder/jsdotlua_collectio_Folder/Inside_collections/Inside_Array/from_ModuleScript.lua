-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Array.from
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Set__1 = require(script.Parent.Parent:WaitForChild("Set"));
local l__Map__2 = require(script.Parent.Parent:WaitForChild("Map"):WaitForChild("Map"));
local l__isArray__3 = require(script.Parent:WaitForChild("isArray"));
local u1 = require(script.Parent.Parent.Parent:WaitForChild("instance-of"));
require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
local l__fromString__4 = require(script:WaitForChild("fromString"));
local l__fromSet__5 = require(script:WaitForChild("fromSet"));
local l__fromMap__6 = require(script:WaitForChild("fromMap"));
local l__fromArray__7 = require(script:WaitForChild("fromArray"));
return function(p2, p3, p4) --[[ Line: 19 ]]
    -- upvalues: l__isArray__3 (copy), l__fromArray__7 (copy), u1 (copy), l__Set__1 (copy), l__fromSet__5 (copy), l__Map__2 (copy), l__fromMap__6 (copy), l__fromString__4 (copy)
    if p2 == nil then
        error("cannot create array from a nil value");
    end;
    local v5 = typeof(p2);
    if v5 == "table" and l__isArray__3(p2) then
        return l__fromArray__7(p2, p3, p4);
    elseif u1(p2, l__Set__1) then
        return l__fromSet__5(p2, p3, p4);
    elseif u1(p2, l__Map__2) then
        return l__fromMap__6(p2, p3, p4);
    else
        return v5 ~= "string" and {} or l__fromString__4(p2, p3, p4);
    end;
end;