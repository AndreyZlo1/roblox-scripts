-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Array.flat
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l____DEV____1 = _G.__DEV__;
local l__isArray__2 = require(script.Parent:WaitForChild("isArray"));
require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
local function u8(p1, p2) --[[ Line: 5 ]]
    -- upvalues: l____DEV____1 (copy), l__isArray__2 (copy), u8 (copy)
    if l____DEV____1 then
        if typeof(p1) ~= "table" then
            error(string.format("Array.flat called on %s", (typeof(p1))));
        end;
        if p2 ~= nil and typeof(p2) ~= "number" then
            error("depth is not a number or nil");
        end;
    end;
    local v3 = p2 or 1;
    local v4 = {};
    for _, v6 in p1 do
        if l__isArray__2(v6) then
            if v3 > 1 then
                local v6 = u8(v6, v3 - 1);
            end;
            for _, v7 in v6 do
                table.insert(v4, v7);
            end;
        else
            table.insert(v4, v6);
        end;
    end;
    return v4;
end;
return u8;