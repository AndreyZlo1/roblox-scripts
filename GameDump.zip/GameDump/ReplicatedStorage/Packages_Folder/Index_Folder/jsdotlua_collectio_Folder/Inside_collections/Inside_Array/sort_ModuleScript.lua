-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Array.sort
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__None__1 = require(script.Parent.Parent:WaitForChild("Object"):WaitForChild("None"));
require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
local function u3(p1, p2) --[[ Line: 5 ]]
    return type(p1) .. tostring(p1) < type(p2) .. tostring(p2);
end;
return function(p4, u5) --[[ Line: 9 ]]
    -- upvalues: u3 (copy), l__None__1 (copy)
    local v6 = u3;
    if u5 ~= nil and u5 ~= l__None__1 then
        if typeof(u5) == "function" then
            v6 = function(p10, p11) --[[ Line: 16 ]]
                -- upvalues: u5 (copy)
                local v12 = u5(p10, p11);
                if typeof(v12) ~= "number" then
                    error(("invalid result from compare function, expected number but got %s"):format((typeof(v12))));
                end;
                return v12 < 0;
            end;
        else
            error("invalid argument to Array.sort: compareFunction must be a function");
            v6 = function(p10, p11) --[[ Line: 16 ]]
                -- upvalues: u5 (copy)
                local v12 = u5(p10, p11);
                if typeof(v12) ~= "number" then
                    error(("invalid result from compare function, expected number but got %s"):format((typeof(v12))));
                end;
                return v12 < 0;
            end;
        end;
    end;
    table.sort(p4, v6);
    return p4;
end;