-- Roblox: ReplicatedStorage.Packages._Index.jsdotlua_collections@1.2.7.collections.Array.join
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent.Parent.Parent:WaitForChild("es7-types"));
local l__map__1 = require(script.Parent:WaitForChild("map"));
return function(p1, p2) --[[ Line: 5 ]]
    -- upvalues: l__map__1 (copy)
    if #p1 == 0 then
        return "";
    end;
    local v4 = l__map__1(p1, function(p3) --[[ Line: 10 ]]
        return tostring(p3);
    end);
    return table.concat(v4, p2 or ",");
end;