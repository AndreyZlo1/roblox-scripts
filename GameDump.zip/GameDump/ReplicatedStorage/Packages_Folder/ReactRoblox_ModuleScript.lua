-- Roblox: ReplicatedStorage.Packages.ReactRoblox
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return require(script.Parent._Index["jsdotlua_react-roblox@17.1.0"]["react-roblox"]);