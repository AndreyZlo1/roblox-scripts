-- Roblox: ReplicatedStorage.Packages.RoactRodux
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__StoreProvider__1 = require(script.StoreProvider);
local l__connect__2 = require(script.connect);
return {
    StoreProvider = l__StoreProvider__1,
    connect = l__connect__2,
    UNSTABLE_getStore = require(script.getStore),
    UNSTABLE_connect2 = l__connect__2
};