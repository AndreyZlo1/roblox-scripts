-- Roblox: ReplicatedStorage.Packages.asset
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__ServerStorage__2 = game:GetService("ServerStorage");
local l__RunService__3 = game:GetService("RunService");
local l__Configs__4 = l__ReplicatedStorage__1:WaitForChild("Shared"):WaitForChild("Configs");
local l__Sounds__5 = require(l__Configs__4:WaitForChild("Sound"):WaitForChild("Sounds"));
local l__Animations__6 = require(l__Configs__4:WaitForChild("Animation"):WaitForChild("Animations"));
local l__AssetClass__7 = require(script:WaitForChild("AssetClass"));
local u1 = {
    { "Sound", "UISounds", "LoadoutPurchaseStart" },
    { "Sound", "UISounds", "LoadoutPurchaseCompleted" },
    { "Sound", "Foley", "TakeDown" },
    { "Animation", "Emotes" },
    { "Animation", "CharacterAnimations", "Vault" },
    { "Animation", "CharacterAnimations", "KickDoor" },
    { "Animation", "CharacterAnimations", "KnockBack" },
    { "Animation", "CharacterAnimations", "Radio" },
    { "Animation", "CharacterAnimations", "TakeDown" },
    {
        "Animation",
        "MeleeAnimations",
        "Hooligan",
        "TP",
        "BreachLeft"
    },
    {
        "Animation",
        "MeleeAnimations",
        "Hooligan",
        "TP",
        "BreachRight"
    },
    { "Animation", "CharacterPacks" }
};
local u2 = {};
u2.__index = u2;
function u2._getDirectory(p3, p4) --[[ Line: 103 ]]
    local l___assets__8 = p3._assets;
    for _, v5 in p4 do
        if l___assets__8[v5] then
            l___assets__8 = l___assets__8[v5];
        else
            error("Directory doesn\'t exist: " .. table.concat(p4, ", "));
        end;
    end;
    return l___assets__8;
end;
function u2.new() --[[ Line: 116 ]]
    -- upvalues: u2 (copy), l__Sounds__5 (copy), l__Animations__6 (copy), l__ReplicatedStorage__1 (copy), l__RunService__3 (copy), l__ServerStorage__2 (copy), l__AssetClass__7 (copy), u1 (copy)
    local v6 = {
        _assets = {},
        _random = Random.new(),
        _cache = {}
    };
    local v7 = setmetatable(v6, u2);
    local l___assets__9 = v7._assets;
    local v8 = {};
    local function u16(p9, p10) --[[ Line: 45 ]]
        -- upvalues: u16 (copy)
        local v11 = false;
        local v12 = false;
        for v13, v14 in p9 do
            if v14._animation or v14._sound then
                v12 = true;
                if v11 then
                    error("Asset compile error, folder in asset.");
                end;
                p10[v13] = {
                    _isAsset = true,
                    _lastPicked = false,
                    IsLoaded = false,
                    Asset = v14
                };
            else
                v11 = true;
                if v12 then
                    print(p9);
                    error("Asset compile error, folder in asset.");
                end;
                local v15 = {};
                p10[v13] = v15;
                u16(v14, v15);
            end;
        end;
    end;
    u16(l__Sounds__5, v8);
    l___assets__9.Sound = v8;
    local l___assets__10 = v7._assets;
    local v17 = {};
    local function u25(p18, p19) --[[ Line: 45 ]]
        -- upvalues: u25 (copy)
        local v20 = false;
        local v21 = false;
        for v22, v23 in p18 do
            if v23._animation or v23._sound then
                v21 = true;
                if v20 then
                    error("Asset compile error, folder in asset.");
                end;
                p19[v22] = {
                    _isAsset = true,
                    _lastPicked = false,
                    IsLoaded = false,
                    Asset = v23
                };
            else
                v20 = true;
                if v21 then
                    print(p18);
                    error("Asset compile error, folder in asset.");
                end;
                local v24 = {};
                p19[v22] = v24;
                u25(v23, v24);
            end;
        end;
    end;
    u25(l__Animations__6, v17);
    l___assets__10.Animation = v17;
    local l___assets__11 = v7._assets;
    local v26 = {};
    local function u31(p27, p28) --[[ Line: 82 ]]
        -- upvalues: u31 (copy)
        for _, v29 in p27:GetChildren() do
            if v29:IsA("Folder") then
                local v30 = {};
                p28[v29.Name] = v30;
                u31(v29, v30);
            else
                p28[v29.Name] = {
                    _isAsset = true,
                    _lastPicked = false,
                    IsLoaded = false,
                    Asset = v29
                };
            end;
        end;
    end;
    u31(l__ReplicatedStorage__1:WaitForChild("Assets"), v26);
    l___assets__11.Shared = v26;
    if not l__RunService__3:IsServer() then
        local function u34(p32) --[[ Line: 130 ]]
            -- upvalues: l__AssetClass__7 (ref), u34 (copy)
            if p32._isAsset then
                l__AssetClass__7.new(p32):Preload();
            else
                for _, v33 in p32 do
                    u34(v33);
                end;
            end;
        end;
        for _, v35 in u1 do
            local v36 = v7:_getDirectory(v35);
            if v36._isAsset then
                l__AssetClass__7.new(v36):Preload();
            else
                for _, v37 in v36 do
                    u34(v37);
                end;
            end;
        end;
        return v7;
    end;
    local l___assets__12 = v7._assets;
    local v38 = {};
    local function u43(p39, p40) --[[ Line: 82 ]]
        -- upvalues: u43 (copy)
        for _, v41 in p39:GetChildren() do
            if v41:IsA("Folder") then
                local v42 = {};
                p40[v41.Name] = v42;
                u43(v41, v42);
            else
                p40[v41.Name] = {
                    _isAsset = true,
                    _lastPicked = false,
                    IsLoaded = false,
                    Asset = v41
                };
            end;
        end;
    end;
    u43(l__ServerStorage__2:WaitForChild("Assets"), v38);
    l___assets__12.Server = v38;
    return v7;
end;
function u2.Get(p44, ...) --[[ Line: 151 ]]
    -- upvalues: l__AssetClass__7 (copy)
    local v45 = table.concat({ ... }, ",");
    if p44._cache[v45] then
        return p44._cache[v45];
    end;
    local v46 = p44:_getDirectory({ ... });
    if v46._isAsset == nil then
        return p44:GetRandom(...);
    end;
    local v47 = l__AssetClass__7.new(v46, p44.Debugger);
    p44._cache[v45] = v47;
    return v47;
end;
function u2.GetRandom(p48, ...) --[[ Line: 170 ]]
    -- upvalues: l__AssetClass__7 (copy)
    local v49 = p48:_getDirectory({ ... });
    if v49._isAsset then
        error("Directory returns an asset, needs to be a folder for random picking.");
    end;
    local v50 = {};
    local v51 = nil;
    for v52, v53 in v49 do
        if v53._lastPicked then
            v51 = v52;
        else
            v50[#v50 + 1] = v52;
        end;
    end;
    if #v50 > 0 then
        local v54 = v50[p48._random:NextInteger(1, #v50)];
        v49[v54]._lastPicked = true;
        if v51 then
            v49[v51]._lastPicked = false;
        end;
        return l__AssetClass__7.new(v49[v54], p48.Debugger);
    end;
    if v51 then
        return l__AssetClass__7.new(v49[v51], p48.Debugger);
    end;
    error("There needs to be atleast one (1) asset in folder directory to randomly pick from.");
end;
return u2.new();