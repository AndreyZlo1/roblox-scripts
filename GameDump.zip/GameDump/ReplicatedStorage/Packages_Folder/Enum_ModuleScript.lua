-- Roblox: ReplicatedStorage.Packages.Enum
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return setmetatable({
    LoadoutButtonType = {
        Loadout = 0,
        ViewAreaButton = 1,
        Item = 2,
        Icon = 3,
        Category = 4,
        Colorway = 5,
        Manufacturer = 6,
        Add = 7,
        LoadoutSet = 8
    },
    RoamingEnemyConvy = {
        InvestigateArea = 0
    },
    PopupType = {
        Default = 0,
        Patch = 1,
        Vertical = 2,
        Shop = 3
    },
    InteractionState = {
        Started = 0,
        Failed = 1,
        Finished = 2,
        InProgress = 3
    },
    RadioCall = {
        DeadBody = 0,
        SuspiciousActivity = 1
    },
    BotStance = {
        Crouch = 0,
        Prone = 1,
        Stand = 2
    },
    ShellPriority = {
        Default = 0,
        PreferVisible = 1,
        AlwaysVisible = 2
    },
    DoorTypes = {
        Weak = 1,
        Strong = 2
    },
    CursorType = {
        None = 0,
        Pointer = 1,
        Crosshair = 2
    },
    InvestigationPriority = {
        LookAt = 0,
        BeAware = 1,
        WalkOver = 2,
        RunOver = 3
    },
    PhysicsGroup = {
        Character = 1,
        CharacterCast = 2,
        GroundVehicle = 3,
        GroundVehicleCast = 4,
        HelicopterVehicle = 5,
        HelicopterVehicleCast = 6,
        GrenadeCast = 7,
        Debris = 8,
        BulletCast = 9,
        BotNoCollide = 10,
        BotSightBlocker = 11,
        BotCast = 12,
        LimbRagdoll = 19,
        Ragdoll = 13,
        Glass = 14,
        BotEars = 20,
        BotEyes = 15,
        Fence = 16,
        Door = 18,
        RGESelectable = 17
    },
    GrenadeType = {
        Explosive = 0,
        Smoke = 1,
        Flare = 2,
        Glowstick = 3,
        Dummy = 4,
        Flash = 5
    },
    CharacterHeightState = {
        Standing = 0,
        Crouching = 1,
        Proning = 2,
        Sitting = 3,
        Swimming = 4,
        Climbing = 5,
        Vaulting = 6,
        Falling = 7,
        Skydiving = 8,
        Parachuting = 9
    },
    DataFetchStatus = {
        Success = 0,
        Migrating = 1,
        Failure = 2
    },
    VehicleType = {
        Ground = 0,
        Helicopter = 1,
        FixedWing = 2,
        Boat = 3
    },
    WidgetPositions = {
        TopCenter = 0,
        BottomCenter = 1,
        TopRight = 2,
        BottomLeft = 3,
        RightCenter = 4,
        LeftCenter = 5,
        BottomRight = 6,
        TopLeft = 7
    },
    TargetGroup = {
        Friendly = 0,
        Hostile = 1,
        Zombie = 2
    },
    ItemType = {
        Consumable = 0,
        Firearm = 1,
        Backpack = 2,
        Ammo = 3,
        Grenade = 4,
        Medical = 5,
        Melee = 6,
        Vest = 7,
        Belt = 8,
        Helmet = 9,
        Rocket = 10,
        Mag = 11,
        Facewear = 12,
        Earwear = 13,
        Eyewear = 14,
        Boots = 15,
        Gloves = 16,
        Shirt = 17,
        Pants = 18,
        Wrist = 19,
        Junk = 20,
        Gear = 21
    },
    SlotType = {
        Backpack = 1,
        Grenade = 2,
        Primary = 3,
        Secondary = 5,
        Offhand = 4,
        Medical = 6,
        Melee = 7,
        Vest = 8,
        Belt = 9,
        Helmet = 10,
        Facewear = 11,
        Earwear = 12,
        Eyewear = 13,
        Boots = 14,
        Gloves = 15,
        Shirt = 16,
        Pants = 17,
        Wrist = 18
    },
    GearType = {
        Binoculars = 0,
        RangeFinder = 1,
        CSEL = 2
    },
    DamageType = {
        Actor = 0,
        Vehicle = 1
    },
    TurretType = {
        Fixed = 0,
        Vehicle = 1
    },
    TurretAccess = {
        Public = 0,
        Disabled = 1,
        Squad = 2
    },
    CoverType = {
        Normal = 0,
        Ambush = 1,
        RPG = 2,
        MANPAD = 3
    },
    BotDriverType = {
        None = 0,
        Ground = 1,
        Helicopter = 2,
        FixedWing = 3,
        Boat = 4
    },
    FamilySpawn = {
        Defence = 0,
        Alarm = 1,
        Attack = 2,
        Wave = 3,
        Civilian = 4,
        Trigger = 5
    },
    ActionType = {
        Inventory = 0,
        Helmet = 1,
        Function = 2,
        FunctionIgnoreClient = 3,
        InventoryIncludeClient = 4
    },
    ExplosionType = {
        None = 9,
        Grenade = 0,
        Mine = 1,
        Motar = 2,
        RPG7v2 = 3,
        Igla = 4,
        C4 = 5,
        GroundVehicle = 6,
        HelicopterVehicle = 7,
        ObjBig = 8,
        Flash = 10,
        Breach = 11,
        M320A1 = 12
    },
    LobbyStatus = {
        Leave = 0,
        Update = 1,
        Disband = 2,
        Prepare = 3,
        Joining = 4,
        Join = 5,
        Cancel = 6,
        Matching = 7,
        Matched = 8,
        Kick = 9
    },
    UserStatus = {
        Invited = 0,
        Join = 1
    }
}, {
    __index = Enum
});