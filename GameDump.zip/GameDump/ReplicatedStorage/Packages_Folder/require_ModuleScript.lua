-- Roblox: ReplicatedStorage.Packages.require
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__RunService__1 = game:GetService("RunService");
local l__ReplicatedFirst__2 = game:GetService("ReplicatedFirst");
local l__ReplicatedStorage__3 = game:GetService("ReplicatedStorage");
local l__ServerScriptService__4 = game:GetService("ServerScriptService");
local u1 = {};
u1.__index = u1;
function u1.new() --[[ Line: 34 ]]
    -- upvalues: l__RunService__1 (copy), l__ServerScriptService__4 (copy), l__ReplicatedFirst__2 (copy), l__ReplicatedStorage__3 (copy), u1 (copy)
    local u2 = {};
    local function v5(p3) --[[ Line: 39 ]]
        -- upvalues: u2 (copy)
        for _, v4 in p3:GetDescendants() do
            if v4:IsA("ModuleScript") then
                u2[v4.Name] = v4;
            end;
        end;
    end;
    local v6;
    if l__RunService__1:IsServer() or l__RunService__1:IsStudio() and not (l__RunService__1:IsRunning() or _G.testClient) then
        v5(l__ServerScriptService__4:WaitForChild("Flux/server"));
        v6 = true;
    else
        v6 = false;
    end;
    if not v6 then
        v5(l__ReplicatedFirst__2:WaitForChild("Flux/client"));
    end;
    v5(l__ReplicatedStorage__3:WaitForChild("Shared"));
    return setmetatable({
        _lazyModules = {},
        _isServer = v6,
        _modules = u2
    }, u1);
end;
function u1.__call(p7, p8, p9) --[[ Line: 69 ]]
    local l___modules__5 = p7._modules;
    if p9 then
        if typeof(p8) ~= "string" then
            error("Requiring modules lazy must be from a string.");
        end;
        local v10 = p7._lazyModules[p8];
        if not v10 then
            v10 = {};
            p7._lazyModules[p8] = v10;
        end;
        return v10;
    end;
    if typeof(p8) ~= "string" then
        if typeof(p8) == "Instance" then
            if not p8:IsA("ModuleScript") then
                error("Could not load module \'" .. p8.Name .. "\'.");
            end;
            return require(p8);
        end;
        local v11 = {};
        for _, v12 in p8 do
            local v13 = l___modules__5[v12];
            if not v13 then
                error("Could not find module \'" .. v12 .. "\'.");
            end;
            v11[v12] = require(v13);
        end;
        return v11;
    end;
    local v14 = l___modules__5[p8];
    if not v14 then
        error("Could not find module \'" .. p8 .. "\'.");
    end;
    local v15 = require(v14);
    local v16 = p7._lazyModules[p8];
    if v16 then
        v16.Lazy = v15;
    end;
    return v15;
end;
return u1.new();