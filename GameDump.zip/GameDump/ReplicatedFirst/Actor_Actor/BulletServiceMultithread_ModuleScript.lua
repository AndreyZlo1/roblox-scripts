-- Roblox: ReplicatedFirst.Actor.BulletServiceMultithread
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__RunService__1 = game:GetService("RunService");
local u1 = l__RunService__1:IsClient();
local l__BulletClassMultithread__2 = require(script:WaitForChild("BulletClassMultithread"));
local u2 = {};
local u3 = true;
local u4 = true;
local u5 = {
    [true] = 0,
    [false] = 0
};
script:WaitForChild("Send").Event:Connect(function(p6, ...) --[[ Line: 31 ]]
    -- upvalues: u2 (copy), l__BulletClassMultithread__2 (copy), u3 (ref), u1 (copy)
    if p6 == 0 then
        local v7, v8 = ...;
        if u2[v7] then
            u2[v7].CancelElapse = v8;
        end;
    elseif p6 == 1 then
        local v9, v10 = ...;
        local v11 = l__BulletClassMultithread__2.new(v10, u3);
        if not u1 then
            u3 = not u3;
            v11.UpdateGroup = u3;
        end;
        u2[v9] = v11;
    end;
end);
local l__Receive__3 = script:WaitForChild("Receive");
l__RunService__1.Heartbeat:ConnectParallel(function(p12) --[[ Line: 40 ]]
    -- upvalues: u1 (copy), u2 (copy), u4 (ref), u5 (copy), l__Receive__3 (copy)
    if u1 then
        for _, v13 in u2 do
            v13:UpdateParallel(p12);
        end;
    else
        local v14 = os.clock();
        u4 = not u4;
        local v15 = v14 - u5[u4];
        u5[u4] = v14;
        for _, v16 in u2 do
            if v16.UpdateGroup == u4 then
                v16:UpdateParallel(v15);
            end;
        end;
    end;
    task.synchronize();
    local v17 = {};
    for v18, v19 in u2 do
        v19:Update(p12);
        if v19._destroyed then
            u2[v18] = nil;
        else
            local l__MultithreadPayload__4 = v19.MultithreadPayload;
            if l__MultithreadPayload__4 then
                v17[v18] = l__MultithreadPayload__4;
                v19.MultithreadPayload = nil;
            end;
            if v19.QueueDestroy then
                v19:Destroy();
            end;
        end;
    end;
    l__Receive__3:Fire(v17);
end);
return {};