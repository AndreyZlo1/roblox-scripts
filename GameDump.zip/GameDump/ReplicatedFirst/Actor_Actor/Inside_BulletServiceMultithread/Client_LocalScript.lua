-- Roblox: ReplicatedFirst.Actor.BulletServiceMultithread.Client
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent);