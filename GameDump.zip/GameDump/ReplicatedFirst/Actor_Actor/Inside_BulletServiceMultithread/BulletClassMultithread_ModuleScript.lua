-- Roblox: ReplicatedFirst.Actor.BulletServiceMultithread.BulletClassMultithread
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = game:GetService("RunService"):IsClient();
local u2 = {
    "LeftHand",
    "LeftLowerArm",
    "LeftUpperArm",
    "RightUpperArm",
    "RightLowerArm",
    "RightHand"
};
local u3 = { "UpperTorso", "LowerTorso" };
local l__Terrain__1 = workspace.Terrain;
local l__CurrentCamera__2 = workspace.CurrentCamera;
local u4 = {};
u4.__index = u4;
local function u7(p5, p6) --[[ Line: 34 ]]
    local l__Magnitude__3 = (p5.Unit:ClosestPoint(p6) - p5.Origin).Magnitude;
    return p5.Origin + p5.Direction.Unit * math.clamp(l__Magnitude__3, 0, (p5.Origin - (p5.Origin + p5.Direction)).Magnitude);
end;
function u4._constantsGetPosition(p8) --[[ Line: 40 ]]
    local l___angle__4 = p8._angle;
    local l___velocity__5 = p8._velocity;
    p8._cosA = math.cos(l___angle__4);
    p8._tanA = math.tan(l___angle__4);
    p8._divConstant = 1 / (2 * p8._velocity ^ 2 * p8._cosA ^ 2);
    p8._cosAVel = p8._cosA * l___velocity__5;
end;
function u4._getPosition(p9, p10) --[[ Line: 50 ]]
    local v11 = p9._cosAVel * p10;
    return Vector3.new(0, v11 * p9._tanA - 32.2 * v11 ^ 2 * p9._divConstant, -v11);
end;
function u4._multithreadSend(p12, ...) --[[ Line: 56 ]]
    if not p12.MultithreadPayload then
        p12.MultithreadPayload = {};
    end;
    table.insert(p12.MultithreadPayload, { ... });
end;
local u13 = Instance.new("Beam");
u13.FaceCamera = true;
u13.TextureSpeed = 0;
u13.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.8, 0), NumberSequenceKeypoint.new(1, 1) });
u13.Texture = "rbxassetid://16992331901";
u13.LightInfluence = 0;
u13.TextureLength = 1;
u13.TextureMode = Enum.TextureMode.Stretch;
u13.Brightness = 2;
u13.Segments = 2;
u13.CurveSize0 = 0;
u13.CurveSize1 = 0;
u13.Width1 = 0.15;
u13.Transparency = NumberSequence.new(0);
function u4.new(p14) --[[ Line: 83 ]]
    -- upvalues: u1 (copy), l__CurrentCamera__2 (copy), u4 (copy), u13 (copy), l__Terrain__1 (copy)
    local l__Caliber__6 = p14.Caliber;
    local l__OriginCFrame__7 = p14.OriginCFrame;
    local l__Velocity__8 = p14.Velocity;
    local l__Range__9 = p14.Range;
    local v15, v16 = l__OriginCFrame__7:ToOrientation();
    local v17 = RaycastParams.new();
    v17.FilterType = Enum.RaycastFilterType.Blacklist;
    v17.IgnoreWater = false;
    v17.CollisionGroup = 9;
    local l__Replicate__10 = p14.Replicate;
    if u1 then
        v17:AddToFilter(l__CurrentCamera__2);
    end;
    local v18 = typeof(l__Replicate__10) == "string" and l__CurrentCamera__2:FindFirstChild(l__Replicate__10);
    if v18 then
        v17:AddToFilter(v18);
    end;
    if p14.Ignore then
        v17:AddToFilter(p14.Ignore);
    end;
    local v19 = {
        _startFrame = os.clock(),
        _uid = p14.UID,
        _replicate = l__Replicate__10,
        _velocity = l__Velocity__8,
        _angle = v15,
        _canBreach = p14.CanBreach,
        _range = l__Range__9,
        _caliber = l__Caliber__6,
        _local = p14.Local,
        _originCFrame = l__OriginCFrame__7,
        _rayParams = v17
    };
    local v20 = setmetatable(v19, u4);
    v20:_constantsGetPosition();
    if u1 then
        local l__Model__11 = p14.Model;
        if l__Model__11 then
            v20._effects = {
                Model = l__Model__11
            };
        else
            local l__Tracer__12 = p14.Tracer;
            local v21 = Instance.new("Attachment");
            local v22 = Instance.new("Attachment");
            local v23 = u13:Clone();
            v21.Parent = l__Terrain__1;
            v22.Parent = l__Terrain__1;
            v21.CFrame = l__OriginCFrame__7;
            v22.CFrame = l__OriginCFrame__7;
            local v24 = 1;
            local v25 = 2;
            local v26 = false;
            local v27 = Color3.fromRGB(255, 88, 37);
            if l__Tracer__12 == "Red" then
                v27 = Color3.new(1, 0, 0);
                v26 = true;
            elseif l__Tracer__12 == "Green" then
                v27 = Color3.new(0, 1, 0);
                v26 = true;
            elseif l__Tracer__12 == "Blue" then
                v27 = Color3.new(0, 0, 1);
                v26 = true;
            else
                v24 = 0.3;
                v25 = 0.5;
            end;
            if v26 then
                local v28 = Instance.new("PointLight");
                v28.Color = v27;
                v28.Brightness = 2;
                v28.Range = 16;
                v28.Parent = v22;
                v22:SetAttribute("Color", v27);
                v22:AddTag("Flare");
            end;
            v23.Color = ColorSequence.new(v27);
            v23.LightEmission = v25;
            v23.Attachment0 = v22;
            v23.Attachment1 = v21;
            v23.Width0 = v24;
            v23.Parent = l__Terrain__1;
            v20._effects = {
                From = v21,
                To = v22,
                Beam = v23
            };
        end;
    end;
    v20._clacked = false;
    v20._cframe = CFrame.new(l__OriginCFrame__7.Position) * CFrame.Angles(0, v16, 0);
    v20._lastPosition = l__OriginCFrame__7.Position;
    v20._lastFrame = v20._startFrame;
    v20._totalDistance = 0;
    return v20;
end;
function u4.UpdateParallel(u29, p30) --[[ Line: 194 ]]
    -- upvalues: l__CurrentCamera__2 (copy), u1 (copy), u7 (copy), u2 (copy), u3 (copy)
    if u29._landed or u29._destroyed then
    else
        local l__Position__13 = l__CurrentCamera__2.CFrame.Position;
        local v31 = os.clock();
        local v32 = math.ceil(p30 / 2 / u29._velocity);
        local u33 = nil;
        local u34 = nil;
        local u35 = nil;
        for v36 = 1, v32 do
            local u37 = u29._lastFrame - u29._startFrame + p30 / v32 * v36;
            local u38 = u29._cframe:PointToWorldSpace(u29:_getPosition(u37));
            local function u49() --[[ Line: 210 ]]
                -- upvalues: u38 (copy), u29 (copy), u1 (ref), u7 (ref), l__Position__13 (copy), u35 (ref), u49 (copy), u2 (ref), u3 (ref), u33 (ref), u37 (copy), u34 (ref)
                local v39 = u38 - u29._lastPosition;
                local l__Magnitude__14 = v39.Magnitude;
                if u1 and not u29._clacked then
                    local v40, v41 = pcall(u7, Ray.new(u29._lastPosition, v39), l__Position__13);
                    if v40 and (l__Position__13 - v41).Magnitude < 35 then
                        u35 = v41;
                    end;
                end;
                local v42 = workspace:Raycast(u29._lastPosition, v39, u29._rayParams);
                if v42 then
                    local l__Instance__15 = v42.Instance;
                    local l__Position__16 = v42.Position;
                    if l__Instance__15 and (l__Instance__15:HasTag("Prefab") and l__Instance__15:GetAttribute("Prefab") == "Glass") then
                        u29:_multithreadSend(3, l__Instance__15, l__Position__16);
                        u29._rayParams:AddToFilter(l__Instance__15);
                        return u49();
                    end;
                    if l__Instance__15 and (u29._canBreach and (l__Instance__15:HasTag("Prefab") and l__Instance__15:GetAttribute("Prefab") == "Door")) then
                        u29:_multithreadSend(4, l__Instance__15, l__Position__16);
                    end;
                    local v43, v44;
                    if l__Instance__15 and (l__Instance__15:GetAttribute("ActorUID") and table.find(u2, l__Instance__15.Name)) then
                        for _, v45 in u2 do
                            local v46 = l__Instance__15.Parent:FindFirstChild(v45);
                            if v46 then
                                u29._rayParams:AddToFilter(v46);
                            end;
                        end;
                        v43 = workspace:Raycast(u29._lastPosition, v39 * 5, u29._rayParams);
                        if v43 then
                            v44 = v43.Instance;
                        else
                            v44 = v43;
                        end;
                        if v44 and (v44:GetAttribute("ActorUID") == l__Instance__15:GetAttribute("ActorUID") and table.find(u3, v44.Name)) then
                            l__Position__16 = v43.Position;
                        else
                            v43 = v42;
                            v44 = l__Instance__15;
                        end;
                    else
                        v43 = v42;
                        v44 = l__Instance__15;
                    end;
                    u33 = {
                        l__Position__16,
                        v44,
                        v43.Normal,
                        v43.Material,
                        u37 - (u38 - l__Position__16).Magnitude / u29._velocity
                    };
                    u34 = {
                        u29._originCFrame.Position,
                        l__Position__16,
                        v44,
                        v43.Normal,
                        v43.Material,
                        u29._caliber,
                        u29._local
                    };
                    u29._lastPosition = l__Position__16;
                    return true;
                end;
                if u29._totalDistance > u29._range then
                    u33 = { u29._lastPosition + v39 };
                    return true;
                end;
                if u29.CancelElapse and u37 >= u29.CancelElapse then
                    u33 = {
                        u29._lastPosition,
                        nil,
                        nil,
                        nil,
                        u37
                    };
                    return true;
                end;
                local v47 = u29;
                v47._lastPosition = v47._lastPosition + v39;
                local v48 = u29;
                v48._totalDistance = v48._totalDistance + l__Magnitude__14;
            end;
            if u49() then
                break;
            end;
        end;
        u29._lastFrame = v31;
        if u35 then
            if (u35 - u29._originCFrame.Position):Dot(u29._originCFrame.LookVector) > 0 then
                u29:_multithreadSend(4, u29._caliber, u35);
            end;
            u29._clacked = true;
        end;
        if u34 and u1 then
            u29:_multithreadSend(2, unpack(u34));
        end;
        u29._landed = u33;
    end;
end;
function u4.Update(p50, _) --[[ Line: 298 ]]
    local l___effects__17 = p50._effects;
    local l___landed__18 = p50._landed;
    if p50._destroyed then
        if l___effects__17 then
            for _, v51 in l___effects__17 do
                v51:Destroy();
            end;
            p50._effects = nil;
        end;
    else
        if l___effects__17 then
            if l___effects__17.Model then
                l___effects__17.Model.CFrame = CFrame.new(l___effects__17.Model.Position, p50._lastPosition) - l___effects__17.Model.Position + p50._lastPosition;
            else
                l___effects__17.From.CFrame = l___effects__17.To.CFrame;
                l___effects__17.To.CFrame = CFrame.new(p50._lastPosition);
            end;
        end;
        if l___landed__18 then
            p50:Landed(unpack(l___landed__18));
        end;
    end;
end;
function u4.Destroy(p52) --[[ Line: 327 ]]
    if p52._destroyed then
    else
        p52._destroyed = true;
    end;
end;
function u4.Landed(p53, ...) --[[ Line: 336 ]]
    if p53.QueueDestroy then
    else
        p53.QueueDestroy = true;
        p53:_multithreadSend(1, p53._uid, p53._replicate, ...);
    end;
end;
return u4;