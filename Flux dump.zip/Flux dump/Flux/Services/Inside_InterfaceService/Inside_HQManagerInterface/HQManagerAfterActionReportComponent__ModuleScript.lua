-- Services.InterfaceService.HQManagerInterface.HQManagerAfterActionReportComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "network");
local u3 = v1("RoactTween");
v1("StatsService");
v1("GameShellProxyButton");
v1("PopupInterface");
v1("LandingInterface");
local u4 = v1("MenuButtonComponent");
game:GetService("RunService");
Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local v5 = u2.Component:extend("HQManagerMarker");
function v5.init(u6, _) --[[ Line: 18 ]]
    -- upvalues: u3 (copy)
    u6.Open = u3.new(1, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out, 0, false, 0));
    u6._open = task.delay(0.2, function() --[[ Line: 21 ]]
        -- upvalues: u6 (copy)
        u6._open = nil;
        u6.Open:SetGoal(0);
    end);
    u6._close = task.delay(1, function() --[[ Line: 26 ]]
        -- upvalues: u6 (copy)
        u6._close = nil;
        u6:setState({
            CloseButton = true
        });
    end);
end;
function v5.willUnmount(p7) --[[ Line: 34 ]]
    if p7._open then
        task.cancel(p7._open);
        p7._open = nil;
    end;
    if p7._close then
        task.cancel(p7._close);
        p7._close = nil;
    end;
end;
function v5.render(p8) --[[ Line: 45 ]]
    -- upvalues: u2 (copy), u4 (copy)
    local l__props__1 = p8.props;
    local l__Results__2 = l__props__1.Results;
    local v9;
    if l__Results__2.Won then
        v9 = "The island was attacked on " .. os.date("%c", l__Results__2.Time) .. ". Defense personnel were successful in securing the island and only took minor casualties.\n\nResource gathering operations were unaffected by the event.";
    else
        v9 = "The island was attacked on " .. os.date("%c", l__Results__2.Time) .. ". Defense personnel were unsuccessful in securing the island and took heavy casualties.\n\nDue to the casualties sustained, resource gathering operations were immediately suspended.";
    end;
    local v10 = {};
    for v11, v12 in l__Results__2.Casualties do
        v10["Casuality" .. v11] = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            FontFace = Font.new("rbxasset://fonts/families/SpecialElite.json", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
            Position = UDim2.fromScale(0.1, (v11 - 1) * 0.02 + 0.4),
            Size = UDim2.fromScale(0.8, 0.02),
            Text = v12,
            TextColor3 = Color3.new(),
            TextXAlignment = Enum.TextXAlignment.Left,
            TextYAlignment = Enum.TextYAlignment.Top
        });
    end;
    local l__createFragment__3 = u2.createFragment;
    local v13 = {};
    local l__CloseButton__4 = p8.state.CloseButton;
    if l__CloseButton__4 then
        l__CloseButton__4 = u2.createElement(u4, {
            Ignore = l__props__1.Ignore,
            Size = UDim2.fromScale(0.35, 0.05),
            Position = UDim2.fromScale(0.5, 0.9),
            AnchorPoint = Vector2.new(0.5, 1),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            Name = l__Results__2.Won and "CLOSE" or "RESUME OPERATIONS",
            Callback = function() --[[ Name: Callback, Line 83 ]]
                -- upvalues: l__props__1 (copy)
                l__props__1.Close();
            end
        });
    end;
    v13[1], v13[2] = l__CloseButton__4, u2.createElement("ImageLabel", {
    BorderSizePixel = 0,
    Image = "rbxassetid://107855929291886",
    AnchorPoint = Vector2.new(0.5, 0),
    BackgroundColor3 = Color3.new(1, 1, 1),
    BorderColor3 = Color3.new(),
    ImageColor3 = Color3.fromRGB(255, 250, 244),
    Position = p8.Open:Map(function(p14) --[[ Line: 94 ]]
        return UDim2.fromScale(0.5, p14 + 0.1);
    end),
    ScaleType = Enum.ScaleType.Tile,
    Size = UDim2.fromScale(0.7, 0.9),
    SizeConstraint = Enum.SizeConstraint.RelativeYY,
    TileSize = UDim2.fromOffset(740, 740)
}, {
    Title = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        Text = "AFTER ACTION REPORT",
        TextScaled = true,
        FontFace = Font.new("rbxasset://fonts/families/SpecialElite.json"),
        Position = UDim2.fromScale(0.1, 0.08),
        Size = UDim2.fromScale(0.8, 0.04),
        TextColor3 = Color3.new(),
        TextXAlignment = Enum.TextXAlignment.Left,
        TextYAlignment = Enum.TextYAlignment.Top
    }),
    Date = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        FontFace = Font.new("rbxasset://fonts/families/SpecialElite.json"),
        Position = UDim2.fromScale(0.1, 0.12),
        Size = UDim2.fromScale(0.8, 0.03),
        Text = os.date("%c", l__Results__2.Time),
        TextColor3 = Color3.new(),
        TextXAlignment = Enum.TextXAlignment.Left,
        TextYAlignment = Enum.TextYAlignment.Top
    }),
    Outcome = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        FontFace = Font.new("rbxasset://fonts/families/SpecialElite.json"),
        Position = UDim2.fromScale(0.1, 0.18),
        Size = UDim2.fromScale(0.8, 0.02),
        Text = "Outcome: " .. (l__Results__2.Won and "WIN" or "LOSS"),
        TextColor3 = Color3.new(),
        TextXAlignment = Enum.TextXAlignment.Left,
        TextYAlignment = Enum.TextYAlignment.Top
    }),
    Description = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        FontFace = Font.new("rbxasset://fonts/families/SpecialElite.json", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
        Position = UDim2.fromScale(0.1, 0.22),
        Size = UDim2.fromScale(0.8, 0.12),
        Text = v9,
        TextColor3 = Color3.new(),
        TextXAlignment = Enum.TextXAlignment.Left,
        TextYAlignment = Enum.TextYAlignment.Top
    }),
    Casualties = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        Text = "Casualties:",
        TextScaled = true,
        FontFace = Font.new("rbxasset://fonts/families/SpecialElite.json"),
        Position = UDim2.fromScale(0.1, 0.36),
        Size = UDim2.fromScale(0.8, 0.02),
        TextColor3 = Color3.new(),
        TextXAlignment = Enum.TextXAlignment.Left,
        TextYAlignment = Enum.TextYAlignment.Top
    }),
    u2.createFragment(v10)
});
    return l__createFragment__3(v13);
end;
return v5;