-- Services.InterfaceService.HQManagerInterface.HQManagerPersonnelComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Roact", "Enum", "network");
local l__RunService__1 = game:GetService("RunService");
local u5 = v1("RoactTween");
local u6 = v1("StatsService");
local u7 = v1("GameShellProxyScroller");
local u8 = v1("PopupInterface");
local u9 = v1("MenuButtonComponent");
local u10 = v1("CompanyInfo");
local u11 = v1("levelToRating");
local u12 = v1("formatNumber");
local u13 = Font.fromId(12187375422, u3.FontWeight.Bold, u3.FontStyle.Normal);
Font.fromId(12187375422, u3.FontWeight.Regular, u3.FontStyle.Normal);
local u14 = {
    "Construction Materials",
    "Precious Metals",
    "Fuel",
    "Equipment"
};
local u15 = {
    "Material",
    "Metal",
    "Fuel",
    "Equipment"
};
local u16 = {
    "Logistics",
    "Combat",
    "Mechanics",
    "Command",
    "Deliveries",
    "Medical"
};
local v17 = u2.Component:extend("HQManagerMarker");
local function u22(p18) --[[ Line: 46 ]]
    local v19 = p18 % 60;
    local v20 = math.floor(p18 / 60) % 60;
    local v21 = math.floor(p18 / 3600) % 24;
    if p18 <= 0 then
        v21 = 0;
        v20 = 0;
        v19 = 0;
    end;
    return string.format("%02i", v21) .. ":" .. string.format("%02i", v20) .. ":" .. string.format("%02i", v19);
end;
function v17.init(u23, u24) --[[ Line: 59 ]]
    -- upvalues: u5 (copy), u3 (copy), u2 (copy), u16 (copy), u11 (copy), l__RunService__1 (copy)
    u23.Open = u5.new(0, TweenInfo.new(1, u3.EasingStyle.Exponential, u3.EasingDirection.Out, 0, false, 0));
    u23.Open:SetGoal(1);
    u23.ScrollerRef = u2.createRef();
    function u23.CreateEmployee(p25, p26, p27, p28, p29) --[[ Line: 64 ]]
        -- upvalues: u24 (copy), u16 (ref), u11 (ref), u2 (ref), u3 (ref)
        local l__Department__2 = u24.Department;
        local v30 = u24.Page == "Training";
        local v31 = {};
        for v32, v33 in u16 do
            local l__Skill__3 = l__Department__2.Skill;
            if l__Skill__3 then
                l__Skill__3 = table.find(l__Department__2.Skill, v33);
            end;
            if v30 then
                l__Skill__3 = v33 == p26.Training.Skill;
            end;
            if p29 then
                l__Skill__3 = false;
            end;
            local v34, v35 = u11(p26.Skills[v33] or 0);
            v31["Skill" .. v32] = u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(255, 194, 89),
                BackgroundTransparency = l__Skill__3 and 0.8 or 1,
                BorderColor3 = Color3.new(),
                LayoutOrder = v32
            }, { u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422"),
                    Position = UDim2.fromScale(0, 0.5),
                    Size = UDim2.fromScale(1, 0.6),
                    Text = v34,
                    TextColor3 = v35
                }) });
        end;
        local l__createElement__4 = u2.createElement;
        local v36 = "Frame";
        local v37 = {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            LayoutOrder = p25,
            BackgroundColor3 = p28,
            BorderColor3 = Color3.new(),
            Size = UDim2.fromScale(1, 0.09)
        };
        local v38 = {
            Line = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 1),
                Size = UDim2.fromScale(1, 0.03)
            })
        };
        local l__createElement__5 = u2.createElement;
        local v39 = "Frame";
        local v40 = {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(1, 0.97)
        };
        local v41 = {
            Name = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422"),
                Position = UDim2.fromScale(0.025, p26.Health and 0.4 or 0.5),
                Size = UDim2.fromScale(0.3, p26.Health and 0.5 or 0.6),
                Text = p26.Name,
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Left
            })
        };
        local l__Health__6 = p26.Health;
        if l__Health__6 then
            l__Health__6 = u2.createElement("Frame", {
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 0.5),
                BackgroundColor3 = Color3.fromRGB(255, 0, 0),
                Position = UDim2.fromScale(0.025, 0.75),
                Size = UDim2.fromScale(0.1, 0.05)
            }, {
                Bar = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.fromRGB(85, 255, 0),
                    Size = UDim2.fromScale(p26.Health / 100, 1)
                })
            });
        end;
        v41[1] = l__Health__6;
        v41.Skills = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Position = UDim2.fromScale(0.2, 0),
            Size = UDim2.fromScale(0.2, 1)
        }, {
            UIGridLayout = u2.createElement("UIGridLayout", {
                CellPadding = UDim2.new(),
                CellSize = UDim2.fromScale(1 / #u16 - 0.001, 1),
                SortOrder = u3.SortOrder.LayoutOrder
            }),
            u2.createFragment(v31)
        });
        v41[2] = u2.createFragment(p27);
        v38.Content = l__createElement__5(v39, v40, v41);
        v38.Gradient = u2.createElement("UIGradient", {
            Rotation = -90,
            Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.5375) })
        });
        return l__createElement__4(v36, v37, v38);
    end;
    local v42, v43 = u2.createBinding(os.time());
    u23.UpdateBinding = v42;
    u23.UpdateUpdate = v43;
    u23.Connection = l__RunService__1.Heartbeat:Connect(function(_) --[[ Line: 169 ]]
        -- upvalues: u24 (copy), u23 (copy)
        if os.time() >= u24.Company.Hiring.NextRoll and u23.state.ShowHires then
            u23:setState({
                ShowHires = false
            });
        end;
        u23.UpdateUpdate(os.time());
    end);
    u23:setState({
        ShowHires = os.time() < u24.Company.Hiring.NextRoll
    });
end;
function v17.willUnmount(p44) --[[ Line: 184 ]]
    p44.Connection:Disconnect();
end;
function v17.render(u45) --[[ Line: 188 ]]
    -- upvalues: u16 (copy), u2 (copy), u10 (copy), u3 (copy), u9 (copy), u6 (copy), u8 (copy), u12 (copy), u4 (copy), u13 (copy), u14 (copy), u15 (copy), u11 (copy), u22 (copy), u7 (copy)
    local l__props__7 = u45.props;
    local l__state__8 = u45.state;
    local l__Department__9 = l__props__7.Department;
    local l__Page__10 = l__props__7.Page;
    local l__Company__11 = l__props__7.Company;
    local v46 = l__Company__11:GetCapacity(l__Page__10);
    local v47 = l__Page__10 == "Command";
    local u48 = l__Page__10 == "Training";
    local v49 = l__Page__10 == "Barracks";
    local v50 = l__Page__10 == "Infirmary";
    local v51 = l__Page__10 == "Operations";
    local v52 = l__Page__10 == "Defenses";
    local v53 = 0;
    local v54 = {};
    local v55 = 0;
    local v56 = {};
    local v57 = 0;
    local v58 = 0;
    local v59 = 0;
    local v60 = 0;
    local v61 = {
        0,
        0,
        0,
        0
    };
    for _, v62 in l__Company__11.Employees do
        if v51 and (v62.Assigned == "Operations" and v62.Health >= 10) then
            v60 = v60 + 86400 / l__Company__11:GetOperationSpeed(v62, 1);
            local l__Focus__12 = v62.Operation.Focus;
            v61[l__Focus__12] = v61[l__Focus__12] + 86400 / l__Company__11:GetOperationSpeed(v62, v62.Operation.Focus);
        end;
        if u48 and (v62.Assigned == "Training" and v62.Training.IsTeacher) then
            local l__Skill__13 = v62.Training.Skill;
            if v56[l__Skill__13] then
                v56[l__Skill__13] = math.max(v56[l__Skill__13], v62.Skills[l__Skill__13]);
            else
                v56[l__Skill__13] = v62.Skills[l__Skill__13];
            end;
        end;
        if v50 and v62.Assigned == "Infirmary" then
            if v62.Infirmary.IsDoctor then
                v58 = v58 + l__Company__11:GetDoctorEfficiency(v62);
            else
                v55 = v55 + 1;
            end;
        end;
        if v62.Assigned == l__Page__10 or v49 then
            v57 = v57 + 1;
            v54[#v54 + 1] = v62;
            if not v50 or v62.Infirmary.IsDoctor then
                for _, v63 in l__Department__9.Skill or u16 do
                    v53 = v53 + (v62.Skills[v63] or 0);
                    v59 = v59 + 1;
                end;
            end;
        end;
    end;
    local v64 = v58 / v55;
    local v65 = v53 / math.max(1, v59);
    local v66 = {};
    for v67, v68 in u16 do
        local l__Skill__14 = l__Department__9.Skill;
        if l__Skill__14 then
            l__Skill__14 = table.find(l__Department__9.Skill, v68);
        end;
        if v47 then
            l__Skill__14 = false;
        end;
        v66["Skill" .. v67] = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.fromRGB(255, 194, 89),
            BackgroundTransparency = l__Skill__14 and 0 or 1,
            BorderColor3 = Color3.new(),
            LayoutOrder = v67
        }, { u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Image = "rbxassetid://" .. u10.Skills[v68].Icon,
                ImageColor3 = (v47 or l__Skill__14) and Color3.new() or Color3.new(1, 1, 1),
                Position = UDim2.fromScale(0.5, 0.5),
                Size = UDim2.fromScale(0.4, 0.4),
                SizeConstraint = u3.SizeConstraint.RelativeYY
            }) });
    end;
    if v49 then
        table.sort(v54, function(p69, p70) --[[ Line: 287 ]]
            -- upvalues: l__Company__11 (copy)
            return l__Company__11:GetTotalSkill(p69) + (p69.Assigned == "Unassigned" and 1000 or 0) > l__Company__11:GetTotalSkill(p70) + (p70.Assigned == "Unassigned" and 1000 or 0);
        end);
    elseif u48 or v50 then
        table.sort(v54, function(p71, p72) --[[ Line: 293 ]]
            -- upvalues: u48 (copy)
            local v73 = u48 and p71.Skills[p71.Training.Skill] or p71.Skills.Medical;
            local v74 = u48 and p72.Skills[p72.Training.Skill] or p72.Skills.Medical;
            if p71.Training.IsTeacher or p71.Infirmary.IsDoctor then
                v73 = v73 + 1000;
            end;
            if p72.Training.IsTeacher or p72.Infirmary.IsDoctor then
                v74 = v74 + 1000;
            end;
            return v74 < v73;
        end);
    elseif l__Department__9.Skill then
        table.sort(v54, function(p75, p76) --[[ Line: 306 ]]
            -- upvalues: l__Department__9 (copy)
            local v77 = 0;
            local v78 = 0;
            for _, v79 in l__Department__9.Skill do
                v77 = v77 + (p75.Skills[v79] or 0);
                v78 = v78 + (p76.Skills[v79] or 0);
            end;
            return v78 < v77;
        end);
    end;
    local v80 = {};
    local v81 = #v54;
    local v82 = l__state__8.ShowHires and (math.max(1, #l__Company__11.Hiring.Hires) or 1) or 1;
    if v47 then
        v81 = v81 + (v82 + 1);
        if l__state__8.ShowHires then
            if #l__Company__11.Hiring.Hires > 0 then
                for u83, u84 in l__Company__11.Hiring.Hires do
                    local v87 = {
                        Hire = u2.createElement(u9, {
                            Name = "HIRE",
                            Ignore = l__props__7.Ignore,
                            Size = UDim2.fromScale(0.15, 0.6),
                            Position = UDim2.fromScale(0.95, 0.5),
                            AnchorPoint = Vector2.new(1, 0.5),
                            Callback = function() --[[ Name: Callback, Line 375 ]]
                                -- upvalues: u6 (ref), u84 (copy), u8 (ref), u12 (ref), l__Company__11 (copy), u4 (ref), u83 (copy), u45 (copy)
                                if u6.Money < u84.Cost then
                                    local v85 = {
                                        { "Close", function() --[[ Line: 378 ]]
                                                -- upvalues: u8 (ref)
                                                u8:Close();
                                            end }
                                    };
                                    u8:Open("Not enough money", "You need " .. u12(u84.Cost - u6.Money) .. " more to hire this employee", v85);
                                elseif #l__Company__11.Employees >= l__Company__11:GetCapacity("Barracks") then
                                    u8:Open("Not enough capacity", "You need to upgrade your barracks to hire more employees", {
                                        { "Close", function() --[[ Line: 384 ]]
                                                -- upvalues: u8 (ref)
                                                u8:Close();
                                            end }
                                    });
                                else
                                    local v86 = {
                                        { "Hire", function() --[[ Line: 390 ]]
                                                -- upvalues: u4 (ref), u83 (ref), l__Company__11 (ref), u84 (ref), u45 (ref), u8 (ref)
                                                u4:FireServer("ActivateInteract", "Hire", u83);
                                                table.remove(l__Company__11.Hiring.Hires, u83);
                                                l__Company__11:AddEmployee(u84);
                                                u45:setState({});
                                                u8:Open("Hiring Complete", "\'" .. u84.Name .. "\' is now an un-assigned employee.\n\nHead to the \'BARRACKS\' to assign them to a department.", {
                                                    { "Close", function() --[[ Line: 397 ]]
                                                            -- upvalues: u8 (ref)
                                                            u8:Close();
                                                        end }
                                                });
                                            end },
                                        { "Cancel", function() --[[ Line: 402 ]]
                                                -- upvalues: u8 (ref)
                                                u8:Close();
                                            end }
                                    };
                                    u8:Open("Hire Employee", "Are you sure you want to hire \'" .. u84.Name .. "\' for " .. u12(u84.Cost) .. "?", v86);
                                end;
                            end
                        }),
                        Cost = u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            TextScaled = true,
                            AnchorPoint = Vector2.new(0, 0.5),
                            FontFace = u13,
                            Position = UDim2.fromScale(0.435, 0.5),
                            Size = UDim2.fromScale(0.2, 0.6),
                            Text = u12(u84.Cost),
                            TextColor3 = Color3.new(1, 1, 1),
                            TextXAlignment = u3.TextXAlignment.Center
                        })
                    };
                    v80["Employee" .. u83] = u45.CreateEmployee(u83, u84, v87, Color3.new(), true);
                end;
            else
                v80.Employee = u2.createElement("Frame", {
                    LayoutOrder = 1,
                    BackgroundTransparency = 0.5,
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.new(),
                    BorderColor3 = Color3.new(),
                    Size = UDim2.fromScale(1, 0.09)
                }, {
                    Line = u2.createElement("Frame", {
                        BackgroundTransparency = 0.5,
                        BorderSizePixel = 0,
                        AnchorPoint = Vector2.new(0, 1),
                        BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                        BorderColor3 = Color3.new(),
                        Position = UDim2.fromScale(0, 1),
                        Size = UDim2.fromScale(1, 0.03)
                    }),
                    Content = u2.createElement("Frame", {
                        BackgroundTransparency = 1,
                        Size = UDim2.fromScale(1, 0.97)
                    }, {
                        Message = u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            Text = "You have no current hiring candidates, wait for the next hiring re-roll.",
                            TextScaled = true,
                            AnchorPoint = Vector2.new(0, 0.5),
                            FontFace = Font.new("rbxassetid://12187375422"),
                            Position = UDim2.fromScale(0, 0.5),
                            Size = UDim2.fromScale(1, 0.6),
                            TextColor3 = Color3.new(1, 1, 1),
                            TextXAlignment = u3.TextXAlignment.Center
                        })
                    }),
                    Gradient = u2.createElement("UIGradient", {
                        Rotation = -90,
                        Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.5375) })
                    })
                });
            end;
        else
            v80.Warning = u2.createElement("Frame", {
                LayoutOrder = 1,
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.new(),
                BorderColor3 = Color3.new(),
                Size = UDim2.fromScale(1, 0.09)
            }, {
                Line = u2.createElement("Frame", {
                    BackgroundTransparency = 0.5,
                    BorderSizePixel = 0,
                    AnchorPoint = Vector2.new(0, 1),
                    BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                    BorderColor3 = Color3.new(),
                    Position = UDim2.fromScale(0, 1),
                    Size = UDim2.fromScale(1, 0.03)
                }),
                Content = u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Size = UDim2.fromScale(1, 0.97)
                }, {
                    Message = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        Text = "Candidate list is out-of-date, please exit and re-enter the \'HQ Manager\' tablet.",
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = Font.new("rbxassetid://12187375422"),
                        Position = UDim2.fromScale(0, 0.5),
                        Size = UDim2.fromScale(1, 0.6),
                        TextColor3 = Color3.new(1, 1, 1),
                        TextXAlignment = u3.TextXAlignment.Center
                    })
                }),
                Gradient = u2.createElement("UIGradient", {
                    Rotation = -90,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.5375) })
                })
            });
        end;
    elseif u48 or v50 then
        v81 = v81 + 1;
    end;
    local v88 = math.max(11.1, v81);
    local v89 = 1 / v88;
    v80.Grid = u2.createElement("UIGridLayout", {
        CellPadding = UDim2.fromScale(0, 0),
        CellSize = UDim2.fromScale(1, v89),
        FillDirection = u3.FillDirection.Vertical,
        HorizontalAlignment = u3.HorizontalAlignment.Left,
        SortOrder = u3.SortOrder.LayoutOrder,
        StartCorner = u3.StartCorner.TopLeft,
        VerticalAlignment = u3.VerticalAlignment.Top
    });
    local v90 = 0;
    local v91 = 0;
    local v92 = nil;
    local v93 = 0;
    for v108, u95 in v54 do
        local v98 = {
            Reassign = u2.createElement(u9, {
                Ignore = l__props__7.Ignore,
                Size = UDim2.fromScale(0.15, 0.6),
                Position = UDim2.fromScale(0.95, 0.5),
                AnchorPoint = Vector2.new(1, 0.5),
                Name = u95.Assigned:upper(),
                Callback = function() --[[ Name: Callback, Line 495 ]]
                    -- upvalues: l__props__7 (copy), u95 (copy)
                    l__props__7.Reassign(u95.Index);
                end
            }),
            Dismiss = u2.createElement(u9, {
                Name = "X",
                Ignore = l__props__7.Ignore,
                Size = UDim2.fromScale(0.03, 0.6),
                Position = UDim2.fromScale(0.99, 0.5),
                AnchorPoint = Vector2.new(1, 0.5),
                Callback = function() --[[ Name: Callback, Line 505 ]]
                    -- upvalues: u95 (copy), u8 (ref), u4 (ref), l__Company__11 (copy), u45 (copy)
                    if u95.Delivery > os.time() then
                        u8:Open("Delivery in progress", "You cannot remove \'" .. u95.Name .. "\' as they are currently completing a delivery. \n\nYou can track their delivery in the \'DELIVERIES\' department.", {
                            { "Cancel", function() --[[ Line: 508 ]]
                                    -- upvalues: u8 (ref)
                                    u8:Close();
                                end }
                        });
                    else
                        u8:Open("Remove Employee", "Are you sure you want to remove \'" .. u95.Name .. "\'?\n\nYOU CANNOT RE-HIRE THIS EMPLOYEE. THEY ARE GONE FOREVER.", {
                            { "Remove", function() --[[ Line: 516 ]]
                                    -- upvalues: u4 (ref), u95 (ref), l__Company__11 (ref), u45 (ref), u8 (ref)
                                    u4:FireServer("ActivateInteract", "Dismiss", u95.Index);
                                    table.remove(l__Company__11.Employees, u95.Index);
                                    for v96, v97 in l__Company__11.Employees do
                                        v97.Index = v96;
                                    end;
                                    u45:setState({});
                                    u8:Close();
                                end },
                            { "Cancel", function() --[[ Line: 526 ]]
                                    -- upvalues: u8 (ref)
                                    u8:Close();
                                end }
                        });
                    end;
                end
            })
        };
        local v99 = false;
        local v100 = Color3.new();
        if l__Page__10 == "Mechanics" then
            v98.Class = u2.createElement(u9, {
                Ignore = l__props__7.Ignore,
                Size = UDim2.fromScale(0.15, 0.6),
                Position = UDim2.fromScale(0.435, 0.5),
                AnchorPoint = Vector2.new(0, 0.5),
                Name = u95.Mechanic:upper(),
                Callback = function() --[[ Name: Callback, Line 543 ]]
                    -- upvalues: u8 (ref), l__props__7 (copy), u95 (copy), u3 (ref)
                    u8:Open("Assign division", "What type of vehicle should this employee work on?", {
                        { "Ground", function() --[[ Line: 545 ]]
                                -- upvalues: l__props__7 (ref), u95 (ref), u8 (ref)
                                l__props__7.AssignEmployee(u95.Index, "Mechanics", "Ground");
                                u8:Close();
                            end },
                        { "Helicopter", function() --[[ Line: 549 ]]
                                -- upvalues: l__props__7 (ref), u95 (ref), u8 (ref)
                                l__props__7.AssignEmployee(u95.Index, "Mechanics", "Helicopter");
                                u8:Close();
                            end },
                        { "Plane", function() --[[ Line: 553 ]]
                                -- upvalues: l__props__7 (ref), u95 (ref), u8 (ref)
                                l__props__7.AssignEmployee(u95.Index, "Mechanics", "Plane");
                                u8:Close();
                            end },
                        { "Cancel", function() --[[ Line: 557 ]]
                                -- upvalues: u8 (ref)
                                u8:Close();
                            end }
                    }, u3.PopupType.Vertical);
                end
            });
        elseif l__Page__10 == "Operations" then
            if u95.Health >= 10 then
                v98.Resource = u2.createElement(u9, {
                    Ignore = l__props__7.Ignore,
                    Size = UDim2.fromScale(0.2, 0.6),
                    Position = UDim2.fromScale(0.435, 0.5),
                    AnchorPoint = Vector2.new(0, 0.5),
                    Name = u14[u95.Operation.Focus]:upper(),
                    Callback = function() --[[ Name: Callback, Line 571 ]]
                        -- upvalues: u8 (ref), l__props__7 (copy), u95 (copy), u3 (ref)
                        u8:Open("Resource focus", "What resource should this employee gather?", {
                            { "Construction Materials", function() --[[ Line: 573 ]]
                                    -- upvalues: l__props__7 (ref), u95 (ref), u8 (ref)
                                    l__props__7.AssignEmployee(u95.Index, "Operations", 1);
                                    u8:Close();
                                end },
                            { "Precious Metals", function() --[[ Line: 577 ]]
                                    -- upvalues: l__props__7 (ref), u95 (ref), u8 (ref)
                                    l__props__7.AssignEmployee(u95.Index, "Operations", 2);
                                    u8:Close();
                                end },
                            { "Fuel", function() --[[ Line: 581 ]]
                                    -- upvalues: l__props__7 (ref), u95 (ref), u8 (ref)
                                    l__props__7.AssignEmployee(u95.Index, "Operations", 3);
                                    u8:Close();
                                end },
                            { "Equipment", function() --[[ Line: 585 ]]
                                    -- upvalues: l__props__7 (ref), u95 (ref), u8 (ref)
                                    l__props__7.AssignEmployee(u95.Index, "Operations", 4);
                                    u8:Close();
                                end },
                            { "Cancel", function() --[[ Line: 589 ]]
                                    -- upvalues: u8 (ref)
                                    u8:Close();
                                end }
                        }, u3.PopupType.Vertical);
                    end
                });
                local l__createElement__15 = u2.createElement;
                local v101 = {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422"),
                    Position = UDim2.fromScale(0.665, 0.5),
                    Size = UDim2.fromScale(0.1, 0.6)
                };
                local v102 = 86400 / l__Company__11:GetOperationSpeed(u95, u95.Operation.Focus) * 10;
                local v103 = math.floor(v102) / 10;
                v101.Text = tostring(v103) .. "/day";
                v101.TextColor3 = u10.Resources[u15[u95.Operation.Focus]].Color;
                v101.TextXAlignment = u3.TextXAlignment.Center;
                v98.Rate = l__createElement__15("TextLabel", v101);
            else
                v98.Warning = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "Critical condition: assign to infirmary",
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Position = UDim2.fromScale(0.42, 0.5),
                    Size = UDim2.fromScale(0.36, 0.6),
                    TextColor3 = Color3.new(1, 1, 1)
                });
            end;
        elseif l__Page__10 == "Logistics" then
            v98.Tab = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = u13,
                Position = UDim2.fromScale(0.435, 0.5),
                Size = UDim2.fromScale(0.2, 0.6),
                Text = l__Company__11:GetAddedCapacity(u95),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Center
            });
        elseif l__Page__10 == "Deliveries" then
            local l__createElement__16 = u2.createElement;
            local v104 = {
                BackgroundTransparency = 1,
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = u13,
                Position = UDim2.fromScale(0.435, 0.5),
                Size = UDim2.fromScale(0.2, 0.6)
            };
            local v105 = 100 + l__Company__11:GetAddedEfficiency(u95) * 100;
            v104.Text = math.floor(v105) .. "%";
            v104.TextColor3 = Color3.new(1, 1, 1);
            v104.TextXAlignment = u3.TextXAlignment.Center;
            v98.Tab = l__createElement__16("TextLabel", v104);
        elseif l__Page__10 == "Research" then
            local l__createElement__17 = u2.createElement;
            local v106 = {
                BackgroundTransparency = 1,
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = u13,
                Position = UDim2.fromScale(0.435, 0.5),
                Size = UDim2.fromScale(0.2, 0.6)
            };
            local v107 = l__Company__11:GetResearchEfficiency(u95) * 100;
            v106.Text = math.floor(v107) .. "%";
            v106.TextColor3 = Color3.new(1, 1, 1);
            v106.TextXAlignment = u3.TextXAlignment.Center;
            v98.Tab = l__createElement__17("TextLabel", v106);
        elseif v49 then
            if u95.Assigned == "Unassigned" then
                v90 = v90 + 1;
                v100 = Color3.new(0.2, 0, 0);
            end;
        else
            local v108;
            if u48 then
                local l__IsTeacher__18 = u95.Training.IsTeacher;
                v98.Focus = u2.createElement(u9, {
                    Ignore = l__props__7.Ignore,
                    Size = UDim2.fromScale(0.2, 0.6),
                    Position = UDim2.fromScale(0.435, 0.5),
                    AnchorPoint = Vector2.new(0, 0.5),
                    Name = u95.Training.Skill:upper(),
                    Callback = function() --[[ Name: Callback, Line 671 ]]
                        -- upvalues: u8 (ref), l__IsTeacher__18 (copy), l__props__7 (copy), u95 (copy), u3 (ref)
                        u8:Open("Curriculum type", "What skill should this employee focus on " .. (l__IsTeacher__18 and "teaching?" or "improving?"), {
                            { "Logistics", function() --[[ Line: 673 ]]
                                    -- upvalues: l__props__7 (ref), u95 (ref), l__IsTeacher__18 (ref), u8 (ref)
                                    l__props__7.AssignEmployee(u95.Index, "Training", l__IsTeacher__18, "Logistics");
                                    u8:Close();
                                end },
                            { "Combat", function() --[[ Line: 677 ]]
                                    -- upvalues: l__props__7 (ref), u95 (ref), l__IsTeacher__18 (ref), u8 (ref)
                                    l__props__7.AssignEmployee(u95.Index, "Training", l__IsTeacher__18, "Combat");
                                    u8:Close();
                                end },
                            { "Mechanics", function() --[[ Line: 681 ]]
                                    -- upvalues: l__props__7 (ref), u95 (ref), l__IsTeacher__18 (ref), u8 (ref)
                                    l__props__7.AssignEmployee(u95.Index, "Training", l__IsTeacher__18, "Mechanics");
                                    u8:Close();
                                end },
                            { "Command", function() --[[ Line: 685 ]]
                                    -- upvalues: l__props__7 (ref), u95 (ref), l__IsTeacher__18 (ref), u8 (ref)
                                    l__props__7.AssignEmployee(u95.Index, "Training", l__IsTeacher__18, "Command");
                                    u8:Close();
                                end },
                            { "Deliveries", function() --[[ Line: 689 ]]
                                    -- upvalues: l__props__7 (ref), u95 (ref), l__IsTeacher__18 (ref), u8 (ref)
                                    l__props__7.AssignEmployee(u95.Index, "Training", l__IsTeacher__18, "Deliveries");
                                    u8:Close();
                                end },
                            { "Medical", function() --[[ Line: 693 ]]
                                    -- upvalues: l__props__7 (ref), u95 (ref), l__IsTeacher__18 (ref), u8 (ref)
                                    l__props__7.AssignEmployee(u95.Index, "Training", l__IsTeacher__18, "Medical");
                                    u8:Close();
                                end },
                            { "Cancel", function() --[[ Line: 697 ]]
                                    -- upvalues: u8 (ref)
                                    u8:Close();
                                end }
                        }, u3.PopupType.Vertical);
                    end
                });
                if l__IsTeacher__18 then
                    v98.Rate = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        Text = "-",
                        TextTransparency = 0.5,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = Font.new("rbxassetid://12187375422"),
                        Position = UDim2.fromScale(0.665, 0.5),
                        Size = UDim2.fromScale(0.1, 0.6),
                        TextColor3 = Color3.new(1, 1, 1),
                        TextXAlignment = u3.TextXAlignment.Center
                    });
                else
                    local v109, v110 = u11(u95.Training.StartingLevel);
                    v98.Rate = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = Font.new("rbxassetid://12187375422"),
                        Position = UDim2.fromScale(0.665, 0.5),
                        Size = UDim2.fromScale(0.1, 0.6),
                        Text = v109,
                        TextColor3 = v110,
                        TextXAlignment = u3.TextXAlignment.Center
                    });
                    local l__Skill__19 = u95.Training.Skill;
                    if v56[l__Skill__19] then
                        if v56[l__Skill__19] <= u95.Skills[l__Skill__19] then
                            v91 = v91 + 1;
                            v100 = Color3.new(0.403921, 0.313725, 0);
                        end;
                    else
                        v93 = v93 + 1;
                        v100 = Color3.new(0.2, 0, 0);
                    end;
                    v92 = v92 or v108;
                    v108 = v108 + 1;
                end;
            elseif v50 then
                local l__IsDoctor__20 = u95.Infirmary.IsDoctor;
                if l__IsDoctor__20 then
                    local l__createElement__21 = u2.createElement;
                    local v111 = {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = u13,
                        Position = UDim2.fromScale(0.435, 0.5),
                        Size = UDim2.fromScale(0.2, 0.6)
                    };
                    local v112 = l__Company__11:GetDoctorEfficiency(u95) * 100;
                    v111.Text = math.floor(v112) .. "%";
                    v111.TextColor3 = Color3.new(1, 1, 1);
                    v111.TextXAlignment = u3.TextXAlignment.Center;
                    v98.Tab = l__createElement__21("TextLabel", v111);
                else
                    if v64 > 0 then
                        local u113 = u95.Infirmary.Started + (100 - u95.Health) / l__Company__11:GetHealingMultiplier(u95, v64);
                        v98.Tab = u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            TextScaled = true,
                            AnchorPoint = Vector2.new(0, 0.5),
                            FontFace = u13,
                            Position = UDim2.fromScale(0.435, 0.5),
                            Size = UDim2.fromScale(0.2, 0.6),
                            Text = u45.UpdateBinding:map(function(p114) --[[ Line: 768 ]]
                                -- upvalues: u22 (ref), u113 (copy)
                                return u22(u113 - p114);
                            end),
                            TextColor3 = Color3.new(1, 1, 1),
                            TextXAlignment = u3.TextXAlignment.Center
                        });
                    else
                        v100 = Color3.new(0.2, 0, 0);
                    end;
                    v92 = v92 or v108;
                    v108 = v108 + 1;
                    v99 = true;
                end;
                v98.Move = u2.createElement(u9, {
                    Ignore = l__props__7.Ignore,
                    Size = UDim2.fromScale(0.03, 0.6),
                    Position = UDim2.fromScale(0.79, 0.5),
                    AnchorPoint = Vector2.new(1, 0.5),
                    Name = l__IsDoctor__20 and "↓" or "↑",
                    Callback = function() --[[ Name: Callback, Line 792 ]]
                        -- upvalues: l__props__7 (copy), u95 (copy), l__IsDoctor__20 (copy)
                        l__props__7.AssignEmployee(u95.Index, "Infirmary", not l__IsDoctor__20);
                    end
                });
            elseif v52 then
                if u95.Health < 10 then
                    v98.Warning = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        Text = "Critical condition: assign to infirmary",
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                        Position = UDim2.fromScale(0.42, 0.5),
                        Size = UDim2.fromScale(0.36, 0.6),
                        TextColor3 = Color3.new(1, 1, 1)
                    });
                    v100 = Color3.new(0.2, 0, 0);
                else
                    local l__createElement__22 = u2.createElement;
                    local v115 = {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = u13,
                        Position = UDim2.fromScale(0.435, 0.5),
                        Size = UDim2.fromScale(0.2, 0.6)
                    };
                    local v116 = l__Company__11:GetDefenseEfficiency(u95) * 100;
                    v115.Text = math.floor(v116) .. "%";
                    v115.TextColor3 = Color3.new(1, 1, 1);
                    v115.TextXAlignment = u3.TextXAlignment.Center;
                    v98.Tab = l__createElement__22("TextLabel", v115);
                end;
            elseif v47 then
                v108 = v108 + (v82 + 1);
            end;
        end;
        v80["Employee" .. v108] = u45.CreateEmployee(v108, u95, v98, v100, v99);
    end;
    local v117 = v92 or #v54 + 1;
    local v118 = {};
    local v119 = {};
    if l__Page__10 == "Mechanics" then
        v118.Tab = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "DIVISION",
            TextScaled = true,
            AnchorPoint = Vector2.new(0, 0.5),
            FontFace = u13,
            Position = UDim2.fromScale(0.435, 0.5),
            Size = UDim2.fromScale(0.15, 0.6),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Center
        });
    elseif l__Page__10 == "Operations" then
        v118.Tab = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "RESOURCE",
            TextScaled = true,
            AnchorPoint = Vector2.new(0, 0.5),
            FontFace = u13,
            Position = UDim2.fromScale(0.435, 0.5),
            Size = UDim2.fromScale(0.2, 0.6),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Center
        });
        v118.Rate = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "RATE",
            TextScaled = true,
            AnchorPoint = Vector2.new(0, 0.5),
            FontFace = u13,
            Position = UDim2.fromScale(0.665, 0.5),
            Size = UDim2.fromScale(0.1, 0.6),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Center
        });
        local v120 = {};
        local v121 = 0;
        local v122 = {};
        for v123, v124 in v61 do
            local v125 = u15[v123];
            local l__Color__23 = u10.Resources[v125].Color;
            local v126 = math.ceil(v124 / v60 * 360);
            local v127 = math.floor(v124 * 10) / 10;
            v120[v125] = tostring(v127) .. "/day";
            for u128 = v121 + 1, v121 + v126 do
                if u128 % 3 == 1 then
                    v122[u128] = u2.createElement("Frame", {
                        BackgroundTransparency = 1,
                        AnchorPoint = Vector2.new(0.5, 0.5),
                        Position = UDim2.fromScale(0.5, 0.5),
                        Size = UDim2.fromScale(0.05, 0.05),
                        Rotation = u45.Open:Map(function(p129) --[[ Line: 892 ]]
                            -- upvalues: u128 (copy)
                            return p129 * u128;
                        end),
                        ZIndex = u128
                    }, { u2.createElement("Frame", {
                            BorderSizePixel = 0,
                            Position = UDim2.fromScale(0, 8.5),
                            Size = UDim2.fromScale(1, 4),
                            BackgroundColor3 = l__Color__23
                        }) });
                end;
            end;
            v121 = v121 + v126;
        end;
        v119.Distribution = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0, 0.62),
            Size = UDim2.fromScale(0.2, 0.38)
        }, {
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                ScaleType = u3.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 139,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                })
            }),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0.5, 0),
                Size = UDim2.fromScale(0.4, 0.4),
                Position = UDim2.fromScale(0.35, 0.2),
                SizeConstraint = u3.SizeConstraint.RelativeYY
            }, { u2.createElement("UIStroke", {
                    Thickness = 1,
                    Color = Color3.new(1, 1, 1)
                }), u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.5, 0)
                }), u2.createFragment(v122) }),
            Construction = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0.55, 0.2),
                Size = UDim2.fromScale(0.2, 0.08),
                Text = v120.Material,
                TextColor3 = u10.Resources.Material.Color,
                TextXAlignment = u3.TextXAlignment.Right
            }, {
                ImageLabel = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Image = u10.Resources.Material.Icon,
                    ImageColor3 = u10.Resources.Material.Color,
                    Position = UDim2.fromScale(1.1, 0),
                    Size = UDim2.fromScale(1, 1),
                    SizeConstraint = u3.SizeConstraint.RelativeYY
                })
            }),
            Metals = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0.55, 0.3),
                Size = UDim2.fromScale(0.2, 0.08),
                Text = v120.Metal,
                TextColor3 = u10.Resources.Metal.Color,
                TextXAlignment = u3.TextXAlignment.Right
            }, {
                ImageLabel = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Image = u10.Resources.Metal.Icon,
                    ImageColor3 = u10.Resources.Metal.Color,
                    Position = UDim2.fromScale(1.1, 0),
                    Size = UDim2.fromScale(1, 1),
                    SizeConstraint = u3.SizeConstraint.RelativeYY
                })
            }),
            Fuel = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0.55, 0.4),
                Size = UDim2.fromScale(0.2, 0.08),
                Text = v120.Fuel,
                TextColor3 = u10.Resources.Fuel.Color,
                TextXAlignment = u3.TextXAlignment.Right
            }, {
                ImageLabel = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Image = u10.Resources.Fuel.Icon,
                    ImageColor3 = u10.Resources.Fuel.Color,
                    Position = UDim2.fromScale(1.1, 0),
                    Size = UDim2.fromScale(1, 1),
                    SizeConstraint = u3.SizeConstraint.RelativeYY
                })
            }),
            Equipment = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0.55, 0.5),
                Size = UDim2.fromScale(0.2, 0.08),
                Text = v120.Equipment,
                TextColor3 = u10.Resources.Equipment.Color,
                TextXAlignment = u3.TextXAlignment.Right
            }, {
                ImageLabel = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Image = u10.Resources.Equipment.Icon,
                    ImageColor3 = u10.Resources.Equipment.Color,
                    Position = UDim2.fromScale(1.1, 0),
                    Size = UDim2.fromScale(1, 1),
                    SizeConstraint = u3.SizeConstraint.RelativeYY
                })
            }),
            Title = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "WORK\nDISTRIBUTION",
                TextScaled = true,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422"),
                Position = UDim2.fromScale(0.55, 0.75),
                Size = UDim2.fromScale(0.3, 0.16),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Right
            })
        });
    elseif l__Page__10 == "Logistics" then
        v118.Tab = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "ADDED STORAGE",
            TextScaled = true,
            AnchorPoint = Vector2.new(0, 0.5),
            FontFace = u13,
            Position = UDim2.fromScale(0.435, 0.5),
            Size = UDim2.fromScale(0.2, 0.6),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Center
        });
    elseif l__Page__10 == "Research" then
        v118.Tab = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "RESEARCH EFFICIENCY",
            TextScaled = true,
            AnchorPoint = Vector2.new(0, 0.5),
            FontFace = u13,
            Position = UDim2.fromScale(0.435, 0.5),
            Size = UDim2.fromScale(0.2, 0.6),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Center
        });
    elseif l__Page__10 == "Deliveries" then
        v118.Tab = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "DELIVERY EFFICIENCY",
            TextScaled = true,
            AnchorPoint = Vector2.new(0, 0.5),
            FontFace = u13,
            Position = UDim2.fromScale(0.435, 0.5),
            Size = UDim2.fromScale(0.2, 0.6),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Center
        });
    elseif v49 then
        if v90 > 0 then
            v119.NonAssigned = u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(75, 16, 14),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 0.62),
                Size = UDim2.fromScale(0.2, 0.15)
            }, {
                Title = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    ZIndex = 2,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422"),
                    Position = UDim2.fromScale(0.3, 0.5),
                    Size = UDim2.fromScale(0.7, 0.4),
                    Text = v90 == 1 and "1 EMPLOYEE IS\nUN-ASSIGNED (USELESS)" or tostring(v90) .. " EMPLOYEES ARE\nUN-ASSIGNED (USELESS)",
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                ImageLabel = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Image = "rbxassetid://80619550813478",
                    AnchorPoint = Vector2.new(0, 0.5),
                    ImageColor3 = Color3.fromRGB(255, 67, 66),
                    Position = UDim2.fromScale(0.08, 0.5),
                    Size = UDim2.fromScale(0.45, 0.45),
                    SizeConstraint = u3.SizeConstraint.RelativeYY
                })
            });
        end;
    elseif u48 then
        v118.Tab = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "SKILL",
            TextScaled = true,
            AnchorPoint = Vector2.new(0, 0.5),
            FontFace = u13,
            Position = UDim2.fromScale(0.435, 0.5),
            Size = UDim2.fromScale(0.2, 0.6),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Center
        });
        v118.Rate = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "FROM",
            TextScaled = true,
            AnchorPoint = Vector2.new(0, 0.5),
            FontFace = u13,
            Position = UDim2.fromScale(0.665, 0.5),
            Size = UDim2.fromScale(0.1, 0.6),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Center
        });
        v80.Training = u2.createElement("Frame", {
            BorderSizePixel = 0,
            LayoutOrder = v117,
            BackgroundColor3 = Color3.new()
        }, {
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                ScaleType = u3.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 139,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                }),
                Count = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "STUDENT",
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = u13,
                    Position = UDim2.fromScale(0.025, 0.5),
                    Size = UDim2.fromScale(0.3, 0.6),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                Assigned = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "DEPARTMENT",
                    TextScaled = true,
                    AnchorPoint = Vector2.new(1, 0.5),
                    FontFace = u13,
                    Position = UDim2.fromScale(0.95, 0.5),
                    Size = UDim2.fromScale(0.15, 0.6),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Center
                }),
                u2.createFragment(v118)
            }),
            Skills = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ZIndex = 2,
                Position = UDim2.fromScale(0.2, 0),
                Size = UDim2.fromScale(0.2, 1)
            }, {
                UIGridLayout = u2.createElement("UIGridLayout", {
                    CellPadding = UDim2.new(),
                    CellSize = UDim2.fromScale(1 / #u16 - 0.001, 1),
                    SortOrder = u3.SortOrder.LayoutOrder
                }),
                u2.createFragment(v66)
            })
        });
        if v93 > 0 then
            v119.NonTraining = u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(75, 16, 14),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 0.62),
                Size = UDim2.fromScale(0.2, 0.15)
            }, {
                Title = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    ZIndex = 2,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422"),
                    Position = UDim2.fromScale(0.3, 0.5),
                    Size = UDim2.fromScale(0.7, 0.4),
                    Text = v93 == 1 and "1 STUDENT NEEDS A\nTEACHER FOR THEIR SKILL" or tostring(v93) .. " STUDENTS NEED A\nTEACHER FOR THEIR SKILLS",
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                ImageLabel = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Image = "rbxassetid://80619550813478",
                    AnchorPoint = Vector2.new(0, 0.5),
                    ImageColor3 = Color3.fromRGB(255, 67, 66),
                    Position = UDim2.fromScale(0.08, 0.5),
                    Size = UDim2.fromScale(0.45, 0.45),
                    SizeConstraint = u3.SizeConstraint.RelativeYY
                })
            });
        end;
        if v91 > 0 then
            v119.FinishedTraining = u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(147, 107, 52),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, v93 > 0 and 0.78 or 0.62),
                Size = UDim2.fromScale(0.2, 0.15)
            }, {
                Title = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    ZIndex = 2,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422"),
                    Position = UDim2.fromScale(0.3, 0.5),
                    Size = UDim2.fromScale(0.7, 0.4),
                    Text = v91 == 1 and "1 STUDENT HAS REACHED\nTHEIR TEACHER\'S SKILL" or tostring(v91) .. " STUDENTS HAVE REACHED\nTHEIR TEACHER\'S SKILL",
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                ImageLabel = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Image = "rbxassetid://80619550813478",
                    AnchorPoint = Vector2.new(0, 0.5),
                    ImageColor3 = Color3.fromRGB(234, 198, 127),
                    Position = UDim2.fromScale(0.08, 0.5),
                    Size = UDim2.fromScale(0.45, 0.45),
                    SizeConstraint = u3.SizeConstraint.RelativeYY
                })
            });
        end;
    elseif v47 then
        local v130 = {};
        for v131, v132 in u16 do
            local l__Skill__24 = l__Department__9.Skill;
            if l__Skill__24 then
                l__Skill__24 = table.find(l__Department__9.Skill, v132);
            end;
            v130["Skill" .. v131] = u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(255, 194, 89),
                BackgroundTransparency = l__Skill__24 and 0 or 1,
                BorderColor3 = Color3.new(),
                LayoutOrder = v131
            }, { u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Image = "rbxassetid://" .. u10.Skills[v132].Icon,
                    ImageColor3 = l__Skill__24 and Color3.new() or Color3.new(1, 1, 1),
                    Position = UDim2.fromScale(0.5, 0.5),
                    Size = UDim2.fromScale(0.4, 0.4),
                    SizeConstraint = u3.SizeConstraint.RelativeYY
                }) });
        end;
        v119.Roll = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0, 0.62),
            Size = UDim2.fromScale(0.2, 0.2)
        }, {
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                ScaleType = u3.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 139,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                })
            }),
            Count = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0.12, 0.5),
                Size = UDim2.fromScale(0.8, 0.4),
                Text = u45.UpdateBinding:map(function(p133) --[[ Line: 1329 ]]
                    -- upvalues: u22 (ref), l__Company__11 (copy)
                    return u22(l__Company__11.Hiring.NextRoll - p133);
                end),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Left
            }),
            Title = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "HIRING RE-ROLL",
                TextScaled = true,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422"),
                Position = UDim2.fromScale(0.55, 0.5),
                Size = UDim2.fromScale(0.3, 0.32),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Right
            })
        });
        v118.Tab = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "COST",
            TextScaled = true,
            AnchorPoint = Vector2.new(0, 0.5),
            FontFace = u13,
            Position = UDim2.fromScale(0.435, 0.5),
            Size = UDim2.fromScale(0.2, 0.6),
            TextColor3 = Color3.new(),
            TextXAlignment = u3.TextXAlignment.Center
        });
        v80.Command = u2.createElement("Frame", {
            BorderSizePixel = 0,
            LayoutOrder = v82 + 1,
            BackgroundColor3 = Color3.new()
        }, {
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                ScaleType = u3.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 139,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                }),
                Count = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "NAME",
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = u13,
                    Position = UDim2.fromScale(0.025, 0.5),
                    Size = UDim2.fromScale(0.3, 0.6),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                Assigned = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "DEPARTMENT",
                    TextScaled = true,
                    AnchorPoint = Vector2.new(1, 0.5),
                    FontFace = u13,
                    Position = UDim2.fromScale(0.95, 0.5),
                    Size = UDim2.fromScale(0.15, 0.6),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Center
                }),
                u2.createFragment(v118)
            }),
            Skills = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ZIndex = 2,
                Position = UDim2.fromScale(0.2, 0),
                Size = UDim2.fromScale(0.2, 1)
            }, {
                UIGridLayout = u2.createElement("UIGridLayout", {
                    CellPadding = UDim2.new(),
                    CellSize = UDim2.fromScale(1 / #u16 - 0.001, 1),
                    SortOrder = u3.SortOrder.LayoutOrder
                }),
                u2.createFragment(v130)
            })
        });
    elseif v52 then
        v118.Tab = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "DEFENSE EFFICIENCY",
            TextScaled = true,
            AnchorPoint = Vector2.new(0, 0.5),
            FontFace = u13,
            Position = UDim2.fromScale(0.435, 0.5),
            Size = UDim2.fromScale(0.2, 0.6),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Center
        });
        local v134 = l__Company__11:GetWinProbability();
        v119.Win = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0, 0.62),
            Size = UDim2.fromScale(0.2, 0.3)
        }, {
            Count = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422"),
                Position = UDim2.fromScale(0.1, 0.335),
                Size = UDim2.fromScale(0.4, 0.4),
                Text = math.floor(v134 * 100) .. "%",
                TextColor3 = Color3.new(1, 0, 0):Lerp(Color3.new(0, 1, 0), v134)
            }),
            Title = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "WIN\nPROBABILITY",
                TextScaled = true,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422"),
                Position = UDim2.fromScale(0.55, 0.35),
                Size = UDim2.fromScale(0.3, 0.2),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Right
            }),
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                ScaleType = u3.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 139,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                })
            }),
            Help = u2.createElement(u9, {
                ZIndex = 2,
                NoUpper = true,
                Name = "How is this calculated?",
                SizeY = 0.45,
                Ignore = l__props__7.Ignore,
                Size = UDim2.fromScale(0.8, 0.2),
                Position = UDim2.fromScale(0.1, 0.65),
                Callback = function() --[[ Name: Callback, Line 1487 ]]
                    -- upvalues: u8 (ref)
                    u8:Open("Win probability", "Your chances of winning a raid is based on your \'DEFENSE\' department level and the combined efficiency of assigned employees. Note that employee efficiency decreases with their health.", {
                        { "Close", function() --[[ Line: 1489 ]]
                                -- upvalues: u8 (ref)
                                u8:Close();
                            end }
                    });
                end
            })
        });
        local v135 = l__Company__11:GetRaidProbability();
        v119.Raid = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0, 0.31),
            Size = UDim2.fromScale(0.2, 0.3)
        }, {
            Count = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422"),
                Position = UDim2.fromScale(0.1, 0.335),
                Size = UDim2.fromScale(0.4, 0.4),
                Text = math.floor(v135 * 100) .. "%",
                TextColor3 = Color3.new(0, 1, 0):Lerp(Color3.new(1, 0, 0), v135)
            }),
            Title = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "RAID\nPROBABILITY",
                TextScaled = true,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422"),
                Position = UDim2.fromScale(0.55, 0.35),
                Size = UDim2.fromScale(0.3, 0.2),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Right
            }),
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                ScaleType = u3.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 139,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                })
            }),
            Help = u2.createElement(u9, {
                ZIndex = 2,
                NoUpper = true,
                Name = "How is this calculated?",
                SizeY = 0.45,
                Ignore = l__props__7.Ignore,
                Size = UDim2.fromScale(0.8, 0.2),
                Position = UDim2.fromScale(0.1, 0.65),
                Callback = function() --[[ Name: Callback, Line 1552 ]]
                    -- upvalues: u8 (ref)
                    u8:Open("Raid probability", "Your base is more likely to be raided under the following conditions:\n• High amount of employees assigned to \'OPERATIONS\'\n• Large amount of resources stored in \'LOGISTICS\'\n• Airbase level is high (High level airbases are more attractive targets)\n\nYou cannot be raided again within 24 hours of a raid.", {
                        { "Close", function() --[[ Line: 1554 ]]
                                -- upvalues: u8 (ref)
                                u8:Close();
                            end }
                    });
                end
            })
        });
    elseif v50 then
        if v64 <= 0 then
            v119.NonTraining = u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(75, 16, 14),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 0.62),
                Size = UDim2.fromScale(0.2, 0.15)
            }, {
                Title = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "NO DOCTORS ARE ASSIGNED\nNO PATIENTS WILL BE HEALED",
                    TextScaled = true,
                    ZIndex = 2,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422"),
                    Position = UDim2.fromScale(0.3, 0.5),
                    Size = UDim2.fromScale(0.7, 0.4),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                ImageLabel = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Image = "rbxassetid://80619550813478",
                    AnchorPoint = Vector2.new(0, 0.5),
                    ImageColor3 = Color3.fromRGB(255, 67, 66),
                    Position = UDim2.fromScale(0.08, 0.5),
                    Size = UDim2.fromScale(0.45, 0.45),
                    SizeConstraint = u3.SizeConstraint.RelativeYY
                })
            });
        end;
        local v136 = {};
        for v137, v138 in u16 do
            v136["Skill" .. v137] = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                BorderSizePixel = 0,
                BorderColor3 = Color3.new(),
                LayoutOrder = v137
            }, { u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Image = "rbxassetid://" .. u10.Skills[v138].Icon,
                    ImageColor3 = Color3.new(1, 1, 1),
                    Position = UDim2.fromScale(0.5, 0.5),
                    Size = UDim2.fromScale(0.4, 0.4),
                    SizeConstraint = u3.SizeConstraint.RelativeYY
                }) });
        end;
        local l__createElement__25 = u2.createElement;
        local v139 = "Frame";
        local v140 = {
            BorderSizePixel = 0,
            LayoutOrder = v117,
            BackgroundColor3 = Color3.new()
        };
        local v141 = {};
        local l__createElement__26 = u2.createElement;
        local v142 = "ImageLabel";
        local v143 = {
            BackgroundTransparency = 1,
            Image = "rbxassetid://13867939464",
            ImageColor3 = Color3.fromRGB(71, 71, 71),
            ScaleType = u3.ScaleType.Tile,
            Size = UDim2.fromScale(1, 1),
            TileSize = UDim2.fromOffset(6, 6)
        };
        local v144 = {
            Gradient = u2.createElement("UIGradient", {
                Rotation = 139,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
            }),
            Count = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "PATIENT",
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = u13,
                Position = UDim2.fromScale(0.025, 0.5),
                Size = UDim2.fromScale(0.3, 0.6),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Left
            }),
            Assigned = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "DEPARTMENT",
                TextScaled = true,
                AnchorPoint = Vector2.new(1, 0.5),
                FontFace = u13,
                Position = UDim2.fromScale(0.95, 0.5),
                Size = UDim2.fromScale(0.15, 0.6),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Center
            })
        };
        local v145;
        if v64 > 0 then
            v145 = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "TIME UNTIL RECOVERED",
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = u13,
                Position = UDim2.fromScale(0.435, 0.5),
                Size = UDim2.fromScale(0.2, 0.6),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Center
            });
        else
            v145 = false;
        end;
        v144[1], v144[2] = v145, u2.createFragment(v118);
        v141.Dots = l__createElement__26(v142, v143, v144);
        v141.Skills = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            Position = UDim2.fromScale(0.2, 0),
            Size = UDim2.fromScale(0.2, 1)
        }, {
            UIGridLayout = u2.createElement("UIGridLayout", {
                CellPadding = UDim2.new(),
                CellSize = UDim2.fromScale(1 / #u16 - 0.001, 1),
                SortOrder = u3.SortOrder.LayoutOrder
            }),
            u2.createFragment(v136)
        });
        v80.Patients = l__createElement__25(v139, v140, v141);
    end;
    local v146, v147 = u11(v65);
    local l__createFragment__27 = u2.createFragment;
    local v148 = {};
    local v149 = u2.createElement(u7, {
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
        Ref = u45.ScrollerRef,
        Size = UDim2.fromScale(0.795, 0.92),
        Position = UDim2.fromScale(0.205, 0.08),
        CanvasSize = v88 / 11.1,
        Content = v80
    });
    local v150 = u2.createElement("Frame", {
        BorderSizePixel = 0,
        BackgroundColor3 = Color3.new(),
        BorderColor3 = Color3.new(),
        Size = UDim2.fromScale(0.2, 0.3)
    }, {
        Max = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            ZIndex = 2,
            FontFace = Font.new("rbxassetid://12187375422"),
            Position = UDim2.fromScale(0.3, 0.25),
            Size = UDim2.fromScale(0.3, 0.3),
            Text = "/" .. v46,
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Left
        }),
        Count = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0, 0.5),
            FontFace = Font.new("rbxassetid://12187375422"),
            Position = UDim2.fromScale(0, 0.335),
            Size = UDim2.fromScale(0.3, 0.4),
            Text = v57,
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Right
        }),
        Title = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0, 0.5),
            FontFace = Font.new("rbxassetid://12187375422"),
            Position = UDim2.fromScale(0.55, 0.35),
            Size = UDim2.fromScale(0.3, 0.2),
            Text = v49 and "TOTAL\nEMPLOYEES" or "DEPARTMENT\nEMPLOYEES",
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Right
        }),
        Dots = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://13867939464",
            ImageColor3 = Color3.fromRGB(71, 71, 71),
            ScaleType = u3.ScaleType.Tile,
            Size = UDim2.fromScale(1, 1),
            TileSize = UDim2.fromOffset(6, 6)
        }, {
            Gradient = u2.createElement("UIGradient", {
                Rotation = 139,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
            })
        }),
        Help = u2.createElement(u9, {
            ZIndex = 2,
            NoUpper = true,
            Name = "How do I add more employee slots?",
            SizeY = 0.45,
            Ignore = l__props__7.Ignore,
            Size = UDim2.fromScale(0.8, 0.2),
            Position = UDim2.fromScale(0.1, 0.65),
            Callback = function() --[[ Name: Callback, Line 1761 ]]
                -- upvalues: u8 (ref), l__props__7 (copy)
                u8:Open("Adding more employee slots", "Employee slots can be increased by upgrading the department in the \'UPGRADES\' tab.", {
                    { "Upgrades", function() --[[ Line: 1763 ]]
                            -- upvalues: l__props__7 (ref), u8 (ref)
                            l__props__7.ChangePage("Upgrades");
                            u8:Close();
                        end },
                    { "Close", function() --[[ Line: 1767 ]]
                            -- upvalues: u8 (ref)
                            u8:Close();
                        end }
                });
            end
        })
    });
    local v151 = not v52;
    if v151 then
        v151 = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0, 0.31),
            Size = UDim2.fromScale(0.2, 0.3)
        }, {
            Count = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422"),
                Position = UDim2.fromScale(0.1, 0.335),
                Size = UDim2.fromScale(0.4, 0.4),
                Text = v146,
                TextColor3 = v147
            }),
            Title = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "AVERAGE\nSKILL LEVEL",
                TextScaled = true,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422"),
                Position = UDim2.fromScale(0.55, 0.35),
                Size = UDim2.fromScale(0.3, 0.2),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Right
            }),
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                ScaleType = u3.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 139,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                })
            }),
            Help = u2.createElement(u9, {
                ZIndex = 2,
                NoUpper = true,
                Name = "How do I improve skill level?",
                SizeY = 0.45,
                Ignore = l__props__7.Ignore,
                Size = UDim2.fromScale(0.8, 0.2),
                Position = UDim2.fromScale(0.1, 0.65),
                Callback = function() --[[ Name: Callback, Line 1828 ]]
                    -- upvalues: u8 (ref)
                    u8:Open("Improving skill level", "Employee skill level can be increased by training them in the \'TRAINING\' department.\n\nAlternatively, you can hire better skilled employees at the \'COMMAND\' department.", {
                        { "Close", function() --[[ Line: 1830 ]]
                                -- upvalues: u8 (ref)
                                u8:Close();
                            end }
                    });
                end
            })
        });
    end;
    local l__createElement__28 = u2.createElement;
    local v152 = "Frame";
    local v153 = {
        BorderSizePixel = 0,
        BackgroundColor3 = v47 and Color3.fromRGB(255, 194, 89) or Color3.new(),
        BorderColor3 = Color3.new(),
        Position = UDim2.fromScale(0.205, 0),
        Size = UDim2.fromScale(0.795, 0.08)
    };
    local v154 = {};
    local l__createElement__29 = u2.createElement;
    local v155 = "ImageLabel";
    local v156 = {
        BackgroundTransparency = 1,
        Image = "rbxassetid://13867939464",
        ImageColor3 = Color3.fromRGB(71, 71, 71),
        ScaleType = u3.ScaleType.Tile,
        Size = UDim2.fromScale(1, 1),
        TileSize = UDim2.fromOffset(6, 6)
    };
    local v157 = {
        Gradient = u2.createElement("UIGradient", {
            Rotation = 139,
            Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
        }),
        Count = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            AnchorPoint = Vector2.new(0, 0.5),
            FontFace = u13,
            Position = UDim2.fromScale(0.025, 0.5),
            Size = UDim2.fromScale(0.3, 0.6),
            Text = v50 and "DOCTOR" or (v47 and "CANDIDATE" or (u48 and "TEACHER" or "NAME")),
            TextColor3 = v47 and Color3.new() or Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Left
        })
    };
    if v50 then
        v50 = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "HEALING EFFICIENCY",
            TextScaled = true,
            AnchorPoint = Vector2.new(0, 0.5),
            FontFace = u13,
            Position = UDim2.fromScale(0.435, 0.5),
            Size = UDim2.fromScale(0.2, 0.6),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Center
        });
    end;
    v157[1], v157[2], v157[3] = v50, u2.createElement("TextLabel", {
    BackgroundTransparency = 1,
    TextScaled = true,
    AnchorPoint = Vector2.new(1, 0.5),
    FontFace = u13,
    Position = UDim2.fromScale(0.95, 0.5),
    Size = UDim2.fromScale(0.15, 0.6),
    Text = v47 and "HIRE" or "DEPARTMENT",
    TextColor3 = v47 and Color3.new() or Color3.new(1, 1, 1),
    TextXAlignment = u3.TextXAlignment.Center
}), u2.createFragment(v118);
    v154.Dots = l__createElement__29(v155, v156, v157);
    v154.Skills = u2.createElement("Frame", {
        BackgroundTransparency = 1,
        ZIndex = 2,
        Position = UDim2.fromScale(0.2, 0),
        Size = UDim2.fromScale(0.2, 1)
    }, {
        UIGridLayout = u2.createElement("UIGridLayout", {
            CellPadding = UDim2.new(),
            CellSize = UDim2.fromScale(1 / #u16 - 0.001, 1),
            SortOrder = u3.SortOrder.LayoutOrder
        }),
        u2.createFragment(v66)
    });
    v148[1], v148[2], v148[3], v148[4], v148[5] = v149, v150, v151, l__createElement__28(v152, v153, v154), u2.createFragment(v119);
    return l__createFragment__27(v148);
end;
return v17;