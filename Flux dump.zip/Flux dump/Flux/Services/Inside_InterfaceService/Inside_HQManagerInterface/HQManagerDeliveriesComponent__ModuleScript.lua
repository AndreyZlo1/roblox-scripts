-- Services.InterfaceService.HQManagerInterface.HQManagerDeliveriesComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Roact", "Enum", "network");
local l__RunService__1 = game:GetService("RunService");
local u5 = v1("RoactTween");
v1("StatsService");
local u6 = v1("GameShellProxyScroller");
local u7 = v1("MenuButtonComponent");
local u8 = v1("CompanyInfo");
local u9 = v1("CompanyConfig");
local u10 = v1("formatNumber");
local u11 = v1("levelToRating");
local u12 = Vector2.new(0.653, 0.579);
local u13 = Vector2.new(405, 283);
Font.fromId(12187375422, u3.FontWeight.Bold, u3.FontStyle.Normal);
Font.fromId(12187375422, u3.FontWeight.Regular, u3.FontStyle.Normal);
local u14 = {
    "Material",
    "Metal",
    "Fuel",
    "Equipment"
};
local v15 = u2.Component:extend("HQManagerDeliveries");
local function u20(p16) --[[ Line: 35 ]]
    local v17 = p16 % 60;
    local v18 = math.floor(p16 / 60) % 60;
    local v19 = math.floor(p16 / 3600) % 24;
    if p16 <= 0 then
        v19 = 0;
        v18 = 0;
        v17 = 0;
    end;
    return string.format("%02i", v19) .. ":" .. string.format("%02i", v18) .. ":" .. string.format("%02i", v17);
end;
function v15.init(u21, _) --[[ Line: 48 ]]
    -- upvalues: u14 (copy), u2 (copy), l__RunService__1 (copy), u5 (copy), u3 (copy)
    local v22 = {};
    for _, v23 in u14 do
        v22[v23] = 0;
    end;
    u21.ScrollerRef = u2.createRef();
    local v24, v25 = u2.createBinding(os.time());
    u21.UpdateBinding = v24;
    u21.UpdateUpdate = v25;
    u21.Connection = l__RunService__1.Heartbeat:Connect(function(_) --[[ Line: 56 ]]
        -- upvalues: u21 (copy)
        u21.UpdateUpdate(os.time());
    end);
    u21.Open = u5.new(0, TweenInfo.new(1, u3.EasingStyle.Exponential, u3.EasingDirection.Out, 0, false, 0));
    u21.Open:SetGoal(1);
    u21:setState({
        ResourceSells = v22
    });
end;
function v15.willUnmount(p26) --[[ Line: 68 ]]
    p26.Connection:Disconnect();
end;
function v15.render(u27) --[[ Line: 72 ]]
    -- upvalues: u2 (copy), u3 (copy), u11 (copy), u9 (copy), u12 (copy), u13 (copy), u20 (copy), u10 (copy), u7 (copy), u4 (copy), u14 (copy), u8 (copy), u6 (copy)
    local l__props__2 = u27.props;
    local l__state__3 = u27.state;
    local l__Company__4 = l__props__2.Company;
    local l__ResourceSells__5 = l__state__3.ResourceSells;
    local u28 = nil;
    local u29 = 0;
    for _, v30 in l__Company__4.Employees do
        if v30.Assigned == "Logistics" then
            u29 = u29 + l__Company__4:GetAddedCapacity(v30);
        end;
        if v30.Assigned == "Deliveries" and (v30.Delivery <= os.time() and (not u28 or v30.Skills.Deliveries > u28.Skills.Deliveries)) then
            u28 = v30;
        end;
    end;
    local v31 = {};
    local v32 = math.max(4, #l__Company__4.Deliveries);
    local v33 = 1 / v32;
    v31.Grid = u2.createElement("UIGridLayout", {
        CellPadding = UDim2.fromScale(0, 0),
        CellSize = UDim2.fromScale(1, v33),
        FillDirection = u3.FillDirection.Vertical,
        HorizontalAlignment = u3.HorizontalAlignment.Left,
        SortOrder = u3.SortOrder.LayoutOrder,
        StartCorner = u3.StartCorner.TopLeft,
        VerticalAlignment = u3.VerticalAlignment.Top
    });
    local v34 = {};
    for u35, u36 in l__Company__4.Deliveries do
        local v37, v38 = u11(u36.Skill or 0);
        local v39 = u9.Destinations[u36.Destination];
        local u40 = os.time() >= u36.End;
        local v41 = (os.time() - u36.Start) / (u36.End - u36.Start);
        local u42 = math.clamp(v41, 0, 1);
        local v43 = v39.Position or Vector2.new();
        local l__Magnitude__6 = (v43 - u12).Magnitude;
        local v44 = (u12 + v43) / 2;
        local v45 = Vector2.new(v44.X, v44.Y - l__Magnitude__6 * 0.4);
        local v46 = (1 - u42) ^ 2 * u12 + 2 * (1 - u42) * u42 * v45 + u42 ^ 2 * v43;
        v34[u35 .. "_Current"] = u2.createElement("Frame", {
            ZIndex = 100,
            Rotation = 45,
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Size = UDim2.fromScale(0.02, 0.02),
            SizeConstraint = u3.SizeConstraint.RelativeYY,
            Position = UDim2.fromScale(v46.X, v46.Y),
            BackgroundColor3 = u27.UpdateBinding:map(function() --[[ Line: 132 ]]
                -- upvalues: u42 (copy)
                local v47 = -os.clock();
                return Color3.fromRGB(255, 241, 216):Lerp(Color3.fromRGB(255, 194, 89), (math.sin((v47 + u42 * 2) * 5) + 1) / 2);
            end),
            BackgroundTransparency = u27.Open:Map(function(p48) --[[ Line: 136 ]]
                return 1 - math.clamp((p48 - 0.9) / 0.1, 0, 1);
            end)
        });
        for u49 = 1, 30 do
            local v50 = (u49 - 1) / 30;
            local u51 = (1 - v50) ^ 2 * u12 + 2 * (1 - v50) * v50 * v45 + v50 ^ 2 * v43;
            local v52 = u49 / 30;
            local v53 = (1 - v52) ^ 2 * u12 + 2 * (1 - v52) * v52 * v45 + v52 ^ 2 * v43;
            local v54 = v53 * u13 - u51 * u13;
            local _ = v54.Magnitude;
            local v55 = (u51 + v53) / 2;
            local u56 = u49 / 30 <= u42;
            local l__Magnitude__7 = (u51 - v53).Magnitude;
            local u57 = Vector2.new(v55.X, v55.Y);
            local v58 = u35 .. "_" .. u49;
            local l__createElement__8 = u2.createElement;
            local v65 = {
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Size = u27.Open:Map(function(p59) --[[ Line: 155 ]]
                    -- upvalues: u49 (copy), l__Magnitude__7 (copy), u56 (copy)
                    local v60 = (u49 - 1) / 30;
                    local v61 = math.clamp((p59 - v60) / (u49 / 30 - v60), 0, 1);
                    return UDim2.fromScale(math.lerp(0, l__Magnitude__7, v61), u56 and 0.01 or 0.005);
                end),
                Position = u27.Open:Map(function(p62) --[[ Line: 160 ]]
                    -- upvalues: u49 (copy), u51 (copy), u57 (copy)
                    local v63 = (u49 - 1) / 30;
                    local v64 = u51:Lerp(u57, (math.clamp((p62 - v63) / (u49 / 30 - v63), 0, 1)));
                    return UDim2.fromScale(v64.X, v64.Y);
                end),
                ZIndex = math.floor(u42 * 100)
            };
            local v66 = math.atan2(v54.Y, v54.X);
            v65.Rotation = math.deg(v66);
            v65.BackgroundColor3 = u56 and u27.UpdateBinding:map(function() --[[ Line: 168 ]]
                -- upvalues: u49 (copy)
                local v67 = -os.clock();
                return Color3.fromRGB(255, 241, 216):Lerp(Color3.fromRGB(255, 194, 89), (math.sin((v67 + u49 / 30 * 2) * 5) + 1) / 2);
            end) or Color3.new(0.9, 0.9, 0.9);
            v34[v58] = l__createElement__8("Frame", v65);
        end;
        local v68 = "Delivery" .. u35;
        local l__createElement__9 = u2.createElement;
        local v69 = "Frame";
        local v70 = {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            LayoutOrder = u35,
            Size = UDim2.fromScale(1, 0.25)
        };
        local v71 = {
            Line = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 1),
                Size = UDim2.fromScale(1, 0.01)
            })
        };
        local l__createElement__10 = u2.createElement;
        local v72 = "Frame";
        local v73 = {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(1, 0.99)
        };
        local v75 = {
            Name = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0.05, 0.1),
                Size = UDim2.fromScale(0.9, 0.2),
                Text = u36.Name or "???",
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Left
            }),
            Skill = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0.05, 0.1),
                Size = UDim2.fromScale(0.9, 0.2),
                Text = v37,
                TextColor3 = v38,
                TextXAlignment = u3.TextXAlignment.Right
            }),
            Location = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422"),
                Position = UDim2.fromScale(0.05, 0.3),
                Size = UDim2.fromScale(0.9, 0.15),
                Text = "Destination: " .. v39.Name,
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Left
            }),
            Status = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422"),
                Position = UDim2.fromScale(0.05, 0.45),
                Size = UDim2.fromScale(0.9, 0.15),
                Text = u27.UpdateBinding:map(function(p74) --[[ Line: 241 ]]
                    -- upvalues: u36 (copy), u40 (ref), u27 (copy), u20 (ref)
                    if u36.End > p74 then
                        return "Status: On-route (" .. u20(u36.End - p74) .. ")";
                    end;
                    if not u40 then
                        u40 = true;
                        u27:setState({});
                    end;
                    return "Status: Delivered";
                end),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Left
            }),
            Payout = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                ZIndex = 2,
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0.05, 0.75),
                Size = UDim2.fromScale(0.9, 0.15),
                Text = u40 and "" or "Payout On Delivery:",
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Left
            }),
            Count = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                ZIndex = 2,
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                AnchorPoint = Vector2.new(0, 0.5),
                Position = UDim2.fromScale(0.05, 0.825),
                Size = UDim2.fromScale(0.9, u40 and 0.2 or 0.15),
                Text = u10(u36.Value),
                TextColor3 = Color3.fromRGB(0, 255, 0),
                TextXAlignment = u3.TextXAlignment.Right
            })
        };
        local v76;
        if u40 then
            v76 = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(119, 216, 102),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 1),
                Size = UDim2.fromScale(1, 0.35)
            }, { u2.createElement("UIGradient", {
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
                }) });
        end;
        if u40 then
            u40 = u2.createElement(u7, {
                Name = "Collect Payment",
                ZIndex = 2,
                Ignore = l__props__2.Ignore,
                Scroller = u27.ScrollerRef,
                AnchorPoint = Vector2.new(0, 0.5),
                Position = UDim2.fromScale(0.1, 0.825),
                Size = UDim2.fromScale(0.4, 0.2),
                Callback = function() --[[ Name: Callback, Line 311 ]]
                    -- upvalues: u4 (ref), u35 (copy), l__Company__4 (copy), u27 (copy)
                    u4:FireServer("ActivateInteract", "CollectDelivery", u35);
                    table.remove(l__Company__4.Deliveries, u35);
                    u27:setState({});
                end
            });
        end;
        v75[1], v75[2] = v76, u40;
        v71.Content = l__createElement__10(v72, v73, v75);
        v71.Gradient = u2.createElement("UIGradient", {
            Rotation = -90,
            Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.5375) })
        });
        v31[v68] = l__createElement__9(v69, v70, v71);
    end;
    local v77 = {};
    if u28 then
        local u78 = 0;
        local v79 = 0;
        local v80 = {};
        for v81, u82 in u14 do
            local v83 = l__ResourceSells__5[u82];
            local u84 = l__Company__4.Resources[u82] - v83;
            local v85 = l__Company__4:GetResourceValue(u82) * v83;
            u78 = u78 + v85;
            v79 = v79 + v83 * 0.1;
            local l__createElement__11 = u2.createElement;
            local v86 = "Frame";
            local v87 = {
                BackgroundTransparency = 1,
                Position = UDim2.fromScale(0, (v81 - 1) * 0.25),
                Size = UDim2.fromScale(1, 0.25)
            };
            local v88 = {
                Less = u2.createElement(u7, {
                    Name = "<",
                    Ignore = l__props__2.Ignore,
                    Disabled = v83 <= 0,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.fromScale(0, 0.6),
                    Size = UDim2.fromScale(0.15, 0.3),
                    Callback = function() --[[ Name: Callback, Line 353 ]]
                        -- upvalues: l__ResourceSells__5 (copy), u82 (copy), u27 (copy)
                        l__ResourceSells__5[u82] = math.max(0, l__ResourceSells__5[u82] - 1);
                        u27:setState({
                            ResourceSells = l__ResourceSells__5
                        });
                    end
                }),
                More = u2.createElement(u7, {
                    Name = ">",
                    Ignore = l__props__2.Ignore,
                    Disabled = l__Company__4.Resources[u82] <= v83,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.fromScale(0.4, 0.6),
                    Size = UDim2.fromScale(0.15, 0.3),
                    Callback = function() --[[ Name: Callback, Line 367 ]]
                        -- upvalues: l__ResourceSells__5 (copy), u82 (copy), l__Company__4 (copy), u27 (copy)
                        l__ResourceSells__5[u82] = math.min(l__Company__4.Resources[u82], l__ResourceSells__5[u82] + 1);
                        u27:setState({
                            ResourceSells = l__ResourceSells__5
                        });
                    end
                }),
                Count = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Position = UDim2.fromScale(0.15, 0.75),
                    Size = UDim2.fromScale(0.25, 0.2),
                    Text = tostring(v83),
                    TextColor3 = Color3.new(1, 1, 1)
                }),
                White = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    AnchorPoint = Vector2.new(0, 0.5),
                    BackgroundColor3 = Color3.new(1, 1, 1),
                    BorderColor3 = Color3.new(),
                    Position = UDim2.fromScale(0, 0.425),
                    Size = UDim2.fromScale(1, 0.02)
                })
            };
            local l__createElement__12 = u2.createElement;
            local v89 = "Frame";
            local v91 = {
                BorderSizePixel = 0,
                ZIndex = 2,
                BackgroundColor3 = u8.Resources[u82].Color,
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 0.35),
                Size = u27.Open:Map(function(p90) --[[ Line: 401 ]]
                    -- upvalues: u84 (copy), u29 (ref)
                    return UDim2.fromScale(u84 / u29 * p90, 0.15);
                end)
            };
            local v92 = {};
            local l__createElement__13 = u2.createElement;
            local v93 = "Frame";
            local v94 = {
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(1, 0),
                Position = UDim2.fromScale(1, 0),
                Size = UDim2.fromScale(1, 1),
                SizeConstraint = u3.SizeConstraint.RelativeYY
            };
            local v95 = {};
            local v96;
            if u84 > 0 then
                v96 = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(1, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Position = UDim2.fromScale(0.75, 0.5),
                    Size = UDim2.fromScale(10, 1.25),
                    Text = tostring(u84),
                    TextColor3 = Color3.new(),
                    TextXAlignment = u3.TextXAlignment.Right
                });
            else
                v96 = false;
            end;
            v95[1] = v96;
            v92.Constraint = l__createElement__13(v93, v94, v95);
            v88.Bar = l__createElement__12(v89, v91, v92);
            v88.Header = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0, 0.1),
                Size = UDim2.fromScale(1, 0.2),
                Text = u8.Resources[u82].Name,
                TextColor3 = u8.Resources[u82].Color,
                TextXAlignment = u3.TextXAlignment.Left
            });
            v88.Payout = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0, 0.75),
                Size = UDim2.fromScale(1, 0.2),
                Text = u10(v85),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Right
            });
            v88.Line = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 1),
                Size = UDim2.fromScale(1, 0.012)
            });
            v80[u82] = l__createElement__11(v86, v87, v88);
        end;
        local v97 = l__Company__4:GetAddedEfficiency(u28) + 1 < v79;
        v77.Efficiency = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
            Position = UDim2.fromScale(0.1, 0.8),
            Size = UDim2.fromScale(0.8, 0.05),
            Text = math.floor(v79 * 100) .. "%",
            TextColor3 = v97 and Color3.new(1, 0, 0) or Color3.fromRGB(0, 255, 0),
            TextXAlignment = u3.TextXAlignment.Right
        });
        v77.Payout = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
            Position = UDim2.fromScale(0.1, 0.75),
            Size = UDim2.fromScale(0.8, 0.05),
            Text = u10(u78),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Right
        });
        v77.Agent = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
            Position = UDim2.fromScale(0.1, 0.85),
            Size = UDim2.fromScale(0.8, 0.05),
            Text = u28.Name,
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Right
        });
        v77.PayoutLabel = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "Payout On Delivery",
            TextScaled = true,
            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
            Position = UDim2.fromScale(0.1, 0.775),
            AnchorPoint = Vector2.new(0, 0.5),
            Size = UDim2.fromScale(0.8, 0.03),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Left
        });
        v77.DeliveryLabel = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "Delivery Efficiency",
            TextScaled = true,
            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
            Position = UDim2.fromScale(0.1, 0.825),
            AnchorPoint = Vector2.new(0, 0.5),
            Size = UDim2.fromScale(0.8, 0.03),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Left
        });
        v77.AgentLabel = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "Agent",
            TextScaled = true,
            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
            Position = UDim2.fromScale(0.1, 0.875),
            AnchorPoint = Vector2.new(0, 0.5),
            Size = UDim2.fromScale(0.8, 0.03),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Left
        });
        if v97 then
            v77.TooBig = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "Delivery Efficiency is too high for this employee! Try selling less resources.",
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0.1, 0.92),
                Size = UDim2.fromScale(0.8, 0.05),
                TextColor3 = Color3.fromRGB(255, 0, 0)
            });
        else
            v77.Sell = u2.createElement(u7, {
                Name = "Sell",
                Ignore = l__props__2.Ignore,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.fromScale(0.1, 0.92),
                Size = UDim2.fromScale(0.8, 0.05),
                Disabled = v79 == 0,
                Callback = function() --[[ Name: Callback, Line 584 ]]
                    -- upvalues: u4 (ref), u28 (ref), l__ResourceSells__5 (copy), l__Company__4 (copy), u9 (ref), u78 (ref), u14 (ref), u27 (copy)
                    u4:FireServer("ActivateInteract", "Sell", u28.Index, l__ResourceSells__5.Material, l__ResourceSells__5.Metal, l__ResourceSells__5.Fuel, l__ResourceSells__5.Equipment);
                    u28.Delivery = os.time() + 21600;
                    l__Company__4.Deliveries[#l__Company__4.Deliveries + 1] = {
                        Destination = os.time() % #u9.Destinations + 1,
                        Value = u78,
                        Start = os.time(),
                        End = os.time() + 21600,
                        Name = u28.Name,
                        Skill = u28.Skills.Deliveries
                    };
                    local v98 = {};
                    for _, v99 in u14 do
                        local l__Resources__14 = l__Company__4.Resources;
                        l__Resources__14[v99] = l__Resources__14[v99] - l__ResourceSells__5[v99];
                        v98[v99] = 0;
                    end;
                    u27:setState({
                        ResourceSells = v98
                    });
                end
            });
        end;
        v77.Resources = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Position = UDim2.fromScale(0.1, 0.02),
            Size = UDim2.fromScale(0.8, 0.7)
        }, v80);
    else
        v77.Notif = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "You have no available delivery agents. Assign more employees to this department to make more simultaneous deliveries.",
            TextScaled = true,
            AnchorPoint = Vector2.new(0, 0.5),
            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
            Position = UDim2.fromScale(0.1, 0.5),
            Size = UDim2.fromScale(0.8, 0.6),
            TextColor3 = Color3.new(1, 1, 1)
        });
    end;
    return u2.createFragment({
        u2.createElement("Frame", {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            LayoutOrder = 1,
            AnchorPoint = Vector2.new(1, 0),
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0.695, 0.08),
            Size = UDim2.fromScale(0.2, u28 and 0.92 or 0.2)
        }, {
            Line = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 1),
                Size = UDim2.fromScale(1, u28 and 0.003 or 0.015)
            }),
            Content = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(1, u28 and 0.997 or 0.985)
            }, v77),
            Gradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.5375) })
            })
        }),
        u2.createElement("Frame", {
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(1, 0),
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0.695, 0),
            Size = UDim2.fromScale(0.2, 0.08)
        }, {
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                ScaleType = u3.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Header = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "SELL",
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Position = UDim2.fromScale(0.07, 0.5),
                    Size = UDim2.fromScale(0.4, 0.6),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 139,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                })
            })
        }),
        u2.createElement("Frame", {
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(1, 0),
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(1, 0),
            Size = UDim2.fromScale(0.3, 0.08)
        }, {
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                ScaleType = u3.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Header = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "DELIVERIES",
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Position = UDim2.fromScale(0.05, 0.5),
                    Size = UDim2.fromScale(0.4, 0.6),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 139,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                })
            })
        }),
        u2.createElement(u6, {
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            Ref = u27.ScrollerRef,
            AnchorPoint = Vector2.new(1, 0),
            Position = UDim2.fromScale(1, 0.08),
            Size = UDim2.fromScale(0.3, 0.92),
            CanvasSize = v32 / 4,
            Content = v31
        }),
        u2.createElement("Frame", {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            LayoutOrder = 1,
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0, 0.08),
            Size = UDim2.fromScale(0.49, 0.72)
        }, {
            Line = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 1),
                Size = UDim2.fromScale(1, 0.003)
            }),
            Content = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(1, 0.997)
            }),
            Gradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.5375) })
            }),
            Map = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                ImageTransparency = 0.5,
                Image = "rbxassetid://77603816987495",
                Position = UDim2.fromScale(0.05, 0),
                ScaleType = u3.ScaleType.Fit,
                Size = UDim2.fromScale(0.9, 1)
            }, v34)
        }),
        u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Size = UDim2.fromScale(0.49, 0.08)
        }, {
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                ScaleType = u3.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Header = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "MAP",
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Position = UDim2.fromScale(0.025, 0.5),
                    Size = UDim2.fromScale(0.4, 0.6),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 139,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                })
            })
        })
    });
end;
return v15;