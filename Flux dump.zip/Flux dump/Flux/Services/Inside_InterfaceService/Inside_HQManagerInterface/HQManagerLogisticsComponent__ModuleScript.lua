-- Services.InterfaceService.HQManagerInterface.HQManagerLogisticsComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Roact", "Enum", "network");
game:GetService("RunService");
local u5 = v1("RoactTween");
v1("StatsService");
local u6 = v1("GameShellProxyInput");
local u7 = v1("PopupInterface");
local u8 = v1("MenuButtonComponent");
local u9 = v1("CompanyInfo");
v1("formatNumber");
local u10 = Font.fromId(12187375422, u3.FontWeight.Bold, u3.FontStyle.Normal);
Font.fromId(12187375422, u3.FontWeight.Regular, u3.FontStyle.Normal);
local u11 = {
    "Material",
    "Metal",
    "Fuel",
    "Equipment"
};
local v12 = u2.Component:extend("HQManagerLogistics");
function v12.init(p13, _) --[[ Line: 27 ]]
    -- upvalues: u11 (copy), u2 (copy), u5 (copy), u3 (copy)
    local v14 = {};
    for v15 in u11 do
        v14[v15] = { u2.createBinding() };
        v14[v15 + #u11] = { u2.createBinding() };
    end;
    p13.Bindings = v14;
    p13.Open = u5.new(0, TweenInfo.new(1, u3.EasingStyle.Exponential, u3.EasingDirection.Out, 0, false, 0));
    p13.Open:SetGoal(1);
end;
function v12.render(u16) --[[ Line: 39 ]]
    -- upvalues: u9 (copy), u2 (copy), u11 (copy), u7 (copy), u4 (copy), u8 (copy), u6 (copy), u10 (copy), u3 (copy)
    local l__props__1 = u16.props;
    local l__Company__2 = l__props__1.Company;
    local v17 = 0;
    local u18 = 0;
    for _, v19 in l__Company__2.Employees do
        if v19.Assigned == "Logistics" then
            v17 = v17 + 1;
            u18 = u18 + l__Company__2:GetAddedCapacity(v19);
        end;
    end;
    local v20 = 0;
    local v21 = 0;
    local v22 = {};
    for v23, v24 in l__Company__2.Resources do
        local v25 = math.max(u18, 1);
        local l__Color__3 = u9.Resources[v23].Color;
        local v26 = math.ceil(v24 / v25 * 360);
        v20 = v20 + v24;
        for u27 = v21 + 1, v21 + v26 do
            if u27 % 3 == 1 then
                v22[u27] = u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Position = UDim2.fromScale(0.5, 0.5),
                    Size = UDim2.fromScale(0.05, 0.05),
                    Rotation = u16.Open:Map(function(p28) --[[ Line: 70 ]]
                        -- upvalues: u27 (copy)
                        return p28 * u27;
                    end),
                    ZIndex = u27
                }, { u2.createElement("Frame", {
                        BorderSizePixel = 0,
                        Position = UDim2.fromScale(0, 8.5),
                        Size = UDim2.fromScale(1, 4),
                        BackgroundColor3 = l__Color__3
                    }) });
            end;
        end;
        v21 = v21 + v26;
    end;
    local v29 = {};
    for v30, u31 in u11 do
        local u32 = u9.Resources[u31];
        local l__Color__4 = u32.Color;
        local u33, v34 = unpack(u16.Bindings[v30]);
        local function v37() --[[ Line: 92 ]]
            -- upvalues: u33 (copy), u7 (ref), u32 (copy), u4 (ref), u31 (copy), l__Company__2 (copy), u16 (copy)
            local v35 = tonumber(u33:getValue());
            if v35 and v35 > 0 then
                local u36 = math.ceil(v35);
                u7:Open("Dispose Resource", "Are you sure you want to dispose (destroy) " .. u36 .. " " .. u32.Name .. "?\n\nYou WILL NOT receive money for disposing of resources. To make money from resources, sell them in the \'DELIVERIES\' department.", {
                    { "Dispose", function() --[[ Line: 105 ]]
                            -- upvalues: u4 (ref), u31 (ref), u36 (ref), l__Company__2 (ref), u7 (ref), u16 (ref)
                            u4:FireServer("ActivateInteract", "Dispose", u31, u36);
                            l__Company__2.Resources[u31] = math.max(0, l__Company__2.Resources[u31] - u36);
                            u7:Close();
                            u16:setState({});
                        end },
                    { "Cancel", function() --[[ Line: 111 ]]
                            -- upvalues: u7 (ref)
                            u7:Close();
                        end }
                });
            else
                u7:Open("Invalid Number", "Input a valid number over 0.", {
                    { "Close", function() --[[ Line: 96 ]]
                            -- upvalues: u7 (ref)
                            u7:Close();
                        end }
                });
            end;
        end;
        local u38, v39 = unpack(u16.Bindings[v30 + #u11]);
        local function v43() --[[ Line: 118 ]]
            -- upvalues: u38 (copy), u18 (ref), u7 (ref), u32 (copy), u4 (ref), u31 (copy), l__Company__2 (copy), u16 (copy)
            local v40 = tonumber(u38:getValue());
            if v40 and (v40 >= 1 and u18 >= v40) then
                local v41 = math.ceil(v40);
                local u42 = math.clamp(v41, 1, u18);
                u7:Open("Confirm Limit", "Are you sure you want to set a limit for " .. u32.Name .. "?\n\nOperators will not be able to generate resources over the limit specified.", {
                    { "Set Limit", function() --[[ Line: 131 ]]
                            -- upvalues: u4 (ref), u31 (ref), u42 (ref), l__Company__2 (ref), u7 (ref), u16 (ref)
                            u4:FireServer("ActivateInteract", "Limit", u31, u42);
                            l__Company__2.Limits[u31] = u42;
                            u7:Close();
                            u16:setState({});
                        end },
                    { "Cancel", function() --[[ Line: 137 ]]
                            -- upvalues: u7 (ref)
                            u7:Close();
                        end }
                });
            else
                u7:Open("Invalid Number", "Input a valid number between 1 and " .. u18 .. ".", {
                    { "Close", function() --[[ Line: 122 ]]
                            -- upvalues: u7 (ref)
                            u7:Close();
                        end }
                });
            end;
        end;
        local v44 = {};
        if l__Company__2.Limits[u31] > 0 then
            v44.Limit = u2.createElement("Frame", {
                BorderSizePixel = 0,
                ZIndex = 3,
                AnchorPoint = Vector2.new(0.5, 0.5),
                BackgroundColor3 = Color3.new(1, 1, 1),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(math.min(l__Company__2.Limits[u31], u18) / u18, 0.425),
                Size = UDim2.fromScale(0.004, 0.25)
            });
            v44.RemoveLimit = u2.createElement(u8, {
                Ignore = l__props__1.Ignore,
                AnchorPoint = Vector2.new(1, 0),
                Position = UDim2.fromScale(1, 0.6),
                Size = UDim2.fromScale(0.25, 0.3),
                Name = "Remove Limit (" .. tostring(l__Company__2.Limits[u31]) .. ")",
                Callback = function() --[[ Name: Callback, Line 160 ]]
                    -- upvalues: u4 (ref), u31 (copy), l__Company__2 (copy), u16 (copy)
                    u4:FireServer("ActivateInteract", "Limit", u31, 0);
                    l__Company__2.Limits[u31] = 0;
                    u16:setState({});
                end
            });
        else
            v44.Input = u2.createElement(u6, {
                PlaceholderText = "0",
                ClearTextOnFocus = true,
                BackgroundColor3 = Color3.new(),
                AnchorPoint = Vector2.new(1, 0),
                Position = UDim2.fromScale(0.84, 0.6),
                Size = UDim2.fromScale(0.1, 0.3),
                FontFace = u10,
                TextXAlignment = u3.TextXAlignment.Center,
                TextBind = u38,
                TextBindUpdate = v39,
                EnterPressed = v43,
                Ignore = l__props__1.Ignore,
                Content = { u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0, 4)
                    }) }
            });
            v44.LimitButton = u2.createElement(u8, {
                Name = "Set Limit",
                Ignore = l__props__1.Ignore,
                AnchorPoint = Vector2.new(1, 0),
                Position = UDim2.fromScale(1, 0.6),
                Size = UDim2.fromScale(0.15, 0.3),
                Callback = v43
            });
        end;
        local l__createElement__5 = u2.createElement;
        local v45 = "Frame";
        local v46 = {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(1, 0.25),
            Position = UDim2.fromScale(0, (v30 - 1) * 0.25)
        };
        local v47 = {
            Header = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0, 0.1),
                Size = UDim2.fromScale(0.4, 0.2),
                Text = u32.Name:upper(),
                TextColor3 = l__Color__4,
                TextXAlignment = u3.TextXAlignment.Left
            }),
            u2.createFragment(v44),
            DisposeInput = u2.createElement(u6, {
                PlaceholderText = "0",
                ClearTextOnFocus = true,
                BackgroundColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 0.6),
                Size = UDim2.fromScale(0.1, 0.3),
                FontFace = u10,
                TextXAlignment = u3.TextXAlignment.Center,
                TextBind = u33,
                TextBindUpdate = v34,
                EnterPressed = v37,
                Ignore = l__props__1.Ignore,
                Content = { u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0, 4)
                    }) }
            }),
            DisposeButton = u2.createElement(u8, {
                Name = "Dispose",
                Ignore = l__props__1.Ignore,
                Position = UDim2.fromScale(0.11, 0.6),
                Size = UDim2.fromScale(0.15, 0.3),
                Callback = v37
            }),
            White = u2.createElement("Frame", {
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 0.5),
                BackgroundColor3 = Color3.new(1, 1, 1),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 0.425),
                Size = UDim2.fromScale(1, 0.02)
            })
        };
        local l__createElement__6 = u2.createElement;
        local v48 = "Frame";
        local v50 = {
            BorderSizePixel = 0,
            ZIndex = 2,
            BackgroundColor3 = l__Color__4,
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0, 0.35),
            Size = u16.Open:Map(function(p49) --[[ Line: 256 ]]
                -- upvalues: l__Company__2 (copy), u31 (copy), u18 (ref)
                return UDim2.fromScale(l__Company__2.Resources[u31] / u18 * p49, 0.15);
            end)
        };
        local v51 = {};
        local l__createElement__7 = u2.createElement;
        local v52 = "Frame";
        local v53 = {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(1, 0),
            Position = UDim2.fromScale(1, 0),
            Size = UDim2.fromScale(1, 1),
            SizeConstraint = u3.SizeConstraint.RelativeYY
        };
        local v54 = {};
        local v55;
        if l__Company__2.Resources[u31] > 0 then
            v55 = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                AnchorPoint = Vector2.new(1, 0.5),
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0.75, 0.5),
                Size = UDim2.fromScale(10, 1.25),
                Text = l__Company__2.Resources[u31],
                TextColor3 = Color3.new(),
                TextXAlignment = u3.TextXAlignment.Right
            });
        else
            v55 = false;
        end;
        v54[1] = v55;
        v51.Constraint = l__createElement__7(v52, v53, v54);
        v47.Bar = l__createElement__6(v48, v50, v51);
        local v56;
        if v30 < #u11 then
            v56 = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 1),
                Size = UDim2.fromScale(1, 0.012)
            });
        else
            v56 = false;
        end;
        v47[2] = v56;
        v29[u31] = l__createElement__5(v45, v46, v47);
    end;
    return u2.createFragment({
        EditHeader = u2.createElement("Frame", {
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(1, 0),
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(1, 0),
            Size = UDim2.fromScale(0.695, 0.08)
        }, {
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                ScaleType = u3.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Header = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "RESOURCES",
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Position = UDim2.fromScale(0.025, 0.5),
                    Size = UDim2.fromScale(0.4, 0.6),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 139,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                })
            })
        }),
        Edit = u2.createElement("Frame", {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            LayoutOrder = 1,
            AnchorPoint = Vector2.new(1, 0),
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(1, 0.08),
            Size = UDim2.fromScale(0.695, 0.92)
        }, {
            Line = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 1),
                Size = UDim2.fromScale(1, 0.003)
            }),
            Gradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.5375) })
            }),
            Content = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(1, 0.997)
            }, { u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Position = UDim2.fromScale(0.04, 0.05),
                    Size = UDim2.fromScale(0.92, 0.9)
                }, v29) })
        }),
        CurrentHeader = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Size = UDim2.fromScale(0.3, 0.08)
        }, {
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                ScaleType = u3.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Header = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "STORAGE",
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Position = UDim2.fromScale(0.05, 0.5),
                    Size = UDim2.fromScale(0.4, 0.6),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 139,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                })
            })
        }),
        Current = u2.createElement("Frame", {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            LayoutOrder = 1,
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0, 0.08),
            Size = UDim2.fromScale(0.3, 0.61)
        }, {
            Line = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 1),
                Size = UDim2.fromScale(1, 0.006)
            }),
            Gradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.5375) })
            }),
            Content = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(1, 0.994)
            }, { u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Position = UDim2.fromScale(0.05, 0.8),
                    Size = UDim2.fromScale(0.9, 0.125)
                }, {
                    Material = u2.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        AnchorPoint = Vector2.new(1, 0.5),
                        Image = u9.Resources.Material.Icon,
                        ImageColor3 = u9.Resources.Material.Color,
                        Position = UDim2.fromScale(0.2, 0.5),
                        Size = UDim2.fromScale(0.5, 0.5),
                        SizeConstraint = u3.SizeConstraint.RelativeYY
                    }, {
                        Count = u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            TextScaled = true,
                            AnchorPoint = Vector2.new(0, 0.5),
                            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                            Position = UDim2.fromScale(1.5, 0.5),
                            Size = UDim2.fromScale(10, 1.25),
                            Text = l__Company__2.Resources.Material,
                            TextColor3 = u9.Resources.Material.Color,
                            TextXAlignment = u3.TextXAlignment.Left
                        })
                    }),
                    Metal = u2.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        AnchorPoint = Vector2.new(1, 0.5),
                        Image = u9.Resources.Metal.Icon,
                        ImageColor3 = u9.Resources.Metal.Color,
                        Position = UDim2.fromScale(0.4, 0.5),
                        Size = UDim2.fromScale(0.5, 0.5),
                        SizeConstraint = u3.SizeConstraint.RelativeYY
                    }, {
                        Count = u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            TextScaled = true,
                            AnchorPoint = Vector2.new(0, 0.5),
                            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                            Position = UDim2.fromScale(1.5, 0.5),
                            Size = UDim2.fromScale(10, 1.25),
                            Text = l__Company__2.Resources.Metal,
                            TextColor3 = u9.Resources.Metal.Color,
                            TextXAlignment = u3.TextXAlignment.Left
                        })
                    }),
                    Fuel = u2.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        AnchorPoint = Vector2.new(1, 0.5),
                        Image = u9.Resources.Fuel.Icon,
                        ImageColor3 = u9.Resources.Fuel.Color,
                        Position = UDim2.fromScale(0.6, 0.5),
                        Size = UDim2.fromScale(0.5, 0.5),
                        SizeConstraint = u3.SizeConstraint.RelativeYY
                    }, {
                        Count = u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            TextScaled = true,
                            AnchorPoint = Vector2.new(0, 0.5),
                            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                            Position = UDim2.fromScale(1.5, 0.5),
                            Size = UDim2.fromScale(10, 1.25),
                            Text = l__Company__2.Resources.Fuel,
                            TextColor3 = u9.Resources.Fuel.Color,
                            TextXAlignment = u3.TextXAlignment.Left
                        })
                    }),
                    Equipment = u2.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        AnchorPoint = Vector2.new(1, 0.5),
                        Image = u9.Resources.Equipment.Icon,
                        ImageColor3 = u9.Resources.Equipment.Color,
                        Position = UDim2.fromScale(0.8, 0.5),
                        Size = UDim2.fromScale(0.5, 0.5),
                        SizeConstraint = u3.SizeConstraint.RelativeYY
                    }, {
                        Count = u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            TextScaled = true,
                            AnchorPoint = Vector2.new(0, 0.5),
                            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                            Position = UDim2.fromScale(1.5, 0.5),
                            Size = UDim2.fromScale(10, 1.25),
                            Text = l__Company__2.Resources.Equipment,
                            TextColor3 = u9.Resources.Equipment.Color,
                            TextXAlignment = u3.TextXAlignment.Left
                        })
                    })
                }), u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Size = UDim2.fromScale(0.5, 0.5),
                    Position = UDim2.fromScale(0.5, 0.4),
                    SizeConstraint = u3.SizeConstraint.RelativeYY
                }, { u2.createElement("UIStroke", {
                        Thickness = 1,
                        Color = Color3.new(1, 1, 1)
                    }), u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0.5, 0)
                    }), u2.createFragment(v22) }) })
        }),
        Small = u2.createElement("Frame", {
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(0, 1),
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0, 1),
            Size = UDim2.fromScale(0.3, 0.3)
        }, {
            Count = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422"),
                Position = UDim2.fromScale(0, 0.335),
                Size = UDim2.fromScale(0.3, 0.4),
                Text = v20,
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Right
            }),
            Max = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                ZIndex = 2,
                FontFace = Font.new("rbxassetid://12187375422"),
                Position = UDim2.fromScale(0.3, 0.25),
                Size = UDim2.fromScale(0.3, 0.3),
                Text = "/" .. tostring(u18),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Left
            }),
            Help = u2.createElement(u8, {
                ZIndex = 2,
                NoUpper = true,
                Name = "How do I add more storage for resources?",
                SizeY = 0.45,
                Ignore = l__props__1.Ignore,
                Position = UDim2.fromScale(0.1, 0.65),
                Size = UDim2.fromScale(0.8, 0.2),
                Callback = function() --[[ Name: Callback, Line 605 ]]
                    -- upvalues: u7 (ref), l__props__1 (copy)
                    u7:Open("Adding more resource storage", "Resource storage can be expanded by assigning employees to \'LOGISTICS\' (this department).\n\nOn the \'PERSONNEL\' tab, you can view how much storage each employee contributes.", {
                        { "Personnel", function() --[[ Line: 607 ]]
                                -- upvalues: l__props__1 (ref), u7 (ref)
                                l__props__1.ChangePage("Personnel");
                                u7:Close();
                            end },
                        { "Close", function() --[[ Line: 611 ]]
                                -- upvalues: u7 (ref)
                                u7:Close();
                            end }
                    });
                end
            }),
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                ScaleType = u3.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 139,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                })
            }),
            Title = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "MAX RESOURCES",
                TextScaled = true,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422"),
                Position = UDim2.fromScale(0.7, 0.35),
                Size = UDim2.fromScale(0.2, 0.2),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Right
            })
        })
    });
end;
return v12;