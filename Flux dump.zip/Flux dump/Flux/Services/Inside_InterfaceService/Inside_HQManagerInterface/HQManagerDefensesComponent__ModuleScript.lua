-- Services.InterfaceService.HQManagerInterface.HQManagerDefensesComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, _ = shared.import("require", "Roact", "Enum", "network");
game:GetService("RunService");
local u4 = v1("RoactTween");
v1("StatsService");
v1("GameShellProxyInput");
v1("PopupInterface");
v1("MenuButtonComponent");
v1("CompanyInfo");
v1("formatNumber");
local v5 = u2.Component:extend("HQManagerDefense");
function v5.init(p6, _) --[[ Line: 30 ]]
    -- upvalues: u4 (copy), u3 (copy)
    p6.Open = u4.new(0, TweenInfo.new(1, u3.EasingStyle.Exponential, u3.EasingDirection.Out, 0, false, 0));
    p6.Open:SetGoal(1);
end;
function v5.render(p7) --[[ Line: 35 ]]
    -- upvalues: u2 (copy), u3 (copy)
    local l__Company__1 = p7.props.Company;
    local v8 = os.time();
    local l__Next__2 = l__Company__1.Raid.Next;
    local l__Last__3 = l__Company__1.Raid.Last;
    local v9 = v8 - 86400;
    local v10 = {};
    for v11 = 0, 120, 12 do
        local v12 = (v9 + v11 * 3600 - (v8 - 86400)) / 432000;
        local v13 = v11 - 24;
        local v14 = v13 == 0 and "" or (v13 > 0 and "+" .. v13 or tostring(v13)) .. "h";
        local v15 = v13 == 0 and "" or v14;
        v10["Tick_" .. v11] = u2.createElement("Frame", {
            BackgroundTransparency = 0.3,
            BorderSizePixel = 0,
            ZIndex = 2,
            Size = UDim2.new(0, 2, 2, 0),
            Position = UDim2.new(v12, 0, 0.5, 0),
            AnchorPoint = Vector2.new(0.5, 0.5),
            BackgroundColor3 = Color3.fromRGB(150, 150, 150)
        }, {
            Label = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                AnchorPoint = Vector2.new(0.5, 0),
                FontFace = Font.new("rbxassetid://12187375422"),
                Position = UDim2.fromScale(0.5, 1.4),
                Size = UDim2.new(0, 100, 0.75, 0),
                Text = v15,
                TextColor3 = Color3.fromRGB(150, 150, 150)
            })
        });
    end;
    local l__LastAttack__4 = l__Company__1.Raid.LastAttack;
    local v16 = (l__LastAttack__4 - (v8 - 86400)) / 432000;
    local v17 = (l__LastAttack__4 + 86400 - (v8 - 86400)) / 432000;
    if v17 > 0 then
        local v18 = math.max(0, v17 - v16);
        if v16 < 0 then
            v18 = v18 + v16;
        end;
        v10.GracePeriod = u2.createElement("Frame", {
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            ZIndex = 1,
            Size = UDim2.new(v18, 0, 1, 0),
            Position = UDim2.new(math.clamp(v16, 0, 1), 0, 0, 0),
            BackgroundColor3 = Color3.fromRGB(46, 204, 113)
        }, {
            Label = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "GRACE PERIOD",
                TextScaled = true,
                AnchorPoint = Vector2.new(0.5, 1),
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0.5, -1.5),
                Size = UDim2.new(0, 1000, 1.5, 0),
                TextColor3 = Color3.fromRGB(46, 204, 113)
            }),
            Tick = u2.createElement("Frame", {
                BorderSizePixel = 0,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0.5, 1),
                BackgroundColor3 = Color3.fromRGB(46, 204, 113),
                Position = UDim2.fromScale(0.5, 0),
                Size = UDim2.new(0, 2, 1, 0)
            })
        });
    end;
    v10.Now = u2.createElement("Frame", {
        BorderSizePixel = 0,
        ZIndex = 3,
        AnchorPoint = Vector2.new(0.5, 0.5),
        BackgroundColor3 = Color3.fromRGB(255, 140, 0),
        Position = UDim2.new(0.2, 0, 0.5, 0),
        Size = UDim2.new(0, 4, 2, 0)
    }, {
        Label = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "NOW",
            TextScaled = true,
            AnchorPoint = Vector2.new(0.5, 0),
            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
            Position = UDim2.fromScale(0.5, 1.4),
            Size = UDim2.new(0, 100, 0.75, 0),
            TextColor3 = Color3.fromRGB(255, 140, 0)
        })
    });
    local v19 = (l__Next__2 - (v8 - 86400)) / 432000;
    if v19 > 0 and v19 < 1 then
        local l__createElement__5 = u2.createElement;
        local v20 = {
            ZIndex = 4,
            AnchorPoint = Vector2.new(0.5, 0.5),
            BackgroundColor3 = Color3.fromRGB(255, 60, 60),
            Position = UDim2.new(v19, 0, 0.5, 0),
            Size = UDim2.fromScale(1, 1),
            SizeConstraint = u3.SizeConstraint.RelativeYY
        };
        local v21 = {
            UICorner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0.5, 0)
            }),
            Time = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                AnchorPoint = Vector2.new(0.5, 1),
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0.5, -2.8),
                Size = UDim2.new(0, 1000, 1, 0),
                Text = os.date("%B %d, %Y - %I:%M %p", l__Next__2),
                TextColor3 = Color3.fromRGB(255, 60, 60)
            })
        };
        local l__createElement__6 = u2.createElement;
        local v22 = {
            BackgroundTransparency = 1,
            TextScaled = true,
            AnchorPoint = Vector2.new(0.5, 1),
            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
            Position = UDim2.fromScale(0.5, -1.3),
            Size = UDim2.new(0, 1000, 1.5, 0)
        };
        local v23 = l__Company__1:GetRaidProbability() * 100;
        v22.Text = "POSSIBLE RAID (" .. math.floor(v23) .. "%)";
        v22.TextColor3 = Color3.fromRGB(255, 60, 60);
        v21.Label = l__createElement__6("TextLabel", v22);
        v21.Tick = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0.5, 1),
            BackgroundColor3 = Color3.fromRGB(255, 60, 60),
            Position = UDim2.fromScale(0.5, 0),
            Size = UDim2.new(0, 2, 1, 0)
        });
        v10.NextAttack = l__createElement__5("ImageLabel", v20, v21);
    end;
    local v24 = (l__Last__3 - (v8 - 86400)) / 432000;
    if v24 > 0 and v24 < 1 then
        v10.LastAttack = u2.createElement("ImageLabel", {
            ZIndex = 4,
            AnchorPoint = Vector2.new(0.5, 0.5),
            BackgroundColor3 = Color3.fromRGB(255, 60, 60),
            Position = UDim2.new(v24, 0, 0.5, 0),
            Size = UDim2.fromScale(1, 1),
            SizeConstraint = u3.SizeConstraint.RelativeYY
        }, {
            UICorner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0.5, 0)
            }),
            Time = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                AnchorPoint = Vector2.new(0.5, 1),
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0.5, -2.8),
                Size = UDim2.new(0, 1000, 1, 0),
                Text = os.date("%B %d, %Y - %I:%M %p", l__Last__3),
                TextColor3 = Color3.fromRGB(255, 60, 60)
            }),
            Label = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "LAST RAID",
                TextScaled = true,
                AnchorPoint = Vector2.new(0.5, 1),
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0.5, -1.3),
                Size = UDim2.new(0, 1000, 1.5, 0),
                TextColor3 = Color3.fromRGB(255, 60, 60)
            }),
            Tick = u2.createElement("Frame", {
                BorderSizePixel = 0,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0.5, 1),
                BackgroundColor3 = Color3.fromRGB(255, 60, 60),
                Position = UDim2.fromScale(0.5, 0),
                Size = UDim2.new(0, 2, 1, 0)
            })
        });
    end;
    return u2.createFragment({
        Timeline = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ClipsDescendants = true,
            Size = UDim2.new(1, 0, 0.2, 0),
            BackgroundColor3 = Color3.new(0, 0, 0)
        }, {
            Track = u2.createElement("Frame", {
                BorderSizePixel = 0,
                ZIndex = 2,
                Size = UDim2.new(0.9, 0, 0.1, 0),
                Position = UDim2.new(0.5, 0, 0.5, 0),
                AnchorPoint = Vector2.new(0.5, 0.5),
                BackgroundColor3 = Color3.fromRGB(80, 80, 80)
            }, v10),
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(255, 194, 39),
                ScaleType = u3.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Gradient = u2.createElement("UIGradient", {
                    Rotation = -90,
                    Transparency = NumberSequence.new({
                        NumberSequenceKeypoint.new(0, 0),
                        NumberSequenceKeypoint.new(0.179551, 0.3375),
                        NumberSequenceKeypoint.new(0.784289, 0.8),
                        NumberSequenceKeypoint.new(1, 1)
                    })
                })
            })
        })
    });
end;
return v5;