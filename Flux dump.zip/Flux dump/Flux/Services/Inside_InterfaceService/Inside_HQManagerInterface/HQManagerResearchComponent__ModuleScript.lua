-- Services.InterfaceService.HQManagerInterface.HQManagerResearchComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4, u5 = shared.import("require", "Roact", "Enum", "network", "signal");
local l__RunService__1 = game:GetService("RunService");
local l__UserInputService__2 = game:GetService("UserInputService");
local u6 = v1("RoactTween");
local u7 = v1("StatsService");
local u8 = v1("HQManagerResearchNodeComponent");
local u9 = v1("formatNumber");
local u10 = v1("PopupInterface");
local u11 = v1("MenuButtonComponent");
local u12 = v1("CompanyInfo");
local u13 = v1("SoundService");
local u14 = v1("ResearchTree");
local l__CurrentCamera__3 = workspace.CurrentCamera;
local v15 = u2.Component:extend("HQManagerMarker");
local function u20(p16) --[[ Line: 25 ]]
    local v17 = p16 % 60;
    local v18 = math.floor(p16 / 60) % 60;
    local v19 = math.floor(p16 / 3600) % 24;
    if p16 <= 0 then
        v19 = 0;
        v18 = 0;
        v17 = 0;
    end;
    return string.format("%02i", v19) .. ":" .. string.format("%02i", v18) .. ":" .. string.format("%02i", v17);
end;
function v15.init(u21, p22) --[[ Line: 38 ]]
    -- upvalues: u13 (copy), u14 (copy), u6 (copy), u3 (copy), u2 (copy), l__UserInputService__2 (copy), l__CurrentCamera__3 (copy), l__RunService__1 (copy), u5 (copy)
    p22.DarkenLerp:SetGoal(1);
    u21.DarkenLerp = p22.DarkenLerp;
    u13.DiegeticMix.Research = 0;
    local u23 = {};
    local v24 = {};
    local u25 = 0;
    local function u46(p26, p27, p28, p29, p30, p31, p32) --[[ Line: 46 ]]
        -- upvalues: u25 (ref), u23 (copy), u46 (copy)
        local v33 = table.clone(p28);
        v33[#v33 + 1] = p26.ID;
        u25 = math.max(u25, p31);
        local v34 = table.concat(v33, "_");
        local v35 = {
            Depth = p31,
            Config = p26,
            Directory = v34,
            Position = p27,
            Parent = p32
        };
        u23[v34] = v35;
        local v36 = p26.Children or {};
        local v37 = p31 == 1 and 70 or 140 / (p31 + 1);
        local v38 = (p30 - p29) / #v36;
        for v39, v40 in v36 do
            if not v40.Hidden then
                local v41 = p29 + v38 * (v39 - 0.5);
                local v42 = math.rad(v41);
                local v43 = 0.03333333333333333 / math.max(p31 - 1, 1);
                local v44 = math.cos(v42) * v43;
                local v45 = math.sin(v42) * v43;
                u46(v40, p27 + Vector2.new(v44, v45), v33, v41 - v37, v41 + v37, p31 + 1, v35);
            end;
        end;
    end;
    u46({
        ID = "Base",
        Name = "Research Lab",
        Type = "Major",
        Icon = "rbxassetid://116702387409909",
        Prerequisites = {},
        Children = u14
    }, Vector2.new(0.5, 0.5), {}, 0, 360, 1);
    for v47 = 1, u25 do
        local v48 = u6.new(0, TweenInfo.new(0.3, u3.EasingStyle.Exponential, u3.EasingDirection.Out, 0, false, (v47 - 1) * 0.1));
        v48:SetGoal(1);
        v24[v47] = v48;
    end;
    u21.NodeTree = u23;
    u21.AnimationBindings = v24;
    local u49 = 1;
    local u50 = Vector2.new(0.5, 0.5);
    u21._zoomLevel = u6.new(u49);
    local v51 = u6.new(u50.X);
    local v52 = u6.new(u50.Y);
    u21._posXTween = v51;
    u21._posYTween = v52;
    u21._positionBinding = u2.joinBindings({ u21._posXTween.Binding, u21._posYTween.Binding }):map(function(p53) --[[ Line: 107 ]]
        return Vector2.new(p53[1], p53[2]);
    end);
    local u54 = 0;
    local function v57(p55, p56) --[[ Line: 112 ]]
        -- upvalues: u49 (ref), u21 (copy)
        u49 = math.clamp(p55, 0.5, 10);
        if p56 then
            u21._zoomLevel:SetValue(u49);
        else
            u21._zoomLevel:SetGoal(u49);
        end;
    end;
    local function u60(p58, p59) --[[ Line: 120 ]]
        -- upvalues: u54 (ref), u21 (copy), u50 (ref)
        if p59 then
            u54 = tick();
            u21._posXTween:SetGoal(p58.X);
            u21._posYTween:SetGoal(p58.Y);
        else
            if tick() - u54 < 0.5 then
                return;
            end;
            u21._posXTween:SetValue(p58.X);
            u21._posYTween:SetValue(p58.Y);
        end;
        u50 = p58;
    end;
    local u61 = false;
    local u62 = Vector3.new();
    u21._began = l__UserInputService__2.InputBegan:Connect(function(p63) --[[ Line: 138 ]]
        -- upvalues: u3 (ref), u61 (ref)
        if p63.UserInputType == u3.UserInputType.MouseButton1 then
            u61 = true;
        end;
    end);
    u21._ended = l__UserInputService__2.InputEnded:Connect(function(p64) --[[ Line: 143 ]]
        -- upvalues: u3 (ref), u61 (ref)
        if p64.UserInputType == u3.UserInputType.MouseButton1 then
            u61 = false;
        end;
    end);
    u21._moved = l__UserInputService__2.TouchMoved:Connect(function(p65) --[[ Line: 148 ]]
        -- upvalues: u21 (copy), l__CurrentCamera__3 (ref), u60 (copy), u49 (ref)
        local l__Delta__4 = p65.Delta;
        local v66 = u21._positionBinding:getValue();
        local v67 = l__CurrentCamera__3.ViewportSize.Y * 0.6 * 6;
        u60(Vector2.new(math.clamp(v66.X - l__Delta__4.X / v67 / u49, 0, 1), (math.clamp(v66.Y - l__Delta__4.Y / v67 / u49, 0, 1))));
    end);
    u21._pinch = l__UserInputService__2.TouchPinch:Connect(function(_, _, p68) --[[ Line: 158 ]]
        -- upvalues: u21 (copy)
        u21._zoomTouch = p68 / 5;
    end);
    u21._changed = l__UserInputService__2.InputChanged:Connect(function(p69) --[[ Line: 161 ]]
        -- upvalues: u3 (ref), u61 (ref), u62 (ref), u21 (copy), l__CurrentCamera__3 (ref), u60 (copy), u49 (ref)
        if p69.UserInputType == u3.UserInputType.MouseMovement then
            local l__Position__5 = p69.Position;
            if u61 then
                local v70 = l__Position__5 - u62;
                local v71 = u21._positionBinding:getValue();
                local v72 = l__CurrentCamera__3.ViewportSize.Y * 0.6 * 6;
                u60(Vector2.new(math.clamp(v71.X - v70.X / v72 / u49, 0, 1), (math.clamp(v71.Y - v70.Y / v72 / u49, 0, 1))));
            end;
            u62 = l__Position__5;
        else
            if p69.UserInputType.Name:sub(1, 7) == "Gamepad" then
                if p69.KeyCode == u3.KeyCode.Thumbstick1 then
                    u21._thumbStick = p69.Position;
                    return;
                end;
                if p69.KeyCode == u3.KeyCode.Thumbstick2 then
                    u21._zoomStick = p69.Position;
                end;
            elseif p69.UserInputType == u3.UserInputType.MouseWheel then
                u49 = math.clamp(u49 + p69.Position.Z * u49 / 5, 0.5, 10);
                u21._zoomLevel:SetGoal(u49);
            end;
        end;
    end);
    local v73, v74 = u2.createBinding(os.clock());
    u21.UpdateBinding = v73;
    u21.UpdateUpdate = v74;
    u21._update = l__RunService__1.Heartbeat:Connect(function(p75) --[[ Line: 188 ]]
        -- upvalues: u21 (copy), u60 (copy), u49 (ref)
        local v76 = u21._zoomLevel:GetValue();
        local l___thumbStick__6 = u21._thumbStick;
        if l___thumbStick__6 and l___thumbStick__6.Magnitude > 0.1 then
            local v77 = l___thumbStick__6 * p75 / 2 / v76;
            local v78 = u21._positionBinding:getValue();
            u60(Vector2.new(math.clamp(v78.X + v77.X, 0, 1), (math.clamp(v78.Y - v77.Y, 0, 1))));
        end;
        local l___zoomStick__7 = u21._zoomStick;
        if l___zoomStick__7 and l___zoomStick__7.Magnitude > 0.1 then
            u49 = math.clamp(u49 + l___zoomStick__7.Y * p75 * v76, 0.5, 10);
            u21._zoomLevel:SetValue(u49);
            v76 = u49;
        end;
        local l___zoomTouch__8 = u21._zoomTouch;
        if l___zoomTouch__8 then
            u49 = math.clamp(u49 + l___zoomTouch__8 * p75 * v76 * 4, 0.5, 10);
            u21._zoomLevel:SetValue(u49);
            u21._zoomTouch = 0;
        end;
        u21.UpdateUpdate(os.clock());
    end);
    u21._setZoom = v57;
    u21._setPosition = u60;
    u21.SelectionChanged = u5.new();
end;
function v15.willUnmount(p79) --[[ Line: 223 ]]
    -- upvalues: u13 (copy)
    p79.DarkenLerp:SetGoal(0);
    p79._update:Disconnect();
    p79._began:Disconnect();
    p79._ended:Disconnect();
    p79._changed:Disconnect();
    p79._pinch:Disconnect();
    p79._moved:Disconnect();
    u13.DiegeticMix.Research = 1;
end;
function v15.render(u80) --[[ Line: 235 ]]
    -- upvalues: u2 (copy), u8 (copy), u3 (copy), u20 (copy), u9 (copy), u7 (copy), u12 (copy), u11 (copy), u10 (copy), u4 (copy), l__CurrentCamera__3 (copy)
    local l__state__9 = u80.state;
    local l__Company__10 = u80.props.Company;
    local l__Research__11 = l__Company__10.Research;
    local l__SelectedNode__12 = l__state__9.SelectedNode;
    local l__NodeTree__13 = u80.NodeTree;
    local v81 = {};
    for v82, u83 in l__NodeTree__13 do
        local l__Position__14 = u83.Position;
        local v84 = u83.Parent == nil;
        local v85 = false;
        if not v84 then
            local v86 = l__Research__11.Processing[u83.Config.ID];
            if v86 then
                if v86 <= os.time() then
                    l__Research__11.Processing[u83.Config.ID] = nil;
                    l__Research__11.Complete[#l__Research__11.Complete + 1] = u83.Config.ID;
                else
                    v85 = true;
                end;
            end;
            if table.find(l__Research__11.Complete, u83.Config.ID) then
                v84 = true;
            end;
        end;
        u83.Owned = v84;
        v81[v82] = u2.createElement(u8, {
            MapSize = 6,
            Node = u83,
            Position = UDim2.fromScale(l__Position__14.X, l__Position__14.Y),
            Binding = u80.AnimationBindings[u83.Depth],
            Nodes = l__NodeTree__13,
            Zoom = u80._zoomLevel,
            Researching = v85,
            SelectedNode = l__SelectedNode__12,
            Ignore = u80.props.Ignore,
            Callback = function() --[[ Name: Callback, Line 275 ]]
                -- upvalues: u80 (copy), u83 (copy), l__Position__14 (copy)
                u80._setZoom(u83.Depth);
                u80._setPosition(l__Position__14, true);
                u80:setState({
                    SelectedNode = u83
                });
                u80.SelectionChanged:Fire(u83);
            end,
            Update = u80.UpdateBinding,
            SelectionChanged = u80.SelectionChanged
        });
    end;
    local v88 = {
        Tree = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Position = UDim2.fromScale(0.5, 0.5),
            Size = u80._zoomLevel:Map(function(p87) --[[ Line: 292 ]]
                return UDim2.fromScale(p87 * 6, p87 * 6);
            end),
            SizeConstraint = u3.SizeConstraint.RelativeYY,
            AnchorPoint = u80._positionBinding
        }, v81),
        WIP = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ClipsDescendants = true,
            ZIndex = 2,
            BackgroundColor3 = Color3.fromRGB(255, 170, 0),
            BorderColor3 = Color3.new(),
            Size = UDim2.fromScale(0.3, 0.08)
        }, {
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageTransparency = 0.54,
                ImageColor3 = Color3.new(),
                ScaleType = u3.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Header = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "WORK IN PROGRESS (EXPERIMENTAL)",
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Position = UDim2.fromScale(0.04, 0.35),
                    Size = UDim2.fromScale(0.8, 0.4),
                    TextColor3 = Color3.new(),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 95,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                }),
                Desc = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "WE ARE RELYING ON COMMUNITY FEEDBACK TO HELP BALANCE RESEARCH",
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422"),
                    Position = UDim2.fromScale(0.04, 0.7),
                    Size = UDim2.fromScale(0.9, 0.4),
                    TextColor3 = Color3.new(),
                    TextXAlignment = u3.TextXAlignment.Left
                })
            })
        })
    };
    if l__SelectedNode__12 then
        local l__Config__15 = l__SelectedNode__12.Config;
        local v89 = {};
        local u90 = l__Research__11.Processing[l__Config__15.ID];
        local u91 = l__Config__15.Requirements or {};
        if l__SelectedNode__12.Owned then
            if l__Config__15.Item then
                v89.Message = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    RichText = true,
                    Text = "This item can be retrieved from <b>HQ Storage</b> in Openworld",
                    TextScaled = true,
                    FontFace = Font.new("rbxassetid://12187375422"),
                    Position = UDim2.fromScale(0.05, 0.75),
                    Size = UDim2.fromScale(0.9, 0.1),
                    TextColor3 = Color3.new(1, 1, 1)
                });
            end;
        elseif u90 then
            v89.TimeTitle = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "Time left:",
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Regular, u3.FontStyle.Italic),
                Position = UDim2.fromScale(0.05, 0.75),
                Size = UDim2.fromScale(0.9, 0.04),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Left
            });
            v89.Time = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Regular, u3.FontStyle.Italic),
                Position = UDim2.fromScale(0.05, 0.75),
                Size = UDim2.fromScale(0.9, 0.04),
                Text = u80.UpdateBinding:map(function() --[[ Line: 574 ]]
                    -- upvalues: u20 (ref), u90 (copy)
                    return u20(u90 - os.time());
                end),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Right
            });
            v89.Bar = u2.createElement("ImageLabel", {
                BackgroundTransparency = 0.5,
                AnchorPoint = Vector2.new(0.5, 1),
                BackgroundColor3 = Color3.fromRGB(16, 16, 16),
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                Position = UDim2.fromScale(0.5, 0.88),
                Size = UDim2.fromScale(0.8, 0.06)
            }, {
                Stroke = u2.createElement("UIStroke", {
                    Color = Color3.fromRGB(71, 71, 71)
                }, {
                    Gradient = u2.createElement("UIGradient", {
                        Transparency = NumberSequence.new({
                            NumberSequenceKeypoint.new(0, 0),
                            NumberSequenceKeypoint.new(0.2, 1),
                            NumberSequenceKeypoint.new(0.8, 1),
                            NumberSequenceKeypoint.new(1, 0)
                        })
                    })
                }),
                Corner = u2.createElement("UICorner", {
                    CornerRadius = UDim.new()
                }),
                Bar = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.fromRGB(0, 255, 115),
                    BorderColor3 = Color3.new(),
                    Size = u80.UpdateBinding:map(function() --[[ Line: 608 ]]
                        -- upvalues: u90 (copy), u80 (copy), u91 (copy)
                        local v92 = os.time();
                        if u90 > v92 then
                            return UDim2.fromScale(1 - (u90 - v92) / (u91.Time or 1), 1);
                        end;
                        u80:setState({});
                        return UDim2.fromScale(1, 1);
                    end)
                })
            });
            v89.Line = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0.05, 0.731),
                Size = UDim2.fromScale(0.9, 0.003)
            });
        else
            v89.MoneyTitle = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "Cost to research:",
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Regular, u3.FontStyle.Italic),
                Position = UDim2.fromScale(0.05, 0.71),
                Size = UDim2.fromScale(0.9, 0.04),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Left
            });
            v89.Money = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Regular, u3.FontStyle.Italic),
                Position = UDim2.fromScale(0.05, 0.71),
                Size = UDim2.fromScale(0.9, 0.04),
                Text = u9(u91.Money or 0),
                TextColor3 = u7.Money >= (u91.Money or 0) and Color3.new(1, 1, 1) or Color3.new(1, 0, 0),
                TextXAlignment = u3.TextXAlignment.Right
            });
            v89.ResearchTitle = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "Research power needed:",
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Regular, u3.FontStyle.Italic),
                Position = UDim2.fromScale(0.05, 0.63),
                Size = UDim2.fromScale(0.9, 0.04),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Left
            });
            v89.Research = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Italic),
                Position = UDim2.fromScale(0.05, 0.63),
                Size = UDim2.fromScale(0.9, 0.04),
                Text = math.floor((u91.Power or 0) * 100) .. "%",
                TextColor3 = l__Company__10:GetTotalResearchEfficiency() >= (u91.Power or 0) and Color3.new(1, 1, 1) or Color3.new(1, 0, 0),
                TextXAlignment = u3.TextXAlignment.Right
            });
            v89.ResourceTitle = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "Resources needed:",
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Regular, u3.FontStyle.Italic),
                Position = UDim2.fromScale(0.05, 0.67),
                Size = UDim2.fromScale(0.9, 0.04),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Left
            });
            v89.Resource = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Position = UDim2.fromScale(0.45, 0.67),
                Size = UDim2.fromScale(0.55, 0.05)
            }, {
                Material = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(1, 0.5),
                    Image = u12.Resources.Material.Icon,
                    ImageColor3 = u12.Resources.Material.Color,
                    Position = UDim2.fromScale(0.2, 0.5),
                    Size = UDim2.fromScale(0.5, 0.5),
                    SizeConstraint = u3.SizeConstraint.RelativeYY
                }, {
                    Count = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                        Position = UDim2.fromScale(1.5, 0.5),
                        Size = UDim2.fromScale(10, 1.25),
                        Text = u91.Material or 0,
                        TextColor3 = u12.Resources.Material.Color,
                        TextXAlignment = u3.TextXAlignment.Left
                    })
                }),
                Metal = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(1, 0.5),
                    Image = u12.Resources.Metal.Icon,
                    ImageColor3 = u12.Resources.Metal.Color,
                    Position = UDim2.fromScale(0.4, 0.5),
                    Size = UDim2.fromScale(0.5, 0.5),
                    SizeConstraint = u3.SizeConstraint.RelativeYY
                }, {
                    Count = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                        Position = UDim2.fromScale(1.5, 0.5),
                        Size = UDim2.fromScale(10, 1.25),
                        Text = u91.Metal or 0,
                        TextColor3 = u12.Resources.Metal.Color,
                        TextXAlignment = u3.TextXAlignment.Left
                    })
                }),
                Fuel = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(1, 0.5),
                    Image = u12.Resources.Fuel.Icon,
                    ImageColor3 = u12.Resources.Fuel.Color,
                    Position = UDim2.fromScale(0.6, 0.5),
                    Size = UDim2.fromScale(0.5, 0.5),
                    SizeConstraint = u3.SizeConstraint.RelativeYY
                }, {
                    Count = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                        Position = UDim2.fromScale(1.5, 0.5),
                        Size = UDim2.fromScale(10, 1.25),
                        Text = u91.Fuel or 0,
                        TextColor3 = u12.Resources.Fuel.Color,
                        TextXAlignment = u3.TextXAlignment.Left
                    })
                }),
                Equipment = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(1, 0.5),
                    Image = u12.Resources.Equipment.Icon,
                    ImageColor3 = u12.Resources.Equipment.Color,
                    Position = UDim2.fromScale(0.8, 0.5),
                    Size = UDim2.fromScale(0.5, 0.5),
                    SizeConstraint = u3.SizeConstraint.RelativeYY
                }, {
                    Count = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                        Position = UDim2.fromScale(1.5, 0.5),
                        Size = UDim2.fromScale(10, 1.25),
                        Text = u91.Equipment or 0,
                        TextColor3 = u12.Resources.Equipment.Color,
                        TextXAlignment = u3.TextXAlignment.Left
                    })
                })
            });
            v89.TimeTitle = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "Time to research:",
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Regular, u3.FontStyle.Italic),
                Position = UDim2.fromScale(0.05, 0.75),
                Size = UDim2.fromScale(0.9, 0.04),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Left
            });
            v89.Time = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Regular, u3.FontStyle.Italic),
                Position = UDim2.fromScale(0.05, 0.75),
                Size = UDim2.fromScale(0.9, 0.04),
                Text = u20(u91.Time or 1),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Right
            });
            local v93 = true;
            for _, v94 in l__Config__15.Prerequisites do
                local v95 = l__NodeTree__13["Base_" .. table.concat(v94, "_")];
                if v95 and not v95.Owned then
                    v93 = false;
                    break;
                end;
            end;
            if l__SelectedNode__12.Parent.Owned and v93 then
                v89.Start = u2.createElement(u11, {
                    Name = "RESEARCH",
                    Ignore = u80.props.Ignore,
                    Size = UDim2.fromScale(0.8, 0.06),
                    AnchorPoint = Vector2.new(0.5, 1),
                    Position = UDim2.fromScale(0.5, 0.88),
                    Callback = function() --[[ Name: Callback, Line 849 ]]
                        -- upvalues: l__Company__10 (copy), u91 (copy), u10 (ref), u7 (ref), l__SelectedNode__12 (copy), u4 (ref), l__Config__15 (copy), l__Research__11 (copy), u80 (copy)
                        if l__Company__10:GetTotalResearchEfficiency() < (u91.Power or 0) then
                            u10:Open("Not enough research efficiency", "You need to assign more researchers or improve current researchers skill level to research this item.", {
                                { "Close", function() --[[ Line: 852 ]]
                                        -- upvalues: u10 (ref)
                                        u10:Close();
                                    end }
                            });
                        elseif u7.Money < (u91.Money or 0) then
                            u10:Open("Not enough money", "You need more money to research this item.", {
                                { "Close", function() --[[ Line: 857 ]]
                                        -- upvalues: u10 (ref)
                                        u10:Close();
                                    end }
                            });
                        elseif l__Company__10.Resources.Material < (u91.Material or 0) then
                            u10:Open("Not enough resources", "You need more Construction Material to research this item.", {
                                { "Close", function() --[[ Line: 862 ]]
                                        -- upvalues: u10 (ref)
                                        u10:Close();
                                    end }
                            });
                        elseif l__Company__10.Resources.Metal < (u91.Metal or 0) then
                            u10:Open("Not enough resources", "You need more Metal to research this item.", {
                                { "Close", function() --[[ Line: 867 ]]
                                        -- upvalues: u10 (ref)
                                        u10:Close();
                                    end }
                            });
                        elseif l__Company__10.Resources.Fuel < (u91.Fuel or 0) then
                            u10:Open("Not enough resources", "You need more Fuel to research this item.", {
                                { "Close", function() --[[ Line: 872 ]]
                                        -- upvalues: u10 (ref)
                                        u10:Close();
                                    end }
                            });
                        elseif l__Company__10.Resources.Equipment < (u91.Equipment or 0) then
                            u10:Open("Not enough resources", "You need more Equipment to research this item.", {
                                { "Close", function() --[[ Line: 877 ]]
                                        -- upvalues: u10 (ref)
                                        u10:Close();
                                    end }
                            });
                        else
                            u10:Open("Research \'" .. l__SelectedNode__12.Config.Name .. "\'", "Are you sure you want to research this item?\n\nYou cannot cancel research once it is in progress.", {
                                { "Research", function() --[[ Line: 883 ]]
                                        -- upvalues: l__Company__10 (ref), u91 (ref), u4 (ref), l__Config__15 (ref), l__Research__11 (ref), u80 (ref), u10 (ref)
                                        local l__Resources__16 = l__Company__10.Resources;
                                        l__Resources__16.Material = l__Resources__16.Material - (u91.Material or 0);
                                        local l__Resources__17 = l__Company__10.Resources;
                                        l__Resources__17.Metal = l__Resources__17.Metal - (u91.Metal or 0);
                                        local l__Resources__18 = l__Company__10.Resources;
                                        l__Resources__18.Fuel = l__Resources__18.Fuel - (u91.Fuel or 0);
                                        local l__Resources__19 = l__Company__10.Resources;
                                        l__Resources__19.Equipment = l__Resources__19.Equipment - (u91.Equipment or 0);
                                        u4:FireServer("ActivateInteract", "Research", l__Config__15.ID);
                                        l__Research__11.Processing[l__Config__15.ID] = os.time() + (u91.Time or 1);
                                        u80:setState({});
                                        u10:Close();
                                    end },
                                { "Close", function() --[[ Line: 894 ]]
                                        -- upvalues: u10 (ref)
                                        u10:Close();
                                    end }
                            });
                        end;
                    end
                });
            else
                v89.Cannot = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Italic),
                    Position = UDim2.fromScale(0.1, 0.83),
                    Size = UDim2.fromScale(0.8, 0.04),
                    Text = v93 and "Must research previous node first" or "Must research all prerequisite nodes",
                    TextColor3 = Color3.new(1, 1, 1)
                });
            end;
            v89.Line = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0.05, 0.611),
                Size = UDim2.fromScale(0.9, 0.003)
            });
        end;
        local l__createElement__20 = u2.createElement;
        local v96 = "Frame";
        local v97 = {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            LayoutOrder = 1,
            ZIndex = 2,
            AnchorPoint = Vector2.new(1, 0),
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(1, 0.08),
            Size = UDim2.fromScale(0.3, 0.92)
        };
        local v98 = {
            Line = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 1),
                Size = UDim2.fromScale(1, 0.003)
            })
        };
        local l__createElement__21 = u2.createElement;
        local v99 = "Frame";
        local v100 = {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(1, 0.997)
        };
        local v101 = {
            Close = u2.createElement(u11, {
                Name = "CLOSE",
                Ignore = u80.props.Ignore,
                Size = UDim2.fromScale(0.8, 0.06),
                AnchorPoint = Vector2.new(0.5, 1),
                Position = UDim2.fromScale(0.5, 0.95),
                Callback = function() --[[ Name: Callback, Line 956 ]]
                    -- upvalues: u80 (copy), u2 (ref)
                    u80:setState({
                        SelectedNode = u2.None
                    });
                    u80.SelectionChanged:Fire();
                end
            })
        };
        local l__FlavorText__22 = l__Config__15.FlavorText;
        if l__FlavorText__22 then
            l__FlavorText__22 = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                RichText = true,
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Italic),
                Position = UDim2.fromScale(0.05, 0.34),
                Size = UDim2.fromScale(0.9, 0.05),
                Text = l__Config__15.FlavorText,
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u3.TextXAlignment.Left
            });
        end;
        local l__Description__23 = l__Config__15.Description;
        if l__Description__23 then
            l__Description__23 = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                RichText = true,
                TextWrapped = true,
                FontFace = Font.new("rbxassetid://12187375422"),
                Position = UDim2.fromScale(0.05, l__Config__15.FlavorText and 0.4 or 0.34),
                Size = UDim2.fromScale(0.9, 0.4),
                Text = l__Config__15.Description,
                TextColor3 = Color3.new(1, 1, 1),
                TextSize = l__CurrentCamera__3.ViewportSize.Y * 0.022,
                TextXAlignment = u3.TextXAlignment.Left,
                TextYAlignment = u3.TextYAlignment.Top
            });
        end;
        v101[1], v101[2] = l__FlavorText__22, l__Description__23;
        v101.Image = u2.createElement("Frame", {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0.05, 0.02),
            Size = UDim2.fromScale(0.9, 0.3)
        }, {
            Stroke = u2.createElement("UIStroke", {
                Color = Color3.fromRGB(71, 71, 71)
            }, {
                Gradient = u2.createElement("UIGradient", {
                    Transparency = NumberSequence.new({
                        NumberSequenceKeypoint.new(0, 0),
                        NumberSequenceKeypoint.new(0.2, 1),
                        NumberSequenceKeypoint.new(0.8, 1),
                        NumberSequenceKeypoint.new(1, 0)
                    })
                })
            }),
            Icon = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = l__Config__15.Image or (l__Config__15.Icon or "rbxassetid://107497991613070"),
                Position = UDim2.fromScale(0.1, 0.1),
                ScaleType = u3.ScaleType.Fit,
                Size = UDim2.fromScale(0.8, 0.8)
            })
        });
        v101[3] = u2.createFragment(v89);
        v98.Content = l__createElement__21(v99, v100, v101);
        v98.Gradient = u2.createElement("UIGradient", {
            Rotation = -90,
            Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.5375) })
        });
        v88.Content = l__createElement__20(v96, v97, v98);
        v88.Header = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ClipsDescendants = true,
            ZIndex = 2,
            AnchorPoint = Vector2.new(1, 0),
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(1, 0),
            Size = UDim2.fromScale(0.3, 0.08)
        }, {
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                ScaleType = u3.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Header = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Position = UDim2.fromScale(0.04, 0.5),
                    Size = UDim2.fromScale(10, 0.6),
                    Text = l__SelectedNode__12.Config.Name:upper(),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 139,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                })
            })
        });
    end;
    return u2.createFragment(v88);
end;
return v15;