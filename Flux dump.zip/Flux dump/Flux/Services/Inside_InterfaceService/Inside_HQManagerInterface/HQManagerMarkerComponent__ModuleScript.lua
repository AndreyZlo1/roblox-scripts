-- Services.InterfaceService.HQManagerInterface.HQManagerMarkerComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "network");
local u3 = v1("RoactTween");
v1("StatsService");
local u4 = v1("GameShellProxyButton");
v1("PopupInterface");
v1("LandingInterface");
game:GetService("RunService");
local u5 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u6 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local v7 = u2.Component:extend("HQManagerMarker");
function v7.init(p8, _) --[[ Line: 17 ]]
    -- upvalues: u3 (copy)
    p8.Hover = u3.new(0);
end;
function v7.render(u9) --[[ Line: 21 ]]
    -- upvalues: u2 (copy), u4 (copy), u5 (copy), u6 (copy)
    local l__props__1 = u9.props;
    local v13 = u2.joinBindings({ l__props__1.GlobalHover:Map(function(p10) --[[ Line: 25 ]]
            return p10;
        end), l__props__1.GlobalHoverName:map(function(p11) --[[ Line: 28 ]]
            return p11;
        end) }):map(function(p12) --[[ Line: 31 ]]
        -- upvalues: l__props__1 (copy)
        return p12[2] == l__props__1.Upgradeable and 0 or p12[1] * 0.8;
    end);
    local l__createElement__2 = u2.createElement;
    local v14 = u4;
    local v15 = {
        BackgroundTransparency = 1,
        Position = l__props__1.Position,
        Size = l__props__1.Size,
        AnchorPoint = Vector2.new(0.5, 0.5),
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        Ignore = l__props__1.Ignore,
        MouseEnter = function() --[[ Name: MouseEnter, Line 46 ]]
            -- upvalues: u9 (copy), l__props__1 (copy)
            u9.Hover:SetGoal(1);
            l__props__1.MouseEnter();
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 50 ]]
            -- upvalues: u9 (copy), l__props__1 (copy)
            u9.Hover:SetGoal(0);
            l__props__1.MouseLeave();
        end,
        MouseUp = function() --[[ Name: MouseUp, Line 54 ]]
            -- upvalues: l__props__1 (copy)
            l__props__1.MouseUp();
        end
    };
    local v16 = {};
    local v17;
    if l__props__1.Count > 0 then
        v17 = u2.createElement("Frame", {
            ZIndex = 3,
            AnchorPoint = Vector2.new(0.5, 0.5),
            BackgroundColor3 = Color3.fromRGB(255, 0, 0),
            BackgroundTransparency = v13,
            Position = UDim2.fromScale(1, 0),
            Size = u9.Hover:Map(function(p18) --[[ Line: 63 ]]
                local v19 = p18 / 5;
                return UDim2.fromScale(v19 + 0.5, v19 + 0.5);
            end),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }, {
            UICorner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0.5, 0)
            }),
            Count = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
                Position = UDim2.fromScale(0, 0.1),
                Size = UDim2.fromScale(1, 0.8),
                Text = l__props__1.Count,
                TextColor3 = Color3.new(1, 1, 1),
                TextTransparency = v13
            })
        });
    else
        v17 = false;
    end;
    v16[1], v16[2], v16[3] = v17, u2.createElement("Frame", {
    BackgroundTransparency = 1,
    ClipsDescendants = true,
    Position = UDim2.fromScale(1.6, 0),
    Size = UDim2.fromScale(5, 1)
}, { u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        Size = UDim2.fromScale(1, 0.5),
        Position = u9.Hover:Map(function(p20) --[[ Line: 97 ]]
            return UDim2.fromScale(p20 + -1, 0);
        end),
        Text = l__props__1.Name:upper(),
        TextColor3 = Color3.fromRGB(255, 194, 89),
        TextXAlignment = Enum.TextXAlignment.Left,
        FontFace = u5
    }), u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        Size = UDim2.fromScale(1, 0.5),
        Position = u9.Hover:Map(function(p21) --[[ Line: 109 ]]
            return UDim2.fromScale(p21 + -1, 0.5);
        end),
        Text = "LEVEL " .. l__props__1.Level,
        TextColor3 = Color3.fromRGB(255, 194, 89),
        TextXAlignment = Enum.TextXAlignment.Left,
        FontFace = u6
    }) }), u2.createElement("CanvasGroup", {
    BackgroundTransparency = 1,
    ZIndex = 2,
    AnchorPoint = Vector2.new(0.5, 0.5),
    Position = UDim2.fromScale(0.5, 0.5),
    Size = u9.Hover:Map(function(p22) --[[ Line: 123 ]]
        local v23 = p22 / 2;
        return UDim2.fromScale(v23 + 1, v23 + 1);
    end),
    GroupTransparency = v13
}, {
    u2.createElement("ImageLabel", {
        BackgroundTransparency = 1,
        ZIndex = 2,
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.fromScale(0.5, 0.5),
        Size = UDim2.fromScale(0.5, 0.5),
        Image = "rbxassetid://" .. l__props__1.Icon,
        ImageColor3 = Color3.fromRGB(255, 194, 89)
    }),
    u2.createElement("Frame", {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(0, 0),
        BackgroundColor3 = Color3.fromRGB(255, 194, 89),
        Position = UDim2.fromScale(0, 0),
        Size = UDim2.fromScale(0.3, 0.05)
    }),
    u2.createElement("Frame", {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(1, 0),
        BackgroundColor3 = Color3.fromRGB(255, 194, 89),
        Position = UDim2.fromScale(1, 0),
        Size = UDim2.fromScale(0.3, 0.05)
    }),
    u2.createElement("Frame", {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(0, 1),
        BackgroundColor3 = Color3.fromRGB(255, 194, 89),
        Position = UDim2.fromScale(0, 1),
        Size = UDim2.fromScale(0.3, 0.05)
    }),
    u2.createElement("Frame", {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(1, 1),
        BackgroundColor3 = Color3.fromRGB(255, 194, 89),
        Position = UDim2.fromScale(1, 1),
        Size = UDim2.fromScale(0.3, 0.05)
    }),
    u2.createElement("Frame", {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(0, 0),
        BackgroundColor3 = Color3.fromRGB(255, 194, 89),
        Position = UDim2.fromScale(0, 0),
        Size = UDim2.fromScale(0.05, 0.3)
    }),
    u2.createElement("Frame", {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(1, 0),
        BackgroundColor3 = Color3.fromRGB(255, 194, 89),
        Position = UDim2.fromScale(1, 0),
        Size = UDim2.fromScale(0.05, 0.3)
    }),
    u2.createElement("Frame", {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(0, 1),
        BackgroundColor3 = Color3.fromRGB(255, 194, 89),
        Position = UDim2.fromScale(0, 1),
        Size = UDim2.fromScale(0.05, 0.3)
    }),
    u2.createElement("Frame", {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(1, 1),
        BackgroundColor3 = Color3.fromRGB(255, 194, 89),
        Position = UDim2.fromScale(1, 1),
        Size = UDim2.fromScale(0.05, 0.3)
    })
});
    return l__createElement__2(v14, v15, v16);
end;
return v7;