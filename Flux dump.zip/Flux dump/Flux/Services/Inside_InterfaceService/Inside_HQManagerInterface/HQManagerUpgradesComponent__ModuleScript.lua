-- Services.InterfaceService.HQManagerInterface.HQManagerUpgradesComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Roact", "Enum", "network");
game:GetService("RunService");
v1("RoactTween");
local u5 = v1("StatsService");
v1("GameShellProxyScroller");
local u6 = v1("PopupInterface");
local u7 = v1("MenuButtonComponent");
local u8 = v1("CompanyInfo");
local u9 = v1("formatNumber");
Font.fromId(12187375422, u3.FontWeight.Bold, u3.FontStyle.Normal);
Font.fromId(12187375422, u3.FontWeight.Regular, u3.FontStyle.Normal);
local v10 = u2.Component:extend("HQManagerMarker");
function v10.init(p11, p12) --[[ Line: 20 ]]
    for v13, v14 in p12.Company:GetUpgradeables() do
        if v14.ID == p12.MainPage then
            p11.UpgradeList = v14;
            p11.UpgradeIndex = v13;
        end;
    end;
end;
function v10.render(u15) --[[ Line: 29 ]]
    -- upvalues: u9 (copy), u2 (copy), u3 (copy), u8 (copy), u5 (copy), u7 (copy), u6 (copy), u4 (copy)
    local l__props__1 = u15.props;
    local l__Company__2 = l__props__1.Company;
    local l__UpgradeList__3 = u15.UpgradeList;
    local v16 = l__Company__2.Levels[l__props__1.MainPage];
    local v17 = l__UpgradeList__3.Levels[v16];
    local u18 = l__UpgradeList__3.Levels[v16 + 1];
    local v19 = {};
    if u18 then
        local v20 = tostring(u18.Resources.Material);
        local v21 = tostring(u18.Resources.Metal);
        local v22 = tostring(u18.Resources.Fuel);
        local v23 = tostring(u18.Resources.Equipment);
        local v24 = u9(u18.Cost);
        v19.UpgradeHeader = u2.createElement("Frame", {
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(1, 0),
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(1, 0),
            Size = UDim2.fromScale(0.497, 0.08)
        }, {
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                ScaleType = u3.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Header = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Position = UDim2.fromScale(0.025, 0.5),
                    Size = UDim2.fromScale(0.4, 0.6),
                    Text = "LEVEL " .. tostring(v16 + 1),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 139,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                })
            })
        });
        v19.Upgrade = u2.createElement("Frame", {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            LayoutOrder = 1,
            AnchorPoint = Vector2.new(1, 0),
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(1, 0.08),
            Size = UDim2.fromScale(0.497, 0.92)
        }, {
            Line = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 1),
                Size = UDim2.fromScale(1, 0.003)
            }),
            Content = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(1, 0.997)
            }, {
                Description = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    RichText = true,
                    TextScaled = true,
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Position = UDim2.fromScale(0.055, 0.56),
                    Text = u18.Description,
                    Size = UDim2.fromScale(0.9, 0.2),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                Image = u2.createElement("ImageLabel", {
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.new(),
                    BorderColor3 = Color3.new(),
                    Image = u18.Image,
                    Position = UDim2.fromScale(0.05, 0.05),
                    ResampleMode = u3.ResamplerMode.Pixelated,
                    ScaleType = u3.ScaleType.Crop,
                    Size = UDim2.fromScale(0.9, 0.45)
                }),
                Stats = u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(0, 1),
                    Position = UDim2.fromScale(0.05, 0.875),
                    Size = UDim2.fromScale(0.9, 0.07)
                }, {
                    Material = u2.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        ImageTransparency = 0.5,
                        AnchorPoint = Vector2.new(0, 0.5),
                        Image = u8.Resources.Material.Icon,
                        ImageColor3 = u8.Resources.Material.Color,
                        Position = UDim2.fromScale(0, 0.5),
                        Size = UDim2.fromScale(0.5, 0.5),
                        SizeConstraint = u3.SizeConstraint.RelativeYY
                    }, {
                        Count = u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            TextTransparency = 0.5,
                            TextScaled = true,
                            AnchorPoint = Vector2.new(0, 0.5),
                            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                            Position = UDim2.fromScale(1.5, 0.5),
                            Size = UDim2.fromScale(10, 1.25),
                            Text = l__Company__2.Resources.Material,
                            TextColor3 = u8.Resources.Material.Color,
                            TextXAlignment = u3.TextXAlignment.Left
                        })
                    }),
                    Metal = u2.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        ImageTransparency = 0.5,
                        AnchorPoint = Vector2.new(0, 0.5),
                        Image = u8.Resources.Metal.Icon,
                        ImageColor3 = u8.Resources.Metal.Color,
                        Position = UDim2.fromScale(0.1, 0.5),
                        Size = UDim2.fromScale(0.5, 0.5),
                        SizeConstraint = u3.SizeConstraint.RelativeYY
                    }, {
                        Count = u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            TextTransparency = 0.5,
                            TextScaled = true,
                            AnchorPoint = Vector2.new(0, 0.5),
                            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                            Position = UDim2.fromScale(1.5, 0.5),
                            Size = UDim2.fromScale(10, 1.25),
                            Text = l__Company__2.Resources.Metal,
                            TextColor3 = u8.Resources.Metal.Color,
                            TextXAlignment = u3.TextXAlignment.Left
                        })
                    }),
                    Fuel = u2.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        ImageTransparency = 0.5,
                        AnchorPoint = Vector2.new(0, 0.5),
                        Image = u8.Resources.Fuel.Icon,
                        ImageColor3 = u8.Resources.Fuel.Color,
                        Position = UDim2.fromScale(0.2, 0.5),
                        Size = UDim2.fromScale(0.5, 0.5),
                        SizeConstraint = u3.SizeConstraint.RelativeYY
                    }, {
                        Count = u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            TextTransparency = 0.5,
                            TextScaled = true,
                            AnchorPoint = Vector2.new(0, 0.5),
                            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                            Position = UDim2.fromScale(1.5, 0.5),
                            Size = UDim2.fromScale(10, 1.25),
                            Text = l__Company__2.Resources.Fuel,
                            TextColor3 = u8.Resources.Fuel.Color,
                            TextXAlignment = u3.TextXAlignment.Left
                        })
                    }),
                    Equipment = u2.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        ImageTransparency = 0.5,
                        AnchorPoint = Vector2.new(0, 0.5),
                        Image = u8.Resources.Equipment.Icon,
                        ImageColor3 = u8.Resources.Equipment.Color,
                        Position = UDim2.fromScale(0.3, 0.5),
                        Size = UDim2.fromScale(0.5, 0.5),
                        SizeConstraint = u3.SizeConstraint.RelativeYY
                    }, {
                        Count = u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            TextTransparency = 0.5,
                            TextScaled = true,
                            AnchorPoint = Vector2.new(0, 0.5),
                            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                            Position = UDim2.fromScale(1.5, 0.5),
                            Size = UDim2.fromScale(10, 1.25),
                            Text = l__Company__2.Resources.Equipment,
                            TextColor3 = u8.Resources.Equipment.Color,
                            TextXAlignment = u3.TextXAlignment.Left
                        })
                    }),
                    Count = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextTransparency = 0.5,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                        Position = UDim2.fromScale(0.4, 0.5),
                        Size = UDim2.fromScale(0.225, 0.65),
                        Text = u5.MoneyBinding:map(function(p25) --[[ Line: 259 ]]
                            -- upvalues: u9 (ref)
                            return u9(p25);
                        end),
                        TextColor3 = Color3.new(1, 1, 1)
                    })
                }),
                Purchase = u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Position = UDim2.fromScale(0.05, 0.875),
                    Size = UDim2.fromScale(0.9, 0.07)
                }, {
                    Buy = u2.createElement(u7, {
                        Name = "PURCHASE",
                        Ignore = l__props__1.Ignore,
                        Size = UDim2.fromScale(0.35, 1),
                        Position = UDim2.fromScale(1, 0),
                        AnchorPoint = Vector2.new(1, 0),
                        Callback = function() --[[ Name: Callback, Line 277 ]]
                            -- upvalues: u18 (copy), l__Company__2 (copy), l__props__1 (copy), u6 (ref), l__UpgradeList__3 (copy), u5 (ref), u9 (ref), u4 (ref), u15 (copy)
                            if u18.Requires then
                                for v26, v27 in u18.Requires do
                                    if l__Company__2.Levels[v26] < v27 then
                                        local v28 = v26;
                                        for _, v29 in l__props__1.Company:GetUpgradeables() do
                                            if v29.ID == v26 then
                                                v28 = v29.Name;
                                                break;
                                            end;
                                        end;
                                        u6:Open("Prerequisites not met", v28 .. " must be minimum level " .. v27 .. " to upgrade " .. l__UpgradeList__3.Name, {
                                            { "Cancel", function() --[[ Line: 290 ]]
                                                    -- upvalues: u6 (ref)
                                                    u6:Close();
                                                end }
                                        });
                                        return;
                                    end;
                                end;
                            end;
                            if u5.Money < u18.Cost then
                                local v30 = {
                                    { "Cancel", function() --[[ Line: 301 ]]
                                            -- upvalues: u6 (ref)
                                            u6:Close();
                                        end }
                                };
                                u6:Open("Not enough money", "You need " .. u9(u18.Cost - u5.Money) .. " more to upgrade", v30);
                            elseif l__Company__2.Resources.Material < u18.Resources.Material then
                                u6:Open("Not enough resources", "You need more Construction Material to upgrade", {
                                    { "Cancel", function() --[[ Line: 307 ]]
                                            -- upvalues: u6 (ref)
                                            u6:Close();
                                        end }
                                });
                            elseif l__Company__2.Resources.Metal < u18.Resources.Metal then
                                u6:Open("Not enough resources", "You need more Metal to upgrade", {
                                    { "Cancel", function() --[[ Line: 313 ]]
                                            -- upvalues: u6 (ref)
                                            u6:Close();
                                        end }
                                });
                            elseif l__Company__2.Resources.Fuel < u18.Resources.Fuel then
                                u6:Open("Not enough resources", "You need more Fuel to upgrade", {
                                    { "Cancel", function() --[[ Line: 319 ]]
                                            -- upvalues: u6 (ref)
                                            u6:Close();
                                        end }
                                });
                            elseif l__Company__2.Resources.Equipment < u18.Resources.Equipment then
                                u6:Open("Not enough resources", "You need more Equipment to upgrade", {
                                    { "Cancel", function() --[[ Line: 325 ]]
                                            -- upvalues: u6 (ref)
                                            u6:Close();
                                        end }
                                });
                            else
                                u6:Open("Confirm upgrade", "Are you sure you want to upgrade?", {
                                    { "Upgrade", function() --[[ Line: 331 ]]
                                            -- upvalues: u4 (ref), u15 (ref), l__Company__2 (ref), u18 (ref), l__UpgradeList__3 (ref), u6 (ref)
                                            u4:FireServer("ActivateInteract", "Upgrade", u15.UpgradeIndex);
                                            local l__Resources__4 = l__Company__2.Resources;
                                            l__Resources__4.Material = l__Resources__4.Material - u18.Resources.Material;
                                            local l__Resources__5 = l__Company__2.Resources;
                                            l__Resources__5.Metal = l__Resources__5.Metal - u18.Resources.Metal;
                                            local l__Resources__6 = l__Company__2.Resources;
                                            l__Resources__6.Fuel = l__Resources__6.Fuel - u18.Resources.Fuel;
                                            local l__Resources__7 = l__Company__2.Resources;
                                            l__Resources__7.Equipment = l__Resources__7.Equipment - u18.Resources.Equipment;
                                            local l__Levels__8 = l__Company__2.Levels;
                                            local l__ID__9 = l__UpgradeList__3.ID;
                                            l__Levels__8[l__ID__9] = l__Levels__8[l__ID__9] + 1;
                                            u6:Close();
                                            u15:setState({
                                                Upgrade = 0
                                            });
                                        end },
                                    { "Cancel", function() --[[ Line: 343 ]]
                                            -- upvalues: u6 (ref)
                                            u6:Close();
                                        end }
                                });
                            end;
                        end
                    }),
                    Material = u2.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        AnchorPoint = Vector2.new(0, 0.5),
                        Image = u8.Resources.Material.Icon,
                        ImageColor3 = u8.Resources.Material.Color,
                        Position = UDim2.fromScale(0, 0.5),
                        Size = UDim2.fromScale(0.5, 0.5),
                        SizeConstraint = u3.SizeConstraint.RelativeYY
                    }, {
                        Count = u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            TextScaled = true,
                            AnchorPoint = Vector2.new(0, 0.5),
                            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                            Position = UDim2.fromScale(1.5, 0.5),
                            Size = UDim2.fromScale(10, 1.25),
                            Text = v20,
                            TextColor3 = u8.Resources.Material.Color,
                            TextXAlignment = u3.TextXAlignment.Left
                        })
                    }),
                    Metal = u2.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        AnchorPoint = Vector2.new(0, 0.5),
                        Image = u8.Resources.Metal.Icon,
                        ImageColor3 = u8.Resources.Metal.Color,
                        Position = UDim2.fromScale(0.1, 0.5),
                        Size = UDim2.fromScale(0.5, 0.5),
                        SizeConstraint = u3.SizeConstraint.RelativeYY
                    }, {
                        Count = u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            TextScaled = true,
                            AnchorPoint = Vector2.new(0, 0.5),
                            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                            Position = UDim2.fromScale(1.5, 0.5),
                            Size = UDim2.fromScale(10, 1.25),
                            Text = v21,
                            TextColor3 = u8.Resources.Metal.Color,
                            TextXAlignment = u3.TextXAlignment.Left
                        })
                    }),
                    Fuel = u2.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        AnchorPoint = Vector2.new(0, 0.5),
                        Image = u8.Resources.Fuel.Icon,
                        ImageColor3 = u8.Resources.Fuel.Color,
                        Position = UDim2.fromScale(0.2, 0.5),
                        Size = UDim2.fromScale(0.5, 0.5),
                        SizeConstraint = u3.SizeConstraint.RelativeYY
                    }, {
                        Count = u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            TextScaled = true,
                            AnchorPoint = Vector2.new(0, 0.5),
                            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                            Position = UDim2.fromScale(1.5, 0.5),
                            Size = UDim2.fromScale(10, 1.25),
                            Text = v22,
                            TextColor3 = u8.Resources.Fuel.Color,
                            TextXAlignment = u3.TextXAlignment.Left
                        })
                    }),
                    Equipment = u2.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        AnchorPoint = Vector2.new(0, 0.5),
                        Image = u8.Resources.Equipment.Icon,
                        ImageColor3 = u8.Resources.Equipment.Color,
                        Position = UDim2.fromScale(0.3, 0.5),
                        Size = UDim2.fromScale(0.5, 0.5),
                        SizeConstraint = u3.SizeConstraint.RelativeYY
                    }, {
                        Count = u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            TextScaled = true,
                            AnchorPoint = Vector2.new(0, 0.5),
                            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                            Position = UDim2.fromScale(1.5, 0.5),
                            Size = UDim2.fromScale(10, 1.25),
                            Text = v23,
                            TextColor3 = u8.Resources.Equipment.Color,
                            TextXAlignment = u3.TextXAlignment.Left
                        })
                    }),
                    Count = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                        Position = UDim2.fromScale(0.4, 0.5),
                        Size = UDim2.fromScale(0.225, 0.65),
                        Text = v24,
                        TextColor3 = Color3.new(1, 1, 1)
                    })
                })
            }),
            Gradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.5375) })
            })
        });
    end;
    return u2.createFragment({
        CurrentHeader = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Size = UDim2.fromScale(0.497, 0.08)
        }, {
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                ScaleType = u3.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Header = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Position = UDim2.fromScale(0.025, 0.5),
                    Size = UDim2.fromScale(0.4, 0.6),
                    Text = "LEVEL " .. tostring(v16) .. " (CURRENT)",
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 139,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                })
            })
        }),
        Current = u2.createElement("Frame", {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            LayoutOrder = 1,
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0, 0.08),
            Size = UDim2.fromScale(0.497, 0.92)
        }, {
            Line = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 1),
                Size = UDim2.fromScale(1, 0.003)
            }),
            Content = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(1, 0.997)
            }, {
                Image = u2.createElement("ImageLabel", {
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.new(),
                    BorderColor3 = Color3.new(),
                    Image = v17.Image,
                    Position = UDim2.fromScale(0.05, 0.05),
                    ResampleMode = u3.ResamplerMode.Pixelated,
                    ScaleType = u3.ScaleType.Crop,
                    Size = UDim2.fromScale(0.9, 0.55)
                }),
                Description = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    RichText = true,
                    TextScaled = true,
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Position = UDim2.fromScale(0.055, 0.64),
                    Size = UDim2.fromScale(0.9, 0.2),
                    Text = v17.Description,
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Left
                })
            }),
            Gradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.5375) })
            })
        }),
        u2.createFragment(v19)
    });
end;
return v10;