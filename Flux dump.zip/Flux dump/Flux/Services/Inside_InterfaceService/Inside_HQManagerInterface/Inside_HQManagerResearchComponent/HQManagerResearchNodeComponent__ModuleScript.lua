-- Services.InterfaceService.HQManagerInterface.HQManagerResearchComponent.HQManagerResearchNodeComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "network");
local l__TextService__1 = game:GetService("TextService");
local u3 = v1("RoactTween");
local u4 = v1("GameShellProxyButton");
local u5 = v1("HQManagerResearchArrowComponent");
Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u6 = {
    Minor = {
        Size = 0.12,
        Color = Color3.fromRGB(105, 146, 224)
    },
    Item = {
        Size = 0.14,
        Color = Color3.fromRGB(114, 229, 78)
    },
    Major = {
        Size = 0.15,
        Color = Color3.fromRGB(229, 88, 78)
    },
    Department = {
        Size = 0.15,
        Color = Color3.fromRGB(229, 143, 78)
    }
};
local l__CurrentCamera__2 = workspace.CurrentCamera;
local v7 = u2.Component:extend("HQManagerMarker");
function v7.init(u8, u9) --[[ Line: 37 ]]
    -- upvalues: u3 (copy), u2 (copy), l__CurrentCamera__2 (copy), l__TextService__1 (copy)
    u8.Zero = os.clock();
    u8.Hover = u3.new(0);
    local l__Node__3 = u9.Node;
    u8._connection = u9.SelectionChanged:Connect(function(p10) --[[ Line: 42 ]]
        -- upvalues: u8 (copy), l__Node__3 (copy), u9 (copy)
        u8._selectedNode = p10;
        local u11 = false;
        local function u13(p12) --[[ Line: 46 ]]
            -- upvalues: l__Node__3 (ref), u11 (ref), u13 (copy)
            if p12 == l__Node__3 then
                u11 = true;
            else
                if p12.Parent then
                    u13(p12.Parent);
                end;
            end;
        end;
        if p10 then
            if p10 == l__Node__3 then
                u11 = true;
            elseif p10.Parent then
                u13(p10.Parent);
            end;
            if not u11 then
                for _, v14 in p10.Config.Prerequisites do
                    local v15 = "Base_" .. table.concat(v14, "_");
                    if u9.Nodes[v15] then
                        local v16 = u9.Nodes[v15];
                        if v16 == l__Node__3 then
                            u11 = true;
                        elseif v16.Parent then
                            u13(v16.Parent);
                        end;
                    end;
                end;
            end;
        end;
        u8:setState({
            Selected = u11
        });
    end);
    local v17, v18 = u2.createBinding(0);
    u8._nameSize = v17;
    u8._updateNameSize = v18;
    task.spawn(function() --[[ Line: 73 ]]
        -- upvalues: l__Node__3 (copy), l__CurrentCamera__2 (ref), u8 (copy), l__TextService__1 (ref)
        local v19 = Instance.new("GetTextBoundsParams");
        v19.Text = l__Node__3.Config.Name;
        v19.Font = Font.new("rbxassetid://12187375422");
        v19.Size = math.floor(l__CurrentCamera__2.ViewportSize.Y * 0.6 * 0.1 * 0.6);
        v19.Width = (1 / 0);
        if not u8.Unmounted then
            u8._updateNameSize(l__TextService__1:GetTextBoundsAsync(v19).X);
        end;
    end);
    u8:setState({
        Selected = false
    });
end;
function v7.willUnmount(p20) --[[ Line: 90 ]]
    p20.Unmounted = true;
    p20._connection:Disconnect();
end;
function v7.render(u21) --[[ Line: 95 ]]
    -- upvalues: u6 (copy), u2 (copy), u5 (copy), u4 (copy)
    local l__props__4 = u21.props;
    local l__Node__5 = l__props__4.Node;
    local l__Minor__6 = u6.Minor;
    if l__Node__5.Config.Type and #l__Node__5.Config.Type > 0 then
        l__Minor__6 = u6[l__Node__5.Config.Type];
        if not l__Minor__6 then
            print(l__Node__5.Config.ID);
        end;
    end;
    local l__Color__7 = l__Minor__6.Color;
    local l__Owned__8 = l__Node__5.Owned;
    local l__Selected__9 = u21.state.Selected;
    local u22 = {};
    local function v26(p23, p24, p25) --[[ Line: 110 ]]
        -- upvalues: u6 (ref), l__props__4 (copy), u22 (copy), u2 (ref), u5 (ref), l__Owned__8 (copy), l__Selected__9 (copy)
        local l__Position__10 = p23.Position;
        local l__Position__11 = p24.Position;
        local l__Unit__12 = (l__Position__11 - l__Position__10).Unit;
        u22[#u22 + 1] = u2.createElement(u5, {
            Zoom = l__props__4.Zoom,
            Depth = p24.Depth,
            Binding = l__props__4.Binding,
            Owned = l__Owned__8,
            Update = l__props__4.Update,
            Dotted = p25,
            Selected = l__Selected__9,
            From = l__Position__10 + l__Unit__12 * ((p23.Config.Type and u6[p23.Config.Type] or u6.Minor).Size / l__props__4.MapSize / 2 / p23.Depth),
            To = l__Position__11 - l__Unit__12 * ((p24.Config.Type and u6[p24.Config.Type] or u6.Minor).Size / l__props__4.MapSize / 2 / p24.Depth)
        });
    end;
    if l__Node__5.Parent then
        v26(l__Node__5.Parent, l__Node__5);
    end;
    if l__Selected__9 then
        for _, v27 in l__Node__5.Config.Prerequisites do
            local v28 = "Base_" .. table.concat(v27, "_");
            if l__props__4.Nodes[v28] and not l__props__4.Nodes[v28].Owned then
                v26(l__props__4.Nodes[v28], l__Node__5, true);
            end;
        end;
    end;
    local l__createFragment__13 = u2.createFragment;
    local v29 = {};
    local v30 = u2.createFragment(u22);
    local v34 = u2.createElement("Frame", {
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
        ClipsDescendants = true,
        ZIndex = 4,
        AnchorPoint = Vector2.new(0, 0.5),
        BorderColor3 = Color3.new(),
        Position = UDim2.fromScale(l__props__4.Position.X.Scale + l__Minor__6.Size / l__props__4.MapSize / l__Node__5.Depth, l__props__4.Position.Y.Scale),
        Size = l__props__4.Zoom:Map(function(p31) --[[ Line: 154 ]]
            -- upvalues: l__props__4 (copy)
            return UDim2.fromScale(10, 0.1 / l__props__4.MapSize / p31);
        end)
    }, { u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(),
            AnchorPoint = u21.Hover:Map(function(p32) --[[ Line: 163 ]]
                return Vector2.new(1 - p32, 0);
            end),
            Size = u21._nameSize:map(function(p33) --[[ Line: 166 ]]
                return UDim2.new(0.5, p33, 1, 0);
            end),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }, {
            Title = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                RichText = true,
                TextScaled = true,
                ZIndex = 2,
                FontFace = Font.new("rbxassetid://12187375422"),
                Position = UDim2.fromScale(0, 0.2),
                Size = UDim2.fromScale(1, 0.6),
                Text = l__Node__5.Config.Name,
                TextColor3 = Color3.new(1, 1, 1),
                TextTransparency = l__Owned__8 and 0 or 0.5,
                TextXAlignment = Enum.TextXAlignment.Center
            })
        }) });
    local l__createElement__14 = u2.createElement;
    local v35 = u4;
    local v38 = {
        SoundKit = "ResearchNode",
        BackgroundTransparency = 1,
        Position = l__props__4.Position,
        Size = l__props__4.Binding:Map(function(p36) --[[ Line: 188 ]]
            -- upvalues: l__Minor__6 (ref), l__props__4 (copy), l__Node__5 (copy)
            local v37 = math.lerp(0.001, l__Minor__6.Size / l__props__4.MapSize / l__Node__5.Depth, p36);
            return UDim2.fromScale(v37, v37);
        end),
        AnchorPoint = Vector2.new(0.5, 0.5),
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        Ignore = l__props__4.Ignore,
        ZIndex = l__Selected__9 and 3 or 2,
        MouseEnter = function() --[[ Name: MouseEnter, Line 199 ]]
            -- upvalues: u21 (copy), l__props__4 (copy), l__Node__5 (copy)
            u21.Hover:SetGoal(1);
            if l__props__4.SelectedNode then
            else
                l__props__4.SelectionChanged:Fire(l__Node__5);
            end;
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 206 ]]
            -- upvalues: u21 (copy), l__props__4 (copy), l__Node__5 (copy)
            u21.Hover:SetGoal(0);
            if l__props__4.SelectedNode then
            else
                if u21._selectedNode == l__Node__5 then
                    l__props__4.SelectionChanged:Fire();
                end;
            end;
        end,
        MouseDown = function() --[[ Name: MouseDown, Line 215 ]]
            -- upvalues: l__props__4 (copy)
            l__props__4.Callback();
        end
    };
    local v45 = {
        Main = u2.createElement("Frame", {
            ZIndex = 2,
            BackgroundColor3 = l__Color__7:Lerp(Color3.new(), 0.8),
            BackgroundTransparency = l__props__4.Binding:Map(function(p39) --[[ Line: 221 ]]
                -- upvalues: l__Owned__8 (copy)
                return math.lerp(1, l__Owned__8 and 0 or 0.2, p39);
            end),
            Size = UDim2.fromScale(1, 1)
        }, {
            UICorner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0.5, 0)
            }),
            UIStroke = u2.createElement("UIStroke", {
                Thickness = 0.05,
                Color = l__Color__7,
                StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize,
                Transparency = l__props__4.Binding:Map(function(p40) --[[ Line: 234 ]]
                    -- upvalues: l__Owned__8 (copy)
                    return math.lerp(1, l__Owned__8 and 0 or 0.5, p40);
                end)
            }, {
                UIGradient = u2.createElement("UIGradient", {
                    Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.new(1, 1, 1)), ColorSequenceKeypoint.new(1, Color3.fromRGB(116, 117, 117)) }),
                    Rotation = l__props__4.Update:map(function(p41) --[[ Line: 243 ]]
                        -- upvalues: u21 (copy)
                        return (p41 - u21.Zero) * 100;
                    end)
                })
            }),
            Icon = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Image = l__Node__5.Config.Icon or "rbxassetid://107497991613070",
                ImageColor3 = l__Color__7,
                ImageTransparency = l__props__4.Binding:Map(function(p42) --[[ Line: 253 ]]
                    -- upvalues: l__Owned__8 (copy)
                    return math.lerp(1, l__Owned__8 and 0 or 0.5, p42);
                end),
                Position = UDim2.fromScale(0.5, 0.5),
                Size = UDim2.fromScale(0.5, 0.5)
            }, {
                UIGradient = u2.createElement("UIGradient", {
                    Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.new(1, 1, 1)), ColorSequenceKeypoint.new(1, Color3.fromRGB(116, 117, 117)) }),
                    Rotation = l__props__4.Update:map(function(p43) --[[ Line: 264 ]]
                        -- upvalues: u21 (copy)
                        return (p43 - u21.Zero) * 100 + 180;
                    end)
                })
            })
        }),
        Highlight = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(1, 1),
            Visible = l__Selected__9
        }, {
            UICorner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0.5, 0)
            }),
            UIStroke = u2.createElement("UIStroke", {
                Thickness = 0.1,
                Color = Color3.new(1, 1, 1),
                StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize,
                Transparency = l__props__4.Binding:Map(function(p44) --[[ Line: 282 ]]
                    -- upvalues: l__Owned__8 (copy)
                    return math.lerp(1, l__Owned__8 and 0 or 0.5, p44);
                end)
            })
        })
    };
    local l__Researching__15 = l__props__4.Researching;
    if l__Researching__15 then
        l__Researching__15 = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ZIndex = 3,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = UDim2.fromScale(0.8, 0.8)
        }, {
            UICorner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0.5, 0)
            }),
            UIStroke = u2.createElement("UIStroke", {
                Thickness = 0.05,
                Transparency = 0.5,
                StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize,
                Color = Color3.fromRGB(0, 255, 115)
            }, {
                UIGradient = u2.createElement("UIGradient", {
                    Rotation = l__props__4.Update:map(function(p46) --[[ Line: 305 ]]
                        -- upvalues: u21 (copy)
                        return (p46 - u21.Zero) * 100 + 180;
                    end),
                    Transparency = NumberSequence.new({
                        NumberSequenceKeypoint.new(0, 0),
                        NumberSequenceKeypoint.new(0.501247, 0),
                        NumberSequenceKeypoint.new(0.503741, 1),
                        NumberSequenceKeypoint.new(1, 1)
                    })
                })
            })
        });
    end;
    v45.Researching = l__Researching__15;
    v29[1], v29[2], v29[3] = v30, v34, l__createElement__14(v35, v38, v45);
    return l__createFragment__13(v29);
end;
return v7;