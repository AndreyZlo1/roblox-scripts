-- Services.InterfaceService.HQManagerInterface.HQManagerResearchComponent.HQManagerResearchArrowComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local _, u1, _ = shared.import("require", "Roact", "network");
Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local v2 = u1.Component:extend("HQManagerMarker");
function v2.init(_, _) --[[ Line: 8 ]] end;
function v2.render(p3) --[[ Line: 12 ]]
    -- upvalues: u1 (copy)
    local l__props__1 = p3.props;
    local l__Binding__2 = l__props__1.Binding;
    local _ = l__props__1.Update;
    local l__From__3 = l__props__1.From;
    local l__To__4 = l__props__1.To;
    local v4 = l__To__4 - l__From__3;
    local l__Magnitude__5 = v4.Magnitude;
    local u5 = l__Magnitude__5 * 100;
    local l__Dotted__6 = l__props__1.Dotted;
    local l__Selected__7 = l__props__1.Selected;
    local v6 = l__props__1.Owned and Color3.new(1, 1, 1) or (l__Selected__7 and Color3.new(0.6, 0.6, 0.6) or Color3.new(0.3, 0.3, 0.3));
    local l__createElement__8 = u1.createElement;
    local v7 = "Frame";
    local v11 = {
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(0.5, 0.5),
        BackgroundTransparency = l__Dotted__6 and 1 or 0,
        BackgroundColor3 = v6,
        Position = l__Binding__2:Map(function(p8) --[[ Line: 32 ]]
            -- upvalues: l__From__3 (copy), l__To__4 (copy)
            local v9 = l__From__3:Lerp(l__To__4, p8 / 2);
            return UDim2.fromScale(v9.X, v9.Y);
        end),
        Size = l__Binding__2:Map(function(p10) --[[ Line: 36 ]]
            -- upvalues: l__Magnitude__5 (copy), l__Selected__7 (copy), l__props__1 (copy)
            return UDim2.fromScale(l__Magnitude__5 * p10, (l__Selected__7 and 0.002 or 0.001) / l__props__1.Depth);
        end)
    };
    local v12 = math.atan2(v4.Y, v4.X);
    v11.Rotation = math.deg(v12);
    local v13 = {};
    if l__Dotted__6 then
        l__Dotted__6 = u1.createElement("CanvasGroup", {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(1, 1)
        }, {
            ImageTop = u1.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://96417124627213",
                ImageColor3 = v6,
                TileSize = l__props__1.Zoom:Map(function(p14) --[[ Line: 49 ]]
                    return UDim2.new(0, p14 * 10, 1, 0);
                end),
                Size = UDim2.fromScale(1, 1),
                Position = l__props__1.Update:map(function(p15) --[[ Line: 53 ]]
                    -- upvalues: u5 (copy)
                    return UDim2.fromScale(p15 % u5 / u5, 0);
                end),
                ScaleType = Enum.ScaleType.Tile,
                ResampleMode = Enum.ResamplerMode.Pixelated
            }),
            ImageBottom = u1.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://96417124627213",
                AnchorPoint = Vector2.new(1, 0),
                ImageColor3 = v6,
                TileSize = l__props__1.Zoom:Map(function(p16) --[[ Line: 64 ]]
                    return UDim2.new(0, p16 * 10, 1, 0);
                end),
                Size = UDim2.fromScale(1, 1),
                Position = l__props__1.Update:map(function(p17) --[[ Line: 68 ]]
                    -- upvalues: u5 (copy)
                    return UDim2.fromScale(p17 % u5 / u5, 0);
                end),
                ScaleType = Enum.ScaleType.Tile,
                ResampleMode = Enum.ResamplerMode.Pixelated
            })
        });
    end;
    v13[1] = l__Dotted__6;
    v13.Pointer = u1.createElement("ImageLabel", {
        BackgroundTransparency = 1,
        Image = "rbxassetid://137191725617352",
        Rotation = 90,
        ZIndex = 2,
        ImageColor3 = v6,
        Size = UDim2.fromScale(l__Selected__7 and 3 or 5, l__Selected__7 and 3 or 5),
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        Position = UDim2.fromScale(0.5, 0.5),
        AnchorPoint = Vector2.new(0.5, 0.5),
        Visible = l__Binding__2:Map(function(p18) --[[ Line: 85 ]]
            return p18 > 0.01;
        end)
    });
    return l__createElement__8(v7, v11, v13);
end;
return v2;