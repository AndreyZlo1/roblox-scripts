-- Services.InterfaceService.HQManagerInterface.HQManagerComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Roact", "network", "Enum");
local l__UserInputService__1 = game:GetService("UserInputService");
game:GetService("Players");
local u5 = v1("PostProcessingService");
local u6 = v1("PopupInterface");
local u7 = v1("InputService");
local u8 = v1("StatsService");
local u9 = v1("TutorialInterface");
local u10 = v1("formatNumber");
local u11 = v1("HQManagerMarkerComponent");
local u12 = v1("CompanyInfo");
local u13 = v1({
    "HQManagerLogisticsComponent",
    "HQManagerDeliveriesComponent",
    "HQManagerResearchComponent",
    "HQManagerDefensesComponent"
});
local u14 = v1("MenuButtonComponent");
local u15 = v1("CompanyComponent");
local u16 = v1("RoactTween");
local u17 = v1("HQManagerAfterActionReportComponent");
local u18 = v1("HQManagerPersonnelComponent");
local u19 = v1("HQManagerUpgradesComponent");
local v20 = u2.Component:extend("HQManager");
local u21 = Font.fromId(12187375422, u4.FontWeight.Regular, u4.FontStyle.Normal);
local u22 = Font.fromId(12187375422, u4.FontWeight.Bold, u4.FontStyle.Normal);
function v20.init(u23, p24) --[[ Line: 38 ]]
    -- upvalues: u15 (copy), u16 (copy), u2 (copy), u5 (copy), u6 (copy), u7 (copy), l__UserInputService__1 (copy), u4 (copy), u3 (copy), u9 (copy)
    local u25 = u15.new(p24.Company);
    u23.Company = u25;
    u23.UpdateCameraFocus = p24.UpdateCameraFocus;
    u23.GlobalHover = u16.new(0);
    u23.DarkenLerp = u16.new(0);
    local v26, v27 = u2.createBinding("");
    u23.GlobalHoverName = v26;
    u23.UpdateGlobalHoverName = v27;
    if p24.RaidResults then
        u23.RaidResults = p24.RaidResults;
    end;
    u23.BlurEffect = u5:AddBlur({
        Size = u23.GlobalHover:Map(function(p28) --[[ Line: 50 ]]
            return p28 * 5;
        end)
    }, nil, true);
    u23.DarkenBlurEffect = u5:AddBlur({
        Size = u23.DarkenLerp:Map(function(p29) --[[ Line: 56 ]]
            return p29 * 20;
        end)
    }, nil, true);
    u23.DarkenEffect = u5:AddColorCorrection({
        Brightness = u23.DarkenLerp:Map(function(p30) --[[ Line: 61 ]]
            return p30 * -0.2;
        end),
        Saturation = u23.DarkenLerp:Map(function(p31) --[[ Line: 64 ]]
            return -p31;
        end)
    }, 2);
    u23.PopupConn = u6.PopupChanged:Connect(function() --[[ Line: 68 ]]
        -- upvalues: u23 (copy), u6 (ref)
        u23:setState({
            PopupOpen = u6.PopupOpen
        });
    end);
    u23.GamepadConnection = u7.GamepadInput:Connect(function(p32) --[[ Line: 73 ]]
        -- upvalues: u23 (copy)
        u23:setState({
            Gamepad = p32
        });
    end);
    u23.Input = l__UserInputService__1.InputBegan:Connect(function(p33) --[[ Line: 78 ]]
        -- upvalues: u23 (copy), u4 (ref)
        if u23.state.Page == "Home" then
        else
            local l__Subpage__2 = u23.state.Subpage;
            if p33.KeyCode == u4.KeyCode.ButtonL1 then
                l__Subpage__2 = math.clamp(l__Subpage__2 - 1, 1, #u23.Pages);
            elseif p33.KeyCode == u4.KeyCode.ButtonR1 then
                l__Subpage__2 = math.clamp(l__Subpage__2 + 1, 1, #u23.Pages);
            end;
            u23:setState({
                Subpage = l__Subpage__2
            });
        end;
    end);
    function u23.AssignEmployee(p34, p35, p36, p37) --[[ Line: 95 ]]
        -- upvalues: u25 (copy), u6 (ref), u3 (ref), u23 (copy)
        local v38 = u25.Employees[p34];
        if v38.Delivery > os.time() then
            u6:Open("Delivery in progress", "You cannot re-assign \'" .. v38.Name .. "\' as they are currently completing a delivery. \n\nYou can track their delivery in the \'DELIVERIES\' department.", {
                { "Cancel", function() --[[ Line: 99 ]]
                        -- upvalues: u6 (ref)
                        u6:Close();
                    end }
            });
        else
            if v38.Assigned == "Logistics" then
                local v39 = 0;
                local v40 = 0;
                for _, v41 in u25.Resources do
                    v39 = v39 + v41;
                end;
                for _, v42 in u25.Employees do
                    if v42.Assigned == "Logistics" then
                        v40 = v40 + u25:GetAddedCapacity(v42);
                    end;
                end;
                if v40 - u25:GetAddedCapacity(v38) < v39 then
                    u6:Open("Too many resources", "You cannot un-assign this employee from Logistics as you have too many resources.\n\nDispose of resources in the \'LOGISTICS\' department OR sell resources in the \'DELIVERIES\' department to free up space.", {
                        { "Close", function() --[[ Line: 121 ]]
                                -- upvalues: u6 (ref)
                                u6:Close();
                            end }
                    });
                    return;
                end;
            end;
            u3:FireServer("ActivateInteract", "Assign", p34, p35, p36, p37);
            v38.Assigned = p35;
            if p35 == "Training" then
                v38.Training = {
                    Started = os.time(),
                    IsTeacher = p36,
                    Skill = p37,
                    StartingLevel = p36 and 0 or v38.Skills[p37]
                };
            elseif p35 == "Infirmary" then
                v38.Infirmary = {
                    IsDoctor = p36,
                    Started = os.time()
                };
            elseif p35 == "Operations" then
                v38.Operation = {
                    Focus = p36 ~= 2 and (p36 ~= 3 and p36 ~= 4) and 1 or p36,
                    LastAssessment = os.time()
                };
            elseif p35 == "Mechanics" then
                v38.Mechanic = p36;
            end;
            u23:setState({});
        end;
    end;
    function u23.Reassign(u43) --[[ Line: 159 ]]
        -- upvalues: u25 (copy), u6 (ref), u23 (copy), u15 (ref), u4 (ref)
        local v44 = u25.Employees[u43];
        local function u45(...) --[[ Line: 161 ]]
            -- upvalues: u6 (ref), u23 (ref), u43 (copy)
            u6:Close();
            u23.AssignEmployee(u43, ...);
        end;
        local v46 = {};
        for _, v47 in u15.Assignable do
            local v48 = u25:GetCapacity(v47);
            local v49 = 0;
            for v50, v51 in u25.Employees do
                if v51.Assigned == v47 then
                    v49 = v49 + 1;
                    if v50 == u43 and (v47 ~= "Training" and v47 ~= "Infirmary") then
                        v46[v47] = "(CURRENT)";
                    end;
                end;
            end;
            if v48 <= v49 and v44.Assigned ~= v47 then
                v46[v47] = "(FULL)";
            end;
        end;
        u6:Open("Re-Assign Employee", "Choose what department to assign this employee", {
            { "Logistics", function() --[[ Line: 186 ]]
                    -- upvalues: u45 (copy)
                    u45("Logistics");
                end, v46.Logistics },
            { "Operations", function() --[[ Line: 189 ]]
                    -- upvalues: u6 (ref), u45 (copy), u4 (ref)
                    u6:Open("Resource focus", "What resource should this employee gather?", {
                        { "Construction Materials", function() --[[ Line: 191 ]]
                                -- upvalues: u45 (ref)
                                u45("Operations", 1);
                            end },
                        { "Precious Metals", function() --[[ Line: 194 ]]
                                -- upvalues: u45 (ref)
                                u45("Operations", 2);
                            end },
                        { "Fuel", function() --[[ Line: 197 ]]
                                -- upvalues: u45 (ref)
                                u45("Operations", 3);
                            end },
                        { "Equipment", function() --[[ Line: 200 ]]
                                -- upvalues: u45 (ref)
                                u45("Operations", 4);
                            end },
                        { "Cancel", function() --[[ Line: 203 ]]
                                -- upvalues: u6 (ref)
                                u6:Close();
                            end }
                    }, u4.PopupType.Vertical);
                end, v46.Operations },
            { "Deliveries", function() --[[ Line: 208 ]]
                    -- upvalues: u45 (copy)
                    u45("Deliveries");
                end, v46.Deliveries },
            { "Command", function() --[[ Line: 211 ]]
                    -- upvalues: u45 (copy)
                    u45("Command");
                end, v46.Command },
            { "Training", function() --[[ Line: 214 ]]
                    -- upvalues: u6 (ref), u45 (copy), u4 (ref)
                    u6:Open("Training type", "Assign to training as a student or teacher?", {
                        { "Teacher", function() --[[ Line: 216 ]]
                                -- upvalues: u6 (ref), u45 (ref), u4 (ref)
                                u6:Open("Curriculum type", "What skill should this employee teach?", {
                                    { "Logistics", function() --[[ Line: 218 ]]
                                            -- upvalues: u45 (ref)
                                            u45("Training", true, "Logistics");
                                        end },
                                    { "Combat", function() --[[ Line: 221 ]]
                                            -- upvalues: u45 (ref)
                                            u45("Training", true, "Combat");
                                        end },
                                    { "Mechanics", function() --[[ Line: 224 ]]
                                            -- upvalues: u45 (ref)
                                            u45("Training", true, "Mechanics");
                                        end },
                                    { "Command", function() --[[ Line: 227 ]]
                                            -- upvalues: u45 (ref)
                                            u45("Training", true, "Command");
                                        end },
                                    { "Deliveries", function() --[[ Line: 230 ]]
                                            -- upvalues: u45 (ref)
                                            u45("Training", true, "Deliveries");
                                        end },
                                    { "Medical", function() --[[ Line: 233 ]]
                                            -- upvalues: u45 (ref)
                                            u45("Training", true, "Medical");
                                        end },
                                    { "Cancel", function() --[[ Line: 236 ]]
                                            -- upvalues: u6 (ref)
                                            u6:Close();
                                        end }
                                }, u4.PopupType.Vertical);
                            end },
                        { "Student", function() --[[ Line: 241 ]]
                                -- upvalues: u6 (ref), u45 (ref), u4 (ref)
                                u6:Open("Curriculum type", "What skill should this employee focus on improving?", {
                                    { "Logistics", function() --[[ Line: 243 ]]
                                            -- upvalues: u45 (ref)
                                            u45("Training", false, "Logistics");
                                        end },
                                    { "Combat", function() --[[ Line: 246 ]]
                                            -- upvalues: u45 (ref)
                                            u45("Training", false, "Combat");
                                        end },
                                    { "Mechanics", function() --[[ Line: 249 ]]
                                            -- upvalues: u45 (ref)
                                            u45("Training", false, "Mechanics");
                                        end },
                                    { "Command", function() --[[ Line: 252 ]]
                                            -- upvalues: u45 (ref)
                                            u45("Training", false, "Command");
                                        end },
                                    { "Deliveries", function() --[[ Line: 255 ]]
                                            -- upvalues: u45 (ref)
                                            u45("Training", false, "Deliveries");
                                        end },
                                    { "Medical", function() --[[ Line: 258 ]]
                                            -- upvalues: u45 (ref)
                                            u45("Training", false, "Medical");
                                        end },
                                    { "Cancel", function() --[[ Line: 261 ]]
                                            -- upvalues: u6 (ref)
                                            u6:Close();
                                        end }
                                }, u4.PopupType.Vertical);
                            end },
                        { "Cancel", function() --[[ Line: 266 ]]
                                -- upvalues: u6 (ref)
                                u6:Close();
                            end }
                    }, u4.PopupType.Vertical);
                end, v46.Training },
            { "Mechanics", function() --[[ Line: 271 ]]
                    -- upvalues: u6 (ref), u45 (copy), u4 (ref)
                    u6:Open("Assign division", "What type of vehicle should this employee work on?", {
                        { "Ground", function() --[[ Line: 273 ]]
                                -- upvalues: u45 (ref)
                                u45("Mechanics", "Ground");
                            end },
                        { "Helicopter", function() --[[ Line: 276 ]]
                                -- upvalues: u45 (ref)
                                u45("Mechanics", "Helicopter");
                            end },
                        { "Plane", function() --[[ Line: 279 ]]
                                -- upvalues: u45 (ref)
                                u45("Mechanics", "Plane");
                            end },
                        { "Cancel", function() --[[ Line: 282 ]]
                                -- upvalues: u6 (ref)
                                u6:Close();
                            end }
                    }, u4.PopupType.Vertical);
                end, v46.Mechanics },
            { "Infirmary", function() --[[ Line: 287 ]]
                    -- upvalues: u6 (ref), u45 (copy), u4 (ref)
                    u6:Open("Staff type", "Should this employee work as a doctor or are they a patient?", {
                        { "Doctor", function() --[[ Line: 289 ]]
                                -- upvalues: u45 (ref)
                                u45("Infirmary", true);
                            end },
                        { "Patient", function() --[[ Line: 292 ]]
                                -- upvalues: u45 (ref)
                                u45("Infirmary", false);
                            end },
                        { "Cancel", function() --[[ Line: 295 ]]
                                -- upvalues: u6 (ref)
                                u6:Close();
                            end }
                    }, u4.PopupType.Vertical);
                end, v46.Infirmary },
            { "Research", function() --[[ Line: 300 ]]
                    -- upvalues: u45 (copy)
                    u45("Research");
                end, v46.Research },
            { "Defenses", function() --[[ Line: 303 ]]
                    -- upvalues: u45 (copy)
                    u45("Defenses");
                end, v46.Defenses },
            { "Unassigned", function() --[[ Line: 306 ]]
                    -- upvalues: u45 (copy)
                    u45("Unassigned");
                end },
            { "Cancel", function() --[[ Line: 309 ]]
                    -- upvalues: u6 (ref)
                    u6:Close();
                end }
        }, u4.PopupType.Vertical);
    end;
    u23._controls = u7:Connect({
        Exit = function(p52) --[[ Name: Exit, Line 316 ]]
            -- upvalues: u23 (copy), u3 (ref)
            if p52 then
                if u23.state.Page == "Home" then
                    u3:FireServer("ActivateInteract", "Exit");
                else
                    u23.UpdateCameraFocus("");
                    u23:setState({
                        Page = "Home"
                    });
                end;
            end;
        end
    });
    u23:setState({
        Page = "Home",
        Gamepad = u7.Gamepad,
        PopupOpen = u6.PopupOpen
    });
    u9.ManageCompany = u23;
end;
function v20.willUnmount(p53) --[[ Line: 341 ]]
    -- upvalues: u9 (copy)
    u9.ManageCompany = nil;
    if p53._controls then
        p53._controls:Disconnect();
    end;
    p53.GamepadConnection:Disconnect();
    p53.Input:Disconnect();
    p53.BlurEffect.Destroy();
    p53.DarkenEffect.Destroy();
    p53.DarkenBlurEffect.Destroy();
    p53.PopupConn:Disconnect();
end;
function v20.render(u54) --[[ Line: 356 ]]
    -- upvalues: u2 (copy), u17 (copy), u12 (copy), u11 (copy), u4 (copy), u8 (copy), u10 (copy), u14 (copy), u3 (copy), u15 (copy), u13 (copy), u18 (copy), u19 (copy), u21 (copy), u22 (copy), l__UserInputService__1 (copy)
    local l__props__3 = u54.props;
    local l__state__4 = u54.state;
    local l__Company__5 = u54.Company;
    local l__Page__6 = l__state__4.Page;
    if u54.RaidResults then
        return u2.createElement(u17, {
            Results = u54.RaidResults,
            Ignore = l__state__4.PopupOpen,
            Close = function() --[[ Name: Close, Line 365 ]]
                -- upvalues: u54 (copy)
                u54.RaidResults = nil;
                u54:setState({});
            end
        });
    end;
    if l__Page__6 == "Home" then
        local v55 = {
            Deliveries = 0,
            Operations = 0,
            Defenses = 0,
            Barracks = 0,
            Training = 0
        };
        for _, v56 in l__Company__5.Deliveries do
            if os.time() >= v56.End then
                v55.Deliveries = v55.Deliveries + 1;
            end;
        end;
        local v57 = 0;
        local v58 = {};
        local v59 = {};
        local v60 = false;
        for _, v61 in l__Company__5.Employees do
            local l__Assigned__7 = v61.Assigned;
            if l__Assigned__7 == "Unassigned" then
                v55.Barracks = v55.Barracks + 1;
            elseif l__Assigned__7 == "Operations" or l__Assigned__7 == "Defenses" then
                if v61.Health < 10 then
                    v55[l__Assigned__7] = v55[l__Assigned__7] + 1;
                end;
            elseif l__Assigned__7 == "Training" then
                if v61.Training.IsTeacher then
                    v58[v61.Training.Skill] = true;
                else
                    v59[#v59 + 1] = v61;
                end;
            elseif l__Assigned__7 == "Infirmary" then
                if v61.Infirmary.IsDoctor then
                    v60 = true;
                else
                    v57 = v57 + 1;
                end;
            end;
        end;
        for _, v62 in v59 do
            if not v58[v62.Training.Skill] then
                v55.Training = v55.Training + 1;
            end;
        end;
        if not v60 then
            v55.Infirmary = v57;
        end;
        local v63 = {};
        for u64, u65 in l__props__3.HQUpgrades do
            local v66 = u12.Departments[u64] or {
                Icon = 16191609576,
                Name = l__Page__6
            };
            v63[u64] = u2.createElement(u11, {
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = u65.Position,
                Ignore = l__state__4.PopupOpen,
                Size = UDim2.fromScale(0.06, 0.06),
                SizeConstraint = u4.SizeConstraint.RelativeYY,
                GlobalHover = u54.GlobalHover,
                GlobalHoverName = u54.GlobalHoverName,
                Upgradeable = u64,
                Count = v55[u64] or 0,
                Level = l__Company__5.Levels[u64],
                Name = v66.Name,
                Icon = v66.Icon,
                MouseUp = function() --[[ Name: MouseUp, Line 440 ]]
                    -- upvalues: u54 (copy), u64 (copy), u65 (copy)
                    u54.UpdateCameraFocus(u64);
                    u54:setState({
                        Subpage = 1,
                        Page = u64
                    });
                    u54.UpdateGlobalHoverName("");
                    u54.GlobalHover:SetGoal(0);
                    u65.Hover = false;
                end,
                MouseEnter = function() --[[ Name: MouseEnter, Line 450 ]]
                    -- upvalues: u54 (copy), u64 (copy), u65 (copy)
                    u54.UpdateGlobalHoverName(u64);
                    u54.GlobalHover:SetGoal(1);
                    u65.Hover = true;
                end,
                MouseLeave = function() --[[ Name: MouseLeave, Line 455 ]]
                    -- upvalues: u54 (copy), u65 (copy)
                    u54.UpdateGlobalHoverName("");
                    u54.GlobalHover:SetGoal(0);
                    u65.Hover = false;
                end
            });
        end;
        v63._Header = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0.1, 0.05),
            Size = UDim2.fromScale(0.28, 0.08),
            SizeConstraint = u4.SizeConstraint.RelativeYY
        }, {
            Count = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", u4.FontWeight.Bold, u4.FontStyle.Normal),
                Position = UDim2.fromScale(0.08, 0.2),
                Size = UDim2.fromScale(10, 0.25),
                Text = u8.MoneyBinding:map(function(p67) --[[ Line: 480 ]]
                    -- upvalues: u10 (ref)
                    return u10(p67);
                end),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u4.TextXAlignment.Left
            }),
            Exit = u2.createElement(u14, {
                Image = "rbxassetid://95718280743867",
                ImageY = 0.6,
                Size = UDim2.fromScale(1, 1),
                Position = UDim2.fromScale(1.01, 0),
                AnchorPoint = Vector2.new(0, 0),
                SizeConstraint = u4.SizeConstraint.RelativeYY,
                Ignore = l__state__4.PopupOpen,
                Callback = function() --[[ Name: Callback, Line 495 ]]
                    -- upvalues: u3 (ref)
                    u3:FireServer("ActivateInteract", "Exit");
                end
            }),
            Materials = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Position = UDim2.fromScale(-0.08, 0.5),
                Size = UDim2.fromScale(1.1, 0.4)
            }, {
                Material = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(1, 0.5),
                    Image = u12.Resources.Material.Icon,
                    ImageColor3 = u12.Resources.Material.Color,
                    Position = UDim2.fromScale(0.2, 0.5),
                    Size = UDim2.fromScale(0.5, 0.5),
                    SizeConstraint = u4.SizeConstraint.RelativeYY
                }, {
                    Count = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = Font.new("rbxassetid://12187375422", u4.FontWeight.Bold, u4.FontStyle.Normal),
                        Position = UDim2.fromScale(1.5, 0.5),
                        Size = UDim2.fromScale(10, 1.25),
                        Text = l__Company__5.Resources.Material,
                        TextColor3 = u12.Resources.Material.Color,
                        TextXAlignment = u4.TextXAlignment.Left
                    })
                }),
                Metal = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(1, 0.5),
                    Image = u12.Resources.Metal.Icon,
                    ImageColor3 = u12.Resources.Metal.Color,
                    Position = UDim2.fromScale(0.4, 0.5),
                    Size = UDim2.fromScale(0.5, 0.5),
                    SizeConstraint = u4.SizeConstraint.RelativeYY
                }, {
                    Count = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = Font.new("rbxassetid://12187375422", u4.FontWeight.Bold, u4.FontStyle.Normal),
                        Position = UDim2.fromScale(1.5, 0.5),
                        Size = UDim2.fromScale(10, 1.25),
                        Text = l__Company__5.Resources.Metal,
                        TextColor3 = u12.Resources.Metal.Color,
                        TextXAlignment = u4.TextXAlignment.Left
                    })
                }),
                Fuel = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(1, 0.5),
                    Image = u12.Resources.Fuel.Icon,
                    ImageColor3 = u12.Resources.Fuel.Color,
                    Position = UDim2.fromScale(0.6, 0.5),
                    Size = UDim2.fromScale(0.5, 0.5),
                    SizeConstraint = u4.SizeConstraint.RelativeYY
                }, {
                    Count = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = Font.new("rbxassetid://12187375422", u4.FontWeight.Bold, u4.FontStyle.Normal),
                        Position = UDim2.fromScale(1.5, 0.5),
                        Size = UDim2.fromScale(10, 1.25),
                        Text = l__Company__5.Resources.Fuel,
                        TextColor3 = u12.Resources.Fuel.Color,
                        TextXAlignment = u4.TextXAlignment.Left
                    })
                }),
                Equipment = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(1, 0.5),
                    Image = u12.Resources.Equipment.Icon,
                    ImageColor3 = u12.Resources.Equipment.Color,
                    Position = UDim2.fromScale(0.8, 0.5),
                    Size = UDim2.fromScale(0.5, 0.5),
                    SizeConstraint = u4.SizeConstraint.RelativeYY
                }, {
                    Count = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = Font.new("rbxassetid://12187375422", u4.FontWeight.Bold, u4.FontStyle.Normal),
                        Position = UDim2.fromScale(1.5, 0.5),
                        Size = UDim2.fromScale(10, 1.25),
                        Text = l__Company__5.Resources.Equipment,
                        TextColor3 = u12.Resources.Equipment.Color,
                        TextXAlignment = u4.TextXAlignment.Left
                    })
                })
            })
        });
        return u2.createFragment(v63);
    end;
    local v68 = u12.Departments[l__Page__6] or {
        Icon = 16191609576,
        Name = l__Page__6
    };
    local l__Gamepad__8 = l__state__4.Gamepad;
    local u69 = {};
    if not l__Gamepad__8 then
        u69[1] = "Exit";
    end;
    u54.Pages = u69;
    for _, v70 in l__Company__5:GetUpgradeables() do
        if v70.ID == l__Page__6 then
            table.insert(u69, 1, "Upgrades");
            break;
        end;
    end;
    local v71 = (l__Page__6 == "PlaneHangers" or (l__Page__6 == "HeliHangers" or l__Page__6 == "Garage")) and "Mechanics" or l__Page__6;
    if table.find(u15.Assignable, v71) or l__Page__6 == "Barracks" then
        table.insert(u69, 1, "Personnel");
    end;
    if u13["HQManager" .. v71 .. "Component"] then
        table.insert(u69, 1, "Overview");
    end;
    local l__Subpage__9 = l__state__4.Subpage;
    local v72 = {};
    for u73, u74 in u69 do
        v72[u74] = u2.createElement(u14, {
            Layout = u73,
            Name = u74,
            Ignore = l__Gamepad__8 or l__state__4.PopupOpen,
            Activated = l__Subpage__9 == u73,
            Callback = function() --[[ Name: Callback, Line 646 ]]
                -- upvalues: u74 (copy), u54 (copy), u73 (copy)
                if u74 == "Exit" then
                    u54.UpdateCameraFocus("");
                    u54:setState({
                        Page = "Home"
                    });
                else
                    u54:setState({
                        Subpage = u73
                    });
                end;
            end
        });
    end;
    local v75 = nil;
    local v76 = u69[l__Subpage__9];
    if v76 == "Personnel" then
        v75 = u18;
    elseif v76 == "Overview" then
        v75 = u13["HQManager" .. v71 .. "Component"];
    elseif v76 == "Upgrades" then
        v75 = u19;
    end;
    local l__createElement__10 = u2.createElement;
    local v77 = "Frame";
    local v78 = {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1.4, 1),
        Position = UDim2.fromScale(0.5, 0),
        AnchorPoint = Vector2.new(0.5, 0),
        SizeConstraint = u4.SizeConstraint.RelativeYY
    };
    local v80 = {
        Page = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(1, 0.6),
            Position = UDim2.fromScale(0, 0.255)
        }, { u2.createElement(v75, {
                ChangePage = function(p79) --[[ Name: ChangePage, Line 684 ]]
                    -- upvalues: u54 (copy), u69 (copy)
                    u54:setState({
                        Subpage = table.find(u69, p79)
                    });
                end,
                AssignEmployee = u54.AssignEmployee,
                Reassign = u54.Reassign,
                DarkenLerp = u54.DarkenLerp,
                Ignore = l__state__4.PopupOpen,
                Company = l__Company__5,
                Department = u12.Departments[v71],
                MainPage = l__Page__6,
                Page = v71
            }) })
    };
    local l__createElement__11 = u2.createElement;
    local v81 = "Frame";
    local v82 = {
        BorderSizePixel = 0,
        BackgroundTransparency = 0.5,
        Size = UDim2.fromScale(1, 0.2),
        BackgroundColor3 = Color3.new()
    };
    local v84 = {
        Gradient = u2.createElement("UIGradient", {
            Rotation = -90,
            Transparency = NumberSequence.new(0, 1)
        }),
        Title = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            ZIndex = 2,
            Position = UDim2.fromScale(0, 0.5),
            Size = UDim2.fromScale(1, 0.4),
            TextColor3 = Color3.new(1, 1, 1),
            Text = v68.Name:upper(),
            FontFace = u21
        }),
        Fade = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextTransparency = 0.8,
            TextScaled = true,
            RichText = true,
            ZIndex = 1,
            Position = UDim2.fromScale(0, 0),
            Size = UDim2.fromScale(1, 1),
            TextColor3 = Color3.new(1, 1, 1),
            Text = v68.Name:upper(),
            FontFace = u22
        }, {
            Gradient = u2.createElement("UIGradient", {
                Rotation = 90,
                Transparency = NumberSequence.new(0, 1)
            })
        }),
        Stats = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Position = UDim2.fromScale(0, 0.6),
            Size = UDim2.fromScale(1.5, 0.4),
            SizeConstraint = u4.SizeConstraint.RelativeYY
        }, {
            Count = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", u4.FontWeight.Bold, u4.FontStyle.Normal),
                Position = UDim2.fromScale(0.08, 0.2),
                Size = UDim2.fromScale(10, 0.25),
                Text = u8.MoneyBinding:map(function(p83) --[[ Line: 753 ]]
                    -- upvalues: u10 (ref)
                    return u10(p83);
                end),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u4.TextXAlignment.Left
            }),
            Materials = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Position = UDim2.fromScale(-0.08, 0.5),
                Size = UDim2.fromScale(1.1, 0.4)
            }, {
                Material = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(1, 0.5),
                    Image = u12.Resources.Material.Icon,
                    ImageColor3 = u12.Resources.Material.Color,
                    Position = UDim2.fromScale(0.2, 0.5),
                    Size = UDim2.fromScale(0.5, 0.5),
                    SizeConstraint = u4.SizeConstraint.RelativeYY
                }, {
                    Count = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = Font.new("rbxassetid://12187375422", u4.FontWeight.Bold, u4.FontStyle.Normal),
                        Position = UDim2.fromScale(1.5, 0.5),
                        Size = UDim2.fromScale(10, 1.25),
                        Text = l__Company__5.Resources.Material,
                        TextColor3 = u12.Resources.Material.Color,
                        TextXAlignment = u4.TextXAlignment.Left
                    })
                }),
                Metal = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(1, 0.5),
                    Image = u12.Resources.Metal.Icon,
                    ImageColor3 = u12.Resources.Metal.Color,
                    Position = UDim2.fromScale(0.4, 0.5),
                    Size = UDim2.fromScale(0.5, 0.5),
                    SizeConstraint = u4.SizeConstraint.RelativeYY
                }, {
                    Count = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = Font.new("rbxassetid://12187375422", u4.FontWeight.Bold, u4.FontStyle.Normal),
                        Position = UDim2.fromScale(1.5, 0.5),
                        Size = UDim2.fromScale(10, 1.25),
                        Text = l__Company__5.Resources.Metal,
                        TextColor3 = u12.Resources.Metal.Color,
                        TextXAlignment = u4.TextXAlignment.Left
                    })
                }),
                Fuel = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(1, 0.5),
                    Image = u12.Resources.Fuel.Icon,
                    ImageColor3 = u12.Resources.Fuel.Color,
                    Position = UDim2.fromScale(0.6, 0.5),
                    Size = UDim2.fromScale(0.5, 0.5),
                    SizeConstraint = u4.SizeConstraint.RelativeYY
                }, {
                    Count = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = Font.new("rbxassetid://12187375422", u4.FontWeight.Bold, u4.FontStyle.Normal),
                        Position = UDim2.fromScale(1.5, 0.5),
                        Size = UDim2.fromScale(10, 1.25),
                        Text = l__Company__5.Resources.Fuel,
                        TextColor3 = u12.Resources.Fuel.Color,
                        TextXAlignment = u4.TextXAlignment.Left
                    })
                }),
                Equipment = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(1, 0.5),
                    Image = u12.Resources.Equipment.Icon,
                    ImageColor3 = u12.Resources.Equipment.Color,
                    Position = UDim2.fromScale(0.8, 0.5),
                    Size = UDim2.fromScale(0.5, 0.5),
                    SizeConstraint = u4.SizeConstraint.RelativeYY
                }, {
                    Count = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        FontFace = Font.new("rbxassetid://12187375422", u4.FontWeight.Bold, u4.FontStyle.Normal),
                        Position = UDim2.fromScale(1.5, 0.5),
                        Size = UDim2.fromScale(10, 1.25),
                        Text = l__Company__5.Resources.Equipment,
                        TextColor3 = u12.Resources.Equipment.Color,
                        TextXAlignment = u4.TextXAlignment.Left
                    })
                })
            })
        }),
        Buttons = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Position = UDim2.fromScale(0, 1.04),
            Size = UDim2.fromScale(1, 0.2)
        }, {
            Grid = u2.createElement("UIGridLayout", {
                CellPadding = UDim2.fromScale(0.005, 0),
                CellSize = UDim2.fromScale(1 / #u69 - 0.005, 1),
                FillDirection = u4.FillDirection.Horizontal,
                HorizontalAlignment = u4.HorizontalAlignment.Center,
                SortOrder = u4.SortOrder.LayoutOrder
            }),
            u2.createFragment(v72)
        })
    };
    local v85;
    if l__Gamepad__8 then
        v85 = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(1, 0),
            Position = UDim2.fromScale(0, 1.04),
            Size = UDim2.new(0.25, 0, 0.2, 0),
            SizeConstraint = u4.SizeConstraint.RelativeYY,
            Image = l__UserInputService__1:GetImageForKeyCode(u4.KeyCode.ButtonL1),
            ScaleType = u4.ScaleType.Fit
        });
    else
        v85 = l__Gamepad__8;
    end;
    if l__Gamepad__8 then
        l__Gamepad__8 = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.fromScale(1, 1.04),
            Size = UDim2.new(0.25, 0, 0.2, 0),
            SizeConstraint = u4.SizeConstraint.RelativeYY,
            Image = l__UserInputService__1:GetImageForKeyCode(u4.KeyCode.ButtonR1),
            ScaleType = u4.ScaleType.Fit
        });
    end;
    v84[1], v84[2], v84[3] = v85, l__Gamepad__8, u2.createElement("Frame", {
    BackgroundTransparency = 1,
    Position = UDim2.fromScale(0.85, 0.2),
    Size = UDim2.fromScale(0.6, 0.6),
    SizeConstraint = u4.SizeConstraint.RelativeYY
}, {
    UICorner = u2.createElement("UICorner", {
        CornerRadius = UDim.new(0.5, 0)
    }),
    UIStroke = u2.createElement("UIStroke", {
        Thickness = 0.05,
        Transparency = 0.5,
        Color = Color3.fromRGB(253, 255, 255),
        StrokeSizingMode = u4.StrokeSizingMode.ScaledSize
    }, {
        Gradient = u2.createElement("UIGradient", {
            Rotation = 90,
            Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
        })
    }),
    Fade = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        RichText = true,
        TextTransparency = 0.5,
        FontFace = Font.new("rbxassetid://12187375422", u4.FontWeight.Bold, u4.FontStyle.Normal),
        Size = UDim2.fromScale(1, 1),
        Text = l__Company__5.Levels[l__Page__6],
        TextColor3 = Color3.new(1, 1, 1)
    }, {
        Gradient = u2.createElement("UIGradient", {
            Rotation = 90,
            Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
        })
    })
});
    v80.Header = l__createElement__11(v81, v82, v84);
    return l__createElement__10(v77, v78, v80);
end;
return v20;