-- Services.InterfaceService.VoicelineInterface.VoicelineComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

game:GetService("LocalizationService");
local v1, u2 = shared.import("require", "Roact");
v1("InputService");
local v3 = u2.Component:extend("Voiceline");
local u4 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
function v3.init(_, _) --[[ Line: 10 ]] end;
function v3.render(p5) --[[ Line: 14 ]]
    -- upvalues: u2 (copy), u4 (copy)
    local v6 = {};
    for v7, v8 in p5.props.Lines do
        local l__Color__1 = v8.Color;
        v6[v7] = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            LayoutOrder = v7,
            Size = v8.Size:Map(function(p9) --[[ Line: 21 ]]
                return UDim2.fromScale(1, p9 * 0.022);
            end)
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                RichText = true,
                Size = UDim2.fromScale(1, 1),
                FontFace = u4,
                TextColor3 = Color3.new(1, 1, 1),
                TextStrokeColor3 = Color3.new(),
                TextStrokeTransparency = v8.Transparency:Map(function(p10) --[[ Line: 33 ]]
                    return p10 + 0.75;
                end),
                TextTransparency = v8.Transparency:Map(function(p11) --[[ Line: 36 ]]
                    return p11;
                end),
                Text = "<b><font color=\"rgb(" .. math.floor(l__Color__1.R * 255) .. "," .. math.floor(l__Color__1.G * 255) .. "," .. math.floor(l__Color__1.B * 255) .. ")\">" .. v8.Name .. ": </font></b>" .. v8.Line
            }) });
    end;
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(0.5, 1),
        Position = UDim2.fromScale(0.25, -0.1)
    }, {
        List = u2.createElement("UIListLayout", {
            SortOrder = Enum.SortOrder.LayoutOrder,
            VerticalAlignment = Enum.VerticalAlignment.Bottom
        }),
        u2.createFragment(v6)
    });
end;
return v3;