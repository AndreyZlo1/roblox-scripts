-- Services.InterfaceService.ControlInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "Enum");
local u4 = v1("GameShellProxyService");
local u5 = v1("InputService");
local u6 = v1("ControlComponent");
local l__UserInputService__1 = game:GetService("UserInputService");
local u7 = {};
u7.__index = u7;
function u7._update(p8) --[[ Line: 20 ]]
    -- upvalues: u2 (copy), u6 (copy)
    p8._handle = u2.update(p8._handle, u2.createElement(u6, {
        Enabled = p8._enabled,
        Binds = p8._binds,
        Gamepad = p8._gamepad,
        Touch = p8._touch
    }));
end;
function u7._input(p9, p10, p11) --[[ Line: 29 ]]
    -- upvalues: u3 (copy)
    local l___gamepad__2 = p9._gamepad;
    for _, v12 in p9._binds do
        if l___gamepad__2 then
            if v12.Gamepad == p10.KeyCode then
                v12.Down = p11;
            end;
        elseif v12.Key.EnumType == u3.KeyCode then
            if v12.Key == p10.KeyCode then
                v12.Down = p11;
            end;
        elseif v12.Key == p10.UserInputType then
            v12.Down = p11;
        end;
    end;
    p9:_update();
end;
function u7.new() --[[ Line: 47 ]]
    -- upvalues: u4 (copy), u3 (copy), u5 (copy), u2 (copy), u6 (copy), u7 (copy), l__UserInputService__1 (copy)
    local v13 = u4:CreateProxy(7, u3.ShellPriority.Default, "ControlInterface");
    local v14 = 0;
    local v15 = {};
    for v16 in u5.Binds do
        for v17, v18 in v16 do
            v15[v17] = {
                Down = false,
                Key = v18.Key,
                Gamepad = v18.Gamepad,
                Description = v18.Description,
                VisibleOnKeyboard = v18.VisibleOnKeyboard,
                VisibleOnGamepad = v18.VisibleOnGamepad,
                TouchButton = v18.TouchButton,
                Order = v14
            };
            v14 = v14 + 1;
        end;
    end;
    local v19 = {
        _enabled = false,
        _handle = u2.mount(u2.createElement(u6, {
            Enabled = false,
            Binds = v15,
            Gamepad = u5.Gamepad,
            Touch = u5.Touch
        }), v13),
        _order = v14,
        _touch = u5.Touch,
        _gamepad = u5.Gamepad,
        _binds = v15
    };
    local u20 = setmetatable(v19, u7);
    l__UserInputService__1.InputBegan:Connect(function(p21, p22) --[[ Line: 83 ]]
        -- upvalues: u20 (copy)
        if p22 then
        else
            u20:_input(p21, true);
        end;
    end);
    l__UserInputService__1.InputEnded:Connect(function(p23) --[[ Line: 90 ]]
        -- upvalues: u20 (copy)
        u20:_input(p23, false);
    end);
    u5.Connected:Connect(function(p24) --[[ Line: 94 ]]
        -- upvalues: u20 (copy)
        for v25, v26 in p24 do
            u20._binds[v25] = {
                Down = false,
                Key = v26.Key,
                Gamepad = v26.Gamepad,
                Description = v26.Description,
                VisibleOnKeyboard = v26.VisibleOnKeyboard,
                VisibleOnGamepad = v26.VisibleOnGamepad,
                TouchButton = v26.TouchButton,
                Order = u20._order
            };
            local v27 = u20;
            v27._order = v27._order + 1;
        end;
        u20:_update();
    end);
    u5.Disconnected:Connect(function(p28) --[[ Line: 111 ]]
        -- upvalues: u20 (copy)
        for v29 in p28 do
            u20._binds[v29] = nil;
        end;
        u20:_update();
    end);
    u5.GamepadInput:Connect(function(p30) --[[ Line: 118 ]]
        -- upvalues: u20 (copy)
        u20._gamepad = p30;
        u20:_update();
    end);
    u5.TouchInput:Connect(function(p31) --[[ Line: 123 ]]
        -- upvalues: u20 (copy)
        u20._touch = p31;
        u20:_update();
    end);
    return u20;
end;
function u7.Update(p32) --[[ Line: 131 ]]
    -- upvalues: u5 (copy)
    local v33 = not (u5.PauseOpen or u5.MenuOpen);
    if v33 == p32._enabled then
    else
        p32._enabled = v33;
        p32:_update();
    end;
end;
return u7.new();