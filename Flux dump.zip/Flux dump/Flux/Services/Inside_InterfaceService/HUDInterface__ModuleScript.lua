-- Services.InterfaceService.HUDInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4, u5 = shared.import("require", "signal", "Roact", "Enum", "network");
local u6 = v1("GameShellProxyService");
local u7 = v1("EnvironmentService");
local u8 = v1("ReplicatorService");
local u9 = v1("ClientService");
local u10 = v1("HUDComponent");
local u11 = v1("SoundService");
local u12 = v1("RoactTween");
local l__HttpService__1 = game:GetService("HttpService");
local l__Lighting__2 = game:GetService("Lighting");
local l__Players__3 = game:GetService("Players");
local l__TextService__4 = game:GetService("TextService");
local l__LocalPlayer__5 = l__Players__3.LocalPlayer;
local l__CurrentCamera__6 = workspace.CurrentCamera;
local u13 = Font.fromId(12187375422, u4.FontWeight.Bold, u4.FontStyle.Normal);
Font.fromId(12187375422, u4.FontWeight.Regular, u4.FontStyle.Normal);
local u14 = {};
u14.__index = u14;
function u14._update(p15) --[[ Line: 28 ]]
    -- upvalues: u3 (copy), u10 (copy)
    p15._handle = u3.update(p15._handle, u3.createElement(u10, {
        Inventories = p15._inventories,
        Weapon = p15._weapon,
        Bumped = p15._bumped,
        Round = p15._round,
        RoundWin = p15._roundWin,
        Objective = p15._objective,
        Killfeed = p15._killfeed,
        DeathScreen = p15._deathScreen,
        Spectating = p15._spectating,
        Compound = p15._compound,
        Quest = p15._quest,
        Watch = p15._watch,
        PlayerInfoVisible = p15._playerInfoVisible
    }));
end;
function u14.new() --[[ Line: 46 ]]
    -- upvalues: u6 (copy), u4 (copy), u3 (copy), u12 (copy), u2 (copy), u14 (copy), u10 (copy), u5 (copy), u11 (copy), u9 (copy), l__LocalPlayer__5 (copy), l__CurrentCamera__6 (copy), u13 (copy), l__TextService__4 (copy), l__HttpService__1 (copy)
    local v16 = u6:CreateProxy(4, u4.ShellPriority.Default, "HUDInterface");
    local v17, v18 = u3.createBinding(0);
    local v19, v20 = u3.createBinding(0);
    local v21, v22 = u3.createBinding(1);
    local v23, v24 = u3.createBinding(nil);
    local v25, v26 = u3.createBinding(nil);
    local v27, v28 = u3.createBinding(0);
    local v29, v30 = u3.createBinding();
    local v31, v32 = u3.createBinding(0);
    local v33, v34 = u3.createBinding("0 - 0");
    local v35, v36 = u3.createBinding(nil);
    local v37, v38 = u3.createBinding(0);
    local v39, v40 = u3.createBinding(false);
    local v41, v42 = u3.createBinding(nil);
    local v43, v44 = u3.createBinding(0);
    local v45, v46 = u3.createBinding(0);
    local v47, v48 = u3.createBinding("");
    local v49, v50 = u3.createBinding(0);
    local u51 = u12.new(0, TweenInfo.new(3, u4.EasingStyle.Exponential, u4.EasingDirection.Out, 0, false, 0));
    local u52 = u2.new();
    local v53 = {
        ImmortalExpire = 0,
        _playerInfoVisible = true,
        _spectating = false,
        _objective = false,
        _round = false,
        _deathScreen = "",
        _bumped = true,
        _killfeedCount = 0,
        Capturing = {},
        UpdateStamina = v18,
        UpdateBleeding = v40,
        UpdateCompass = v30,
        _updateSmoke = v48,
        _updateHealth = v20,
        _updateDowned = v22,
        _updateDragged = v24,
        _updateCQB = v42,
        _updateZero = v26,
        _updateCounter = v28,
        _updateRoundTimer = v32,
        _updateRoundScore = v34,
        _updateRoundObjective = v38,
        _updateWatch = v36,
        _updateImmortal = v46,
        _updateCombat = v44,
        _updateCapturing = v50,
        _inventories = {},
        _bump = tick(),
        _watch = v35,
        _deathScreenTween = u51,
        _killfeed = {}
    };
    local u54 = setmetatable(v53, u14);
    u54._handle = u3.mount(u3.createElement(u10, {
        AddEXP = u52,
        Inventories = u54._inventories,
        Weapon = u54._weapon,
        Bumped = u54._bumped,
        Killfeed = u54._killfeed,
        Round = u54._round,
        RoundTimer = v31,
        RoundScore = v33,
        RoundObjective = v37,
        DeathScreenTween = u51,
        DeathScreen = u54._deathScreen,
        Spectating = u54._spectating,
        Objective = u54._objective,
        Counter = v27,
        CQB = v41,
        Zero = v25,
        Health = v19,
        Downed = v21,
        Dragged = v23,
        Compass = v29,
        Stamina = v17,
        Bleeding = v39,
        Combat = v43,
        Immortal = v45,
        Watch = v35,
        Smoke = v47,
        Capturing = v49
    }), v16);
    u5:ConnectEvents({
        AddEXP = function(...) --[[ Name: AddEXP, Line 142 ]]
            -- upvalues: u52 (copy)
            u52:Fire(...);
        end,
        ShowRound = function(p55) --[[ Name: ShowRound, Line 145 ]]
            -- upvalues: u54 (copy)
            u54._round = p55;
            u54:_update();
        end,
        UpdateCounter = function(p56) --[[ Name: UpdateCounter, Line 149 ]]
            -- upvalues: u54 (copy)
            u54._counter = p56;
        end,
        DeathScreen = function(p57) --[[ Name: DeathScreen, Line 152 ]]
            -- upvalues: u51 (copy), u54 (copy), u11 (ref)
            if p57 then
                u51:SetGoal(1);
                u54._deathScreen = p57;
            else
                u51:SetGoal(0);
            end;
            u11:CreateSound("Button", nil, true, "UISounds", p57 and "DeathStinger" or "DeathTransition").Destroy(5);
            u54:_update();
        end,
        ImmortalExpire = function(p58) --[[ Name: ImmortalExpire, Line 163 ]]
            -- upvalues: u54 (copy)
            u54.ImmortalExpire = p58;
        end,
        CombatExpire = function(p59) --[[ Name: CombatExpire, Line 166 ]]
            -- upvalues: u54 (copy)
            u54.CombatExpire = p59;
        end,
        EndRound = function(p60, p61, p62, p63) --[[ Name: EndRound, Line 169 ]]
            -- upvalues: u9 (ref), l__LocalPlayer__5 (ref), u54 (copy)
            if p60 then
                local l__Squad__7 = u9.Clients[l__LocalPlayer__5].Squad;
                local v64 = p60 .. " wins";
                if not p62 then
                    p60 = p60 == "Tie" and "Match Tied" or (l__Squad__7 and (l__Squad__7 == "Red" and p60 == "Red" and "Round won" or (l__Squad__7 == "Blue" and p60 == "Blue" and "Round won" or "Round lost")) or v64);
                end;
                u54._roundWin = {
                    p60,
                    p61,
                    p62,
                    p63
                };
            else
                u54._roundWin = nil;
            end;
            u54:_update();
        end,
        UpdateCompound = function(p65, p66, p67, p68, p69, p70, p71, p72, p73, p74, p75, p76, p77, p78) --[[ Name: UpdateCompound, Line 192 ]]
            -- upvalues: u54 (copy)
            if p66 then
                if p67 then
                    if not u54._compound or (u54._compound.Name == p65 or p66 < u54._compound.Distance) then
                        u54._compound = {
                            Name = p65,
                            Distance = p66,
                            Title = p68,
                            Sub = p69,
                            Waves = p70,
                            Progress = p71,
                            Loud = p72,
                            Defeated = p73,
                            Objectives = p74,
                            MakeKnown = p75,
                            Fear = p76,
                            FriendlyCount = p77,
                            EnemyCount = p78
                        };
                    end;
                elseif not u54._quest or u54._quest.Name == p65 then
                    u54._quest = {
                        Name = p65,
                        Title = p68,
                        Sub = p69,
                        Waves = p70,
                        Progress = p71,
                        Loud = p72,
                        Defeated = p73,
                        Objectives = p74,
                        MakeKnown = p75,
                        Fear = p76,
                        FriendlyCount = p77,
                        EnemyCount = p78
                    };
                end;
            else
                if u54._compound and u54._compound.Name == p65 then
                    u54._compound = nil;
                end;
                if u54._quest and u54._quest.Name == p65 then
                    u54._quest = nil;
                end;
            end;
            u54:_update();
        end,
        UpdateObjective = function(p79, p80, p81) --[[ Name: UpdateObjective, Line 240 ]]
            -- upvalues: u54 (copy)
            if p80 and p81 then
                u54._objectiveStart = p81;
                u54._objectiveEnd = p80;
            else
                u54._objectiveEnd = nil;
            end;
            u54._objective = p79;
            u54:_update();
        end,
        UpdateRound = function(p82, p83, p84) --[[ Name: UpdateRound, Line 250 ]]
            -- upvalues: u54 (copy), u9 (ref), l__LocalPlayer__5 (ref)
            local v85 = p83 .. " - " .. p84;
            if typeof(u54._round) == "boolean" then
                local v86 = u9.Clients[l__LocalPlayer__5];
                if not v86 then
                    return;
                end;
                local v87 = v86.Squad == "Blue";
                v85 = ("<font color=\"rgb(52,133,255)\" " .. (v87 and "weight=\"bold\"" or "") .. ">" .. p83 .. "</font>") .. " " .. (v87 and "←" or "→") .. " " .. "<font color=\"rgb(255,10,14)\" " .. (v87 and "" or "weight=\"bold\"") .. ">" .. p84 .. "</font>";
            end;
            u54._updateRoundScore(v85);
            u54.RedWins = p84;
            u54.BlueWins = p83;
            u54._timer = p82;
        end,
        UpdateKillfeed = function(p88, p89, p90, p91) --[[ Name: UpdateKillfeed, Line 270 ]]
            -- upvalues: l__CurrentCamera__6 (ref), u13 (ref), l__TextService__4 (ref), u12 (ref), l__HttpService__1 (ref), u54 (copy), u3 (ref), u4 (ref)
            local v92 = p91:upper();
            local l__Y__8 = l__CurrentCamera__6.ViewportSize.Y;
            local v93 = math.floor(l__Y__8 * 0.02 * 0.8);
            local v94 = Instance.new("GetTextBoundsParams");
            v94.Text = p89[1]:upper();
            v94.Font = u13;
            v94.Size = math.floor(v93);
            v94.Width = (1 / 0);
            local v95 = l__TextService__4:GetTextBoundsAsync(v94).X + v93;
            local v96 = 0 + v95;
            local v97;
            if p90 then
                v94.Text = p90[1]:upper();
                v97 = l__TextService__4:GetTextBoundsAsync(v94).X + v93;
                v96 = v96 + v97 + v93;
            else
                v97 = 0;
            end;
            v94.Text = p88[1]:upper();
            local v98 = l__TextService__4:GetTextBoundsAsync(v94).X + v93;
            local v99 = v96 + v98;
            local v100 = math.floor(l__Y__8 * 0.02);
            v94.Size = math.floor(v100);
            v94.Text = v92;
            local v101 = l__TextService__4:GetTextBoundsAsync(v94).X + v93 * 2;
            local v102 = v99 + v101;
            local v103 = u12.new(1);
            local u104 = l__HttpService__1:GenerateGUID(false);
            local l___killfeed__9 = u54._killfeed;
            local l__createElement__10 = u3.createElement;
            local v105 = "Frame";
            local v106 = {
                BorderSizePixel = 0,
                BackgroundTransparency = 1,
                Size = UDim2.new(v102 / (l__Y__8 * 1.778), 0, 0.1, 0),
                LayoutOrder = -u54._killfeedCount
            };
            local v107 = {};
            local l__createElement__11 = u3.createElement;
            local v108 = "Frame";
            local v110 = {
                BorderSizePixel = 0,
                BackgroundTransparency = 1,
                Position = v103:Map(function(p109) --[[ Line: 315 ]]
                    return UDim2.fromScale(p109, 0);
                end),
                Size = UDim2.new(1, 0, 1, 0)
            };
            local v111 = {};
            local v112 = u3.createElement("ImageLabel", {
                Image = "rbxassetid://13867926930",
                BorderSizePixel = 0,
                ZIndex = 2,
                TileSize = UDim2.fromOffset(64, 64),
                ScaleType = u4.ScaleType.Tile,
                ImageColor3 = p89[2]:Lerp(Color3.new(), 0.2),
                Size = UDim2.new(v95 / v102, 0, 1, 0)
            }, {
                Corner = u3.createElement("UICorner", {
                    CornerRadius = UDim.new(0, 1)
                }),
                Gradient = u3.createElement("UIGradient", {
                    Rotation = -90,
                    Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(112, 112, 112)), ColorSequenceKeypoint.new(1, Color3.fromRGB(54, 54, 54)) })
                }),
                Stroke = u3.createElement("UIStroke", {
                    Thickness = 1,
                    ApplyStrokeMode = u4.ApplyStrokeMode.Contextual,
                    Color = p89[2],
                    LineJoinMode = u4.LineJoinMode.Round
                }),
                Name = u3.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AutoLocalize = false,
                    Position = UDim2.new(0, 0, 0.1, 0),
                    Size = UDim2.new(1, 0, 0.8, 0),
                    FontFace = u13,
                    Text = p89[1]:upper(),
                    TextColor3 = p89[2],
                    TextXAlignment = u4.TextXAlignment.Center
                })
            });
            local v113 = u3.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                TextTransparency = 0.2,
                AutoLocalize = false,
                Size = UDim2.new(v101 / v102, 0, 1, 0),
                Position = UDim2.new((v95 + v97 + (p90 and v93 and v93 or 0)) / v102, 0, 0.1, 0),
                FontFace = u13,
                Text = v92,
                TextColor3 = Color3.new(0, 0, 0),
                TextXAlignment = u4.TextXAlignment.Center
            }, {
                White = u3.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextTransparency = 0.1,
                    TextScaled = true,
                    AutoLocalize = false,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.new(0, 0, 0, -1),
                    Size = UDim2.new(1, 0, 1, 0),
                    FontFace = u13,
                    Text = v92,
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u4.TextXAlignment.Center
                })
            });
            local v114 = u3.createElement("ImageLabel", {
                Image = "rbxassetid://13867926930",
                BorderSizePixel = 0,
                ZIndex = 2,
                TileSize = UDim2.fromOffset(64, 64),
                ScaleType = u4.ScaleType.Tile,
                ImageColor3 = p88[2],
                Size = UDim2.new(v98 / v102, 0, 1, 0),
                Position = UDim2.new(1, 0, 0, 0),
                AnchorPoint = Vector2.new(1, 0)
            }, {
                Corner = u3.createElement("UICorner", {
                    CornerRadius = UDim.new(0, 1)
                }),
                Gradient = u3.createElement("UIGradient", {
                    Rotation = -90,
                    Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(112, 112, 112)), ColorSequenceKeypoint.new(1, Color3.fromRGB(54, 54, 54)) })
                }),
                Stroke = u3.createElement("UIStroke", {
                    Thickness = 1,
                    ApplyStrokeMode = u4.ApplyStrokeMode.Contextual,
                    Color = p88[2],
                    LineJoinMode = u4.LineJoinMode.Round
                }),
                Name = u3.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AutoLocalize = false,
                    Position = UDim2.new(0, 0, 0.1, 0),
                    Size = UDim2.new(1, 0, 0.8, 0),
                    FontFace = u13,
                    Text = p88[1]:upper(),
                    TextColor3 = p88[2],
                    TextXAlignment = u4.TextXAlignment.Center
                })
            });
            local v115;
            if p90 then
                v115 = u3.createElement("ImageLabel", {
                    Image = "rbxassetid://13867926930",
                    BorderSizePixel = 0,
                    ZIndex = 2,
                    TileSize = UDim2.fromOffset(64, 64),
                    ScaleType = u4.ScaleType.Tile,
                    ImageColor3 = p90[2],
                    Position = UDim2.fromScale((v95 + v93) / v102),
                    Size = UDim2.new(v97 / v102, 0, 1, 0)
                }, {
                    Corner = u3.createElement("UICorner", {
                        CornerRadius = UDim.new(0, 1)
                    }),
                    Gradient = u3.createElement("UIGradient", {
                        Rotation = -90,
                        Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(112, 112, 112)), ColorSequenceKeypoint.new(1, Color3.fromRGB(54, 54, 54)) })
                    }),
                    Stroke = u3.createElement("UIStroke", {
                        Thickness = 1,
                        ApplyStrokeMode = u4.ApplyStrokeMode.Contextual,
                        Color = p90[2],
                        LineJoinMode = u4.LineJoinMode.Round
                    }),
                    Name = u3.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        AutoLocalize = false,
                        Position = UDim2.new(0, 0, 0.1, 0),
                        Size = UDim2.new(1, 0, 0.8, 0),
                        FontFace = u13,
                        Text = p90[1]:upper(),
                        TextColor3 = p90[2],
                        TextXAlignment = u4.TextXAlignment.Center
                    })
                });
            else
                v115 = p90;
            end;
            if p90 then
                p90 = u3.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundColor3 = p90[2],
                    Position = UDim2.new(v95 / v102, 0, 0.5, 0),
                    Size = UDim2.new(v93 / v102, 0, 0, 1),
                    AnchorPoint = Vector2.new(0, 0.5)
                });
            end;
            v111[1], v111[2], v111[3], v111[4], v111[5] = v112, v113, v114, v115, p90;
            v107[1] = l__createElement__11(v108, v110, v111);
            l___killfeed__9[u104] = l__createElement__10(v105, v106, v107);
            local v116 = u54;
            v116._killfeedCount = v116._killfeedCount + 1;
            u54:_update();
            v103:SetGoal(0);
            task.delay(5, v103.SetGoal, v103, 1.1);
            task.delay(6, function() --[[ Line: 476 ]]
                -- upvalues: u54 (ref), u104 (copy)
                u54._killfeed[u104] = nil;
                u54:_update();
            end);
        end
    });
    return u54;
end;
function u14.UpdateSpectating(p117, p118) --[[ Line: 486 ]]
    p117._spectating = p118;
    p117:_update();
end;
function u14.UpdateInventories(p119, p120) --[[ Line: 491 ]]
    p119._inventories = p120;
    p119._bumped = true;
    p119._bump = tick();
    p119:_update();
end;
function u14.UpdateWeapon(p121, p122) --[[ Line: 498 ]]
    p121._weapon = p122;
    p121:_update();
end;
function u14.UpdateZero(p123, p124) --[[ Line: 503 ]]
    p123._updateZero(p124);
    p123._expireZero = tick() + 2;
end;
function u14.Bump(p125) --[[ Line: 508 ]]
    p125._bump = tick();
    if not p125._bumped then
        p125._bumped = true;
        p125:_update();
    end;
end;
function u14.SetPlayerInfoVisible(p126, p127) --[[ Line: 516 ]]
    p126._playerInfoVisible = p127;
    p126:_update();
end;
function u14.Update(p128, p129) --[[ Line: 521 ]]
    -- upvalues: u8 (copy), u11 (copy), l__Lighting__2 (copy), u7 (copy)
    local l__LocalActor__12 = u8.LocalActor;
    if l__LocalActor__12 and l__LocalActor__12.Alive then
        if l__LocalActor__12.Downed then
            p128._updateHealth(0);
            p128._updateDowned(l__LocalActor__12.Health);
            local v130;
            if l__LocalActor__12.CurrentState.Dragged then
                local v131 = u8.Actors[l__LocalActor__12.CurrentState.Dragged];
                v130 = not (v131 and v131.Owner) and "A Teammate" or v131.Owner.Name;
            else
                v130 = nil;
            end;
            p128._updateDragged(v130);
        else
            p128._updateHealth(l__LocalActor__12.Health / 100);
            p128._updateDowned(1);
        end;
        if p128._lastHealth and p128._lastHealth > l__LocalActor__12.Health then
            u11:CancelMusic();
        end;
        p128._lastHealth = l__LocalActor__12.Health;
        p128._updateCQB(l__LocalActor__12.CQB);
    else
        u11:CancelMusic();
        p128._updateHealth(1);
    end;
    local v132;
    if l__LocalActor__12 and l__LocalActor__12.Wrist then
        v132 = l__Lighting__2.TimeOfDay:sub(1, 5);
    else
        v132 = nil;
    end;
    p128._updateWatch(v132);
    local v133 = workspace:GetServerTimeNow();
    if p128.CombatExpire and v133 < p128.CombatExpire then
        p128._inCombat = true;
        p128._updateCombat(p128.CombatExpire - v133);
    elseif p128._inCombat then
        p128._inCombat = false;
        p128._updateCombat(0);
    end;
    local l__ImmortalExpire__13 = p128.ImmortalExpire;
    if l__ImmortalExpire__13 == true or v133 < l__ImmortalExpire__13 then
        p128._immortal = true;
        p128._updateImmortal(l__ImmortalExpire__13 == true and true or l__ImmortalExpire__13 - v133);
    elseif p128._immortal then
        p128._immortal = false;
        p128._updateImmortal(0);
    end;
    p128._updateSmoke(u7.SmokeText or "");
    u11.DiegeticMix.Death = 1 - p128._deathScreenTween:GetValue();
    if p128._counter then
        if v133 < p128._counter then
            p128._updateCounter(p128._counter - v133);
        else
            p128._counter = nil;
            p128._updateCounter(0);
        end;
    end;
    if p128._expireZero and tick() > p128._expireZero then
        p128._updateZero(nil);
        p128._expireZero = nil;
    end;
    if p128._timer then
        if v133 < p128._timer then
            p128._updateRoundTimer(p128._timer - v133);
        else
            p128._timer = nil;
            p128._updateRoundTimer(0);
        end;
    end;
    if p128._objectiveEnd then
        p128._objectiveEnd = p128._objectiveEnd - p129;
        p128._updateRoundObjective((math.clamp(1 - p128._objectiveEnd / p128._objectiveStart, 0, 1)));
    end;
    local v134 = 0;
    for _, v135 in p128.Capturing do
        v134 = math.max(v134, v135);
    end;
    p128._updateCapturing(v134);
    if tick() - p128._bump > 3 and p128._bumped then
        p128._bumped = false;
        p128:_update();
    end;
end;
return u14.new();