-- Services.InterfaceService.CursorInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Enum", "Roact");
local l__UserInputService__1 = game:GetService("UserInputService");
local l__RunService__2 = game:GetService("RunService");
local u4 = v1("ViewmodelService");
local u5 = v1("CursorComponent");
v1("LandingInterface");
local u6 = v1("RealmInterface");
local u7 = v1("InputService");
local u8 = v1("PopupInterface");
local u9 = v1("HQManagerInterface");
local u10 = v1("GameShellProxyService");
local u11 = v1("RGEService");
local u12 = v1("LandingInterface");
local l__CurrentCamera__3 = workspace.CurrentCamera;
local u13 = {};
u13.__index = u13;
function u13._update(p14) --[[ Line: 26 ]]
    -- upvalues: u3 (copy), u5 (copy)
    p14._handle = u3.update(p14._handle, u3.createElement(u5, {
        CursorType = p14._cursorType
    }));
end;
function u13.new() --[[ Line: 32 ]]
    -- upvalues: u3 (copy), u10 (copy), u2 (copy), u5 (copy), u7 (copy), u13 (copy), l__RunService__2 (copy)
    local v15, v16 = u3.createBinding(0);
    local v17, v18 = u3.createBinding(0);
    local v19, v20 = u3.createBinding(nil);
    local v21 = u10:CreateProxy(11, u2.ShellPriority.Default, "CursorInterface");
    local v22 = {
        _cursorType = u2.CursorType.None,
        _handle = u3.mount(u3.createElement(u5, {
            CrosshairBinding = v15,
            CrosshairTransparencyBinding = v17,
            CursorType = u2.CursorType.None,
            VirtualCursor = u7.VirtualCursorBinding,
            BlockedPositionBinding = v19
        }), v21),
        _updateCrosshair = v16,
        _updateCrosshairTransparency = v18,
        _updateBlockedPositionBinding = v20
    };
    local v23 = setmetatable(v22, u13);
    if l__RunService__2:IsStudio() then
        v23._studioMouse = true;
    end;
    return v23;
end;
function u13.SetBlockedPosition(_, _) --[[ Line: 59 ]] end;
function u13.Update(p24, _) --[[ Line: 63 ]]
    -- upvalues: u2 (copy), u4 (copy), u7 (copy), u12 (copy), u6 (copy), u8 (copy), u9 (copy), l__UserInputService__1 (copy), l__CurrentCamera__3 (copy), u11 (copy), u10 (copy)
    local l__None__4 = u2.CursorType.None;
    local l__Viewmodel__5 = u4.Viewmodel;
    if not u7.RadialOpen and (l__Viewmodel__5 and (l__Viewmodel__5.CurrentModel and not (u7.OverlayOpen or u7.RoundOpen))) then
        local l__Position__6 = l__Viewmodel__5.Recoil.Spring.Position;
        local v25 = 1 - l__Viewmodel__5.SprintLerp;
        local l__ADSLerp__7 = l__Viewmodel__5.ADSLerp;
        local v26 = 1 - u12.TransparencyTween:GetValue();
        local v27 = math.max(v25, l__ADSLerp__7, v26);
        local v28 = not l__Viewmodel__5.Active and 0 or v27;
        p24._updateCrosshair((1 - v27) * (20 + l__Position__6.Y * 200));
        p24._updateCrosshairTransparency(v28);
        l__None__4 = u2.CursorType.Crosshair;
    end;
    if (u7.PauseOpen or (u7.MenuOpen or (u7.TabletOpen or (u7.InventoryOpen or (u7.DebugOpen or (u6.CursorEnabled:getValue() or (u8.PopupOpen or u9.Open))))))) and not u12.Enabled then
        l__None__4 = u2.CursorType.Pointer;
    end;
    if p24._studioMouse and l__UserInputService__1:IsKeyDown(u2.KeyCode.LeftControl) then
        l__None__4 = u2.CursorType.Pointer;
    end;
    if p24._blockedPosition then
        p24._updateBlockedPositionBinding(l__CurrentCamera__3:WorldToViewportPoint(p24._blockedPosition));
    else
        p24._updateBlockedPositionBinding(false);
    end;
    local v29 = nil;
    if u11.Enabled then
        if u11.Fullscreen then
            l__None__4 = u2.CursorType.None;
        else
            local l__Resize__8 = u11.Resize;
            v29 = l__Resize__8 == "B" and "rbxassetid://116174647717667" or ((l__Resize__8 == "L" or l__Resize__8 == "R") and "rbxassetid://130828232195531" or ((u11.Hover or u10.Hovering) and "rbxassetid://136098032080425" or "rbxassetid://124399064680566"));
            l__None__4 = u2.CursorType.Pointer;
        end;
    end;
    if l__None__4 ~= p24._cursorType then
        p24._cursorType = l__None__4;
        p24:_update();
    end;
    l__UserInputService__1.MouseIcon = v29 or (u10.Hovering and "rbxassetid://13856000720" or "rbxassetid://13856000545");
    local v30 = l__UserInputService__1;
    local v31 = not u7.Gamepad;
    if v31 then
        v31 = l__None__4 == u2.CursorType.Pointer;
    end;
    v30.MouseIconEnabled = v31;
    l__UserInputService__1.MouseBehavior = l__None__4 == u2.CursorType.Pointer and u2.MouseBehavior.Default or u2.MouseBehavior.LockCenter;
end;
return u13.new();