-- Services.InterfaceService.PopupInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4, u5 = shared.import("require", "Roact", "Enum", "signal", "network");
local l__UserInputService__1 = game:GetService("UserInputService");
local l__TweenService__2 = game:GetService("TweenService");
local l__RunService__3 = game:GetService("RunService");
local u6 = v1("GameShellProxyService");
local u7 = v1("SoundService");
local u8 = v1("StatsService");
local u9 = v1("RoactTween");
local u10 = v1("PopupComponent");
local u11 = v1("formatNumber");
local u12 = {};
u12.__index = u12;
local function u22(p13) --[[ Line: 29 ]]
    -- upvalues: u3 (copy), u11 (copy)
    local v14 = Instance.new("Frame");
    v14.BackgroundTransparency = 1;
    v14.AnchorPoint = Vector2.new(0.5, 0.5);
    v14.Size = UDim2.fromScale(0.1, 0.1);
    v14.SizeConstraint = u3.SizeConstraint.RelativeYY;
    v14.ZIndex = 10;
    local v15 = Instance.new("TextLabel");
    v15.AnchorPoint = Vector2.new(0, 0.5);
    v15.BackgroundTransparency = 1;
    v15.FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal);
    v15.Position = UDim2.fromScale(1.1, 0.5);
    v15.Size = UDim2.fromScale(10, 0.8);
    v15.Text = u11(p13):sub(2);
    v15.TextColor3 = Color3.new(1, 1, 1);
    v15.TextScaled = true;
    v15.TextXAlignment = u3.TextXAlignment.Left;
    v15.ZIndex = 2;
    v15.Parent = v14;
    local v16 = Instance.new("Frame");
    v16.AnchorPoint = Vector2.new(0.5, 0.5);
    v16.BackgroundTransparency = 1;
    v16.Position = UDim2.fromScale(0.5, 0.5);
    v16.Size = UDim2.fromScale(0.7, 0.7);
    local v17 = Instance.new("Frame");
    v17.AnchorPoint = Vector2.new(1, 0);
    v17.BackgroundTransparency = 1;
    v17.Position = UDim2.fromScale(1, 0);
    v17.Size = UDim2.fromScale(0.65, 0.65);
    local v18 = Instance.new("UIStroke");
    v18.Color = Color3.new(1, 1, 1);
    v18.LineJoinMode = u3.LineJoinMode.Miter;
    v18.Thickness = 1;
    v18.Parent = v17;
    v17.Parent = v16;
    local v19 = Instance.new("Frame");
    v19.AnchorPoint = Vector2.new(0, 1);
    v19.BackgroundColor3 = Color3.new(1, 1, 1);
    v19.BorderColor3 = Color3.new();
    v19.BorderSizePixel = 0;
    v19.Position = UDim2.fromScale(0, 1);
    v19.Size = UDim2.fromScale(0.65, 0.65);
    local v20 = Instance.new("UIGradient");
    v20.Rotation = -45;
    v20.Transparency = NumberSequence.new({
        NumberSequenceKeypoint.new(0, 0),
        NumberSequenceKeypoint.new(0.49536, 0),
        NumberSequenceKeypoint.new(0.50464, 1),
        NumberSequenceKeypoint.new(1, 1)
    });
    v20.Parent = v19;
    local v21 = Instance.new("UIStroke");
    v21.Color = Color3.new(1, 1, 1);
    v21.LineJoinMode = u3.LineJoinMode.Miter;
    v21.StrokeSizingMode = u3.StrokeSizingMode.ScaledSize;
    v21.Thickness = 0.05;
    v21.Parent = v19;
    v19.Parent = v16;
    v16.Parent = v14;
    return v14, {
        [v15] = "TextColor3",
        [v18] = "Color",
        [v19] = "BackgroundColor3",
        [v21] = "Color"
    };
end;
function u12._update(p23) --[[ Line: 110 ]]
    -- upvalues: u2 (copy), u10 (copy)
    p23._handle = u2.update(p23._handle, u2.createElement(u10, {
        Title = p23._title,
        Type = p23._type,
        Description = p23._description,
        Options = p23._options,
        Slides = p23._slides,
        FocusRef = p23._focusRef,
        CancelFocus = p23._cancelCallback
    }));
end;
function u12.DisplayCredits(u24, u25) --[[ Line: 122 ]]
    -- upvalues: u7 (copy), u8 (copy), u22 (copy), l__TweenService__2 (copy), u3 (copy)
    u7:CreateSound("Button", nil, true, "UISounds", "CreditPurchase").Destroy(10);
    u8.UpdateMoney(u8.Money - u25);
    local u26 = u25 >= 90000 and 5 or (u25 >= 20000 and 3 or (u25 >= 9000 and 2 or 1));
    local u27 = 0;
    local u28 = math.ceil(u25 / 100);
    task.spawn(function() --[[ Line: 137 ]]
        -- upvalues: u28 (copy), u27 (ref), u7 (ref), u22 (ref), u24 (copy), l__TweenService__2 (ref), u3 (ref), u8 (ref), u25 (copy), u26 (ref)
        for u29 = 1, u28 do
            local u30 = u27 == 0;
            if u30 then
                u7:CreateSound("Button", nil, true, "UISounds", "CreditSpawn").Destroy(2);
            end;
            local u31, v32 = u22(100);
            u31.Position = UDim2.fromScale(math.random(20, 80) / 100, math.random(20, 80) / 100);
            u31.Parent = u24.UI;
            for v33, v34 in v32 do
                l__TweenService__2:Create(v33, TweenInfo.new(0.1, u3.EasingStyle.Sine, u3.EasingDirection.Out, 0), {
                    [v34] = Color3.fromRGB(255, 205, 122)
                }):Play();
            end;
            l__TweenService__2:Create(u31, TweenInfo.new(0.1, u3.EasingStyle.Sine, u3.EasingDirection.Out, 0), {
                Size = UDim2.fromScale(0.025, 0.025)
            }):Play();
            task.delay(0.5, function() --[[ Line: 157 ]]
                -- upvalues: l__TweenService__2 (ref), u31 (copy), u3 (ref), u30 (copy), u7 (ref), u29 (copy), u28 (ref), u8 (ref), u25 (ref)
                l__TweenService__2:Create(u31, TweenInfo.new(0.4, u3.EasingStyle.Sine, u3.EasingDirection.In, 0), {
                    Position = UDim2.fromScale(1.1, -0.1)
                }):Play();
                task.wait(0.4);
                u31:Destroy();
                if u30 then
                    u7:CreateSound("Button", nil, true, "UISounds", "CreditCollect").Destroy(2);
                end;
                if u29 == u28 then
                    u8.UpdateMoney(u8.Money);
                else
                    u8.UpdateMoney(u8.Money - u25 + u29 * 100);
                end;
            end);
            u27 = u27 + 1;
            if u26 <= u27 then
                u27 = 0;
                task.wait(0.05);
            end;
        end;
    end);
end;
function u12.new() --[[ Line: 183 ]]
    -- upvalues: u9 (copy), u3 (copy), u2 (copy), u6 (copy), u4 (copy), u10 (copy), u12 (copy), u5 (copy), u11 (copy)
    local v35 = u9.new(0, TweenInfo.new(0.5, u3.EasingStyle.Exponential, u3.EasingDirection.Out, 0, false, 0));
    local v36 = u9.new(0, TweenInfo.new(0.5, u3.EasingStyle.Exponential, u3.EasingDirection.Out, 0, false, 0));
    local v37 = u9.new(0, TweenInfo.new(0.5, u3.EasingStyle.Exponential, u3.EasingDirection.Out, 0, false, 0));
    local v38, v39 = u2.createBinding(0);
    local v40 = u6:CreateProxy(20, u3.ShellPriority.AlwaysVisible, "PopupInterface");
    local v41 = {
        PopupOpen = false,
        _slideCount = 1,
        _focused = false,
        _popuped = false,
        UI = v40,
        PopupChanged = u4.new(),
        _handle = u2.mount(u2.createElement(u10, {
            LoadingTween = v35,
            OpenTween = v36,
            CircleTween = v38,
            FocusTween = v37,
            Options = {},
            Slides = {}
        }), v40),
        _updateCircle = v39,
        _slides = {},
        _options = {},
        _openTween = v36,
        _loadingTween = v35,
        _focusTween = v37
    };
    local u42 = setmetatable(v41, u12);
    u5:ConnectEvents({
        RefundNotice = function(u43) --[[ Name: RefundNotice, Line 217 ]]
            -- upvalues: u42 (copy), u11 (ref)
            u42:Open("ITEM REFUND", "Due to the amount of changes with the gun smith, we have had to refund all items from GEN3\n\nRemoved items will be re-added in the following days.", {
                { "View Merge", function() --[[ Line: 219 ]]
                        -- upvalues: u42 (ref), u11 (ref), u43 (copy)
                        local v44 = {
                            { "View Stars", function() --[[ Line: 221 ]]
                                    -- upvalues: u42 (ref), u43 (ref)
                                    u42:Open("STAR INFORMATION", "To further game progression, we have moved away from the stars system. We have adjusted your level based on your stars from GEN3.\n\nGEN3: " .. u43.Stars .. " STARS\nGEN4: Level " .. u43.Level, {
                                        { "Let\'s go", function() --[[ Line: 223 ]]
                                                -- upvalues: u42 (ref)
                                                u42:Close();
                                            end }
                                    });
                                end }
                        };
                        u42:Open("DATA MERGE", "GEN3: " .. u11(u43.StartMoney) .. "\nGEN4: " .. u11(u43.NowMoney) .. " (after refunds)\n\nVehicle refunds: " .. u11(u43.VehicleRefund) .. "\nGear refunds: " .. u11(u43.GearRefund), v44);
                    end }
            });
        end,
        PlayTutorial = function() --[[ Name: PlayTutorial, Line 232 ]]
            -- upvalues: u42 (copy), u5 (ref)
            u42:Open("Tutorial Mission", "Would you like to play the tutorial mission? It is recommended for all new players.\n\nYou can play at any time in the Missions page.", {
                { "Yes", function() --[[ Line: 234 ]]
                        -- upvalues: u5 (ref), u42 (ref)
                        u5:FireServer("JoinMission", "CM_Mission1");
                        u42:Close();
                    end },
                { "No", function() --[[ Line: 238 ]]
                        -- upvalues: u42 (ref)
                        u42:Close();
                    end }
            });
        end
    });
    return u42;
end;
function u12.Slide(u45, p46, p47, p48, p49) --[[ Line: 248 ]]
    -- upvalues: u9 (copy), u3 (copy), u2 (copy)
    local l___slideCount__4 = u45._slideCount;
    u45._slideCount = u45._slideCount + 1;
    local u50 = u9.new(0, TweenInfo.new(0.5, u3.EasingStyle.Exponential, u3.EasingDirection.Out, 0, false, 0));
    local v51, v52 = u2.createBinding(false);
    local u53 = false;
    local u54 = nil;
    u45._slides[l___slideCount__4] = {
        Title = p46,
        Description = p47,
        Options = p48,
        Tween = u50,
        Binding = v51,
        UpdateBinding = v52,
        Close = function() --[[ Name: Close, Line 263 ]]
            -- upvalues: u53 (ref), u50 (copy), u54 (ref), u45 (copy), l___slideCount__4 (copy)
            if u53 then
            else
                u53 = true;
                u50:SetGoal(0);
                task.cancel(u54);
                task.delay(1, function() --[[ Line: 271 ]]
                    -- upvalues: u45 (ref), l___slideCount__4 (ref)
                    u45._slides[l___slideCount__4] = nil;
                    u45:_update();
                end);
            end;
        end
    };
    u54 = task.delay(p49 or 5, function() --[[ Line: 278 ]]
        -- upvalues: u53 (ref), u50 (copy), u45 (copy), l___slideCount__4 (copy)
        u53 = true;
        u50:SetGoal(0);
        task.delay(1, function() --[[ Line: 282 ]]
            -- upvalues: u45 (ref), l___slideCount__4 (ref)
            u45._slides[l___slideCount__4] = nil;
            u45:_update();
        end);
    end);
    u45:_update();
    u50:SetGoal(1);
end;
function u12.Focus(u55, p56, u57) --[[ Line: 292 ]]
    -- upvalues: l__UserInputService__1 (copy), u3 (copy)
    if u55._focused and u55._focusRef == p56 then
    else
        u55._focused = true;
        u55:Close();
        u55.Input = l__UserInputService__1.InputBegan:Connect(function(p58) --[[ Line: 300 ]]
            -- upvalues: u3 (ref), u55 (copy), u57 (copy)
            if p58.KeyCode == u3.KeyCode.ButtonB then
                u55:Unfocus();
                u57();
            end;
        end);
        u55.PopupOpen = true;
        u55.PopupChanged:Fire(true);
        u55._focusRef = p56;
        u55._focusTween:SetGoal(1);
        function u55._cancelCallback() --[[ Line: 311 ]]
            -- upvalues: u55 (copy), u57 (copy)
            u55:Unfocus();
            u57();
        end;
        u55:_update();
    end;
end;
function u12.Unfocus(p59) --[[ Line: 318 ]]
    if p59._focused then
        p59._focused = false;
        p59.Input:Disconnect();
        p59.PopupOpen = false;
        p59.PopupChanged:Fire(false);
        p59._focusTween:SetGoal(0);
        p59:_update();
    end;
end;
function u12.SetLoading(u60, p61) --[[ Line: 332 ]]
    -- upvalues: l__RunService__3 (copy)
    u60._popuped = true;
    u60:Unfocus();
    u60.PopupOpen = p61;
    u60.PopupChanged:Fire(p61);
    u60._loadingTween:SetGoal(p61 and 1 or 0);
    if u60._loadingCircle then
        u60._loadingCircle:Disconnect();
        u60._loadingCircle = nil;
    end;
    if p61 then
        local u62 = 0;
        u60._loadingCircle = l__RunService__3.Heartbeat:Connect(function(p63) --[[ Line: 347 ]]
            -- upvalues: u62 (ref), u60 (copy)
            u62 = u62 + p63 * 300;
            u60._updateCircle(u62);
        end);
    end;
end;
function u12.Open(p64, p65, p66, p67, p68) --[[ Line: 354 ]]
    -- upvalues: u3 (copy)
    p64._popuped = true;
    p64:Unfocus();
    p64.PopupOpen = true;
    p64.PopupChanged:Fire(true);
    p64._openTween:SetGoal(1);
    p64._title = p65;
    p64._type = p68 or u3.PopupType.Default;
    p64._description = p66;
    p64._options = p67;
    p64:_update();
end;
function u12.Close(p69) --[[ Line: 368 ]]
    if p69._popuped then
        p69._type = nil;
        p69._popuped = false;
        p69.PopupOpen = false;
        p69.PopupChanged:Fire(false);
        p69._openTween:SetGoal(0);
        p69._options = {};
        p69:_update();
    end;
end;
return u12.new();