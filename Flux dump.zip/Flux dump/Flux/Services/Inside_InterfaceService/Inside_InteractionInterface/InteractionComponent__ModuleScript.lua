-- Services.InterfaceService.InteractionInterface.InteractionComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local l__TextService__1 = game:GetService("TextService");
local l__UserInputService__2 = game:GetService("UserInputService");
local u3 = v1("InputService");
local u4 = v1("GameShellProxyService");
v1("GameShellProxyButton");
local u5 = v1("TouchButtonComponent");
local v6 = u2.Component:extend("Interaction");
local u7 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
function v6.init(p8, p9) --[[ Line: 20 ]]
    p8.PromptProgress = p9.PromptProgress;
    p8.PositionBinding = p9.PositionBinding;
    p8.ShowTween = p9.ShowTween;
end;
function v6.render(p10) --[[ Line: 26 ]]
    -- upvalues: u2 (copy), u5 (copy), u3 (copy), u4 (copy), u7 (copy), l__TextService__1 (copy), l__UserInputService__2 (copy)
    local l__props__3 = p10.props;
    if l__props__3.Touch then
        local l__Visible__4 = l__props__3.Visible;
        if l__Visible__4 then
            l__Visible__4 = u2.createElement(u5, {
                Size = UDim2.fromScale(0.1, 0.1),
                Position = p10.PositionBinding,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Image = l__props__3.Icon,
                Up = function() --[[ Name: Up, Line 34 ]]
                    -- upvalues: u3 (ref)
                    u3:TouchBind("Interact", false);
                end,
                Down = function() --[[ Name: Down, Line 37 ]]
                    -- upvalues: u3 (ref)
                    u3:TouchBind("Interact", true);
                end
            });
        end;
        return l__Visible__4;
    end;
    local l__Y__5 = u4.ViewportSize.Y;
    local v11 = l__props__3.ActionText:upper();
    local v12 = Instance.new("GetTextBoundsParams");
    v12.Text = v11;
    v12.Font = u7;
    v12.Size = math.floor(l__Y__5 * 0.02 * 1);
    v12.Width = (1 / 0);
    local v13 = l__TextService__1:GetTextBoundsAsync(v12).X / l__Y__5 + 0.024;
    local v14, v15, v16;
    if l__props__3.Gamepad then
        v14 = 0.02;
        v15 = v13 + v14;
        local v17 = l__UserInputService__2:GetImageForKeyCode(l__props__3.Key.Raw);
        v16 = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(v14 / v15, 1),
            ImageColor3 = Color3.new(),
            Image = v17
        }, { u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(1, 1),
                Position = UDim2.fromOffset(0, -1),
                Image = v17
            }) });
    else
        local v18 = l__props__3.Key.Name:upper();
        local v19 = Instance.new("GetTextBoundsParams");
        v19.Text = v18;
        v19.Font = u7;
        v19.Size = math.floor(l__Y__5 * 0.02 * 1);
        v19.Width = (1 / 0);
        v14 = l__TextService__1:GetTextBoundsAsync(v19).X / l__Y__5 + 0.012;
        v15 = v13 + v14;
        local v20 = Color3.new(1, 1, 1);
        v16 = u2.createElement("ImageLabel", {
            Image = "rbxassetid://13867926930",
            BorderSizePixel = 0,
            TileSize = UDim2.fromOffset(64, 64),
            ScaleType = Enum.ScaleType.Tile,
            ImageColor3 = v20,
            Size = UDim2.fromScale(v14 / v15, 1)
        }, {
            Corner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 1)
            }),
            Gradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(112, 112, 112)), ColorSequenceKeypoint.new(1, Color3.fromRGB(54, 54, 54)) })
            }),
            Stroke = u2.createElement("UIStroke", {
                Thickness = 1,
                ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                Color = v20,
                LineJoinMode = Enum.LineJoinMode.Round
            }),
            Label = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.8),
                Position = UDim2.fromScale(0, 0.18),
                Text = v18,
                TextColor3 = v20,
                FontFace = u7
            }),
            Progress = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://91586039536034",
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.5),
                Size = UDim2.fromScale(4, 4),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                ImageColor3 = Color3.new(1, 1, 1),
                Visible = p10.PromptProgress:Map(function(p21) --[[ Line: 130 ]]
                    return p21 >= 0.05;
                end)
            }, {
                u2.createElement("UIGradient", {
                    Color = ColorSequence.new(Color3.new(1, 1, 1)),
                    Offset = Vector2.new(0, 0),
                    Rotation = p10.PromptProgress:Map(function(p22) --[[ Line: 137 ]]
                        return math.clamp(p22 * 2, 0, 1) * -180;
                    end),
                    Transparency = NumberSequence.new({
                        NumberSequenceKeypoint.new(0, 1),
                        NumberSequenceKeypoint.new(0.495, 1),
                        NumberSequenceKeypoint.new(0.505, 0),
                        NumberSequenceKeypoint.new(1, 0)
                    })
                }),
                Inside = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Rotation = 180,
                    Image = "rbxassetid://91586039536034",
                    ImageColor3 = Color3.new(1, 1, 1),
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.fromOffset(-2, 0),
                    Size = UDim2.fromScale(1, 1),
                    Visible = p10.PromptProgress:Map(function(p23) --[[ Line: 153 ]]
                        return p23 >= 0.5;
                    end)
                }, { u2.createElement("UIGradient", {
                        Color = ColorSequence.new(Color3.new(1, 1, 1)),
                        Offset = Vector2.new(0, 0),
                        Rotation = p10.PromptProgress:Map(function(p24) --[[ Line: 162 ]]
                            return math.clamp((p24 - 0.5) * 2, 0, 1) * -180;
                        end),
                        Transparency = NumberSequence.new({
                            NumberSequenceKeypoint.new(0, 1),
                            NumberSequenceKeypoint.new(0.495, 1),
                            NumberSequenceKeypoint.new(0.505, 0),
                            NumberSequenceKeypoint.new(1, 0)
                        })
                    }) })
            })
        });
    end;
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = p10.PositionBinding,
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        Size = UDim2.fromScale(v15, 0.02),
        Visible = l__props__3.Visible
    }, { u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(1, 1),
            Visible = p10.ShowTween:Map(function(p25) --[[ Line: 188 ]]
                return p25 > 0.5;
            end)
        }, { v16, u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(v13 / v15, 1),
                Position = UDim2.fromScale(v14 / v15, 0.1),
                Text = v11,
                FontFace = u7,
                Visible = p10.PromptProgress:Map(function(p26) --[[ Line: 200 ]]
                    return p26 < 0.05;
                end),
                TextColor3 = Color3.new(0, 0, 0)
            }, { u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    Size = UDim2.fromScale(1, 1),
                    Position = UDim2.fromOffset(0, -1),
                    Text = v11,
                    FontFace = u7,
                    TextColor3 = Color3.new(1, 1, 1)
                }) }) }), u2.createElement("Frame", {
            ZIndex = 2,
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            BackgroundColor3 = Color3.new(1, 1, 1),
            BackgroundTransparency = p10.ShowTween:Map(function(p27) --[[ Line: 222 ]]
                return math.clamp(p27 - 0.5, 0, 1) * 2;
            end),
            Size = p10.ShowTween:Map(function(p28) --[[ Line: 225 ]]
                return UDim2.new(math.clamp(p28 * 2, 0, 1), 2, 1, 2);
            end)
        }, { u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }) }) });
end;
return v6;