-- Services.InterfaceService.LandingInterface.LandingComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local u3 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u4 = v1("LogoComponent");
local v5 = u2.Component:extend("Landing");
function v5.init(p6, p7) --[[ Line: 9 ]]
    p6.TickBinding = p7.TickBinding;
    p6.LandingBinding = p7.LandingBinding;
    p6.MessageBinding = p7.MessageBinding;
    p6.TransparencyTween = p7.TransparencyTween;
end;
function v5.render(p8) --[[ Line: 16 ]]
    -- upvalues: u2 (copy), u3 (copy), u4 (copy)
    return u2.createFragment({
        Background = u2.createElement("Frame", {
            BackgroundTransparency = p8.TransparencyTween:Map(function(p9) --[[ Line: 19 ]]
                return p9;
            end),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = UDim2.fromScale(10, 10),
            BackgroundColor3 = Color3.new(0, 0, 0)
        }),
        Message = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            ZIndex = 2,
            AnchorPoint = Vector2.new(1, 0),
            Size = UDim2.fromScale(1, 0.015),
            Position = UDim2.fromScale(0.95, 0.92),
            TextXAlignment = Enum.TextXAlignment.Right,
            Text = p8.LandingBinding,
            FontFace = u3,
            TextTransparency = p8.TransparencyTween:Map(function(p10) --[[ Line: 37 ]]
                return p10;
            end),
            TextColor3 = Color3.fromRGB(45, 45, 45)
        }),
        White = u2.createElement(u4, {
            ZIndex = 4,
            Color = Color3.new(1, 1, 1),
            Position = UDim2.fromScale(0.95, 0.9),
            Bind = p8.TickBinding,
            Visible = p8.TransparencyTween
        }),
        Blue = u2.createElement(u4, {
            ZIndex = 3,
            Color = Color3.fromRGB(0, 242, 255),
            Position = UDim2.fromScale(0.949, 0.896),
            Bind = p8.TickBinding,
            Visible = p8.TransparencyTween
        }),
        Red = u2.createElement(u4, {
            ZIndex = 2,
            Color = Color3.fromRGB(255, 0, 0),
            Position = UDim2.fromScale(0.951, 0.902),
            Bind = p8.TickBinding,
            Visible = p8.TransparencyTween
        }),
        u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            ZIndex = 4,
            TextTransparency = 0.5,
            TextStrokeTransparency = 0.5,
            AnchorPoint = Vector2.new(0, 1),
            Size = UDim2.new(1, 0, 0, 30),
            Position = UDim2.new(0, 0, 1, -20),
            TextXAlignment = Enum.TextXAlignment.Center,
            Text = p8.MessageBinding,
            FontFace = u3,
            TextStrokeColor3 = Color3.new(0, 0, 0),
            TextColor3 = Color3.new(1, 1, 1)
        })
    });
end;
return v5;