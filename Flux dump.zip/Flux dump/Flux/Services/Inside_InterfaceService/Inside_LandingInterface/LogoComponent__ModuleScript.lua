-- Services.InterfaceService.LandingInterface.LogoComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local _, u1 = shared.import("require", "Roact");
local u2 = Font.fromName("RobotoCondensed", Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local v3 = u1.Component:extend("Logo");
function v3.render(p4) --[[ Line: 7 ]]
    -- upvalues: u1 (copy), u2 (copy)
    local l__props__1 = p4.props;
    local l__Bind__2 = l__props__1.Bind;
    return u1.createElement("CanvasGroup", {
        BackgroundTransparency = 1,
        GroupTransparency = l__Bind__2:map(function(p5) --[[ Line: 12 ]]
            -- upvalues: l__props__1 (copy)
            local v6 = math.noise(l__props__1.ZIndex * p5 / 3 % 1000000, 0, 0);
            return math.abs(v6) + 0.5;
        end),
        GroupColor3 = l__props__1.Color,
        AnchorPoint = Vector2.new(1, 1),
        Position = l__props__1.Position,
        Size = UDim2.fromScale(0.05, 0.05),
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        ZIndex = l__props__1.ZIndex,
        Visible = l__props__1.Visible:Map(function(p7) --[[ Line: 23 ]]
            return p7 < 0.5;
        end)
    }, {
        u1.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(1, 1, 1),
            Size = UDim2.fromScale(0.3, 1)
        }, { u1.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Rotation = 90,
                Text = "PLATINUM",
                AutoLocalize = false,
                TextScaled = true,
                AnchorPoint = Vector2.new(0.5, 0.5),
                SizeConstraint = Enum.SizeConstraint.RelativeXX,
                Position = UDim2.fromScale(0.5, 0.5),
                Size = UDim2.fromScale(10, 0.9),
                TextColor3 = Color3.new(0, 0, 0),
                Font = Enum.Font.Oswald
            }) }),
        u1.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(1, 1, 1),
            Position = l__Bind__2:map(function(p8) --[[ Line: 49 ]]
                local v9 = math.sin(p8);
                local v10 = math.abs(v9);
                return UDim2.fromScale(0.38, (1 - v10) * 0.45 + 0.55);
            end),
            Size = l__Bind__2:map(function(p11) --[[ Line: 53 ]]
                local v12 = math.sin(p11);
                local v13 = math.abs(v12);
                return UDim2.fromScale(0.03, (1 - v13) * 0.45);
            end)
        }),
        u1.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(1, 1, 1),
            Position = l__Bind__2:map(function(p14) --[[ Line: 61 ]]
                local v15 = math.sin(p14 + 1.0471975511965976);
                local v16 = math.abs(v15);
                return UDim2.fromScale(0.44, (1 - v16) * 0.45 + 0.55);
            end),
            Size = l__Bind__2:map(function(p17) --[[ Line: 65 ]]
                local v18 = math.sin(p17 + 1.0471975511965976);
                local v19 = math.abs(v18);
                return UDim2.fromScale(0.03, (1 - v19) * 0.45);
            end)
        }),
        u1.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(1, 1, 1),
            Position = l__Bind__2:map(function(p20) --[[ Line: 73 ]]
                local v21 = math.sin(p20 + 2.0943951023931953);
                local v22 = math.abs(v21);
                return UDim2.fromScale(0.5, (1 - v22) * 0.45 + 0.55);
            end),
            Size = l__Bind__2:map(function(p23) --[[ Line: 77 ]]
                local v24 = math.sin(p23 + 2.0943951023931953);
                local v25 = math.abs(v24);
                return UDim2.fromScale(0.03, (1 - v25) * 0.45);
            end)
        }),
        u1.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://15443015283",
            Size = UDim2.fromScale(0.6, 0.45),
            Position = UDim2.fromScale(0.96, 0),
            AnchorPoint = Vector2.new(1, 0)
        }),
        u1.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "5",
            AutoLocalize = false,
            TextScaled = true,
            AnchorPoint = Vector2.new(1, 1),
            Position = UDim2.fromScale(1, 1.19),
            Size = UDim2.fromScale(0.7, 1),
            TextColor3 = Color3.new(1, 1, 1),
            FontFace = u2,
            TextXAlignment = Enum.TextXAlignment.Right
        })
    });
end;
return v3;