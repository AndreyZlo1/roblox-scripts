-- Services.InterfaceService.TagInterface.TagComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local u3 = v1("InputService");
local v4 = u2.Component:extend("Tag");
local u5 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u6 = {
    { Color3.fromRGB(51, 131, 223), Color3.fromRGB(124, 188, 230) },
    { Color3.fromRGB(223, 51, 51), Color3.fromRGB(230, 124, 124) }
};
function v4.init(p7, p8) --[[ Line: 15 ]]
    p7.MedicalBinding = p8.MedicalBinding;
    p7.NameTagBinding = p8.NameTagBinding;
    p7.NameTagTween = p8.NameTagTween;
    p7.SpottedMeter = p8.SpottedMeter;
    p7.Flash = p8.Flash;
end;
function v4.render(u9) --[[ Line: 24 ]]
    -- upvalues: u2 (copy), u5 (copy), u6 (copy), u3 (copy)
    local l__SquadColor__1 = u9.props.SquadColor;
    local v10 = {};
    local v11 = {};
    local v12 = {};
    for v13, v14 in u9.props.POI do
        v10[v13] = v14;
    end;
    local v15 = {};
    for v16, v17 in u9.props.Markers do
        if v17.IsBig then
            v10[v16] = v17;
        else
            v15[v16] = {
                Color = Color3.new(1, 0.5, 0),
                Name = v17.Text,
                PositionBinding = v17.PositionBinding,
                DistanceBinding = v17.DistanceBinding,
                TransparencyBinding = v17.TransparencyBinding
            };
        end;
    end;
    for v18, v19 in u9.props.Squad do
        v15[v18] = {
            Color = l__SquadColor__1,
            Name = v19.Name,
            DownedBinding = v19.DownedBinding,
            PositionBinding = v19.PositionBinding,
            DistanceBinding = v19.DistanceBinding,
            TransparencyBinding = v19.TransparencyBinding
        };
    end;
    for v20, v21 in v10 do
        v11[v20] = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0.5, 0),
            Position = v21.PositionBinding,
            Size = UDim2.fromScale(1, 0.025)
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.5),
                Position = UDim2.fromScale(0, 0.1),
                Text = v21.TextBinding and v21.TextBinding:map(function(p22) --[[ Line: 71 ]]
                    return p22:upper();
                end) or v21.Text:upper(),
                TextColor3 = v21.ColorBinding or Color3.new(1, 0.5, 0),
                FontFace = u5,
                TextTransparency = v21.TransparencyBinding
            }, { u2.createElement("UIStroke", {
                    Thickness = 1.3,
                    ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                    Color = Color3.new(),
                    LineJoinMode = Enum.LineJoinMode.Round,
                    Transparency = v21.TransparencyBinding:map(function(p23) --[[ Line: 84 ]]
                        return p23 * 0.55 + 0.45;
                    end)
                }) }), u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.4),
                Position = UDim2.fromScale(0, 0.6),
                Text = v21.DistanceBinding,
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u5,
                TextTransparency = v21.TransparencyBinding
            }, { u2.createElement("UIStroke", {
                    Thickness = 1.3,
                    ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                    Color = Color3.new(),
                    LineJoinMode = Enum.LineJoinMode.Round,
                    Transparency = v21.TransparencyBinding:map(function(p24) --[[ Line: 104 ]]
                        return p24 * 0.55 + 0.45;
                    end)
                }) }), u2.createElement("ImageLabel", {
                BorderSizePixel = 0,
                BackgroundTransparency = 1,
                Image = "rbxassetid://94446116652375",
                AnchorPoint = Vector2.new(0.5, 1),
                Position = UDim2.fromScale(0.5, 0),
                Size = UDim2.fromScale(0.7, 0.7),
                ImageColor3 = v21.ColorBinding or Color3.new(1, 0.5, 0),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                ImageTransparency = v21.TransparencyBinding
            }) });
    end;
    for v25, u26 in v15 do
        local l__createElement__2 = u2.createElement;
        local v27 = "Frame";
        local v28 = {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0.5, 0),
            Position = u26.PositionBinding,
            Size = UDim2.fromScale(1, 0.025)
        };
        local v29 = {};
        local l__DownedBinding__3 = u26.DownedBinding;
        if l__DownedBinding__3 then
            l__DownedBinding__3 = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://92347778607419",
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.5),
                Size = UDim2.fromScale(1.5, 1.5),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                ImageColor3 = u26.DownedBinding:map(function(p30) --[[ Line: 137 ]]
                    -- upvalues: u26 (copy)
                    return p30 == 1 and u26.Color or Color3.new(1, 1, 1);
                end),
                ImageTransparency = u26.TransparencyBinding:map(function(p31) --[[ Line: 140 ]]
                    return p31 * 0.4 + 0.5;
                end),
                Visible = u26.DownedBinding:map(function(p32) --[[ Line: 143 ]]
                    return p32 and true or false;
                end)
            });
        end;
        v29[1], v29[2], v29[3], v29[4] = l__DownedBinding__3, u2.createElement("TextLabel", {
    BackgroundTransparency = 1,
    TextScaled = true,
    Size = UDim2.fromScale(1, 0.5),
    Position = UDim2.fromScale(0, 0.1),
    Text = u26.Name,
    TextColor3 = u26.Color,
    FontFace = u5,
    TextTransparency = u26.TransparencyBinding
}, { u2.createElement("UIStroke", {
        Thickness = 1.3,
        ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
        Color = Color3.new(),
        LineJoinMode = Enum.LineJoinMode.Round,
        Transparency = u26.TransparencyBinding:map(function(p33) --[[ Line: 162 ]]
            return p33 * 0.55 + 0.45;
        end)
    }) }), u2.createElement("TextLabel", {
    BackgroundTransparency = 1,
    TextScaled = true,
    Size = UDim2.fromScale(1, 0.4),
    Position = UDim2.fromScale(0, 0.6),
    Text = u26.DistanceBinding,
    TextColor3 = Color3.new(1, 1, 1),
    FontFace = u5,
    TextTransparency = u26.TransparencyBinding
}, { u2.createElement("UIStroke", {
        Thickness = 1.3,
        ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
        Color = Color3.new(),
        LineJoinMode = Enum.LineJoinMode.Round,
        Transparency = u26.TransparencyBinding:map(function(p34) --[[ Line: 183 ]]
            return p34 * 0.55 + 0.45;
        end)
    }) }), u2.createElement("Frame", {
    BorderSizePixel = 0,
    Rotation = 45,
    AnchorPoint = Vector2.new(0.5, 0.5),
    Position = UDim2.fromScale(0.5, 0),
    Size = UDim2.fromScale(0.2, 0.2),
    BackgroundColor3 = u26.Color,
    SizeConstraint = Enum.SizeConstraint.RelativeYY,
    BackgroundTransparency = u26.TransparencyBinding
}, { u2.createElement("UIStroke", {
        Thickness = 1.3,
        ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
        Color = Color3.new(),
        LineJoinMode = Enum.LineJoinMode.Round,
        Transparency = u26.TransparencyBinding:map(function(p35) --[[ Line: 203 ]]
            return p35 * 0.55 + 0.45;
        end)
    }) });
        v12[v25] = l__createElement__2(v27, v28, v29);
    end;
    for v36, u37 in u9.props.SpottedMarkers do
        v12[v36] = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            Size = UDim2.fromScale(0.04, 0.04),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = u37.PositionBinding,
            Text = u37.Radio and "" or u37.RadioCircle:Map(function(p38) --[[ Line: 218 ]]
                return p38 < 0.5 and "?" or "!";
            end),
            TextColor3 = u9.Flash:map(function(p39) --[[ Line: 221 ]]
                -- upvalues: u6 (ref), u37 (copy)
                local v40 = u6[(u37.Radio or u37.RadioCircle:GetValue() >= 0.5) and 2 or 1];
                return v40[1]:Lerp(v40[2], math.sin(p39 * 100) / 2 + 0.5);
            end),
            TextTransparency = u37.TransparencyBinding,
            FontFace = u5
        }, {
            u2.createElement("UIStroke", {
                Thickness = 1,
                ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                Color = Color3.new(0, 0, 0),
                LineJoinMode = Enum.LineJoinMode.Round,
                Transparency = u37.TransparencyBinding:map(function(p41) --[[ Line: 234 ]]
                    return p41 * 0.5 + 0.5;
                end)
            }),
            u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://18901346515",
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.5),
                Size = UDim2.fromScale(0.75, 0.75),
                ImageColor3 = u9.Flash:map(function(p42) --[[ Line: 244 ]]
                    -- upvalues: u6 (ref)
                    local v43 = u6[2];
                    return v43[1]:Lerp(v43[2], math.sin(p42 * 100) / 2 + 0.5);
                end),
                Visible = u37.RadioCircle:Map(function() --[[ Line: 248 ]]
                    -- upvalues: u37 (copy)
                    return u37.Radio and true or false;
                end),
                ImageTransparency = u37.TransparencyBinding
            }),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.5),
                Size = UDim2.fromScale(2, 2),
                Visible = u37.ArrowBinding:map(function(p44) --[[ Line: 258 ]]
                    return p44 and true or false;
                end),
                Rotation = u37.ArrowBinding:map(function(p45) --[[ Line: 261 ]]
                    return p45 or 0;
                end)
            }, { u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Image = "rbxassetid://78404048877055",
                    AnchorPoint = Vector2.new(0.5, 0),
                    Position = UDim2.fromScale(0.5, 0),
                    Size = UDim2.fromScale(0.4, 0.2),
                    ImageColor3 = u9.Flash:map(function(p46) --[[ Line: 271 ]]
                        -- upvalues: u6 (ref), u37 (copy)
                        local v47 = u6[(u37.Radio or u37.RadioCircle:GetValue() >= 0.5) and 2 or 1];
                        return v47[1]:Lerp(v47[2], math.sin(p46 * 100) / 2 + 0.5);
                    end)
                }) }),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.5),
                Size = u37.ExpandCircle:Map(function(p48) --[[ Line: 281 ]]
                    return UDim2.fromScale(p48 * 2 + 0.5, p48 * 2 + 0.5);
                end)
            }, { u2.createElement("UICorner", {
                    CornerRadius = UDim.new(1, 0)
                }), u2.createElement("UIStroke", {
                    Thickness = 12,
                    Color = u9.Flash:map(function(p49) --[[ Line: 290 ]]
                        -- upvalues: u6 (ref), u37 (copy)
                        local v50 = u6[(u37.Radio or u37.RadioCircle:GetValue() >= 0.5) and 2 or 1];
                        return v50[1]:Lerp(v50[2], math.sin(p49 * 100) / 2 + 0.5);
                    end),
                    Transparency = u37.ExpandCircle:Map(function(p51) --[[ Line: 294 ]]
                        return p51;
                    end)
                }) }),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(1.2, 1.2),
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.5)
            }, { u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Image = "rbxassetid://18901227026",
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Position = UDim2.new(0.5, 1, 0.5, 0),
                    Size = UDim2.fromScale(1, 1),
                    ImageTransparency = u37.TransparencyBinding,
                    ImageColor3 = u9.Flash:map(function(p52) --[[ Line: 312 ]]
                        -- upvalues: u6 (ref), u37 (copy)
                        local v53 = u6[(u37.Radio or u37.RadioCircle:GetValue() >= 0.5) and 2 or 1];
                        return v53[1]:Lerp(v53[2], math.sin(p52 * 100) / 2 + 0.5);
                    end),
                    Visible = u37.RadioCircle:Map(function(p54) --[[ Line: 316 ]]
                        return p54 >= 0.05;
                    end)
                }, {
                    u2.createElement("UIGradient", {
                        Color = ColorSequence.new(Color3.new(1, 1, 1)),
                        Offset = Vector2.new(0, 0),
                        Rotation = u37.RadioCircle:Map(function(p55) --[[ Line: 323 ]]
                            return math.clamp(p55, 0, 1) * -180;
                        end),
                        Transparency = NumberSequence.new({
                            NumberSequenceKeypoint.new(0, 1),
                            NumberSequenceKeypoint.new(0.495, 1),
                            NumberSequenceKeypoint.new(0.505, 0),
                            NumberSequenceKeypoint.new(1, 0)
                        })
                    }),
                    Inside = u2.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        Rotation = 180,
                        Image = "rbxassetid://18901227026",
                        ImageColor3 = u9.Flash:map(function(p56) --[[ Line: 334 ]]
                            -- upvalues: u6 (ref), u37 (copy)
                            local v57 = u6[(u37.Radio or u37.RadioCircle:GetValue() >= 0.5) and 2 or 1];
                            return v57[1]:Lerp(v57[2], math.sin(p56 * 100) / 2 + 0.5);
                        end),
                        ImageTransparency = u37.TransparencyBinding,
                        AnchorPoint = Vector2.new(0, 0),
                        Position = UDim2.fromOffset(-1, 0),
                        Size = UDim2.fromScale(1, 1)
                    }, { u2.createElement("UIGradient", {
                            Color = ColorSequence.new(Color3.new(1, 1, 1)),
                            Offset = Vector2.new(0, 0),
                            Rotation = u37.RadioCircle:Map(function(p58) --[[ Line: 349 ]]
                                return math.clamp(p58, 0, 1) * 180;
                            end),
                            Transparency = NumberSequence.new({
                                NumberSequenceKeypoint.new(0, 1),
                                NumberSequenceKeypoint.new(0.495, 1),
                                NumberSequenceKeypoint.new(0.505, 0),
                                NumberSequenceKeypoint.new(1, 0)
                            })
                        }) })
                }) })
        });
    end;
    local l__Name__4 = u3:GetBind("ActionMenu").Name;
    local l__createFragment__5 = u2.createFragment;
    local v59 = {};
    local v64 = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        Size = UDim2.fromScale(1, 0.015),
        Position = UDim2.fromScale(0, 0.55),
        Text = u9.NameTagBinding,
        TextColor3 = Color3.fromRGB(165, 165, 165),
        TextTransparency = u9.NameTagTween:Map(function(p60) --[[ Line: 373 ]]
            return p60;
        end),
        FontFace = u5
    }, { u2.createElement("UIStroke", {
            Thickness = 1.3,
            ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
            Color = Color3.new(),
            LineJoinMode = Enum.LineJoinMode.Round,
            Transparency = u9.NameTagTween:Map(function(p61) --[[ Line: 384 ]]
                return p61 * 0.55 + 0.45;
            end)
        }), u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            Size = UDim2.fromScale(1, 1),
            Position = UDim2.fromScale(0, 1),
            Text = "HOLD [" .. l__Name__4 .. "] FOR MEDICAL",
            TextColor3 = Color3.fromRGB(165, 165, 165),
            TextTransparency = u9.NameTagTween:Map(function(p62) --[[ Line: 394 ]]
                return p62;
            end),
            FontFace = u5,
            Visible = u9.MedicalBinding
        }, { u2.createElement("UIStroke", {
                Thickness = 1.3,
                ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                Color = Color3.new(),
                LineJoinMode = Enum.LineJoinMode.Round,
                Transparency = u9.NameTagTween:Map(function(p63) --[[ Line: 406 ]]
                    return p63 * 0.55 + 0.45;
                end)
            }) }) });
    local l__Spotted__6 = u9.props.Spotted;
    if l__Spotted__6 then
        l__Spotted__6 = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Position = UDim2.fromScale(0.5, 0.8),
            AnchorPoint = Vector2.new(0.5, 0),
            Size = UDim2.fromScale(0.25, 0.06),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "BEING DETECTED",
                TextTransparency = 0.2,
                TextScaled = true,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(-0.5, 0, 0.2, 0),
                Size = UDim2.new(2, 0, 0.4, 0),
                FontFace = u5,
                TextColor3 = Color3.new(0, 0, 0),
                TextXAlignment = Enum.TextXAlignment.Center
            }, { u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "BEING DETECTED",
                    TextTransparency = 0.1,
                    TextScaled = true,
                    AutoLocalize = false,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.new(0, 0, 0, -1),
                    Size = UDim2.new(1, 0, 1, 0),
                    FontFace = u5,
                    TextColor3 = u9.Flash:map(function(p65) --[[ Line: 440 ]]
                        -- upvalues: u6 (ref), u9 (copy)
                        local v66 = u6[u9.SpottedMeter:getValue() < 0.5 and 1 or 2];
                        return v66[1]:Lerp(v66[2], math.sin(p65 * 100) / 2 + 0.5);
                    end),
                    TextXAlignment = Enum.TextXAlignment.Center
                }) }), u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundTransparency = 0.1,
                BackgroundColor3 = Color3.new(),
                Size = UDim2.fromScale(1.5, 0.05),
                Position = UDim2.fromScale(-0.25, 0)
            }, { u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    ZIndex = 2,
                    BackgroundColor3 = Color3.new(1, 1, 1),
                    Size = UDim2.new(0, 1, 2, 0),
                    Position = UDim2.fromScale(0.5, -0.5)
                }), u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundTransparency = 0.1,
                    BackgroundColor3 = u9.Flash:map(function(p67) --[[ Line: 466 ]]
                        -- upvalues: u6 (ref), u9 (copy)
                        local v68 = u6[u9.SpottedMeter:getValue() < 0.5 and 1 or 2];
                        return v68[1]:Lerp(v68[2], math.sin(p67 * 100) / 2 + 0.5);
                    end),
                    Size = u9.SpottedMeter:map(function(p69) --[[ Line: 470 ]]
                        return UDim2.fromScale(p69, 1);
                    end),
                    Position = UDim2.new(0, 0, 0, -1)
                }) }) });
    end;
    v59[1], v59[2], v59[3], v59[4] = v64, l__Spotted__6, u2.createFragment(v12), u2.createFragment(v11);
    return l__createFragment__5(v59);
end;
return v4;