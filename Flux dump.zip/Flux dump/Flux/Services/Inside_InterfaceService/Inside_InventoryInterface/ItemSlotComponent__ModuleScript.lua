-- Services.InterfaceService.InventoryInterface.ItemSlotComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local l__RunService__1 = game:GetService("RunService");
local v1, u2, u3, u4 = shared.import("require", "Roact", "asset", "Enum");
local u5 = v1("GameShellProxyButton");
local u6 = v1("FluidSimulation");
local u7 = v1("BaseComponent");
local u8 = v1("RoactTween");
local u9 = v1("SharedInventory");
local u10 = v1("Consumables");
local u11 = v1("Menu");
local u12 = v1("Calibers");
local u13 = v1("Mathf");
Font.fromId(12187375422, u4.FontWeight.Bold, u4.FontStyle.Normal);
local u14 = Font.fromId(12187375422, u4.FontWeight.Regular, u4.FontStyle.Normal);
local function u22(_, p15, _, p16, p17, p18) --[[ Line: 19 ]]
    -- upvalues: u4 (copy), u11 (copy), u3 (copy)
    local v19 = p16 == u4.ItemType.Gloves;
    local v20 = p15.MetaData.Build[1][3];
    local l__Texture__2 = u11.Character[v19 and "Gloves" or "Boots"][v20].Camos[p15.MetaData.Build[2].Camo or "Default"].Texture;
    local v21;
    if v19 then
        v21 = u3:Get("Shared", "Models", "Character", "Arm", "Gloves", v20, "FP", "L").Asset:Clone();
    else
        v21 = u3:Get("Shared", "Models", "Character", "Boot", v20, "L").Asset:Clone();
    end;
    v21.TextureID = l__Texture__2;
    v21:PivotTo(CFrame.Angles(0, 3.141592653589793, 0));
    return v21, v19 and 1.5 or 3, p17, p18;
end;
local function u27(_, p23, _, u24, p25, p26) --[[ Line: 37 ]]
    -- upvalues: u7 (copy), u4 (copy)
    local l__ParentModel__3 = u7.Deserialize(p23.MetaData.Build).ParentModel;
    task.defer(function() --[[ Line: 41 ]]
        -- upvalues: l__ParentModel__3 (copy), u24 (copy), u4 (ref)
        l__ParentModel__3.PrimaryPart = nil;
        l__ParentModel__3.WorldPivot = l__ParentModel__3:GetBoundingBox();
        l__ParentModel__3:PivotTo(CFrame.Angles(0, u24 == u4.ItemType.Backpack and 0 or (u24 == u4.ItemType.Wrist and 1.5707963267948966 or 3.141592653589793), 0));
    end);
    return l__ParentModel__3, 4, p25, p26;
end;
local function u34(_, p28, _, p29, p30, p31) --[[ Line: 49 ]]
    -- upvalues: u4 (copy), u3 (copy)
    local v32 = p29 == u4.ItemType.Shirt;
    local v33 = u3:Get("Shared", "Models", "Outfit", "Physical", v32 and "Shirt" or "Pants").Asset:Clone();
    u3:Get("Shared", "Models", "Outfit", v32 and "ShirtTransparent" or "Pants", p28.Layout.Build).Asset:Clone().Parent = v33;
    v33.CFrame = CFrame.new() * CFrame.Angles(0, 3.141592653589793, 0);
    return v33, 5.5, p30, p31;
end;
local u83 = {
    [u4.ItemType.Mag] = function(p35, p36, p37, _, p38, _) --[[ Line: 61 ]]
        -- upvalues: u7 (copy), u12 (copy)
        p35.IsMag = true;
        local v39 = u7.new({ "Weapon", "Mag", p37:sub(11) }, nil, nil);
        local v40, v41 = v39:GetMenuConfig();
        if v40 then
            p38 = v41.Name;
        end;
        local v42 = u12[p36.MetaData.Caliber];
        if not v42 then
            warn(p36.Name .. " incorrect caliber: " .. (p36.MetaData.Caliber or "NO CALIBER SET"));
        end;
        local l__FamilyName__4 = v42.FamilyName;
        local l__ParentModel__5 = v39.ParentModel;
        l__ParentModel__5:PivotTo(CFrame.Angles(0, 1.5707963267948966, 0));
        return l__ParentModel__5, 2, p38, l__FamilyName__4;
    end,
    [u4.ItemType.Firearm] = function(_, p43, _, _, p44, _) --[[ Line: 79 ]]
        -- upvalues: u7 (copy), u12 (copy)
        local v45 = u7.Deserialize(p43.MetaData.Build);
        if not p43.MetaData.Mag and v45:GetChild("Mag") then
            v45:Remove("Mag");
        end;
        local l__ParentModel__6 = v45.ParentModel;
        local l__FamilyName__7 = u12[v45.Tune.Caliber].FamilyName;
        task.defer(function() --[[ Line: 88 ]]
            -- upvalues: l__ParentModel__6 (copy)
            l__ParentModel__6.PrimaryPart = nil;
            l__ParentModel__6.WorldPivot = l__ParentModel__6:GetBoundingBox();
            l__ParentModel__6:PivotTo(CFrame.Angles(0, -1.5707963267948966, 0));
        end);
        return l__ParentModel__6, 3, p44, l__FamilyName__7;
    end,
    [u4.ItemType.Melee] = function(_, p46, _, _, p47, p48) --[[ Line: 95 ]]
        -- upvalues: u3 (copy)
        local u49 = u3:Get("Shared", "Models", "Weapon", "Melee", p46.Layout.Build).Asset:Clone();
        task.defer(function() --[[ Line: 98 ]]
            -- upvalues: u49 (copy)
            u49.PrimaryPart = nil;
            u49.WorldPivot = u49:GetBoundingBox();
            u49:PivotTo(CFrame.Angles(0, -1.5707963267948966, 0));
        end);
        return u49, 2, p47, p48;
    end,
    [u4.ItemType.Medical] = function(_, _, p50, _, p51, p52) --[[ Line: 105 ]]
        -- upvalues: u3 (copy)
        local v53 = u3:Get("Shared", "Models", "Medical", p50).Asset:Clone();
        (v53:IsA("BasePart") and v53 and v53 or v53.PrimaryPart):PivotTo(CFrame.new());
        return v53, 2, p51, p52;
    end,
    [u4.ItemType.Grenade] = function(_, p54, _, _, p55, p56) --[[ Line: 112 ]]
        -- upvalues: u3 (copy)
        local v57 = u3:Get("Shared", "Models", "Grenade", p54.Layout.Model).Asset:Clone();
        v57:PivotTo(CFrame.new());
        return v57, 2, p55, p56;
    end,
    [u4.ItemType.Consumable] = function(_, p58, _, _, p59, p60) --[[ Line: 118 ]]
        -- upvalues: u10 (copy), u3 (copy), u6 (copy)
        local v61 = u10[p58.Name:sub(11)];
        local l__Asset__8 = u3:Get("Animation", "ConsumableAnimations", v61.Model, "TP", "Use").Asset;
        local v62 = u3:Get("Shared", "Models", "Consumables", v61.Model).Asset:Clone();
        for v63, v64 in v61.Texture do
            v62[v63].TextureID = v64;
        end;
        v62:PivotTo(l__Asset__8.Offset or CFrame.new(0, 0, 0));
        if v61.Fluid then
            local l__Fluid__9 = v62:WaitForChild("Fluid");
            l__Fluid__9.Color = v61.Fluid;
            u6(l__Fluid__9.CFrame, l__Fluid__9.Size, 1 - (p58.MetaData.Uses or 0) / v61.Uses, l__Fluid__9:GetChildren());
        end;
        return v62, l__Asset__8.Zoom or 3, p59, p60;
    end,
    [u4.ItemType.Ammo] = function(p65, p66, _, _, p67, p68) --[[ Line: 136 ]]
        -- upvalues: u3 (copy)
        local v69 = u3:Get("Shared", "Models", "Boxes", p66.Layout.Box).Asset:Clone();
        v69.CFrame = CFrame.Angles(1.5707963267948966, 0, 0);
        p65.IsMag = true;
        return v69, 2, p67, p68;
    end,
    [u4.ItemType.Junk] = function(_, p70, _, _, p71, p72) --[[ Line: 143 ]]
        -- upvalues: u3 (copy)
        local v73 = u3:Get("Shared", "Models", "Junk", p70.Layout.Build).Asset:Clone();
        v73:PivotTo(CFrame.Angles(0, 3.141592653589793, 0));
        return v73, p70.Layout.Zoom, p71, p72;
    end,
    [u4.ItemType.Rocket] = function(_, p74, _, _, p75, p76) --[[ Line: 154 ]]
        -- upvalues: u3 (copy)
        local v77 = u3:Get("Shared", "Models", "Rocket", p74.Layout.Model).Asset:Clone();
        local v78 = v77:FindFirstChild("rocket", true);
        if v78 then
            v78:Destroy();
        end;
        v77.PrimaryPart.PivotOffset = CFrame.new();
        v77:PivotTo(CFrame.Angles(0, 1.5707963267948966, 0));
        return v77, p74.Layout.Zoom, p75, p76;
    end,
    [u4.ItemType.Gear] = function(_, p79, _, _, p80, p81) --[[ Line: 165 ]]
        -- upvalues: u3 (copy)
        local v82 = u3:Get("Shared", "Models", "Gear", p79.Layout.Build).Asset:Clone();
        v82:PivotTo(CFrame.Angles(0, 3.141592653589793, 0));
        return v82, p79.Layout.Zoom, p80, p81;
    end,
    [u4.ItemType.Gloves] = function(...) --[[ Line: 170 ]]
        -- upvalues: u22 (copy)
        return u22(...);
    end,
    [u4.ItemType.Boots] = function(...) --[[ Line: 173 ]]
        -- upvalues: u22 (copy)
        return u22(...);
    end,
    [u4.ItemType.Helmet] = function(...) --[[ Line: 176 ]]
        -- upvalues: u27 (copy)
        return u27(...);
    end,
    [u4.ItemType.Vest] = function(...) --[[ Line: 179 ]]
        -- upvalues: u27 (copy)
        return u27(...);
    end,
    [u4.ItemType.Belt] = function(...) --[[ Line: 182 ]]
        -- upvalues: u27 (copy)
        return u27(...);
    end,
    [u4.ItemType.Facewear] = function(...) --[[ Line: 185 ]]
        -- upvalues: u27 (copy)
        return u27(...);
    end,
    [u4.ItemType.Earwear] = function(...) --[[ Line: 188 ]]
        -- upvalues: u27 (copy)
        return u27(...);
    end,
    [u4.ItemType.Eyewear] = function(...) --[[ Line: 191 ]]
        -- upvalues: u27 (copy)
        return u27(...);
    end,
    [u4.ItemType.Wrist] = function(...) --[[ Line: 194 ]]
        -- upvalues: u27 (copy)
        return u27(...);
    end,
    [u4.ItemType.Backpack] = function(...) --[[ Line: 197 ]]
        -- upvalues: u27 (copy)
        return u27(...);
    end,
    [u4.ItemType.Shirt] = function(...) --[[ Line: 201 ]]
        -- upvalues: u34 (copy)
        return u34(...);
    end,
    [u4.ItemType.Pants] = function(...) --[[ Line: 204 ]]
        -- upvalues: u34 (copy)
        return u34(...);
    end
};
local u84 = u2.Component:extend("TouchButton");
function u84.init(u85, p86) --[[ Line: 210 ]]
    -- upvalues: u2 (copy), u83 (copy), u8 (copy), u4 (copy)
    local l__Item__10 = p86.Item;
    local v87 = u2.createRef();
    local v88 = Instance.new("Camera");
    v88.FieldOfView = 35;
    local v89 = l__Item__10.Layout.Name or (l__Item__10.Name or "");
    local v90 = l__Item__10.Layout.Description or "";
    local l__Name__11 = l__Item__10.Name;
    local l__ItemType__12 = l__Item__10.Layout.ItemType;
    local v91 = u83[l__ItemType__12];
    local v92, v93;
    if v91 then
        v92, v93, v89, v90 = v91(u85, l__Item__10, l__Name__11, l__ItemType__12, v89, v90);
    else
        v93 = 2;
        v92 = nil;
    end;
    v88.CFrame = CFrame.new(0, 0, v93);
    u85.Zoom = v93;
    u85.Name = v89;
    u85.Description = v90;
    u85.Hovering = p86.Hovering;
    u85.Viewport = v87;
    u85.Model = v92;
    u85.Camera = v88;
    u85.Tween = p86.Tween or u8.new(0);
    u85.Transparency = u8.new(0);
    u85.Dragging = p86.Dragging;
    u85.SizeTween = u8.new(p86.Dragging and 1 or 0);
    u85.SizeIsBinding = type(p86.Size) == "table";
    local v94, v95 = u2.createBinding(u85.SizeIsBinding and p86.Size:getValue() or p86.Size);
    u85.Size = v94;
    u85.UpdSize = v95;
    u85.PositionIsBinding = type(p86.Position) == "table";
    local v96, v97 = u2.createBinding(u85.PositionIsBinding and p86.Position:getValue() or p86.Position);
    u85.Position = v96;
    u85.UpdPosition = v97;
    if p86.Rotated then
        u85.RotatedTween = u8.new(p86.Rotated:getValue() and 1 or 0, TweenInfo.new(0.15, u4.EasingStyle.Exponential, u4.EasingDirection.Out, 0, false, 0));
    else
        u85.RotatedTween = u8.new(l__Item__10.Rotated and 1 or 0);
    end;
    u85._wasRotated = l__Item__10.Rotated;
    if p86.Dragging then
        u85.SizeTween:SetGoal(0);
    end;
    function u85.Callback() --[[ Line: 260 ]]
        -- upvalues: u85 (copy)
        u85.Transparency:SetGoal(0);
    end;
end;
function u84.didMount(u98) --[[ Line: 265 ]]
    -- upvalues: l__RunService__1 (copy)
    if u98.Model then
        u98.Model.Parent = u98.Viewport:getValue();
    end;
    if u98.SizeIsBinding or u98.PositionIsBinding then
        u98.Step = l__RunService__1.RenderStepped:Connect(function(p99) --[[ Line: 271 ]]
            -- upvalues: u98 (copy)
            if u98.SizeIsBinding then
                local v100 = u98.props.Size:getValue();
                if v100 ~= u98.TargetSize then
                    u98.TargetSizeScale = 0;
                end;
                local v101 = u98;
                v101.TargetSizeScale = v101.TargetSizeScale + p99 * 2.5;
                u98.TargetSize = v100;
                u98.UpdSize(u98.Size:getValue():Lerp(v100, (math.min(1, u98.TargetSizeScale))));
            end;
            if u98.PositionIsBinding then
                local v102 = u98.props.Position:getValue();
                if v102 ~= u98.TargetPosition then
                    u98.TargetPositionScale = 0;
                end;
                local v103 = u98;
                v103.TargetPositionScale = v103.TargetPositionScale + p99 * 8;
                u98.TargetPosition = v102;
                u98.UpdPosition(u98.Position:getValue():Lerp(u98.TargetPosition, u98.props.TweenPosition and math.min(1, u98.TargetPositionScale) or 1));
            end;
        end);
    end;
end;
function u84.willUnmount(p104) --[[ Line: 297 ]]
    if p104.Model then
        p104.Model:Destroy();
    end;
    if p104.Step then
        p104.Step:Disconnect();
    end;
end;
function u84.render(u105) --[[ Line: 306 ]]
    -- upvalues: u2 (copy), u13 (copy), u4 (copy), u84 (copy), u5 (copy), u9 (copy), u14 (copy)
    local l__props__13 = u105.props;
    local l__Item__14 = l__props__13.Item;
    local l__Nested__15 = l__props__13.Nested;
    local v106;
    if u105.IsMag then
        if not l__Item__14.MetaData.Capacity then
            return;
        end;
        local v107, v108 = Color3.new(1, 0, 0):Lerp(Color3.new(0, 1, 0), (math.clamp(l__Item__14.MetaData.Capacity / l__Item__14.Layout.Max, 0, 1))):ToHSV();
        v106 = Color3.fromHSV(v107, v108, 1);
    else
        v106 = nil;
    end;
    if not u105.PositionIsBinding then
        u105.UpdPosition(l__props__13.Position);
    end;
    local l__Rotated__16 = l__Item__14.Rotated;
    if l__Rotated__16 ~= u105._wasRotated then
        u105.RotatedTween:SetValue(l__Rotated__16 and 1 or 0);
        u105._wasRotated = l__Rotated__16;
    end;
    local u109 = l__Item__14.Layout.Size.X / l__Item__14.Layout.Size.Y;
    local u110 = l__Nested__15 and (l__props__13.SectionSize.X / l__props__13.SectionSize.Y or 1) or 1;
    local v115 = u2.joinBindings({ u105.SizeTween:Map(function(p111) --[[ Line: 334 ]]
            return UDim2.fromScale(p111 * 0.03, p111 * 0.03);
        end), u2.joinBindings({ u105.RotatedTween:Map(function(p112) --[[ Line: 338 ]]
                return p112;
            end), u105.Size }):map(function(p113) --[[ Line: 340 ]]
            -- upvalues: u105 (copy), u13 (ref), u109 (copy), u110 (copy)
            u105.Camera.CFrame = CFrame.new(0, 0, u105.Zoom * u13.Lerp(1, u109, p113[1])) * CFrame.Angles(0, 0, u13.Lerp(0, -1.5707963267948966, p113[1]));
            return p113[2]:Lerp(UDim2.new(p113[2].Y.Scale / u110, p113[2].Y.Offset, p113[2].X.Scale * u110, p113[2].X.Offset), p113[1]);
        end) }):map(function(p114) --[[ Line: 344 ]]
        return p114[1] + p114[2];
    end);
    if l__props__13.Preview then
        return u2.createElement("Frame", {
            ZIndex = 1,
            Size = v115,
            Position = u105.Position,
            Ref = l__props__13.Ref,
            SizeConstraint = u4.SizeConstraint.RelativeYY,
            BackgroundTransparency = l__props__13.Rotated and (l__props__13.Rotated:map(function(p116) --[[ Line: 354 ]]
                -- upvalues: u105 (copy)
                u105.RotatedTween:SetGoal(p116 and 1 or 0);
                return 1;
            end) or 1) or 1
        }, {
            Corner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 1)
            }),
            Stroke = u2.createElement("UIStroke", {
                Thickness = 2,
                Transparency = 0.7,
                Color = l__props__13.ValidLocation:map(function(p117) --[[ Line: 364 ]]
                    return p117 and Color3.fromRGB(255, 194, 89) or Color3.fromRGB(255, 69, 69);
                end),
                LineJoinMode = u4.LineJoinMode.Round
            })
        });
    end;
    local l__MetaData__17 = l__Item__14.MetaData;
    local u118 = u84.Rarity[l__Item__14.Layout.Rarity or (l__Item__14.MetaData.Rarity or 1)];
    local l__createElement__18 = u2.createElement;
    local v119 = u5;
    local v123 = {
        AnchorPoint = l__Nested__15 and Vector2.new() or Vector2.new(0.5, 0.5),
        SizeConstraint = l__Nested__15 and u4.SizeConstraint.RelativeXY or u4.SizeConstraint.RelativeYY,
        Ref = l__props__13.Ref,
        Ignore = l__props__13.MouseDown == nil,
        Size = v115,
        Position = u105.Position,
        BackgroundTransparency = l__props__13.Rotated and (l__props__13.Rotated:map(function(p120) --[[ Line: 384 ]]
            -- upvalues: u105 (copy)
            u105.RotatedTween:SetGoal(p120 and 1 or 0);
            return 1;
        end) or 1) or 1,
        ZIndex = u105.Tween:Map(function(p121) --[[ Line: 388 ]]
            return p121 > 0.1 and 3 or 2;
        end),
        MouseEnter = function() --[[ Name: MouseEnter, Line 392 ]]
            -- upvalues: u105 (copy), l__Item__14 (copy), l__props__13 (copy)
            if u105.Hovering then
                u105.Hovering:Fire(l__Item__14.Layout.SlotType);
            end;
            if l__props__13.Hover then
                l__props__13.Hover(u105.Name, u105.Description);
            end;
            u105.Tween:SetGoal(1);
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 402 ]]
            -- upvalues: u105 (copy), l__props__13 (copy)
            if u105.Hovering then
                u105.Hovering:Fire(nil);
            end;
            if l__props__13.Hover then
                l__props__13.Hover();
            end;
            u105.Tween:SetGoal(0);
        end,
        MouseDown = function(p122) --[[ Name: MouseDown, Line 411 ]]
            -- upvalues: l__props__13 (copy), u105 (copy)
            if l__props__13 and l__props__13.MouseDown(p122, u105.Callback) then
                u105.Transparency:SetGoal(0);
            else
                u105.Transparency:SetGoal(1);
            end;
        end,
        MouseUp = function() --[[ Name: MouseUp, Line 418 ]]
            -- upvalues: u105 (copy)
            u105.Transparency:SetGoal(0);
        end
    };
    local v124 = {};
    local v129 = u2.createElement("ImageLabel", {
        Image = "rbxassetid://13867926930",
        BorderSizePixel = 0,
        BackgroundTransparency = 1,
        ImageTransparency = 0.6,
        TileSize = UDim2.fromOffset(64, 64),
        ScaleType = u4.ScaleType.Tile,
        Size = UDim2.new(1, 0, 1, 0),
        ImageColor3 = u105.Dragging and Color3.fromRGB(255, 194, 89):Lerp(Color3.new(), 0.2) or u105.Tween:Map(function(p125) --[[ Line: 431 ]]
            return Color3.fromRGB(105, 105, 105):Lerp(Color3.new(1, 1, 1), p125):Lerp(Color3.new(), 0.2);
        end)
    }, {
        Corner = u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 1)
        }),
        Gradient = u2.createElement("UIGradient", {
            Rotation = -90,
            Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, u118.Color:Lerp(Color3.new(), u118.Bright and 0.2 or 0.5)), ColorSequenceKeypoint.new(1, Color3.fromRGB(54, 54, 54)) })
        }),
        Stroke = u2.createElement("UIStroke", {
            Thickness = 1,
            ApplyStrokeMode = u4.ApplyStrokeMode.Contextual,
            Color = u105.Dragging and Color3.fromRGB(255, 194, 89) or u105.Tween:Map(function(p126) --[[ Line: 447 ]]
                -- upvalues: u118 (copy)
                return u118.Color:Lerp(Color3.new(), u118.Bright and 0.35 or 0.5):Lerp(u118.Color, p126);
            end),
            BorderStrokePosition = u4.BorderStrokePosition.Outer,
            LineJoinMode = u4.LineJoinMode.Round,
            Transparency = u105.Transparency:Map(function(p127) --[[ Line: 453 ]]
                return p127 / 1.9;
            end)
        }),
        u2.createElement("ViewportFrame", {
            LightDirection = Vector3.new(0.5, -1, 0.5),
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            Ambient = Color3.new(1, 1, 1),
            LightColor = Color3.new(1, 1, 1),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = UDim2.fromScale(1, 1),
            SizeConstraint = u4.SizeConstraint.RelativeXY,
            BackgroundColor3 = Color3.fromRGB(39, 39, 39),
            ImageColor3 = Color3.new(1, 1, 1),
            ImageTransparency = u105.Transparency:Map(function(p128) --[[ Line: 470 ]]
                return p128 / 1.9;
            end),
            CurrentCamera = u105.Camera
        }, { u2.createElement("WorldModel", {
                [u2.Ref] = u105.Viewport
            }) })
    });
    local l__Durability__19 = l__MetaData__17.Durability;
    if l__Durability__19 then
        if l__MetaData__17.Durability > 0 then
            l__Durability__19 = u2.createElement("Frame", {
                BorderSizePixel = 0,
                ZIndex = 2,
                Size = UDim2.fromScale(l__MetaData__17.Durability / l__MetaData__17.DurabilityMax, 0.1),
                Position = UDim2.fromScale(0, 0.9),
                BackgroundColor3 = Color3.new(1, 0, 0):Lerp(Color3.new(0, 1, 0), l__MetaData__17.Durability / l__MetaData__17.DurabilityMax)
            });
        else
            l__Durability__19 = false;
        end;
    end;
    local l__Durability__20 = l__MetaData__17.Durability;
    if l__Durability__20 then
        if l__MetaData__17.Durability <= 0 then
            l__Durability__20 = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://105272496075887",
                ImageTransparency = 0.8,
                ZIndex = 2,
                Size = UDim2.fromScale(1, 1),
                ImageColor3 = Color3.new(1, 0, 0)
            });
        else
            l__Durability__20 = false;
        end;
    end;
    if v106 then
        local l__createElement__21 = u2.createElement;
        local v130 = "TextLabel";
        local v134 = {
            BackgroundTransparency = 1,
            ZIndex = 4,
            TextScaled = true,
            Size = u105.RotatedTween:Map(function(p131) --[[ Line: 497 ]]
                -- upvalues: l__props__13 (copy), u13 (ref), u9 (ref), l__Item__14 (copy)
                local v132 = l__props__13.Small and 1 or u13.Lerp(u9.GetSize(l__Item__14, false).Y, u9.GetSize(l__Item__14, true).Y, p131);
                return UDim2.fromScale(1, 0.4 / v132);
            end),
            Position = UDim2.new(1, 0, 1, 0),
            AnchorPoint = Vector2.new(1, 1),
            Text = "(x" .. l__Item__14.MetaData.Capacity .. ")",
            TextXAlignment = u4.TextXAlignment.Right,
            TextTransparency = u105.Transparency:Map(function(p133) --[[ Line: 510 ]]
                return p133 / 1.9;
            end)
        };
        if u105.Dragging then
            v106 = Color3.fromRGB(255, 194, 89) or v106;
        end;
        v134.TextColor3 = v106;
        v134.FontFace = u14;
        v106 = l__createElement__21(v130, v134);
    end;
    v124[1], v124[2], v124[3], v124[4] = v129, l__Durability__19, l__Durability__20, v106;
    return l__createElement__18(v119, v123, v124);
end;
return u84;