-- Services.InterfaceService.InventoryInterface.StoreInventoryComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Roact", "network", "Enum");
local u5 = v1("StoreInventoryButtonComponent");
local u6 = v1("GameShellProxyScroller");
local u7 = v1("getItemValue");
local u8 = v1("formatNumber");
local u9 = v1("CompanyInfo");
local u10 = v1("ClientService");
local u11 = v1("PopupInterface");
local u12 = v1("GameShellProxyInput");
local u13 = v1("BaseComponent");
local u14 = v1("ItemLayout");
local u15 = v1("Calibers");
local u16 = v1("Item");
local u17 = v1("Boxes");
local u18 = Font.fromId(12187375422, u4.FontWeight.Bold, u4.FontStyle.Normal);
local u19 = Font.fromId(12187375422, u4.FontWeight.Regular, u4.FontStyle.Normal);
local function u23(p20) --[[ Line: 24 ]]
    -- upvalues: u13 (copy), u10 (copy), u17 (copy), u15 (copy)
    local l___item__1 = p20._item;
    if l___item__1 and (l___item__1 == "PrimaryMag" or l___item__1 == "SecondaryMag") then
        p20.Price = 0;
        p20.Level = 0;
        local v21 = u13.Deserialize(u10.LocalClient.Loadouts[u10.LocalClient.ActiveLoadout].Tree, true);
        local v22;
        if l___item__1 == "PrimaryMag" then
            v22 = v21:GetChild("Primary");
        else
            v22 = v21:GetChild("Secondary");
        end;
        if v22 then
            if v22.Tune.Box then
                p20.Item = "AmmoBox" .. v22.Tune.Box;
                p20.MetaData = {
                    Capacity = u17[v22.Tune.Box].Capacity
                };
                return;
            else
                local l__Name__2 = v22:GetChild("Mag").Name;
                p20.Item = "FirearmMag" .. l__Name__2;
                p20.MetaData = {
                    Caliber = v22.Tune.Caliber,
                    Capacity = v22.Tune.Ammo,
                    Description = u15[v22.Tune.Caliber].FamilyName,
                    Name = l__Name__2
                };
                return;
            end;
        end;
        p20.Item = nil;
    end;
end;
local v24 = u2.Component:extend("TouchButton");
function v24.init(u25, _) --[[ Line: 63 ]]
    -- upvalues: u2 (copy), u11 (copy), u3 (copy)
    local v26, v27 = u2.createBinding("");
    u25.RenamingBind = v26;
    u25.UpdRenamingBind = v27;
    u25.RenameButtonRef = u2.createRef();
    function u25.AttemptRename() --[[ Line: 66 ]]
        -- upvalues: u11 (ref), u25 (copy), u3 (ref)
        u11:Unfocus();
        local v28 = u25.RenamingBind:getValue();
        if u3:InvokeServer("ArmoryAdd", v28) then
            u25.props.NewPreset(v28);
        end;
        u25:setState({
            Renaming = false
        });
    end;
    u25.ScrollerRef = u2.createRef();
    u25:setState({
        Page = 0
    });
end;
function v24.render(u29) --[[ Line: 86 ]]
    -- upvalues: u2 (copy), u4 (copy), u5 (copy), u12 (copy), u19 (copy), u11 (copy), u6 (copy), u7 (copy), u8 (copy), u9 (copy), u3 (copy), u23 (copy), u14 (copy), u16 (copy), u18 (copy)
    local l__props__3 = u29.props;
    local l__PopupActive__4 = l__props__3.PopupActive;
    local l__Wishlist__5 = l__props__3.Wishlist;
    local l__ArmoryPresets__6 = l__props__3.ArmoryPresets;
    local l__Payload__7 = l__props__3.Payload;
    local l__CellSize__8 = l__props__3.CellSize;
    local v30 = l__CellSize__8 * 12;
    local v31 = l__CellSize__8 * 10;
    local v32 = l__CellSize__8 / 1.5;
    local v33 = v32 / v30;
    local v34 = Color3.fromRGB(105, 105, 105);
    local v35 = "STORE";
    local l__Page__9 = u29.state.Page;
    local v36 = {};
    local v37;
    if l__ArmoryPresets__6 then
        local v38 = #l__ArmoryPresets__6;
        local v39;
        if v38 < 6 then
            v38 = v38 + 1;
            v39 = true;
        else
            v39 = false;
        end;
        local v40 = math.max(6, v38);
        local v41 = 1 / v40;
        local v42 = {
            grid = u2.createElement("UIGridLayout", {
                CellPadding = UDim2.fromScale(0, 0),
                CellSize = UDim2.fromScale(1, v41),
                FillDirection = u4.FillDirection.Vertical,
                HorizontalAlignment = u4.HorizontalAlignment.Left,
                SortOrder = u4.SortOrder.LayoutOrder,
                StartCorner = u4.StartCorner.TopLeft,
                VerticalAlignment = u4.VerticalAlignment.Top
            })
        };
        for u43, v44 in l__ArmoryPresets__6 do
            v42["preset_" .. u43] = u2.createElement(u5, {
                Preset = true,
                Sub = "",
                Scroller = u29.ScrollerRef,
                PopupActive = l__PopupActive__4,
                Name = v44[1],
                LayoutOrder = u43,
                Callback = function(p45) --[[ Name: Callback, Line 133 ]]
                    -- upvalues: l__props__3 (copy), u43 (copy)
                    l__props__3.ChangePreset(u43, p45);
                end
            });
        end;
        if v39 then
            if u29.state.Renaming then
                v42.add = u2.createElement("Frame", {
                    LayoutOrder = v38 + 1,
                    BackgroundTransparency = 0,
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.new(),
                    [u2.Ref] = u29.RenameButtonRef
                }, { u2.createElement(u12, {
                        BackgroundTransparency = 1,
                        PlaceholderText = "Default",
                        ClearTextOnFocus = false,
                        Ignore = false,
                        InstantFocus = true,
                        Size = UDim2.new(1, 0, 1, 0),
                        FontFace = u19,
                        TextXAlignment = u4.TextXAlignment.Left,
                        TextYAlignment = u4.TextYAlignment.Center,
                        TextBind = u29.RenamingBind,
                        TextBindUpdate = u29.UpdRenamingBind,
                        EnterPressed = u29.AttemptRename,
                        Content = {}
                    }) });
            else
                v42.add = u2.createElement(u5, {
                    Add = true,
                    Name = "+",
                    Sub = "",
                    Scroller = u29.ScrollerRef,
                    PopupActive = l__PopupActive__4,
                    LayoutOrder = v38 + 1,
                    Callback = function() --[[ Name: Callback, Line 174 ]]
                        -- upvalues: u29 (copy), u11 (ref)
                        u29:setState({
                            Renaming = true
                        });
                        u11:Focus(u29.RenameButtonRef, u29.AttemptRename);
                    end
                });
            end;
        end;
        v36 = u2.createElement(u6, {
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            Ref = u29.ScrollerRef,
            Size = UDim2.fromScale(1, 1),
            CanvasSize = v40 / 6,
            Content = v42
        });
        v37 = (l__Wishlist__5 or l__ArmoryPresets__6) and true or false;
        return u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            SizeConstraint = u4.SizeConstraint.RelativeYY,
            Size = v37 and UDim2.fromScale(1, 1) or UDim2.fromScale(v31, v30 + v32)
        }, { u2.createElement("ImageLabel", {
                Image = "rbxassetid://13867926930",
                BorderSizePixel = 0,
                ZIndex = 2,
                TileSize = UDim2.fromOffset(64, 64),
                ScaleType = u4.ScaleType.Tile,
                Size = UDim2.new(1, 0, v33, -2),
                ImageColor3 = v34:Lerp(Color3.new(), 0.2)
            }, {
                Corner = u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0, 1)
                }),
                Gradient = u2.createElement("UIGradient", {
                    Rotation = -90,
                    Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(112, 112, 112)), ColorSequenceKeypoint.new(1, Color3.fromRGB(54, 54, 54)) })
                }),
                Stroke = u2.createElement("UIStroke", {
                    Thickness = 1,
                    ApplyStrokeMode = u4.ApplyStrokeMode.Contextual,
                    Color = v34,
                    LineJoinMode = u4.LineJoinMode.Round
                }),
                Label = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    Size = UDim2.fromScale(1, 0.75),
                    Position = UDim2.new(0, 20, 0.5, 0),
                    AnchorPoint = Vector2.new(0, 0.5),
                    Text = v37 and "ARMORY" or v35,
                    TextXAlignment = u4.TextXAlignment.Left,
                    TextColor3 = v34,
                    FontFace = u18
                })
            }), u2.createElement("Frame", {
                BorderSizePixel = 1,
                BackgroundTransparency = 0.5,
                ZIndex = 1,
                BorderMode = u4.BorderMode.Inset,
                BorderColor3 = Color3.new(0.447058, 0.447058, 0.447058),
                BackgroundColor3 = Color3.new(1, 1, 1),
                Size = UDim2.fromScale(1, 1 - v33),
                Position = UDim2.fromScale(0, 1),
                AnchorPoint = Vector2.new(0, 1)
            }, { u2.createFragment(v36), u2.createElement("UIGradient", {
                    Rotation = 45,
                    Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(43, 43, 43)), ColorSequenceKeypoint.new(1, Color3.fromRGB(0, 0, 0)) })
                }) }) });
    end;
    if l__Payload__7.Seller then
        local v46 = {};
        v35 = "SELL ITEMS";
        for _, v47 in l__props__3.Main.Storages do
            for _, v48 in v47.Sections do
                for _, v49 in v48 do
                    local v50 = u7(v49, l__Payload__7.Seller, l__Payload__7.Quantities);
                    if v50 then
                        v46[#v46 + 1] = {
                            Item = v49,
                            Value = v50,
                            Price = v50.Price,
                            Stock = l__Payload__7.Quantities[v49.Name]
                        };
                    end;
                end;
            end;
        end;
        table.sort(v46, function(p51, p52) --[[ Line: 215 ]]
            return p51.Price > p52.Price;
        end);
        local v53 = math.max(6, #v46);
        local v54 = 1 / v53;
        local v55 = {
            grid = u2.createElement("UIGridLayout", {
                CellPadding = UDim2.fromScale(0, 0),
                CellSize = UDim2.fromScale(1, v54),
                FillDirection = u4.FillDirection.Vertical,
                HorizontalAlignment = u4.HorizontalAlignment.Left,
                SortOrder = u4.SortOrder.LayoutOrder,
                StartCorner = u4.StartCorner.TopLeft,
                VerticalAlignment = u4.VerticalAlignment.Top
            })
        };
        for v56, v57 in v46 do
            local l__Item__10 = v57.Item;
            local l__Value__11 = v57.Value;
            local l__Price__12 = l__Value__11.Price;
            local v58 = "<font color=\"rgb(0,255,0)\">SELL FOR: " .. u8(l__Price__12) .. "</font>";
            local v59 = v57.Stock and v57.Stock == 0 and "ITEM OVER STOCKED" or v58;
            local l__Resource__13 = l__Value__11.Resource;
            if l__Resource__13 then
                local v60 = u9.Resources[l__Resource__13[1]];
                v59 = v59 .. " <font color=\"#" .. v60.Color:ToHex() .. "\">" .. v60.Name:upper() .. ": " .. tostring(l__Resource__13[2]) .. "</font>";
            end;
            v55["item_" .. l__Item__10.MetaData.UID] = u2.createElement(u5, {
                RichText = true,
                Scroller = u29.ScrollerRef,
                PopupActive = l__PopupActive__4 or l__Price__12 == 0,
                Name = l__Item__10.Layout.Name or l__Item__10.Name,
                Description = v57.Stock and "NEEDED: " .. v57.Stock or "ALWAYS NEEDED",
                Item = l__Item__10,
                Sub = v59,
                LayoutOrder = v56,
                Callback = function() --[[ Name: Callback, Line 258 ]]
                    -- upvalues: u3 (ref), l__Item__10 (copy), l__Payload__7 (copy), u29 (copy)
                    u3:FireServer("ActivateInteract", "Sell", l__Item__10.MetaData.UID);
                    if l__Payload__7.Quantities[l__Item__10.Name] then
                        local l__Quantities__14 = l__Payload__7.Quantities;
                        local l__Name__15 = l__Item__10.Name;
                        l__Quantities__14[l__Name__15] = l__Quantities__14[l__Name__15] - 1;
                    end;
                    u29:setState({});
                end
            });
        end;
        v36 = u2.createElement(u6, {
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            Ref = u29.ScrollerRef,
            Size = UDim2.fromScale(1, 1),
            CanvasSize = v53 / 6,
            Content = v55
        });
    elseif l__Payload__7.Store then
        local l__Store__16 = l__Payload__7.Store;
        local l__StockLevel__17 = l__Payload__7.StockLevel;
        v35 = l__Store__16.Name:upper();
        local l__ChangeQuantity__18 = l__props__3.ChangeQuantity;
        if l__Page__9 ~= 0 then
            local v61 = l__Store__16.Categories[l__Page__9];
            local v62 = math.max(6, #v61.Items + 1);
            local v63 = 1 / v62;
            local v64 = {
                grid = u2.createElement("UIGridLayout", {
                    CellPadding = UDim2.fromScale(0, 0),
                    CellSize = UDim2.fromScale(1, v63),
                    FillDirection = u4.FillDirection.Vertical,
                    HorizontalAlignment = u4.HorizontalAlignment.Left,
                    SortOrder = u4.SortOrder.LayoutOrder,
                    StartCorner = u4.StartCorner.TopLeft,
                    VerticalAlignment = u4.VerticalAlignment.Top
                }),
                ["return"] = u2.createElement(u5, {
                    Name = "Return",
                    Sub = "Back to home",
                    LayoutOrder = 0,
                    Scroller = u29.ScrollerRef,
                    PopupActive = l__PopupActive__4,
                    Callback = function() --[[ Name: Callback, Line 361 ]]
                        -- upvalues: u29 (copy)
                        u29:setState({
                            Page = 0
                        });
                    end
                })
            };
            for u65, v66 in v61.Items do
                u23(v66);
                if v66.Item and u14[v66.Item] then
                    local v67 = u16.new(v66.Item, v66.MetaData);
                    local v68 = false;
                    local u69 = v66._item or v66.Item;
                    local v70 = true;
                    local v71 = nil;
                    local u72;
                    if l__StockLevel__17 then
                        u72 = l__StockLevel__17[u69];
                    else
                        u72 = l__StockLevel__17;
                    end;
                    local v73, v74, v75, v76, v77, v78;
                    if l__Payload__7.HQ then
                        if u72 then
                            if u72[1] <= 0 then
                                v71 = u72[3];
                                v70 = false;
                                v73 = "Next Available In: ";
                            else
                                v73 = "Available: " .. u72[1];
                            end;
                            v74 = "item_" .. u65;
                            v75 = u2.createElement;
                            v76 = u5;
                            v77 = {
                                Scroller = u29.ScrollerRef,
                                PopupActive = l__PopupActive__4 or not v70,
                                Name = v67.Layout.Name or v67.Name,
                                Description = v67.Layout.Description or v67.MetaData.Description,
                                Sub = v73,
                                Item = v67,
                                Timer = v71,
                                RichText = v68,
                                LayoutOrder = u65
                            };
                            if l__Wishlist__5 then
                                v78 = l__Wishlist__5[u69];
                            else
                                v78 = l__Wishlist__5;
                            end;
                            v77.Quantity = v78;
                            function v77.Callback(p83) --[[ Line: 431 ]]
                                -- upvalues: l__ChangeQuantity__18 (copy), u69 (copy), l__Wishlist__5 (copy), u3 (ref), l__Page__9 (copy), u65 (copy), u72 (copy), u29 (copy)
                                if l__ChangeQuantity__18 then
                                    l__ChangeQuantity__18(u69, l__Wishlist__5[u69] and p83.X > 0.8 and -1 or 1);
                                else
                                    u3:FireServer("ActivateInteract", "Buy", l__Page__9, u65);
                                end;
                                if u72 then
                                    if u72[4] then
                                        u72[3] = workspace:GetServerTimeNow() + u72[4];
                                    end;
                                    if u72[2] > 0 then
                                        local v84 = u72;
                                        v84[2] = v84[2] - 1;
                                    else
                                        local v85 = u72;
                                        v85[1] = v85[1] - 1;
                                    end;
                                    u29:setState({});
                                end;
                            end;
                            v64[v74] = v75(v76, v77);
                        end;
                    else
                        local v82 = u8(v66.Price);
                        if v66.Level > 0 then
                            v82 = v82 .. " (Level " .. v66.Level .. ")";
                        end;
                        v73 = v66.Price == 0 and v66.Level == 0 and "FREE" or v82;
                        if u72 then
                            if u72[2] > 0 then
                                v73 = "<font color=\"rgb(0,255,0)\">" .. tostring(u72[2]) .. " FREE VOUCHERS</font>";
                                v68 = true;
                            elseif u72[1] <= 0 and u72[2] <= 0 then
                                v70 = false;
                                v73 = "OUT OF STOCK";
                            else
                                v73 = v73 .. " (Stock Available: " .. u72[1] .. ")";
                            end;
                        end;
                        v74 = "item_" .. u65;
                        v75 = u2.createElement;
                        v76 = u5;
                        v77 = {
                            Scroller = u29.ScrollerRef,
                            PopupActive = l__PopupActive__4 or not v70,
                            Name = v67.Layout.Name or v67.Name,
                            Description = v67.Layout.Description or v67.MetaData.Description,
                            Sub = v73,
                            Item = v67,
                            Timer = v71,
                            RichText = v68,
                            LayoutOrder = u65
                        };
                        if l__Wishlist__5 then
                            v78 = l__Wishlist__5[u69];
                        else
                            v78 = l__Wishlist__5;
                        end;
                        v77.Quantity = v78;
                        function v77.Callback(p83) --[[ Line: 431 ]]
                            -- upvalues: l__ChangeQuantity__18 (copy), u69 (copy), l__Wishlist__5 (copy), u3 (ref), l__Page__9 (copy), u65 (copy), u72 (copy), u29 (copy)
                            if l__ChangeQuantity__18 then
                                l__ChangeQuantity__18(u69, l__Wishlist__5[u69] and p83.X > 0.8 and -1 or 1);
                            else
                                u3:FireServer("ActivateInteract", "Buy", l__Page__9, u65);
                            end;
                            if u72 then
                                if u72[4] then
                                    u72[3] = workspace:GetServerTimeNow() + u72[4];
                                end;
                                if u72[2] > 0 then
                                    local v84 = u72;
                                    v84[2] = v84[2] - 1;
                                else
                                    local v85 = u72;
                                    v85[1] = v85[1] - 1;
                                end;
                                u29:setState({});
                            end;
                        end;
                        v64[v74] = v75(v76, v77);
                    end;
                end;
            end;
            v36 = u2.createElement(u6, {
                BackgroundTransparency = 1,
                BorderSizePixel = 0,
                Ref = u29.ScrollerRef,
                Size = UDim2.fromScale(1, 1),
                CanvasSize = v62 / 6,
                Content = v64
            });
            v37 = (l__Wishlist__5 or l__ArmoryPresets__6) and true or false;
            return u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ZIndex = 2,
                SizeConstraint = u4.SizeConstraint.RelativeYY,
                Size = v37 and UDim2.fromScale(1, 1) or UDim2.fromScale(v31, v30 + v32)
            }, { u2.createElement("ImageLabel", {
                    Image = "rbxassetid://13867926930",
                    BorderSizePixel = 0,
                    ZIndex = 2,
                    TileSize = UDim2.fromOffset(64, 64),
                    ScaleType = u4.ScaleType.Tile,
                    Size = UDim2.new(1, 0, v33, -2),
                    ImageColor3 = v34:Lerp(Color3.new(), 0.2)
                }, {
                    Corner = u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0, 1)
                    }),
                    Gradient = u2.createElement("UIGradient", {
                        Rotation = -90,
                        Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(112, 112, 112)), ColorSequenceKeypoint.new(1, Color3.fromRGB(54, 54, 54)) })
                    }),
                    Stroke = u2.createElement("UIStroke", {
                        Thickness = 1,
                        ApplyStrokeMode = u4.ApplyStrokeMode.Contextual,
                        Color = v34,
                        LineJoinMode = u4.LineJoinMode.Round
                    }),
                    Label = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        Size = UDim2.fromScale(1, 0.75),
                        Position = UDim2.new(0, 20, 0.5, 0),
                        AnchorPoint = Vector2.new(0, 0.5),
                        Text = v37 and "ARMORY" or v35,
                        TextXAlignment = u4.TextXAlignment.Left,
                        TextColor3 = v34,
                        FontFace = u18
                    })
                }), u2.createElement("Frame", {
                    BorderSizePixel = 1,
                    BackgroundTransparency = 0.5,
                    ZIndex = 1,
                    BorderMode = u4.BorderMode.Inset,
                    BorderColor3 = Color3.new(0.447058, 0.447058, 0.447058),
                    BackgroundColor3 = Color3.new(1, 1, 1),
                    Size = UDim2.fromScale(1, 1 - v33),
                    Position = UDim2.fromScale(0, 1),
                    AnchorPoint = Vector2.new(0, 1)
                }, { u2.createFragment(v36), u2.createElement("UIGradient", {
                        Rotation = 45,
                        Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(43, 43, 43)), ColorSequenceKeypoint.new(1, Color3.fromRGB(0, 0, 0)) })
                    }) }) });
        end;
        local v86 = math.max(6, #l__Store__16.Categories);
        local v87 = 1 / v86;
        local v88 = {
            grid = u2.createElement("UIGridLayout", {
                CellPadding = UDim2.fromScale(0, 0),
                CellSize = UDim2.fromScale(1, v87),
                FillDirection = u4.FillDirection.Vertical,
                HorizontalAlignment = u4.HorizontalAlignment.Left,
                SortOrder = u4.SortOrder.LayoutOrder,
                StartCorner = u4.StartCorner.TopLeft,
                VerticalAlignment = u4.VerticalAlignment.Top
            })
        };
        for u89, v90 in l__Store__16.Categories do
            local v91 = "";
            for v92, v93 in v90.Items do
                u23(v93);
                if v93.Item then
                    local v94 = u14[v93.Item];
                    if v94 then
                        v91 = v91 .. (v94.Name or v93.Item);
                        if v92 < #v90.Items then
                            v91 = v91 .. ", ";
                        end;
                    end;
                end;
            end;
            v88["category_" .. u89] = u2.createElement(u5, {
                Scroller = u29.ScrollerRef,
                PopupActive = l__PopupActive__4,
                Name = v90.Name,
                Sub = v91,
                LayoutOrder = u89,
                Callback = function() --[[ Name: Callback, Line 322 ]]
                    -- upvalues: u29 (copy), u89 (copy)
                    u29:setState({
                        Page = u89
                    });
                end
            });
        end;
        v36 = u2.createElement(u6, {
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            Ref = u29.ScrollerRef,
            Size = UDim2.fromScale(1, 1),
            CanvasSize = v86 / 6,
            Content = v88
        });
    end;
    v37 = (l__Wishlist__5 or l__ArmoryPresets__6) and true or false;
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        ZIndex = 2,
        SizeConstraint = u4.SizeConstraint.RelativeYY,
        Size = v37 and UDim2.fromScale(1, 1) or UDim2.fromScale(v31, v30 + v32)
    }, { u2.createElement("ImageLabel", {
            Image = "rbxassetid://13867926930",
            BorderSizePixel = 0,
            ZIndex = 2,
            TileSize = UDim2.fromOffset(64, 64),
            ScaleType = u4.ScaleType.Tile,
            Size = UDim2.new(1, 0, v33, -2),
            ImageColor3 = v34:Lerp(Color3.new(), 0.2)
        }, {
            Corner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 1)
            }),
            Gradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(112, 112, 112)), ColorSequenceKeypoint.new(1, Color3.fromRGB(54, 54, 54)) })
            }),
            Stroke = u2.createElement("UIStroke", {
                Thickness = 1,
                ApplyStrokeMode = u4.ApplyStrokeMode.Contextual,
                Color = v34,
                LineJoinMode = u4.LineJoinMode.Round
            }),
            Label = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.75),
                Position = UDim2.new(0, 20, 0.5, 0),
                AnchorPoint = Vector2.new(0, 0.5),
                Text = v37 and "ARMORY" or v35,
                TextXAlignment = u4.TextXAlignment.Left,
                TextColor3 = v34,
                FontFace = u18
            })
        }), u2.createElement("Frame", {
            BorderSizePixel = 1,
            BackgroundTransparency = 0.5,
            ZIndex = 1,
            BorderMode = u4.BorderMode.Inset,
            BorderColor3 = Color3.new(0.447058, 0.447058, 0.447058),
            BackgroundColor3 = Color3.new(1, 1, 1),
            Size = UDim2.fromScale(1, 1 - v33),
            Position = UDim2.fromScale(0, 1),
            AnchorPoint = Vector2.new(0, 1)
        }, { u2.createFragment(v36), u2.createElement("UIGradient", {
                Rotation = 45,
                Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(43, 43, 43)), ColorSequenceKeypoint.new(1, Color3.fromRGB(0, 0, 0)) })
            }) }) });
end;
return v24;