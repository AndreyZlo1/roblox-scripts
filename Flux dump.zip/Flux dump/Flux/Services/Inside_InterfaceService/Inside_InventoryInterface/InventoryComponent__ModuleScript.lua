-- Services.InterfaceService.InventoryInterface.InventoryComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4, u5, u6 = shared.import("require", "Roact", "Enum", "signal", "asset", "server");
v1("GameShellProxyButton");
local u7 = v1("InventoryService");
local u8 = v1("ItemSlotComponent");
local u9 = v1("StoreInventoryComponent");
local u10 = v1("InventoryGridComponent");
local u11 = v1("MenuButtonComponent");
local u12 = v1("PostProcessingService");
local u13 = v1("RoactTween");
local u14 = v1("StorageLayout");
local u15 = v1("Cells");
local u16 = v1("SharedInventory");
local u17 = v1("InputService");
local u18 = v1("SoundService");
local u19 = v1("ContainerSounds");
local u20 = v1("CompanyInfo");
local u21 = v1("weightToText");
local u22 = v1("formatNumber");
local u23 = v1("getItemValue");
local u24 = v1("Sellers");
game:GetService("Debris");
local l__GuiService__1 = game:GetService("GuiService");
game:GetService("Lighting");
local l__UserInputService__2 = game:GetService("UserInputService");
local l__CurrentCamera__3 = workspace.CurrentCamera;
local u25 = Font.fromId(12187375422, u3.FontWeight.Bold, u3.FontStyle.Normal);
local u26 = Font.fromId(12187375422, u3.FontWeight.Regular, u3.FontStyle.Normal);
local u27 = {
    [u3.ItemType.Vest] = "Vest",
    [u3.ItemType.Belt] = "Belt",
    [u3.ItemType.Helmet] = "Helmet",
    [u3.ItemType.Facewear] = "Facewear",
    [u3.ItemType.Earwear] = "Earwear",
    [u3.ItemType.Eyewear] = "Eyewear",
    [u3.ItemType.Shirt] = "Shirt",
    [u3.ItemType.Pants] = "Pants",
    [u3.ItemType.Gloves] = "Gloves",
    [u3.ItemType.Boots] = "Boots",
    [u3.ItemType.Wrist] = "Wrist",
    [u3.ItemType.Backpack] = "Backpack"
};
local u28 = {
    [u3.SlotType.Backpack] = "Backpack",
    [u3.SlotType.Primary] = "Primary",
    [u3.SlotType.Secondary] = "Secondary",
    [u3.SlotType.Melee] = "Melee",
    [u3.SlotType.Vest] = "Vest",
    [u3.SlotType.Belt] = "Belt",
    [u3.SlotType.Helmet] = "Helmet",
    [u3.SlotType.Facewear] = "Face wear",
    [u3.SlotType.Earwear] = "Ear wear",
    [u3.SlotType.Eyewear] = "Eye wear",
    [u3.SlotType.Shirt] = "Shirt",
    [u3.SlotType.Pants] = "Pants",
    [u3.SlotType.Grenade] = "Utility",
    [u3.SlotType.Gloves] = "Gloves",
    [u3.SlotType.Boots] = "Boots",
    [u3.SlotType.Wrist] = "Wrist wear"
};
local u29 = {
    {
        Color = Color3.new(1, 1, 1)
    },
    {
        Bright = true,
        White = true,
        Name = "Uncommon",
        Color = Color3.new(0, 1, 0)
    },
    {
        Bright = true,
        White = true,
        Name = "Rare",
        Color = Color3.new(1, 0.568627, 0)
    },
    {
        Bright = true,
        White = true,
        Name = "Unique",
        Color = Color3.new(1, 0, 0)
    },
    {
        Bright = true,
        White = true,
        Name = "Special",
        Color = Color3.new(0.549019, 0, 1)
    }
};
u8.Rarity = u29;
local u30 = u2.Component:extend("InventoryInterface");
local function u33(p31, p32) --[[ Line: 106 ]]
    -- upvalues: u3 (copy)
    return ({
        [u3.SlotType.Backpack] = UDim2.new(0.6, 0, 0.45, 0),
        [u3.SlotType.Primary] = UDim2.new(0.23, 0, 0.4, 0),
        [u3.SlotType.Secondary] = UDim2.new(0.23, 0, 0.45, 0),
        [u3.SlotType.Melee] = UDim2.new(0.23, 0, 0.5, 0),
        [u3.SlotType.Vest] = UDim2.new(0.4, 0, 0.45, 0),
        [u3.SlotType.Belt] = UDim2.new(0.5, 0, 0.54, 0),
        [u3.SlotType.Helmet] = UDim2.new(0.5, 0, 0.3, 0),
        [u3.SlotType.Facewear] = UDim2.new(0.5, 0, 0.35, 0),
        [u3.SlotType.Earwear] = UDim2.new(0.6, 0, 0.3, 0),
        [u3.SlotType.Eyewear] = UDim2.new(0.4, 0, 0.3, 0),
        [u3.SlotType.Shirt] = UDim2.new(0.5, 0, 0.45, 0),
        [u3.SlotType.Pants] = UDim2.new(0.5, 0, 0.64, 0),
        [u3.SlotType.Grenade] = UDim2.new(0.4 + (p32 - 1) / 10, 0, 0.59, 0),
        [u3.SlotType.Gloves] = UDim2.new(0.77, 0, 0.5, 0),
        [u3.SlotType.Boots] = UDim2.new(0.5, 0, 0.69, 0),
        [u3.SlotType.Wrist] = UDim2.new(0.77, 0, 0.45, 0)
    })[p31];
end;
local function u35(p34) --[[ Line: 129 ]]
    -- upvalues: u6 (copy), u23 (copy), u24 (copy)
    if u6.GLOBAL_SELLER then
        return u23(p34, u24[u6.GLOBAL_SELLER]);
    end;
end;
function u30._createGrids(p36, p37, p38, p39, p40) --[[ Line: 147 ]]
    -- upvalues: u2 (copy), u10 (copy)
    local v41 = p36._gridRefs[p38][p39][p40];
    local v42 = {};
    for _ = 1, p37.Size.X do
        for _ = 1, p37.Size.Y do
            local v43 = u2.createRef();
            v41[#v41 + 1] = v43;
            local v44 = #v42 + 1;
            v42[v44] = u2.createElement(u10, {
                LayoutOrder = v44,
                Ref = v43
            });
        end;
    end;
    return u2.createFragment(v42);
end;
function u30._createFunctionGrid(p45, p46, p47, p48, p49, p50, p51, p52) --[[ Line: 167 ]]
    -- upvalues: u2 (copy), u10 (copy)
    local v53 = u2.createRef();
    p45._functionRefs[p47][p48][p49][p50] = v53;
    return u2.createElement(u10, {
        Size = UDim2.fromScale(0.035, 0.035),
        Hover = p51,
        Position = p46,
        Ref = v53,
        slotType = p52,
        hovering = p45._hovering,
        draggingSignal = p45._draggingSignal,
        updHoverText = p45._updHoverText
    });
end;
function u30._getMouseInFunctionCells(p54) --[[ Line: 185 ]]
    -- upvalues: u17 (copy), l__UserInputService__2 (copy), l__GuiService__1 (copy)
    local v55 = u17.VirtualCursorPosition or l__UserInputService__2:GetMouseLocation();
    local l__X__4 = v55.X;
    local l__Y__5 = v55.Y;
    for v56, v57 in p54._functionRefs do
        for v58, v59 in v57 do
            for v60, v61 in v59 do
                for v62, v63 in v61 do
                    local v64 = v63:getValue();
                    if v64 and (v64.AbsolutePosition.X < l__X__4 and (l__X__4 < v64.AbsolutePosition.X + v64.AbsoluteSize.X and (v64.AbsolutePosition.Y + l__GuiService__1:GetGuiInset().Y < l__Y__5 and l__Y__5 < v64.AbsolutePosition.Y + v64.AbsoluteSize.Y + l__GuiService__1:GetGuiInset().Y))) then
                        return v56, v58, v60, v62;
                    end;
                end;
            end;
        end;
    end;
    return false;
end;
function u30._getClosestPos(p65, p66, p67, p68) --[[ Line: 210 ]]
    -- upvalues: u7 (copy), u14 (copy), u15 (copy), l__CurrentCamera__3 (copy)
    local v69 = Vector2.new(p67, p66);
    local v70 = (1 / 0);
    local v71 = nil;
    local v72 = nil;
    local v73 = nil;
    local v74 = nil;
    local v75 = nil;
    for v76, v77 in p65._gridRefs do
        local v78 = u7.Inventories[v76];
        for v79, v80 in v77 do
            local v81 = u14[v78.Storages[v79].StorageName];
            for v82, v83 in v80 do
                local l__Size__6 = v81.Sections[v82].Size;
                for v84 = 1, l__Size__6.X - p68.X + 1 do
                    for v85 = 1, l__Size__6.Y - p68.Y + 1 do
                        local v86 = v83[u15.PositionToNumber(v84, v85, l__Size__6.Y)];
                        if v86 then
                            local v87 = v86:getValue();
                            if v87 then
                                local l__Magnitude__7 = (v69 - v87.AbsolutePosition).Magnitude;
                                if l__Magnitude__7 < v70 then
                                    v75 = v85;
                                    v74 = v84;
                                    v73 = v82;
                                    v72 = v79;
                                    v71 = v76;
                                    v70 = l__Magnitude__7;
                                end;
                            end;
                        end;
                    end;
                end;
            end;
        end;
    end;
    if v70 < l__CurrentCamera__3.ViewportSize.Y * 0.035 then
        return v71, v72, v73, v74, v75;
    else
        return false;
    end;
end;
function u30._getRef(p88, p89, p90, p91, p92) --[[ Line: 257 ]]
    local v93 = p88._functionRefs and p88._functionRefs[p89] and (p88._functionRefs[p89][p90] and p88._functionRefs[p89][p90][p91]);
    if v93 then
        v93 = p88._functionRefs[p89][p90][p91][p92];
    end;
    local v94 = p88._gridRefs and p88._gridRefs[p89] and (p88._gridRefs[p89][p90] and p88._gridRefs[p89][p90][p91]);
    if v94 then
        v94 = p88._gridRefs[p89][p90][p91][p92];
    end;
    return v93 and true, v93 or v94;
end;
function u30._putPreview(p95, p96, p97, p98, p99) --[[ Line: 269 ]]
    -- upvalues: l__GuiService__1 (copy), u7 (copy), u2 (copy), u8 (copy), l__CurrentCamera__3 (copy)
    local l___dragging__8 = p95._dragging;
    if p99 and l___dragging__8 then
        local l__Size__9 = l___dragging__8.Item.Layout.Size;
        local v100, v101 = p95:_getRef(p96, p97, p98, p99);
        if v101 and v101:getValue() then
            p95.UpdDraggingPreviewSize(v100 and UDim2.fromScale(0.035, 0.035) or UDim2.fromScale(0.035 * l__Size__9.X, 0.035 * l__Size__9.Y));
            local v102 = v101:getValue().AbsolutePosition + l__GuiService__1:GetGuiInset();
            p95.UpdDraggingPreviewPosition(UDim2.new(0, v102.X, 0, v102.Y));
            p95.UpdDraggingPreviewValid(u7:CanMoveItem(l___dragging__8.InvID, l___dragging__8.StorageID, l___dragging__8.SectionIDX, l___dragging__8.PosN, p96, p97, p98, p99, l___dragging__8.Item.Rotated ~= p95.DraggingRotated:getValue()));
            if not p95._preview then
                p95._preview = u2.mount(u2.createElement(u8, {
                    Preview = true,
                    TweenPosition = true,
                    CellSize = 0.035,
                    ValidLocation = p95.DraggingPreviewValid,
                    Item = l___dragging__8.Item,
                    Rotated = p95.DraggingRotated,
                    SectionSize = l__CurrentCamera__3.ViewportSize,
                    Size = p95.DraggingPreviewSize,
                    Position = p95.DraggingPreviewPosition
                }), p95._ui);
            end;
        elseif p95._preview then
            u2.unmount(p95._preview);
            p95._preview = nil;
        end;
    elseif p95._preview then
        u2.unmount(p95._preview);
        p95._preview = nil;
    end;
end;
function u30._createDraggingImage(p103, p104) --[[ Line: 308 ]]
    -- upvalues: u2 (copy), u8 (copy), l__CurrentCamera__3 (copy)
    local l__Size__10 = p104.Layout.Size;
    return u2.createElement(u8, {
        Dragging = true,
        CellSize = 0.035,
        Item = p104,
        Rotated = p103.DraggingRotated,
        SectionSize = l__CurrentCamera__3.ViewportSize,
        Size = UDim2.fromScale(0.035 * l__Size__10.X, 0.035 * l__Size__10.Y),
        Position = p103.DraggingBinding,
        Ref = p103.DraggingRef
    });
end;
function u30._createDraggingKey(p105, p106, p107, p108, p109, p110, p111, p112, p113) --[[ Line: 325 ]]
    p105._dragging = {
        MouseOffset = p112,
        Handle = p111,
        InvID = p106,
        StorageID = p107,
        SectionIDX = p108,
        PosN = p109,
        Item = p110,
        Callback = p113
    };
    p105._draggingSignal:Fire(p105._dragging);
end;
local function u125(p114, p115) --[[ Line: 340 ]]
    -- upvalues: u14 (copy)
    for v116, v117 in pairs(p114.Storages) do
        local v118 = u14[v117.StorageName];
        for v119, v120 in pairs(v117.Sections) do
            local v121 = v118.Sections[v119];
            if v121.FunctionCells then
                for v122 = 1, #v121.FunctionCells do
                    local v123 = v121.FunctionCells[v122];
                    local v124 = v121.Size.X * v121.Size.Y + v122;
                    if not v120[v124] and v123 == p115 then
                        return v116, v119, v124;
                    end;
                end;
            end;
        end;
    end;
    return false;
end;
function u30.GetShiftClickDestination(p126, p127, p128, p129, p130) --[[ Line: 362 ]]
    -- upvalues: u7 (copy), u16 (copy), u14 (copy), u125 (copy)
    local v131 = nil;
    local v132 = nil;
    local v133 = nil;
    for _, v134 in u7.Inventories do
        local l__Main__11 = v134.Main;
        if l__Main__11 then
            v132 = v134;
        end;
        if v134.ID == p127 then
            v131 = v134;
        elseif not l__Main__11 then
            v133 = v134;
        end;
    end;
    local v135 = u16.IsEquipPosition(p130, u14[v131.Storages[p128].StorageName].Sections[p129].Size);
    local l__SlotType__12 = p126.Layout.SlotType;
    if not v135 then
        local v136, v137, v138 = u125(v132, l__SlotType__12);
        if v136 then
            return v132.ID, v136, v137, v138, true;
        end;
        for _, v139 in u7.Inventories do
            if v139.ID ~= v132.ID then
                local v140, v141, v142 = u125(v139, l__SlotType__12);
                if v140 then
                    return v139.ID, v140, v141, v142, true;
                end;
            end;
        end;
    end;
    if v133 then
        local v143, v144, v145 = u16.AddItem(v133, p126, nil, nil, true);
        if v143 then
            return v133.ID, v143, v144, v145;
        end;
    end;
    local v146, v147, v148 = u16.AddItem(v132, p126, nil, nil, true);
    if v146 then
        return v132.ID, v146, v147, v148;
    end;
    for _, v149 in u7.Inventories do
        if v149.ID ~= v132.ID then
            local v150, v151, v152 = u16.AddItem(v149, p126, nil, nil, true);
            if v150 then
                return v149.ID, v150, v151, v152;
            end;
        end;
    end;
    return false;
end;
function u30._createItems(u153, p154, p155, u156, u157, u158, p159) --[[ Line: 434 ]]
    -- upvalues: u15 (copy), u28 (copy), u2 (copy), u8 (copy), u17 (copy), u21 (copy), u35 (copy), l__UserInputService__2 (copy), u3 (copy), u30 (copy), u27 (copy), u18 (copy), u7 (copy), l__GuiService__1 (copy)
    local v160 = {};
    for u161, u162 in p155 do
        local l__Size__13 = u162.Layout.Size;
        local v163, v164 = u15.NumberToPosition(u161, p154.Size.Y);
        if p154.Size.X >= v163 then
            local u165 = u28[u162.Layout.SlotType];
            v160[u162.MetaData.UID] = u2.createElement(u8, {
                Nested = true,
                CellSize = 0.035,
                draggingSignal = u153._draggingSignal,
                Hovering = u153._hovering,
                Item = u162,
                SectionSize = p159,
                Size = UDim2.fromScale(l__Size__13.X / p159.X, l__Size__13.Y / p159.Y),
                Position = UDim2.fromScale((v163 - 1) / p159.X, (v164 - 1) / p159.Y),
                Hover = function(p166, p167) --[[ Name: Hover, Line 456 ]]
                    -- upvalues: u17 (ref), u162 (copy), u153 (copy), u21 (ref), u165 (copy), u35 (ref)
                    if p166 then
                        local l__CompatibleItems__14 = u17.CompatibleItems;
                        if l__CompatibleItems__14 and table.find(l__CompatibleItems__14, u162.Name) then
                            u17.HoverItem = u162.MetaData.UID;
                            p167 = "Press [" .. u17:GetBind("Reload").Name .. "] to load this item";
                        else
                            u17.HoverItem = nil;
                        end;
                        u153._updHoverText({
                            "<b>" .. p166 .. "</b> (" .. u21(u162:GetWeight()) .. ")",
                            p167,
                            u165,
                            u162.Layout.Rarity or (u162.MetaData.Rarity or 1),
                            u35(u162)
                        });
                    else
                        u17.HoverItem = nil;
                        u153._updHoverText();
                    end;
                end,
                MouseDown = function(p168, p169) --[[ Name: MouseDown, Line 472 ]]
                    -- upvalues: u153 (copy), l__UserInputService__2 (ref), u3 (ref), u30 (ref), u162 (copy), u156 (copy), u157 (copy), u158 (copy), u161 (copy), u27 (ref), u18 (ref), u7 (ref), u17 (ref), l__GuiService__1 (ref), u2 (ref)
                    u153:_clearDragging();
                    if l__UserInputService__2:IsKeyDown(u3.KeyCode.LeftShift) then
                        local v170, v171, v172, v173, v174 = u30.GetShiftClickDestination(u162, u156, u157, u158, u161);
                        if v170 then
                            if u27[u162.Layout.ItemType] then
                                u18:CreateSound("Button", nil, true, "InventorySounds", u27[u162.Layout.ItemType], u162.MetaData.SoundProfile or "Default", v174 and "Equip" or "Place").Destroy(2);
                            end;
                            u153._updHoverText();
                            u7:MoveItem(u156, u157, u158, u161, v170, v171, v172, v173);
                            return true;
                        end;
                    else
                        local v175 = u17.VirtualCursorPosition or l__UserInputService__2:GetMouseLocation();
                        local v176 = p168.AbsolutePosition + p168.AbsoluteSize / 2 - Vector2.new(v175.X, v175.Y) + l__GuiService__1:GetGuiInset();
                        u153.UpdDraggingRotated(u162.Rotated);
                        local v177 = u153:_createDraggingImage(u162);
                        local l__UpdDraggingBinding__15 = u153.UpdDraggingBinding;
                        local v178 = u17.VirtualCursorPosition or l__UserInputService__2:GetMouseLocation();
                        l__UpdDraggingBinding__15(UDim2.new(0, v178.X + v176.X, 0, v178.Y + v176.Y));
                        local v179 = u2.mount(v177, u153._ui);
                        if u27[u162.Layout.ItemType] then
                            u18:CreateSound("Button", nil, true, "InventorySounds", u27[u162.Layout.ItemType], u162.MetaData.SoundProfile or "Default", "Pickup").Destroy(2);
                        end;
                        u153:_createDraggingKey(u156, u157, u158, u161, u162, v179, v176, p169);
                    end;
                end
            });
        end;
    end;
    return u2.createFragment(v160);
end;
function u30._createFunctionItem(u180, p181, u182, u183, u184, u185, u186) --[[ Line: 511 ]]
    -- upvalues: u28 (copy), u2 (copy), u8 (copy), u17 (copy), u21 (copy), u35 (copy), l__UserInputService__2 (copy), u3 (copy), u30 (copy), u27 (copy), u18 (copy), u7 (copy), l__GuiService__1 (copy)
    local u187 = u28[u186.Layout.SlotType];
    return u2.createElement(u8, {
        Item = u186,
        Position = p181,
        Size = UDim2.fromScale(0.035, 0.035),
        Hover = function(p188, p189) --[[ Name: Hover, Line 518 ]]
            -- upvalues: u17 (ref), u180 (copy), u21 (ref), u186 (copy), u187 (copy), u35 (ref)
            u17.HoverItem = nil;
            if p188 then
                u180._updHoverText({
                    "<b>" .. p188 .. "</b> (" .. u21(u186:GetWeight()) .. ")",
                    p189,
                    u187,
                    u186.Layout.Rarity or (u186.MetaData.Rarity or 1),
                    u35(u186)
                });
            else
                u180._updHoverText();
            end;
        end,
        MouseDown = function(p190, p191) --[[ Name: MouseDown, Line 527 ]]
            -- upvalues: u180 (copy), l__UserInputService__2 (ref), u3 (ref), u30 (ref), u186 (copy), u182 (copy), u183 (copy), u184 (copy), u185 (copy), u27 (ref), u18 (ref), u7 (ref), u17 (ref), l__GuiService__1 (ref), u2 (ref)
            u180:_clearDragging();
            if l__UserInputService__2:IsKeyDown(u3.KeyCode.LeftShift) then
                local v192, v193, v194, v195 = u30.GetShiftClickDestination(u186, u182, u183, u184, u185);
                if v192 then
                    if u27[u186.Layout.ItemType] then
                        u18:CreateSound("Button", nil, true, "InventorySounds", u27[u186.Layout.ItemType], u186.MetaData.SoundProfile or "Default", "Place").Destroy(2);
                    end;
                    u180._updHoverText();
                    u7:MoveItem(u182, u183, u184, u185, v192, v193, v194, v195);
                end;
            else
                local v196 = u17.VirtualCursorPosition or l__UserInputService__2:GetMouseLocation();
                local v197 = p190.AbsolutePosition + p190.AbsoluteSize / 2 - Vector2.new(v196.X, v196.Y) + l__GuiService__1:GetGuiInset();
                u180.UpdDraggingRotated(u186.Rotated);
                local v198 = u180:_createDraggingImage(u186, nil);
                local l__UpdDraggingBinding__16 = u180.UpdDraggingBinding;
                local v199 = u17.VirtualCursorPosition or l__UserInputService__2:GetMouseLocation();
                l__UpdDraggingBinding__16(UDim2.new(0, v199.X + v197.X, 0, v199.Y + v197.Y));
                local v200 = u2.mount(v198, u180._ui);
                if u27[u186.Layout.ItemType] then
                    u18:CreateSound("Button", nil, true, "InventorySounds", u27[u186.Layout.ItemType], u186.MetaData.SoundProfile or "Default", "Pickup").Destroy(2);
                end;
                u180:_createDraggingKey(u182, u183, u184, u185, u186, v200, v197, p191);
            end;
        end
    });
end;
function u30._clearDragging(p201) --[[ Line: 564 ]]
    -- upvalues: u2 (copy)
    if p201._dragging then
        p201._dragging.Callback();
        u2.unmount(p201._dragging.Handle);
    end;
    p201._dragging = nil;
    p201._draggingSignal:Fire(nil);
end;
function u30._refreshDragger(p202) --[[ Line: 574 ]]
    -- upvalues: u7 (copy)
    local l___dragging__17 = p202._dragging;
    if l___dragging__17 then
        local v203 = u7.Inventories[l___dragging__17.InvID];
        if v203 then
            local v204 = v203.Storages[l___dragging__17.StorageID];
            if v204 then
                local v205 = v204.Sections[l___dragging__17.SectionIDX];
                if v205 then
                    local v206 = v205[l___dragging__17.PosN];
                    if l___dragging__17.Item and v206.Name == l___dragging__17.Item.Name then
                        l___dragging__17.Item = v206;
                        p202._draggingSignal:Fire(l___dragging__17);
                    else
                        p202:_clearDragging();
                    end;
                else
                    p202:_clearDragging();
                end;
            else
                p202:_clearDragging();
            end;
        else
            p202:_clearDragging();
        end;
    end;
end;
function u30.init(u207, p208) --[[ Line: 608 ]]
    -- upvalues: u2 (copy), u13 (copy), u4 (copy), u17 (copy), l__UserInputService__2 (copy), u16 (copy), u15 (copy), u14 (copy), u7 (copy), u27 (copy), u18 (copy), u3 (copy), u12 (copy)
    local v209, v210 = u2.createBinding(UDim2.new());
    u207.DraggingBinding = v209;
    u207.UpdDraggingBinding = v210;
    local v211, v212 = u2.createBinding(false);
    u207.DraggingRotated = v211;
    u207.UpdDraggingRotated = v212;
    local v213, v214 = u2.createBinding();
    u207.DraggingPreviewSize = v213;
    u207.UpdDraggingPreviewSize = v214;
    local v215, v216 = u2.createBinding();
    u207.DraggingPreviewPosition = v215;
    u207.UpdDraggingPreviewPosition = v216;
    local v217, v218 = u2.createBinding();
    u207.DraggingPreviewValid = v217;
    u207.UpdDraggingPreviewValid = v218;
    u207.DraggingRef = u2.createRef();
    local l__HoverText__18 = p208.HoverText;
    local l__UpdateHoverText__19 = p208.UpdateHoverText;
    u207._hoverText = l__HoverText__18;
    u207._updHoverText = l__UpdateHoverText__19;
    local v219, v220 = u2.createBinding(UDim2.new());
    u207._hoverPos = v219;
    u207._updHoverPos = v220;
    u207._dropItem = u13.new(0);
    u207._hovering = u4.new();
    u207._draggingSignal = u4.new();
    u207._fade = p208.Fade;
    u207._gridRefs = {};
    u207._functionRefs = {};
    u207._ui = p208.UI;
    u207._update = p208.Update:Connect(function(_) --[[ Line: 627 ]]
        -- upvalues: u207 (copy), u17 (ref), l__UserInputService__2 (ref), u16 (ref), u15 (ref), u14 (ref), u7 (ref)
        local l___dragging__20 = u207._dragging;
        if l___dragging__20 then
            local l__UpdDraggingBinding__21 = u207.UpdDraggingBinding;
            local l__MouseOffset__22 = l___dragging__20.MouseOffset;
            local v221 = u17.VirtualCursorPosition or l__UserInputService__2:GetMouseLocation();
            l__UpdDraggingBinding__21(UDim2.new(0, v221.X + l__MouseOffset__22.X, 0, v221.Y + l__MouseOffset__22.Y));
            local v222 = true;
            local v223, v224, v225, v226 = u207:_getMouseInFunctionCells();
            if v223 then
                v222 = false;
            else
                local v227 = u207.DraggingRef:getValue();
                if v227 then
                    local l__AbsolutePosition__23 = v227.AbsolutePosition;
                    local v228, v229;
                    v223, v224, v225, v228, v229 = u207:_getClosestPos(l__AbsolutePosition__23.Y, l__AbsolutePosition__23.X, u16.GetSize(l___dragging__20.Item, u207.DraggingRotated:getValue()));
                    if v223 then
                        v226 = u15.PositionToNumber(v228, v229, u14[u7.Inventories[v223].Storages[v224].StorageName].Sections[v225].Size.Y);
                        v222 = false;
                    end;
                else
                    v222 = false;
                end;
            end;
            if u207._droppingItem ~= v222 then
                u207._dropItem:SetGoal(v222 and 1 or 0);
                u207._droppingItem = v222;
            end;
            u207:_putPreview(v223, v224, v225, v226);
        else
            u207:_putPreview(nil);
        end;
        local l___updHoverPos__24 = u207._updHoverPos;
        local v230 = Vector2.new();
        local v231 = u17.VirtualCursorPosition or l__UserInputService__2:GetMouseLocation();
        l___updHoverPos__24(UDim2.new(0, v231.X + v230.X, 0, v231.Y + v230.Y));
    end);
    u207._changed = u7.OnInterfaceStateChanged:Connect(function() --[[ Line: 664 ]]
        -- upvalues: u207 (copy)
        u207:_refreshDragger();
        u207:setState({});
    end);
    local function u244() --[[ Line: 669 ]]
        -- upvalues: u207 (copy), u27 (ref), u18 (ref), u7 (ref), u16 (ref), u15 (ref), u14 (ref)
        local l___dragging__25 = u207._dragging;
        if l___dragging__25 then
            u207._dropItem:SetGoal(0);
            local l__Item__26 = l___dragging__25.Item;
            local v232 = true;
            local v233, v234, v235, v236 = u207:_getMouseInFunctionCells();
            if v233 then
                u207:_clearDragging();
                if u27[l__Item__26.Layout.ItemType] then
                    u18:CreateSound("Button", nil, true, "InventorySounds", u27[l__Item__26.Layout.ItemType], l__Item__26.MetaData.SoundProfile or "Default", "Equip").Destroy(2);
                end;
                u7:MoveItem(l___dragging__25.InvID, l___dragging__25.StorageID, l___dragging__25.SectionIDX, l___dragging__25.PosN, v233, v234, v235, v236, l___dragging__25.Item.Rotated ~= u207.DraggingRotated:getValue());
                v232 = false;
            else
                local v237 = u207.DraggingRef:getValue();
                if not v237 then
                    u207:_clearDragging();
                    return;
                end;
                if u27[l__Item__26.Layout.ItemType] then
                    u18:CreateSound("Button", nil, true, "InventorySounds", u27[l__Item__26.Layout.ItemType], l__Item__26.MetaData.SoundProfile or "Default", "Place").Destroy(2);
                end;
                local l__AbsolutePosition__27 = v237.AbsolutePosition;
                local v238, v239, v240, v241, v242 = u207:_getClosestPos(l__AbsolutePosition__27.Y, l__AbsolutePosition__27.X, u16.GetSize(l___dragging__25.Item, u207.DraggingRotated:getValue()));
                u207:_clearDragging();
                if v238 then
                    local v243 = u15.PositionToNumber(v241, v242, u14[u7.Inventories[v238].Storages[v239].StorageName].Sections[v240].Size.Y);
                    u7:MoveItem(l___dragging__25.InvID, l___dragging__25.StorageID, l___dragging__25.SectionIDX, l___dragging__25.PosN, v238, v239, v240, v243, l___dragging__25.Item.Rotated ~= u207.DraggingRotated:getValue());
                    v232 = false;
                end;
            end;
            if v232 then
                u7:DropItem(l___dragging__25.InvID, l___dragging__25.StorageID, l___dragging__25.SectionIDX, l___dragging__25.PosN);
            end;
        end;
    end;
    u207._input = l__UserInputService__2.InputEnded:Connect(function(p245, _) --[[ Line: 717 ]]
        -- upvalues: u3 (ref), u244 (copy)
        if p245.UserInputType == u3.UserInputType.MouseButton1 or p245.UserInputType == u3.UserInputType.Touch then
            u244();
        end;
    end);
    u207._input2 = l__UserInputService__2.InputBegan:Connect(function(p246, _) --[[ Line: 722 ]]
        -- upvalues: u3 (ref), u207 (copy), u27 (ref), u18 (ref), u244 (copy)
        if p246.KeyCode == u3.KeyCode.R or p246.KeyCode == u3.KeyCode.ButtonX then
            local l___dragging__28 = u207._dragging;
            if l___dragging__28 then
                u207.UpdDraggingRotated(not u207.DraggingRotated:getValue());
                u207:_refreshDragger();
                local l__Item__29 = l___dragging__28.Item;
                if u27[l__Item__29.Layout.ItemType] then
                    u18:CreateSound("Button", nil, true, "InventorySounds", u27[l__Item__29.Layout.ItemType], l__Item__29.MetaData.SoundProfile or "Default", "Pickup").Destroy(2);
                end;
            end;
        elseif p246.KeyCode == u3.KeyCode.ButtonA then
            u244();
        end;
    end);
    u207.BlurEffect = u12:AddBlur({
        Size = u207._fade:Map(function(p247) --[[ Line: 741 ]]
            return p247 * 15;
        end)
    }, nil, true);
    u207.ColorEffect = u12:AddColorCorrection({
        Saturation = u207._fade:Map(function(p248) --[[ Line: 746 ]]
            return -p248;
        end),
        Constrast = u207._fade:Map(function(p249) --[[ Line: 749 ]]
            return -(p249 * 0.5);
        end),
        Brightness = u207._fade:Map(function(p250) --[[ Line: 752 ]]
            return -(p250 * 0.1);
        end)
    }, nil, true);
    u207:setState({
        worldFunctionCells = false
    });
end;
function u30.willUnmount(p251) --[[ Line: 762 ]]
    p251.BlurEffect.Destroy();
    p251.ColorEffect.Destroy();
    p251._update:Disconnect();
    p251._changed:Disconnect();
    p251._input:Disconnect();
    p251._input2:Disconnect();
end;
function u30.render(u252) --[[ Line: 772 ]]
    -- upvalues: u7 (copy), u2 (copy), u3 (copy), u9 (copy), u14 (copy), u33 (copy), u28 (copy), u25 (copy), u21 (copy), u19 (copy), u5 (copy), u18 (copy), u11 (copy), u17 (copy), u29 (copy), u26 (copy), u22 (copy), u20 (copy), u6 (copy)
    local v253 = u7:GetMain();
    if v253 then
        local v254 = { u2.createElement("UIListLayout", {
                SortOrder = u3.SortOrder.LayoutOrder,
                FillDirection = u3.FillDirection.Vertical,
                VerticalAlignment = u3.VerticalAlignment.Center,
                HorizontalAlignment = u3.HorizontalAlignment.Left,
                Padding = UDim.new(0.02, 0)
            }) };
        local v255 = { u2.createElement("UIListLayout", {
                SortOrder = u3.SortOrder.LayoutOrder,
                FillDirection = u3.FillDirection.Vertical,
                VerticalAlignment = u3.VerticalAlignment.Center,
                HorizontalAlignment = u3.HorizontalAlignment.Right,
                Padding = UDim.new(0.02, 0)
            }) };
        local v256 = {};
        local v257 = {};
        local l__Payload__30 = u252.props.Payload;
        if l__Payload__30 then
            v255[#v255 + 1] = u2.createElement(u9, {
                CellSize = 0.035,
                Main = v253,
                Payload = l__Payload__30
            });
        end;
        local v258 = {};
        local v259 = false;
        local l__worldFunctionCells__31 = u252.state.worldFunctionCells;
        local v260 = 0;
        local l__Enabled__32 = u252.props.Enabled;
        local v261 = nil;
        if l__Enabled__32 then
            local l___gridRefs__33 = u252._gridRefs;
            local l___functionRefs__34 = u252._functionRefs;
            for v262, v263 in u7.Inventories do
                local l__Main__35 = v263.Main;
                if l__Main__35 or not l__Payload__30 then
                    l___gridRefs__33[v262] = {};
                    l___functionRefs__34[v262] = {};
                    local v264 = l__Main__35 and v254 and v254 or v255;
                    for v265, v266 in v263.Storages do
                        l___gridRefs__33[v262][v265] = {};
                        l___functionRefs__34[v262][v265] = {};
                        if not l__Main__35 then
                            v261 = v266.StorageName;
                        end;
                        local v267 = u14[v266.StorageName];
                        for v268, v269 in v266.Sections do
                            l___gridRefs__33[v262][v265][v268] = {};
                            l___functionRefs__34[v262][v265][v268] = {};
                            local v270 = v267.Sections[v268];
                            if v270.FunctionCells then
                                if l__Main__35 or l__worldFunctionCells__31 then
                                    local v271 = {};
                                    local v272 = l__Main__35 and v257 and v257 or v256;
                                    for v273 = 1, #v270.FunctionCells do
                                        local v274 = v270.FunctionCells[v273];
                                        if not v271[v274] then
                                            v271[v274] = 0;
                                        end;
                                        v271[v274] = v271[v274] + 1;
                                        local v275 = v271[v274];
                                        local v276 = v269[v270.Size.X * v270.Size.Y + v273];
                                        if v276 then
                                            local v277 = u33(v274, v275);
                                            local v278 = u252:_createFunctionGrid(v277, v262, v265, v268, v270.Size.X * v270.Size.Y + v273);
                                            local v279 = u252:_createFunctionItem(v277, v262, v265, v268, v270.Size.X * v270.Size.Y + v273, v276);
                                            v272[#v272 + 1] = v278;
                                            v272[#v272 + 1] = v279;
                                        else
                                            local v280 = u252:_createFunctionGrid(u33(v274, v275), v262, v265, v268, v270.Size.X * v270.Size.Y + v273, u28[v274], v274);
                                            v272[#v272 + 1] = v280;
                                        end;
                                    end;
                                end;
                                if not l__Main__35 then
                                    v259 = true;
                                end;
                            end;
                            if not l__worldFunctionCells__31 or (not v259 or l__Main__35) then
                                local v281 = 0;
                                for _, v282 in v269 do
                                    v281 = v281 + v282:GetWeight();
                                end;
                                if l__Main__35 then
                                    v260 = v260 + v281;
                                end;
                                local v283 = Color3.new(0.22745, 0.70196, 0.22745);
                                local v284 = Color3.new(0.721568, 0.035294, 0.035294);
                                local v285 = math.max(v281 - 15000, 0) / 10000;
                                local v286 = v283:Lerp(v284, (math.clamp(v285, 0, 1)));
                                local v287 = #v264 + 1;
                                local v288 = 0.035 * v270.Size.Y;
                                local v289 = 0.035 * v270.Size.X;
                                local v290 = 0.023333333333333334 / v288;
                                local v291 = Color3.fromRGB(105, 105, 105);
                                local l__createElement__36 = u2.createElement;
                                local v292 = "Frame";
                                local v293 = {
                                    BackgroundTransparency = 1,
                                    LayoutOrder = v287,
                                    SizeConstraint = u3.SizeConstraint.RelativeYY,
                                    Size = UDim2.fromScale(v289, v288 + 0.023333333333333334)
                                };
                                local v294 = {};
                                local l__createElement__37 = u2.createElement;
                                local v295 = "ImageLabel";
                                local v296 = {
                                    Image = "rbxassetid://13867926930",
                                    BorderSizePixel = 0,
                                    ZIndex = 2,
                                    TileSize = UDim2.fromOffset(64, 64),
                                    ScaleType = u3.ScaleType.Tile,
                                    Size = UDim2.new(1, 0, v290, -2),
                                    ImageColor3 = v291:Lerp(Color3.new(), 0.2)
                                };
                                local v297 = {
                                    Corner = u2.createElement("UICorner", {
                                        CornerRadius = UDim.new(0, 1)
                                    }),
                                    Gradient = u2.createElement("UIGradient", {
                                        Rotation = -90,
                                        Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(112, 112, 112)), ColorSequenceKeypoint.new(1, Color3.fromRGB(54, 54, 54)) })
                                    }),
                                    Stroke = u2.createElement("UIStroke", {
                                        Thickness = 1,
                                        ApplyStrokeMode = u3.ApplyStrokeMode.Contextual,
                                        Color = v291,
                                        LineJoinMode = u3.LineJoinMode.Round
                                    })
                                };
                                local v298 = u2.createElement("Frame", {
                                    BackgroundTransparency = 1,
                                    Size = UDim2.fromScale(0.5, 1),
                                    SizeConstraint = u3.SizeConstraint.RelativeYY
                                }, { u2.createElement("TextLabel", {
                                        BackgroundTransparency = 1,
                                        TextScaled = true,
                                        Size = UDim2.fromScale(100, 0.75),
                                        Position = UDim2.fromScale(1, 0.5),
                                        AnchorPoint = Vector2.new(0, 0.5),
                                        Text = v270.Name:upper(),
                                        TextXAlignment = u3.TextXAlignment.Left,
                                        TextColor3 = v291,
                                        FontFace = u25
                                    }) });
                                local v299;
                                if l__Main__35 then
                                    v299 = u2.createElement("Frame", {
                                        BackgroundTransparency = 1,
                                        Size = UDim2.fromScale(1, 1),
                                        Position = UDim2.fromScale(1, 0),
                                        AnchorPoint = Vector2.new(1, 0),
                                        SizeConstraint = u3.SizeConstraint.RelativeYY
                                    }, { u2.createElement("ImageLabel", {
                                            BackgroundTransparency = 1,
                                            Image = "rbxassetid://104565034609171",
                                            Size = UDim2.fromScale(0.5, 0.5),
                                            Position = UDim2.fromScale(0.4, 0.5),
                                            AnchorPoint = Vector2.new(0.5, 0.5),
                                            SizeConstraint = u3.SizeConstraint.RelativeYY,
                                            ImageColor3 = v286
                                        }), u2.createElement("TextLabel", {
                                            BackgroundTransparency = 1,
                                            TextScaled = true,
                                            Size = UDim2.fromScale(100, 0.5),
                                            Position = UDim2.fromScale(0, 0.5),
                                            AnchorPoint = Vector2.new(1, 0.5),
                                            Text = u21(v281),
                                            TextXAlignment = u3.TextXAlignment.Right,
                                            TextColor3 = v286,
                                            FontFace = u25
                                        }) });
                                else
                                    v299 = l__Main__35;
                                end;
                                v297[1], v297[2] = v298, v299;
                                v294[1], v294[2] = l__createElement__37(v295, v296, v297), u2.createElement("Frame", {
    BackgroundTransparency = 1,
    ZIndex = 1,
    Size = UDim2.fromScale(1, 1 - v290),
    Position = UDim2.fromScale(0, 1),
    AnchorPoint = Vector2.new(0, 1)
}, { u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 1, 0)
    }, { u2.createElement("UIGridLayout", {
            CellSize = UDim2.fromScale(1 / v270.Size.X, 1 / v270.Size.Y),
            CellPadding = UDim2.fromOffset(0, 0),
            FillDirection = u3.FillDirection.Vertical,
            SortOrder = u3.SortOrder.LayoutOrder
        }), u252:_createGrids(v270, v262, v265, v268) }), u2.createElement("Frame", {
        BackgroundTransparency = 1,
        ZIndex = 2,
        Size = UDim2.new(1, 0, 1, 0)
    }, { u252:_createItems(v270, v269, v262, v265, v268, v270.Size) }) });
                                v264[v287] = l__createElement__36(v292, v293, v294);
                            end;
                        end;
                    end;
                end;
            end;
        else
            u252:_clearDragging();
            u252._gridRefs = {};
            u252._functionRefs = {};
        end;
        if u252._open or not l__Enabled__32 then
            if u252._open and not l__Enabled__32 then
                if not u252._cancelBag then
                    u18:CreateSound("Button", nil, true, "UISounds", "InventoryClose").Destroy(4);
                end;
                u252._cancelBag = nil;
            end;
        elseif v261 and u19[v261] then
            u252._cancelBag = true;
            u5:Get("Sound", "ContainerSounds", v261, "Close"):Preload();
        else
            u18:CreateSound("Button", nil, true, "UISounds", "InventoryOpen").Destroy(4);
        end;
        u252._open = l__Enabled__32;
        if v259 then
            if l__worldFunctionCells__31 then
                v255 = u252:_generateCharacter(l__Enabled__32, v256);
            end;
            v258 = { u2.createElement(u11, {
                    Name = "Inventory",
                    SizeConstraint = u3.SizeConstraint.RelativeXX,
                    Size = UDim2.fromScale(0.29, 0.05),
                    Position = UDim2.fromScale(0.2, 0.77),
                    Activated = not l__worldFunctionCells__31,
                    Callback = function() --[[ Name: Callback, Line 1036 ]]
                        -- upvalues: u252 (copy)
                        u252:setState({
                            worldFunctionCells = false
                        });
                    end
                }), u2.createElement(u11, {
                    Name = "Gear",
                    AnchorPoint = Vector2.new(1, 0),
                    SizeConstraint = u3.SizeConstraint.RelativeXX,
                    Size = UDim2.fromScale(0.29, 0.05),
                    Position = UDim2.fromScale(0.8, 0.77),
                    Activated = l__worldFunctionCells__31,
                    Callback = function() --[[ Name: Callback, Line 1049 ]]
                        -- upvalues: u252 (copy)
                        u252:setState({
                            worldFunctionCells = true
                        });
                    end
                }) };
        end;
        local v300 = Color3.new(0.22745, 0.70196, 0.22745);
        local v301 = Color3.new(0.721568, 0.035294, 0.035294);
        local v302 = math.max(v260 - 15000, 0) / 10000;
        local v303 = v300:Lerp(v301, (math.clamp(v302, 0, 1)));
        local l__Name__38 = u17:GetBind("Inventory").Name;
        local l__createFragment__39 = u2.createFragment;
        local v304 = {};
        local v305;
        if l__Enabled__32 then
            v305 = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ZIndex = 2,
                Size = UDim2.fromScale(0.1, 0.05),
                AnchorPoint = Vector2.new(0, 1),
                Position = u252._hoverPos,
                Visible = u252._hoverText:map(function(p306) --[[ Line: 1067 ]]
                    return p306 and true or false;
                end)
            }, {
                Layout = u2.createElement("UIListLayout", {
                    FillDirection = u3.FillDirection.Vertical,
                    HorizontalAlignment = u3.HorizontalAlignment.Right,
                    SortOrder = u3.SortOrder.LayoutOrder,
                    VerticalAlignment = u3.VerticalAlignment.Bottom,
                    Padding = UDim.new(0, 0)
                }),
                u2.createElement("Frame", {
                    BackgroundTransparency = 0.5,
                    LayoutOrder = 1,
                    Size = UDim2.fromScale(1, 0.4),
                    BackgroundColor3 = u252._hoverText:map(function(p307) --[[ Line: 1083 ]]
                        -- upvalues: u29 (ref)
                        if p307 and p307[4] then
                            return u29[p307[4]].Color;
                        else
                            return Color3.new(1, 1, 1);
                        end;
                    end),
                    Visible = u252._hoverText:map(function(p308) --[[ Line: 1091 ]]
                        return p308 and (p308[3] or p308[4] > 1) and true or false;
                    end)
                }, {
                    u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        Size = UDim2.fromScale(0.9, 0.8),
                        Position = UDim2.fromScale(0.1, 0.1),
                        AnchorPoint = Vector2.new(0, 0),
                        Text = u252._hoverText:map(function(p309) --[[ Line: 1103 ]]
                            -- upvalues: u29 (ref)
                            local v310 = "";
                            local v311;
                            if p309 then
                                v311 = p309[3];
                                local v312 = p309[4];
                                if v312 and v312 > 1 then
                                    v310 = u29[v312].Name;
                                end;
                                if v311 then
                                    if v312 and v312 > 1 then
                                        return v310 .. " (" .. v311 .. ")";
                                    end;
                                else
                                    v311 = v310;
                                end;
                            else
                                v311 = v310;
                            end;
                            return v311;
                        end),
                        TextXAlignment = u3.TextXAlignment.Left,
                        TextColor3 = u252._hoverText:map(function(p313) --[[ Line: 1123 ]]
                            -- upvalues: u29 (ref)
                            if p313 and p313[4] then
                                return u29[p313[4]].White and Color3.new(1, 1, 1) or Color3.new();
                            else
                                return Color3.new();
                            end;
                        end),
                        FontFace = u25
                    }),
                    Corner = u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0, 3)
                    }),
                    u2.createElement("UIGradient", {
                        Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.6, 0), NumberSequenceKeypoint.new(1, 1) })
                    })
                }),
                u2.createElement("Frame", {
                    BackgroundTransparency = 0.5,
                    LayoutOrder = 2,
                    Size = UDim2.fromScale(1, 1),
                    BackgroundColor3 = Color3.new(0, 0, 0),
                    Visible = u252._hoverText:map(function(p314) --[[ Line: 1148 ]]
                        return p314 and p314[1] and true or false;
                    end)
                }, {
                    u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        RichText = true,
                        TextScaled = true,
                        Size = UDim2.fromScale(3, 0.3),
                        Position = UDim2.fromScale(0.1, 0.2),
                        AnchorPoint = Vector2.new(0, 0),
                        Text = u252._hoverText:map(function(p315) --[[ Line: 1160 ]]
                            if p315 and p315[1] then
                                return p315[1];
                            end;
                        end),
                        TextXAlignment = u3.TextXAlignment.Left,
                        TextColor3 = Color3.new(1, 1, 1),
                        FontFace = u26
                    }),
                    u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        RichText = true,
                        TextScaled = true,
                        Size = UDim2.fromScale(3, 0.3),
                        Position = UDim2.fromScale(0.1, 0.5),
                        AnchorPoint = Vector2.new(0, 0),
                        Text = u252._hoverText:map(function(p316) --[[ Line: 1182 ]]
                            if p316 and p316[2] then
                                return p316[2];
                            end;
                        end),
                        TextXAlignment = u3.TextXAlignment.Left,
                        TextColor3 = Color3.new(1, 1, 1),
                        FontFace = u26
                    }),
                    Corner = u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0, 3)
                    }),
                    u2.createElement("UIGradient", {
                        Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.6, 0), NumberSequenceKeypoint.new(1, 1) })
                    })
                }),
                u2.createElement("Frame", {
                    BackgroundTransparency = 0.5,
                    LayoutOrder = 3,
                    Size = UDim2.fromScale(1, 0.4),
                    BackgroundColor3 = Color3.new(1, 1, 1),
                    Visible = u252._hoverText:map(function(p317) --[[ Line: 1210 ]]
                        return p317 and p317[5] and true or false;
                    end)
                }, {
                    u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0, 3)
                    }),
                    u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        Size = UDim2.fromScale(0.9, 0.6),
                        Position = UDim2.fromScale(0.1, 0.2),
                        AnchorPoint = Vector2.new(0, 0),
                        Text = u252._hoverText:map(function(p318) --[[ Line: 1225 ]]
                            -- upvalues: u22 (ref)
                            if not (p318 and p318[5]) then
                                return "";
                            end;
                            print(p318[5].Resource);
                            warn(p318[5]);
                            return "SELL VALUE: " .. u22(p318[5].Price);
                        end),
                        TextXAlignment = u3.TextXAlignment.Left,
                        TextColor3 = Color3.fromRGB(38, 255, 0),
                        FontFace = u25
                    }),
                    u2.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        AnchorPoint = Vector2.new(1, 0.5),
                        Image = u252._hoverText:map(function(p319) --[[ Line: 1241 ]]
                            -- upvalues: u20 (ref)
                            local v320 = p319 and p319[5];
                            if v320 then
                                v320 = p319[5].Resource;
                            end;
                            return not v320 and "" or u20.Resources[v320[1]].Icon;
                        end),
                        ImageColor3 = u252._hoverText:map(function(p321) --[[ Line: 1248 ]]
                            -- upvalues: u20 (ref)
                            local v322 = p321 and p321[5];
                            if v322 then
                                v322 = p321[5].Resource;
                            end;
                            if v322 then
                                return u20.Resources[v322[1]].Color;
                            else
                                return Color3.new();
                            end;
                        end),
                        Position = UDim2.fromScale(0.8, 0.5),
                        Size = UDim2.fromScale(0.7, 0.7),
                        SizeConstraint = u3.SizeConstraint.RelativeYY
                    }),
                    u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                        Position = UDim2.fromScale(0.82, 0.2),
                        Size = UDim2.fromScale(0.9, 0.6),
                        Text = u252._hoverText:map(function(p323) --[[ Line: 1268 ]]
                            local v324 = p323 and p323[5];
                            if v324 then
                                v324 = p323[5].Resource;
                            end;
                            return not v324 and "" or v324[2];
                        end),
                        TextColor3 = u252._hoverText:map(function(p325) --[[ Line: 1275 ]]
                            -- upvalues: u20 (ref)
                            local v326 = p325 and p325[5];
                            if v326 then
                                v326 = p325[5].Resource;
                            end;
                            if v326 then
                                return u20.Resources[v326[1]].Color;
                            else
                                return Color3.new();
                            end;
                        end),
                        TextXAlignment = u3.TextXAlignment.Left
                    }),
                    u2.createElement("UIGradient", {
                        Color = u252._hoverText:map(function(p327) --[[ Line: 1286 ]]
                            -- upvalues: u20 (ref)
                            local v328 = p327 and p327[5];
                            if v328 then
                                v328 = p327[5].Resource;
                            end;
                            if not v328 then
                                return ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(1, 68, 0)), ColorSequenceKeypoint.new(1, Color3.fromRGB(1, 68, 0)) });
                            end;
                            local v329 = u20.Resources[v328[1]];
                            return ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(1, 68, 0)), ColorSequenceKeypoint.new(0.45, Color3.fromRGB(1, 71, 7)), ColorSequenceKeypoint.new(1, v329.Color) });
                        end),
                        Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.6, 0), NumberSequenceKeypoint.new(1, 1) })
                    })
                })
            });
        else
            v305 = l__Enabled__32;
        end;
        local v330;
        if l__Enabled__32 then
            v330 = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0.5, 0),
                Position = u252.DraggingBinding,
                Size = u252._dropItem:Map(function(p331) --[[ Line: 1312 ]]
                    return UDim2.fromScale(p331 * 0.05, p331 * 0.05);
                end),
                SizeConstraint = u3.SizeConstraint.RelativeYY
            }, { u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Image = "rbxassetid://79400192387320",
                    Size = UDim2.fromScale(1, 1),
                    Position = UDim2.fromScale(0, 1),
                    ImageColor3 = Color3.fromRGB(255, 194, 89),
                    ImageTransparency = u252._dropItem:Map(function(p332) --[[ Line: 1324 ]]
                        return 1 - p332;
                    end)
                }) });
        else
            v330 = l__Enabled__32;
        end;
        local v333 = l__Enabled__32 and (u17.Gamepad and not u6.FIRST_PERSON);
        if v333 then
            v333 = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Position = UDim2.fromScale(0.5, 0.8),
                AnchorPoint = Vector2.new(0.5, 0),
                Size = UDim2.fromScale(0.25, 0.06),
                SizeConstraint = u3.SizeConstraint.RelativeYY
            }, { u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextTransparency = 0.2,
                    TextScaled = true,
                    AutoLocalize = false,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.new(-0.5, 0, 0.6, 0),
                    Size = UDim2.new(2, 0, 0.3, 0),
                    FontFace = u25,
                    Text = "HOLD [" .. l__Name__38 .. "] TO CHANGE PERSPECTIVE",
                    TextColor3 = Color3.new(0, 0, 0),
                    TextXAlignment = u3.TextXAlignment.Center
                }, { u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextTransparency = 0.1,
                        TextScaled = true,
                        AutoLocalize = false,
                        AnchorPoint = Vector2.new(0, 0),
                        Position = UDim2.new(0, 0, 0, -1),
                        Size = UDim2.new(1, 0, 1, 0),
                        FontFace = u25,
                        Text = "HOLD [" .. l__Name__38 .. "] TO CHANGE PERSPECTIVE",
                        TextColor3 = Color3.fromRGB(255, 255, 255),
                        TextXAlignment = u3.TextXAlignment.Center
                    }) }) });
        end;
        v304[1], v304[2], v304[3], v304[4], v304[5] = v305, v330, v333, u2.createElement("Frame", {
    Size = UDim2.fromScale(1, 1),
    BackgroundColor3 = Color3.new(0, 0, 0),
    BackgroundTransparency = u252._fade:Map(function(p334) --[[ Line: 1367 ]]
        return 1 - p334;
    end)
}, { u2.createElement("UIGradient", {
        Rotation = 90,
        Transparency = NumberSequence.new({
            NumberSequenceKeypoint.new(0, 0),
            NumberSequenceKeypoint.new(0.3, 1),
            NumberSequenceKeypoint.new(0.7, 1),
            NumberSequenceKeypoint.new(1, 0)
        })
    }) }), u2.createElement("Frame", {
    BackgroundTransparency = 1,
    Size = u252._fade:Map(function(p335) --[[ Line: 1383 ]]
        return UDim2.fromScale(0, (p335 / 2 + 0.5) * 1);
    end),
    SizeConstraint = u3.SizeConstraint.RelativeXY,
    AnchorPoint = Vector2.new(0.5, 0.5),
    Position = UDim2.fromScale(0.5, 0.5)
}, {
    u2.createElement("UIAspectRatioConstraint", {
        AspectRatio = 1.4,
        AspectType = u3.AspectType.ScaleWithParentSize,
        DominantAxis = u3.DominantAxis.Height
    }),
    u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(0.333, 1),
        AnchorPoint = Vector2.new(0.5, 1),
        Position = UDim2.fromScale(0.5, 1)
    }, v254),
    u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(0.333, 1),
        AnchorPoint = Vector2.new(0, 1),
        Position = UDim2.fromScale(-0.05, 1)
    }, { u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(1, 1)
        }, v255), u2.createFragment(v258) }),
    u2.createElement("Frame", {
        BackgroundTransparency = 1,
        AnchorPoint = Vector2.new(1, 0),
        Position = UDim2.fromScale(1, 0),
        Size = UDim2.fromScale(0.333, 1)
    }, u252:_generateCharacter(l__Enabled__32, v257, v260, v303))
});
        return l__createFragment__39(v304);
    end;
end;
function u30._generateCharacter(p336, p337, p338, p339, p340) --[[ Line: 1424 ]]
    -- upvalues: u2 (copy), u3 (copy), u21 (copy), u25 (copy)
    local v341 = {};
    if p337 then
        if p339 then
            p339 = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(0.04, 0.04),
                Position = UDim2.fromScale(0.6, 0.76),
                AnchorPoint = Vector2.new(1, 0),
                SizeConstraint = u3.SizeConstraint.RelativeYY
            }, { u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Image = "rbxassetid://104565034609171",
                    Size = UDim2.fromScale(0.5, 0.5),
                    Position = UDim2.fromScale(0.4, 0.5),
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    SizeConstraint = u3.SizeConstraint.RelativeYY,
                    ImageColor3 = p340,
                    ImageTransparency = p336._fade:Map(function(p342) --[[ Line: 1441 ]]
                        return 1 - p342;
                    end)
                }), u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    Size = UDim2.fromScale(100, 0.5),
                    Position = UDim2.fromScale(0, 0.5),
                    AnchorPoint = Vector2.new(1, 0.5),
                    Text = u21(p339),
                    TextXAlignment = u3.TextXAlignment.Right,
                    TextTransparency = p336._fade:Map(function(p343) --[[ Line: 1452 ]]
                        return 1 - p343;
                    end),
                    TextColor3 = p340,
                    FontFace = u25
                }) });
        end;
    else
        p339 = p337;
    end;
    v341[1], v341[2], v341[3] = p339, u2.createFragment(p338), u2.createElement("ImageLabel", {
    BackgroundTransparency = 1,
    Image = "rbxassetid://15182031887",
    ZIndex = 0,
    AnchorPoint = Vector2.new(0.5, 0.5),
    Size = UDim2.fromScale(0.8, 0.5),
    Position = UDim2.fromScale(0.5, 0.5),
    ImageTransparency = p336._fade:Map(function(p344) --[[ Line: 1468 ]]
        return 1 - p344 * 0.6;
    end),
    ScaleType = u3.ScaleType.Fit
});
    return v341;
end;
return u30;