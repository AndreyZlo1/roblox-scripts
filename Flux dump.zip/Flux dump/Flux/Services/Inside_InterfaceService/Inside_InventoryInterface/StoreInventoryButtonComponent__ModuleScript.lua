-- Services.InterfaceService.InventoryInterface.StoreInventoryButtonComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local l__RunService__1 = game:GetService("RunService");
local v1, u2, _, u3 = shared.import("require", "Roact", "asset", "Enum");
local u4 = v1("GameShellProxyButton");
local u5 = v1("ItemSlotComponent");
local u6 = v1("RoactTween");
local u7 = Font.fromId(12187375422, u3.FontWeight.Bold, u3.FontStyle.Normal);
local u8 = Font.fromId(12187375422, u3.FontWeight.Regular, u3.FontStyle.Normal);
local function u12(p9) --[[ Line: 13 ]]
    local v10 = p9 % 60;
    local v11 = math.floor(p9 / 60) % 60;
    local _ = math.floor(p9 / 3600) % 24;
    if p9 <= 0 then
        v11 = 0;
        v10 = 0;
    end;
    return string.format("%02i", v11) .. ":" .. string.format("%02i", v10);
end;
local v13 = u2.Component:extend("StoreInventoryButton");
function v13.init(p14, _) --[[ Line: 27 ]]
    -- upvalues: u6 (copy), u2 (copy)
    p14.Tween = u6.new(0);
    p14.Transparency = u6.new(0);
    local v15, v16 = u2.createBinding("");
    p14._sub = v15;
    p14._updateSub = v16;
    local v17, v18 = u2.createBinding(0);
    p14._textSize = v17;
    p14._updateTextSize = v18;
end;
function v13._startTimer(u19) --[[ Line: 35 ]]
    -- upvalues: l__RunService__1 (copy), u12 (copy)
    u19._timerLoop = l__RunService__1.Heartbeat:Connect(function(_) --[[ Line: 36 ]]
        -- upvalues: u19 (copy), u12 (ref)
        local v20 = workspace:GetServerTimeNow();
        local l___expire__2 = u19._expire;
        local v21 = l___expire__2 < v20 and "(Refresh)" or u12(l___expire__2 - v20);
        u19._updateSub(u19._subText .. v21);
    end);
end;
function v13.willUnmount(p22) --[[ Line: 50 ]]
    if p22._timerLoop then
        p22._timerLoop:Disconnect();
        p22._timerLoop = nil;
    end;
end;
function v13.render(u23) --[[ Line: 57 ]]
    -- upvalues: u2 (copy), u4 (copy), u3 (copy), u7 (copy), u8 (copy), u5 (copy)
    local l__props__3 = u23.props;
    if l__props__3.Timer then
        u23._subText = l__props__3.Sub or "";
        u23._expire = l__props__3.Timer;
        if not u23._timerLoop then
            u23:_startTimer();
        end;
    else
        u23._updateSub(l__props__3.Sub or "");
        if u23._timerLoop then
            u23._timerLoop:Disconnect();
            u23._timerLoop = nil;
        end;
    end;
    local l__Item__4 = l__props__3.Item;
    local l__Add__5 = l__props__3.Add;
    local l__Preset__6 = l__props__3.Preset;
    local l__Description__7 = l__props__3.Description;
    local l__createElement__8 = u2.createElement;
    local v24 = u4;
    local v27 = {
        BackgroundTransparency = 1,
        Ignore = l__props__3.PopupActive,
        Scroller = l__props__3.Scroller,
        Size = l__props__3.Size,
        LayoutOrder = l__props__3.LayoutOrder,
        Position = l__props__3.Position,
        SoundKit = l__Item__4 and "ArmoryButtonItem" or "ArmoryButton",
        ZIndex = u23.Tween:Map(function(p25) --[[ Line: 86 ]]
            return p25 > 0.1 and 3 or 2;
        end),
        MouseEnter = function() --[[ Name: MouseEnter, Line 90 ]]
            -- upvalues: u23 (copy)
            u23.Tween:SetGoal(1);
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 93 ]]
            -- upvalues: u23 (copy)
            u23.Tween:SetGoal(0);
        end,
        MouseDown = function(_, p26) --[[ Name: MouseDown, Line 96 ]]
            -- upvalues: u23 (copy)
            u23.cursorPosition = p26;
            u23.Transparency:SetGoal(1);
        end,
        MouseUp = function() --[[ Name: MouseUp, Line 100 ]]
            -- upvalues: u23 (copy), l__props__3 (copy)
            if u23.cursorPosition then
                l__props__3.Callback(u23.cursorPosition);
            end;
            u23.Transparency:SetGoal(0);
        end
    };
    local v28 = {};
    local l__createElement__9 = u2.createElement;
    local v29 = "ImageLabel";
    local v31 = {
        Image = "rbxassetid://13867926930",
        BorderSizePixel = 0,
        BackgroundTransparency = 1,
        ImageTransparency = 0.6,
        TileSize = UDim2.fromOffset(64, 64),
        ScaleType = u3.ScaleType.Tile,
        Size = UDim2.new(1, -2, 1, -2),
        Position = UDim2.new(0, 1, 0, 1),
        ImageColor3 = u23.Tween:Map(function(p30) --[[ Line: 117 ]]
            return Color3.fromRGB(105, 105, 105):Lerp(Color3.new(1, 1, 1), p30):Lerp(Color3.new(), 0.2);
        end)
    };
    local v34 = {
        Corner = u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 1)
        }),
        Gradient = u2.createElement("UIGradient", {
            Rotation = -90,
            Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(112, 112, 112)), ColorSequenceKeypoint.new(1, Color3.fromRGB(54, 54, 54)) })
        }),
        Stroke = u2.createElement("UIStroke", {
            Thickness = 1,
            ApplyStrokeMode = u3.ApplyStrokeMode.Contextual,
            Color = u23.Tween:Map(function(p32) --[[ Line: 133 ]]
                return Color3.fromRGB(105, 105, 105):Lerp(Color3.new(1, 1, 1), p32);
            end),
            LineJoinMode = u3.LineJoinMode.Round,
            Transparency = u23.Transparency:Map(function(p33) --[[ Line: 138 ]]
                return p33 / 2;
            end)
        })
    };
    local v37 = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        ZIndex = 2,
        TextScaled = true,
        Size = UDim2.fromScale(l__Add__5 and 0.8 or 1, l__Description__7 and 0.3 or 0.5),
        Position = UDim2.new(0.1, 0, (l__Add__5 or l__Preset__6) and 0.5 or (l__Description__7 and 0.3 or 0.4), 0),
        AnchorPoint = Vector2.new(0, 0.5),
        Text = l__props__3.Name:upper(),
        TextXAlignment = l__Add__5 and u3.TextXAlignment.Center or u3.TextXAlignment.Left,
        TextTransparency = u23.Transparency:Map(function(p35) --[[ Line: 150 ]]
            return p35 / 2;
        end),
        TextColor3 = u23.Tween:Map(function(p36) --[[ Line: 154 ]]
            return Color3.fromRGB(105, 105, 105):Lerp(Color3.new(1, 1, 1), p36);
        end),
        FontFace = u7
    });
    if l__Description__7 then
        l__Description__7 = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            TextScaled = true,
            Size = UDim2.fromScale(1, 0.2),
            Position = UDim2.new(0.1, 0, 0.5, 0),
            AnchorPoint = Vector2.new(0, 0.5),
            Text = l__Description__7,
            TextXAlignment = u3.TextXAlignment.Left,
            TextTransparency = u23.Transparency:Map(function(p38) --[[ Line: 168 ]]
                return p38 / 2;
            end),
            TextColor3 = u23.Tween:Map(function(p39) --[[ Line: 172 ]]
                return Color3.fromRGB(105, 105, 105):Lerp(Color3.new(1, 1, 1), p39);
            end),
            FontFace = u7
        });
    end;
    local v43 = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(0.8, 0.25),
        Position = UDim2.new(0.1, 0, 0.75, 0),
        AnchorPoint = Vector2.new(0, 0.5),
        ZIndex = 2,
        Text = u23._sub,
        RichText = l__props__3.RichText,
        TextXAlignment = u3.TextXAlignment.Left,
        TextTransparency = u23.Transparency:Map(function(p40) --[[ Line: 187 ]]
            return p40 / 2;
        end),
        TextColor3 = u23.Tween:Map(function(p41) --[[ Line: 191 ]]
            return Color3.fromRGB(105, 105, 105):Lerp(Color3.new(1, 1, 1), p41);
        end),
        TextTruncate = u3.TextTruncate.AtEnd,
        TextSize = u23._textSize,
        FontFace = u8,
        [u2.Change.AbsoluteSize] = function(p42) --[[ Line: 198 ]]
            -- upvalues: u23 (copy)
            u23._updateTextSize(p42.AbsoluteSize.Y);
        end
    }, { u2.createElement("UIGradient", {
            Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.6, 0), NumberSequenceKeypoint.new(1, 1) })
        }) });
    local l__Quantity__10 = l__props__3.Quantity;
    if l__Quantity__10 then
        l__Quantity__10 = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            TextScaled = true,
            Size = UDim2.fromScale(1, 0.7),
            Position = UDim2.new(0.73, 0, 0.5, 0),
            AnchorPoint = Vector2.new(1, 0.5),
            Text = "x" .. l__props__3.Quantity,
            TextXAlignment = u3.TextXAlignment.Right,
            TextTransparency = u23.Transparency:Map(function(p44) --[[ Line: 218 ]]
                return p44 / 2;
            end),
            TextColor3 = u23.Tween:Map(function(p45) --[[ Line: 222 ]]
                return Color3.fromRGB(105, 105, 105):Lerp(Color3.new(1, 1, 1), p45);
            end),
            FontFace = u7
        });
    end;
    local v46 = l__Preset__6 or l__props__3.Quantity;
    if v46 then
        v46 = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            Text = "-",
            TextScaled = true,
            Size = UDim2.fromScale(1, 0.7),
            Position = UDim2.new(0.9, 0, 0.5, 0),
            AnchorPoint = Vector2.new(1, 0.5),
            TextXAlignment = u3.TextXAlignment.Right,
            TextTransparency = u23.Transparency:Map(function(p47) --[[ Line: 236 ]]
                return p47 / 2;
            end),
            TextColor3 = u23.Tween:Map(function(p48) --[[ Line: 240 ]]
                return Color3.fromRGB(245, 128, 128):Lerp(Color3.new(1, 0.360784, 0.360784), p48);
            end),
            FontFace = u7
        });
    end;
    if l__Item__4 then
        l__Item__4 = u2.createElement(u5, {
            Small = true,
            Tween = u23.Tween,
            Item = l__Item__4,
            Size = UDim2.fromScale(0.5, 0.5),
            Position = UDim2.fromScale(0.8, 0.5)
        });
    end;
    v34[1], v34[2], v34[3], v34[4], v34[5], v34[6] = v37, l__Description__7, v43, l__Quantity__10, v46, l__Item__4;
    v28[1] = l__createElement__9(v29, v31, v34);
    return l__createElement__8(v24, v27, v28);
end;
return v13;