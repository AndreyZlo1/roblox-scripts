-- Services.InterfaceService.InventoryInterface.InventoryGridComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _, u3 = shared.import("require", "Roact", "asset", "Enum");
local u4 = v1("GameShellProxyButton");
v1("RoactTween");
local v5 = u2.Component:extend("InventoryGrid");
function v5.init(u6, p7) --[[ Line: 8 ]]
    if p7.hovering then
        u6.conn = p7.hovering:Connect(function(p8) --[[ Line: 10 ]]
            -- upvalues: u6 (copy)
            u6.hoveringSlotType = p8;
            u6:setState({
                Glow = u6.hoveringSlotType == u6.slotType and u6.hoveringSlotType ~= nil and true or (u6.draggingKey and u6.slotType == u6.draggingKey.Item.Layout.SlotType and true or false)
            });
        end);
    end;
    if p7.draggingSignal then
        u6.conn2 = p7.draggingSignal:Connect(function(p9) --[[ Line: 19 ]]
            -- upvalues: u6 (copy)
            u6.draggingKey = p9;
            u6:setState({
                Glow = u6.hoveringSlotType == u6.slotType and u6.hoveringSlotType ~= nil and true or (u6.draggingKey and u6.slotType == u6.draggingKey.Item.Layout.SlotType and true or false)
            });
        end);
    end;
end;
function v5.willUnmount(p10, _) --[[ Line: 28 ]]
    if p10.conn then
        p10.conn:Disconnect();
    end;
    if p10.conn2 then
        p10.conn2:Disconnect();
    end;
end;
function v5.render(p11) --[[ Line: 37 ]]
    -- upvalues: u2 (copy), u3 (copy), u4 (copy)
    local l__props__1 = p11.props;
    p11.slotType = l__props__1.slotType;
    local l__Glow__2 = p11.state.Glow;
    local l__createElement__3 = u2.createElement;
    local v12 = "Frame";
    local v13 = {
        Position = l__props__1.Position,
        Size = l__props__1.Size,
        AnchorPoint = Vector2.new(0.5, 0.5),
        SizeConstraint = u3.SizeConstraint.RelativeYY,
        BorderSizePixel = 1,
        BorderMode = u3.BorderMode.Inset,
        BorderColor3 = l__Glow__2 and Color3.fromRGB(255, 194, 89) or Color3.new(0.447058, 0.447058, 0.447058),
        BackgroundColor3 = l__Glow__2 and Color3.fromRGB(255, 194, 89) or Color3.new(1, 1, 1),
        BackgroundTransparency = 0.5,
        LayoutOrder = l__props__1.LayoutOrder,
        [u2.Ref] = l__props__1.Ref
    };
    local v14 = {};
    local v15 = u2.createElement("UIGradient", {
        Rotation = 45,
        Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(43, 43, 43)), ColorSequenceKeypoint.new(1, Color3.fromRGB(0, 0, 0)) })
    });
    local l__Hover__4 = l__props__1.Hover;
    if l__Hover__4 then
        l__Hover__4 = u2.createElement(u4, {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(1, 1),
            MouseEnter = function() --[[ Name: MouseEnter, Line 65 ]]
                -- upvalues: l__props__1 (copy)
                l__props__1.updHoverText({ nil, nil, l__props__1.Hover });
            end,
            MouseLeave = function() --[[ Name: MouseLeave, Line 68 ]]
                -- upvalues: l__props__1 (copy)
                l__props__1.updHoverText();
            end
        });
    end;
    if l__Glow__2 then
        l__Glow__2 = u2.createElement("UIStroke", {
            Thickness = 1,
            Transparency = 0,
            ApplyStrokeMode = u3.ApplyStrokeMode.Contextual,
            Color = Color3.fromRGB(255, 194, 89),
            LineJoinMode = u3.LineJoinMode.Round
        });
    end;
    v14[1], v14[2], v14[3] = v15, l__Hover__4, l__Glow__2;
    return l__createElement__3(v12, v13, v14);
end;
return v5;