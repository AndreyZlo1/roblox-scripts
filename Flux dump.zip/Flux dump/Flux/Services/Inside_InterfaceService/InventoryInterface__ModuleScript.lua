-- Services.InterfaceService.InventoryInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "signal", "Roact", "Enum");
local u5 = v1("GameShellProxyService");
local u6 = v1("ClientService");
local u7 = v1("RoactTween");
v1("SoundService");
local u8 = v1("InventoryComponent");
local u9 = v1("InputService");
local u10 = v1("Stores");
local u11 = v1("Sellers");
local u12 = {};
u12.__index = u12;
function u12._update(p13) --[[ Line: 25 ]]
    -- upvalues: u9 (copy), u3 (copy), u8 (copy)
    local l___enabled__1 = p13._enabled;
    u9.InventoryOpen = l___enabled__1;
    p13._fade:SetGoal(l___enabled__1 and 1 or 0);
    p13._handle = u3.update(p13._handle, u3.createElement(u8, {
        Enabled = l___enabled__1,
        Payload = p13._payload
    }));
    p13._updHoverText();
end;
function u12._reset(p14) --[[ Line: 38 ]]
    p14._payload = nil;
end;
function u12.new() --[[ Line: 42 ]]
    -- upvalues: u7 (copy), u2 (copy), u3 (copy), u5 (copy), u4 (copy), u12 (copy)
    local v15 = u7.new(0);
    local v16 = u2.new();
    local v17, v18 = u3.createBinding();
    local v19 = {
        _enabled = false,
        _updateSignal = v16,
        _hoverText = v17,
        _updHoverText = v18,
        _fade = v15,
        _ui = u5:CreateProxy(5, u4.ShellPriority.AlwaysVisible, "InventoryInterface")
    };
    return setmetatable(v19, u12);
end;
function u12.ForceOpen(p20, p21) --[[ Line: 61 ]]
    -- upvalues: u10 (copy), u11 (copy)
    if p20._toggleControls and p20._enabled then
    else
        if p21 then
            local l__Payload__2 = p21.Payload;
            if l__Payload__2 == "Store" then
                p20._payload = {
                    Store = u10[p21.StoreName],
                    StockLevel = p21.StockLevel,
                    HQ = p21.HQ
                };
            elseif l__Payload__2 == "Seller" then
                p20._payload = {
                    Seller = u11[p21.SellerName],
                    Quantities = p21.Quantities
                };
            end;
        end;
        p20._enabled = true;
        p20:_update();
    end;
end;
function u12.ForceClose(p22) --[[ Line: 86 ]]
    if p22._toggleControls and p22._enabled then
        p22:_reset();
        p22._enabled = false;
        p22:_update();
    end;
end;
function u12.Enable(u23) --[[ Line: 94 ]]
    -- upvalues: u3 (copy), u8 (copy), u9 (copy)
    if u23._toggleControls then
    else
        u23._handle = u3.mount(u3.createElement(u8, {
            Enabled = false,
            UpdateHoverText = u23._updHoverText,
            HoverText = u23._hoverText,
            Update = u23._updateSignal,
            UI = u23._ui,
            Fade = u23._fade
        }), u23._ui);
        u23._toggleControls = u9:Connect({
            Inventory = function(p24, p25) --[[ Name: Inventory, Line 109 ]]
                -- upvalues: u9 (ref), u23 (copy)
                if u9.TabletOpen or (u9.PauseOpen or u9.RadialOpen) then
                else
                    if p25 then
                        if p24 then
                            u23._cameraTimer = tick();
                            return;
                        end;
                        if u23._cameraTimer then
                            u23._cameraTimer = nil;
                            u23._enabled = not u23._enabled;
                            u23:_reset();
                            u23:_update();
                        end;
                    elseif p24 then
                        u23._enabled = not u23._enabled;
                        u23:_reset();
                        u23:_update();
                    end;
                end;
            end
        });
    end;
end;
function u12.Disable(p26) --[[ Line: 134 ]]
    -- upvalues: u3 (copy)
    if p26._toggleControls then
        p26._toggleControls:Disconnect();
        p26._toggleControls = nil;
        p26._enabled = false;
        p26:_update();
        u3.unmount(p26._handle);
    end;
end;
function u12.Update(p27, p28) --[[ Line: 148 ]]
    -- upvalues: u6 (copy), u9 (copy)
    if p27._cameraTimer and tick() - p27._cameraTimer > 0.5 then
        p27._cameraTimer = nil;
        local l__LocalClient__3 = u6.LocalClient;
        if l__LocalClient__3 and l__LocalClient__3.Actor then
            l__LocalClient__3.Actor.Zoom = l__LocalClient__3.Actor.Zoom > 0 and 0 or 5;
        end;
    end;
    if p27._enabled then
        u9.UseVirtualCursor = true;
        p27._updateSignal:Fire(p28);
        p27._disableCursor = true;
    else
        if p27._disableCursor then
            p27._disableCursor = nil;
            u9.UseVirtualCursor = false;
        end;
    end;
end;
return u12.new();