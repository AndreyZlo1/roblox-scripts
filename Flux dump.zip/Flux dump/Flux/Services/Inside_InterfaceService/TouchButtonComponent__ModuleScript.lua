-- Services.InterfaceService.TouchButtonComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local u3 = v1("GameShellProxyButton");
local u4 = v1("InputService");
local u5 = v1("RoactTween");
local u6 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local v7 = u2.Component:extend("TouchButton");
function v7.init(p8, _) --[[ Line: 12 ]]
    -- upvalues: u5 (copy), u2 (copy)
    p8.TouchButton = u5.new(0);
    local v9, v10 = u2.createBinding(false);
    p8.HoverLock = v9;
    p8.UpdateHoverLock = v10;
end;
function v7.render(u11) --[[ Line: 17 ]]
    -- upvalues: u2 (copy), u3 (copy), u4 (copy), u6 (copy)
    local l__props__1 = u11.props;
    local l__Text__2 = l__props__1.Text;
    local l__Image__3 = l__props__1.Image;
    local u12 = l__props__1.Color or Color3.new();
    local l__createElement__4 = u2.createElement;
    local v13 = u3;
    local v15 = {
        BorderSizePixel = 0,
        BackgroundTransparency = 0.8,
        Size = l__props__1.Size,
        Position = l__props__1.Position,
        HoverLock = u11.HoverLock,
        AnchorPoint = l__props__1.AnchorPoint,
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        BackgroundColor3 = u11.TouchButton:Map(function(p14) --[[ Line: 31 ]]
            -- upvalues: u12 (copy)
            return u12:Lerp(Color3.new(0.8, 0.8, 0.8), p14);
        end),
        MouseUp = function() --[[ Name: MouseUp, Line 35 ]]
            -- upvalues: u4 (ref), u11 (copy), l__props__1 (copy)
            if u4.PauseOpen or u4.MenuOpen then
            else
                u11.UpdateHoverLock(false);
                u11.TouchButton:SetGoal(0);
                if l__props__1.Up then
                    task.spawn(l__props__1.Up);
                end;
            end;
        end,
        MouseDown = function() --[[ Name: MouseDown, Line 46 ]]
            -- upvalues: u4 (ref), u11 (copy), l__props__1 (copy)
            if u4.PauseOpen or u4.MenuOpen then
            else
                u11.UpdateHoverLock(true);
                u11.TouchButton:SetGoal(1);
                if l__props__1.Down then
                    task.spawn(l__props__1.Down);
                end;
            end;
        end
    };
    local v16 = {};
    local v17 = u2.createElement("UICorner", {
        CornerRadius = UDim.new(0.5, 0)
    });
    local v19 = u2.createElement("UIStroke", {
        Thickness = 1,
        BorderStrokePosition = Enum.BorderStrokePosition.Inner,
        LineJoinMode = Enum.LineJoinMode.Round,
        Color = Color3.new(1, 1, 1),
        Transparency = u11.TouchButton:Map(function(p18) --[[ Line: 66 ]]
            return math.lerp(0.8, 0, p18);
        end)
    });
    if l__Image__3 then
        l__Image__3 = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = u11.TouchButton:Map(function(p20) --[[ Line: 73 ]]
                return UDim2.fromScale(0.5, 0.5):Lerp(UDim2.fromScale(0.4, 0.4), p20);
            end),
            Image = l__Image__3
        });
    end;
    if l__Text__2 then
        l__Text__2 = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            Size = u11.TouchButton:Map(function(p21) --[[ Line: 81 ]]
                return UDim2.fromScale(1, 0.5):Lerp(UDim2.fromScale(1, 0.4), p21);
            end),
            Position = UDim2.fromScale(0, 0.25),
            Text = l__Text__2,
            TextColor3 = Color3.new(1, 1, 1),
            FontFace = u6
        });
    end;
    v16[1], v16[2], v16[3], v16[4] = v17, v19, l__Image__3, l__Text__2;
    return l__createElement__4(v13, v15, v16);
end;
return v7;