-- Services.InterfaceService.VehicleButtonInterface.VehicleButtonComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local u3 = v1("VehicleButtonNodeComponent");
local v4 = u2.Component:extend("Radial");
function v4.init(_, _) --[[ Line: 8 ]] end;
function v4.render(p5) --[[ Line: 11 ]]
    -- upvalues: u2 (copy), u3 (copy)
    local v6 = {};
    for v7, v8 in p5.props.Buttons do
        v6[v7] = u2.createElement(u3, {
            Button = v8
        });
    end;
    local v9 = next(v6) and { u2.createElement("Frame", {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            ZIndex = 2,
            Size = UDim2.new(0, 2, 0.01, 0),
            Position = UDim2.fromScale(0.5, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            BackgroundColor3 = Color3.new(1, 1, 1)
        }), u2.createElement("Frame", {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            ZIndex = 2,
            Size = UDim2.new(0.01, 0, 0, 2),
            Position = UDim2.fromScale(0.5, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            BackgroundColor3 = Color3.new(1, 1, 1)
        }) } or {};
    return u2.createFragment({ u2.createFragment(v6), u2.createFragment(v9) });
end;
return v4;