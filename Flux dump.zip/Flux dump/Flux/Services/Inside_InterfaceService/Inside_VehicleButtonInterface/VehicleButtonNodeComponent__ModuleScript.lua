-- Services.InterfaceService.VehicleButtonInterface.VehicleButtonNodeComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local u3 = v1("GameShellProxyButton");
local u4 = v1("RoactTween");
local u5 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local v6 = u2.Component:extend("Radial");
function v6.init(p7, _) --[[ Line: 11 ]]
    -- upvalues: u4 (copy)
    p7.Hover = u4.new(0);
end;
function v6.render(u8) --[[ Line: 15 ]]
    -- upvalues: u2 (copy), u3 (copy), u5 (copy)
    local l__Button__1 = u8.props.Button;
    return u2.createElement(u3, {
        BackgroundTransparency = 1,
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = l__Button__1.Position,
        Size = UDim2.fromScale(0.05, 0.05),
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        MouseEnter = function() --[[ Name: MouseEnter, Line 24 ]]
            -- upvalues: u8 (copy)
            u8.Hover:SetGoal(1);
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 27 ]]
            -- upvalues: u8 (copy)
            u8.Hover:SetGoal(0);
        end,
        MouseUp = function() --[[ Name: MouseUp, Line 30 ]]
            -- upvalues: l__Button__1 (copy)
            l__Button__1.Callback(false);
        end,
        MouseDown = function() --[[ Name: MouseDown, Line 33 ]]
            -- upvalues: l__Button__1 (copy)
            l__Button__1.Callback(true);
        end
    }, { u2.createElement("Frame", {
            BorderSizePixel = 0,
            Size = UDim2.fromScale(0.15, 0.15),
            Position = UDim2.fromScale(0.5, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5),
            BackgroundColor3 = Color3.new(1, 1, 1),
            BackgroundTransparency = u8.Hover:Map(function(p9) --[[ Line: 43 ]]
                return 1 - p9;
            end)
        }, { u2.createElement("UICorner", {
                CornerRadius = UDim.new(0.5, 0)
            }), u2.createElement("UIStroke", {
                Thickness = 2,
                Color = Color3.new(1, 1, 1),
                LineJoinMode = Enum.LineJoinMode.Round,
                Transparency = u8.Hover:Map(function(p10) --[[ Line: 53 ]]
                    return 0.5 - p10 * 0.5;
                end)
            }) }), u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.fromScale(0.7, 0.3),
            Size = UDim2.fromScale(10, 0.4),
            FontFace = u5,
            Text = l__Button__1.Tooltip,
            TextTransparency = u8.Hover:Map(function(p11) --[[ Line: 66 ]]
                return 1 - p11;
            end),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = Enum.TextXAlignment.Left
        }) });
end;
return v6;