-- Services.InterfaceService.NotifyInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Enum", "Roact", "network");
local u5 = v1("GameShellProxyService");
local u6 = v1("RoactTween");
local u7 = v1("SoundService");
local l__TextService__1 = game:GetService("TextService");
local u8 = Font.fromId(12187375422, u2.FontWeight.Bold, u2.FontStyle.Normal);
local u9 = v1("NotifyComponent");
local u10 = {};
u10.__index = u10;
function u10._update(p11) --[[ Line: 29 ]]
    -- upvalues: u3 (copy), u9 (copy)
    p11._handle = u3.update(p11._handle, u3.createElement(u9, {
        Notifications = p11._notifications
    }));
end;
function u10.new() --[[ Line: 35 ]]
    -- upvalues: u3 (copy), u5 (copy), u2 (copy), u7 (copy), u9 (copy), u10 (copy), u4 (copy)
    local v12 = u3.createRef();
    local v13 = u5:CreateProxy(6, u2.ShellPriority.Default, "NotifyInterface");
    local l__Sound__2 = u7:CreateSound("Button", nil, false, "UISounds", "Kill").Sound;
    local v14 = {
        _notificationCount = 0,
        _handle = u3.mount(u3.createElement(u9, {
            Container = v12,
            Notifications = {}
        }), v13),
        _kill = l__Sound__2,
        _container = v12,
        _notifications = {}
    };
    local u15 = setmetatable(v14, u10);
    u4:ConnectEvents({
        Notify = function(p16, p17) --[[ Name: Notify, Line 52 ]]
            -- upvalues: u15 (copy)
            u15:Notify(p16, p17);
        end
    });
    return u15;
end;
function u10.Notify(u18, p19, p20) --[[ Line: 60 ]]
    -- upvalues: u6 (copy), u2 (copy), u8 (copy), l__TextService__1 (copy), u3 (copy), u7 (copy)
    local v21 = u18._container:getValue().AbsoluteSize.Y * 0.015;
    local v22 = {};
    local v23 = 0;
    local v24 = 1;
    local v25 = false;
    local v26 = 5;
    for _, v27 in p19 do
        local v28 = "   " .. v27[1]:upper() .. "   ";
        local v29 = "  " .. v27[2]:upper() .. "  ";
        local u30 = v27[3];
        if p20 then
            v25 = true;
        else
            if v27[1] == "Killed Enemy" then
                u18._kill:Play();
            end;
            v25 = v27[4] and true or v25;
        end;
        local v31 = u6.new(0, TweenInfo.new(0.3, u2.EasingStyle.Exponential, u2.EasingDirection.Out, 0, false, 0));
        local v32 = u6.new(0, TweenInfo.new(0.3, u2.EasingStyle.Exponential, u2.EasingDirection.Out, 0, false, 0));
        local v33 = u6.new(0, TweenInfo.new(0.3, u2.EasingStyle.Exponential, u2.EasingDirection.Out, 0, false, 0));
        local v34 = Instance.new("GetTextBoundsParams");
        v34.Text = v28;
        v34.Font = u8;
        v34.Size = math.ceil(v21 * 0.8);
        v34.Width = (1 / 0);
        local u35 = l__TextService__1:GetTextBoundsAsync(v34);
        v22[v24] = u3.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 1,
            Size = v31:Map(function(p36) --[[ Line: 97 ]]
                -- upvalues: u35 (copy)
                return UDim2.new(0, p36 * u35.X, 1, 0);
            end),
            Visible = v31:Map(function(p37) --[[ Line: 100 ]]
                return p37 > 0;
            end),
            LayoutOrder = v24
        }, {
            Bonus = u3.createElement("ImageLabel", {
                Image = "rbxassetid://13867926930",
                BorderSizePixel = 0,
                TileSize = UDim2.fromOffset(64, 64),
                ScaleType = u2.ScaleType.Tile,
                BackgroundColor3 = v32:Map(function(p38) --[[ Line: 111 ]]
                    -- upvalues: u30 (copy)
                    return Color3.new(1, 1, 1):Lerp(u30, p38);
                end),
                ImageColor3 = v32:Map(function(p39) --[[ Line: 114 ]]
                    -- upvalues: u30 (copy)
                    return Color3.new(1, 1, 1):Lerp(u30:Lerp(Color3.new(), 0.2), p39);
                end),
                ImageTransparency = v32:Map(function(p40) --[[ Line: 117 ]]
                    return 1 - p40;
                end),
                Position = UDim2.fromScale(0.1, 0),
                Size = UDim2.new(0.9, 0, 1, 0)
            }, {
                Corner = u3.createElement("UICorner", {
                    CornerRadius = UDim.new(0, 1)
                }),
                Gradient = u3.createElement("UIGradient", {
                    Rotation = -90,
                    Color = v32:Map(function(p41) --[[ Line: 129 ]]
                        return ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(112, 112, 112):Lerp(Color3.new(1, 1, 1), 1 - p41)), ColorSequenceKeypoint.new(1, Color3.fromRGB(54, 54, 54):Lerp(Color3.new(1, 1, 1), 1 - p41)) });
                    end)
                }),
                Stroke = u3.createElement("UIStroke", {
                    Thickness = 1,
                    ApplyStrokeMode = u2.ApplyStrokeMode.Contextual,
                    Color = v32:Map(function(p42) --[[ Line: 139 ]]
                        -- upvalues: u30 (copy)
                        return Color3.new(1, 1, 1):Lerp(u30, p42);
                    end),
                    LineJoinMode = u2.LineJoinMode.Round
                }),
                Name = u3.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AutoLocalize = false,
                    Position = UDim2.new(0, 0, 0.18, 0),
                    Size = UDim2.new(1, 0, 0.8, 0),
                    FontFace = u8,
                    Text = v28,
                    TextColor3 = v32:Map(function(p43) --[[ Line: 151 ]]
                        -- upvalues: u30 (copy)
                        return Color3.new(1, 1, 1):Lerp(u30, p43);
                    end),
                    TextXAlignment = u2.TextXAlignment.Center
                })
            })
        });
        v34.Text = v29;
        v34.Size = math.ceil(v21);
        local u44 = l__TextService__1:GetTextBoundsAsync(v34);
        v22[v24 + 1] = u3.createElement("TextLabel", {
            BackgroundTransparency = 1,
            ClipsDescendants = true,
            AutoLocalize = false,
            Size = v33:Map(function(p45) --[[ Line: 166 ]]
                -- upvalues: u44 (copy)
                return UDim2.new(0, p45 * u44.X, 1, 0);
            end),
            Position = UDim2.fromScale(0, 0.02),
            LayoutOrder = v24 + 1,
            FontFace = u8,
            Text = v29,
            TextColor3 = Color3.new(0, 0, 0),
            TextSize = math.ceil(v21),
            TextTransparency = v33:Map(function(p46) --[[ Line: 175 ]]
                return 1 - math.clamp((p46 - 0.5) * 2, 0, 1) * 0.8;
            end),
            TextXAlignment = u2.TextXAlignment.Left
        }, {
            White = u3.createElement("TextLabel", {
                BackgroundTransparency = 1,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0),
                FontFace = u8,
                Text = v29,
                TextTransparency = v33:Map(function(p47) --[[ Line: 189 ]]
                    return 1 - math.clamp((p47 - 0.5) * 2, 0, 1) * 0.9;
                end),
                TextColor3 = Color3.new(1, 1, 1),
                TextSize = math.ceil(v21),
                TextXAlignment = u2.TextXAlignment.Left
            })
        });
        local v48 = v23 * 0.3;
        if not v25 then
            local v49 = u7:CreateSound("Button", nil, false, "UISounds", "Notification");
            v49.Destroy(v48 + 4);
            task.delay(v48, v49.Sound.Play, v49.Sound);
        end;
        task.delay(v48, v31.SetGoal, v31, 1);
        task.delay(v48 + 0.5, v32.SetGoal, v32, 1);
        task.delay(v48 + 0.5 + 0.3, v33.SetGoal, v33, 1);
        task.delay(v48 + 5 - 0.3, v33.SetGoal, v33, 0);
        task.delay(v48 + 5, v32.SetGoal, v32, 0);
        task.delay(v48 + 5 + 0.3, v31.SetGoal, v31, 0);
        v26 = v48 + 5 + 0.3;
        v23 = v23 + 1;
        v24 = v24 + 2;
    end;
    local v50 = u6.new(0, TweenInfo.new(0.3, u2.EasingStyle.Exponential, u2.EasingDirection.Out, 0, false, 0));
    local l___notificationCount__3 = u18._notificationCount;
    u18._notifications[l___notificationCount__3] = u3.createElement("Frame", {
        BorderSizePixel = 0,
        BackgroundTransparency = 1,
        Size = v50:Map(function(p51) --[[ Line: 220 ]]
            return UDim2.fromScale(1, p51 * 0.015);
        end),
        LayoutOrder = -l___notificationCount__3
    }, {
        u3.createFragment(v22),
        List = u3.createElement("UIListLayout", {
            Padding = UDim.new(0, 0),
            FillDirection = u2.FillDirection.Horizontal,
            HorizontalAlignment = u2.HorizontalAlignment.Center,
            SortOrder = u2.SortOrder.LayoutOrder,
            VerticalAlignment = u2.VerticalAlignment.Top
        })
    });
    u18._notificationCount = u18._notificationCount + 1;
    u18:_update();
    v50:SetGoal(1);
    task.delay(v26 + 0.3, function() --[[ Line: 240 ]]
        -- upvalues: u18 (copy), l___notificationCount__3 (copy)
        u18._notifications[l___notificationCount__3] = nil;
        u18:_update();
    end);
end;
return u10.new();