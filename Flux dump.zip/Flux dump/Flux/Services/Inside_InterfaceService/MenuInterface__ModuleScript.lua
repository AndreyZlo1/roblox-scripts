-- Services.InterfaceService.MenuInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Enum", "Roact", "network");
local u5 = v1("ClientService");
local u6 = v1("InputService");
v1("FlagService");
local u7 = v1("PostProcessingService");
local u8 = v1("EnvironmentService");
local u9 = v1("GameShellProxyService");
local u10 = v1("SoundService");
local u11 = v1("BaseComponent");
local u12 = v1("PopupInterface");
v1("MenuLoadout3DViewer");
local u13 = v1("RoactTween");
local u14 = v1("StatsService");
local u15 = v1("MenuComponent");
local u16 = v1("RadioInterface");
local u17 = v1("HUDInterface");
local u18 = v1("Mathf");
local u19 = v1("formatNumber");
local l__LocalPlayer__1 = game:GetService("Players").LocalPlayer;
local l__CurrentCamera__2 = workspace.CurrentCamera;
local u20 = Font.fromId(12187375422, u2.FontWeight.Bold, u2.FontStyle.Normal);
local u21 = {
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "#",
    "$",
    "%",
    "&",
    "@"
};
local u22 = {
    Default = {
        FromFOV = 40,
        GoalFOV = 40,
        DoesShake = false,
        FromCFrame = CFrame.new(21.0888252, -9.54803944, 5.668, -0, 0, 1, -0, 1, 0, -1, 0, 0),
        GoalCFrame = CFrame.new(21.0888252, -9.54803944, 5.668, -0, 0, 1, -0, 1, 0, -1, 0, 0),
        Focus = CFrame.new(66.3, -13.303, -79.1),
        Environment = {
            Atmosphere = "Lobby",
            LunarPhase = 1,
            RainDensity = 0,
            CloudDensity = 0.7,
            CloudCover = 0.5,
            ClockTime = 17.8,
            FogDensity = 0,
            ShowUnderWater = false
        }
    },
    Loadout = {
        FromFOV = 50,
        GoalFOV = 50,
        DoesShake = false,
        FromCFrame = CFrame.new(-6.48329163, -225.833221, -2.87549138, 0.999268353, 0.000574267178, 0.0382428132, -0, 0.999887288, -0.0150146466, -0.0382471308, 0.0150036607, 0.999155641),
        GoalCFrame = CFrame.new(-0.193855807, -222.758911, -8.86863899, 0.999999464, -0.00027427281, 0.00101728796, -0, 0.965523362, 0.260316461, -0.00105361303, -0.260316312, 0.965522826),
        Focus = CFrame.new(-0.2, -494.331, -14.7),
        TouchExtents = { UDim2.fromScale(0.2, 0), UDim2.fromScale(1, 1) },
        Environment = {
            Atmosphere = "Loadout",
            LunarPhase = 1,
            RainDensity = 0,
            CloudDensity = 0.7,
            CloudCover = 0.5,
            ClockTime = 6.4,
            FogDensity = 0,
            ShowUnderWater = false
        }
    },
    ReduxLoadout = {
        FromFOV = 30,
        GoalFOV = 30,
        DoesShake = false,
        FromCFrame = CFrame.new(0, -1500, 0),
        GoalCFrame = CFrame.new(0, -1500, 0),
        Focus = CFrame.new(0, -1500, 0),
        TouchExtents = { UDim2.fromScale(0.2, 0), UDim2.fromScale(1, 1) },
        Environment = {
            Atmosphere = "TESTDONOTCHANGE",
            LunarPhase = 1,
            RainDensity = 0,
            CloudDensity = 0.7,
            CloudCover = 0.5,
            ClockTime = 10,
            FogDensity = 0,
            ShowUnderWater = false
        }
    }
};
local u23 = {
    CFrame.new(12.276, -11.45, 5.668) * CFrame.Angles(0, -1.5707963267948966, 0),
    CFrame.new(9.476, -11.45, 3.816) * CFrame.Angles(0, -1.5707963267948966, 0),
    CFrame.new(9.476, -11.45, 7.502) * CFrame.Angles(0, -1.5707963267948966, 0),
    CFrame.new(6.375, -11.45, 1.958) * CFrame.Angles(0, -1.5707963267948966, 0),
    CFrame.new(6.375, -11.45, 9.429) * CFrame.Angles(0, -1.5707963267948966, 0)
};
local u24 = {
    8588572507,
    8588584965,
    8588589950,
    8588596824,
    8588579661
};
local u25 = {};
u25.__index = u25;
local function u31(p26, p27) --[[ Line: 124 ]]
    -- upvalues: u21 (copy)
    if p27 > 1 then
        return p26;
    end;
    local v28 = math.floor(#p26 * (1 - p27));
    local v29 = "";
    for v30 = 1, #p26 do
        if v28 < v30 then
            v29 = v29 .. p26:sub(v30, v30);
        else
            v29 = v29 .. u21[math.random(1, #u21)];
        end;
    end;
    return v29;
end;
function u25._update(p32) --[[ Line: 142 ]]
    -- upvalues: u3 (copy), u15 (copy), u12 (copy)
    if p32._enabled then
        p32._handle = u3.update(p32._handle, u3.createElement(u15, {
            UpdateLoadout = p32._updateLoadout,
            IconsEnabled = p32._iconsEnabled,
            PopupActive = u12.PopupOpen,
            PrivateServerData = p32._privateServerData,
            MatchmakingQueueData = p32._matchmakingQueueData
        }));
    end;
end;
function u25._updateCharacterModels(u33, p34) --[[ Line: 154 ]]
    -- upvalues: l__LocalPlayer__1 (copy), u5 (copy), u11 (copy), u23 (copy), u24 (copy), u2 (copy), u20 (copy)
    local l___currentModels__3 = u33._currentModels;
    for u35, u36 in p34 do
        local v37 = l___currentModels__3[u35];
        if v37 == nil or v37.UserId ~= u36.UserId then
            if v37 then
                v37.Model:Destroy();
            end;
            local u38 = {
                UserId = u36.UserId
            };
            function u38.Generate() --[[ Line: 166 ]]
                -- upvalues: u38 (copy), l__LocalPlayer__1 (ref), u5 (ref), u33 (copy), u11 (ref), u23 (ref), u35 (copy), u24 (ref), u2 (ref), u20 (ref), u36 (copy)
                if u38.Model then
                    u38.Model:Destroy();
                end;
                local v39 = nil;
                if u38.UserId == l__LocalPlayer__1.UserId then
                    v39 = u5.LocalClient.Loadouts[u5.LocalClient.ActiveLoadout].Tree;
                elseif u33._characterLoadouts[u38.UserId] then
                    v39 = u33._characterLoadouts[u38.UserId];
                end;
                local v40;
                if v39 then
                    local v41 = u11.Deserialize(v39);
                    local v42 = v41:GetChild("Character");
                    v40 = v42.ParentModel;
                    v40.PrimaryPart.Anchored = true;
                    v40.PrimaryPart:PivotTo(u23[u35]);
                    local v43 = v41:GetChild("Primary");
                    if v43 then
                        local l__Weld__4 = v43.Weld;
                        l__Weld__4.C0 = CFrame.new(-0.3, 0, -0.5) * CFrame.Angles(1.5707963267948966, 3.141592653589793, 3.141592653589793);
                        l__Weld__4.C1 = v43.ParentModel.PrimaryPart.anchor.CFrame;
                        l__Weld__4.Part0 = v42.Model.RightHand;
                        l__Weld__4.Part1 = v43.ParentModel.PrimaryPart;
                        v43.ParentModel.Parent = v40;
                    end;
                    local v44 = Instance.new("AnimationController");
                    v44.Parent = v42.Model;
                    local v45 = Instance.new("Animator");
                    v45.Parent = v44;
                    local v46 = Instance.new("Animation");
                    v46.AnimationId = "rbxassetid://" .. u24[u35];
                    local v47 = Instance.new("BillboardGui");
                    v47.Enabled = u33._iconsEnable;
                    v47.AlwaysOnTop = true;
                    v47.Adornee = v40.PrimaryPart;
                    v47.ExtentsOffset = Vector3.new(0, 0, 0);
                    local v48 = Instance.new("ImageLabel");
                    v48.Parent = v47;
                    v48.Size = UDim2.fromScale(0.4, 0.4);
                    v48.Position = UDim2.fromScale(0.5, 0);
                    v48.AnchorPoint = Vector2.new(0.5, 0);
                    v48.SizeConstraint = u2.SizeConstraint.RelativeYY;
                    v48.BackgroundTransparency = 1;
                    v48.Image = "rbxthumb://type=AvatarHeadShot&id=" .. u38.UserId .. "&w=150&h=150";
                    local v49 = Instance.new("UICorner");
                    v49.Parent = v48;
                    v49.CornerRadius = UDim.new(0, 1);
                    local v50 = Instance.new("UIStroke");
                    v50.Parent = v48;
                    v50.Thickness = 1;
                    v50.Color = Color3.new(1, 1, 1);
                    local v51 = Instance.new("TextLabel");
                    v51.Parent = v47;
                    v51.BackgroundTransparency = 1;
                    v51.Size = UDim2.fromScale(1, 0.15);
                    v51.Position = UDim2.new(0, 0, 0.5, 0);
                    v51.AnchorPoint = Vector2.new(0);
                    v51.TextXAlignment = u2.TextXAlignment.Center;
                    v51.TextColor3 = Color3.new(1, 1, 1);
                    v51.TextScaled = true;
                    v51.FontFace = u20;
                    v51.Text = u36.Username;
                    u38.Tag = v51;
                    u38.Icon = v47;
                    v47.Parent = v40.PrimaryPart;
                    v40.Parent = workspace;
                    local v52 = v45:LoadAnimation(v46);
                    v52.Looped = true;
                    v52:Play(0);
                else
                    v40 = Instance.new("Model");
                end;
                u38.Model = v40;
            end;
            u38.Generate();
            l___currentModels__3[u35] = u38;
        elseif v37.Tag then
            v37.Tag.Text = u36.Username;
        end;
    end;
    for v53, v54 in l___currentModels__3 do
        if not p34[v53] then
            v54.Model:Destroy();
            l___currentModels__3[v53] = nil;
        end;
    end;
end;
function u25.new() --[[ Line: 271 ]]
    -- upvalues: u9 (copy), u2 (copy), u13 (copy), u3 (copy), u25 (copy), u22 (copy), l__CurrentCamera__2 (copy), u8 (copy), u6 (copy), l__LocalPlayer__1 (copy), u12 (copy), u4 (copy), u10 (copy)
    local v55, v56 = u9:CreateProxy(10, u2.ShellPriority.AlwaysVisible, "MenuInterface");
    v56.ScreenInsets = u2.ScreenInsets.None;
    local v57 = u13.new(0);
    local v58 = u13.new(0);
    local v59, v60 = u3.createBinding();
    local v61, v62 = u3.createBinding();
    local u63 = {
        FullCommunityMapResults = false,
        UpdatingCommunityMapResults = false,
        PrivateServerCode = "00000000-0000-0000-0000-000000000000",
        PrivateServerDays = 0,
        UpdatingPrivateServerConfig = false,
        UpdatingPrivateServerCode = false,
        CommunityMapMetadata = {},
        CommunityMapResults = {},
        PrivateServerWhitelist = {
            Enabled = false,
            Users = {}
        },
        PrivateServerBlacklist = {
            Users = {}
        },
        PrivateServerAdminlist = {
            Users = {}
        }
    };
    local u64 = {
        IsMatchmaking = false,
        CancellingQueue = false,
        JoiningSession = false,
        MatchmakingQueue = "",
        MatchmakingStarted = 0,
        CurrentLobby = {}
    };
    local v65 = {
        _enabled = false,
        _openTimer = 0,
        _ui = v55,
        _enabledTween = v57,
        _logoTween = v58,
        _inviteBlocks = {},
        _currentModels = {},
        _characterLoadouts = {},
        _expandedTween = u13.new(1),
        _updateMoney = v60,
        _updateExp = v62,
        _moneyBinding = v59,
        _expBinding = v61,
        _privateServerData = u63,
        _matchmakingQueueData = u64
    };
    local u66 = setmetatable(v65, u25);
    function u66._setCamera(p67) --[[ Line: 328 ]]
        -- upvalues: u66 (copy), u22 (ref), l__CurrentCamera__2 (ref), u8 (ref), u6 (ref)
        local v68 = u22[not p67 and u66._pages[1] ~= "Play" and "ReduxLoadout" or p67 or "Default"];
        l__CurrentCamera__2.CFrame = v68.FromCFrame;
        l__CurrentCamera__2.FieldOfView = v68.FromFOV;
        u8:SetOverride(v68.Environment);
        if v68.TouchExtents then
            u6:SetCameraTouchExtents(v68.TouchExtents[1], v68.TouchExtents[2]);
        else
            u6:SetCameraTouchExtents(nil, nil);
        end;
        u66._cameraSettings = {
            Preset = v68,
            CFrame = v68.GoalCFrame,
            FieldOfView = v68.GoalFOV,
            Focus = v68.Focus,
            DoesShake = v68.DoesShake,
            StopMusic = v68.StopMusic
        };
        return u66._cameraSettings;
    end;
    function u66._iconsEnabled(p69) --[[ Line: 358 ]]
        -- upvalues: u66 (copy)
        u66._iconsEnable = p69;
        for _, v70 in u66._currentModels do
            if v70.Icon then
                v70.Icon.Enabled = p69;
            end;
        end;
    end;
    function u66._updateLoadout() --[[ Line: 367 ]]
        -- upvalues: u66 (copy), l__LocalPlayer__1 (ref)
        for _, v71 in u66._currentModels do
            if v71.UserId == l__LocalPlayer__1.UserId then
                v71.Generate();
            end;
        end;
    end;
    u12.PopupChanged:Connect(function() --[[ Line: 375 ]]
        -- upvalues: u66 (copy)
        u66:_update();
    end);
    u4:ConnectEvents({
        CommunityMapMetadataLoaded = function(p72, p73) --[[ Name: CommunityMapMetadataLoaded, Line 380 ]]
            -- upvalues: u63 (copy), u66 (copy)
            u63.CommunityMapMetadata[p72] = p73;
            u66:_update();
        end,
        CommunityMapResults = function(p74, p75) --[[ Name: CommunityMapResults, Line 384 ]]
            -- upvalues: u63 (copy), u66 (copy)
            u63.CommunityMapResults = p74;
            u63.UpdatingCommunityMapResults = false;
            u63.FullCommunityMapResults = p75;
            u66:_update();
        end,
        PrivateServerMapUpdate = function(p76) --[[ Name: PrivateServerMapUpdate, Line 390 ]]
            -- upvalues: u63 (copy), u66 (copy)
            u63.CurrentMap = p76;
            u63.UpdatingPrivateServerCode = false;
            u66:_update();
        end,
        PrivateServerCodeUpdated = function(p77) --[[ Name: PrivateServerCodeUpdated, Line 395 ]]
            -- upvalues: u63 (copy), u66 (copy)
            u63.PrivateServerCode = p77;
            u63.UpdatingPrivateServerCode = false;
            u66:_update();
        end,
        PrivateServerCodeWhitelistUpdated = function(p78) --[[ Name: PrivateServerCodeWhitelistUpdated, Line 400 ]]
            -- upvalues: u63 (copy), u66 (copy)
            u63.PrivateServerWhitelist = p78;
            u63.UpdatingPrivateServerConfig = false;
            u66:_update();
        end,
        PrivateServerCodeBlacklistUpdated = function(p79) --[[ Name: PrivateServerCodeBlacklistUpdated, Line 405 ]]
            -- upvalues: u63 (copy), u66 (copy)
            u63.PrivateServerBlacklist = p79;
            u63.UpdatingPrivateServerConfig = false;
            u66:_update();
        end,
        PrivateServerCodeAdminlistUpdated = function(p80) --[[ Name: PrivateServerCodeAdminlistUpdated, Line 410 ]]
            -- upvalues: u63 (copy), u66 (copy)
            u63.PrivateServerAdminlist = p80;
            u63.UpdatingPrivateServerConfig = false;
            u66:_update();
        end,
        PrivateServerDaysUpdated = function(p81) --[[ Name: PrivateServerDaysUpdated, Line 415 ]]
            -- upvalues: u63 (copy), u66 (copy)
            u63.PrivateServerDays = p81;
            u66:_update();
        end,
        MatchmakingLobbyUpdated = function(p82) --[[ Name: MatchmakingLobbyUpdated, Line 419 ]]
            -- upvalues: u64 (copy), u66 (copy)
            u64.CurrentLobby = p82;
            u66:_updateCharacterModels(p82);
            u66:_update();
        end,
        JoinSessionUpdate = function(p83) --[[ Name: JoinSessionUpdate, Line 425 ]]
            -- upvalues: u10 (ref), u64 (copy), u66 (copy)
            u10:CreateSound("Button", nil, true, "UISounds", "JoinSession").Destroy(4);
            u64.JoiningSession = true;
            u64.JoinMessage = p83;
            u66:_update();
        end,
        JoinSessionFailed = function(p84) --[[ Name: JoinSessionFailed, Line 433 ]]
            -- upvalues: u64 (copy), u66 (copy), u10 (ref), u12 (ref)
            u64.JoiningSession = false;
            u64.JoinMessage = nil;
            u64.IsMatchmaking = false;
            u64.CancellingQueue = false;
            u66:_update();
            u10:CreateSound("Button", nil, true, "UISounds", "JoinSessionFailed").Destroy(2);
            u12:Open("Failed to join session", p84, {
                { "Close", function() --[[ Line: 444 ]]
                        -- upvalues: u12 (ref)
                        u12:Close();
                    end }
            });
        end,
        UpdateCharacterLoadout = function(p85, p86) --[[ Name: UpdateCharacterLoadout, Line 450 ]]
            -- upvalues: u66 (copy)
            u66._characterLoadouts[p85] = p86;
            for _, v87 in u66._currentModels do
                if v87.UserId == p85 then
                    v87.Generate();
                end;
            end;
        end,
        JoinMatchmaking = function(p88) --[[ Name: JoinMatchmaking, Line 458 ]]
            -- upvalues: u10 (ref), u64 (copy), u66 (copy)
            u10:CreateSound("Button", nil, true, "UISounds", "JoinQueue").Destroy(6);
            u64.MatchmakingQueue = p88;
            u64.MatchmakingStarted = tick();
            u64.IsMatchmaking = true;
            u66:_update();
        end,
        SendInvite = function(p89) --[[ Name: SendInvite, Line 468 ]]
            -- upvalues: u10 (ref), u12 (ref)
            u10:CreateSound("Button", nil, true, "UISounds", "InviteSend").Destroy(2);
            u12:Slide("Invite Sent", p89 .. " has been invited to your lobby", {});
        end,
        ReceiveInvited = function(u90, u91, p92) --[[ Name: ReceiveInvited, Line 474 ]]
            -- upvalues: u66 (copy), u10 (ref), u4 (ref), u12 (ref)
            if u66._inviteBlocks[u90] then
            else
                u10:CreateSound("Button", nil, true, "UISounds", "InviteReceive").Destroy(2);
                local v93 = {
                    { "Join", function() --[[ Line: 483 ]]
                            -- upvalues: u4 (ref), u90 (copy)
                            u4:FireServer("AcceptInvite", u90);
                        end }
                };
                if p92 then
                    v93[2] = { "Block", function() --[[ Line: 488 ]]
                            -- upvalues: u12 (ref), u91 (copy), u66 (ref), u90 (copy)
                            u12:Open("Block \'" .. u91 .. "\'", "Are you sure you want to block \'" .. u91 .. "\' from sending you lobby invitations?", {
                                { "Block", function() --[[ Line: 490 ]]
                                        -- upvalues: u66 (ref), u90 (ref), u12 (ref)
                                        u66._inviteBlocks[u90] = true;
                                        u12:Close();
                                    end },
                                { "Cancel", function() --[[ Line: 494 ]]
                                        -- upvalues: u12 (ref)
                                        u12:Close();
                                    end }
                            });
                        end };
                end;
                u12:Slide("Received Invite", u91 .. " has sent you an invite to join their lobby", v93, 10);
            end;
        end,
        PopupInformation = function(p94, p95) --[[ Name: PopupInformation, Line 504 ]]
            -- upvalues: u12 (ref)
            u12:Open(p94, p95, {
                { "Close", function() --[[ Line: 506 ]]
                        -- upvalues: u12 (ref)
                        u12:Close();
                    end }
            });
        end
    });
    return u66;
end;
function u25.Enable(p96, p97) --[[ Line: 516 ]]
    -- upvalues: u16 (copy), u17 (copy), u3 (copy), u15 (copy), u12 (copy), u10 (copy), u6 (copy)
    if p96._enabled then
    else
        p96._pages = p97;
        u16:SetVisible(false);
        u17:SetPlayerInfoVisible(false);
        p96._setCamera();
        p96._logoTween:SetValue(0);
        p96._logoTween:SetGoal(1);
        p96._openTimer = tick();
        p96._enabled = true;
        p96._handle = u3.mount(u3.createElement(u15, {
            Pages = p97,
            SetCamera = p96._setCamera,
            LogoTween = p96._logoTween,
            MoneyBinding = p96._moneyBinding,
            ExpBinding = p96._expBinding,
            ExpandedTween = p96._expandedTween,
            IconsEnabled = p96._iconsEnabled,
            UpdateLoadout = p96._updateLoadout,
            PopupActive = u12.PopupOpen,
            PrivateServerData = p96._privateServerData,
            MatchmakingQueueData = p96._matchmakingQueueData
        }), p96._ui);
        p96._menuMusic = u10:CreateSound("Music", nil, true, "Music", "MainMenu");
        u6.MenuOpen = true;
    end;
end;
function u25.Disable(p98) --[[ Line: 553 ]]
    -- upvalues: u16 (copy), u17 (copy), u3 (copy), u8 (copy), u6 (copy)
    if p98._enabled then
        p98._menuMusic.FadeOut();
        p98._menuMusic = nil;
        u16:SetVisible(true);
        u17:SetPlayerInfoVisible(true);
        p98._enabled = false;
        u3.unmount(p98._handle);
        u8:SetOverride();
        u6.MenuOpen = false;
    end;
end;
function u25.Update(p99, _, p100) --[[ Line: 570 ]]
    -- upvalues: u19 (copy), u14 (copy), u31 (copy), l__CurrentCamera__2 (copy), u18 (copy), u7 (copy)
    local v101 = tick();
    if p99._enabled then
        local v102 = u19(u14.MoneyBinding:getValue());
        local v103 = u14.EXP .. "/" .. u14.MaxEXP .. " EXP (LVL. " .. u14.Level .. ")";
        if p99._expandedTween:GetValue() < 0.5 then
            v103 = "LVL. " .. u14.Level;
        end;
        local v104 = (v101 - p99._openTimer) / 0.2;
        p99._updateMoney((u31(v102, v104)));
        p99._updateExp((u31(v103, v104)));
        local l___cameraSettings__5 = p99._cameraSettings;
        local v105 = p100 * 10;
        local l__CFrame__6 = l___cameraSettings__5.CFrame;
        if l___cameraSettings__5.DoesShake then
            l__CFrame__6 = l__CFrame__6 * CFrame.new(math.sin(v101 * 0.5) * 0.1, math.sin(v101 * 0.4) * 0.2, 0);
        end;
        l__CurrentCamera__2.FieldOfView = u18.Lerp(l__CurrentCamera__2.FieldOfView, l___cameraSettings__5.FieldOfView, v105);
        if l___cameraSettings__5.Force then
            l__CurrentCamera__2.CFrame = l___cameraSettings__5.Force;
        else
            l__CurrentCamera__2.CFrame = l__CurrentCamera__2.CFrame:Lerp(l__CFrame__6, v105);
        end;
        l__CurrentCamera__2.Focus = l__CurrentCamera__2.CFrame;
        local l___menuMusic__7 = p99._menuMusic;
        if l___menuMusic__7 then
            l___menuMusic__7.Sound.Volume = math.lerp(l___menuMusic__7.Sound.Volume, l___cameraSettings__5.StopMusic and 0 or l___menuMusic__7.Volume, p100);
        end;
        local l__ViewportSize__8 = l__CurrentCamera__2.ViewportSize;
        local l___matchmakingQueueData__9 = p99._matchmakingQueueData;
        local v106 = u7.Blur.Size > 10 and true or (l___matchmakingQueueData__9.IsMatchmaking or l___matchmakingQueueData__9.JoiningSession);
        for _, v107 in p99._currentModels do
            if v107.Icon then
                v107.Icon.Enabled = not v106;
                v107.Icon.Size = UDim2.new(10, 0, 0, l__ViewportSize__8.Y / 11.2);
            end;
        end;
        local v108 = workspace.Terrain:FindFirstChild("MenuBillboard");
        if v108 then
            v108.Gui.Enabled = true;
            v108.Gui.Size = UDim2.fromOffset(l__ViewportSize__8.X + 100, l__ViewportSize__8.Y + 10);
        end;
        local v109 = workspace:FindFirstChild("MenuBackdrop");
        if v109 then
            local l__Light__10 = v109.Blue.Light;
            local v110 = math.noise(tick() % 1000000, 0, 0);
            l__Light__10.Brightness = math.abs(v110) + 0.5;
        end;
    end;
end;
return u25.new();