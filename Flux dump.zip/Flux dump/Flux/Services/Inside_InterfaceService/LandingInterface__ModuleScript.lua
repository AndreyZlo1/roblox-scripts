-- Services.InterfaceService.LandingInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4, _ = shared.import("require", "network", "Roact", "Enum", "server");
local u5 = v1("GameShellProxyService");
local u6 = v1("RoactTween");
local u7 = v1("LandingComponent");
local u8 = v1("SoundService");
local l__Players__1 = game:GetService("Players");
local l__TeleportService__2 = game:GetService("TeleportService");
local l__LocalPlayer__3 = l__Players__1.LocalPlayer;
local u9 = {};
u9.__index = u9;
function u9.new() --[[ Line: 27 ]]
    -- upvalues: u3 (copy), u6 (copy), u5 (copy), u4 (copy), u7 (copy), u9 (copy), u2 (copy), l__LocalPlayer__3 (copy), l__TeleportService__2 (copy)
    local v10 = not shared.landing and "CONNECTING TO SESSION" or shared.landing:WaitForChild("Frame"):WaitForChild("Message").Text;
    local v11, v12 = u3.createBinding("");
    local v13, v14 = u3.createBinding(v10);
    local v15, v16 = u3.createBinding(tick());
    local v17 = u6.new(0);
    local v18, u19 = u5:CreateProxy(12, u4.ShellPriority.AlwaysVisible, "LandingInterface");
    local v20 = {
        Enabled = true,
        _handle = u3.mount(u3.createElement(u7, {
            LandingBinding = v13,
            TickBinding = v15,
            TransparencyTween = v17,
            MessageBinding = v11
        }), v18),
        _message = v10,
        TransparencyTween = v17,
        _updateLanding = v14,
        _updateMessage = v12,
        _update = v16
    };
    local u21 = setmetatable(v20, u9);
    if shared.landing then
        u21.SkipIntro = true;
        task.defer(shared.landing.Destroy, shared.landing);
    end;
    u2:ConnectEvents({
        UpdateLanding = function(p22) --[[ Name: UpdateLanding, Line 60 ]]
            -- upvalues: u21 (copy)
            u21:Message(p22);
            if not p22 and u21._clone then
                u21._clone:Destroy();
                u21._clone = nil;
            end;
        end,
        PrepareTeleport = function() --[[ Name: PrepareTeleport, Line 68 ]]
            -- upvalues: u21 (copy), u19 (copy), l__LocalPlayer__3 (ref), l__TeleportService__2 (ref)
            if u21._clone then
                u21._clone:Destroy();
            end;
            local v23 = u19:Clone();
            local l__Frame__4 = v23.Frame;
            l__Frame__4.Background.BackgroundTransparency = 0;
            l__Frame__4.Message.TextTransparency = 0;
            l__Frame__4.Red:Destroy();
            l__Frame__4.Blue:Destroy();
            l__Frame__4.White.GroupTransparency = 0.5;
            v23.DisplayOrder = 10;
            u21._clone = v23;
            task.delay(0.5, function() --[[ Line: 84 ]]
                -- upvalues: u21 (ref), l__LocalPlayer__3 (ref)
                if u21._clone then
                    u21._clone.Parent = l__LocalPlayer__3.PlayerGui;
                end;
            end);
            l__TeleportService__2:SetTeleportGui(v23);
        end
    });
    return u21;
end;
function u9.Message(p24, p25) --[[ Line: 97 ]]
    p24._message = p25;
    if p25 then
        p24.Enabled = true;
        p24.TransparencyTween:SetGoal(0);
        p24._updateLanding(p25:upper());
    else
        p24.Enabled = false;
        p24.TransparencyTween:SetGoal(1);
        p24._updateLanding("");
    end;
end;
function u9.Update(p26, _) --[[ Line: 110 ]]
    -- upvalues: u8 (copy)
    u8.DiegeticMix.Landing = p26.TransparencyTween:GetValue();
    if p26.Enabled then
        p26._update(tick() * 2);
    end;
end;
return u9.new();