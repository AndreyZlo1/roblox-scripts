-- Services.InterfaceService.PauseInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Enum", "Roact", "network");
local u5 = v1("PostProcessingService");
local u6 = v1("GameShellProxyService");
local u7 = v1("InventoryInterface");
local u8 = v1("StatsService");
local u9 = v1("InputService");
local u10 = v1("PopupInterface");
local u11 = v1("HQManagerInterface");
local u12 = v1("RoactTween");
local u13 = v1("PauseComponent");
local u14 = {
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "#",
    "$",
    "%",
    "&",
    "@"
};
local u15 = {};
u15.__index = u15;
local function u21(p16, p17) --[[ Line: 32 ]]
    -- upvalues: u14 (copy)
    if p17 > 1 then
        return p16;
    end;
    local v18 = math.floor(#p16 * (1 - p17));
    local v19 = "";
    for v20 = 1, #p16 do
        if v18 < v20 then
            v19 = v19 .. p16:sub(v20, v20);
        else
            v19 = v19 .. u14[math.random(1, #u14)];
        end;
    end;
    return v19;
end;
local u22 = v1("formatNumber");
function u15._update(p23) --[[ Line: 51 ]]
    -- upvalues: u9 (copy), u7 (copy), u3 (copy), u13 (copy), u10 (copy)
    local l___enabled__1 = p23._enabled;
    p23._blur.Size = l___enabled__1 and 20 or 0;
    u9.PauseOpen = l___enabled__1;
    if l___enabled__1 and u9.InventoryOpen then
        u7:ForceClose();
    end;
    p23._handle = u3.update(p23._handle, u3.createElement(u13, {
        PopupActive = u10.PopupOpen,
        Enabled = l___enabled__1
    }));
end;
function u15.new() --[[ Line: 67 ]]
    -- upvalues: u6 (copy), u2 (copy), u12 (copy), u3 (copy), u5 (copy), u15 (copy), u10 (copy)
    local v24, v25 = u6:CreateProxy(10, u2.ShellPriority.AlwaysVisible, "PauseInterface");
    v25.ScreenInsets = u2.ScreenInsets.None;
    local v26 = u12.new(0);
    local v27 = u12.new(0);
    local v28, v29 = u3.createBinding();
    local v30, v31 = u3.createBinding();
    local v32 = {
        _enabled = false,
        _openTimer = 0,
        _ui = v24,
        _enabledTween = v26,
        _logoTween = v27,
        _blur = u5:AddBlur(nil, nil, true),
        _updateMoney = v29,
        _updateExp = v31,
        _moneyBinding = v28,
        _expBinding = v30
    };
    local u33 = setmetatable(v32, u15);
    u10.PopupChanged:Connect(function() --[[ Line: 91 ]]
        -- upvalues: u33 (copy)
        if u33._handle then
            u33:_update();
        end;
    end);
    return u33;
end;
function u15.Enable(u34) --[[ Line: 100 ]]
    -- upvalues: u3 (copy), u13 (copy), u10 (copy), u9 (copy), u11 (copy), u4 (copy)
    if u34._toggleControls then
    else
        u34._handle = u3.mount(u3.createElement(u13, {
            PopupActive = u10.PopupOpen,
            Enabled = u34._enabled,
            LogoTween = u34._logoTween,
            MoneyBinding = u34._moneyBinding,
            ExpBinding = u34._expBinding
        }), u34._ui);
        u34._toggleControls = u9:Connect({
            PauseMenu = function(p35) --[[ Name: PauseMenu, Line 114 ]]
                -- upvalues: u9 (ref), u11 (ref), u34 (copy), u4 (ref)
                if u9.TabletOpen or u11.Open then
                else
                    if p35 then
                        u34._logoTween:SetValue(0);
                        u34._logoTween:SetGoal(1);
                        u34._openTimer = tick();
                        u34._enabled = not u34._enabled;
                        u4:FireServer("PauseMenu", u34._enabled);
                        u34:_update();
                    end;
                end;
            end
        });
    end;
end;
function u15.Disable(p36) --[[ Line: 132 ]]
    -- upvalues: u3 (copy)
    if p36._toggleControls then
        p36._toggleControls:Disconnect();
        p36._toggleControls = nil;
        p36._enabled = false;
        p36:_update();
        u3.unmount(p36._handle);
    end;
end;
function u15.Update(p37, _) --[[ Line: 146 ]]
    -- upvalues: u22 (copy), u8 (copy), u21 (copy)
    local v38 = tick();
    if p37._enabled then
        local v39 = u22(u8.Money);
        local v40 = u8.EXP .. "/" .. u8.MaxEXP .. " EXP (LVL. " .. u8.Level .. ")";
        local v41 = (v38 - p37._openTimer) / 0.2;
        p37._updateMoney((u21(v39, v41)));
        p37._updateExp((u21(v40, v41)));
    end;
end;
return u15.new();