-- Services.InterfaceService.RadioInterface.ChatComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local u1 = shared.import("Roact");
local l__TextService__1 = game:GetService("TextService");
local v2 = u1.PureComponent:extend("Chat");
local u3 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
function v2.init(p4, p5) --[[ Line: 9 ]]
    -- upvalues: u3 (copy), l__TextService__1 (copy)
    local l__user__2 = p5.user;
    local l__message__3 = p5.message;
    local l__size__4 = p5.size;
    local v6 = math.floor(l__size__4.Y * 0.1);
    local v7 = Instance.new("GetTextBoundsParams");
    v7.Text = l__user__2 .. ": ";
    v7.Font = u3;
    v7.Size = v6;
    v7.Width = (1 / 0);
    local v8 = l__TextService__1:GetTextBoundsAsync(v7);
    local v9 = v8.X / l__size__4.X;
    local v10 = Instance.new("GetTextBoundsParams");
    v10.Text = l__message__3;
    v10.Font = u3;
    v10.Size = v6;
    v10.Width = l__size__4.X * (1 - v9);
    local v11 = l__TextService__1:GetTextBoundsAsync(v10);
    p4:setState({
        height = v11.Y / l__size__4.Y,
        width = v9,
        tag = v8.Y / v11.Y
    });
end;
function v2.render(p12) --[[ Line: 38 ]]
    -- upvalues: u1 (copy), u3 (copy)
    local l__user__5 = p12.props.user;
    local l__color__6 = p12.props.color;
    local l__message__7 = p12.props.message;
    local l__order__8 = p12.props.order;
    local l__height__9 = p12.state.height;
    local l__width__10 = p12.state.width;
    local l__tag__11 = p12.state.tag;
    return u1.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, l__height__9, 0),
        LayoutOrder = l__order__8
    }, {
        Tag = u1.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextTransparency = 0.2,
            TextScaled = true,
            AutoLocalize = false,
            Size = UDim2.new(1, 0, l__tag__11, 0),
            FontFace = u3,
            Text = l__user__5 .. ": ",
            TextColor3 = Color3.new(0, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Left
        }, {
            White = u1.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextTransparency = 0.1,
                TextScaled = true,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0),
                FontFace = u3,
                Text = l__user__5 .. ": ",
                TextColor3 = l__color__6,
                TextXAlignment = Enum.TextXAlignment.Left
            })
        }),
        Message = u1.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextWrapped = true,
            TextTransparency = 0.2,
            TextScaled = true,
            AutoLocalize = false,
            Size = UDim2.new(1 - l__width__10, 0, 1, 0),
            Position = UDim2.new(l__width__10, 0, 0, 0),
            FontFace = u3,
            Text = l__message__7,
            TextColor3 = Color3.new(0, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Left
        }, {
            White = u1.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextWrapped = true,
                TextTransparency = 0.1,
                TextScaled = true,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0),
                FontFace = u3,
                Text = l__message__7,
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = Enum.TextXAlignment.Left
            })
        })
    });
end;
return v2;