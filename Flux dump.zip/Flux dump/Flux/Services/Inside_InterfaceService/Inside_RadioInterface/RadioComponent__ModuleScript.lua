-- Services.InterfaceService.RadioInterface.RadioComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "network", "server", "Roact");
local l__HttpService__1 = game:GetService("HttpService");
game:GetService("Players");
local l__UserInputService__2 = game:GetService("UserInputService");
local l__TextChatService__3 = game:GetService("TextChatService");
local u5 = v1("InventoryService");
local u6 = v1("NotifyInterface");
local u7 = v1("ClientService");
local u8 = v1("InputService");
local u9 = v1("RoactTween");
local u10 = v1("SoundService");
local u11 = v1("ActionInterface");
local l__Main__4 = l__TextChatService__3:WaitForChild("Main");
local u12 = v1("TouchButtonComponent");
local u13 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u14 = { "Halt", "Forward", "Regroup" };
local l__CurrentCamera__5 = workspace.CurrentCamera;
local u15 = {
    [Enum.KeyCode.Zero] = 0,
    [Enum.KeyCode.One] = 1,
    [Enum.KeyCode.Two] = 2,
    [Enum.KeyCode.Three] = 3,
    [Enum.KeyCode.Four] = 4,
    [Enum.KeyCode.Five] = 5,
    [Enum.KeyCode.Six] = 6,
    [Enum.KeyCode.Seven] = 7,
    [Enum.KeyCode.Eight] = 8,
    [Enum.KeyCode.Nine] = 9
};
local u16 = {
    UDim2.fromScale(0.26, 0.88),
    UDim2.fromScale(0.23, 0.6699999999999999),
    UDim2.fromScale(0.26, 0.6699999999999999),
    UDim2.fromScale(0.29000000000000004, 0.6699999999999999),
    UDim2.fromScale(0.23, 0.74),
    UDim2.fromScale(0.26, 0.74),
    UDim2.fromScale(0.29000000000000004, 0.74),
    UDim2.fromScale(0.23, 0.81),
    UDim2.fromScale(0.26, 0.81),
    UDim2.fromScale(0.29000000000000004, 0.81)
};
local u17 = v1("ChatComponent");
local u18 = v1("KeyComponent");
local v19 = u4.Component:extend("Radio");
function v19.willUnmount(p20) --[[ Line: 64 ]]
    p20.startSound.Destroy();
    if p20._chatTransmit then
        p20._chatTransmit:Disconnect();
        p20._chatTransmit = nil;
    end;
end;
function v19.init(u21, p22) --[[ Line: 72 ]]
    -- upvalues: u4 (copy), u9 (copy), u10 (copy), u2 (copy), l__UserInputService__2 (copy), u15 (copy), u8 (copy)
    u21.chats = p22.Chats;
    u21.chat = u4.createRef();
    u21.switch = u9.new(0);
    local v23, v24 = u4.createBinding(false);
    u21.offScreen = v23;
    u21.updateOffScreen = v24;
    local v25, v26 = u4.createBinding(0);
    u21.length = v25;
    u21.updateLength = v26;
    local v27, v28 = u4.createBinding(0);
    u21.placeholder = v27;
    u21.updatePlaceholder = v28;
    local v29, v30 = u4.createBinding(true);
    u21.enabled = v29;
    u21.updateEnabled = v30;
    local v31, v32 = u4.createBinding(true);
    u21.active = v31;
    u21.updateActive = v32;
    u21.startSound = u10:CreateSound("VoiceChat", nil, false, "Foley", "Radio", "Start");
    u21._channel = 3;
    function u21._inputFrequency(p33) --[[ Line: 88 ]]
        -- upvalues: u21 (copy), u2 (ref)
        if u21._channel == 0 then
            u21:setState({
                frequency = p33 .. "--"
            });
        elseif u21._channel == 1 then
            u21:setState({
                frequency = u21.state.frequency:sub(1, 1) .. p33 .. "-"
            });
        elseif u21._channel == 2 then
            local v34 = u21.state.frequency:sub(1, 2) .. p33;
            local v35 = tostring(v34);
            u21:setState({
                NumpadOpen = false,
                frequency = v35
            });
            u21.state.updateChannel(v35);
            u2:FireServer("ChangeChannel", v35);
        end;
        local v36 = u21;
        v36._channel = v36._channel + 1;
    end;
    l__UserInputService__2.InputBegan:Connect(function(p37) --[[ Line: 109 ]]
        -- upvalues: u21 (copy), u15 (ref)
        if u21._channel > 2 then
            return;
        end;
        local v38 = nil;
        for v39, v40 in u15 do
            if v39 == p37.KeyCode then
                v38 = v40;
                break;
            end;
        end;
        if v38 then
            u21._inputFrequency(v38);
        end;
    end);
    u8:Connect({
        Chat = function(p41) --[[ Name: Chat, Line 128 ]]
            -- upvalues: u21 (copy)
            if not p41 and u21.chat:getValue() then
                u21.switch:SetGoal(1);
                u21.chat:getValue():CaptureFocus();
            end;
        end,
        ChatChannel = function(p42) --[[ Name: ChatChannel, Line 137 ]]
            -- upvalues: u21 (copy)
            if not p42 then
                u21._channel = 0;
                u21:setState({
                    frequency = "---"
                });
            end;
        end,
        ChatRadio = function(p43) --[[ Name: ChatRadio, Line 145 ]]
            -- upvalues: u21 (copy)
            if p43 then
                u21.updateEnabled(not u21.enabled:getValue());
            end;
        end,
        ChatActive = function(p44) --[[ Name: ChatActive, Line 150 ]]
            -- upvalues: u21 (copy)
            if p44 then
                u21.updateActive(not u21.active:getValue());
            end;
        end
    });
    u8.BindingsChanged:Connect(function() --[[ Line: 156 ]]
        -- upvalues: u21 (copy), u8 (ref)
        u21:setState({
            chatRadioBind = u8:GetBind("ChatRadio"),
            chatActiveBind = u8:GetBind("ChatActive"),
            chatChannelBind = u8:GetBind("ChatChannel"),
            chatBind = u8:GetBind("Chat")
        });
    end);
    u21:setState({
        NumpadOpen = false,
        frequency = "000",
        updateChannel = p22.UpdateChannel,
        chatRadioBind = u8:GetBind("ChatRadio"),
        chatActiveBind = u8:GetBind("ChatActive"),
        chatChannelBind = u8:GetBind("ChatChannel"),
        chatBind = u8:GetBind("Chat")
    });
end;
function v19.render(u45) --[[ Line: 178 ]]
    -- upvalues: u8 (copy), u6 (copy), u3 (copy), u5 (copy), u7 (copy), u2 (copy), l__CurrentCamera__5 (copy), u4 (copy), u17 (copy), u13 (copy), u12 (copy), u16 (copy), u18 (copy), l__HttpService__1 (copy), u14 (copy), u11 (copy), l__Main__4 (copy)
    if not u45.props.Visible then
        return false;
    end;
    local l__AudioDeviceInput__6 = u45.props.AudioDeviceInput;
    if l__AudioDeviceInput__6 and not u45._chatTransmit then
        u45._chatTransmit = u8:Connect({
            ChatTransmit = function(p46) --[[ Name: ChatTransmit, Line 186 ]]
                -- upvalues: l__AudioDeviceInput__6 (copy), u6 (ref), u3 (ref), u5 (ref), u45 (copy), u7 (ref), u2 (ref)
                if l__AudioDeviceInput__6.Active then
                    if u3.RADIO_STRICT and not u5.HasRadio then
                        if p46 then
                            u6:Notify({
                                { "Alert", "You do not have a radio", Color3.new(1, 0.866666, 0.505882) }
                            });
                            p46 = false;
                        else
                            p46 = false;
                        end;
                    end;
                    if p46 then
                        u45.startSound.Play();
                    end;
                    u45.props.Transmitted();
                    u7.LocalClient.ClientTransmitting = p46;
                    u2:FireServer("TransmitVoice", p46);
                else
                    if p46 then
                        u6:Notify({
                            { "Alert", "Microphone is muted", Color3.new(1, 0.866666, 0.505882) }
                        });
                    end;
                end;
            end
        });
    end;
    local l__Touch__7 = u45.props.Touch;
    local l__state__8 = u45.state;
    local l__chats__9 = u45.chats;
    local l__ViewportSize__10 = l__CurrentCamera__5.ViewportSize;
    local v47 = Vector2.new(l__ViewportSize__10.Y * 1.778 * 0.25, l__ViewportSize__10.Y * 0.2);
    local v48 = {};
    for v49, v50 in l__chats__9 do
        v48[v49] = u4.createElement(u17, {
            user = v50.user,
            color = v50.color,
            message = v50.message,
            order = v50.order,
            size = v47
        });
    end;
    local v51 = {};
    for v52, v53 in u45.props.Transmitting do
        v51[v52] = u4.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://93458491900848",
            ImageTransparency = 0.2,
            Size = UDim2.fromScale(1, 1),
            ImageColor3 = Color3.new(0, 0, 0)
        }, { u4.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://93458491900848",
                ImageTransparency = 0.1,
                Size = UDim2.fromScale(1, 1),
                Position = UDim2.fromOffset(0, -1),
                ImageColor3 = v53.Color
            }), u4.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextTransparency = 0.2,
                TextScaled = true,
                AutoLocalize = false,
                Size = UDim2.new(100, 0, 1, 0),
                FontFace = u13,
                Position = UDim2.fromScale(1.5, 0),
                Text = v53.Name,
                TextColor3 = Color3.new(0, 0, 0),
                TextXAlignment = Enum.TextXAlignment.Left
            }, {
                White = u4.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextTransparency = 0.1,
                    TextScaled = true,
                    AutoLocalize = false,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.new(0, 0, 0, -1),
                    Size = UDim2.new(1, 0, 1, 0),
                    FontFace = u13,
                    Text = v53.Name,
                    TextColor3 = v53.Color,
                    TextXAlignment = Enum.TextXAlignment.Left
                })
            }) });
    end;
    local v54;
    if l__Touch__7 then
        local v55 = {
            u4.createElement(u12, {
                Image = "rbxassetid://15224901555",
                Size = UDim2.fromScale(0.05, 0.05),
                Position = UDim2.fromScale(0.05, 0.95),
                AnchorPoint = Vector2.new(0, 1),
                Up = function() --[[ Name: Up, Line 292 ]]
                    -- upvalues: u45 (copy)
                    u45.switch:SetGoal(1);
                    u45.chat:getValue():CaptureFocus();
                end
            }),
            u4.createElement(u12, {
                Image = "rbxassetid://15224901444",
                Size = UDim2.fromScale(0.05, 0.05),
                Position = UDim2.fromScale(0.12, 0.95),
                AnchorPoint = Vector2.new(0, 1),
                Color = u45.enabled:getValue() and Color3.fromRGB(107, 213, 95) or Color3.fromRGB(213, 92, 92),
                Up = function() --[[ Name: Up, Line 303 ]]
                    -- upvalues: u45 (copy)
                    u45.updateEnabled(not u45.enabled:getValue());
                    u45:setState({});
                end
            }),
            u4.createElement(u12, {
                Image = "rbxassetid://15224901286",
                Size = UDim2.fromScale(0.05, 0.05),
                Position = UDim2.fromScale(0.19, 0.95),
                AnchorPoint = Vector2.new(0, 1),
                Color = u45.active:getValue() and Color3.fromRGB(107, 213, 95) or Color3.fromRGB(213, 92, 92),
                Up = function() --[[ Name: Up, Line 314 ]]
                    -- upvalues: u45 (copy)
                    u45.updateActive(not u45.active:getValue());
                    u45:setState({});
                end
            }),
            u4.createElement(u12, {
                Size = UDim2.fromScale(0.05, 0.05),
                Position = UDim2.fromScale(0.26, 0.95),
                AnchorPoint = Vector2.new(0, 1),
                Text = l__state__8.frequency,
                Up = function() --[[ Name: Up, Line 324 ]]
                    -- upvalues: u45 (copy)
                    u45._channel = 0;
                    u45:setState({
                        NumpadOpen = true,
                        frequency = "---"
                    });
                end
            })
        };
        if l__state__8.NumpadOpen then
            for u56, v57 in u16 do
                v55[#v55 + 1] = u4.createElement(u12, {
                    Size = UDim2.fromScale(0.05, 0.05),
                    Position = v57,
                    AnchorPoint = Vector2.new(0, 1),
                    Text = tostring(u56 - 1),
                    Up = function() --[[ Name: Up, Line 341 ]]
                        -- upvalues: u45 (copy), u56 (copy)
                        u45._inputFrequency(u56 - 1);
                    end
                });
            end;
        end;
        v54 = u4.createFragment(v55);
    else
        local v58 = {};
        for v59, v60 in {
            {
                Description = "CHAT",
                Key = l__state__8.chatBind
            },
            {
                Description = "RADIO",
                Key = l__state__8.chatRadioBind,
                Binding = u45.enabled
            },
            {
                Description = "ACTIVE",
                Key = l__state__8.chatActiveBind,
                Binding = u45.active
            },
            {
                Key = l__state__8.chatChannelBind,
                Description = l__state__8.frequency
            }
        } do
            v58[v59] = u4.createElement(u18, {
                UsingGamepad = false,
                VisibleOnKeyboard = true,
                Key = v60.Key,
                Description = v60.Description,
                Order = -v59,
                Binding = v60.Binding,
                ViewPort = l__ViewportSize__10
            });
        end;
        v54 = u4.createElement("Frame", {
            BackgroundTransparency = 1,
            Position = UDim2.new(0.045, 0, 0.93, 0),
            Size = UDim2.new(1, 0, 0.02, 0)
        }, {
            Layout = u4.createElement("UIListLayout", {
                FillDirection = Enum.FillDirection.Horizontal,
                HorizontalAlignment = Enum.HorizontalAlignment.Left,
                SortOrder = Enum.SortOrder.LayoutOrder,
                VerticalAlignment = Enum.VerticalAlignment.Top,
                Padding = UDim.new(0.01, 0)
            }),
            u4.createFragment(v58)
        });
    end;
    return u4.createElement("Frame", {
        BackgroundTransparency = 1,
        AnchorPoint = Vector2.new(0.5, 1),
        Position = UDim2.new(0.5, 0, 1, 0),
        Size = UDim2.new(0, 0, 1, 0)
    }, {
        u4.createElement("UIAspectRatioConstraint", {
            AspectRatio = 1.778,
            AspectType = Enum.AspectType.ScaleWithParentSize,
            DominantAxis = Enum.DominantAxis.Height
        }),
        v54,
        u4.createElement("Frame", {
            ClipsDescendants = true,
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            ZIndex = 2,
            Position = UDim2.new(0.045, -1, l__Touch__7 and 0.85 or 0.93, -1),
            Size = u45.switch:Map(function(p61) --[[ Line: 412 ]]
                return UDim2.new(p61 * 0.2, 2, 0.02, 2);
            end),
            Visible = u45.switch:Map(function(p62) --[[ Line: 415 ]]
                return p62 > 0;
            end),
            BackgroundColor3 = Color3.new()
        }, { u4.createElement("UICorner", {
                CornerRadius = UDim.new(0.15, 0)
            }), u4.createElement("TextBox", {
                Selectable = false,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Size = UDim2.new(0.96, 0, 0.8, 0),
                Position = UDim2.new(0.5, 0, 0.5, 0),
                BackgroundTransparency = 1,
                FontFace = u13,
                Text = "",
                TextColor3 = Color3.new(1, 1, 1),
                TextScaled = false,
                TextSize = math.floor(l__ViewportSize__10.Y * 0.02 * 0.8),
                TextXAlignment = u45.offScreen:map(function(p63) --[[ Line: 438 ]]
                    if p63 then
                        return Enum.TextXAlignment.Right;
                    else
                        return Enum.TextXAlignment.Left;
                    end;
                end),
                ClearTextOnFocus = false,
                MultiLine = false,
                AutoLocalize = false,
                [u4.Ref] = u45.chat,
                [u4.Change.Text] = function(p64) --[[ Line: 449 ]]
                    -- upvalues: u45 (copy)
                    u45.updateOffScreen(p64.TextBounds.X > p64.AbsoluteSize.X);
                end,
                [u4.Event.FocusLost] = function(p65, p66) --[[ Line: 452 ]]
                    -- upvalues: l__HttpService__1 (ref), u5 (ref), u45 (copy), l__state__8 (copy), u14 (ref), u11 (ref), l__Main__4 (ref)
                    local l__Text__11 = p65.Text;
                    if p66 and #l__Text__11 > 0 then
                        local v67 = l__HttpService__1;
                        local v68 = {
                            HasRadio = u5.HasRadio
                        };
                        local v69 = u45.enabled:getValue();
                        if v69 then
                            v69 = u45.active:getValue();
                        end;
                        v68.Radio = v69;
                        v68.Channel = l__state__8.frequency;
                        local v70 = v67:JSONEncode(v68);
                        for _, v71 in u14 do
                            if l__Text__11:lower() == v71:lower() then
                                u11:DoEmote(v71);
                            end;
                        end;
                        l__Main__4:SendAsync(l__Text__11, v70);
                        u45.props.Transmitted();
                        p65.Text = "";
                    end;
                    u45.switch:SetGoal(0);
                end
            }) }),
        u4.createElement("CanvasGroup", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0, 1),
            Position = UDim2.fromScale(0.045, l__Touch__7 and 0.8 or 0.9),
            Size = UDim2.fromScale(0.25, 0.2),
            Visible = u45.enabled
        }, {
            u4.createElement("UIGradient", {
                Rotation = -90,
                Color = ColorSequence.new(Color3.new(1, 1, 1)),
                Offset = Vector2.new(0, 0),
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0), NumberSequenceKeypoint.new(1, 1) })
            }),
            u4.createElement("UIListLayout", {
                Padding = UDim.new(0, 2),
                FillDirection = Enum.FillDirection.Vertical,
                HorizontalAlignment = Enum.HorizontalAlignment.Left,
                SortOrder = Enum.SortOrder.LayoutOrder,
                VerticalAlignment = Enum.VerticalAlignment.Bottom
            }),
            u4.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "You need to find a radio to transmit messages.",
                TextWrapped = true,
                TextTransparency = 0.2,
                TextScaled = true,
                Size = UDim2.new(1, 0, 0.1, 0),
                FontFace = u13,
                Visible = u45.props.NoRadio,
                TextColor3 = Color3.new(0, 0, 0),
                TextXAlignment = Enum.TextXAlignment.Left
            }, {
                White = u4.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextWrapped = true,
                    Text = "You need to find a radio to transmit messages.",
                    TextTransparency = 0.1,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.new(0, 0, 0, -1),
                    Size = UDim2.new(1, 0, 1, 0),
                    FontFace = u13,
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = Enum.TextXAlignment.Left
                })
            }),
            u4.createFragment(v48)
        }),
        u4.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(0.02, 0.02),
            Position = UDim2.fromScale(0.02, 0.67),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }, { u4.createElement("UIListLayout", {
                Padding = UDim.new(0.3, 0),
                FillDirection = Enum.FillDirection.Vertical,
                HorizontalAlignment = Enum.HorizontalAlignment.Left,
                SortOrder = Enum.SortOrder.LayoutOrder,
                VerticalAlignment = Enum.VerticalAlignment.Bottom
            }), u4.createFragment(v51) })
    });
end;
return v19;