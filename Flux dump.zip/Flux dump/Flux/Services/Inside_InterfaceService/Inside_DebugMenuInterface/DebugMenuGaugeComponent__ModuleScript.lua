-- Services.InterfaceService.DebugMenuInterface.DebugMenuGaugeComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local v3 = u2.Component:extend("DebugMenuGaugeComponent");
local u4 = v1("DebugService");
function v3.init(p5) --[[ Line: 7 ]]
    -- upvalues: u4 (copy)
    local u6 = p5.props.Data.DataBinding:getValue();
    p5.Binding = p5.props.Data.DataBinding:map(function(p7) --[[ Line: 9 ]]
        -- upvalues: u4 (ref), u6 (ref)
        if not u4:ReadValue("DebugMenuStatsPaused") then
            u6 = p7;
        end;
        return u6;
    end);
end;
function v3.render(p8) --[[ Line: 18 ]]
    -- upvalues: u2 (copy)
    local l__Data__1 = p8.props.Data;
    local l__Name__2 = l__Data__1.Name;
    local l__Num__3 = l__Data__1.Num;
    local u9 = l__Data__1.Params[1];
    local u10 = l__Data__1.Params[2];
    local u11 = u10 - u9;
    return u2.createElement("Frame", {
        BackgroundTransparency = 0.4,
        Size = UDim2.new(1, 0, 0, 15),
        LayoutOrder = l__Num__3,
        BackgroundColor3 = Color3.new()
    }, { u2.createElement("Frame", {
            BackgroundTransparency = 0.3,
            AnchorPoint = p8.Binding:map(function(p12) --[[ Line: 34 ]]
                return p12 <= 0 and Vector2.new(1, 0.5) or Vector2.new(0, 0.5);
            end),
            Position = p8.Binding:map(function(_) --[[ Line: 37 ]]
                -- upvalues: u9 (copy), u10 (copy), u11 (copy)
                return UDim2.new((math.clamp(0, u9, u10) - u9) / u11, 0, 0.5, 0);
            end),
            Size = p8.Binding:map(function(p13) --[[ Line: 40 ]]
                -- upvalues: u9 (copy), u10 (copy), u11 (copy)
                local v14 = (math.clamp(0, u9, u10) - u9) / u11;
                local v15 = (math.clamp(p13, u9, u10) - u9) / u11 - v14;
                local v16 = math.abs(v15);
                return UDim2.new(v16, 0, 1, 0);
            end),
            BackgroundColor3 = p8.Binding:map(function(p17) --[[ Line: 48 ]]
                if p17 < 0 then
                    return Color3.new(1, 0, 0);
                elseif p17 > 0 then
                    return Color3.new(0, 1, 0);
                else
                    return Color3.new(1, 1, 1);
                end;
            end)
        }, { u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 2)
            }), u2.createElement("UISizeConstraint", {
                MinSize = Vector2.new(1, 0)
            }) }), u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 4)
        }), u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            Size = UDim2.new(1, 0, 0, 14),
            Position = UDim2.new(0, 0, 1, 1),
            Font = Enum.Font.Roboto,
            TextColor3 = Color3.new(1, 1, 1),
            Text = p8.Binding:map(function(p18) --[[ Line: 77 ]]
                -- upvalues: l__Name__2 (copy)
                return string.format("%s: (%.7f)", l__Name__2, p18);
            end)
        }, { u2.createElement("UIStroke", {
                Thickness = 1,
                ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                Color = Color3.new()
            }) }) });
end;
return v3;