-- Services.InterfaceService.DebugMenuInterface.DebugSliderComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local u3 = v1("ExpressionParser");
local u4 = v1("GameShellProxyButton");
local l__RunService__1 = game:GetService("RunService");
local l__UserInputService__2 = game:GetService("UserInputService");
local v5 = u2.Component:extend("DebugSlider");
local u6 = setmetatable({}, {
    __mode = "v"
});
function v5.init(p7) --[[ Line: 43 ]]
    -- upvalues: u2 (copy)
    local l__props__3 = p7.props;
    p7.Ref = u2.createRef();
    local l__createBinding__4 = u2.createBinding;
    local l__InitialValue__5 = l__props__3.InitialValue;
    local l__Min__6 = l__props__3.Min;
    local v8, v9 = l__createBinding__4((l__InitialValue__5 - l__Min__6) / (l__props__3.Max - l__Min__6));
    p7.Position = v8;
    p7.UpdatePosition = v9;
    local v10, v11 = u2.createBinding(l__props__3.InitialValue);
    p7.Text = v10;
    p7.UpdateText = v11;
end;
function v5.render(u12) --[[ Line: 52 ]]
    -- upvalues: u2 (copy), u4 (copy), u6 (copy), u3 (copy)
    local l__Ref__7 = u12.Ref;
    local l__props__8 = u12.props;
    local l__Min__9 = l__props__8.Min;
    local l__Max__10 = l__props__8.Max;
    local l__Increment__11 = l__props__8.Increment;
    local l__Callback__12 = l__props__8.Callback;
    return u2.createFragment({ u2.createElement(u4, {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.4,
            Size = UDim2.fromScale(0.7, 0.5),
            BorderColor3 = Color3.new(),
            BackgroundColor3 = Color3.new(0.16, 0.16, 0.16),
            AnchorPoint = Vector2.new(0, 0.5),
            Position = UDim2.fromScale(0, 0.5),
            Ref = l__Ref__7,
            MouseDown = function() --[[ Name: MouseDown, Line 72 ]]
                -- upvalues: u6 (ref), u12 (copy)
                u6[1] = u12;
            end
        }, { u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }), u2.createElement(u4, {
                BorderSizePixel = 0,
                Size = UDim2.new(0, 2, 1.8, 0),
                BackgroundColor3 = Color3.new(0, 1, 0),
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = u12.Position:map(function(p13) --[[ Line: 84 ]]
                    return UDim2.new(p13, 0, 0.5, 0);
                end),
                MouseDown = function() --[[ Name: MouseDown, Line 88 ]]
                    -- upvalues: u6 (ref), u12 (copy)
                    u6[1] = u12;
                end
            }, { u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0, 4)
                }) }) }), u2.createElement("TextBox", {
            Position = UDim2.new(1, 5, 0.5, 0),
            AnchorPoint = Vector2.new(1, 0.5),
            Size = UDim2.fromScale(0.28, 1),
            MultiLine = false,
            TextScaled = false,
            BorderSizePixel = 0,
            BorderColor3 = Color3.new(),
            Font = Enum.Font.Roboto,
            TextEditable = true,
            TextColor3 = Color3.new(1, 1, 1),
            ClearTextOnFocus = false,
            BackgroundColor3 = Color3.new(0.16, 0.16, 0.16),
            BackgroundTransparency = 0.4,
            TextTruncate = Enum.TextTruncate.None,
            Text = u12.Text,
            [u2.Event.FocusLost] = function(p14, _) --[[ Line: 116 ]]
                -- upvalues: u3 (ref), l__Increment__11 (copy), u12 (copy), l__Min__9 (copy), l__Max__10 (copy), l__props__8 (copy), l__Callback__12 (copy)
                local v15, v16 = pcall(u3.Evaluate, p14.Text);
                if v15 and v16 then
                    if l__Increment__11 then
                        local v17 = l__Increment__11;
                        if v17 then
                            local v18 = 1 / v17;
                            v16 = math.floor(v16 * v18 + 0.5) / v18;
                        end;
                    end;
                    local v19 = l__Min__9;
                    u12.UpdatePosition((v16 - v19) / (l__Max__10 - v19));
                    u12.UpdateText(v16);
                    l__props__8.InitialValue = v16;
                    l__Callback__12(v16);
                end;
            end
        }, { u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }) }) });
end;
local function u25(_) --[[ Line: 141 ]]
    -- upvalues: u6 (copy), l__UserInputService__2 (copy)
    local v20 = u6[1];
    local v21 = v20 and v20.Ref:getValue();
    if v21 then
        local l__props__13 = v20.props;
        local l__Min__14 = l__props__13.Min;
        local l__Max__15 = l__props__13.Max;
        local l__Increment__16 = l__props__13.Increment;
        local l__Callback__17 = l__props__13.Callback;
        local l__X__18 = l__UserInputService__2:GetMouseLocation().X;
        local l__X__19 = v21.AbsolutePosition.X;
        local v22 = l__Min__14 + (l__X__18 - l__X__19) / (l__X__19 + v21.AbsoluteSize.X - l__X__19) * (l__Max__15 - l__Min__14);
        if l__Increment__16 then
            local v23 = 1 / l__Increment__16;
            v22 = math.floor(v22 * v23 + 0.5) / v23;
        end;
        local v24 = math.clamp(v22, l__Min__14, l__Max__15);
        v20.UpdatePosition((v24 - l__Min__14) / (l__Max__15 - l__Min__14));
        v20.UpdateText(v24);
        l__props__13.InitialValue = v24;
        l__Callback__17(v24);
    end;
end;
l__RunService__1.RenderStepped:Connect(function() --[[ Name: HandleMouseMove, Line 176 ]]
    -- upvalues: u25 (copy)
    u25(false);
end);
l__UserInputService__2.InputEnded:Connect(function(p26) --[[ Line: 181 ]]
    -- upvalues: u25 (copy), u6 (copy)
    if p26.UserInputType == Enum.UserInputType.MouseButton1 then
        u25(true);
        table.clear(u6);
    end;
end);
return v5;