-- Services.InterfaceService.DebugMenuInterface.DebugMenuComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local l__GuiService__1 = game:GetService("GuiService");
game:GetService("TextService");
local v1, u2 = shared.import("require", "Roact");
local u3 = v1("DebugSliderComponent");
local u4 = v1("DebugMenuGaugeComponent");
local u5 = v1("DebugToggleComponent");
local u6 = v1("DebugMenuGraphComponent");
local u7 = v1("GameShellProxyScroller");
local v8 = u2.Component:extend("DebugMenu");
function v8.init(_, _) --[[ Line: 13 ]] end;
local function u14(p9) --[[ Line: 17 ]]
    -- upvalues: u2 (copy), u3 (copy), u5 (copy)
    local l__Kind__2 = p9.Kind;
    local l__Name__3 = p9.Name;
    local l__Params__4 = p9.Params;
    local l__Callback__5 = p9.Callback;
    local v10 = #string.split(l__Name__3, ".") - 1;
    local v11 = nil;
    if l__Kind__2 == "Slider" then
        v11 = u2.createElement(u3, {
            InitialValue = l__Params__4[1],
            Min = l__Params__4[2],
            Max = l__Params__4[3],
            Increment = l__Params__4[4],
            Callback = function(p12) --[[ Name: Callback, Line 34 ]]
                -- upvalues: l__Params__4 (copy), l__Callback__5 (copy)
                l__Params__4[1] = p12;
                l__Callback__5(p12);
            end
        });
    elseif l__Kind__2 == "Toggleable" then
        v11 = u2.createElement(u5, {
            InitialValue = l__Params__4[1],
            Callback = function(p13) --[[ Name: Callback, Line 42 ]]
                -- upvalues: l__Params__4 (copy), l__Callback__5 (copy)
                l__Params__4[1] = p13;
                l__Callback__5(p13);
            end
        });
    end;
    return u2.createElement("Frame", {
        BorderSizePixel = 0,
        Size = UDim2.new(1, -10 - v10 * 12, 0, 20),
        LayoutOrder = p9.Num,
        BackgroundTransparency = p9.Num % 2 == 0 and 1 or 0.93,
        BackgroundColor3 = Color3.new(1, 0, 0)
    }, { u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextSize = 12,
            Size = UDim2.new(0.4, -5, 1, 0),
            Text = l__Name__3,
            Font = Enum.Font.Roboto,
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = Enum.TextXAlignment.Left,
            TextYAlignment = Enum.TextYAlignment.Center
        }, { u2.createElement("UIStroke", {
                Thickness = 1,
                ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                Color = Color3.new()
            }) }), u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.new(0.6, 0, 1, 0),
            AnchorPoint = Vector2.new(1, 0),
            Position = UDim2.new(1, 0, 0, 0)
        }, { v11 }) });
end;
function v8.render(p15) --[[ Line: 85 ]]
    -- upvalues: u14 (copy), u2 (copy), u6 (copy), u4 (copy), u7 (copy), l__GuiService__1 (copy)
    local l__props__6 = p15.props;
    local l__Components__7 = l__props__6.Components;
    local l__Enabled__8 = l__props__6.Enabled;
    local v16 = {};
    local v17 = {};
    local v18 = {};
    for _, v19 in l__Components__7 do
        if v19.Kind == "Slider" then
            table.insert(v18, u14(v19));
        elseif v19.Kind == "Toggleable" then
            table.insert(v17, u14(v19));
        elseif v19.Kind == "Graph" then
            table.insert(v16, u2.createElement(u6, {
                Data = v19
            }));
        elseif v19.Kind == "Gauge" then
            table.insert(v16, u2.createElement(u4, {
                Data = v19
            }));
        end;
    end;
    v18.ListLayout = u2.createElement("UIListLayout", {
        Padding = UDim.new(0, 3),
        FillDirection = Enum.FillDirection.Vertical,
        HorizontalAlignment = Enum.HorizontalAlignment.Right,
        SortOrder = Enum.SortOrder.LayoutOrder,
        VerticalAlignment = Enum.VerticalAlignment.Top
    });
    v17.ListLayout = u2.createElement("UIListLayout", {
        Padding = UDim.new(0, 3),
        FillDirection = Enum.FillDirection.Vertical,
        HorizontalAlignment = Enum.HorizontalAlignment.Right,
        SortOrder = Enum.SortOrder.LayoutOrder,
        VerticalAlignment = Enum.VerticalAlignment.Top
    });
    v16.ListLayout = u2.createElement("UIListLayout", {
        Padding = UDim.new(0, 20),
        FillDirection = Enum.FillDirection.Vertical,
        HorizontalAlignment = Enum.HorizontalAlignment.Right,
        SortOrder = Enum.SortOrder.LayoutOrder,
        VerticalAlignment = Enum.VerticalAlignment.Top
    });
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Visible = l__Enabled__8,
        Size = UDim2.fromScale(1, 1)
    }, { u2.createElement(u7, {
            RequiresFocus = true,
            ScrollingSize = 0,
            BackgroundTransparency = 1,
            CanvasSize = 6,
            Position = UDim2.fromOffset(10, 10 + l__GuiService__1:GetGuiInset().Y),
            Size = UDim2.fromScale(0.4, 0.5),
            Content = v18
        }), u2.createElement(u7, {
            RequiresFocus = true,
            ScrollingSize = 0,
            BackgroundTransparency = 1,
            CanvasSize = 3,
            Position = UDim2.new(0.42, 10, 0, 10 + l__GuiService__1:GetGuiInset().Y),
            Size = UDim2.fromScale(0.16, 0.5),
            Content = v17
        }), u2.createElement(u7, {
            RequiresFocus = true,
            ScrollingSize = 0,
            BackgroundTransparency = 1,
            CanvasSize = 3,
            Position = UDim2.new(0.6, 10, 0, 10 + l__GuiService__1:GetGuiInset().Y),
            Size = UDim2.fromScale(0.3, 0.87),
            Content = v16
        }) });
end;
return v8;