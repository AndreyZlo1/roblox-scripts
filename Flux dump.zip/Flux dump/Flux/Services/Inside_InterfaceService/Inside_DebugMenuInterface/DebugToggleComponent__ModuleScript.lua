-- Services.InterfaceService.DebugMenuInterface.DebugToggleComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local v3 = u2.Component:extend("DebugToggleComponent");
local u4 = v1("GameShellProxyButton");
function v3.init(p5) --[[ Line: 8 ]]
    -- upvalues: u2 (copy)
    local v6, v7 = u2.createBinding(p5.props.InitialValue);
    p5.ValBind = v6;
    p5.UpdValBind = v7;
end;
function v3.render(u8) --[[ Line: 12 ]]
    -- upvalues: u2 (copy), u4 (copy)
    local l__Ref__1 = u8.Ref;
    local l__props__2 = u8.props;
    local l__InitialValue__3 = l__props__2.InitialValue;
    local l__Callback__4 = l__props__2.Callback;
    return u2.createFragment({ u2.createElement(u4, {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.4,
            Size = UDim2.fromScale(0.3, 0.9),
            BorderColor3 = Color3.new(),
            BackgroundColor3 = Color3.new(0.16, 0.16, 0.16),
            AnchorPoint = Vector2.new(1, 0.5),
            Position = UDim2.fromScale(0.95, 0.5),
            Ref = l__Ref__1,
            MouseDown = function() --[[ Name: MouseDown, Line 30 ]]
                -- upvalues: l__InitialValue__3 (ref), u8 (copy), l__Callback__4 (copy)
                l__InitialValue__3 = not l__InitialValue__3;
                u8.UpdValBind(l__InitialValue__3);
                l__Callback__4(l__InitialValue__3);
            end
        }, { u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }), u2.createElement("UIStroke", {
                Transparency = 0.7,
                Thickness = u8.ValBind:map(function(p9) --[[ Line: 40 ]]
                    return p9 and 2 or 0;
                end),
                Color = Color3.new(0, 1, 0)
            }) }) });
end;
return v3;