-- Services.InterfaceService.DebugMenuInterface.DebugMenuGraphComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local l__RunService__1 = game:GetService("RunService");
local v1, u2 = shared.import("require", "Roact");
local v3 = u2.Component:extend("DebugMenuGraphComponent");
local u4 = v1("DebugService");
function v3.init(u5) --[[ Line: 8 ]]
    -- upvalues: l__RunService__1 (copy), u4 (copy)
    u5.Points = table.create(101, false);
    u5.RenderIncrement = 1;
    u5.Stepped = l__RunService__1.RenderStepped:Connect(function() --[[ Line: 12 ]]
        -- upvalues: u4 (ref), u5 (copy)
        if u4:ReadValue("DebugMenuStatsPaused") then
        else
            if u5.PendingUpdate then
                u5.PendingUpdate = false;
                u5:setState({});
            end;
        end;
    end);
end;
function v3.willUnmount(p6) --[[ Line: 24 ]]
    p6.Stepped:Disconnect();
end;
local function u14(p7) --[[ Line: 28 ]]
    local v8 = (1 / 0);
    local v9 = (-1 / 0);
    local v10 = (1 / 0);
    local v11 = (-1 / 0);
    for v12 = 1, #p7 do
        local v13 = p7[v12];
        v8 = math.min(v8, v13.X);
        v9 = math.max(v9, v13.X);
        v10 = math.min(v10, v13.Y);
        v11 = math.max(v11, v13.Y);
    end;
    return v8, v9, v10, v11;
end;
local function u22(u15, p16, p17, p18, p19, p20, p21) --[[ Line: 42 ]]
    -- upvalues: u2 (copy)
    return u2.createElement("Frame", {
        BackgroundTransparency = 0.4,
        ClipsDescendants = false,
        Size = UDim2.new(1, 0, 0, 100),
        LayoutOrder = p17,
        BackgroundColor3 = Color3.new()
    }, { u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 4)
        }), u2.createElement("Frame", {
            ClipsDescendants = false,
            BackgroundTransparency = 1,
            Archivable = p18:map(function() --[[ Line: 54 ]]
                -- upvalues: u15 (copy)
                local l__NextIndex__2 = u15.props.Data.NextIndex;
                if l__NextIndex__2 ~= u15.LastIndex then
                    u15.LastIndex = l__NextIndex__2;
                    u15.PendingUpdate = true;
                end;
                return true;
            end),
            Size = UDim2.new(1, -6, 1, -6),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5)
        }, { u2.createFragment(p19), u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.new(1, 0, 0, 14),
                Position = UDim2.new(0, 0, 1, 1),
                Font = Enum.Font.Roboto,
                TextColor3 = Color3.new(1, 1, 1),
                Text = string.format("%s: (%.7f, %.7f)", p16, p20 or 0, p21 or 0)
            }, { u2.createElement("UIStroke", {
                    Thickness = 1,
                    ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                    Color = Color3.new()
                }) }) }) });
end;
local u23 = Vector2.one * 0.5;
function v3.render(p24) --[[ Line: 91 ]]
    -- upvalues: u22 (copy), u14 (copy), u23 (copy), u2 (copy)
    local l__Data__3 = p24.props.Data;
    local l__Name__4 = l__Data__3.Name;
    local l__DataBinding__5 = l__Data__3.DataBinding;
    local v25 = l__DataBinding__5:getValue();
    if #v25 == 0 then
        return u22(p24, l__Name__4, l__Data__3.Num, l__DataBinding__5, {});
    end;
    local v26, v27, v28, v29 = u14(v25);
    if v27 - v26 < 1e-9 then
        v27 = v27 + 0.1;
        v26 = v26 - 0.1;
    end;
    if v29 - v28 < 1e-9 then
        v29 = v29 + 0.1;
        v28 = v28 - 0.1;
    end;
    local v30 = v27 - v26;
    local v31 = v29 - v28;
    p24.RenderIncrement = p24.RenderIncrement + 1;
    local v32 = p24.RenderIncrement % 2;
    local l__Points__6 = p24.Points;
    for v33 = 1, #v25 do
        local v34 = v25[v33];
        v34.Props = v34.Props or {
            BorderSizePixel = 0,
            Size = v34.Scale,
            BackgroundColor3 = v34.Color,
            AnchorPoint = u23
        };
        v34.Props.Position = UDim2.fromScale((v34.X - v26) / v30, 1 - (v34.Y - v28) / v31);
        l__Points__6[v33 + v32] = u2.createElement("Frame", v34.Props);
    end;
    if v32 == 0 then
        l__Points__6[#v25 + 1] = nil;
    else
        l__Points__6[1] = nil;
    end;
    return u22(p24, l__Name__4, l__Data__3.Num, l__DataBinding__5, p24.Points, v25[#v25].X, v25[#v25].Y);
end;
return v3;