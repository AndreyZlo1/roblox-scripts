-- Services.InterfaceService.ActionInterface.ActionComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local u3 = v1("GameShellProxyService");
local u4 = v1("GameShellProxyButton");
local u5 = v1("TouchButtonComponent");
local v6 = u2.Component:extend("Radial");
local u7 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u8 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
function v6.init(p9, p10) --[[ Line: 14 ]]
    p9._enabledTween = p10.EnabledTween;
    p9._hoverName = p10.HoverName;
    p9._hoverHealth = p10.HoverHealth;
    p9._health = p10.Health;
    p9._spinner = p10.Spinner;
end;
function v6.render(p11) --[[ Line: 22 ]]
    -- upvalues: u2 (copy), u4 (copy), u7 (copy), u8 (copy), u3 (copy), u5 (copy)
    local l__props__1 = p11.props;
    local l__Options__2 = l__props__1.Options;
    local l__Touch__3 = l__props__1.Touch;
    local l__Selected__4 = l__props__1.Selected;
    local v12 = 360 / #l__Options__2;
    local v13 = v12 * (l__Selected__4 - 1) + 0;
    local v14 = {};
    for v15 = v13 / 2, (v13 + v12) / 2 do
        local v16 = v15 * 2;
        local l__createElement__5 = u2.createElement;
        local v17 = {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Rotation = v16
        };
        local l__fromScale__6 = UDim2.fromScale;
        local v18 = math.rad(v16);
        local v19 = math.sin(v18) / 2 + 0.5;
        local v20 = math.rad(v16);
        v17.Position = l__fromScale__6(v19, 0.5 - math.cos(v20) / 2);
        v17.Size = UDim2.fromScale(0.01, 0.01);
        v14[v16] = l__createElement__5("Frame", v17, { u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = l__Options__2[l__Selected__4][4],
                Position = UDim2.fromScale(0, 0),
                Size = UDim2.fromScale(2, 25)
            }) });
    end;
    for u21, u22 in l__Options__2 do
        local v23 = u21 * v12 - v12 / 2;
        local v24 = u21 == l__Selected__4;
        local l__fromScale__7 = UDim2.fromScale;
        local v25 = math.rad(v23);
        local v26 = math.sin(v25) / 2.7 + 0.5;
        local v27 = math.rad(v23);
        local v28 = l__fromScale__7(v26, 0.5 - math.cos(v27) / 2.7);
        if typeof(u22[3]) == "Color3" then
            local v29 = u22[1];
            local l__createElement__8 = u2.createElement;
            local v30 = "Frame";
            local v31 = {
                BorderSizePixel = 0,
                ZIndex = 2,
                BackgroundColor3 = u22[3],
                AnchorPoint = Vector2.new(0.5, 0.5),
                Size = UDim2.fromScale(0.05, 0.05),
                Position = v28
            };
            local v32 = {};
            local v33 = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0.5, 0)
            });
            local v34 = u22[6];
            if v34 then
                v34 = u2.createElement("UIStroke", {
                    Thickness = 4,
                    Color = Color3.new(0, 0, 0),
                    LineJoinMode = Enum.LineJoinMode.Round
                });
            end;
            v32[1], v32[2] = v33, v34;
            v14[v29] = l__createElement__8(v30, v31, v32);
        else
            v14[u22[1]] = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                ZIndex = 2,
                Image = u22[3],
                ImageColor3 = Color3.new(0, 0, 0),
                AnchorPoint = Vector2.new(0.5, 0.5),
                Size = UDim2.fromScale(0.1, 0.1),
                Position = v28
            }, { u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Image = u22[3],
                    ImageColor3 = v24 and Color3.new(0, 0, 0) or Color3.new(1, 1, 1),
                    Size = UDim2.fromScale(1, 1),
                    Position = UDim2.fromOffset(0, -1)
                }) });
        end;
        if l__Touch__3 then
            v14[u22[1] .. "Touch"] = u2.createElement(u4, {
                BackgroundTransparency = 1,
                Position = v28,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Size = UDim2.fromScale(0.2, 0.2),
                MouseUp = function() --[[ Name: MouseUp, Line 99 ]]
                    -- upvalues: l__props__1 (copy), u22 (copy)
                    l__props__1.GoNext(u22[5]);
                end,
                MouseDown = function() --[[ Name: MouseDown, Line 102 ]]
                    -- upvalues: l__props__1 (copy), u21 (copy)
                    l__props__1.SetSelected(u21);
                end
            });
        end;
    end;
    local l__createFragment__9 = u2.createFragment;
    local v35 = {};
    local v36 = u2.createElement("ImageLabel", {
        BackgroundTransparency = 1,
        Image = "rbxasset://textures/ui/TopBar/WhiteOverlayAsset.png",
        Size = UDim2.new(1, 0, 1, 0),
        ImageColor3 = Color3.fromRGB(89, 0, 0),
        ImageTransparency = p11._health
    }, l__props__1.BloodSplatters);
    local v40 = u2.createElement("Frame", {
        BorderSizePixel = 0,
        BackgroundTransparency = 0.6,
        Size = UDim2.fromScale(1, 1),
        Position = UDim2.fromScale(0, 0),
        BackgroundColor3 = p11._hoverHealth,
        Visible = p11._hoverName:map(function(p37) --[[ Line: 123 ]]
            return p37 and true or false;
        end)
    }, { u2.createElement("UIGradient", {
            Rotation = 90,
            Color = ColorSequence.new(Color3.new(1, 1, 1)),
            Offset = Vector2.new(0, 0),
            Transparency = NumberSequence.new({
                NumberSequenceKeypoint.new(0, 0),
                NumberSequenceKeypoint.new(0.3, 1),
                NumberSequenceKeypoint.new(0.7, 1),
                NumberSequenceKeypoint.new(1, 0)
            })
        }), u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextTransparency = 0.2,
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.new(0, 0, 0.22, 0),
            Size = UDim2.new(1, 0, 0.03, 0),
            FontFace = u7,
            Visible = l__props__1.Objective,
            Text = p11._hoverName:map(function(p38) --[[ Line: 148 ]]
                return p38 or "";
            end),
            TextColor3 = Color3.new(0, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Center
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextTransparency = 0.1,
                TextScaled = true,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0),
                FontFace = u7,
                Text = p11._hoverName:map(function(p39) --[[ Line: 166 ]]
                    return p39 or "";
                end),
                TextColor3 = p11._hoverHealth,
                TextXAlignment = Enum.TextXAlignment.Center
            }) }), u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "USING MEDICAL ON",
            TextTransparency = 0.2,
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.new(0, 0, 0.2, 0),
            Size = UDim2.new(1, 0, 0.02, 0),
            FontFace = u7,
            Visible = l__props__1.Objective,
            TextColor3 = Color3.new(0, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Center
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "USING MEDICAL ON",
                TextTransparency = 0.1,
                TextScaled = true,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0),
                FontFace = u7,
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = Enum.TextXAlignment.Center
            }) }) });
    local v49 = u2.createElement("ImageLabel", {
        BackgroundTransparency = 1,
        Image = "rbxassetid://13786644388",
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.fromScale(0.5, 0.5),
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        ImageColor3 = Color3.new(0.2, 0.2, 0.2),
        ImageTransparency = p11._enabledTween:Map(function(p41) --[[ Line: 215 ]]
            return 1 - p41 * 0.5;
        end),
        Size = p11._enabledTween:Map(function(p42) --[[ Line: 218 ]]
            local v43 = p42 * 0.4;
            return UDim2.fromScale(v43, v43);
        end),
        Visible = p11._enabledTween:Map(function(p44) --[[ Line: 222 ]]
            return p44 > 0.05;
        end)
    }, {
        u2.createFragment(v14),
        Spinner = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://18527799185",
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = UDim2.fromScale(1.05, 1.05),
            Visible = p11._spinner:map(function(p45) --[[ Line: 233 ]]
                return p45 >= 0.05;
            end)
        }, {
            u2.createElement("UIGradient", {
                Color = ColorSequence.new(Color3.new(1, 1, 1)),
                Offset = Vector2.new(0, 0),
                Rotation = p11._spinner:map(function(p46) --[[ Line: 240 ]]
                    return math.clamp(p46 * 2, 0, 1) * -180;
                end),
                Transparency = NumberSequence.new({
                    NumberSequenceKeypoint.new(0, 1),
                    NumberSequenceKeypoint.new(0.495, 1),
                    NumberSequenceKeypoint.new(0.505, 0),
                    NumberSequenceKeypoint.new(1, 0)
                })
            }),
            Inside = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://18527799185",
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.fromScale(0, 0),
                Size = UDim2.fromScale(1, 1),
                Visible = p11._spinner:map(function(p47) --[[ Line: 255 ]]
                    return p47 >= 0.5;
                end),
                Rotation = p11._spinner:map(function(p48) --[[ Line: 258 ]]
                    return math.clamp(p48 - 0.5, 0, 1) * 2 * -180;
                end)
            })
        }),
        Name = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            Size = UDim2.fromScale(0.4, 0.05),
            Position = UDim2.fromScale(0.5, 0.45),
            AnchorPoint = Vector2.new(0.5, 1),
            Text = l__Options__2[l__Selected__4] and (l__Options__2[l__Selected__4][1]:upper() or "") or "",
            TextColor3 = Color3.new(0, 0, 0),
            FontFace = u7
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 1),
                Position = UDim2.fromOffset(0, -1),
                Text = l__Options__2[l__Selected__4] and (l__Options__2[l__Selected__4][1]:upper() or "") or "",
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u7
            }) }),
        Description = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            Size = UDim2.fromScale(0.3, 0.25),
            TextYAlignment = Enum.TextYAlignment.Top,
            Position = UDim2.fromScale(0.5, 0.45),
            AnchorPoint = Vector2.new(0.5, 0),
            Text = l__Options__2[l__Selected__4] and (l__Options__2[l__Selected__4][2] or "") or "",
            TextColor3 = Color3.new(0, 0, 0),
            FontFace = u8
        }, { u2.createElement("UITextSizeConstraint", {
                MaxTextSize = u3.ViewportSize.Y * 0.4 * 0.05
            }), u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 1),
                TextYAlignment = Enum.TextYAlignment.Top,
                Position = UDim2.fromOffset(0, -1),
                Text = l__Options__2[l__Selected__4] and l__Options__2[l__Selected__4][2] or "",
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u8
            }, { u2.createElement("UITextSizeConstraint", {
                    MaxTextSize = u3.ViewportSize.Y * 0.4 * 0.05
                }) }) })
    });
    local v50 = l__Touch__3 and l__props__1.Open;
    if v50 then
        v50 = u2.createElement(u5, {
            Image = "rbxassetid://15222586129",
            Size = UDim2.fromScale(0.1, 0.1),
            Position = UDim2.fromScale(0.5, 0.2),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Up = function() --[[ Name: Up, Line 319 ]]
                -- upvalues: l__props__1 (copy)
                l__props__1.GoPrev();
            end
        });
    end;
    v35[1], v35[2], v35[3], v35[4] = v36, v40, v49, v50;
    return l__createFragment__9(v35);
end;
return v6;