-- Services.InterfaceService.LockPickComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local u3 = v1("PostProcessingService");
local u4 = v1("RoactTween");
game:GetService("Lighting");
local v5 = u2.Component:extend("TouchButton");
local u6 = {
    0.65,
    0.53,
    0.46,
    0.39,
    0.32,
    0.25,
    0.18
};
function v5.init(p7, p8) --[[ Line: 21 ]]
    -- upvalues: u4 (copy), u3 (copy)
    p7.Blur = u4.new(0);
    p7.Timer = p8.Timer;
    p7.Cursor = p8.Cursor;
    p7.Color = p8.Color;
    p7.Scale = p8.Scale;
    p7.Pick = p8.Pick;
    p7.Pins = p8.Pins;
    p7.Blur:SetGoal(1);
    p7.BlurEffect = u3:AddBlur({
        Size = p7.Blur:Map(function(p9) --[[ Line: 32 ]]
            return p9 * 15;
        end)
    }, nil, true);
end;
function v5.willUnmount(p10) --[[ Line: 38 ]]
    p10.BlurEffect.Destroy();
end;
function v5.render(p11) --[[ Line: 42 ]]
    -- upvalues: u2 (copy), u6 (copy)
    local v12 = {};
    for v13, v14 in p11.Pins do
        v12[v13] = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            LayoutOrder = 6 - v13
        }, { u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://15841474753",
                Size = v14:Map(function(p15) --[[ Line: 52 ]]
                    return UDim2.fromScale(1, 1 - p15 / 2);
                end)
            }, { u2.createElement("Frame", {
                    BackgroundTransparency = 0,
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.new(1, 1, 1),
                    Size = UDim2.fromScale(1, 1),
                    AnchorPoint = Vector2.new(0, 1),
                    Position = UDim2.fromScale(0, 1),
                    SizeConstraint = Enum.SizeConstraint.RelativeXX
                }, { u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0.2, 0)
                    }) }) }) });
    end;
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Position = UDim2.fromScale(0.5, 0.5),
        AnchorPoint = Vector2.new(0.5, 0.5),
        Size = UDim2.fromScale(0.5, 0.25),
        SizeConstraint = Enum.SizeConstraint.RelativeYY
    }, {
        u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(0.4, 0.6),
            Position = UDim2.fromScale(0.2, 0.1)
        }, { u2.createElement("UIGridLayout", {
                CellPadding = UDim2.fromScale(0.05, 0),
                CellSize = UDim2.fromScale(0.12, 1),
                FillDirection = Enum.FillDirection.Horizontal,
                SortOrder = Enum.SortOrder.LayoutOrder,
                HorizontalAlignment = Enum.HorizontalAlignment.Left
            }), u2.createFragment(v12) }),
        u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://15842555763",
            AnchorPoint = Vector2.new(0, 0.5),
            Position = p11.Pick:map(function(p16) --[[ Line: 98 ]]
                -- upvalues: u6 (ref)
                return UDim2.fromScale(u6[p16 + 1], 0.5);
            end),
            Size = UDim2.fromScale(1, 0.25)
        }),
        u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(0.6, 0.1),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.85)
        }, { u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(141, 141, 141),
                Size = UDim2.fromScale(1, 0.15),
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.5)
            }), u2.createElement("Frame", {
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                ZIndex = 2,
                BackgroundColor3 = p11.Color,
                Size = UDim2.fromScale(p11.Scale, 0.6),
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.5)
            }), u2.createElement("Frame", {
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                ZIndex = 3,
                BackgroundColor3 = Color3.fromRGB(255, 255, 255),
                Size = UDim2.new(0, 2, 1, 0),
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = p11.Cursor:map(function(p17) --[[ Line: 132 ]]
                    return UDim2.fromScale(p17, 0.5);
                end)
            }) }),
        u2.createElement("UIStroke", {
            Thickness = 1,
            LineJoinMode = Enum.LineJoinMode.Round,
            Color = Color3.new(1, 1, 1)
        }, { u2.createElement("UIGradient", {
                Color = p11.Timer:map(function(p18) --[[ Line: 144 ]]
                    local v19 = 1 - p18;
                    return ColorSequence.new({
                        ColorSequenceKeypoint.new(0, Color3.fromRGB(125, 125, 125)),
                        ColorSequenceKeypoint.new(math.clamp(v19 - 0.01, 0.005, 0.99), Color3.fromRGB(125, 125, 125)),
                        ColorSequenceKeypoint.new(math.clamp(v19 - 0.005, 0.01, 0.995), Color3.new(0, 1, 0)),
                        ColorSequenceKeypoint.new(1, Color3.new(0, 1, 0))
                    });
                end)
            }) }),
        u2.createElement("UICorner", {
            CornerRadius = UDim.new(0.3, 0)
        })
    });
end;
return v5;