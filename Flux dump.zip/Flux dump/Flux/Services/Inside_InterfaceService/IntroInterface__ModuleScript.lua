-- Services.InterfaceService.IntroInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "network", "Roact", "Enum");
local u5 = v1("GameShellProxyService");
local u6 = v1("EnvironmentService");
local u7 = v1("SoundService");
local u8 = v1("RealmInterface");
local u9 = v1("LandingInterface");
local u10 = v1("IntroComponent");
local u11 = v1("InputService");
local u12 = v1("PostProcessingService");
local l__Lighting__1 = game:GetService("Lighting");
local l__RunService__2 = game:GetService("RunService");
local l__UserInputService__3 = game:GetService("UserInputService");
local l__TweenService__4 = game:GetService("TweenService");
local l__ContentProvider__5 = game:GetService("ContentProvider");
local l__CurrentCamera__6 = workspace.CurrentCamera;
local u13 = {
    { CFrame.new(457.319824, -22.5179253, -62.9144936, -0.701958537, -0.194152072, -0.685227394, 2.67813448e-7, 0.962115288, -0.272605747, 0.712207079, -0.19136332, -0.675367355), CFrame.new(466.055695, -19.0424595, -54.3042107, -0.701958537, -0.194152072, -0.685227394, 2.67813448e-7, 0.962115288, -0.272605747, 0.712207079, -0.19136332, -0.675367355) },
    { CFrame.new(512.192993, 11.0315113, -29.0526047, -0.793263495, -0.464154154, 0.394056767, 2.83238478e-7, 0.647192895, 0.762316823, -0.608870268, 0.60472405, -0.513395011), CFrame.new(511.261719, 9.36090565, -18.2204437, -0.74999243, -0.523419917, 0.404386878, 2.83238478e-7, 0.611375034, 0.791331708, -0.661438465, 0.593499541, -0.458526969) },
    { CFrame.new(489.489014, -4.9941721, -27.0994129, -0.819666088, -0.0811827555, -0.567047656, 2.80851964e-7, 0.989899874, -0.141723856, 0.572830856, -0.116169706, -0.811388731), CFrame.new(484.552246, -6.16481352, -15.8321352, -0.572730482, -0.145307332, -0.806751966, 2.81143002e-7, 0.984156549, -0.177260548, 0.819736481, -0.101526253, -0.563656926) }
};
local u14 = {};
u14.__index = u14;
function u14.new() --[[ Line: 48 ]]
    -- upvalues: u5 (copy), u4 (copy), u14 (copy)
    local v15, v16 = u5:CreateProxy(9, u4.ShellPriority.AlwaysVisible, "IntroInterface");
    local v17 = setmetatable({
        _ui = v15
    }, u14);
    v16.ClipToDeviceSafeArea = false;
    v16.SafeAreaCompatibility = u4.SafeAreaCompatibility.None;
    v16.ScreenInsets = u4.ScreenInsets.None;
    return v17;
end;
function u14.Play(u18) --[[ Line: 61 ]]
    -- upvalues: u9 (copy), u2 (copy), u8 (copy), u7 (copy), u12 (copy), l__Lighting__1 (copy), u3 (copy), u6 (copy), l__ContentProvider__5 (copy), u11 (copy), l__UserInputService__3 (copy), u4 (copy), u10 (copy), l__RunService__2 (copy), u13 (copy), l__TweenService__4 (copy), l__CurrentCamera__6 (copy)
    if u9.SkipIntro then
        u2:FireServer("IntroPreloaded");
        local l__teleportData__7 = shared.teleportData;
        local v19 = l__teleportData__7 and l__teleportData__7.EloChange;
        if v19 then
            u8:Display("MatchFinish", v19.Won, v19.Start, v19.End);
            task.wait(10);
        end;
        u9:Message("PREPARING MAIN MENU");
        task.delay(0.5, function() --[[ Line: 75 ]]
            -- upvalues: u8 (ref), u2 (ref)
            u8:Display();
            u2:FireServer("InitLobby");
        end);
    else
        local u20 = u7:CreateSound("Non_diegetic", nil, false, "Music", "TitleScreen");
        u12.Ambient = Color3.fromRGB(158, 197, 255);
        l__Lighting__1.ColorShift_Top = Color3.fromRGB(255, 120, 23);
        l__Lighting__1.OutdoorAmbient = Color3.fromRGB(58, 0, 249);
        local v21, u22 = u3.createBinding(1);
        local v23, u24 = u3.createBinding(false);
        local u25 = u12:AddBrightness({
            Size = 4.62
        });
        local u26 = u12:AddColorCorrection({
            Brightness = -0.1,
            Contrast = 1,
            Saturation = -0.05
        }, 3);
        local u27 = u12:AddBloom({
            Intensity = 0.75,
            Size = 13,
            Threshold = 0.01
        }, -1);
        local u28 = u12:AddDepthOfField({
            FarIntensity = 0,
            FocusDistance = 15,
            InFocusRadius = 0,
            NearIntensity = 1,
            AutoFocus = false
        }, 3);
        local u29 = Instance.new("SunRaysEffect");
        u29.Intensity = 0.091;
        u29.Spread = 1;
        u29.Parent = l__Lighting__1;
        local u30 = {
            Skybox = "Intro",
            ClockTime = 0,
            LunarPhase = 1,
            CloudDensity = 0,
            CloudCover = 0,
            FogDensity = 0,
            ShowUnderWater = false,
            NoColors = true
        };
        u6:SetOverride(u30);
        l__Lighting__1.GeographicLatitude = 0;
        u7.DiegeticMix.Intro = 0;
        l__Lighting__1.FogColor = Color3.fromRGB(40, 47, 56);
        l__Lighting__1.FogStart = 25;
        l__Lighting__1.FogEnd = 100;
        local l__UH60__8 = workspace:WaitForChild("UH60");
        local l__Primary__9 = l__UH60__8:WaitForChild("Primary");
        local l__Secondary__10 = l__UH60__8:WaitForChild("Secondary");
        local v31 = { u20.Sound };
        for _, v32 in l__UH60__8:GetDescendants() do
            if v32:IsA("MeshPart") then
                v31[#v31 + 1] = v32;
            end;
        end;
        l__ContentProvider__5:PreloadAsync(v31);
        u9:Message();
        local v33 = "PRESS [SPACE] TO START";
        if u11.Touch then
            v33 = "TAP ANYWHERE TO START";
        elseif u11.Gamepad then
            v33 = "PRESS [" .. l__UserInputService__3:GetStringForKeyCode(u4.KeyCode.ButtonA) .. "] TO START";
        end;
        u18._handle = u3.mount(u3.createElement(u10, {
            Transparency = v21,
            StartFlash = v23,
            Button = v33
        }), u18._ui);
        local u34 = tick();
        local u35 = nil;
        local u36 = nil;
        local function u37() --[[ Line: 162 ]]
            -- upvalues: u9 (ref), u20 (copy), u36 (ref), u3 (ref), u18 (copy), u35 (ref), u7 (ref), u6 (ref), u28 (copy), u29 (copy), u27 (copy), u25 (copy), u26 (copy), l__Lighting__1 (ref), u12 (ref), u2 (ref)
            u9:Message("CREATING LOBBY");
            u20.FadeOut(3);
            u36:Disconnect();
            task.delay(0.5, function() --[[ Line: 166 ]]
                -- upvalues: u3 (ref), u18 (ref), u35 (ref), u7 (ref), u6 (ref), u28 (ref), u29 (ref), u27 (ref), u25 (ref), u26 (ref), l__Lighting__1 (ref), u12 (ref), u2 (ref)
                u3.unmount(u18._handle);
                u35:Disconnect();
                u7.DiegeticMix.Intro = nil;
                u6:SetOverride();
                u28.Destroy();
                u29:Destroy();
                u27.Destroy();
                u25.Destroy();
                u26.Destroy();
                l__Lighting__1.GeographicLatitude = 76;
                u12.Ambient = Color3.new();
                u2:FireServer("InitLobby");
            end);
        end;
        local u38 = nil;
        u20.Play(0);
        u35 = l__RunService__2.RenderStepped:Connect(function(p39) --[[ Line: 189 ]]
            -- upvalues: u38 (ref), u20 (copy), u13 (ref), u30 (copy), l__TweenService__4 (ref), u4 (ref), l__Lighting__1 (ref), u26 (copy), u22 (copy), l__Primary__9 (copy), l__Secondary__10 (copy), u34 (copy), u24 (copy), l__CurrentCamera__6 (ref)
            if u38 then
                u38 = u38 + p39;
            else
                u38 = u20.Sound.TimePosition;
            end;
            local v40 = math.floor(u38 / 10) % #u13 + 1;
            local v41 = u38 % 10 / 10;
            u30.ClockTime = math.lerp(6, 18, l__TweenService__4:GetValue(v41, u4.EasingStyle.Sine, u4.EasingDirection.InOut));
            l__Lighting__1.GeographicLatitude = v41 * 170 + 20;
            local v42 = math.sin(v41 * 3.141592653589793);
            u26.TintColor = Color3.new():Lerp(Color3.new(1, 1, 1), v42);
            u22(1 - v42);
            l__Primary__9:PivotTo(CFrame.new(500, 2.633, -7.756) * CFrame.Angles(0, u38, 0));
            l__Secondary__10:PivotTo(CFrame.new(501.702, 3.952, 31.813) * CFrame.Angles(u38, 0, 0));
            if tick() - u34 > 3 then
                u24(u38 % 3 < 1.5);
            end;
            local v43 = u13[v40];
            l__CurrentCamera__6.CFrame = v43[1]:Lerp(v43[2], v41);
            l__CurrentCamera__6.FieldOfView = 40;
        end);
        u36 = l__UserInputService__3.InputBegan:Connect(function(p44) --[[ Line: 217 ]]
            -- upvalues: u4 (ref), u34 (copy), u37 (copy)
            if (p44.KeyCode == u4.KeyCode.Space or (p44.KeyCode == u4.KeyCode.ButtonA or p44.UserInputType == u4.UserInputType.Touch)) and tick() - u34 > 3 then
                u37();
            end;
        end);
    end;
end;
return u14.new();