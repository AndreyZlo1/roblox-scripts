-- Services.InterfaceService.ActionInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4, u5 = shared.import("require", "Enum", "Roact", "network", "server");
local l__Players__1 = game:GetService("Players");
local u6 = v1("GameShellProxyService");
local u7 = v1("InputService");
local u8 = v1("ReplicatorService");
local u9 = v1("DebugService");
local u10 = v1("ClientService");
local u11 = v1("InventoryService");
local u12 = v1("PopupInterface");
local u13 = v1("PostProcessingService");
local u14 = v1("sanitizeDisplayName");
local u15 = v1("TagInterface");
local u16 = v1("NotifyInterface");
local u17 = v1("SoundService");
local u18 = v1("Animations");
local u19 = v1("RoactTween");
local u20 = v1("ActionComponent");
local l__LocalPlayer__2 = l__Players__1.LocalPlayer;
local u21 = {
    {
        "84646942694908",
        { 1.5, 1.5 }
    }
};
local u22 = {};
u22.__index = u22;
function u22._getMedical(_) --[[ Line: 50 ]]
    -- upvalues: u11 (copy)
    local v23 = 0;
    local v24 = 0;
    local v25 = 0;
    for _, v26 in u11.Inventories[u11.Primary].Storages do
        for _, v27 in v26.Sections do
            for _, v28 in v27 do
                if v28.Name == "Bandage" then
                    v25 = v25 + 1;
                elseif v28.Name == "Dressing" then
                    v24 = v24 + 1;
                elseif v28.Name == "Vitamins" then
                    v23 = v23 + 1;
                end;
            end;
        end;
    end;
    return v25, v24, v23;
end;
function u22._update(p29) --[[ Line: 72 ]]
    -- upvalues: u3 (copy), u20 (copy)
    p29._handle = u3.update(p29._handle, u3.createElement(u20, {
        Touch = p29._touch,
        Open = p29._open,
        Options = p29._options,
        Selected = p29._selected,
        SetSelected = p29._setSelected,
        Health = p29._health,
        GoNext = p29._goNext,
        GoPrev = p29._goPrev,
        BloodSplatters = p29._bloodSplatters
    }));
end;
function u22.DoEmote(_, p30) --[[ Line: 86 ]]
    -- upvalues: u8 (copy), u2 (copy), u18 (copy), u16 (copy), u4 (copy)
    local l__LocalActor__3 = u8.LocalActor;
    local l__HeightState__4 = l__LocalActor__3.HeightState;
    if l__HeightState__4 == u2.CharacterHeightState.Climbing or (l__HeightState__4 == u2.CharacterHeightState.Vaulting or (l__HeightState__4 == u2.CharacterHeightState.Swimming or (l__HeightState__4 == u2.CharacterHeightState.Skydiving or l__HeightState__4 == u2.CharacterHeightState.Parachuting))) then
        return false;
    elseif l__HeightState__4 == u2.CharacterHeightState.Sitting and not l__LocalActor__3.SeatCanEquip then
        return false;
    elseif u18.Emotes[p30].Idle and l__LocalActor__3.HeightState ~= u2.CharacterHeightState.Standing then
        u16:Notify({
            { "Alert", "You must be standing to perform this action", Color3.new(1, 0.866666, 0.505882) }
        });
    else
        u4:FireServer("SetEmote", p30);
    end;
end;
function u22._setOptions(p31, p32) --[[ Line: 110 ]]
    local v33 = math.ceil(p31._degrees / (360 / #p32));
    local v34 = math.clamp(v33, 1, #p32);
    p31._options = p32;
    p31._selected = v34;
    p31:_update();
end;
function u22._publicSquads(p35) --[[ Line: 117 ]]
    -- upvalues: u4 (copy)
    p35._page = "publicSquads";
    p35._prev = p35._squad;
    p35:_setOptions({
        {
            "Neutral",
            "",
            Color3.fromRGB(255, 255, 255),
            Color3.fromRGB(255, 255, 255),
            function() --[[ Line: 126 ]]
                -- upvalues: u4 (ref)
                u4:FireServer("JoinSquad", 0);
            end,
            p35._currentSquad == nil
        },
        {
            "Red",
            "",
            Color3.fromRGB(255, 10, 14),
            Color3.fromRGB(255, 10, 14),
            function() --[[ Line: 136 ]]
                -- upvalues: u4 (ref)
                u4:FireServer("JoinSquad", 1);
            end,
            p35._currentSquad == "Red"
        },
        {
            "Orange",
            "",
            Color3.fromRGB(255, 150, 29),
            Color3.fromRGB(255, 150, 29),
            function() --[[ Line: 146 ]]
                -- upvalues: u4 (ref)
                u4:FireServer("JoinSquad", 2);
            end,
            p35._currentSquad == "Orange"
        },
        {
            "Blue",
            "",
            Color3.fromRGB(52, 133, 255),
            Color3.fromRGB(52, 133, 255),
            function() --[[ Line: 156 ]]
                -- upvalues: u4 (ref)
                u4:FireServer("JoinSquad", 3);
            end,
            p35._currentSquad == "Blue"
        },
        {
            "Green",
            "",
            Color3.fromRGB(134, 255, 58),
            Color3.fromRGB(134, 255, 58),
            function() --[[ Line: 166 ]]
                -- upvalues: u4 (ref)
                u4:FireServer("JoinSquad", 4);
            end,
            p35._currentSquad == "Green"
        },
        {
            "Yellow",
            "",
            Color3.fromRGB(255, 216, 57),
            Color3.fromRGB(255, 216, 57),
            function() --[[ Line: 176 ]]
                -- upvalues: u4 (ref)
                u4:FireServer("JoinSquad", 5);
            end,
            p35._currentSquad == "Yellow"
        }
    });
end;
function u22._viewInvites(u36) --[[ Line: 184 ]]
    -- upvalues: u14 (copy), u4 (copy)
    u36._page = "viewInvites";
    u36._prev = u36._squad;
    local l___invites__5 = u36._invites;
    if #l___invites__5 > 0 then
        local v37 = {};
        for v38, u39 in l___invites__5 do
            local v40 = u36._currentSquad == tostring(u39.UserId);
            v37[v38] = {
                u14(u39.DisplayName, u39.Name),
                v40 and "You are in this player\'s squad" or "Join this player\'s squad",
                "rbxthumb://type=AvatarHeadShot&id=" .. u39.UserId .. "&w=60&h=60",
                v40 and Color3.new(0.670588, 1, 0.741176) or Color3.new(1, 1, 1),
                function() --[[ Line: 198 ]]
                    -- upvalues: u4 (ref), u39 (copy)
                    u4:FireServer("JoinSquad", u39.Name);
                end
            };
        end;
        u36:_setOptions(v37);
    else
        u36:_setOptions({
            {
                "No Invites",
                "You have not been invited to any squads",
                "",
                Color3.new(1, 1, 1),
                function() --[[ Line: 212 ]]
                    -- upvalues: u36 (copy)
                    u36:_squad();
                end
            }
        });
    end;
end;
function u22._sendInvites(u41) --[[ Line: 220 ]]
    -- upvalues: u10 (copy), l__LocalPlayer__2 (copy), u14 (copy), u4 (copy)
    u41._page = "sendInvites";
    u41._prev = u41._squad;
    local v42 = {};
    for _, v43 in u10:GetClients() do
        if v43.Owner ~= l__LocalPlayer__2 then
            v42[#v42 + 1] = v43;
        end;
    end;
    if #v42 > 0 then
        local v44 = {};
        for _, u45 in v42 do
            local l__Owner__6 = u45.Owner;
            local l__InvitedToSquad__7 = u45.InvitedToSquad;
            v44[#v44 + 1] = {
                u14(l__Owner__6.DisplayName, l__Owner__6.Name),
                l__InvitedToSquad__7 and "Uninvite this user from your squad" or "Invite this user to your squad",
                "rbxthumb://type=AvatarHeadShot&id=" .. u45.Owner.UserId .. "&w=60&h=60",
                l__InvitedToSquad__7 and Color3.new(1, 0.670588, 0.670588) or Color3.new(0.670588, 1, 0.741176),
                function() --[[ Line: 243 ]]
                    -- upvalues: l__InvitedToSquad__7 (copy), u4 (ref), l__Owner__6 (copy), u45 (copy), u41 (copy)
                    if l__InvitedToSquad__7 then
                        u4:FireServer("InviteSquad", l__Owner__6.Name, false);
                        u45.InvitedToSquad = false;
                    else
                        u4:FireServer("InviteSquad", l__Owner__6.Name, true);
                        u45.InvitedToSquad = true;
                    end;
                    u41:_sendInvites();
                end
            };
        end;
        u41:_setOptions(v44);
    else
        u41:_setOptions({
            {
                "No Players",
                "There is no one you can invite",
                "",
                Color3.new(1, 1, 1),
                function() --[[ Line: 264 ]]
                    -- upvalues: u41 (copy)
                    u41:_squad();
                end
            }
        });
    end;
end;
function u22._squad(u46) --[[ Line: 272 ]]
    -- upvalues: u4 (copy), l__LocalPlayer__2 (copy), u5 (copy)
    u46._page = "squad";
    u46._prev = u46._home;
    local v47 = {
        "Create Squad",
        "Create a private squad and invite friends",
        "rbxassetid://13795517338",
        Color3.new(1, 1, 1),
        function() --[[ Line: 281 ]]
            -- upvalues: u4 (ref), l__LocalPlayer__2 (ref)
            u4:FireServer("JoinSquad", l__LocalPlayer__2.Name);
        end
    };
    local v48 = {
        u46._currentSquad == tostring(l__LocalPlayer__2.UserId) and {
            "Manage Squad",
            "Add and remove friends from your private squad",
            "rbxassetid://13797591969",
            Color3.new(1, 1, 1),
            function() --[[ Line: 292 ]]
                -- upvalues: u46 (copy)
                u46:_sendInvites();
            end
        } or v47,
        {
            "Squad Invites",
            "View active squad invites from friends",
            "rbxassetid://13795517206",
            Color3.new(1, 1, 1),
            function() --[[ Line: 305 ]]
                -- upvalues: u46 (copy)
                u46:_viewInvites();
            end
        }
    };
    if not u5.PRIVATE_SQUADS_ONLY then
        v48[#v48 + 1] = {
            "Public Squads",
            "Join a public squad open to everyone",
            "rbxassetid://13795517050",
            Color3.new(1, 1, 1),
            function() --[[ Line: 317 ]]
                -- upvalues: u46 (copy)
                u46:_publicSquads();
            end
        };
    end;
    u46:_setOptions(v48);
end;
function u22._emote(u49) --[[ Line: 326 ]]
    u49._page = "emote";
    u49._prev = u49._character;
    u49:_setOptions({
        {
            "Arms Crossed",
            "",
            "rbxassetid://5124908450",
            Color3.new(1, 1, 1),
            function() --[[ Line: 335 ]]
                -- upvalues: u49 (copy)
                u49:DoEmote("Crossed");
            end
        },
        {
            "At Ease",
            "",
            "rbxassetid://5124908257",
            Color3.new(1, 1, 1),
            function() --[[ Line: 344 ]]
                -- upvalues: u49 (copy)
                u49:DoEmote("AtEase");
            end
        },
        {
            "Salute",
            "",
            "rbxassetid://5124908700",
            Color3.new(1, 1, 1),
            function() --[[ Line: 353 ]]
                -- upvalues: u49 (copy)
                u49:DoEmote("Salute");
            end
        },
        {
            "Halt",
            "",
            "rbxassetid://5124908587",
            Color3.new(1, 1, 1),
            function() --[[ Line: 362 ]]
                -- upvalues: u49 (copy)
                u49:DoEmote("Halt");
            end
        },
        {
            "Forward",
            "",
            "rbxassetid://5124908529",
            Color3.new(1, 1, 1),
            function() --[[ Line: 371 ]]
                -- upvalues: u49 (copy)
                u49:DoEmote("Forward");
            end
        },
        {
            "Regroup",
            "",
            "rbxassetid://5124908641",
            Color3.new(1, 1, 1),
            function() --[[ Line: 380 ]]
                -- upvalues: u49 (copy)
                u49:DoEmote("Regroup");
            end
        },
        {
            "Sleep",
            "",
            "rbxassetid://5124908803",
            Color3.new(1, 1, 1),
            function() --[[ Line: 389 ]]
                -- upvalues: u49 (copy)
                u49:DoEmote("Sleep");
            end
        },
        {
            "Sit",
            "",
            "rbxassetid://5124908755",
            Color3.new(1, 1, 1),
            function() --[[ Line: 398 ]]
                -- upvalues: u49 (copy)
                u49:DoEmote("Sit");
            end
        },
        {
            "Belt",
            "",
            "rbxassetid://5124908388",
            Color3.new(1, 1, 1),
            function() --[[ Line: 407 ]]
                -- upvalues: u49 (copy)
                u49:DoEmote("Belt");
            end
        }
    });
end;
function u22._medical(u50) --[[ Line: 414 ]]
    -- upvalues: u4 (copy)
    u50._page = "medical";
    u50._prev = u50._home;
    local v51, v52, v53 = u50:_getMedical();
    u50:_setOptions({
        {
            "Bandage (x" .. v51 .. ")",
            "Restores 10 health, restores 25 with a dressing",
            "rbxassetid://13795431940",
            Color3.new(1, 1, 1),
            function() --[[ Line: 425 ]]
                -- upvalues: u50 (copy), u4 (ref)
                local l___hoveringClient__8 = u50._hoveringClient;
                local v54;
                if l___hoveringClient__8 then
                    v54 = l___hoveringClient__8.Owner.UserId;
                else
                    v54 = nil;
                end;
                u4:FireServer("UseMedical", "Bandage", v54);
            end
        },
        {
            "Vitamins (x" .. v53 .. ")",
            "Restores 100 health over 5 seconds",
            "rbxassetid://13795410244",
            Color3.new(1, 1, 1),
            function() --[[ Line: 439 ]]
                -- upvalues: u50 (copy), u4 (ref)
                local l___hoveringClient__9 = u50._hoveringClient;
                local v55;
                if l___hoveringClient__9 then
                    v55 = l___hoveringClient__9.Owner.UserId;
                else
                    v55 = nil;
                end;
                u4:FireServer("UseMedical", "Vitamins", v55);
            end
        },
        {
            "Dressing (x" .. v52 .. ")",
            "Restores 5 health, use before using a bandage",
            "rbxassetid://13795410466",
            Color3.new(1, 1, 1),
            function() --[[ Line: 453 ]]
                -- upvalues: u50 (copy), u4 (ref)
                local l___hoveringClient__10 = u50._hoveringClient;
                local v56;
                if l___hoveringClient__10 then
                    v56 = l___hoveringClient__10.Owner.UserId;
                else
                    v56 = nil;
                end;
                u4:FireServer("UseMedical", "Dressing", v56);
            end
        }
    });
end;
function u22._vehicleLightMode(u57) --[[ Line: 465 ]]
    -- upvalues: u16 (copy)
    local l___vehicle__11 = u57._vehicle;
    local l___lightMode__12 = u57._lightMode;
    u57._page = "vehicleLightMode";
    u57._prev = u57._vehicleLights;
    local v58 = {};
    for u59, v60 in l___lightMode__12[2][2] do
        v58[u59] = {
            v60.Name,
            "Set " .. l___lightMode__12[2][1] .. " to " .. v60.Name,
            "",
            l___vehicle__11.Vehicle.LightModes[l___lightMode__12[1]] == u59 and Color3.new(1, 0.52549, 0.52549) or Color3.new(0.549019, 0.980392, 0.549019),
            function() --[[ Line: 479 ]]
                -- upvalues: l___vehicle__11 (copy), u16 (ref), l___lightMode__12 (copy), u59 (copy), u57 (copy)
                if l___vehicle__11.Vehicle.InRestrictedAirspace then
                    u16:Notify({
                        { "Alert", "Light modes may not display while in restricted airspace", Color3.new(1, 0.866666, 0.505882) }
                    });
                end;
                l___vehicle__11.LightModes(l___lightMode__12[1], u59);
                u57:_vehicleLightMode();
            end
        };
    end;
    u57:_setOptions(v58);
end;
function u22._vehicleLights(u61) --[[ Line: 499 ]]
    local l___vehicle__13 = u61._vehicle;
    local l__LightsOn__14 = l___vehicle__13.Vehicle.LightsOn;
    local l__IndicatorMode__15 = l___vehicle__13.Vehicle.IndicatorMode;
    u61._page = "vehicleLights";
    u61._prev = u61._vehicleMenu;
    if l___vehicle__13.LightModes then
        local l__LightModes__16 = l___vehicle__13.Vehicle.VehicleModule.LightModes;
        if l__LightModes__16 and #l__LightModes__16 ~= 0 then
            local v62 = {};
            for u63, u64 in l__LightModes__16 do
                v62[u63] = {
                    u64[1],
                    "Manage " .. u64[1] .. " light modes",
                    "",
                    Color3.new(1, 1, 1),
                    function() --[[ Line: 531 ]]
                        -- upvalues: u61 (copy), u63 (copy), u64 (copy)
                        u61._lightMode = { u63, u64 };
                        u61:_vehicleLightMode();
                    end
                };
            end;
            u61:_setOptions(v62);
        else
            u61:_setOptions({
                {
                    "No lights",
                    "There are no light modes for this vehicle",
                    "",
                    Color3.new(1, 1, 1),
                    function() --[[ Line: 516 ]]
                        -- upvalues: u61 (copy)
                        u61:_vehicleMenu();
                    end
                }
            });
        end;
    else
        u61:_setOptions({
            {
                "Hazards",
                (l__IndicatorMode__15 == 3 and "Turn off" or "Turn on") .. " hazard lights",
                "rbxassetid://15531012850",
                l__IndicatorMode__15 == 3 and Color3.new(1, 0.52549, 0.52549) or Color3.new(0.549019, 0.980392, 0.549019),
                function() --[[ Line: 546 ]]
                    -- upvalues: l___vehicle__13 (copy), u61 (copy)
                    l___vehicle__13.Indicators(3);
                    u61:_vehicleLights();
                end
            },
            {
                "Indicate Right",
                (l__IndicatorMode__15 == 2 and "Turn off" or "Turn on") .. " right indicator",
                "rbxassetid://15531021197",
                l__IndicatorMode__15 == 2 and Color3.new(1, 0.52549, 0.52549) or Color3.new(0.549019, 0.980392, 0.549019),
                function() --[[ Line: 556 ]]
                    -- upvalues: l___vehicle__13 (copy), u61 (copy)
                    l___vehicle__13.Indicators(2);
                    u61:_vehicleLights();
                end
            },
            {
                "Indicate Left",
                (l__IndicatorMode__15 == 1 and "Turn off" or "Turn on") .. " left indicator",
                "rbxassetid://15531012671",
                l__IndicatorMode__15 == 1 and Color3.new(1, 0.52549, 0.52549) or Color3.new(0.549019, 0.980392, 0.549019),
                function() --[[ Line: 566 ]]
                    -- upvalues: l___vehicle__13 (copy), u61 (copy)
                    l___vehicle__13.Indicators(1);
                    u61:_vehicleLights();
                end
            },
            {
                "Headlights",
                (l__LightsOn__14 and "Turn off" or "Turn on") .. " headlights",
                "rbxassetid://15353628980",
                l__LightsOn__14 and Color3.new(1, 0.52549, 0.52549) or Color3.new(0.549019, 0.980392, 0.549019),
                function() --[[ Line: 576 ]]
                    -- upvalues: l___vehicle__13 (copy), u61 (copy)
                    l___vehicle__13.Lights();
                    u61:_vehicleLights();
                end
            }
        });
    end;
end;
function u22._vehicleTurrets(u65) --[[ Line: 585 ]]
    -- upvalues: u2 (copy), u4 (copy)
    local l___vehicle__17 = u65._vehicle;
    u65._page = "vehicleTurrets";
    u65._prev = u65._vehicleMenu;
    local l__TurretAccess__18 = l___vehicle__17.Vehicle.TurretAccess;
    u65:_setOptions({
        {
            "Public",
            "Turrets operatable by anyone",
            "rbxassetid://13795517050",
            l__TurretAccess__18 == u2.TurretAccess.Public and Color3.new(0.549019, 0.980392, 0.549019) or Color3.new(1, 0.52549, 0.52549),
            function() --[[ Line: 597 ]]
                -- upvalues: l___vehicle__17 (copy), u2 (ref), u65 (copy), u4 (ref)
                l___vehicle__17.Vehicle:State("TurretAccess", u2.TurretAccess.Public);
                u65:_vehicleTurrets();
                u4:FireServer("ActivateVehicle", l___vehicle__17.Vehicle.UID, "TurretAccess", u2.TurretAccess.Public);
            end
        },
        {
            "Disable",
            "Turrets operatable by no-one",
            "rbxassetid://17777230248",
            l__TurretAccess__18 == u2.TurretAccess.Disabled and Color3.new(0.549019, 0.980392, 0.549019) or Color3.new(1, 0.52549, 0.52549),
            function() --[[ Line: 608 ]]
                -- upvalues: l___vehicle__17 (copy), u2 (ref), u65 (copy), u4 (ref)
                l___vehicle__17.Vehicle:State("TurretAccess", u2.TurretAccess.Disabled);
                u65:_vehicleTurrets();
                u4:FireServer("ActivateVehicle", l___vehicle__17.Vehicle.UID, "TurretAccess", u2.TurretAccess.Disabled);
            end
        },
        {
            "Squad only",
            "Turrets only operatable by people in your squad",
            "rbxassetid://13797591969",
            l__TurretAccess__18 == u2.TurretAccess.Squad and Color3.new(0.549019, 0.980392, 0.549019) or Color3.new(1, 0.52549, 0.52549),
            function() --[[ Line: 619 ]]
                -- upvalues: l___vehicle__17 (copy), u2 (ref), u65 (copy), u4 (ref)
                l___vehicle__17.Vehicle:State("TurretAccess", u2.TurretAccess.Squad);
                u65:_vehicleTurrets();
                u4:FireServer("ActivateVehicle", l___vehicle__17.Vehicle.UID, "TurretAccess", u2.TurretAccess.Squad);
            end
        }
    });
end;
function u22._vehicleDoors(u66) --[[ Line: 628 ]]
    -- upvalues: u4 (copy)
    local l___vehicle__19 = u66._vehicle;
    u66._page = "vehicleDoors";
    u66._prev = u66._vehicleMenu;
    local v67 = {};
    for u68, v69 in l___vehicle__19.Vehicle.TurretDoors do
        local l__IsOpen__20 = v69.IsOpen;
        v67[#v67 + 1] = {
            v69.Name,
            (l__IsOpen__20 and "Close" or "Open") .. " door",
            "rbxassetid://15353629152",
            l__IsOpen__20 and Color3.new(1, 0.52549, 0.52549) or Color3.new(0.549019, 0.980392, 0.549019),
            function() --[[ Line: 641 ]]
                -- upvalues: l__IsOpen__20 (ref), l___vehicle__19 (copy), u68 (copy), u4 (ref), u66 (copy)
                l__IsOpen__20 = not l__IsOpen__20;
                l___vehicle__19.Vehicle:State("TurretDoor", {
                    Name = u68,
                    IsOpen = l__IsOpen__20
                });
                u4:FireServer("ActivateVehicle", l___vehicle__19.Vehicle.UID, "TurretDoor", u68, l__IsOpen__20);
                u66:_vehicleDoors();
            end
        };
    end;
    if #v67 > 0 then
        u66:_setOptions(v67);
    else
        u66:_setOptions({
            {
                "No doors",
                "There are no auxillary doors on this vehicle",
                "",
                Color3.new(1, 1, 1),
                function() --[[ Line: 662 ]]
                    -- upvalues: u66 (copy)
                    u66:_vehicleMenu();
                end
            }
        });
    end;
end;
function u22._vehicleMenu(u70) --[[ Line: 670 ]]
    local l___vehicle__21 = u70._vehicle;
    local l__EngineOn__22 = l___vehicle__21.Vehicle.EngineOn;
    local l__ParkingBrakeOn__23 = l___vehicle__21.Vehicle.ParkingBrakeOn;
    u70._page = "vehicleMenu";
    u70._prev = u70._home;
    local v71 = {
        {
            "Engine",
            (l__EngineOn__22 and "Stop" or "Start") .. " the vehicle\'s engine",
            "rbxassetid://15353629054",
            l__EngineOn__22 and Color3.new(1, 0.52549, 0.52549) or Color3.new(0.549019, 0.980392, 0.549019),
            function() --[[ Line: 683 ]]
                -- upvalues: l___vehicle__21 (copy), u70 (copy)
                l___vehicle__21.Toggle();
                u70:_vehicleMenu();
            end
        },
        {
            "Doors",
            "Open and close vehicle doors",
            "rbxassetid://15353629152",
            Color3.new(1, 1, 1),
            function() --[[ Line: 693 ]]
                -- upvalues: u70 (copy)
                u70:_vehicleDoors();
            end
        },
        {
            "Turrets",
            "Enable and disable vehicle turrets",
            "rbxassetid://15353628839",
            Color3.new(1, 1, 1),
            function() --[[ Line: 702 ]]
                -- upvalues: u70 (copy)
                u70:_vehicleTurrets();
            end
        },
        {
            "Lights",
            "Toggle the vehicle\'s lights",
            "rbxassetid://15353628980",
            Color3.new(1, 1, 1),
            function() --[[ Line: 711 ]]
                -- upvalues: u70 (copy)
                u70:_vehicleLights();
            end
        },
        {
            "Park",
            "Toggle the vehicle\'s parking brake",
            "rbxassetid://17777230064",
            l__ParkingBrakeOn__23 and Color3.new(1, 0.52549, 0.52549) or Color3.new(0.549019, 0.980392, 0.549019),
            function() --[[ Line: 720 ]]
                -- upvalues: l___vehicle__21 (copy), u70 (copy)
                l___vehicle__21.ToggleParkingBrake();
                u70:_vehicleMenu();
            end
        }
    };
    if l___vehicle__21.Flares then
        v71[#v71 + 1] = {
            "Flares",
            "Deploy the vehicle\'s flares",
            "rbxassetid://100821119275511",
            Color3.new(1, 1, 1),
            function() --[[ Line: 733 ]]
                -- upvalues: l___vehicle__21 (copy)
                l___vehicle__21.Flares();
            end
        };
    end;
    u70:_setOptions(v71);
end;
function u22._attachmentSubFunctions(u72, u73) --[[ Line: 741 ]]
    u72._page = "attachmentSubFunctions";
    u72._prev = u72._attachmentFunctions;
    local v74 = {};
    for u75, u76 in u73.Callbacks do
        local u77 = u73.Activated == u75;
        v74[u75] = {
            u76.Titleline,
            u76.Subline,
            u76.Image or "",
            u77 and Color3.new(1, 0.52549, 0.52549) or Color3.new(0.549019, 0.980392, 0.549019),
            function() --[[ Line: 754 ]]
                -- upvalues: u77 (copy), u75 (copy), u76 (copy), u73 (copy), u72 (copy)
                local v78 = u77 and 0 or u75;
                if not u76.Callback(v78) then
                    u73.Activated = v78;
                end;
                u72:_attachmentSubFunctions(u73);
            end
        };
    end;
    u72:_setOptions(v74);
end;
function u22._generateAttachmentFunction(u79, u80, u81) --[[ Line: 768 ]]
    return typeof(u80.Activated) == "boolean" and {
        u80.Titleline,
        u80.Activated and u80.Subline[1] or u80.Subline[2],
        u80.Image or "",
        u80.Activated and Color3.new(1, 0.52549, 0.52549) or Color3.new(0.549019, 0.980392, 0.549019),
        function() --[[ Line: 776 ]]
            -- upvalues: u80 (copy), u81 (copy)
            local v82 = not u80.Activated;
            if not u80.Callback(v82) then
                u80.Activated = v82;
            end;
            u81();
        end
    } or {
        u80.Titleline,
        u80.Subline,
        u80.Image or "",
        Color3.new(1, 1, 1),
        function() --[[ Line: 790 ]]
            -- upvalues: u79 (copy), u80 (copy)
            u79:_attachmentSubFunctions(u80);
        end
    };
end;
function u22._attachmentFunctions(u83, u84) --[[ Line: 797 ]]
    u83._page = "attachmentFunctions";
    u83._prev = u83._attachmentReset;
    if u84 then
        u83._lastAttachmentData = u84;
    else
        if not u83._lastAttachmentData then
            u83._attachmentReset();
            return;
        end;
        u84 = u83._lastAttachmentData;
    end;
    local function v85() --[[ Line: 812 ]]
        -- upvalues: u83 (copy), u84 (ref)
        u83:_attachmentFunctions(u84);
    end;
    local v86 = {};
    for v87, v88 in u84.Functions do
        v86[v87] = u83:_generateAttachmentFunction(v88, v85);
    end;
    u83:_setOptions(v86);
end;
function u22._attachment(u89, u90) --[[ Line: 824 ]]
    u89._page = u90;
    u89._prev = u89._character;
    local v91 = u89["_" .. u90 .. "Data"];
    u89._lastAttachmentData = nil;
    if u90 then
        function u89._attachmentReset() --[[ Line: 831 ]]
            -- upvalues: u89 (copy), u90 (copy)
            u89:_attachment(u90);
        end;
    end;
    local v92 = {};
    if v91 and #v91 > 0 then
        for v93, u94 in v91 do
            if #u94.Functions == 1 then
                local v95 = u89:_generateAttachmentFunction(u94.Functions[1], u89._attachmentReset);
                v95[1] = u94.Name;
                v92[v93] = v95;
            else
                print(u94);
                v92[v93] = {
                    u94.Name,
                    "View attachment functions",
                    u94.Image or "",
                    Color3.fromRGB(255, 255, 255),
                    function() --[[ Line: 852 ]]
                        -- upvalues: u89 (copy), u94 (copy)
                        u89:_attachmentFunctions(u94);
                    end
                };
            end;
        end;
    else
        v92 = {
            {
                "No attachments",
                "There are no functioning attachments",
                "",
                Color3.fromRGB(255, 255, 255),
                function() --[[ Line: 865 ]]
                    -- upvalues: u89 (copy)
                    u89:_character();
                end
            }
        };
    end;
    u89:_setOptions(v92);
end;
function u22._character(u96) --[[ Line: 875 ]]
    -- upvalues: u11 (copy)
    u96._page = "character";
    u96._prev = u96._home;
    local v97 = {};
    if u96._weaponData then
        v97[#v97 + 1] = {
            "Weapon",
            "Activate lasers, flashlights etc.",
            "rbxassetid://133635301203525",
            Color3.fromRGB(255, 255, 255),
            function() --[[ Line: 886 ]]
                -- upvalues: u96 (copy)
                u96:_attachment("weapon");
            end
        };
    end;
    if u96._helmetData then
        v97[#v97 + 1] = {
            "Helmet",
            "Activate night vision, flashlights etc.",
            "rbxassetid://74834967870944",
            Color3.fromRGB(255, 255, 255),
            function() --[[ Line: 898 ]]
                -- upvalues: u96 (copy)
                u96:_attachment("helmet");
            end
        };
    end;
    v97[#v97 + 1] = {
        "Emotes",
        "A collection of emotes and gestures",
        "rbxassetid://5124908700",
        Color3.fromRGB(255, 255, 255),
        function() --[[ Line: 909 ]]
            -- upvalues: u96 (copy)
            u96:_emote();
        end
    };
    if u11.Compass then
        local l__CompassOpen__24 = u11.CompassOpen;
        v97[#v97 + 1] = {
            "Compass",
            l__CompassOpen__24 and "Close compass" or "Open compass",
            "rbxassetid://129246532828234",
            l__CompassOpen__24 and Color3.new(1, 0.52549, 0.52549) or Color3.new(0.549019, 0.980392, 0.549019),
            function() --[[ Line: 921 ]]
                -- upvalues: u11 (ref), l__CompassOpen__24 (copy), u96 (copy)
                u11.Compass(not l__CompassOpen__24);
                u96:_character();
            end
        };
    end;
    u96:_setOptions(v97);
end;
function u22._home(u98) --[[ Line: 931 ]]
    u98._page = "home";
    u98._prev = u98._disable;
    local v99;
    if u98._vehicle then
        v99 = {
            "Vehicle",
            "Vehicle engine, light and door controls",
            "rbxassetid://15216812708",
            Color3.fromRGB(255, 174, 119),
            function() --[[ Line: 942 ]]
                -- upvalues: u98 (copy)
                u98:_vehicleMenu();
            end
        };
    else
        v99 = {
            "Character",
            "Emotes, weapon and helmet options",
            "rbxassetid://5110581355",
            Color3.fromRGB(255, 174, 119),
            function() --[[ Line: 952 ]]
                -- upvalues: u98 (copy)
                u98:_character();
            end
        };
    end;
    u98:_setOptions({
        v99,
        {
            "Medical",
            "Medical items can be used to restore health",
            "rbxassetid://9547916670",
            Color3.fromRGB(255, 66, 69),
            function() --[[ Line: 965 ]]
                -- upvalues: u98 (copy)
                u98:_medical();
            end
        },
        {
            "Squads",
            "Join to see where other players are on the map",
            "rbxassetid://5111117394",
            Color3.fromRGB(123, 198, 255),
            function() --[[ Line: 974 ]]
                -- upvalues: u98 (copy)
                u98:_squad();
            end
        }
    });
end;
function u22._enable(u100) --[[ Line: 981 ]]
    -- upvalues: u7 (copy), u15 (copy)
    if u7.InventoryOpen then
    elseif u7.PauseOpen then
    else
        u100._hoveringClient = u15.HoveringClient;
        u100._controls = u7:Connect({
            ActionMenuNext = function(p101) --[[ Name: ActionMenuNext, Line 991 ]]
                -- upvalues: u100 (copy)
                if p101 then
                    u100._goNext(u100._options[u100._selected][5]);
                end;
            end,
            ActionMenuPrev = function(p102) --[[ Name: ActionMenuPrev, Line 996 ]]
                -- upvalues: u100 (copy)
                if p102 then
                    u100._goPrev();
                end;
            end
        });
        u7.RadialOpen = true;
        u100._enabledTween:SetGoal(1);
        u100._open = true;
        u100._enabled = true;
        u100:_update();
    end;
end;
function u22._disable(p103) --[[ Line: 1009 ]]
    -- upvalues: u7 (copy)
    if p103._enabled then
        p103._hoveringClient = nil;
        p103._controls:Disconnect();
        u7.RadialOpen = false;
        p103._enabledTween:SetGoal(0);
        p103._open = false;
        p103._enabled = false;
        p103:_update();
        p103._updateHoveringName();
    end;
end;
function u22.new() --[[ Line: 1024 ]]
    -- upvalues: u6 (copy), u2 (copy), u19 (copy), u3 (copy), u7 (copy), u22 (copy), u20 (copy), u13 (copy), u4 (copy), u12 (copy), u14 (copy), u10 (copy), u9 (copy)
    local v104 = u6:CreateProxy(8, u2.ShellPriority.AlwaysVisible, "ActionInterface");
    local v105 = u19.new(0);
    local v106, v107 = u3.createBinding();
    local v108, v109 = u3.createBinding(Color3.fromRGB(107, 213, 95));
    local v110, v111 = u3.createBinding(0);
    local v112, v113 = u3.createBinding(0);
    local l__Touch__25 = u7.Touch;
    local v114 = {
        _enabled = false,
        _selected = 1,
        _degrees = 0,
        _open = false,
        _page = "",
        _bloodSplatterIndex = 1,
        _enabledTween = v105,
        _options = {},
        _touch = l__Touch__25,
        _random = Random.new(),
        _bloodSplatters = {},
        _invites = {},
        _recentInvites = {},
        _health = v112,
        _last = tick(),
        _updateSpinner = v111,
        _updateHoveringName = v107,
        _updateHoveringHealth = v109,
        _updateHealth = v113
    };
    local u115 = setmetatable(v114, u22);
    u115._handle = u3.mount(u3.createElement(u20, {
        Selected = 1,
        Options = {
            {
                "",
                "",
                "",
                Color3.new(1, 1, 1),
                function() --[[ Line: 1065 ]] end
            }
        },
        Spinner = v110,
        HoverHealth = v108,
        HoverName = v106,
        Touch = l__Touch__25,
        EnabledTween = v105,
        Health = v112,
        BloodSplatters = u115._bloodSplatters
    }), v104);
    local v116, v117 = u3.createBinding(1);
    u115._blindness = v116;
    u115._updateBlindness = v117;
    u13:AddColorCorrection({
        Saturation = u115._blindness:map(function(p118) --[[ Line: 1079 ]]
            return p118;
        end),
        Contrast = u115._blindness:map(function(p119) --[[ Line: 1082 ]]
            return p119 / 10;
        end),
        Brightness = u115._blindness:map(function(p120) --[[ Line: 1085 ]]
            return p120 / 10;
        end)
    }, nil, true);
    function u115._setSelected(p121) --[[ Line: 1090 ]]
        -- upvalues: u115 (copy)
        u115._selected = p121;
        u115:_update();
    end;
    function u115._goPrev() --[[ Line: 1096 ]]
        -- upvalues: u115 (copy)
        if u115._prev then
            u115._enabledTween:SetValue(0.9);
            u115._enabledTween:SetGoal(1);
            u115._prev(u115);
        end;
    end;
    function u115._goNext(p122) --[[ Line: 1105 ]]
        -- upvalues: u115 (copy)
        u115._enabledTween:SetValue(1.1);
        u115._enabledTween:SetGoal(1);
        p122();
    end;
    u7.TouchInput:Connect(function(p123) --[[ Line: 1112 ]]
        -- upvalues: u115 (copy)
        u115._touch = p123;
        u115:_update();
    end);
    u4:ConnectEvents({
        InvitedSquad = function(p124, p125) --[[ Name: InvitedSquad, Line 1118 ]]
            -- upvalues: u115 (copy), u12 (ref), u14 (ref)
            if p125 then
                if not table.find(u115._invites, p124) then
                    u115._invites[#u115._invites + 1] = p124;
                end;
                if not u115._recentInvites[p124] then
                    u12:Slide("Received Squad Invite", "Join " .. u14(p124.DisplayName, p124.Name) .. "\'s squad in the action wheel", {});
                    u115._recentInvites[p124] = tick() + 30;
                end;
            else
                local v126 = table.find(u115._invites, p124);
                if v126 then
                    table.remove(u115._invites, v126);
                end;
            end;
            if u115._enabled and u115._page == "viewInvites" then
                u115:_viewInvites();
            end;
        end,
        DestroySquad = function(p127) --[[ Name: DestroySquad, Line 1140 ]]
            -- upvalues: u10 (ref), u9 (ref), u115 (copy)
            if u10.Clients[p127] then
                if u10.Clients[p127].InvitedToSquad then
                    u9:Print("Squad invited left server (" .. p127.Name .. ")", Color3.new(0.5, 0, 1));
                end;
                u10.Clients[p127].Squad = nil;
                if u115._enabled and u115._page == "sendInvites" then
                    u115:_sendInvites();
                end;
            end;
            u10.SquadChanged:Fire();
        end
    });
    return u115;
end;
function u22.SetVehicle(p128, p129) --[[ Line: 1158 ]]
    p128._vehicle = p129;
    if p128._page == "home" or p128._page:sub(1, 7) == "vehicle" then
        p128:_home();
    end;
end;
function u22.Hit(u130, p131) --[[ Line: 1165 ]]
    -- upvalues: u19 (copy), u2 (copy), u21 (copy), u3 (copy)
    u130._lastHit = tick();
    if p131 then
        local v132 = u19.new(0, TweenInfo.new(2, u2.EasingStyle.Exponential, u2.EasingDirection.In, 0, false, 0));
        local l___bloodSplatterIndex__26 = u130._bloodSplatterIndex;
        local u133 = u21[u130._random:NextInteger(1, #u21)];
        u130._bloodSplatters[l___bloodSplatterIndex__26] = u3.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Size = v132:Map(function(p134) --[[ Line: 1173 ]]
                -- upvalues: u133 (copy)
                return UDim2.fromScale(u133[2][1] - p134 / 20, u133[2][2] - p134 / 20);
            end),
            SizeConstraint = u2.SizeConstraint.RelativeYY,
            Position = UDim2.fromScale(u130._random:NextNumber(0.1, 0.9), u130._random:NextNumber(0.1, 0.9)),
            AnchorPoint = Vector2.new(0.5, 0.5),
            ImageColor3 = Color3.new(0.3, 0, 0),
            Rotation = u130._random:NextNumber(1, 360),
            ImageTransparency = v132:Map(function(p135) --[[ Line: 1181 ]]
                return 0.5 + p135 / 2;
            end),
            Image = "rbxassetid://" .. u133[1]
        });
        v132:SetGoal(1);
        u130._bloodSplatterIndex = u130._bloodSplatterIndex + 1;
        u130:_update();
        task.delay(2, function() --[[ Line: 1191 ]]
            -- upvalues: u130 (copy), l___bloodSplatterIndex__26 (copy)
            u130._bloodSplatters[l___bloodSplatterIndex__26] = nil;
            u130:_update();
        end);
    end;
end;
function u22.Enable(u136) --[[ Line: 1198 ]]
    -- upvalues: u7 (copy)
    if u136._toggleControls then
    else
        u136._toggleControls = u7:Connect({
            ActionMenu = function(p137, p138, p139) --[[ Name: ActionMenu, Line 1204 ]]
                -- upvalues: u136 (copy), u7 (ref)
                if p138 or p139 then
                    if p137 then
                        if u136._enabled then
                            u136:_disable();
                        else
                            u136:_home();
                            u136:_enable();
                        end;
                    end;
                elseif p137 and u136._enabled then
                elseif p137 and not u7.RadialOpen then
                    u136:_home();
                    u136:_enable();
                else
                    if u136._enabled then
                        u136:_disable();
                    end;
                end;
            end
        });
    end;
end;
function u22.ForceClose(p140) --[[ Line: 1230 ]]
    if p140._enabled then
        p140:_disable();
    end;
end;
function u22.Disable(p141) --[[ Line: 1236 ]]
    if p141._toggleControls then
        p141._toggleControls:Disconnect();
        p141._toggleControls = nil;
        if p141._enabled then
            p141:_disable();
        end;
    end;
end;
function u22.Update(p142, p143) --[[ Line: 1249 ]]
    -- upvalues: u10 (copy), l__LocalPlayer__2 (copy), u17 (copy), u7 (copy), u14 (copy), u11 (copy)
    local v144 = tick();
    for v145, v146 in p142._recentInvites do
        if v146 < v144 then
            p142._recentInvites[v145] = nil;
        end;
    end;
    local v147 = u10.Clients[l__LocalPlayer__2];
    local v148;
    if v147 then
        v148 = v147.Actor;
        if v148 then
            local v149 = v148.Health / 100;
            if v148.Alive then
                p142._died = nil;
            else
                if not p142._died then
                    p142._died = tick();
                end;
                local v150 = (tick() - p142._died) / 1;
                v149 = math.clamp(v150, 0, 1);
            end;
            local v151 = p142._blindness:getValue();
            local v152 = v144 - p142._last > 4 and 0 or -(1 - v149);
            local v153 = p143 and math.min(p143 * 5, 1) or 1;
            local v154 = math.lerp(v151, v152, v153);
            if not p142._currentHealth or v149 < p142._currentHealth then
                p142._currentHealth = v149;
                p142._last = v144;
            end;
            local v155 = p142._lastHit or 0;
            local v156 = v144 >= v155 + 0.5 and 1 or (v144 - v155) / 0.5;
            local v157 = -v154;
            u17:SetEffectMix("Damage", v157 > 0.5 and (v157 - 0.5) * 2 or 0);
            p142._updateBlindness(v154);
            p142._updateHealth((math.min(v156, v149)));
        else
            p142._currentHealth = 1;
            p142._updateBlindness(0);
            p142._updateHealth(1);
        end;
    else
        v148 = nil;
    end;
    if p142._enabled then
        if u7.PauseOpen then
            p142:_disable();
        else
            local v158 = 0;
            if v147 then
                local l___page__27 = p142._page;
                local l__Squad__28 = v147.Squad;
                if l__Squad__28 ~= p142._currentSquad then
                    p142._currentSquad = l__Squad__28;
                    if l___page__27 == "publicSquads" then
                        p142:_publicSquads();
                    elseif l___page__27 == "viewInvites" then
                        p142:_viewInvites();
                    elseif l___page__27 == "squad" then
                        p142:_squad();
                    end;
                end;
                if v148 then
                    local l__Medical__29 = v148.CurrentState.Medical;
                    if l__Medical__29 ~= p142._lastMedicalState then
                        p142._lastMedicalState = l__Medical__29;
                        if l___page__27 == "medical" then
                            p142:_medical();
                        end;
                    end;
                    if v148.MedicalEnd and v144 < v148.MedicalEnd then
                        v158 = (v144 - v148.MedicalStart) / (v148.MedicalEnd - v148.MedicalStart);
                    end;
                end;
            end;
            p142._updateSpinner(v158);
            local v159 = nil;
            local l___hoveringClient__30 = p142._hoveringClient;
            if l___hoveringClient__30 and v147 then
                local l__Actor__31 = l___hoveringClient__30.Actor;
                if l__Actor__31 and v148 then
                    if l__Actor__31.Alive and (v148.Alive and (l__Actor__31.Parts.UpperTorso.Position - v148.Position).Magnitude <= 6) then
                        local l__Owner__32 = l___hoveringClient__30.Owner;
                        v159 = u14(l__Owner__32.DisplayName, l__Owner__32.Name) .. " (" .. (l__Actor__31.Downed and math.ceil(l__Actor__31.Health * 100) or math.ceil(l__Actor__31.Health)) .. "%)";
                        p142._updateHoveringHealth(Color3.fromRGB(213, 92, 92):Lerp(Color3.fromRGB(107, 213, 95), l__Actor__31.Health / 100));
                    else
                        p142._hoveringClient = nil;
                    end;
                else
                    p142._hoveringClient = nil;
                end;
            end;
            p142._updateHoveringName(v159);
            local l__Equipped__33 = u11.Equipped;
            if l__Equipped__33 then
                l__Equipped__33 = l__Equipped__33.Handler.ActionMenu;
            end;
            if p142._weaponData ~= l__Equipped__33 then
                p142._weaponData = l__Equipped__33;
                if p142._page == "character" or p142._page:sub(1, 10) == "attachment" then
                    p142:_character();
                end;
            end;
            local v160 = v148 and v148.Helmet;
            if v160 then
                v160 = v148.Helmet.ActionMenu;
            end;
            if p142._helmetData ~= v160 then
                p142._helmetData = v160;
                if p142._page == "character" or p142._page:sub(1, 10) == "attachment" then
                    p142:_character();
                end;
            end;
            local v161 = u7:GetRadialMovement();
            if v161.Magnitude < 8 then
            else
                local v162 = math.atan2(v161.X, -v161.Y);
                local v163 = math.deg(v162);
                if v163 < 0 then
                    v163 = v163 + 360;
                end;
                p142._degrees = v163;
                local v164 = #p142._options;
                local v165 = math.ceil(v163 / (360 / v164));
                local v166 = math.clamp(v165, 1, v164);
                if v166 ~= p142._selected then
                    p142._selected = v166;
                    p142:_update();
                end;
            end;
        end;
    end;
end;
return u22.new();