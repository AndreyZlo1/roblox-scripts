-- Services.InterfaceService.CursorInterface.CursorComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local _, u1, u2 = shared.import("require", "Roact", "Enum");
local v3 = u1.Component:extend("Cursor");
function v3.init(p4, p5) --[[ Line: 5 ]]
    p4.CrosshairBinding = p5.CrosshairBinding;
    p4.CrosshairTransparencyBinding = p5.CrosshairTransparencyBinding;
    p4.VirtualCursor = p5.VirtualCursor;
    p4.BlockedPositionBinding = p5.BlockedPositionBinding;
end;
function v3.render(p6) --[[ Line: 12 ]]
    -- upvalues: u1 (copy), u2 (copy)
    local l__props__1 = p6.props;
    local l__CrosshairBinding__2 = p6.CrosshairBinding;
    local l__CrosshairTransparencyBinding__3 = p6.CrosshairTransparencyBinding;
    local l__BlockedPositionBinding__4 = p6.BlockedPositionBinding;
    local l__CursorType__5 = l__props__1.CursorType;
    return u1.createFragment({ u1.createElement("TextLabel", {
            Text = "x",
            TextScaled = true,
            BackgroundTransparency = 1,
            TextTransparency = 0.3,
            Size = UDim2.fromOffset(16, 16),
            FontFace = Font.fromEnum(u2.Font.Michroma),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = l__BlockedPositionBinding__4:map(function(p7) --[[ Line: 25 ]]
                return UDim2.fromOffset(p7 and (p7.X or 0) or 0, p7 and p7.Y or 0);
            end),
            Visible = l__BlockedPositionBinding__4:map(function(p8) --[[ Line: 28 ]]
                return p8 and true or false;
            end),
            TextColor3 = Color3.new(0.219608, 0.219608, 0.219608)
        }), u1.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://13856000545",
            Size = UDim2.fromOffset(128, 128),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = p6.VirtualCursor:map(function(p9) --[[ Line: 39 ]]
                return UDim2.fromOffset(p9.X, p9.Y);
            end)
        }), u1.createElement("Frame", {
            BackgroundTransparency = 1,
            Visible = l__CursorType__5 == u2.CursorType.Crosshair,
            Size = UDim2.fromOffset(1, 1),
            Position = UDim2.fromScale(0.5, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5)
        }, {
            u1.createElement("Frame", {
                BorderSizePixel = 0,
                Size = UDim2.new(0, 2, 0, 10),
                Position = l__CrosshairBinding__2:map(function(p10) --[[ Line: 55 ]]
                    return UDim2.new(0.5, 0, 0.5, p10);
                end),
                BackgroundTransparency = l__CrosshairTransparencyBinding__3:map(function(p11) --[[ Line: 58 ]]
                    return p11;
                end),
                AnchorPoint = Vector2.new(0.5, 0),
                BackgroundColor3 = Color3.new(1, 1, 1)
            }, { u1.createElement("UIGradient", {
                    Rotation = 270,
                    Color = ColorSequence.new(Color3.new(1, 1, 1)),
                    Offset = Vector2.new(0, 0),
                    Transparency = NumberSequence.new(0, 1)
                }) }),
            u1.createElement("Frame", {
                BorderSizePixel = 0,
                Size = UDim2.new(0, 2, 0, 10),
                Position = l__CrosshairBinding__2:map(function(p12) --[[ Line: 74 ]]
                    return UDim2.new(0.5, 0, 0.5, -p12);
                end),
                BackgroundTransparency = l__CrosshairTransparencyBinding__3:map(function(p13) --[[ Line: 77 ]]
                    return p13;
                end),
                AnchorPoint = Vector2.new(0.5, 1),
                BackgroundColor3 = Color3.new(1, 1, 1)
            }, { u1.createElement("UIGradient", {
                    Rotation = 90,
                    Color = ColorSequence.new(Color3.new(1, 1, 1)),
                    Offset = Vector2.new(0, 0),
                    Transparency = NumberSequence.new(0, 1)
                }) }),
            u1.createElement("Frame", {
                BorderSizePixel = 0,
                Size = UDim2.new(0, 10, 0, 2),
                Position = l__CrosshairBinding__2:map(function(p14) --[[ Line: 93 ]]
                    return UDim2.new(0.5, -p14, 0.5, 0);
                end),
                BackgroundTransparency = l__CrosshairTransparencyBinding__3:map(function(p15) --[[ Line: 96 ]]
                    return p15;
                end),
                AnchorPoint = Vector2.new(1, 0.5),
                BackgroundColor3 = Color3.new(1, 1, 1)
            }, { u1.createElement("UIGradient", {
                    Rotation = 0,
                    Color = ColorSequence.new(Color3.new(1, 1, 1)),
                    Offset = Vector2.new(0, 0),
                    Transparency = NumberSequence.new(0, 1)
                }) }),
            u1.createElement("Frame", {
                BorderSizePixel = 0,
                Size = UDim2.new(0, 10, 0, 2),
                Position = l__CrosshairBinding__2:map(function(p16) --[[ Line: 112 ]]
                    return UDim2.new(0.5, p16, 0.5, 0);
                end),
                BackgroundTransparency = l__CrosshairTransparencyBinding__3:map(function(p17) --[[ Line: 115 ]]
                    return p17;
                end),
                AnchorPoint = Vector2.new(0, 0.5),
                BackgroundColor3 = Color3.new(1, 1, 1)
            }, { u1.createElement("UIGradient", {
                    Rotation = 180,
                    Color = ColorSequence.new(Color3.new(1, 1, 1)),
                    Offset = Vector2.new(0, 0),
                    Transparency = NumberSequence.new(0, 1)
                }) }),
            u1.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundTransparency = l__CrosshairTransparencyBinding__3:map(function(p18) --[[ Line: 129 ]]
                    return p18 * 0.5 + 0.5;
                end),
                Size = UDim2.new(0, 2, 0, 2),
                Position = UDim2.new(0.5, 0, 0.5, 0),
                AnchorPoint = Vector2.new(0.5, 0.5),
                BackgroundColor3 = Color3.new(1, 1, 1)
            })
        }) });
end;
return v3;