-- Services.InterfaceService.VoicelineInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, _, _ = shared.import("require", "Enum", "Roact", "network", "server");
local u4 = v1("GameShellProxyService");
local u5 = v1("VoicelineComponent");
local u6 = v1("RoactTween");
local u7 = {};
u7.__index = u7;
function u7._update(p8) --[[ Line: 22 ]]
    -- upvalues: u3 (copy), u5 (copy)
    p8._handle = u3.update(p8._handle, u3.createElement(u5, {
        Lines = p8._lines
    }));
end;
function u7.new() --[[ Line: 28 ]]
    -- upvalues: u4 (copy), u2 (copy), u3 (copy), u5 (copy), u7 (copy)
    local v9 = u4:CreateProxy(1, u2.ShellPriority.Default, "VoicelineInterface");
    local v10 = {
        _id = 0,
        _handle = u3.mount(u3.createElement(u5, {
            Lines = {}
        }), v9),
        _lines = {}
    };
    return setmetatable(v10, u7);
end;
function u7.DoLine(u11, p12, p13, p14, p15) --[[ Line: 42 ]]
    -- upvalues: u6 (copy)
    local u16 = u6.new(0);
    local u17 = u6.new(1);
    local l___id__1 = u11._id;
    u11._lines[l___id__1] = {
        Size = u16,
        Transparency = u17,
        Line = p12,
        Name = p13,
        Color = p14
    };
    u16:SetGoal(1);
    task.delay(0.3, u17.SetGoal, u17, 0);
    local u18 = nil;
    local u19 = false;
    local function u20() --[[ Line: 60 ]]
        -- upvalues: u19 (ref), u18 (ref), u17 (copy), u16 (copy), u11 (copy), l___id__1 (copy)
        if u19 then
        else
            u19 = true;
            u18 = nil;
            u17:SetGoal(1);
            task.delay(0.3, u16.SetGoal, u16, 0);
            task.delay(0.6, function() --[[ Line: 69 ]]
                -- upvalues: u11 (ref), l___id__1 (ref)
                u11._lines[l___id__1] = nil;
                u11:_update();
            end);
        end;
    end;
    u18 = task.delay(p15 + 0.3, u20);
    u11._id = u11._id + 1;
    u11:_update();
    return function() --[[ Line: 78 ]]
        -- upvalues: u18 (ref), u20 (copy)
        if u18 then
            task.cancel(u18);
        end;
        u20();
    end;
end;
return u7.new();