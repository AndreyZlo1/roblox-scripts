-- Services.InterfaceService.VehicleButtonInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, _ = shared.import("require", "Enum", "Roact", "network");
local u4 = v1("GameShellProxyService");
local l__CurrentCamera__1 = workspace.CurrentCamera;
local u5 = v1("VehicleButtonComponent");
local u6 = {};
u6.__index = u6;
function u6._getButtonToolTip(p7, p8) --[[ Line: 22 ]]
    if table.find(p8.Seats, p7._seat.Seat) then
        if p8.Function == "PageBind" then
            local l__Page__2 = p7._vehicle.MFDS[p8.Screen].Page;
            if l__Page__2 and l__Page__2.Binds then
                local v9 = l__Page__2.Binds[p8.Bind];
                if v9 then
                    return v9.ToolTip;
                end;
            end;
        else
            return "Use";
        end;
    end;
end;
function u6._update(p10) --[[ Line: 44 ]]
    -- upvalues: u3 (copy), u5 (copy)
    p10._handle = u3.update(p10._handle, u3.createElement(u5, {
        Buttons = p10._buttons
    }));
end;
function u6.new() --[[ Line: 50 ]]
    -- upvalues: u4 (copy), u2 (copy), u6 (copy)
    local v11 = {
        _ui = u4:CreateProxy(1, u2.ShellPriority.Default, "VehicleButtonInterface"),
        _buttons = {}
    };
    return setmetatable(v11, u6);
end;
function u6.Init(p12, p13, p14) --[[ Line: 60 ]]
    -- upvalues: u3 (copy), u5 (copy)
    if p12._handle then
        p12:Clear();
    end;
    p12._handle = u3.mount(u3.createElement(u5, {
        Buttons = p12._buttons
    }), p12._ui);
    p12._localActor = p13;
    p12._seat = p13.Seat;
    p12._vehicle = p14;
end;
function u6.Update(u15, _) --[[ Line: 73 ]]
    -- upvalues: u3 (copy), l__CurrentCamera__1 (copy)
    if u15._handle then
        local v16 = {};
        local v17 = false;
        if u15._localActor.Focused then
            for u18, v19 in u15._vehicle.Buttons do
                local v20 = u15:_getButtonToolTip(v19);
                if v20 then
                    local v21 = u15._buttons[u18];
                    if not v21 then
                        local v22, v23 = u3.createBinding(v20);
                        local v24, v25 = u3.createBinding(Vector2.new());
                        v21 = {
                            Data = v19,
                            Position = v24,
                            UpdatePosition = v25,
                            Tooltip = v22,
                            UpdateToolTip = v23,
                            Callback = function(p26) --[[ Name: Callback, Line 97 ]]
                                -- upvalues: u15 (copy), u18 (copy)
                                u15._vehicle:Button(u18, p26);
                            end
                        };
                        u15._buttons[u18] = v21;
                        v17 = true;
                    end;
                    local v27 = l__CurrentCamera__1:WorldToViewportPoint(v21.Data.Attachment.WorldPosition);
                    v21.UpdatePosition(UDim2.fromOffset(v27.X, v27.Y));
                    v21.UpdateToolTip(v20);
                    v16[u18] = true;
                end;
            end;
        end;
        for v28 in u15._buttons do
            if not v16[v28] then
                u15._buttons[v28] = nil;
                v17 = true;
            end;
        end;
        if v17 then
            u15:_update();
        end;
    end;
end;
function u6.Clear(p29) --[[ Line: 127 ]]
    -- upvalues: u3 (copy)
    if p29._handle then
        u3.unmount(p29._handle);
    end;
    p29._localActor = nil;
    p29._handle = nil;
    p29._vehicle = nil;
    p29._buttons = {};
end;
return u6.new();