-- Services.InterfaceService.MenuInterface.MenuReduxLoadoutComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4, u5, u6, u7 = shared.import("require", "Roact", "network", "Enum", "frc", "signal", "asset");
game:GetService("GuiService");
game:GetService("Lighting");
local l__RunService__1 = game:GetService("RunService");
local l__UserInputService__2 = game:GetService("UserInputService");
local u8 = v1("PostProcessingService");
local u9 = v1("ClientService");
local u10 = v1("SoundService");
local u11 = v1("StatsService");
local u12 = v1("InputService");
local u13 = v1("NotifyInterface");
local u14 = v1("PopupInterface");
local u15 = v1("RoactTween");
local u16 = v1("BaseComponent");
local u17 = v1("LoadoutSets");
local u18 = v1("GameSettings");
local u19 = v1("skipLevel");
local u20 = v1("formatNumber");
local u21 = v1("Menu");
local u22 = v1("Manufacturers");
local u23 = v1("MenuLoadoutConstants");
local u24 = v1("GameShellProxyService");
local u25 = v1("GameShellProxyGlobals");
local u26 = v1("GameShellProxyButton");
local u27 = v1("MenuReduxSquareButtonComponent");
local u28 = v1("MenuReduxLoadoutStatsComponent");
local u29 = v1("MenuReduxLoadoutHoverComponent");
local u30 = v1("MenuReduxLoadoutShoppingCartComponent");
local u31 = v1("MenuReduxLoadoutViewAreaComponent");
local u32 = v1("MenuReduxLoadoutInfiniteScroller");
local v33 = u2.Component:extend("MenuReduxLoadout");
local l__CurrentCamera__3 = workspace.CurrentCamera;
local l__SAVE_CONFIGS__4 = u23.SAVE_CONFIGS;
local u34 = { "Helmet", "Vest", "Belt" };
local u35 = {
    Helmet = {
        Distance = 5,
        Position = Vector3.new(0, 3, 0)
    },
    Vest = {
        Distance = 4.5,
        Position = Vector3.new(0, 1, 0)
    },
    Belt = {
        Distance = 5,
        Position = Vector3.new(0, -0.25, 0)
    },
    Appearance = {
        Distance = 5,
        Position = Vector3.new(0, 2.5, 0)
    }
};
local u36 = CFrame.new(0, -2500, 0);
local function u40(p37) --[[ Line: 85 ]]
    -- upvalues: u23 (copy)
    local v38 = 0;
    local v39 = p37.Path[2];
    if v39 and u23.PinSubName[v39] then
        return -tonumber(p37.Path[3]:sub(5));
    end;
    local l__MenuTags__5 = p37.MenuTags;
    if l__MenuTags__5 then
        if l__MenuTags__5.REWARD_ITEM then
            v38 = v38 + 3000000;
        end;
        if l__MenuTags__5.NEW then
            v38 = v38 + 2000000;
        end;
        if l__MenuTags__5.REDUX then
            v38 = v38 + 1000000;
        end;
    end;
    if p37.Price then
        v38 = v38 + p37.Price;
    end;
    return v38;
end;
local function u50(p41, p42, p43, p44) --[[ Line: 111 ]]
    -- upvalues: u50 (copy)
    local v45 = p43 or {};
    for _, v46 in p41 do
        local v47 = table.clone(v45);
        local v48 = v46[1];
        v47[#v47 + 1] = v48;
        if p42 == v48 then
            return v47;
        end;
        if v46[2] then
            local v49 = u50(v46[2], p42, v47, p44);
            if v49 then
                return v49;
            end;
        end;
    end;
end;
local function u58(p51, p52, p53) --[[ Line: 132 ]]
    -- upvalues: u58 (copy)
    for _, v54 in p53.Children do
        for _, v55 in v54 do
            local v56, v57 = v55:GetMenuConfig();
            if v56 and not p51:IsComponentUnlocked(v57.Path) then
                table.insert(p52, {
                    Component = v55,
                    Config = v57
                });
            end;
            u58(p51, p52, v55);
        end;
    end;
end;
local function u67(p59, p60) --[[ Line: 144 ]]
    -- upvalues: l__CurrentCamera__3 (copy)
    local l__ViewportSize__6 = l__CurrentCamera__3.ViewportSize;
    local v61 = l__ViewportSize__6.X / l__ViewportSize__6.Y;
    local v62 = Vector2.new(p60.X.Scale * l__ViewportSize__6.X + p60.X.Offset, p60.Y.Scale * l__ViewportSize__6.Y + p60.Y.Offset);
    local v63 = Vector2.new(p59.X.Scale * l__ViewportSize__6.X + p59.X.Offset, p59.Y.Scale * l__ViewportSize__6.Y + p59.Y.Offset) / l__CurrentCamera__3.ViewportSize;
    local v64 = math.rad(l__CurrentCamera__3.FieldOfView) / 2;
    local v65 = math.tan(v64);
    local v66 = v62 / l__ViewportSize__6;
    return CFrame.new(0, 0, 0, v63.X, 0, 0, 0, v63.Y, 0, -v66.X * v65 * v61 * 2, v66.Y * v65 * 2, 1);
end;
local function u79(p68, p69, p70, p71, p72) --[[ Line: 162 ]]
    -- upvalues: u79 (copy)
    local v73 = p71 or {};
    for v74, v75 in p69 do
        local l____IsLast__7 = p69.__IsLast;
        local v76 = type(v75) == "table";
        local v77 = nil;
        if l____IsLast__7 and (v76 and v75.Category) then
            for _, v78 in v75.Category do
                if p68[v78] then
                    v77 = true;
                    break;
                end;
            end;
        end;
        if l____IsLast__7 and (v76 and (v77 or (p68[p72] or p68[v74] and p72 == p70))) then
            table.insert(v73, v75);
        end;
        if v76 and not l____IsLast__7 then
            u79(p68, v75, p70, v73, v74);
        end;
    end;
    return v73;
end;
local function u86(p80) --[[ Line: 191 ]]
    local l__File__8 = p80.File;
    local v81, v82 = p80:GetMenuConfig();
    local v83 = {};
    if v81 and v82.Camos then
        for v84, _ in v82.Camos do
            v83[v84] = p80:GetCamoConfig(v84);
        end;
    end;
    if l__File__8 and l__File__8.Textures then
        for v85, _ in l__File__8.Textures do
            if not v83[v85] then
                v83[v85] = p80:GetCamoConfig(v85);
            end;
        end;
    end;
    return v83;
end;
local function u90(p87) --[[ Line: 213 ]]
    -- upvalues: u16 (copy)
    local v88 = u16.new({ "Character", "Loadout" }, nil, nil, true);
    local v89 = {
        Name = p87,
        Tree = v88:Serialize(),
        WeaponBuilds = {}
    };
    v88:Destroy();
    return v89;
end;
function v33._pasteFromLoadout(p91, p92, p93, p94) --[[ Line: 224 ]]
    -- upvalues: u9 (copy), u16 (copy), l__SAVE_CONFIGS__4 (copy), u13 (copy), u23 (copy), u3 (copy)
    local l__LocalClient__9 = u9.LocalClient;
    local l__ActiveLoadout__10 = l__LocalClient__9.ActiveLoadout;
    local l___currentComponent__11 = p91._currentComponent;
    local v95;
    if #p93 == 0 then
        v95 = l__LocalClient__9.Loadouts[p92].Tree;
        local v96 = u16.Deserialize(v95, true);
        for _, v97 in v96:GetDescendants() do
            if l__SAVE_CONFIGS__4[v97.ParentSubName] then
                l__LocalClient__9.Loadouts[l__ActiveLoadout__10].WeaponBuilds[v97.Path[#v97.Path]] = v97:Serialize();
            end;
        end;
        v96:Destroy();
        u13:Notify({
            { "Alert", "Pasted entire loadout from \'" .. l__LocalClient__9.Loadouts[p92].Name .. "\'", Color3.new(1, 0.866666, 0.505882) }
        });
    else
        local v98 = l___currentComponent__11:GetChild(table.unpack(p93));
        local v99, v100;
        if v98 then
            v99 = v98.ParentComponent;
            v100 = v98.ParentSubName;
        else
            local v101 = table.clone(p93);
            table.remove(v101, #v101);
            if tonumber(v101[#v101]) then
                table.remove(v101, #v101);
            end;
            v99 = l___currentComponent__11:GetChild(table.unpack(v101));
            v100 = p93[#p93];
        end;
        local v102 = v99 or l___currentComponent__11;
        local v103 = l___currentComponent__11:GetChild(p93[1]);
        local v104 = l__LocalClient__9.Loadouts[p92];
        local v105 = nil;
        local v106;
        if p94 and l__SAVE_CONFIGS__4[v100] then
            v106 = v104.WeaponBuilds[p94];
            if v106 then
                v106 = u16.Deserialize(v104.WeaponBuilds[p94], true);
            end;
            if not v106 then
                v106 = u16.new({ "Weapon", "Receiver", p94 }, nil, nil, true);
            end;
        else
            v105 = u16.Deserialize(v104.Tree, true);
            v106 = v105:GetChild(table.unpack(p93));
        end;
        if v103 and v106 then
            local v107, v108 = v106:GetMenuConfig();
            if v107 then
                local v109, v110 = v103:IsUnderCategoryLimit(v108, v98);
                if not v109 then
                    local v111 = {};
                    if v110 then
                        local v112 = { "Cannot Add", v110, Color3.new(1, 0, 0) };
                        table.insert(v111, v112);
                    end;
                    u13:Notify(v111);
                    if v105 then
                        v105:Destroy();
                    end;
                    return;
                end;
            end;
        end;
        if v98 then
            v98:Destroy();
        end;
        if v103 and (v106 and v103 ~= v98) then
            local v113 = v106:GetDescendants();
            local v114 = {};
            for v115 = #v113, 1, -1 do
                local v116 = v113[v115];
                local v117, v118 = v116:GetMenuConfig();
                if v117 then
                    local v119, v120 = v103:IsUnderCategoryLimit(v118);
                    if not v119 then
                        v116:Destroy();
                        if v120 then
                            local v121 = { "Cannot Add", v120, Color3.new(1, 0, 0) };
                            table.insert(v114, v121);
                        end;
                    end;
                end;
            end;
            if #v114 > 0 then
                u13:Notify(v114);
            end;
        end;
        if v106 then
            local v122 = v106:Serialize();
            v106:AssignParent(v102, v100);
            if l__SAVE_CONFIGS__4[v100] then
                l__LocalClient__9.Loadouts[l__ActiveLoadout__10].WeaponBuilds[v106.Path[#v106.Path]] = v122;
            end;
        end;
        if v105 then
            v105:Destroy();
        end;
        local v123 = u23.SubIndexDisplayNames[v100] or v100;
        if p94 and v106 then
            local v124, v125 = v106:GetMenuConfig();
            if v124 then
                v123 = v125.Name;
            end;
        end;
        u13:Notify({
            { "Alert", "Pasted \'" .. v123 .. "\' from \'" .. l__LocalClient__9.Loadouts[p92].Name .. "\'", Color3.new(1, 0.866666, 0.505882) }
        });
        v95 = l___currentComponent__11:Serialize();
    end;
    l__LocalClient__9.Loadouts[l__ActiveLoadout__10].Tree = v95;
    u3:FireServer("PasteFromLoadout", p92, l__ActiveLoadout__10, p93, p94);
end;
function v33._resetBaseComponent(_, p126, p127) --[[ Line: 374 ]]
    -- upvalues: u9 (copy), u3 (copy), u90 (copy)
    local l__LocalClient__12 = u9.LocalClient;
    local l__ActiveLoadout__13 = l__LocalClient__12.ActiveLoadout;
    local v128 = l__LocalClient__12.Loadouts[l__ActiveLoadout__13];
    if p126 then
        local l__Name__14 = v128.Name;
        u3:FireServer("ResetLoadout", l__ActiveLoadout__13);
        table.remove(l__LocalClient__12.Loadouts, l__ActiveLoadout__13);
        local l__Loadouts__15 = l__LocalClient__12.Loadouts;
        local v129 = u90(l__Name__14);
        table.insert(l__Loadouts__15, l__ActiveLoadout__13, v129);
    else
        v128.WeaponBuilds[p127] = nil;
        u3:FireServer("ResetWeaponBuild", l__ActiveLoadout__13, p127);
    end;
end;
function v33._isTopComponent(p130, p131) --[[ Line: 390 ]]
    local l___topComponent__16 = p130._topComponent;
    if l___topComponent__16 then
        l___topComponent__16 = p131 == p130._topComponent.Name;
    end;
    return l___topComponent__16;
end;
function v33._changeTopComponent(p132, p133, p134) --[[ Line: 394 ]]
    if not p132._topComponent or p132._topComponent.Path ~= p133 then
        p132._topComponent = {
            Name = p134,
            Path = p133
        };
    end;
end;
function v33._applyChange(_, p135, p136) --[[ Line: 403 ]]
    -- upvalues: u9 (copy), u16 (copy)
    local l__Path__17 = p136.Path;
    local l__Config__18 = p136.Config;
    local l__IsCamo__19 = p136.IsCamo;
    local l__IsRail__20 = p136.IsRail;
    local l__SaveConfig__21 = p136.SaveConfig;
    local l__LocalClient__22 = u9.LocalClient;
    local v137 = l__LocalClient__22.Loadouts[l__LocalClient__22.ActiveLoadout];
    if not l__IsCamo__19 then
        if not l__Config__18 then
            local l__ParentComponent__23 = p135:GetChild(unpack(l__Path__17)).ParentComponent;
            p135:Remove(unpack(l__Path__17));
            return l__ParentComponent__23;
        end;
        if not l__SaveConfig__21 then
            if l__IsRail__20 then
                return p135:AddChild(l__Config__18.Path, {
                    Lerp = 0.5
                }, unpack(l__Path__17));
            end;
            local v138, v139 = p135:SetChildKeepChildren(l__Config__18.Path, nil, unpack(l__Path__17));
            if v139 then
                if v139.IsBase then
                    u16.ConvertToBase(v138);
                end;
                v139:Destroy();
            end;
            return v138;
        end;
        local v140 = v137.WeaponBuilds[l__Config__18.Path[#l__Config__18.Path]];
        if not v140 then
            local v141, v142 = p135:SetChild(l__Config__18.Path, nil, unpack(l__Path__17));
            if v142 then
                v142:Destroy();
            end;
            return v141;
        end;
        local v143 = p135:GetChild(unpack(l__Path__17));
        if v143 then
            v143:Remove();
            v143:Destroy();
        end;
        local v144 = u16.Deserialize(v140);
        v144:AssignParent(p135, l__SaveConfig__21);
        return v144;
    end;
    local v145 = p135:GetChild(unpack(l__Path__17));
    if v145 then
        v145:EditMetaData({
            Camo = l__Config__18.CamoPath[#l__Config__18.CamoPath]
        });
        return v145;
    end;
end;
function v33._checkForChanges(u146, u147, u148) --[[ Line: 464 ]]
    -- upvalues: u14 (copy)
    if #u146._applyQueue > 0 then
        u14:Open("Unsaved Changes", "You haven\'t purchased the items in your shopping cart.\n\nWould you like to discard these items?", {
            { "Discard and Continue", function() --[[ Line: 467 ]]
                    -- upvalues: u14 (ref), u148 (copy), u146 (copy), u147 (copy)
                    u14:Close();
                    if u148 then
                        u146._applyQueue = {};
                    else
                        u146:_discardShoppingCart();
                    end;
                    u147();
                end },
            { "Cancel", function() --[[ Line: 476 ]]
                    -- upvalues: u14 (ref)
                    u14:Close();
                end }
        });
    else
        u147();
    end;
end;
function v33._discardShoppingCart(p149, p150) --[[ Line: 485 ]]
    p149._applyQueue = {};
    p149._changeModel:Fire(p149.state.Path[1], true);
    local v151 = {
        Camo = false
    };
    if p150 then
        v151.AdditionalPath = {};
    end;
    p149:setState(v151);
end;
function v33._purchaseShoppingCart(p152) --[[ Line: 498 ]]
    -- upvalues: u11 (copy), u14 (copy), u4 (copy), u10 (copy), u9 (copy), u3 (copy)
    local l___applyQueue__24 = p152._applyQueue;
    local v153 = 0;
    for _, v154 in l___applyQueue__24 do
        if not v154.Owned and v154.Config then
            v153 = v153 + (v154.Config.Price or 0);
        end;
    end;
    if u11.Money < v153 then
        u14:Open("Insufficient Funds", nil, {
            { "Close", function() --[[ Line: 515 ]]
                    -- upvalues: u14 (ref)
                    u14:Close();
                end }
        }, u4.PopupType.Shop);
    elseif p152._busy then
    else
        p152._busy = true;
        u10:CreateSound("Button", nil, true, "UISounds", "LoadoutPurchaseStart").Destroy(2);
        local l__LocalClient__25 = u9.LocalClient;
        local v155 = {};
        local v156 = {};
        for _, v157 in l___applyQueue__24 do
            local l__Config__26 = v157.Config;
            if l__Config__26 and not v157.Owned then
                if v157.IsCamo then
                    v155[#v155 + 1] = l__Config__26.CamoPath;
                else
                    v156[#v156 + 1] = l__Config__26.Path;
                end;
            end;
        end;
        u14:SetLoading(true);
        if u3:InvokeServer("TryBuyComponents", v156, v155) then
            for _, v158 in v156 do
                l__LocalClient__25:UnlockComponent(v158);
            end;
            for _, v159 in v155 do
                l__LocalClient__25:UnlockComponent(v159);
            end;
            p152:_processQueue();
            u10:CreateSound("Button", nil, true, "UISounds", "LoadoutPurchaseCompleted").Destroy(2);
        end;
        u14:SetLoading(false);
        p152._busy = false;
    end;
end;
function v33._processQueue(p160) --[[ Line: 571 ]]
    -- upvalues: u9 (copy), l__SAVE_CONFIGS__4 (copy), u3 (copy)
    local l___currentComponent__27 = p160._currentComponent;
    local l__LocalClient__28 = u9.LocalClient;
    local l__ActiveLoadout__29 = l__LocalClient__28.ActiveLoadout;
    local v161 = l__LocalClient__28.Loadouts[l__ActiveLoadout__29];
    local l___applyQueue__30 = p160._applyQueue;
    local v162 = nil;
    local v163 = true;
    for _, v164 in l___applyQueue__30 do
        local l__Config__31 = v164.Config;
        if l__Config__31 and not l__LocalClient__28:IsComponentUnlocked(l__Config__31.CamoPath or l__Config__31.Path, v164.IsCamo) then
            v163 = false;
            break;
        end;
    end;
    if v163 then
        for _, v165 in l___applyQueue__30 do
            local l__Path__32 = v165.Path;
            local l__Config__33 = v165.Config;
            if l__SAVE_CONFIGS__4[l__Path__32[1]] then
                v162 = l__Path__32[1];
            end;
            if l__Config__33 then
                local v166;
                if #l__Path__32 == 1 then
                    v166 = l__Path__32[1] == "Melee";
                else
                    v166 = false;
                end;
                local l__Component__34 = v165.Component;
                if v165.IsCamo then
                    u3:FireServer("SetComponentCamo", l__ActiveLoadout__29, l__Path__32, l__Config__33.CamoPath);
                elseif v165.SaveConfig or v166 then
                    u3:FireServer("ChangeBaseComponent", l__ActiveLoadout__29, l__Path__32, l__Config__33.Path);
                elseif v165.IsRail then
                    if l__Component__34 then
                        u3:FireServer("SetComponentLerp", l__ActiveLoadout__29, l__Component__34:GetFullName(), l__Component__34.MetaData.Lerp, l__Config__33.Path);
                    end;
                else
                    u3:FireServer("AddComponent", l__ActiveLoadout__29, l__Path__32, l__Config__33.Path);
                end;
            else
                u3:FireServer("RemoveComponent", l__ActiveLoadout__29, l__Path__32);
            end;
        end;
        local v167 = v162 and l___currentComponent__27:GetChild(v162);
        if v167 then
            v161.WeaponBuilds[v167.Name] = v167:Serialize();
        end;
        v161.Tree = l___currentComponent__27:Serialize();
        p160._applyQueue = {};
    end;
end;
function v33._cleanQueue(p168, p169, p170, p171) --[[ Line: 638 ]]
    local l___applyQueue__35 = p168._applyQueue;
    while true do
        local v172 = false;
        for v173, v174 in l___applyQueue__35 do
            local v175 = false;
            if p169 then
                if v174.Index == p169 then
                    v175 = not p170 and true or (v174.IsCamo and true or v175);
                else
                    v175 = p171 and v174.Index:sub(1, #p169) == p169 and true or v175;
                end;
            end;
            if v174.Component and v174.Component._Destroyed and true or v175 then
                table.remove(l___applyQueue__35, v173);
                v172 = true;
            end;
        end;
        if not v172 then
            return;
        end;
    end;
end;
function v33._moveComponent(p176, p177) --[[ Line: 678 ]]
    -- upvalues: u9 (copy)
    local v178 = p177:GetFullName();
    local v179 = table.concat(v178, ",");
    local l___applyQueue__36 = p176._applyQueue;
    local v180 = false;
    for _, v181 in l___applyQueue__36 do
        if v181.Index == v179 and not v181.IsCamo then
            v180 = true;
            break;
        end;
    end;
    if not v180 then
        local v182 = {
            IsRail = true,
            IsCamo = false,
            Index = v179,
            Path = v178,
            Config = p177,
            Component = p177
        };
        if u9.LocalClient:IsComponentUnlocked(p177.Path, false) then
            v182.Owned = true;
        end;
        l___applyQueue__36[#l___applyQueue__36 + 1] = v182;
    end;
    p176:_processQueue();
end;
function v33._changeComponent(p183, p184, p185, p186, p187, p188) --[[ Line: 712 ]]
    -- upvalues: u9 (copy), l__SAVE_CONFIGS__4 (copy), u19 (copy), u11 (copy), u14 (copy), u20 (copy), u36 (copy), u58 (copy)
    local l__LocalClient__37 = u9.LocalClient;
    local v189 = p186 and p186.IsCamo and true or false;
    local v190 = table.concat(p185, ",");
    local v191 = {
        Index = v190,
        Path = p185,
        Config = p186,
        IsRail = p187,
        IsCamo = v189
    };
    local v192 = p185[#p185];
    local v193 = l__SAVE_CONFIGS__4[v192];
    if v193 then
        v191.SaveConfig = v192;
    end;
    local v194 = false;
    if p186 then
        if l__LocalClient__37:IsComponentUnlocked(p186.CamoPath or p186.Path, v189) then
            v191.Owned = true;
        end;
    else
        v194 = not v189 and true or v194;
    end;
    if p186 and not v191.Owned then
        local v195 = p186.Price or 0;
        local v196 = p186.Level or 0;
        local v197 = u19(u11.Level, v196, v195);
        if v195 < v197 then
            local v198 = {
                { "Close", function() --[[ Line: 748 ]]
                        -- upvalues: u14 (ref)
                        u14:Close();
                    end }
            };
            u14:Open("Not high enough level", "You have to pay extra to buy this item at your current level.\n\nPrice at level " .. v196 .. ": " .. u20(v195) .. "\nPrice at level " .. u11.Level .. ": " .. u20(v197), v198);
        end;
    end;
    local l___applyQueue__38 = p183._applyQueue;
    p183:_cleanQueue(v190, v189, v194);
    l___applyQueue__38[#l___applyQueue__38 + 1] = v191;
    local v199 = p183:_applyChange(p184, v191);
    if v199 then
        if v193 or v190 == "Melee" then
            local l__ParentModel__39 = v199.ParentModel;
            l__ParentModel__39.PrimaryPart.Anchored = true;
            l__ParentModel__39:PivotTo(u36 * CFrame.Angles(0, 3.141592653589793, 0));
            l__ParentModel__39.Parent = workspace;
            p183._setComponent(p184, l__ParentModel__39);
        end;
        v191.Component = v199;
        if p186 and not v189 then
            local v200 = {};
            u58(l__LocalClient__37, v200, v199);
            for _, v201 in v200 do
                local v202 = v201.Component:GetFullName();
                local v203 = table.concat(v202, ",");
                l___applyQueue__38[#l___applyQueue__38 + 1] = {
                    IsRail = false,
                    IsCamo = false,
                    Index = v203,
                    Path = v202,
                    Component = v201.Component,
                    Config = v201.Config
                };
            end;
            local l__Camo__40 = v199.MetaData.Camo;
            if l__Camo__40 then
                local v204 = v199:GetCamoConfig(l__Camo__40);
                if v204 then
                    l___applyQueue__38[#l___applyQueue__38 + 1] = {
                        IsRail = false,
                        IsCamo = true,
                        Component = v199,
                        Index = v190,
                        Path = p185,
                        Config = v204,
                        Owned = l__LocalClient__37:IsComponentUnlocked(v204.CamoPath, true)
                    };
                end;
            end;
        end;
    end;
    p183:_cleanQueue();
    if not p188 then
        p183:_processQueue();
    end;
    p183._updateAppearance();
end;
function v33._changeLoadout(p205) --[[ Line: 817 ]]
    local l__Reveal__41 = p205.Reveal;
    l__Reveal__41:SetValue(0);
    l__Reveal__41:SetGoal(1);
    p205._changeModel:Fire();
    p205:setState({});
end;
function v33._return(u206) --[[ Line: 826 ]]
    local l___parentPath__42 = u206._parentPath;
    local l___sort__43 = u206._sort;
    local l__state__44 = u206.state;
    local l__AdditionalPath__45 = l__state__44.AdditionalPath;
    if l__state__44.Themes then
        u206:setState({
            Themes = false
        });
    elseif #l__state__44.Path == 0 then
    elseif l__state__44.Camo then
        u206:setState({
            Camo = false
        });
    elseif #l___sort__43 > 0 then
        table.remove(l___sort__43, #l___sort__43);
        u206:setState({});
    elseif #l__AdditionalPath__45 > 0 then
        u206._setAdditionalPath({});
    elseif #l___parentPath__42 == 0 then
        u206:_checkForChanges(function() --[[ Line: 848 ]]
            -- upvalues: u206 (copy)
            u206._changeModel:Fire();
        end);
    elseif l___parentPath__42[1] == "Character" and #l___parentPath__42 == 2 then
        u206:_checkForChanges(function() --[[ Line: 853 ]]
            -- upvalues: u206 (copy), l___parentPath__42 (copy)
            u206._setPath(l___parentPath__42);
        end);
    else
        u206._setPath(l___parentPath__42);
    end;
end;
function v33._updateBackground(p207) --[[ Line: 862 ]]
    local l__Path__46 = p207.state.Path;
    if l__Path__46 and (#l__Path__46 ~= 0 and (l__Path__46[1] ~= "Character" and p207._weaponSet)) then
        if p207._characterSetLoaded ~= false then
            p207._characterSetLoaded = false;
            if p207._characterSet then
                p207._characterSet.Parent = nil;
            end;
            p207._weaponSet.Parent = workspace;
        end;
    else
        if p207._characterSetLoaded then
            return;
        end;
        p207._characterSetLoaded = true;
        if p207._characterSet then
            p207._characterSet.Parent = workspace;
        end;
        if p207._weaponSet then
            p207._weaponSet.Parent = nil;
        end;
    end;
end;
function v33._loadBackground(p208, p209) --[[ Line: 887 ]]
    -- upvalues: u17 (copy), u18 (copy), u7 (copy)
    if p208._characterSet then
        p208._characterSet:Destroy();
        p208._characterSet = nil;
    end;
    if p208._weaponSet then
        p208._weaponSet:Destroy();
        p208._weaponSet = nil;
    end;
    p208._characterSetLoaded = nil;
    local v210 = nil;
    for _, v211 in u17 do
        if v211.ID == p209 then
            v210 = v211;
            break;
        end;
    end;
    if p209 and v210 then
        p208._characterSet = u7:Get("Shared", "Models", "LoadoutSets", p209, "Character").Asset:Clone();
        if v210.WeaponSet then
            p208._weaponSet = u7:Get("Shared", "Models", "LoadoutSets", p209, "Weapon").Asset:Clone();
        end;
        u18.LoadoutBackground = p209;
        p208.NoBack:SetGoal(0);
        p208:_updateBackground();
    else
        p208.NoBack:SetGoal(1);
        u18.LoadoutBackground = nil;
    end;
end;
function v33.init(u212, p213) --[[ Line: 924 ]]
    -- upvalues: u10 (copy), u15 (copy), u4 (copy), u12 (copy), u36 (copy), u18 (copy), u6 (copy), u2 (copy), l__RunService__1 (copy), l__UserInputService__2 (copy), u5 (copy), l__CurrentCamera__3 (copy), u35 (copy), u67 (copy), u8 (copy), u24 (copy), u13 (copy)
    u10:CreateSound("Button", nil, true, "UISounds", "LoadoutOpen").Destroy(10);
    u212.Return = u15.new(0);
    u212.Hide = u15.new(0);
    u212.Reveal = u15.new(0, TweenInfo.new(0.5, u4.EasingStyle.Exponential, u4.EasingDirection.Out, 0, false, 0));
    u212.Landing = u15.new(0, TweenInfo.new(0.7, u4.EasingStyle.Exponential, u4.EasingDirection.Out, 0, false, 0));
    u212.Landing:SetGoal(1);
    u212.Store = u15.new(0.6, TweenInfo.new(0.5, u4.EasingStyle.Exponential, u4.EasingDirection.Out, 0, false, 0));
    u212.Black = u15.new(0, TweenInfo.new(0.5, u4.EasingStyle.Exponential, u4.EasingDirection.Out, 0, false, 0));
    u212.NoBack = u15.new(1);
    u12.UseVirtualCursor = true;
    u212._loadoutMusic = u10:CreateSound("Music", nil, true, "Music", "LoadoutMusic");
    local u214 = Instance.new("Part");
    u214.CFrame = u36;
    u214.Color = Color3.new(0, 0, 0);
    u214.Size = Vector3.new(1, 1, 1);
    u214.Anchored = true;
    local v215 = Instance.new("SpecialMesh");
    v215.MeshId = "rbxassetid://554089739";
    v215.MeshType = u4.MeshType.FileMesh;
    v215.Scale = Vector3.new(-1, -1, -1);
    v215.VertexColor = Vector3.new();
    v215.Parent = u214;
    u214.Parent = workspace;
    local v216 = Instance.new("Part");
    v216.Anchored = true;
    v216.CFrame = u36 * CFrame.new(0, -3.1, 0);
    v216.Size = Vector3.new(6, 0.05, 6);
    v216.Transparency = 1;
    local u217 = Instance.new("Decal");
    u217.Face = u4.NormalId.Top;
    u217.Texture = "rbxassetid://1141086155";
    u217.Transparency = 1;
    u217.Parent = v216;
    local u218 = Instance.new("Decal");
    u218.Face = u4.NormalId.Bottom;
    u218.Texture = "rbxassetid://1141086155";
    u218.Transparency = 1;
    u218.Parent = v216;
    v216.Parent = u214;
    if u18.LoadoutBackground then
        u212:_loadBackground(u18.LoadoutBackground);
    end;
    u212._updateNodes = u6.new();
    u212._changeModel = u6.new();
    u212._leftPanel = u2.createRef();
    u212._viewArea = u2.createRef();
    u212._setCamera = p213.SetCamera;
    local u219 = u212._setCamera("ReduxLoadout");
    local v220, v221 = u2.createBinding(1);
    u212._viewAreaWidth = v220;
    u212._updateViewArea = v221;
    u212._hidden = false;
    u212._background = u214;
    local u222 = 70;
    local u223 = 0.5;
    local u224 = -0.3;
    local u225 = 0;
    local u226 = 0;
    local u227 = u15.new(0, TweenInfo.new(0.5, u4.EasingStyle.Exponential, u4.EasingDirection.Out, 0, false, 0));
    local u228 = Vector3.new();
    local u229 = 15;
    local u230 = u36;
    local u231 = 1;
    local u232 = nil;
    u212._update = l__RunService__1.RenderStepped:Connect(function(p233) --[[ Line: 1004 ]]
        -- upvalues: u212 (copy), l__UserInputService__2 (ref), u12 (ref), u4 (ref), u18 (ref), u224 (ref), u223 (ref), u231 (ref), u5 (ref), u217 (copy), u218 (copy), u228 (ref), l__CurrentCamera__3 (ref), u222 (ref), u225 (ref), u226 (ref), u36 (ref), u232 (ref), u35 (ref), u229 (ref), u230 (ref), u219 (copy), u227 (copy), u67 (ref), u214 (copy), u8 (ref)
        local v234 = u212._viewArea:getValue();
        if v234 then
            local v235 = l__UserInputService__2:GetMouseDelta();
            if u12.Gamepad then
                for _, v236 in l__UserInputService__2:GetGamepadState(u12.Gamepad) do
                    if v236.KeyCode == u4.KeyCode.Thumbstick2 then
                        local l__X__47 = v236.Position.X;
                        local v237 = -v236.Position.Y;
                        local v238 = u18.Thumbstick2DeadZone or 0.2;
                        if v238 < math.abs(l__X__47) or v238 < math.abs(v237) then
                            v235 = Vector2.new(l__X__47, v237);
                        else
                            v235 = Vector2.zero;
                        end;
                    end;
                end;
            end;
            u224 = math.clamp(u224 - v235.Y / 100, -1.2217304763960306, 1.2217304763960306);
            u223 = u223 - v235.X / 100;
            local l__Path__48 = u212.state.Path;
            u231 = math.lerp(u231, (#l__Path__48 > 0 and l__Path__48[1] ~= "Character" and true or u224 > 0.3) and 1 or 0.5, u5(p233));
            u217.Transparency = u231;
            u218.Transparency = u231;
            local l__S__49 = u4.KeyCode.S;
            local l__DPadDown__50 = u4.KeyCode.DPadDown;
            local v239;
            if u12.Gamepad then
                v239 = l__UserInputService__2:IsGamepadButtonDown(u12.Gamepad, l__DPadDown__50);
            else
                v239 = l__UserInputService__2:IsKeyDown(l__S__49);
            end;
            local v240;
            if v239 then
                v240 = 1;
            else
                local l__W__51 = u4.KeyCode.W;
                local l__DPadUp__52 = u4.KeyCode.DPadUp;
                local v241;
                if u12.Gamepad then
                    v241 = l__UserInputService__2:IsGamepadButtonDown(u12.Gamepad, l__DPadUp__52);
                else
                    v241 = l__UserInputService__2:IsKeyDown(l__W__51);
                end;
                v240 = v241 and -1 or 0;
            end;
            local l__D__53 = u4.KeyCode.D;
            local l__DPadRight__54 = u4.KeyCode.DPadRight;
            local v242;
            if u12.Gamepad then
                v242 = l__UserInputService__2:IsGamepadButtonDown(u12.Gamepad, l__DPadRight__54);
            else
                v242 = l__UserInputService__2:IsKeyDown(l__D__53);
            end;
            local v243;
            if v242 then
                v243 = 1;
            else
                local l__A__55 = u4.KeyCode.A;
                local l__DPadLeft__56 = u4.KeyCode.DPadLeft;
                local v244;
                if u12.Gamepad then
                    v244 = l__UserInputService__2:IsGamepadButtonDown(u12.Gamepad, l__DPadLeft__56);
                else
                    v244 = l__UserInputService__2:IsKeyDown(l__A__55);
                end;
                v243 = v244 and -1 or 0;
            end;
            local l__E__57 = u4.KeyCode.E;
            local l__ButtonR2__58 = u4.KeyCode.ButtonR2;
            local v245;
            if u12.Gamepad then
                v245 = l__UserInputService__2:IsGamepadButtonDown(u12.Gamepad, l__ButtonR2__58);
            else
                v245 = l__UserInputService__2:IsKeyDown(l__E__57);
            end;
            local v246;
            if v245 then
                v246 = 1;
            else
                local l__Q__59 = u4.KeyCode.Q;
                local l__ButtonL2__60 = u4.KeyCode.ButtonL2;
                local v247;
                if u12.Gamepad then
                    v247 = l__UserInputService__2:IsGamepadButtonDown(u12.Gamepad, l__ButtonL2__60);
                else
                    v247 = l__UserInputService__2:IsKeyDown(l__Q__59);
                end;
                v246 = v247 and -1 or 0;
            end;
            u228 = u228 + l__CurrentCamera__3.CFrame:VectorToWorldSpace((Vector3.new(v243 * p233, v246 * p233, v240 * p233)));
            local v248 = math.clamp(u228.X, -5, 5);
            local v249 = math.clamp(u228.Y, -5, 5);
            local v250 = math.clamp(u228.Z, -5, 5);
            u228 = Vector3.new(v248, v249, v250);
            local v251 = math.deg(u223) % 360;
            u222 = math.lerp(u222, v251 > 90 and v251 < 265 and 0 or 70, u5(p233 * 5));
            u225 = math.lerp(u225, u223, u5(p233 * 10));
            u226 = math.lerp(u226, u224, u5(p233 * 10));
            local l__ViewportSize__61 = l__CurrentCamera__3.ViewportSize;
            local l__Y__62 = v234.AbsoluteSize.Y;
            local v252 = l__Y__62 * (l__ViewportSize__61.X / l__ViewportSize__61.Y);
            local l__AbsolutePosition__63 = v234.AbsolutePosition;
            u212._updateViewArea(v252);
            local v253 = u36 + Vector3.new(0, 1, 0);
            local v254 = 15;
            if u232 then
                local v255 = u35[l__Path__48[3]];
                if v255 then
                    v253 = CFrame.new(u36.Position + v255.Position);
                    v254 = v255.Distance;
                elseif #l__Path__48 > 0 and l__Path__48[1] ~= "Character" then
                    local v256, v257 = u232:GetBoundingBox();
                    v253 = CFrame.new(v256.Position);
                    v254 = math.max(v257.X, v257.Y, v257.Z) + 1;
                end;
            end;
            local v258 = v253 + u228;
            local v259 = u229;
            local v260 = u5(p233 * 5);
            u229 = math.lerp(v259, v254, v260);
            if not u230:FuzzyEq(v258) then
                u230 = u230:Lerp(v258, u5(p233 * 5));
            end;
            u219.Preset.Environment.GeographicLatitude = u212.Reveal:GetValue() * u222;
            local v261 = (u229 + u227:GetValue()) / 1.5;
            local v262 = u230 * CFrame.Angles(0, u225, 0) * CFrame.Angles(u226, 0, 0);
            u219.FieldOfView = 50;
            u219.Force = CFrame.lookAt((v262 * CFrame.new(0, 0, v261)).Position, u230.Position) * u67(UDim2.fromOffset(v252, l__Y__62), UDim2.fromOffset(l__AbsolutePosition__63.X - l__ViewportSize__61.X / 2 + v252 / 2, l__AbsolutePosition__63.Y - l__ViewportSize__61.Y / 2 + l__Y__62 / 2));
            l__CurrentCamera__3.CFrame = u219.Force;
            if u18.LoadoutBackground == "GreenScreen" then
                local l___characterSet__64 = u212._characterSet;
                if l___characterSet__64 then
                    l___characterSet__64 = u212._characterSet.PrimaryPart;
                end;
                if l___characterSet__64 then
                    l___characterSet__64.CFrame = u219.Force + u219.Force.LookVector * 50;
                end;
                u214.Transparency = 1;
                u8.DepthOfFieldMasterEnabled = false;
            else
                u214.Transparency = 0;
                u8.DepthOfFieldMasterEnabled = true;
            end;
            u212._updateNodes:Fire(p233);
        end;
    end);
    u10:SetEffectMix("LoadoutMenu", 1);
    u219.StopMusic = true;
    u212._inputChanged = l__UserInputService__2.InputChanged:Connect(function(p263) --[[ Line: 1106 ]]
        -- upvalues: u4 (ref), u24 (ref), u227 (copy)
        if p263.UserInputType == u4.UserInputType.MouseWheel then
            if u24:IsScrollBarActive() and u24.Hovering then
                return;
            end;
            local v264 = u227;
            local v265 = u227:GetGoal() - p263.Position.Z / 2;
            v264:SetGoal((math.clamp(v265, -3, 3)));
        end;
    end);
    u212._inputBegan = l__UserInputService__2.InputBegan:Connect(function(p266) --[[ Line: 1116 ]]
        -- upvalues: u4 (ref), u212 (copy)
        if p266.KeyCode == u4.KeyCode.ButtonB then
            u212:_return();
        end;
    end);
    function u212._setComponent(p267, p268) --[[ Line: 1122 ]]
        -- upvalues: u212 (copy), u232 (ref)
        u212._currentComponent = p267;
        u232 = p268;
    end;
    u212._captureStats = u6.new();
    function u212._updateCapturedComponent() --[[ Line: 1132 ]]
        -- upvalues: u212 (copy)
        u212._topComponent = nil;
        u212._captureStats:Fire(u212._currentComponent, u212.state.Path);
        u212:setState({});
    end;
    function u212._updateAppearance() --[[ Line: 1138 ]]
        -- upvalues: u212 (copy)
        if u212.state.Path[1] == "Character" then
            local l___currentComponent__65 = u212._currentComponent;
            if l___currentComponent__65 then
                l___currentComponent__65 = u212._currentComponent:GetChild("Character");
            end;
            if l___currentComponent__65 then
                for _, v269 in l___currentComponent__65:GetDescendants() do
                    if v269.Update then
                        v269:Update();
                    end;
                end;
            end;
        end;
    end;
    function u212._setAdditionalPath(p270) --[[ Line: 1155 ]]
        -- upvalues: u212 (copy)
        u212._sort = {};
        u212:setState({
            Camo = false,
            AdditionalPath = p270
        });
        u212._captureStats:Fire(u212._currentComponent, u212.state.Path);
        u212._updateAppearance();
    end;
    u212._hoverComponent = u6.new();
    function u212._notifyIssue(p271) --[[ Line: 1168 ]]
        -- upvalues: u13 (ref)
        u13:Notify({
            { "Cannot Add", p271, Color3.new(1, 0, 0) }
        });
    end;
    function u212._setPath(p272) --[[ Line: 1178 ]]
        -- upvalues: u228 (ref), u227 (copy), u223 (ref), u224 (ref), u212 (copy)
        u228 = Vector3.new(0, 0, 0);
        if #p272 <= 3 and p272[1] == "Character" then
            u227:SetGoal(0);
            u223 = 0.5;
            u224 = -0.3;
        end;
        if #p272 == 3 and (p272[1] == "Character" and p272[3] == "Backpack") then
            u223 = 3.441592653589793;
            u224 = -0.3;
        end;
        if #p272 == 0 then
            u227:SetGoal(0);
            u223 = 0.5;
            u224 = -0.3;
        end;
        u212._sort = {};
        u212:setState({
            Camo = false,
            Path = p272,
            AdditionalPath = {}
        });
        u212._captureStats:Fire(u212._currentComponent, u212.state.Path);
        u212._updateAppearance();
        u212:_updateBackground();
    end;
    u212._applyQueue = {};
    u212._sort = {};
    u212.Reveal:SetGoal(1);
    u212:setState({
        Camo = false,
        Path = {},
        AdditionalPath = {}
    });
end;
function v33.willUnmount(p273) --[[ Line: 1215 ]]
    -- upvalues: u8 (copy), u12 (copy), u10 (copy)
    u8.DepthOfFieldMasterEnabled = true;
    u12.UseVirtualCursor = false;
    u10:SetEffectMix("LoadoutMenu", 0);
    if p273._characterSet then
        p273._characterSet:Destroy();
        p273._characterSet = nil;
    end;
    if p273._weaponSet then
        p273._weaponSet:Destroy();
        p273._weaponSet = nil;
    end;
    p273._background:Destroy();
    p273._update:Disconnect();
    p273._inputChanged:Disconnect();
    p273._inputBegan:Disconnect();
    p273._setCamera();
    p273._loadoutMusic.FadeOut();
    p273.props.UpdateLoadout();
end;
function v33.render(u274) --[[ Line: 1239 ]]
    -- upvalues: u9 (copy), u17 (copy), u18 (copy), u4 (copy), u3 (copy), u14 (copy), u90 (copy), u13 (copy), u23 (copy), u86 (copy), u79 (copy), u21 (copy), u22 (copy), u50 (copy), u34 (copy), l__SAVE_CONFIGS__4 (copy), u40 (copy), u25 (copy), u2 (copy), u30 (copy), u27 (copy), u28 (copy), u26 (copy), u32 (copy), u29 (copy), u31 (copy), u36 (copy)
    local l__props__66 = u274.props;
    local l__state__67 = u274.state;
    local l__Store__68 = u274.Store;
    local l__Black__69 = u274.Black;
    local l__Hide__70 = u274.Hide;
    local _ = u274.Reveal;
    local l__Landing__71 = u274.Landing;
    local l__Return__72 = u274.Return;
    local l__PopupActive__73 = l__props__66.PopupActive;
    local l__LocalClient__74 = u9.LocalClient;
    local l__ActiveLoadout__75 = l__LocalClient__74.ActiveLoadout;
    local u275 = {};
    local v276 = 1;
    local l___currentComponent__76 = u274._currentComponent;
    local v277 = "Loadouts";
    local v278 = {};
    local l___sort__77 = u274._sort;
    local l__Path__78 = l__state__67.Path;
    local l__Camo__79 = l__state__67.Camo;
    local l__AdditionalPath__80 = l__state__67.AdditionalPath;
    local u279 = false;
    if l__state__67.Themes then
        v277 = "Background Theme";
        for v280, u281 in u17 do
            local u282 = u18.LoadoutBackground == u281.ID;
            u275[v280] = {
                Type = u4.LoadoutButtonType.LoadoutSet,
                Name = u281.Name,
                Authors = u281.Authors,
                ID = u281.ID,
                Selected = u282,
                Callback = function() --[[ Name: Callback, Line 1275 ]]
                    -- upvalues: u282 (copy), u3 (ref), u281 (copy), u274 (copy)
                    if u282 then
                    else
                        u3:FireServer("UpdateSettings", "LoadoutBackground", u281.ID);
                        u274:_loadBackground(u281.ID);
                        u274:setState({});
                    end;
                end
            };
        end;
        table.insert(u275, 1, {
            Icon = "None",
            Type = u4.LoadoutButtonType.Icon,
            Selected = u18.LoadoutBackground == nil,
            Callback = function() --[[ Name: Callback, Line 1291 ]]
                -- upvalues: u3 (ref), u274 (copy)
                u3:FireServer("UpdateSettings", "LoadoutBackground");
                u274:_loadBackground();
                u274:setState({});
            end
        });
    elseif #l__Path__78 == 0 then
        for u283, u284 in l__LocalClient__74.Loadouts do
            u275[#u275 + 1] = {
                Type = u4.LoadoutButtonType.Loadout,
                Loadout = u284,
                LoadoutIndex = u283,
                Selected = u283 == l__ActiveLoadout__75,
                Renaming = u283 == l__state__67.Renaming,
                Rename = function(p285, p286) --[[ Name: Rename, Line 1305 ]]
                    -- upvalues: u14 (ref), u3 (ref), u283 (copy), u284 (copy), u274 (copy)
                    u14:Unfocus();
                    if p286 and u3:InvokeServer("NameLoadout", u283, p285) then
                        u284.Name = p285;
                    end;
                    u274:setState({
                        Renaming = 0
                    });
                end,
                Callback = function() --[[ Name: Callback, Line 1318 ]]
                    -- upvalues: l__LocalClient__74 (copy), u283 (copy), u3 (ref), u274 (copy)
                    if l__LocalClient__74.ActiveLoadout == u283 then
                    else
                        l__LocalClient__74.ActiveLoadout = u283;
                        u3:FireServer("SetActiveLoadout", u283);
                        u274:_changeLoadout();
                    end;
                end
            };
        end;
        u275[#u275 + 1] = {
            Type = u4.LoadoutButtonType.Add,
            Callback = function() --[[ Name: Callback, Line 1331 ]]
                -- upvalues: u3 (ref), l__LocalClient__74 (copy), u90 (ref), u274 (copy), u13 (ref)
                if u3:InvokeServer("AddLoadout") then
                    local l__Loadouts__81 = l__LocalClient__74.Loadouts;
                    local v287 = u90("Loadout " .. tostring(#l__LocalClient__74.Loadouts + 1));
                    table.insert(l__Loadouts__81, v287);
                    u274:setState({});
                else
                    u13:Notify({
                        { "HQ", "Upgrade the \'Gunsmith\' at your HQ for more loadout slots", Color3.new(0.274509, 0.274509, 1) }
                    });
                    u13:Notify({
                        { "Max Loadouts", "You have the maximum loadouts available", Color3.new(1, 0, 0) }
                    });
                end;
            end
        };
    elseif l___currentComponent__76 then
        local v288 = l___currentComponent__76:GetChild(unpack(l__Path__78));
        local v289 = false;
        local v290;
        if v288 then
            v290 = v288.ParentSubName;
        else
            local v291 = #l__Path__78;
            v290 = l__Path__78[v291];
            if tonumber(v290) then
                v290 = l__Path__78[v291 - 1];
            end;
            v289 = true;
        end;
        v278 = table.clone(l__Path__78);
        if #l__AdditionalPath__80 > 0 then
            for _, v292 in l__AdditionalPath__80 do
                v278[#v278 + 1] = v292;
            end;
            v290 = l__AdditionalPath__80[#l__AdditionalPath__80];
        end;
        local u293 = table.clone(v278);
        table.remove(v278, #v278);
        local v294 = v278[#v278];
        if v294 and not tonumber(v294) then
            if v294:sub(1, 4) == "Rail" then
                u279 = true;
            else
                table.remove(v278, #v278);
            end;
        end;
        local u295 = l__LocalClient__74.Loadouts[l__ActiveLoadout__75];
        local function v323(u296, p297, u298, u299, u300, p301, p302, u303, p304, p305) --[[ Line: 1397 ]]
            -- upvalues: l__LocalClient__74 (copy), l___sort__77 (copy), l___currentComponent__76 (copy), u295 (copy), u274 (copy), u23 (ref), l__Path__78 (copy), u4 (ref), u275 (copy)
            if u296.Hidden then
            elseif u296.ForSale == false and not l__LocalClient__74:IsComponentUnlocked(u296.Path) then
            elseif p301 and not table.find(u296.Type or (u296.Category or {}), p301) then
            elseif p302 and u296.Manufacturer ~= l___sort__77[2] then
            else
                local v306 = nil;
                local u307 = true;
                local u308 = nil;
                if u303 then
                    u307, u308 = p304:HasEnoughSpace(u298[#u298], u296);
                else
                    v306 = l___currentComponent__76:GetChild(unpack(u298));
                end;
                local u309, u310 = l___currentComponent__76:IsUnderCategoryLimit(u296, v306, u298[1]);
                local v311 = u296.Path[#u296.Path];
                local v312;
                if p305 and u295.WeaponBuilds[v311] then
                    v312 = u295.WeaponBuilds[v311];
                else
                    v312 = nil;
                end;
                local v313 = l__LocalClient__74:IsComponentUnlocked(u296.CamoPath or u296.Path, u296.IsCamo);
                local v314 = u296.Name == "N/A";
                local u315;
                if p297 == v311 then
                    u315 = not u303;
                else
                    u315 = false;
                end;
                local v316 = u274:_isTopComponent(v311);
                if u296.Path[2] and u23.PinSubName[u296.Path[2]] then
                    v316 = false;
                end;
                local u317 = not u296.IsCamo;
                if u317 then
                    u317 = l__Path__78[1] ~= "Character";
                end;
                local v322 = {
                    Type = u4.LoadoutButtonType.Item,
                    NoRailSpace = not u307,
                    NoCategoryLimit = not u309,
                    Config = u296,
                    None = v314,
                    Unlocked = v313,
                    Selected = u315,
                    TopComponent = v316,
                    SavedConfig = v312,
                    CamoOption = u315 and u299,
                    DoComparison = u317,
                    DoubleClick = function() --[[ Name: DoubleClick, Line 1452 ]]
                        -- upvalues: u317 (copy), u274 (ref)
                        if u317 then
                            u274._updateCapturedComponent();
                        end;
                    end,
                    Callback = function() --[[ Name: Callback, Line 1457 ]]
                        -- upvalues: u315 (copy), u299 (copy), l__Path__78 (ref), u298 (copy), u274 (ref), u307 (ref), u309 (copy), u308 (ref), u310 (copy), l___currentComponent__76 (ref), u296 (copy), u303 (copy), u300 (copy)
                        if u315 then
                            if u299 then
                                local v318 = {};
                                for v319 = #l__Path__78 + 1, #u298 do
                                    v318[#v318 + 1] = u298[v319];
                                end;
                                if tonumber(v318[#v318]) then
                                    table.remove(v318, #v318);
                                end;
                                u274:setState({
                                    Camo = true,
                                    AdditionalPath = v318
                                });
                            end;
                        else
                            local v320 = u307;
                            if v320 then
                                v320 = u309;
                            end;
                            if v320 then
                                local function v321() --[[ Line: 1488 ]]
                                    -- upvalues: u274 (ref), l___currentComponent__76 (ref), u298 (ref), u296 (ref), u303 (ref)
                                    u274:_changeComponent(l___currentComponent__76, u298, u296, u303);
                                    u274:setState({});
                                end;
                                if u300 then
                                    u274:_checkForChanges(v321, true);
                                else
                                    u274:_changeComponent(l___currentComponent__76, u298, u296, u303);
                                    u274:setState({});
                                end;
                            else
                                if u308 then
                                    u274._notifyIssue(u308);
                                end;
                                if u310 then
                                    u274._notifyIssue(u310);
                                end;
                            end;
                        end;
                    end
                };
                if v314 then
                    table.insert(u275, u275[1] and u275[1].Selected and 2 or 1, v322);
                elseif v316 then
                    table.insert(u275, 1, v322);
                else
                    u275[#u275 + 1] = v322;
                end;
            end;
        end;
        if u279 then
            local u324 = table.clone(v278);
            u324[#u324 + 1] = v290;
            local v325 = l___currentComponent__76:GetChild(unpack(u324));
            v277 = v325.Name;
            local v326, v327 = v325:GetMenuConfig();
            if v326 then
                v277 = v327.Name;
            end;
            local v328 = u86(v325);
            if l__Camo__79 then
                local v329 = v325:GetCamoConfig(v325.MetaData.Camo);
                local v330 = v329.CamoPath[#v329.CamoPath];
                u274:_changeTopComponent(table.concat(v325:GetFullName(), ",") .. ",Camo", v330);
                v277 = "Colorways";
                for v331, u332 in v328 do
                    local u333 = v331 == v330;
                    local v334 = l__LocalClient__74:IsComponentUnlocked(u332.CamoPath, true);
                    local v335 = {
                        Type = u4.LoadoutButtonType.Item,
                        Config = u332,
                        Unlocked = v334,
                        Selected = u333,
                        ChildComponent = v325,
                        Callback = function() --[[ Name: Callback, Line 1546 ]]
                            -- upvalues: u333 (copy), u274 (copy), l___currentComponent__76 (copy), u324 (copy), u332 (copy)
                            if u333 then
                            else
                                u274:_changeComponent(l___currentComponent__76, u324, u332, false);
                                u274:setState({});
                            end;
                        end
                    };
                    if u274:_isTopComponent(v331) then
                        table.insert(u275, 1, v335);
                    else
                        u275[#u275 + 1] = v335;
                    end;
                end;
                v276 = 1;
            else
                for _, v336 in u23.RailConsolidate do
                    local v337 = v325:GetChild(v336);
                    if v337 then
                        local v338 = v325:GetCompatibleNames(v336);
                        local v339 = {};
                        for _, v340 in type(v338) ~= "table" and { v338 } or v338 do
                            v339[v340] = true;
                        end;
                        local v341 = u79(v339, u21, v336);
                        local v342 = 0;
                        for _ in u86(v337) do
                            v342 = v342 + 1;
                        end;
                        local v343 = table.concat(v337:GetFullName(), ",");
                        local v344 = v337.Path[#v337.Path];
                        u274:_changeTopComponent(v343, v344);
                        for _, v345 in v341 do
                            v323(v345, v344, v337:GetFullName(), v342 > 1);
                        end;
                    end;
                end;
                table.insert(u275, 1, {
                    Icon = "Remove",
                    Type = u4.LoadoutButtonType.Icon,
                    Callback = function() --[[ Name: Callback, Line 1603 ]]
                        -- upvalues: l__AdditionalPath__80 (copy), u274 (copy), l___currentComponent__76 (copy), u324 (copy)
                        local v346 = table.clone(l__AdditionalPath__80);
                        table.remove(v346, #v346);
                        u274:_changeComponent(l___currentComponent__76, u324, nil, false);
                        u274._setAdditionalPath(v346);
                    end
                });
                local v347 = 0;
                for _ in v328 do
                    v347 = v347 + 1;
                end;
                if v347 > 1 then
                    table.insert(u275, 2, {
                        Type = u4.LoadoutButtonType.Colorway,
                        Callback = function() --[[ Name: Callback, Line 1621 ]]
                            -- upvalues: u274 (copy)
                            u274:setState({
                                Camo = true
                            });
                        end
                    });
                    v276 = 2;
                end;
            end;
        else
            if u23.SubNameItemRowSize[v290] then
                v276 = u23.SubNameItemRowSize[v290];
            end;
            if u23.SubIndexDisplayNames[v290] then
                v277 = u23.SubIndexDisplayNames[v290];
            else
                v277 = v290;
            end;
            local v348 = nil;
            local v349 = true;
            local v350 = v290:sub(1, 4) == "Rail";
            local v351;
            if v350 then
                v351 = "Rail";
                v276 = 2;
            else
                v351 = v290;
            end;
            local v352 = nil;
            local v353 = false;
            local v354 = {};
            local v355 = u23.ListCategories[v351];
            local u356 = l___currentComponent__76:GetChild(unpack(u293));
            if u356 and not v350 then
                v352 = u86(u356);
                local v357 = 0;
                for _ in v352 do
                    v357 = v357 + 1;
                end;
                if v357 > 1 then
                    if v355 then
                        v355 = table.clone(v355);
                        table.insert(v355, 1, { "_CAMOS" });
                    else
                        v353 = true;
                    end;
                end;
            elseif not v350 then
                v289 = true;
            end;
            if l__Camo__79 then
                local v358 = u356:GetCamoConfig(u356.MetaData.Camo);
                local v359 = v358 and v358.CamoPath[#v358.CamoPath] or nil;
                local v360 = u23.WeaponFunctionSubName[u356.ParentSubName];
                v277 = v360 and "Keybinds" or "Colorways";
                u274:_changeTopComponent(table.concat(u356:GetFullName(), ",") .. ",Camo", v359);
                if v352 then
                    for v361, u362 in v352 do
                        local u363 = v361 == v359;
                        local v364 = l__LocalClient__74:IsComponentUnlocked(u362.CamoPath, true);
                        local v365 = {
                            Type = u4.LoadoutButtonType.Item,
                            Config = u362,
                            Selected = u363,
                            Unlocked = v364
                        };
                        local v366;
                        if v360 then
                            v366 = tonumber(v361:sub(15));
                        else
                            v366 = v360;
                        end;
                        v365.KeyBind = v366;
                        v365.ChildComponent = u356;
                        function v365.Callback() --[[ Line: 1700 ]]
                            -- upvalues: u363 (copy), u274 (copy), l___currentComponent__76 (copy), u293 (copy), u362 (copy)
                            if u363 then
                            else
                                u274:_changeComponent(l___currentComponent__76, u293, u362, false);
                                u274:setState({});
                            end;
                        end;
                        if v360 then
                            u275[tonumber(v361:sub(15))] = v365;
                        elseif u274:_isTopComponent(v361) then
                            table.insert(u275, 1, v365);
                        else
                            u275[#u275 + 1] = v365;
                        end;
                    end;
                end;
                v276 = 1;
            else
                local v367 = l___sort__77[1] == "_MANUFACTURERS";
                if v367 then
                    v349 = false;
                elseif v355 and l___sort__77[1] ~= "_SHOWALL" then
                    for v368 = 1, #l___sort__77 do
                        local v369 = l___sort__77[v368];
                        local v370 = nil;
                        for _, v371 in v355 do
                            if v371[1] == v369 then
                                v370 = v371;
                                break;
                            end;
                        end;
                        if not v370 then
                            break;
                        end;
                        if v370[2] then
                            v355 = v370[2];
                        else
                            v348 = v370[1];
                        end;
                        v277 = u23.ListCategoriesDisplayNames[v369] or v369;
                    end;
                    if not v348 then
                        v349 = false;
                        for v372, v373 in v355 do
                            v354[v372] = v373[1];
                        end;
                    end;
                end;
                local v374 = l___currentComponent__76:GetChild(unpack(v278)) or l___currentComponent__76;
                if v374 then
                    local v375 = v374:GetCompatibleNames(v290);
                    local v376 = {};
                    for _, v377 in type(v375) ~= "table" and { v375 } or v375 do
                        v376[v377] = true;
                    end;
                    local v378 = table.concat(u293, ",");
                    local v379;
                    if u356 then
                        v379 = u356.Name;
                    else
                        v379 = u356;
                    end;
                    u274:_changeTopComponent(v378, v379);
                    local v380 = {
                        _CAMOS = true
                    };
                    local v381 = u79(v376, u21, v290);
                    local v382 = {};
                    if not v349 then
                        for _, v383 in v381 do
                            if not v383.Hidden and (v383.ForSale ~= false or l__LocalClient__74:IsComponentUnlocked(v383.Path)) then
                                if v383.Manufacturer and u22[v383.Manufacturer] then
                                    v382[v383.Manufacturer] = true;
                                end;
                                for _, v384 in v383.Type or (v383.Category or {}) do
                                    if not v380[v384] then
                                        v380[v384] = {};
                                    end;
                                    v380[v384][#v380[v384] + 1] = v383;
                                    for _, v385 in u50(v355, v384) or {} do
                                        if not v380[v385] then
                                            v380[v385] = {};
                                        end;
                                        v380[v385][#v380[v385] + 1] = v383;
                                    end;
                                end;
                            end;
                        end;
                        if v367 then
                            if #l___sort__77 == 1 then
                                for u386 in v382 do
                                    u275[#u275 + 1] = {
                                        Type = u4.LoadoutButtonType.Manufacturer,
                                        Manufacturer = u386,
                                        Callback = function() --[[ Name: Callback, Line 1816 ]]
                                            -- upvalues: l___sort__77 (copy), u386 (copy), u274 (copy)
                                            l___sort__77[#l___sort__77 + 1] = u386;
                                            u274:setState({});
                                        end
                                    };
                                end;
                                v276 = 2;
                                v277 = "Manufacturers";
                            else
                                v277 = u22[l___sort__77[2]].Name;
                                v349 = true;
                            end;
                        else
                            local v387 = {};
                            for v388 = 1, #v354 do
                                local v389 = v354[v388];
                                if v380[v389] then
                                    v387[#v387 + 1] = v389;
                                end;
                            end;
                            local v390 = #l___sort__77 == 0;
                            if v390 and (next(v382) and #v387 > 0) then
                                table.insert(v387, v387[1] == "_CAMOS" and 2 or 1, "_MANUFACTURERS");
                            end;
                            if #v387 == 0 then
                                v349 = true;
                            else
                                for v391, u392 in v387 do
                                    if v390 and u392 == "_CAMOS" then
                                        u275[v391] = {
                                            Type = u4.LoadoutButtonType.Colorway,
                                            Callback = function() --[[ Name: Callback, Line 1852 ]]
                                                -- upvalues: u274 (copy)
                                                u274:setState({
                                                    Camo = true
                                                });
                                            end
                                        };
                                    elseif v390 and u392 == "_MANUFACTURERS" then
                                        u275[v391] = {
                                            Type = u4.LoadoutButtonType.Manufacturer,
                                            Manufacturers = v382,
                                            Callback = function() --[[ Name: Callback, Line 1862 ]]
                                                -- upvalues: l___sort__77 (copy), u274 (copy)
                                                l___sort__77[#l___sort__77 + 1] = "_MANUFACTURERS";
                                                u274:setState({});
                                            end
                                        };
                                    else
                                        local v393 = nil;
                                        for _, v394 in v355 do
                                            if v394[1] == u392 then
                                                v393 = v394[3];
                                                break;
                                            end;
                                        end;
                                        local v395 = v380[u392];
                                        local v396 = {};
                                        local v397 = {};
                                        local v398 = nil;
                                        for _, v399 in v395 do
                                            local l__Path__82 = v399.Path;
                                            local v400 = l__Path__82[#l__Path__82];
                                            if not v396[v400] then
                                                v396[v400] = true;
                                                if v393 then
                                                    if v400 ~= v393 then
                                                        l__Path__82 = v398;
                                                    end;
                                                else
                                                    l__Path__82 = v398;
                                                end;
                                                if v399.MenuTags then
                                                    for v401 in v399.MenuTags do
                                                        if v401 ~= "REWARD_ITEM" then
                                                            if not v397[v401] then
                                                                v397[v401] = 0;
                                                            end;
                                                            v397[v401] = v397[v401] + 1;
                                                        end;
                                                    end;
                                                    v398 = l__Path__82;
                                                else
                                                    v398 = l__Path__82;
                                                end;
                                            end;
                                        end;
                                        if not v398 then
                                            local v402 = v395[math.random(1, #v395)];
                                            if v402 then
                                                v398 = v402.Path;
                                            end;
                                        end;
                                        u275[v391] = {
                                            Tags = v397,
                                            Type = u4.LoadoutButtonType.Category,
                                            Name = u392,
                                            Path = v398,
                                            Callback = function() --[[ Name: Callback, Line 1917 ]]
                                                -- upvalues: l___sort__77 (copy), u392 (copy), u274 (copy)
                                                l___sort__77[#l___sort__77 + 1] = u392;
                                                u274:setState({});
                                            end
                                        };
                                    end;
                                end;
                                if v390 then
                                    table.insert(u275, 1, {
                                        Icon = "ShowAll",
                                        Type = u4.LoadoutButtonType.Icon,
                                        Callback = function() --[[ Name: Callback, Line 1929 ]]
                                            -- upvalues: l___sort__77 (copy), u274 (copy)
                                            l___sort__77[#l___sort__77 + 1] = "_SHOWALL";
                                            u274:setState({});
                                        end
                                    });
                                    v276 = 2;
                                else
                                    v276 = 2;
                                end;
                            end;
                        end;
                    end;
                    if v349 then
                        local u403;
                        if #l__AdditionalPath__80 == 0 then
                            if #l__Path__78 == 1 and (l__Path__78[1] == "Primary" or l__Path__78[1] == "Secondary") then
                                u403 = true;
                            elseif #l__Path__78 == 3 and l__Path__78[1] == "Character" then
                                u403 = table.find(u34, l__Path__78[3]);
                            else
                                u403 = false;
                            end;
                        else
                            u403 = false;
                        end;
                        if (v376.none or v376.None) and not v350 then
                            u275[#u275 + 1] = {
                                Icon = "None",
                                Type = u4.LoadoutButtonType.Icon,
                                Selected = v289,
                                Callback = function() --[[ Name: Callback, Line 1950 ]]
                                    -- upvalues: u356 (copy), u274 (copy), l___currentComponent__76 (copy), u403 (copy)
                                    if u356 then
                                        local function v404() --[[ Line: 1955 ]]
                                            -- upvalues: u274 (ref), l___currentComponent__76 (ref), u356 (ref)
                                            u274:_changeComponent(l___currentComponent__76, u356:GetFullName(), nil, false);
                                            u274:setState({});
                                        end;
                                        if u403 then
                                            u274:_checkForChanges(v404, true);
                                        else
                                            u274:_changeComponent(l___currentComponent__76, u356:GetFullName(), nil, false);
                                            u274:setState({});
                                        end;
                                    end;
                                end
                            };
                        end;
                        if v276 > 1 and v353 then
                            table.insert(u275, 1, {
                                Type = u4.LoadoutButtonType.Colorway,
                                Callback = function() --[[ Name: Callback, Line 1973 ]]
                                    -- upvalues: u274 (copy)
                                    u274:setState({
                                        Camo = true
                                    });
                                end
                            });
                            v353 = false;
                        end;
                        local v405 = l__SAVE_CONFIGS__4[v290];
                        table.sort(v381, function(p406, p407) --[[ Line: 1982 ]]
                            -- upvalues: u40 (ref)
                            return u40(p406) > u40(p407);
                        end);
                        for _, v408 in v381 do
                            v323(v408, v379, u293, v353, u403, v348, v367, v350, v374, v405);
                        end;
                    end;
                end;
            end;
        end;
    end;
    local v409 = #l__Path__78 > 0 and true or l__state__67.Themes;
    local v410;
    if #l__Path__78 <= 2 then
        v410 = l__Path__78[1] == "Character";
    else
        v410 = false;
    end;
    local v411;
    if v409 then
        if math.floor(#u275 / v276) < 4 then
            v411 = not v410;
        else
            v411 = false;
        end;
    else
        v411 = v409;
    end;
    local u412 = l__state__67.Themes and 0.6 or (v410 and 0.675 or (v411 and 0.5 or 0.6));
    l__Store__68:SetGoal(u412);
    l__Black__69:SetGoal(v411 and 1 or 0);
    if not v409 then
        l__Return__72:SetGoal(0);
    end;
    local v413 = table.clone(l__Path__78);
    for _, v414 in l__AdditionalPath__80 do
        v413[#v413 + 1] = v414;
    end;
    local l___applyQueue__83 = u274._applyQueue;
    local l__LineThickness__84 = u25.Sizes.LineThickness;
    local v415;
    if #l___applyQueue__83 > 0 then
        v415 = u2.createElement(u30, {
            ApplyQueue = l___applyQueue__83,
            PopupActive = l__PopupActive__73,
            Purchase = function() --[[ Name: Purchase, Line 2035 ]]
                -- upvalues: u274 (copy)
                u274:_purchaseShoppingCart();
            end,
            Discard = function() --[[ Name: Discard, Line 2038 ]]
                -- upvalues: u274 (copy), u279 (ref)
                u274:_discardShoppingCart(u279);
            end
        });
    else
        local l__createFragment__85 = u2.createFragment;
        local v418 = {
            Eye = u2.createElement(u27, {
                Image = "rbxassetid://91708143083340",
                Position = UDim2.fromScale(1, 1),
                PopupActive = l__PopupActive__73,
                Callback = function() --[[ Name: Callback, Line 2048 ]]
                    -- upvalues: u274 (copy), l__Hide__70 (copy), l__Store__68 (copy), u412 (ref)
                    u274._hidden = not u274._hidden;
                    l__Hide__70:SetGoal(u274._hidden and 1 or 0);
                    l__Store__68:SetGoal(u274._hidden and 0.5 or u412);
                end,
                Children = { u2.createElement("Frame", {
                        BorderSizePixel = 0,
                        Rotation = 45,
                        ZIndex = 2,
                        AnchorPoint = Vector2.new(0.5, 0.5),
                        BackgroundColor3 = Color3.new(),
                        BorderColor3 = Color3.new(),
                        Position = UDim2.fromScale(0.5, 0.5),
                        Size = l__Hide__70:Map(function(p416) --[[ Line: 2061 ]]
                            return UDim2.fromScale(p416 * 0.7, 0.1);
                        end)
                    }, {
                        White = u2.createElement("Frame", {
                            BorderSizePixel = 0,
                            AnchorPoint = Vector2.new(0.5, 0.5),
                            BackgroundColor3 = Color3.new(1, 1, 1),
                            BorderColor3 = Color3.new(),
                            Position = UDim2.fromScale(0.5, 0.5),
                            Size = UDim2.fromScale(1, 0.4)
                        })
                    }) }
            }),
            Theme = u2.createElement(u27, {
                Image = "rbxassetid://78653948679586",
                Position = l__Hide__70:Map(function(p417) --[[ Line: 2078 ]]
                    return UDim2.new(p417 * 0.2 + 1, 0, 0.92, -10);
                end),
                PopupActive = l__PopupActive__73,
                Callback = function() --[[ Name: Callback, Line 2083 ]]
                    -- upvalues: u274 (copy), l__state__67 (copy)
                    u274:setState({
                        Themes = not l__state__67.Themes
                    });
                end
            })
        };
        local v419 = not l__state__67.Themes;
        if v419 then
            v419 = u2.createElement(u27, {
                Image = "rbxassetid://100649100365982",
                Position = l__Hide__70:Map(function(p420) --[[ Line: 2090 ]]
                    return UDim2.new(p420 * 0.2 + 1, 0, 0.84, -20);
                end),
                PopupActive = l__PopupActive__73,
                Callback = function() --[[ Name: Callback, Line 2095 ]]
                    -- upvalues: l__LocalClient__74 (copy), u274 (copy), l__Path__78 (copy), u14 (ref), l__ActiveLoadout__75 (copy), u4 (ref)
                    local v421 = {};
                    for u422, v423 in l__LocalClient__74.Loadouts do
                        v421[u422] = { v423.Name, function() --[[ Line: 2098 ]]
                                -- upvalues: u274 (ref), u422 (copy), l__Path__78 (ref), u14 (ref)
                                u274:_pasteFromLoadout(u422, l__Path__78);
                                u274._changeModel:Fire(l__Path__78[1], true);
                                u274:setState({
                                    Camo = false,
                                    AdditionalPath = {}
                                });
                                u14:Close();
                            end, u422 == l__ActiveLoadout__75 };
                    end;
                    v421[#v421 + 1] = { "Cancel", function() --[[ Line: 2109 ]]
                            -- upvalues: u14 (ref)
                            u14:Close();
                        end };
                    local v424 = "Which loadout would you like to paste from?";
                    if #l__Path__78 > 0 and l__Path__78[1] ~= "Character" then
                        v424 = "THIS WILL PASTE THE CURRENTLY <b>EQUIPPED</b> WEAPON SYSTEM.\n\nTo paste a specific weapon build from another loadout, hover over that weapon in the list and select \'PASTE FROM LOADOUT\'\n\n" .. v424;
                    end;
                    u14:Open("Paste from loadout", v424, v421, u4.PopupType.Vertical);
                end
            });
        end;
        v418.Paste = v419;
        v415 = l__createFragment__85(v418);
    end;
    u274._parentPath = v278;
    local l__createFragment__86 = u2.createFragment;
    local v427 = {
        Fade = u2.createElement("Frame", {
            ZIndex = 3,
            BackgroundColor3 = Color3.new(),
            BackgroundTransparency = l__Landing__71:Map(function(p425) --[[ Line: 2128 ]]
                return p425;
            end),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Size = UDim2.fromScale(10, 10),
            Position = UDim2.fromScale(0.5, 0.5)
        }),
        Black = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(),
            BackgroundTransparency = u2.joinBindings({ l__Black__69.Binding, l__Hide__70.Binding, u274.NoBack.Binding }):map(function(p426) --[[ Line: 2138 ]]
                return math.max(unpack(p426));
            end),
            BorderColor3 = Color3.new(),
            Size = UDim2.fromScale(0.6, 1),
            SizeConstraint = u4.SizeConstraint.RelativeYY
        }, {
            UIGradient = u2.createElement("UIGradient", {
                Transparency = NumberSequence.new({
                    NumberSequenceKeypoint.new(0, 0.125),
                    NumberSequenceKeypoint.new(0.379052, 0.15625),
                    NumberSequenceKeypoint.new(0.59601, 0.2875),
                    NumberSequenceKeypoint.new(0.769327, 0.425),
                    NumberSequenceKeypoint.new(0.879052, 0.63125),
                    NumberSequenceKeypoint.new(0.96384, 0.74375),
                    NumberSequenceKeypoint.new(1, 1)
                })
            })
        })
    };
    local l__createElement__87 = u2.createElement;
    local v428 = "Frame";
    local v429 = {
        BackgroundTransparency = 1,
        ZIndex = 2,
        AnchorPoint = Vector2.new(0.5, 0.5),
        Size = UDim2.new(1, -40, 1, -40),
        Position = UDim2.fromScale(0.5, 0.5)
    };
    local v431 = {
        Bottom = u2.createElement(u28, {
            ZIndex = 2,
            CurrentComponent = l___currentComponent__76,
            Path = l__Path__78,
            ChangeModel = u274._changeModel,
            CaptureStats = u274._captureStats,
            Position = u2.joinBindings({ l__Store__68.Binding, l__Hide__70.Binding }):map(function(p430) --[[ Line: 2171 ]]
                return UDim2.fromScale(p430[1], 1 + p430[2]);
            end)
        }),
        Right = v415
    };
    local l__createElement__88 = u2.createElement;
    local v432 = "Frame";
    local v435 = {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(0.5, 1),
        Position = l__Hide__70:Map(function(p433) --[[ Line: 2180 ]]
            return UDim2.fromOffset(p433 * -40, 0);
        end),
        AnchorPoint = l__Hide__70:Map(function(p434) --[[ Line: 2183 ]]
            return Vector2.new(p434, 0);
        end),
        SizeConstraint = u4.SizeConstraint.RelativeYY,
        ZIndex = 3,
        [u2.Ref] = u274._leftPanel
    };
    local v436 = {};
    local l__createElement__89 = u2.createElement;
    local v437 = "Frame";
    local v438 = {
        BorderSizePixel = 0,
        ZIndex = 2,
        Size = UDim2.fromScale(1, 0.08),
        BackgroundColor3 = Color3.new()
    };
    local v439 = {};
    if v409 then
        v409 = u2.createElement(u26, {
            BackgroundTransparency = 1,
            ZIndex = 2,
            SoundKit = "MainMenu",
            Size = UDim2.fromScale(0.2, 1),
            Ignore = l__PopupActive__73,
            MouseUp = function() --[[ Name: MouseUp, Line 2204 ]]
                -- upvalues: l__Return__72 (copy), u274 (copy)
                l__Return__72:SetValue(0);
                l__Return__72:SetGoal(1);
                u274._hoverComponent:Fire();
                u274:_return();
            end,
            MouseEnter = function() --[[ Name: MouseEnter, Line 2210 ]]
                -- upvalues: l__Return__72 (copy)
                l__Return__72:SetGoal(1);
            end,
            MouseLeave = function() --[[ Name: MouseLeave, Line 2213 ]]
                -- upvalues: l__Return__72 (copy)
                l__Return__72:SetGoal(0);
            end
        }, {
            ArrowTop = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Rotation = 45,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.4, 0.5),
                Size = UDim2.new(1, 0, 0, l__LineThickness__84),
                SizeConstraint = u4.SizeConstraint.RelativeYY
            }, {
                White = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.new(1, 1, 1),
                    BorderColor3 = Color3.new(),
                    Position = UDim2.fromScale(0.48, 0),
                    Size = l__Return__72:Map(function(p440) --[[ Line: 2230 ]]
                        return UDim2.fromScale(p440 * 0.1 + 0.3, 1);
                    end)
                })
            }),
            ArrowBottom = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Rotation = -45,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.4, 0.5),
                Size = UDim2.new(1, 0, 0, l__LineThickness__84),
                SizeConstraint = u4.SizeConstraint.RelativeYY
            }, {
                White = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.new(1, 1, 1),
                    BorderColor3 = Color3.new(),
                    Position = UDim2.fromScale(0.48, 0),
                    Size = l__Return__72:Map(function(p441) --[[ Line: 2248 ]]
                        return UDim2.fromScale(p441 * 0.1 + 0.3, 1);
                    end)
                })
            }),
            ArrowLength = u2.createElement("Frame", {
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 0.5),
                BackgroundColor3 = Color3.new(1, 1, 1),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0.4, 0.5),
                Size = l__Return__72:Map(function(p442) --[[ Line: 2259 ]]
                    -- upvalues: l__LineThickness__84 (copy)
                    return UDim2.new(p442 * 0.1 + 0.5, 0, 0, l__LineThickness__84);
                end),
                SizeConstraint = u4.SizeConstraint.RelativeYY
            })
        });
    end;
    v439.Return = v409;
    v439.Dots = u2.createElement("ImageLabel", {
        BackgroundTransparency = 1,
        Image = "rbxassetid://13867939464",
        ImageColor3 = Color3.fromRGB(71, 71, 71),
        ScaleType = u4.ScaleType.Tile,
        Size = UDim2.fromScale(1, 1),
        TileSize = UDim2.fromOffset(6, 6)
    }, {
        Title = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            AnchorPoint = Vector2.new(0, 0.5),
            FontFace = Font.new("rbxassetid://12187375422", u4.FontWeight.Bold, u4.FontStyle.Normal),
            Position = UDim2.fromScale(0, 0.5),
            Size = UDim2.fromScale(0.9, 0.4),
            Text = v277:upper(),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u4.TextXAlignment.Right
        }),
        Gradient = u2.createElement("UIGradient", {
            Rotation = 139,
            Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
        })
    });
    v436.Header = l__createElement__89(v437, v438, v439);
    v436.Scroll = u2.createElement(u32, {
        Position = UDim2.fromScale(0, 0.08),
        Size = UDim2.fromScale(1, 0.92),
        HoverComponent = u274._hoverComponent,
        PopupActive = l__PopupActive__73,
        ItemsPerRow = v276,
        Items = u275
    });
    v436.Hover = u2.createElement(u29, {
        UpdateNodes = u274._updateNodes,
        HoverComponent = u274._hoverComponent,
        LeftPanel = u274._leftPanel,
        Path = l__Path__78,
        CartOpen = #l___applyQueue__83 > 0,
        ResetBuild = function(p443, u444, u445) --[[ Name: ResetBuild, Line 2313 ]]
            -- upvalues: u14 (ref), u274 (copy)
            u14:Open("Reset to default configuration", "Are you sure you want " .. p443 .. " to be restored to the default configuration?\n\nThis action CANNOT be undone", {
                { "Reset", function() --[[ Line: 2315 ]]
                        -- upvalues: u274 (ref), u444 (copy), u445 (copy), u14 (ref)
                        u274:_resetBaseComponent(u444, u445);
                        u14:Close();
                        u274:setState({});
                    end },
                { "Cancel", function() --[[ Line: 2320 ]]
                        -- upvalues: u14 (ref)
                        u14:Close();
                    end }
            });
        end,
        PasteFrom = function(u446) --[[ Name: PasteFrom, Line 2325 ]]
            -- upvalues: l__LocalClient__74 (copy), u274 (copy), l__Path__78 (copy), u14 (ref), l__ActiveLoadout__75 (copy), u4 (ref)
            local v447 = {};
            for u448, v449 in l__LocalClient__74.Loadouts do
                v447[u448] = { v449.Name, function() --[[ Line: 2328 ]]
                        -- upvalues: u274 (ref), u448 (copy), l__Path__78 (ref), u446 (copy), u14 (ref)
                        u274:_pasteFromLoadout(u448, l__Path__78, u446);
                        u274._changeModel:Fire(l__Path__78[1], true);
                        u274:setState({
                            Camo = false,
                            AdditionalPath = {}
                        });
                        u14:Close();
                    end, u448 == l__ActiveLoadout__75 };
            end;
            v447[#v447 + 1] = { "Cancel", function() --[[ Line: 2339 ]]
                    -- upvalues: u14 (ref)
                    u14:Close();
                end };
            u14:Open("Paste from loadout", "Which loadout would you like to paste from?", v447, u4.PopupType.Vertical);
        end,
        ChangeComponent = function(p450, p451, p452, p453) --[[ Name: ChangeComponent, Line 2345 ]]
            -- upvalues: u274 (copy), l___currentComponent__76 (copy)
            u274:_changeComponent(l___currentComponent__76, p451, p452, p453, not p450);
            if p450 then
                u274:setState({});
            end;
        end,
        DeleteLoadout = function(u454) --[[ Name: DeleteLoadout, Line 2351 ]]
            -- upvalues: u14 (ref), l__LocalClient__74 (copy), u3 (ref), l__ActiveLoadout__75 (copy), u274 (copy)
            u14:Open("Delete loadout", "Are you sure you want to delete " .. l__LocalClient__74.Loadouts[u454].Name .. "?\n\nThis action CANNOT be undone", {
                { "Yes", function() --[[ Line: 2353 ]]
                        -- upvalues: u3 (ref), u454 (copy), l__LocalClient__74 (ref), l__ActiveLoadout__75 (ref), u274 (ref), u14 (ref)
                        if u3:InvokeServer("DeleteLoadout", u454) then
                            table.remove(l__LocalClient__74.Loadouts, u454);
                            if u454 < l__ActiveLoadout__75 then
                                local v455 = l__LocalClient__74;
                                v455.ActiveLoadout = v455.ActiveLoadout - 1;
                            elseif u454 == l__ActiveLoadout__75 then
                                l__LocalClient__74.ActiveLoadout = 1;
                            end;
                            u274:_changeLoadout();
                        end;
                        u14:Close();
                    end },
                { "No", function() --[[ Line: 2366 ]]
                        -- upvalues: u14 (ref)
                        u14:Close();
                    end }
            });
        end,
        RenameLoadout = function(p456, p457) --[[ Name: RenameLoadout, Line 2371 ]]
            -- upvalues: u274 (copy), u14 (ref)
            u274._hoverComponent:Fire(nil);
            u14:Focus(p457, function() --[[ Line: 2373 ]]
                -- upvalues: u274 (ref)
                u274:setState({
                    Renaming = 0
                });
            end);
            u274:setState({
                Renaming = p456
            });
        end
    });
    v431.Left = l__createElement__88(v432, v435, v436);
    v431.ViewArea = u2.createElement(u31, {
        Size = u274._viewAreaWidth:map(function(p458) --[[ Line: 2386 ]]
            return UDim2.new(0, p458, 1, 0);
        end),
        Position = u274.Store:Map(function(p459) --[[ Line: 2389 ]]
            return UDim2.fromScale(p459, 0);
        end),
        Ref = u274._viewArea,
        PopupActive = l__PopupActive__73,
        HideBoolean = l__state__67.Themes,
        Hide = l__Hide__70,
        Origin = u36,
        Path = l__Path__78,
        FullPath = table.concat(v413, ","),
        SetPath = u274._setPath,
        SetAdditionalPath = u274._setAdditionalPath,
        SetComponent = u274._setComponent,
        UpdateNodes = u274._updateNodes,
        ChangeModel = u274._changeModel,
        MoveComponent = function(p460) --[[ Name: MoveComponent, Line 2406 ]]
            -- upvalues: u274 (copy)
            u274:_moveComponent(p460);
        end
    });
    v427.Content = l__createElement__87(v428, v429, v431);
    return l__createFragment__86(v427);
end;
return v33;