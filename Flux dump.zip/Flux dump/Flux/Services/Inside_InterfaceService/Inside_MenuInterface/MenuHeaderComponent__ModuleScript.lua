-- Services.InterfaceService.MenuInterface.MenuHeaderComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4, u5 = shared.import("require", "Roact", "server", "network", "Enum");
local u6 = v1("StatsService");
local u7 = v1("InputService");
local u8 = v1("PopupInterface");
local u9 = v1("MenuLobbyComponent");
local u10 = v1("HUDInterface");
local u11 = v1("MenuButtonComponent");
local v12 = u2.Component:extend("MenuHeader");
local l__RunService__1 = game:GetService("RunService");
local l__UserInputService__2 = game:GetService("UserInputService");
local u13 = Font.fromId(12187375422, u5.FontWeight.Bold, u5.FontStyle.Normal);
local u14 = Font.fromId(12187375422, u5.FontWeight.Regular, u5.FontStyle.Normal);
local u15 = Font.fromEnum(u5.Font.Code);
local u16 = {
    LoadoutPvP = "Loadout"
};
local function u21(p17) --[[ Line: 26 ]]
    local v18 = p17 % 60;
    local v19 = math.floor(p17 / 60) % 60;
    local v20 = math.floor(p17 / 3600) % 24;
    if p17 <= 0 then
        v20 = 0;
        v19 = 0;
        v18 = 0;
    end;
    return string.format("%02i", v20) .. ":" .. string.format("%02i", v19) .. ":" .. string.format("%02i", v18);
end;
function v12.init(u22, p23) --[[ Line: 39 ]]
    -- upvalues: u2 (copy), u7 (copy), l__UserInputService__2 (copy), u5 (copy), u3 (copy), l__RunService__1 (copy), u6 (copy), u21 (copy)
    u22.ServerCodeRef = u2.createRef();
    u22.Connection = u7.GamepadInput:Connect(function(p24) --[[ Line: 41 ]]
        -- upvalues: u22 (copy)
        u22:setState({
            Gamepad = p24
        });
    end);
    u22.Input = l__UserInputService__2.InputBegan:Connect(function(p25) --[[ Line: 47 ]]
        -- upvalues: u22 (copy), u5 (ref)
        local l__Pages__3 = u22.props.Pages;
        local v26 = table.find(l__Pages__3, u22.props.Page);
        if p25.KeyCode == u5.KeyCode.ButtonL1 then
            if v26 > 1 then
                u22.props.ChangePage(l__Pages__3[v26 - 1]);
            end;
        elseif p25.KeyCode == u5.KeyCode.ButtonR1 and v26 < #l__Pages__3 then
            u22.props.ChangePage(l__Pages__3[v26 + 1]);
        end;
    end);
    local l__SERVER_CODE__4 = u3.SERVER_CODE;
    if l__SERVER_CODE__4 then
        u22.RenderConnection = l__RunService__1.RenderStepped:Connect(function(_) --[[ Line: 63 ]]
            -- upvalues: u22 (copy), l__SERVER_CODE__4 (copy)
            local v27 = u22.ServerCodeRef:getValue();
            if v27 then
                v27.Text = l__SERVER_CODE__4;
            end;
        end);
        u22.ServerCode = l__SERVER_CODE__4;
    end;
    local l__ExpBinding__5 = p23.ExpBinding;
    local v28, v29 = u2.createBinding(l__ExpBinding__5:getValue());
    u22.ExpBinding = v28;
    u22._updateExp = v29;
    u22.Update = l__RunService__1.Heartbeat:Connect(function() --[[ Line: 74 ]]
        -- upvalues: u6 (ref), l__ExpBinding__5 (copy), u3 (ref), u22 (copy), u21 (ref)
        local v30 = os.difftime(u6.Expires, os.time());
        local v31 = "<b>" .. (l__ExpBinding__5:getValue() or "") .. "</b>";
        if v30 > 0 and (not u3.CHEATS_ENABLED and u22.props.Page ~= "Loadout") then
            v31 = "(BOOSTER " .. u21(v30) .. ") " .. v31;
        end;
        u22._updateExp(v31);
    end);
    u22:setState({
        Gamepad = u7.Gamepad
    });
end;
function v12.willUnmount(p32) --[[ Line: 90 ]]
    if p32.RenderConnection then
        p32.RenderConnection:Disconnect();
    end;
    p32.Update:Disconnect();
    p32.Connection:Disconnect();
    p32.Input:Disconnect();
end;
function v12.render(p33) --[[ Line: 99 ]]
    -- upvalues: u2 (copy), u11 (copy), u16 (copy), u9 (copy), u5 (copy), u15 (copy), u13 (copy), u3 (copy), u10 (copy), u8 (copy), u4 (copy), u7 (copy), u14 (copy), l__UserInputService__2 (copy)
    local l__props__6 = p33.props;
    local l__Pages__7 = l__props__6.Pages;
    local l__PopupActive__8 = l__props__6.PopupActive;
    local l__Gamepad__9 = p33.state.Gamepad;
    local v34 = {};
    for v35, u36 in l__Pages__7 do
        v34[u36] = u2.createElement(u11, {
            Layout = v35,
            Name = u16[u36] or u36,
            Ignore = l__Gamepad__9 or l__PopupActive__8,
            Activated = l__props__6.Page == u36,
            Callback = function() --[[ Name: Callback, Line 111 ]]
                -- upvalues: l__props__6 (copy), u36 (copy)
                l__props__6.ChangePage(u36);
            end
        });
    end;
    local v37;
    if l__props__6.MatchmakingQueueData and l__props__6.MatchmakingQueueData.CurrentLobby[1] then
        v37 = u2.createElement(u9, {
            ExpandedTween = l__props__6.ExpandedTween,
            MatchmakingQueueData = l__props__6.MatchmakingQueueData,
            PopupActive = l__PopupActive__8,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Size = UDim2.fromScale(0, 0.3),
            Position = UDim2.fromScale(0.5, 0.45)
        });
    else
        v37 = nil;
    end;
    if p33.ServerCode then
        v37 = u2.createElement("Frame", {
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Size = UDim2.fromScale(3, 0.2),
            SizeConstraint = u5.SizeConstraint.RelativeYY,
            Position = UDim2.fromScale(0.5, 0.46),
            BackgroundColor3 = Color3.new()
        }, { u2.createElement("UIStroke", {
                Thickness = 1,
                ApplyStrokeMode = u5.ApplyStrokeMode.Contextual,
                Color = Color3.fromRGB(71, 71, 71),
                LineJoinMode = u5.LineJoinMode.Round
            }), u2.createElement("TextBox", {
                Size = UDim2.fromScale(1, 0.7),
                Position = UDim2.fromScale(0, 0.5),
                AnchorPoint = Vector2.new(0, 0.5),
                BackgroundTransparency = 1,
                ClearTextOnFocus = false,
                TextEditable = false,
                TextScaled = true,
                Selectable = false,
                Text = p33.ServerCode,
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u15,
                [u2.Ref] = p33.ServerCodeRef
            }), u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "SERVER CODE",
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0),
                Size = UDim2.fromScale(1, 0.8),
                Position = UDim2.fromScale(0, -1),
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u13,
                TextXAlignment = u5.TextXAlignment.Center
            }) });
    end;
    local v38;
    if u3.RETURN_MENU then
        v38 = u2.createElement(u11, {
            Image = "rbxassetid://95718280743867",
            ImageY = 0.6,
            ZIndex = 3,
            Size = UDim2.fromScale(0.4, 0.4),
            Position = UDim2.fromScale(0.95, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5),
            SizeConstraint = u5.SizeConstraint.RelativeYY,
            Ignore = l__PopupActive__8,
            Callback = function() --[[ Name: Callback, Line 183 ]]
                -- upvalues: u10 (ref), u8 (ref), u4 (ref)
                local v39, v40, v41;
                if u10.CombatExpire and u10.CombatExpire > workspace:GetServerTimeNow() then
                    v39 = "WARNING!";
                    v40 = "You are in combat! Leaving the game will reset your survivor inventory.\n\nWait for the combat timer to run out before exiting the game.";
                    v41 = "Exit (Reset Inventory)";
                else
                    v39 = "Return to menu";
                    v40 = "Are you sure you want to return to the main menu?";
                    v41 = "Yes";
                end;
                u8:Open(v39, v40, {
                    { v41, function() --[[ Line: 194 ]]
                            -- upvalues: u4 (ref), u8 (ref)
                            u4:FireServer("ReturnMenu");
                            u8:Close();
                        end },
                    { "Close", function() --[[ Line: 198 ]]
                            -- upvalues: u8 (ref)
                            u8:Close();
                        end }
                });
            end
        });
    else
        v38 = nil;
    end;
    local l__CHEATS_ENABLED__10 = u3.CHEATS_ENABLED;
    local l__createFragment__11 = u2.createFragment;
    local v42 = {
        Leave = v38
    };
    local v43 = u7.Touch and u7.PauseOpen;
    if v43 then
        v43 = u2.createElement(u11, {
            Image = "rbxassetid://105277314441014",
            ImageY = 0.4,
            ZIndex = 3,
            Size = UDim2.fromScale(0.4, 0.4),
            Position = UDim2.fromScale(0.9, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5),
            SizeConstraint = u5.SizeConstraint.RelativeYY,
            Ignore = l__PopupActive__8,
            Callback = function() --[[ Name: Callback, Line 218 ]]
                -- upvalues: u7 (ref)
                u7:TouchBind("PauseMenu", true);
            end
        });
    end;
    v42.Resume = v43;
    v42.Dots = u2.createElement("ImageLabel", {
        BackgroundTransparency = 1,
        Image = "rbxassetid://13867939464",
        ImageTransparency = 1,
        ZIndex = 2,
        Size = UDim2.fromScale(1, 1),
        ImageColor3 = Color3.fromRGB(144, 113, 0),
        TileSize = UDim2.fromOffset(6, 6),
        ScaleType = u5.ScaleType.Tile
    }, {
        Gradient = u2.createElement("UIGradient", {
            Rotation = 90,
            Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
        })
    });
    v42.Glow = u2.createElement("Frame", {
        BorderSizePixel = 0,
        BackgroundTransparency = u3.MAIN_MENU and 1 or 0,
        BackgroundColor3 = Color3.new(1, 1, 1),
        BorderColor3 = Color3.new(),
        Size = UDim2.fromScale(1, 1)
    }, {
        Gradient = u2.createElement("UIGradient", {
            Rotation = 90,
            Color = ColorSequence.new({
                ColorSequenceKeypoint.new(0, Color3.fromRGB(97, 59, 2)),
                ColorSequenceKeypoint.new(0.778333, Color3.fromRGB(133, 88, 22)),
                ColorSequenceKeypoint.new(0.951667, Color3.fromRGB(204, 139, 46)),
                ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 218, 141))
            }),
            Transparency = NumberSequence.new({
                NumberSequenceKeypoint.new(0, 1),
                NumberSequenceKeypoint.new(0.531322, 0.79375),
                NumberSequenceKeypoint.new(0.824826, 0.4375),
                NumberSequenceKeypoint.new(1, 0)
            })
        })
    });
    local l__createElement__12 = u2.createElement;
    local v44 = "Frame";
    local v45 = {
        BackgroundTransparency = 1,
        ZIndex = 3,
        Size = UDim2.fromScale(0, 1),
        Position = UDim2.fromScale(0.5, 1),
        AnchorPoint = Vector2.new(0.5, 1)
    };
    local v46 = {
        Aspect = u2.createElement("UIAspectRatioConstraint", {
            AspectRatio = 12,
            AspectType = u5.AspectType.ScaleWithParentSize,
            DominantAxis = u5.DominantAxis.Height
        })
    };
    local l__createElement__13 = u2.createElement;
    local v47 = "TextLabel";
    local v50 = {
        BackgroundTransparency = 1,
        TextScaled = true,
        AnchorPoint = Vector2.new(1, 0),
        Size = l__props__6.ExpandedTween:Map(function(p48) --[[ Line: 278 ]]
            return UDim2.fromScale(0.5, 0.153):Lerp(UDim2.fromScale(0.5, 0.2), p48);
        end),
        Position = l__props__6.ExpandedTween:Map(function(p49) --[[ Line: 281 ]]
            return UDim2.fromScale(0.99, 0.875):Lerp(UDim2.fromScale(0.9, 0.375), p49);
        end),
        Text = l__props__6.MoneyBinding,
        TextColor3 = Color3.new(0, 0, 0),
        FontFace = u13,
        TextXAlignment = u5.TextXAlignment.Right
    };
    local v51 = {};
    local v53 = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        Size = UDim2.fromScale(1, 1),
        Position = UDim2.fromOffset(0, -1),
        Text = l__props__6.MoneyBinding,
        TextColor3 = l__props__6.LogoTween:Map(function(p52) --[[ Line: 295 ]]
            return Color3.fromRGB(255, 194, 89):Lerp(Color3.new(1, 1, 1), p52);
        end),
        FontFace = u13,
        TextXAlignment = u5.TextXAlignment.Right
    });
    local v54 = not l__Gamepad__9;
    if v54 then
        v54 = u2.createElement(u11, {
            Name = "+",
            SizeY = 0.9,
            ZIndex = 2,
            Size = UDim2.fromScale(1, 1),
            Position = UDim2.fromScale(1.015, 0),
            SizeConstraint = u5.SizeConstraint.RelativeYY,
            Ignore = l__PopupActive__8,
            Callback = function() --[[ Name: Callback, Line 310 ]]
                -- upvalues: u8 (ref), u5 (ref)
                u8:Open("Buy Currency", nil, {
                    { "Close", function() --[[ Line: 312 ]]
                            -- upvalues: u8 (ref)
                            u8:Close();
                        end }
                }, u5.PopupType.Shop);
            end
        });
    end;
    v51[1], v51[2] = v53, v54;
    v46.Money = l__createElement__13(v47, v50, v51);
    v46.Exp = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        RichText = true,
        AnchorPoint = Vector2.new(1, 1),
        Size = l__props__6.ExpandedTween:Map(function(p55) --[[ Line: 322 ]]
            return UDim2.fromScale(0.5, 0.125):Lerp(UDim2.fromScale(0.5, 0.2), p55);
        end),
        Position = l__props__6.ExpandedTween:Map(function(p56) --[[ Line: 325 ]]
            return UDim2.fromScale(0.99, 0.875):Lerp(UDim2.fromScale(0.9, 0.375), p56);
        end),
        Text = p33.ExpBinding,
        TextColor3 = Color3.new(0, 0, 0),
        FontFace = u14,
        TextXAlignment = u5.TextXAlignment.Right
    }, { u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            RichText = true,
            Size = UDim2.fromScale(1, 1),
            Position = UDim2.fromOffset(0, -1),
            Text = p33.ExpBinding,
            TextColor3 = l__props__6.LogoTween:Map(function(p57) --[[ Line: 340 ]]
                return Color3.fromRGB(255, 194, 89):Lerp(Color3.new(1, 1, 1), p57);
            end),
            FontFace = u14,
            TextXAlignment = u5.TextXAlignment.Right
        }) });
    local v58;
    if l__CHEATS_ENABLED__10 then
        v58 = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "CHEATS ARE ENABLED",
            TextScaled = true,
            AnchorPoint = Vector2.new(1, 1),
            Size = l__props__6.ExpandedTween:Map(function(p59) --[[ Line: 353 ]]
                return UDim2.fromScale(0.5, 0.125):Lerp(UDim2.fromScale(0.5, 0.2), p59);
            end),
            Position = l__props__6.ExpandedTween:Map(function(p60) --[[ Line: 356 ]]
                return UDim2.fromScale(5, 0.875):Lerp(UDim2.fromScale(0.75, 0.375), p60);
            end),
            TextColor3 = Color3.new(0, 0, 0),
            FontFace = u13,
            TextXAlignment = u5.TextXAlignment.Right
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "CHEATS ARE ENABLED",
                TextScaled = true,
                Size = UDim2.fromScale(1, 1),
                Position = UDim2.fromOffset(0, -1),
                TextColor3 = l__props__6.LogoTween:Map(function(p61) --[[ Line: 370 ]]
                    return Color3.fromRGB(255, 194, 89):Lerp(Color3.new(1, 0, 0), p61);
                end),
                FontFace = u13,
                TextXAlignment = u5.TextXAlignment.Right
            }) });
    else
        v58 = l__CHEATS_ENABLED__10;
    end;
    v46.Warn1 = v58;
    if l__CHEATS_ENABLED__10 then
        l__CHEATS_ENABLED__10 = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "PROGRESS WILL NOT SAVE",
            TextScaled = true,
            AnchorPoint = Vector2.new(1, 0),
            Size = l__props__6.ExpandedTween:Map(function(p62) --[[ Line: 381 ]]
                return UDim2.fromScale(0.5, 0.153):Lerp(UDim2.fromScale(0.5, 0.2), p62);
            end),
            Position = l__props__6.ExpandedTween:Map(function(p63) --[[ Line: 384 ]]
                return UDim2.fromScale(5, 0.875):Lerp(UDim2.fromScale(0.75, 0.375), p63);
            end),
            TextColor3 = Color3.new(0, 0, 0),
            FontFace = u14,
            TextXAlignment = u5.TextXAlignment.Right
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "PROGRESS WILL NOT SAVE",
                TextScaled = true,
                Size = UDim2.fromScale(1, 1),
                Position = UDim2.fromOffset(0, -1),
                TextColor3 = l__props__6.LogoTween:Map(function(p64) --[[ Line: 398 ]]
                    return Color3.fromRGB(255, 194, 89):Lerp(Color3.new(1, 1, 1), p64);
                end),
                FontFace = u14,
                TextXAlignment = u5.TextXAlignment.Right
            }) });
    end;
    v46.Warn2 = l__CHEATS_ENABLED__10;
    v46.Icon = u2.createElement("ImageLabel", {
        BackgroundTransparency = 1,
        Image = "rbxassetid://13866506142",
        Size = UDim2.fromScale(1.8, 0.5),
        Position = UDim2.fromScale(0.1, 0.375),
        AnchorPoint = Vector2.new(0, 0.5),
        SizeConstraint = u5.SizeConstraint.RelativeYY,
        ImageColor3 = Color3.new()
    }, { u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://13866506142",
            Size = UDim2.fromScale(1, 1),
            Position = UDim2.fromOffset(0, -1),
            ImageColor3 = l__props__6.LogoTween:Map(function(p65) --[[ Line: 421 ]]
                return Color3.fromRGB(255, 194, 89):Lerp(Color3.new(1, 1, 1), p65);
            end)
        }) });
    v46.Buttons = u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Position = UDim2.fromScale(0.1, 0.75),
        Size = UDim2.fromScale(0.8, 0.25)
    }, {
        Grid = u2.createElement("UIGridLayout", {
            CellPadding = UDim2.fromScale(0.005, 0),
            CellSize = UDim2.fromScale(1 / #l__Pages__7 - 0.005, 1),
            FillDirection = u5.FillDirection.Horizontal,
            HorizontalAlignment = u5.HorizontalAlignment.Center,
            SortOrder = u5.SortOrder.LayoutOrder
        }),
        u2.createFragment(v34)
    });
    local v66;
    if l__Gamepad__9 then
        v66 = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(1, 0),
            Position = UDim2.fromScale(0.08, 0.75),
            Size = UDim2.new(0.25, 0, 0.25, 0),
            SizeConstraint = u5.SizeConstraint.RelativeYY,
            Image = l__UserInputService__2:GetImageForKeyCode(u5.KeyCode.ButtonL1),
            ScaleType = u5.ScaleType.Fit
        });
    else
        v66 = l__Gamepad__9;
    end;
    if l__Gamepad__9 then
        l__Gamepad__9 = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.fromScale(0.92, 0.75),
            Size = UDim2.new(0.25, 0, 0.25, 0),
            SizeConstraint = u5.SizeConstraint.RelativeYY,
            Image = l__UserInputService__2:GetImageForKeyCode(u5.KeyCode.ButtonR1),
            ScaleType = u5.ScaleType.Fit
        });
    end;
    v46[1], v46[2], v46[3] = v66, l__Gamepad__9, v37;
    v42.Center = l__createElement__12(v44, v45, v46);
    return l__createFragment__11(v42);
end;
return v12;