-- Services.InterfaceService.MenuInterface.MenuPlayersComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Roact", "server", "network");
local u5 = v1("ClientService");
local u6 = v1("SoundService");
local u7 = v1("PopupInterface");
local u8 = v1("MenuButtonComponent");
local u9 = v1("GameShellProxyScroller");
local u10 = v1("MenuOptionsSliderComponent");
local u11 = v1("HUDInterface");
local l__Players__1 = game:GetService("Players");
local v12 = u2.Component:extend("MenuPlayers");
local u13 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u14 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local l__LocalPlayer__2 = l__Players__1.LocalPlayer;
function v12.init(_, _) --[[ Line: 24 ]]
    -- upvalues: u6 (copy)
    u6:CreateSound("Button", nil, true, "UISounds", "SettingsOpen").Destroy(10);
end;
function v12.render(p15) --[[ Line: 29 ]]
    -- upvalues: u5 (copy), u3 (copy), u2 (copy), u13 (copy), u11 (copy), l__LocalPlayer__2 (copy), u10 (copy), u8 (copy), u7 (copy), u4 (copy), u14 (copy), u9 (copy)
    local l__props__3 = p15.props;
    local _ = p15.state;
    local _ = p15.Landing;
    local l__Admin__4 = u5.LocalClient.Admin;
    local l__PopupActive__5 = l__props__3.PopupActive;
    local v16 = {};
    local l__IS_PVP__6 = u3.IS_PVP;
    if l__IS_PVP__6 then
        v16[1] = {
            Type = "Header",
            Team = "Blue",
            Color = Color3.fromRGB(52, 133, 255)
        };
        for _, v17 in u5:GetClients() do
            if v17.Squad == "Blue" then
                v16[#v16 + 1] = {
                    Type = "Player",
                    Client = v17
                };
            end;
        end;
        v16[#v16 + 1] = {
            Type = "Header",
            Team = "Red",
            Color = Color3.fromRGB(255, 10, 14)
        };
        for _, v18 in u5:GetClients() do
            if v18.Squad == "Red" then
                v16[#v16 + 1] = {
                    Type = "Player",
                    Client = v18
                };
            end;
        end;
    else
        for _, v19 in u5:GetClients() do
            v16[#v16 + 1] = {
                Type = "Player",
                Client = v19
            };
        end;
    end;
    local v20 = math.max(12, #v16);
    local v21 = 1 / v20;
    local v22 = {
        Grid = u2.createElement("UIGridLayout", {
            CellPadding = UDim2.fromScale(0, v21 * 0.2),
            CellSize = UDim2.fromScale(0.98, v21 * 0.8),
            FillDirection = Enum.FillDirection.Vertical,
            HorizontalAlignment = Enum.HorizontalAlignment.Left,
            SortOrder = Enum.SortOrder.LayoutOrder,
            StartCorner = Enum.StartCorner.TopLeft,
            VerticalAlignment = Enum.VerticalAlignment.Top
        })
    };
    local function v26(p23, p24, p25) --[[ Line: 88 ]]
        -- upvalues: u2 (ref), u13 (ref), u11 (ref)
        return u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 1,
            LayoutOrder = p25
        }, {
            u2.createElement("ImageLabel", {
                Image = "rbxassetid://13867926930",
                BackgroundTransparency = 1,
                ImageTransparency = 0.85,
                BorderSizePixel = 0,
                TileSize = UDim2.fromOffset(64, 64),
                ScaleType = Enum.ScaleType.Tile,
                ImageColor3 = p24,
                Size = UDim2.new(1, -2, 1, -2),
                Position = UDim2.fromOffset(1, 1)
            }, {
                u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0, 4)
                }),
                Stroke = u2.createElement("UIStroke", {
                    Thickness = 1,
                    ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                    Color = p24,
                    LineJoinMode = Enum.LineJoinMode.Round
                })
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.6),
                Position = UDim2.fromScale(0.02, 0.2),
                Text = p23:upper(),
                TextColor3 = p24,
                FontFace = u13,
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(0.98, 0.6),
                Position = UDim2.fromScale(0, 0.2),
                Text = tostring(u11[p23 .. "Wins"] or 0),
                TextColor3 = p24,
                FontFace = u13,
                TextXAlignment = Enum.TextXAlignment.Right
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "KILLS",
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.6),
                Position = UDim2.fromScale(0.2, 0.2),
                TextColor3 = p24,
                FontFace = u13,
                AnchorPoint = Vector2.new(0.5, 0),
                TextXAlignment = Enum.TextXAlignment.Center
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "DEATHS",
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.6),
                Position = UDim2.fromScale(0.3, 0.2),
                TextColor3 = p24,
                FontFace = u13,
                AnchorPoint = Vector2.new(0.5, 0),
                TextXAlignment = Enum.TextXAlignment.Center
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "ASSISTS",
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.6),
                Position = UDim2.fromScale(0.4, 0.2),
                TextColor3 = p24,
                FontFace = u13,
                AnchorPoint = Vector2.new(0.5, 0),
                TextXAlignment = Enum.TextXAlignment.Center
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "KDR",
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.6),
                Position = UDim2.fromScale(0.5, 0.2),
                TextColor3 = p24,
                FontFace = u13,
                AnchorPoint = Vector2.new(0.5, 0),
                TextXAlignment = Enum.TextXAlignment.Center
            })
        });
    end;
    local function v38(u27, p28, p29) --[[ Line: 182 ]]
        -- upvalues: l__IS_PVP__6 (copy), u2 (ref), u13 (ref), l__LocalPlayer__2 (ref), u10 (ref), l__PopupActive__5 (copy), l__Admin__4 (copy), u8 (ref), u7 (ref), u4 (ref), u14 (ref)
        local v30;
        if l__IS_PVP__6 then
            v30 = {};
            local v31 = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.6),
                Position = UDim2.fromScale(0.2, 0.2),
                Text = p28.Kills,
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u13,
                AnchorPoint = Vector2.new(0.5, 0),
                TextXAlignment = Enum.TextXAlignment.Center
            });
            local v32 = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.6),
                Position = UDim2.fromScale(0.3, 0.2),
                Text = p28.Deaths,
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u13,
                AnchorPoint = Vector2.new(0.5, 0),
                TextXAlignment = Enum.TextXAlignment.Center
            });
            local v33 = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.6),
                Position = UDim2.fromScale(0.4, 0.2),
                Text = p28.Assists,
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u13,
                AnchorPoint = Vector2.new(0.5, 0),
                TextXAlignment = Enum.TextXAlignment.Center
            });
            local l__createElement__7 = u2.createElement;
            local v34 = {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.6),
                Position = UDim2.fromScale(0.5, 0.2)
            };
            local v35 = p28.Kills / math.max(1, p28.Deaths) * 100;
            v34.Text = math.floor(v35) / 100;
            v34.TextColor3 = Color3.new(1, 1, 1);
            v34.FontFace = u13;
            v34.AnchorPoint = Vector2.new(0.5, 0);
            v34.TextXAlignment = Enum.TextXAlignment.Center;
            v30[1], v30[2], v30[3], v30[4] = v31, v32, v33, l__createElement__7("TextLabel", v34);
        else
            v30 = {};
        end;
        local u36 = u27:FindFirstChildWhichIsA("AudioDeviceInput");
        if u36 and u27 ~= l__LocalPlayer__2 then
            v30[#v30 + 1] = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(0.5, 1),
                Position = UDim2.fromScale(0.495, 0)
            }, { u2.createElement(u10, {
                    Mode = "Callback",
                    Min = 0,
                    Max = 3,
                    Setting = u36.Volume,
                    Callback = function(p37) --[[ Name: Callback, Line 245 ]]
                        -- upvalues: u36 (copy)
                        u36.Volume = p37;
                    end,
                    Ignore = l__PopupActive__5
                }) });
            v30[#v30 + 1] = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://82334723457307",
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                Size = UDim2.new(0.5, 0, 0.5, 0),
                AnchorPoint = Vector2.new(1, 0.5),
                Position = UDim2.new(0.88, 0, 0.5, 0)
            });
        end;
        if l__Admin__4 and u27 ~= l__LocalPlayer__2 then
            v30[#v30 + 1] = u2.createElement(u8, {
                Name = "Kick",
                Activated = false,
                Ignore = l__PopupActive__5,
                Size = UDim2.fromScale(0.05, 0.6),
                Position = UDim2.fromScale(0.6, 0.5),
                AnchorPoint = Vector2.new(0, 0.5),
                Callback = function() --[[ Name: Callback, Line 269 ]]
                    -- upvalues: u7 (ref), u27 (copy), u4 (ref)
                    u7:Open("Kick player", "Are you sure you want to kick:\n\n" .. u27.DisplayName .. "\n(@" .. u27.Name .. ")", {
                        { "Kick", function() --[[ Line: 271 ]]
                                -- upvalues: u4 (ref), u27 (ref), u7 (ref)
                                u4:FireServer("KickPlayer", u27.UserId);
                                u7:Close();
                            end },
                        { "Cancel", function() --[[ Line: 275 ]]
                                -- upvalues: u7 (ref)
                                u7:Close();
                            end }
                    });
                end
            });
            v30[#v30 + 1] = u2.createElement(u8, {
                Name = "Ban",
                Activated = false,
                Ignore = l__PopupActive__5,
                Size = UDim2.fromScale(0.05, 0.6),
                Position = UDim2.fromScale(0.657, 0.5),
                AnchorPoint = Vector2.new(0, 0.5),
                Callback = function() --[[ Name: Callback, Line 288 ]]
                    -- upvalues: u7 (ref), u27 (copy), u4 (ref)
                    u7:Open("Ban player", "Are you sure you want to ban:\n\n" .. u27.DisplayName .. "\n(@" .. u27.Name .. ")", {
                        { "Ban", function() --[[ Line: 290 ]]
                                -- upvalues: u4 (ref), u27 (ref), u7 (ref)
                                u4:FireServer("BanPlayer", u27.UserId);
                                u7:Close();
                            end },
                        { "Cancel", function() --[[ Line: 294 ]]
                                -- upvalues: u7 (ref)
                                u7:Close();
                            end }
                    });
                end
            });
        end;
        return u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.5,
            LayoutOrder = p29,
            BackgroundColor3 = Color3.new()
        }, {
            u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                Image = "https://www.roblox.com/headshot-thumbnail/image?userId=" .. u27.UserId .. "&width=420&height=420&format=png",
                Size = UDim2.new(0.8, 0, 0.8, 0),
                AnchorPoint = Vector2.new(0, 0.5),
                Position = UDim2.new(0.005, 0, 0.5, 0)
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.4),
                Position = UDim2.fromScale(0.04, 0.2),
                Text = u27.DisplayName,
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u13,
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.25),
                Position = UDim2.fromScale(0.04, 0.55),
                Text = "@" .. u27.Name,
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u14,
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }),
            u2.createFragment(v30)
        });
    end;
    for v39, v40 in v16 do
        if v40.Type == "Player" then
            v22[v39] = v38(v40.Client.Owner, v40.Client, v39);
        else
            v22[v39] = v26(v40.Team, v40.Color, v39);
        end;
    end;
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        AnchorPoint = Vector2.new(0.5, 0),
        Size = UDim2.fromScale(0, 0.85),
        Position = UDim2.fromScale(0.5, 0.05)
    }, { u2.createElement("UIAspectRatioConstraint", {
            AspectRatio = 2,
            AspectType = Enum.AspectType.ScaleWithParentSize,
            DominantAxis = Enum.DominantAxis.Height
        }), u2.createElement(u9, {
            BackgroundTransparency = 1,
            Position = UDim2.fromScale(0, 0),
            Size = UDim2.new(1, 0, 1, 0),
            Ignore = l__PopupActive__5,
            CanvasSize = v20 / 12,
            Content = v22
        }) });
end;
return v12;