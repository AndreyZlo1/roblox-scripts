-- Services.InterfaceService.MenuInterface.MenuArmouryPresetComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Roact", "network", "server");
local u5 = v1("GameShellProxyButton");
local u6 = v1("formatNumber");
local u7 = v1("StatsService");
local u8 = v1("InputService");
v1("WorldService");
local u9 = v1("PopupInterface");
local u10 = v1("Stores");
local u11 = v1("StoreInventoryComponent");
local u12 = v1("MenuButtonComponent");
local v13 = u2.Component:extend("MenuArmouryPreset");
local u14 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u15 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
function v13._getItemCost(p16, p17) --[[ Line: 22 ]]
    for _, v18 in p16.Store.Categories do
        for _, v19 in v18.Items do
            if (v19._item or v19.Item) == p17 then
                return v19.Price or 0;
            end;
        end;
    end;
    return 0;
end;
function v13._calculateCost(p20, p21) --[[ Line: 35 ]]
    local v22 = 0;
    for v23, v24 in p21 do
        v22 = v22 + p20:_getItemCost(v23) * v24;
    end;
    return v22;
end;
function v13.init(p25, _) --[[ Line: 44 ]]
    -- upvalues: u7 (copy), u10 (copy), u4 (copy), u2 (copy)
    local l__ArmoryPresets__1 = u7.ArmoryPresets;
    p25.Store = u10[u4.GLOBAL_STORE or "Ronograd_FOB"];
    local v26, v27 = u2.createBinding(l__ArmoryPresets__1.Active);
    p25.Checked = v26;
    p25.UpdateChecked = v27;
    local v28, v29 = u2.createBinding(false);
    p25.CheckedHover = v28;
    p25.UpdateCheckedHover = v29;
    p25.Presets = l__ArmoryPresets__1.Presets;
    p25:setState({
        Editing = false,
        Changing = false,
        Selected = l__ArmoryPresets__1.Selected
    });
end;
function v13.willUnmount(_) --[[ Line: 59 ]]
    -- upvalues: u8 (copy)
    u8.UseVirtualCursor = false;
end;
function v13.render(u30) --[[ Line: 63 ]]
    -- upvalues: u6 (copy), u2 (copy), u14 (copy), u15 (copy), u7 (copy), u5 (copy), u3 (copy), u12 (copy), u8 (copy), u11 (copy), u9 (copy)
    local l__state__2 = u30.state;
    local v31 = u30.Presets[l__state__2.Selected];
    local u32 = v31[2];
    local v33 = u30:_calculateCost(u32);
    local v34 = v33 == 0 and "FREE" or u6(v33);
    local l__props__3 = u30.props;
    local l__PopupActive__4 = l__props__3.PopupActive;
    local l__createFragment__5 = u2.createFragment;
    local v47 = {
        Glow = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.85,
            ZIndex = 2,
            Size = UDim2.fromScale(0.9, 0.08),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            Position = UDim2.fromScale(0.5, 1),
            AnchorPoint = Vector2.new(0.5, 1),
            BackgroundColor3 = l__props__3.Transition:Map(function(p35) --[[ Line: 82 ]]
                return Color3.new(1, 1, 1):Lerp(Color3.fromRGB(255, 194, 89), p35);
            end)
        }, {
            Gradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
            })
        }),
        Menu = u2.createElement("Frame", {
            ZIndex = 3,
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(0, 0, 0),
            Size = UDim2.fromScale(0.8, 0.1),
            AnchorPoint = Vector2.new(0.5, 0),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            Position = UDim2.fromScale(0.5, 0.875)
        }, {
            u2.createElement("UIPadding", {
                PaddingBottom = UDim.new(0.05, 0),
                PaddingTop = UDim.new(0.05, 0)
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "DEPLOY WITH KIT",
                TextScaled = true,
                Size = UDim2.fromScale(0.25, 0.25),
                Position = UDim2.fromScale(0.5, 0.15),
                TextColor3 = Color3.new(0, 0, 0),
                FontFace = u14,
                TextXAlignment = Enum.TextXAlignment.Center
            }, { u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "DEPLOY WITH KIT",
                    TextScaled = true,
                    Size = UDim2.fromScale(1, 1),
                    Position = UDim2.fromOffset(0, -1),
                    TextColor3 = Color3.new(1, 1, 1),
                    FontFace = u14,
                    TextXAlignment = Enum.TextXAlignment.Center
                }) }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "ARMORY KIT",
                TextScaled = true,
                Size = UDim2.fromScale(0.25, 0.25),
                Position = UDim2.fromScale(0, 0.15),
                TextColor3 = Color3.new(0, 0, 0),
                FontFace = u14,
                TextXAlignment = Enum.TextXAlignment.Center,
                TextTransparency = u30.Checked:map(function(p36) --[[ Line: 149 ]]
                    return p36 and 0 or 0.5;
                end)
            }, { u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "ARMORY KIT",
                    TextScaled = true,
                    Size = UDim2.fromScale(1, 1),
                    Position = UDim2.fromOffset(0, -1),
                    TextColor3 = Color3.new(1, 1, 1),
                    FontFace = u14,
                    TextXAlignment = Enum.TextXAlignment.Center,
                    TextTransparency = u30.Checked:map(function(p37) --[[ Line: 162 ]]
                        return p37 and 0 or 0.5;
                    end)
                }) }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "DEPLOYMENT COST",
                TextScaled = true,
                Size = UDim2.fromScale(0.25, 0.25),
                Position = UDim2.fromScale(0.75, 0.15),
                TextColor3 = Color3.new(0, 0, 0),
                FontFace = u14,
                TextXAlignment = Enum.TextXAlignment.Center,
                TextTransparency = u30.Checked:map(function(p38) --[[ Line: 176 ]]
                    return p38 and 0 or 0.5;
                end)
            }, { u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "DEPLOYMENT COST",
                    TextScaled = true,
                    Size = UDim2.fromScale(1, 1),
                    Position = UDim2.fromOffset(0, -1),
                    TextColor3 = Color3.new(1, 1, 1),
                    FontFace = u14,
                    TextXAlignment = Enum.TextXAlignment.Center,
                    TextTransparency = u30.Checked:map(function(p39) --[[ Line: 189 ]]
                        return p39 and 0 or 0.5;
                    end)
                }) }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(0.25, 0.45),
                Position = UDim2.fromScale(0, 0.4),
                Text = v31[1]:upper(),
                TextColor3 = Color3.new(0, 0, 0),
                FontFace = u15,
                TextXAlignment = Enum.TextXAlignment.Center,
                TextTransparency = u30.Checked:map(function(p40) --[[ Line: 203 ]]
                    return p40 and 0 or 0.5;
                end)
            }, { u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    Size = UDim2.fromScale(1, 1),
                    Position = UDim2.fromOffset(0, -1),
                    Text = v31[1]:upper(),
                    TextColor3 = Color3.new(1, 1, 1),
                    FontFace = u15,
                    TextXAlignment = Enum.TextXAlignment.Center,
                    TextTransparency = u30.Checked:map(function(p41) --[[ Line: 216 ]]
                        return p41 and 0 or 0.5;
                    end)
                }) }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(0.25, 0.52),
                Position = UDim2.fromScale(0.75, 0.38),
                Text = v34,
                TextColor3 = Color3.new(0, 0, 0),
                FontFace = u15,
                TextXAlignment = Enum.TextXAlignment.Center,
                TextTransparency = u30.Checked:map(function(p42) --[[ Line: 230 ]]
                    return p42 and 0 or 0.5;
                end)
            }, { u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    Size = UDim2.fromScale(1, 1),
                    Position = UDim2.fromOffset(0, -1),
                    Text = v34,
                    TextColor3 = v33 <= u7.Money and Color3.fromRGB(117, 255, 107) or Color3.fromRGB(255, 107, 107),
                    FontFace = u15,
                    TextXAlignment = Enum.TextXAlignment.Center,
                    TextTransparency = u30.Checked:map(function(p43) --[[ Line: 243 ]]
                        return p43 and 0 or 0.5;
                    end)
                }) }),
            u2.createElement("Frame", {
                BorderSizePixel = 2,
                BackgroundColor3 = Color3.new(),
                BorderColor3 = u30.CheckedHover:map(function(p44) --[[ Line: 251 ]]
                    return p44 and Color3.fromRGB(255, 194, 89) or Color3.new(1, 1, 1);
                end),
                Size = UDim2.fromScale(0.33, 0.33),
                AnchorPoint = Vector2.new(0.5, 0),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                Position = UDim2.fromScale(0.625, 0.48)
            }, { u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "✓",
                    TextScaled = true,
                    Size = UDim2.fromScale(1, 1),
                    TextColor3 = u30.CheckedHover:map(function(p45) --[[ Line: 262 ]]
                        return p45 and Color3.fromRGB(255, 194, 89) or Color3.new(1, 1, 1);
                    end),
                    Visible = u30.Checked,
                    FontFace = u14,
                    TextXAlignment = Enum.TextXAlignment.Center
                }), u2.createElement(u5, {
                    Image = "",
                    BackgroundTransparency = 1,
                    SoundKit = "MainMenu",
                    Ignore = l__PopupActive__4,
                    Size = UDim2.fromScale(1, 1),
                    MouseUp = function() --[[ Name: MouseUp, Line 278 ]]
                        -- upvalues: u30 (copy), u7 (ref), u3 (ref)
                        local v46 = not u30.Checked:getValue();
                        u30.UpdateChecked(v46);
                        u7.ArmoryPresets.Active = v46;
                        u3:FireServer("ArmoryActive", v46);
                    end,
                    MouseEnter = function() --[[ Name: MouseEnter, Line 284 ]]
                        -- upvalues: u30 (copy)
                        u30.UpdateCheckedHover(true);
                    end,
                    MouseLeave = function() --[[ Name: MouseLeave, Line 287 ]]
                        -- upvalues: u30 (copy)
                        u30.UpdateCheckedHover(false);
                    end
                }) }),
            u2.createElement(u12, {
                Name = "Edit",
                Size = UDim2.fromScale(0.2, 0.33),
                AnchorPoint = Vector2.new(0.5, 0),
                Position = UDim2.fromScale(0.375, 0.52),
                Activated = l__state__2.Editing,
                Ignore = l__PopupActive__4,
                Callback = function() --[[ Name: Callback, Line 299 ]]
                    -- upvalues: u30 (copy), l__state__2 (ref), u8 (ref), l__props__3 (copy)
                    u30:setState({
                        Changing = false,
                        Editing = not l__state__2.Editing
                    });
                    l__state__2 = u30.state;
                    u8.UseVirtualCursor = l__state__2.Editing or l__state__2.Changing;
                    l__props__3.Transition:SetGoal((l__state__2.Editing or l__state__2.Changing) and 1 or 0);
                end
            }),
            u2.createElement(u12, {
                Name = "Change",
                Size = UDim2.fromScale(0.2, 0.33),
                AnchorPoint = Vector2.new(0.5, 1),
                Position = UDim2.fromScale(0.375, 0.48),
                Activated = u30.state.Changing,
                Ignore = l__PopupActive__4,
                Callback = function() --[[ Name: Callback, Line 317 ]]
                    -- upvalues: u30 (copy), l__state__2 (ref), u8 (ref), l__props__3 (copy)
                    u30:setState({
                        Editing = false,
                        Changing = not l__state__2.Changing
                    });
                    l__state__2 = u30.state;
                    u8.UseVirtualCursor = l__state__2.Editing or l__state__2.Changing;
                    l__props__3.Transition:SetGoal((l__state__2.Editing or l__state__2.Changing) and 1 or 0);
                end
            })
        })
    };
    local l__createElement__6 = u2.createElement;
    local v48 = "Frame";
    local v50 = {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(0.6, 0.6),
        Position = l__props__3.Transition:Map(function(p49) --[[ Line: 332 ]]
            return UDim2.fromScale(0.5, 0.55 - p49 * 0.1);
        end),
        AnchorPoint = Vector2.new(0.5, 0.5),
        SizeConstraint = Enum.SizeConstraint.RelativeYY
    };
    local v51 = {};
    local l__Editing__7 = l__state__2.Editing;
    if l__Editing__7 then
        l__Editing__7 = u2.createElement(u11, {
            CellSize = 0.035,
            Payload = {
                Store = u30.Store
            },
            PopupActive = l__PopupActive__4,
            Wishlist = u32,
            ChangeQuantity = function(p52, p53) --[[ Name: ChangeQuantity, Line 344 ]]
                -- upvalues: u32 (copy), u3 (ref), u30 (copy)
                if not u32[p52] then
                    u32[p52] = 0;
                end;
                u32[p52] = math.clamp(u32[p52] + p53, 0, 100);
                if u32[p52] <= 0 then
                    u32[p52] = nil;
                end;
                u3:FireServer("ArmoryItem", p52, u32[p52]);
                u30:setState({});
            end
        });
    end;
    local l__Changing__8 = l__state__2.Changing;
    if l__Changing__8 then
        l__Changing__8 = u2.createElement(u11, {
            CellSize = 0.035,
            PopupActive = l__PopupActive__4,
            ArmoryPresets = u30.Presets,
            NewPreset = function(p54) --[[ Name: NewPreset, Line 363 ]]
                -- upvalues: u30 (copy)
                u30.Presets[#u30.Presets + 1] = {
                    p54,
                    {}
                };
            end,
            ChangePreset = function(u55, p56) --[[ Name: ChangePreset, Line 366 ]]
                -- upvalues: u30 (copy), u9 (ref), u3 (ref), l__state__2 (ref), u7 (ref), l__props__3 (copy)
                if p56.X > 0.7 then
                    if #u30.Presets > 1 then
                        u9:Open("DELETE PRESET", "Are you sure you want to delete this preset?", {
                            { "Yes", function() --[[ Line: 370 ]]
                                    -- upvalues: u3 (ref), u55 (copy), u30 (ref), l__state__2 (ref), u7 (ref), u9 (ref)
                                    u3:FireServer("ArmoryRemove", u55);
                                    table.remove(u30.Presets, u55);
                                    if u55 <= l__state__2.Selected then
                                        u7.ArmoryPresets.Selected = math.clamp(u7.ArmoryPresets.Selected - 1, 1, #u30.Presets);
                                        u30:setState({
                                            Selected = u7.ArmoryPresets.Selected
                                        });
                                    end;
                                    u9:Close();
                                end },
                            { "Cancel", function() --[[ Line: 383 ]]
                                    -- upvalues: u9 (ref)
                                    u9:Close();
                                end }
                        });
                    else
                        u9:Open("FAILED TO DELETE", "You must have atleast one armory preset.", {
                            { "Close", function() --[[ Line: 389 ]]
                                    -- upvalues: u9 (ref)
                                    u9:Close();
                                end }
                        });
                    end;
                else
                    u3:FireServer("ArmorySelected", u55);
                    u7.ArmoryPresets.Selected = u55;
                    l__props__3.Transition:SetGoal(0);
                    u30:setState({
                        Changing = false,
                        Selected = u55
                    });
                end;
            end
        });
    end;
    v51[1], v51[2] = l__Editing__7, l__Changing__8;
    v47[1] = l__createElement__6(v48, v50, v51);
    return l__createFragment__5(v47);
end;
return v13;