-- Services.InterfaceService.MenuInterface.MenuLoadoutComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4, u5 = shared.import("require", "Roact", "asset", "network", "Enum");
local l__GuiService__1 = game:GetService("GuiService");
local l__HttpService__2 = game:GetService("HttpService");
local l__RunService__3 = game:GetService("RunService");
game:GetService("UserInputService");
local u6 = v1("MenuButtonComponent");
v1("GameShellProxyInput");
local u7 = v1("ClientService");
local u8 = v1("MenuLoadout3DViewer");
local u9 = v1("MenuLoadoutAttachmentListComponent");
local u10 = v1("MenuLoadoutAttachmentSelectionInfoComponent");
local u11 = v1("BaseComponent");
local u12 = v1("PopupInterface");
local u13 = v1("StatsService");
local u14 = v1("MenuLoadoutAttachmentHoverPanel");
local u15 = v1("RoactTween");
local u16 = v1("NotifyInterface");
local u17 = v1("MenuLoadoutPreviewOptionButton");
local v18 = v1("MenuLoadoutConstants");
local u19 = v1("MenuLoadoutPurchasePreviewComponent");
local u20 = v1("KeyComponent");
local u21 = v1("ControlInterface");
local u22 = v1("SoundService");
local u23 = v1("InputService");
local u24 = v1("skipLevel");
local u25 = v1("formatNumber");
local u26 = v1({ "FlashlightAttachmentReplicator", "LaserAttachmentReplicator", "StrobeAttachmentReplicator" });
local v27 = u2.Component:extend("MenuLoadout");
Font.fromId(12187375422, u5.FontWeight.Bold, u5.FontStyle.Normal);
local u28 = Font.fromId(12187375422, u5.FontWeight.Regular, u5.FontStyle.Normal);
local l__CurrentCamera__4 = workspace.CurrentCamera;
local l__SAVE_CONFIGS__5 = v18.SAVE_CONFIGS;
local l__BASE_KEEP_CHILDRENS__6 = v18.BASE_KEEP_CHILDRENS;
local l__VIEW_CONFIGS__7 = v18.VIEW_CONFIGS;
local l__HANDS_UP__8 = v18.HANDS_UP;
local function u32(p29) --[[ Line: 49 ]]
    -- upvalues: u11 (copy)
    local v30 = u11.new({ "Character", "Loadout" }, nil, nil, true);
    local v31 = {
        Name = p29,
        Tree = v30:Serialize(),
        WeaponBuilds = {}
    };
    v30:Destroy();
    return v31;
end;
local function u52(p33, p34, p35, p36) --[[ Line: 63 ]]
    -- upvalues: l__SAVE_CONFIGS__5 (copy)
    local l__PreviewingState__9 = p34.PreviewingState;
    if l__PreviewingState__9 then
        local l__FullName__10 = l__PreviewingState__9.FullName;
        local l__BeforeRoot__11 = l__PreviewingState__9.BeforeRoot;
        local v37 = p34.RootComponent:GetChild(table.unpack(l__FullName__10));
        if v37 then
            if not p33:IsComponentUnlocked(v37.Path, false) then
                local _, v38 = v37:GetMenuConfig();
                if not p35 or p35.Config == v38 then
                    local v39 = v37:GetFullName();
                    local l__ParentComponent__12 = v37.ParentComponent;
                    local l__ParentSubName__13 = v37.ParentSubName;
                    v37:Destroy();
                    local v40 = l__BeforeRoot__11:GetChild(table.unpack(v39));
                    if v40 then
                        v40:AssignParent(l__ParentComponent__12, l__ParentSubName__13);
                    end;
                    p34.PreviewingState = nil;
                    l__BeforeRoot__11:Destroy();
                    if not p36 then
                        p33.Loadouts[p33.ActiveLoadout].Tree = p34.RootComponent:Serialize();
                    end;
                    return;
                end;
            end;
            if v37.MetaData.Camo then
                local v41 = v37:GetCamoConfig(v37.MetaData.Camo);
                if v41 and (not p33:IsComponentUnlocked(v41.CamoPath, true) and (not p35 or p35.Config == v41)) then
                    local v42 = l__BeforeRoot__11:GetChild(table.unpack(v37:GetFullName()));
                    if v42 and v42.File == v37.File then
                        v37:EditMetaData({
                            Camo = v42.MetaData.Camo or false
                        });
                    else
                        v37:EditMetaData({
                            Camo = false
                        });
                    end;
                end;
            end;
            local v43 = v37:GetDescendants();
            for v44 = #v43, 1, -1 do
                local v45 = v43[v44];
                if v45.DoSave then
                    if v45.MetaData.Camo then
                        local v46 = v45:GetCamoConfig(v45.MetaData.Camo);
                        local v47 = v46 and (not p33:IsComponentUnlocked(v46.CamoPath, true) and (not p35 or p35.Config == v46)) and l__BeforeRoot__11:GetChild(table.unpack(v45:GetFullName()));
                        if v47 then
                            v45:EditMetaData({
                                Camo = v47.MetaData.Camo or false
                            });
                        end;
                    end;
                    if not p33:IsComponentUnlocked(v45.Path, false) then
                        local _, v48 = v45:GetMenuConfig();
                        if not p35 or p35.Config == v48 then
                            local v49 = v45:GetFullName();
                            local v50 = l__BeforeRoot__11:GetChild(table.unpack(v49));
                            if v50 and not v50.MetaData.Lerp then
                                p34.RootComponent:SetChildKeepChildren(v50.Path, {
                                    Camo = v50.MetaData.Camo
                                }, table.unpack(v49));
                            end;
                            v45:Destroy();
                        end;
                    end;
                end;
            end;
            local v51 = p33.Loadouts[p33.ActiveLoadout];
            if not p36 then
                v51.Tree = p34.RootComponent:Serialize();
            end;
            if not p35 then
                p34.PreviewingState = nil;
                l__BeforeRoot__11:Destroy();
                if l__SAVE_CONFIGS__5[v37.ParentSubName] then
                    v51.WeaponBuilds[v37.Path[#v37.Path]] = v37:Serialize();
                end;
            end;
        else
            p34.PreviewingState = nil;
        end;
    end;
end;
local function u57(p53, p54) --[[ Line: 196 ]]
    -- upvalues: u4 (copy)
    local v55;
    if p54.DoSave and p54.MetaData.Camo then
        local v56 = p54:GetCamoConfig(p54.MetaData.Camo);
        v55 = v56 and not p53:IsComponentUnlocked(v56.CamoPath, true) and true or false;
    else
        v55 = false;
    end;
    if v55 then
        p53:UnlockComponent(p54:GetCamoConfig(p54.MetaData.Camo).CamoPath);
    end;
    local l__Camo__14 = p54.MetaData.Camo;
    if l__Camo__14 then
        l__Camo__14 = p54:GetCamoConfig(p54.MetaData.Camo);
    end;
    if l__Camo__14 and p54.DoSave then
        u4:FireServer("SetComponentCamo", p53.ActiveLoadout, p54:GetFullName(), l__Camo__14.CamoPath);
    end;
end;
local function u79(p58, p59) --[[ Line: 208 ]]
    -- upvalues: u12 (copy), u22 (copy), u4 (copy), u52 (copy), u57 (copy), l__SAVE_CONFIGS__5 (copy)
    u12:SetLoading(true);
    u22:CreateSound("Button", nil, true, "UISounds", "LoadoutPurchaseStart").Destroy(2);
    local l__PreviewingState__15 = p59.PreviewingState;
    local l__FullName__16 = l__PreviewingState__15.FullName;
    local l__BeforeRoot__17 = l__PreviewingState__15.BeforeRoot;
    local v60 = p59.RootComponent:GetChild(table.unpack(l__FullName__16));
    local v61 = {};
    local v62 = {};
    local v63;
    if v60.DoSave then
        v63 = not p58:IsComponentUnlocked(v60.Path, false);
    else
        v63 = false;
    end;
    if v63 then
        table.insert(v61, v60.Path);
    end;
    local v64;
    if v60.DoSave and v60.MetaData.Camo then
        local v65 = v60:GetCamoConfig(v60.MetaData.Camo);
        v64 = v65 and not p58:IsComponentUnlocked(v65.CamoPath, true) and true or false;
    else
        v64 = false;
    end;
    if v64 then
        local l__CamoPath__18 = v60:GetCamoConfig(v60.MetaData.Camo).CamoPath;
        table.insert(v62, l__CamoPath__18);
    end;
    for _, v66 in v60:GetDescendants() do
        local v67;
        if v66.DoSave then
            v67 = not p58:IsComponentUnlocked(v66.Path, false);
        else
            v67 = false;
        end;
        if v67 then
            table.insert(v61, v66.Path);
        end;
        local v68;
        if v66.DoSave and v66.MetaData.Camo then
            local v69 = v66:GetCamoConfig(v66.MetaData.Camo);
            v68 = v69 and not p58:IsComponentUnlocked(v69.CamoPath, true) and true or false;
        else
            v68 = false;
        end;
        if v68 then
            local l__CamoPath__19 = v66:GetCamoConfig(v66.MetaData.Camo).CamoPath;
            table.insert(v62, l__CamoPath__19);
        end;
    end;
    if u4:InvokeServer("TryBuyComponents", v61, v62) then
        local v70;
        if v60.DoSave then
            v70 = not p58:IsComponentUnlocked(v60.Path, false);
        else
            v70 = false;
        end;
        if v70 then
            local _, v71 = v60:GetMenuConfig();
            p58:UnlockComponent(v71.Path);
        end;
        if v60.DoSave then
            u4:FireServer("ChangeBaseComponent", p58.ActiveLoadout, l__FullName__16, v60.Path);
            u57(p58, v60);
            local v72 = v60:GetDescendants();
            for v73 = 1, #v72 do
                local v74 = v72[v73];
                local v75;
                if v74.DoSave then
                    v75 = not p58:IsComponentUnlocked(v74.Path, false);
                else
                    v75 = false;
                end;
                if v75 then
                    local _, v76 = v74:GetMenuConfig();
                    p58:UnlockComponent(v76.Path);
                end;
                if v74.DoSave then
                    if v74.MetaData.Lerp then
                        u4:FireServer("SetComponentLerp", p58.ActiveLoadout, v74:GetFullName(), v74.MetaData.Lerp, v74.Path);
                    else
                        u4:FireServer("AddComponent", p58.ActiveLoadout, v74:GetFullName(), v74.Path);
                    end;
                end;
            end;
            for _, v77 in v72 do
                u57(p58, v77);
            end;
            p59.PreviewingState = nil;
            l__BeforeRoot__17:Destroy();
            local v78 = p58.Loadouts[p58.ActiveLoadout];
            v78.Tree = p59.RootComponent:Serialize();
            if l__SAVE_CONFIGS__5[v60.ParentSubName] then
                v78.WeaponBuilds[v60.Path[#v60.Path]] = v60:Serialize();
            end;
            u12:SetLoading(false);
            u22:CreateSound("Button", nil, true, "UISounds", "LoadoutPurchaseCompleted").Destroy(2);
        else
            local _, _ = v60:GetMenuConfig();
            u52(p58, p59);
            u12:SetLoading(false);
        end;
    else
        u12:SetLoading(false);
    end;
end;
local function u89(p80, p81, p82) --[[ Line: 294 ]]
    -- upvalues: u4 (copy), l__SAVE_CONFIGS__5 (copy)
    local l__RootComponent__20 = p81.RootComponent;
    local v83 = p80.Loadouts[p80.ActiveLoadout];
    local v84 = nil;
    local v85, v86 = l__RootComponent__20:GetChildren(table.unpack(p82));
    if v85 and v86 ~= 0 then
        for _, v87 in v85 do
            v84 = v84 or v87:GetBaseComponent(true);
            if p80:IsComponentUnlocked(v87.Path, false) then
                u4:FireServer("RemoveComponent", p80.ActiveLoadout, v87:GetFullName());
                local v88 = p81.PreviewingState and p81.PreviewingState.BeforeRoot:GetChild(table.unpack(v87:GetFullName()));
                if v88 then
                    v88:Destroy();
                end;
            end;
            v87:Destroy();
        end;
        v83.Tree = l__RootComponent__20:Serialize();
        if not p81.PreviewingState and l__SAVE_CONFIGS__5[v84.ParentSubName] then
            v83.WeaponBuilds[v84.Path[#v84.Path]] = v84:Serialize();
        end;
    end;
end;
local function u99(p90, p91, p92) --[[ Line: 328 ]]
    -- upvalues: l__SAVE_CONFIGS__5 (copy), u4 (copy)
    local l__RootComponent__21 = p91.RootComponent;
    local v93 = p90.Loadouts[p90.ActiveLoadout];
    local v94 = l__RootComponent__21:GetChild(table.unpack(p92));
    local v95 = p90:IsComponentUnlocked(v94.Path, false);
    local v96 = v94:GetBaseComponent(true);
    v94:Destroy();
    v93.Tree = l__RootComponent__21:Serialize();
    if not p91.PreviewingState and l__SAVE_CONFIGS__5[v96.ParentSubName] then
        v93.WeaponBuilds[v96.Path[#v96.Path]] = v96:Serialize();
    end;
    local v97 = table.clone(p92);
    table.remove(v97, #v97);
    p91:setState({
        ActivePath = v97
    });
    if v95 then
        u4:FireServer("RemoveComponent", p90.ActiveLoadout, p92);
        local v98 = p91.PreviewingState and p91.PreviewingState.BeforeRoot:GetChild(table.unpack(p92));
        if v98 then
            v98:Destroy();
        end;
    end;
end;
local function u115(u100, u101, u102, u103, p104) --[[ Line: 365 ]]
    -- upvalues: u16 (copy), u4 (copy), l__SAVE_CONFIGS__5 (copy), u11 (copy)
    local l__RootComponent__22 = u101.RootComponent;
    local u105 = u100.Loadouts[u100.ActiveLoadout];
    local u106 = p104:GetBaseComponent(true);
    local v107, v108 = p104:GetRootComponent():GetChild(u103[1]):IsUnderCategoryLimit(u102, l__RootComponent__22:GetChild(table.unpack(u103)));
    if v107 then
        local u109 = u100:IsComponentUnlocked(u102.Path, false);
        local function v112() --[[ Line: 387 ]]
            -- upvalues: l__RootComponent__22 (copy), u102 (copy), u103 (copy), u105 (copy), u109 (copy), u101 (copy), u4 (ref), u100 (copy), l__SAVE_CONFIGS__5 (ref), u106 (copy)
            local _, v110 = l__RootComponent__22:SetChildKeepChildren(u102.Path, nil, table.unpack(u103));
            if v110 then
                v110:Destroy();
            end;
            u105.Tree = l__RootComponent__22:Serialize();
            if u109 then
                if u101.PreviewingState then
                    if u101.PreviewingState.BeforeRoot:GetChildParent(table.unpack(u103)) then
                        local _, v111 = u101.PreviewingState.BeforeRoot:SetChildKeepChildren(u102.Path, nil, table.unpack(u103));
                        if v111 then
                            v111:Destroy();
                        end;
                    end;
                else
                    u4:FireServer("AddComponent", u100.ActiveLoadout, u103, u102.Path);
                end;
            end;
            if not u101.PreviewingState and l__SAVE_CONFIGS__5[u106.ParentSubName] then
                u105.WeaponBuilds[u106.Path[#u106.Path]] = u106:Serialize();
            end;
        end;
        if u109 then
            v112();
        else
            u101.PreviewingState = u101.PreviewingState or {
                FullName = u106:GetFullName(),
                BeforeRoot = u11.Deserialize(l__RootComponent__22:Serialize(), true)
            };
            v112();
            u101.CheckLevel(u102);
        end;
    else
        local v113 = {};
        if v108 then
            local v114 = { "Cannot Add", v108, Color3.new(1, 0, 0) };
            table.insert(v113, v114);
        end;
        u16:Notify(v113);
    end;
end;
local function u130(p116, p117, p118, p119, p120) --[[ Line: 427 ]]
    -- upvalues: u16 (copy)
    local l__RootComponent__23 = p117.RootComponent;
    local _ = p116.Loadouts[p116.ActiveLoadout];
    local v121 = p120:GetFullName();
    local v122, v123 = p120:GetRootComponent():GetChild(v121[1]):IsUnderCategoryLimit(p118);
    local v124, v125 = p120:HasEnoughSpace(p119[#p119], p118);
    if v122 and v124 then
        local v126 = l__RootComponent__23:AddChild(p118.Path, {
            Lerp = 0
        }, table.unpack(p119));
        p117._lastRailConfig = p118;
        p117.Viewer:SlideComponent(v126, true);
        return true;
    end;
    local v127 = {};
    if v123 then
        local v128 = { "Cannot Add", v123, Color3.new(1, 0, 0) };
        table.insert(v127, v128);
    end;
    if v125 then
        local v129 = { "Cannot Add", v125, Color3.new(1, 0, 0) };
        table.insert(v127, v129);
    end;
    u16:Notify(v127);
    return false;
end;
local function u140(u131, u132, u133) --[[ Line: 462 ]]
    -- upvalues: u4 (copy), l__SAVE_CONFIGS__5 (copy), u11 (copy)
    local l__RootComponent__24 = u132.RootComponent;
    local u134 = u131.Loadouts[u131.ActiveLoadout];
    local u135 = u133:GetBaseComponent(true);
    local l__ParentComponent__25 = u133.ParentComponent;
    local l__ParentSubName__26 = u133.ParentSubName;
    local _, u136 = u133:Remove();
    local u137 = u131:IsComponentUnlocked(u133.Path, false);
    local function v139() --[[ Line: 472 ]]
        -- upvalues: u133 (copy), l__ParentComponent__25 (copy), l__ParentSubName__26 (copy), u136 (copy), u134 (copy), l__RootComponent__24 (copy), u137 (copy), u132 (copy), u4 (ref), u131 (copy), l__SAVE_CONFIGS__5 (ref), u135 (copy)
        u133:AssignParent(l__ParentComponent__25, l__ParentSubName__26, u136);
        u134.Tree = l__RootComponent__24:Serialize();
        if u137 then
            local v138 = u133:GetFullName();
            if u132.PreviewingState then
                if u132.PreviewingState.BeforeRoot:GetChildParent(table.unpack(v138)) and not u132.PreviewingState.BeforeRoot:GetChild(table.unpack(v138)) then
                    u132.PreviewingState.BeforeRoot:AddChild(u133.Path, {
                        Lerp = u133.MetaData.Lerp
                    }, table.unpack(v138));
                end;
            else
                u4:FireServer("SetComponentLerp", u131.ActiveLoadout, v138, u133.MetaData.Lerp, u133.Path);
            end;
        end;
        if not u132.PreviewingState and l__SAVE_CONFIGS__5[u135.ParentSubName] then
            u134.WeaponBuilds[u135.Path[#u135.Path]] = u135:Serialize();
        end;
        u132:setState({});
    end;
    if u137 then
        v139();
    else
        u132.PreviewingState = u132.PreviewingState or {
            FullName = u135:GetFullName(),
            BeforeRoot = u11.Deserialize(l__RootComponent__24:Serialize(), true)
        };
        v139();
        u132.CheckLevel(u132._lastRailConfig);
    end;
end;
local function u152(p141, p142, p143, p144, p145) --[[ Line: 511 ]]
    -- upvalues: l__SAVE_CONFIGS__5 (copy)
    local l__RootComponent__27 = p142.RootComponent;
    local v146 = p141.Loadouts[p141.ActiveLoadout];
    local v147 = l__RootComponent__27:GetChild(table.unpack(p143));
    v147:EditMetaData({
        [p144 .. "State"] = p145
    });
    local v148 = v147:GetBaseComponent(true);
    local v149 = v148:GetFullName();
    local v150 = v147:GetFullName();
    for _ = 1, #v149 do
        table.remove(v150, 1);
    end;
    local v151 = table.concat(v150, ".") .. "." .. p144;
    p142.SubStateManagers[v151]:SetState(p145);
    v146.Tree = l__RootComponent__27:Serialize();
    if not p142.PreviewingState and l__SAVE_CONFIGS__5[v148.ParentSubName] then
        v146.WeaponBuilds[v148.Path[#v148.Path]] = v148:Serialize();
    end;
end;
local function u162(p153, p154, p155, p156, p157) --[[ Line: 536 ]]
    -- upvalues: u11 (copy), u4 (copy), l__SAVE_CONFIGS__5 (copy)
    local l__RootComponent__28 = p154.RootComponent;
    local v158 = p153.Loadouts[p153.ActiveLoadout];
    local v159 = p157:GetBaseComponent(true);
    local v160 = p153:IsComponentUnlocked(p155.CamoPath, true);
    if not v160 then
        p154.PreviewingState = p154.PreviewingState or {
            FullName = v159:GetFullName(),
            BeforeRoot = u11.Deserialize(l__RootComponent__28:Serialize(), true)
        };
    end;
    p157:EditMetaData({
        Camo = p155.CamoPath[#p155.CamoPath]
    });
    v158.Tree = l__RootComponent__28:Serialize();
    if v160 then
        if p154.PreviewingState then
            local v161 = p154.PreviewingState.BeforeRoot:GetChild(table.unpack(p156));
            if v161 then
                v161:EditMetaData({
                    Camo = p155.CamoPath[#p155.CamoPath]
                });
            end;
        else
            u4:FireServer("SetComponentCamo", p153.ActiveLoadout, p156, p155.CamoPath);
        end;
    end;
    if not p154.PreviewingState and l__SAVE_CONFIGS__5[v159.ParentSubName] then
        v158.WeaponBuilds[v159.Path[#v159.Path]] = v159:Serialize();
    end;
end;
local function u180(u163, p164, u165, u166, u167, u168) --[[ Line: 572 ]]
    -- upvalues: u52 (copy), u16 (copy), l__SAVE_CONFIGS__5 (copy), u11 (copy), l__BASE_KEEP_CHILDRENS__6 (copy), u4 (copy)
    u52(u163, p164);
    local l__RootComponent__29 = p164.RootComponent;
    local u169 = u163.Loadouts[u163.ActiveLoadout];
    local v170 = u167:GetRootComponent():GetChild(u166[1]);
    if v170 then
        local v171, v172 = v170:IsUnderCategoryLimit(u165, l__RootComponent__29:GetChild(table.unpack(u166)));
        if not v171 then
            local v173 = {};
            if v172 then
                local v174 = { "Cannot Add", v172, Color3.new(1, 0, 0) };
                table.insert(v173, v174);
            end;
            u16:Notify(v173);
            return;
        end;
    end;
    local u175 = u163:IsComponentUnlocked(u165.Path, false);
    local function v179() --[[ Line: 596 ]]
        -- upvalues: l__SAVE_CONFIGS__5 (ref), u168 (copy), u169 (copy), u165 (copy), u11 (ref), l__RootComponent__29 (copy), u166 (copy), l__BASE_KEEP_CHILDRENS__6 (ref), u167 (copy), u175 (copy), u4 (ref), u163 (copy)
        local v176;
        if l__SAVE_CONFIGS__5[u168] then
            v176 = u169.WeaponBuilds[u165.Path[#u165.Path]];
            if v176 then
                v176 = u11.Deserialize(v176);
            end;
        else
            v176 = nil;
        end;
        local v177 = v176 or u11.new(u165.Path, nil, nil);
        local v178 = l__RootComponent__29:Remove(table.unpack(u166));
        if v178 then
            if l__BASE_KEEP_CHILDRENS__6[u168] then
                v178:TransferChildren(v177);
            end;
            v178:Destroy();
        end;
        v177:AssignParent(u167, u168);
        u169.Tree = l__RootComponent__29:Serialize();
        if u175 then
            u4:FireServer("ChangeBaseComponent", u163.ActiveLoadout, u166, u165.Path);
        end;
    end;
    if u175 then
        v179();
    else
        p164.PreviewingState = p164.PreviewingState or {
            FullName = u166,
            BeforeRoot = u11.Deserialize(l__RootComponent__29:Serialize(), true)
        };
        v179();
        p164.CheckLevel(u165);
    end;
end;
local function u212(p181, p182, p183, p184) --[[ Line: 636 ]]
    -- upvalues: u52 (copy), u11 (copy), l__SAVE_CONFIGS__5 (copy), u16 (copy), u4 (copy)
    u52(p181, p182);
    local l__RootComponent__30 = p182.RootComponent;
    local v185 = p181.Loadouts[p181.ActiveLoadout];
    local _ = p182.state;
    local v186;
    if p184 then
        local v187 = l__RootComponent__30:GetChild(table.unpack(p184));
        local l__ParentComponent__31 = v187.ParentComponent;
        local l__ParentSubName__32 = v187.ParentSubName;
        local v188 = v187.Path[#v187.Path];
        local v189 = l__ParentComponent__31:GetRootComponent():GetChild(p184[1]);
        local v190 = p181.Loadouts[p183];
        local v191 = nil;
        local v192;
        if l__SAVE_CONFIGS__5[l__ParentSubName__32] then
            v192 = v190.WeaponBuilds[v188];
            if v192 then
                v192 = u11.Deserialize(v190.WeaponBuilds[v188], true);
            end;
        else
            v191 = u11.Deserialize(v190.Tree, true);
            v192 = v191:GetChild(table.unpack(p184));
        end;
        local v193 = v192 or u11.new(v187.Path, nil, nil, true);
        local v194, v195 = v193:GetMenuConfig();
        if v194 then
            local v196, v197 = v189:IsUnderCategoryLimit(v195, v187);
            if not v196 then
                local v198 = {};
                if v197 then
                    local v199 = { "Cannot Add", v197, Color3.new(1, 0, 0) };
                    table.insert(v198, v199);
                end;
                u16:Notify(v198);
                if v191 then
                    v191:Destroy();
                end;
                return;
            end;
        end;
        v187:Destroy();
        if v189 ~= v187 then
            local v200 = v193:GetDescendants();
            local v201 = {};
            for v202 = #v200, 1, -1 do
                local v203 = v200[v202];
                local v204, v205 = v203:GetMenuConfig();
                if v204 then
                    local v206, v207 = v189:IsUnderCategoryLimit(v205);
                    if not v206 then
                        v203:Destroy();
                        if v207 then
                            local v208 = { "Cannot Add", v207, Color3.new(1, 0, 0) };
                            table.insert(v201, v208);
                        end;
                    end;
                end;
            end;
            if #v201 > 0 then
                u16:Notify(v201);
            end;
        end;
        local v209 = v193:Serialize();
        v193:AssignParent(l__ParentComponent__31, l__ParentSubName__32);
        if v191 then
            v191:Destroy();
        end;
        v186 = l__RootComponent__30:Serialize();
        if l__SAVE_CONFIGS__5[l__ParentSubName__32] then
            v185.WeaponBuilds[v188] = v209;
        end;
    else
        v186 = p181.Loadouts[p183].Tree;
        local v210 = u11.Deserialize(v186, true);
        for _, v211 in v210:GetDescendants() do
            if l__SAVE_CONFIGS__5[v211.ParentSubName] then
                v185.WeaponBuilds[v211.Path[#v211.Path]] = v211:Serialize();
            end;
        end;
        v210:Destroy();
    end;
    v185.Tree = v186;
    u4:FireServer("PasteFromLoadout", p183, p181.ActiveLoadout, p184);
    p182:setState({});
end;
local function u221(p213, p214, p215) --[[ Line: 742 ]]
    -- upvalues: u52 (copy), u4 (copy), u32 (copy), u11 (copy), l__SAVE_CONFIGS__5 (copy), u12 (copy)
    u52(p213, p214);
    if p215 then
        local v216 = p214.RootComponent:GetChild(table.unpack(p215));
        local l__ParentComponent__33 = v216.ParentComponent;
        local l__ParentSubName__34 = v216.ParentSubName;
        local l__Path__35 = v216.Path;
        v216:Destroy();
        local v217 = u11.new(l__Path__35, nil, nil, true);
        v217:AssignParent(l__ParentComponent__33, l__ParentSubName__34);
        v217:DeBare();
        local v218 = p213.Loadouts[p213.ActiveLoadout];
        v218.Tree = p214.RootComponent:Serialize();
        if l__SAVE_CONFIGS__5[l__ParentSubName__34] then
            local v219 = v217:Serialize();
            v218.WeaponBuilds[l__Path__35[#l__Path__35]] = v219;
        end;
        u4:FireServer("ResetBaseComponent", p213.ActiveLoadout, p215);
    else
        local l__Name__36 = p213.Loadouts[p213.ActiveLoadout].Name;
        u4:FireServer("ResetLoadout", p213.ActiveLoadout);
        table.remove(p213.Loadouts, p213.ActiveLoadout);
        local l__Loadouts__37 = p213.Loadouts;
        local l__ActiveLoadout__38 = p213.ActiveLoadout;
        local v220 = u32(l__Name__36);
        table.insert(l__Loadouts__37, l__ActiveLoadout__38, v220);
    end;
    p214:setState({});
    u12:Close();
end;
function v27.init(u222, p223) --[[ Line: 790 ]]
    -- upvalues: u22 (copy), u7 (copy), u23 (copy), u3 (copy), u13 (copy), u24 (copy), u12 (copy), u25 (copy), u2 (copy), u15 (copy), u4 (copy), u16 (copy), u32 (copy), u8 (copy), u140 (copy), l__RunService__3 (copy)
    u22:CreateSound("Button", nil, true, "UISounds", "LoadoutOpen").Destroy(10);
    local l__LocalClient__39 = u7.LocalClient;
    u23.UseVirtualCursor = true;
    u222.SetCamera = p223.SetCamera;
    local v224 = u3:Get("Shared", "Models", "Set", "Loadout").Asset:Clone();
    v224.Parent = workspace;
    u222.LoadoutSet = v224;
    u222.OverrideAtts = {};
    for _, v225 in u222.LoadoutSet.PrimaryPart:GetChildren() do
        if v225:IsA("Attachment") then
            u222.OverrideAtts[v225.Name] = v225;
        end;
    end;
    function u222.CheckLevel(p226) --[[ Line: 810 ]]
        -- upvalues: u13 (ref), u24 (ref), u12 (ref), u25 (ref)
        local v227 = p226.Level or 0;
        if u13.Level < v227 then
            local v228 = p226.Price or 0;
            local v229 = u24(u13.Level, v227, v228);
            local v230 = {
                { "Close", function() --[[ Line: 816 ]]
                        -- upvalues: u12 (ref)
                        u12:Close();
                    end }
            };
            u12:Open("Not high enough level", "You have to pay extra to buy this item at your current level.\n\nPrice at level " .. v227 .. ": " .. u25(v228) .. "\nPrice at level " .. u13.Level .. ": " .. u25(v229), v230);
        end;
    end;
    function u222.GetModelCF(p231) --[[ Line: 823 ]]
        -- upvalues: u222 (copy)
        local v232 = (not p231 or #p231 == 0) and { "Character" } or p231;
        for v233 = #v232, 1, -1 do
            local v234 = u222.OverrideAtts[v232[v233]];
            if v234 then
                return v234.WorldCFrame;
            end;
        end;
        warn("No attachment location: " .. table.concat(v232, ", "));
        return CFrame.identity;
    end;
    function u222.GetCameraCF(p235, p236, p237) --[[ Line: 839 ]]
        -- upvalues: u222 (copy)
        local v238 = (not p235 or #p235 == 0) and { "Character" } or p235;
        local v239 = nil;
        for v240 = #v238, 1, -1 do
            local v241 = u222.OverrideAtts[v238[v240]];
            if v241 then
                v239 = v241:FindFirstChild("Camera");
                if v239 then
                    break;
                end;
            end;
        end;
        if not v239 then
            warn("No camera attachment location: " .. table.concat(v238, ", "));
            return CFrame.identity;
        end;
        local l__WorldCFrame__40 = v239.WorldCFrame;
        if p237 then
            l__WorldCFrame__40 = l__WorldCFrame__40 - l__WorldCFrame__40.Position + p237.Position;
        end;
        local v242 = 3;
        if p236 then
            local v243 = p236.ParentModel:GetExtentsSize();
            local v244 = math.sqrt(v243.X ^ 2 + v243.Y ^ 2 + v243.Z ^ 2) * 0.5 / 0.4663076581549986 * 1.2;
            v242 = math.clamp(v244, v242, 10);
        end;
        return l__WorldCFrame__40 * CFrame.new(0, 0, v242);
    end;
    local v245, v246 = u2.createBinding(nil);
    u222.HoverConfig = v245;
    u222.UpdHoverConfig = v246;
    local v247, v248 = u2.createBinding(nil);
    u222.HoverRBX = v247;
    u222.UpdHoverRBX = v248;
    u222.FrameUpdateHover = nil;
    local v249, v250 = u2.createBinding(false);
    u222.HiddenSelectors = v249;
    u222.UpdHiddenSelectors = v250;
    local v251, v252 = u2.createBinding(false);
    u222.PasteDropDownActive = v251;
    u222.UpdPasteDropDownActive = v252;
    u222.PasteDropDownTween = u15.new(0);
    u222.ShowSelectionInfoPanelTween = u15.new(1);
    u222.ShowAttachmentListPanelTween = u15.new(1);
    u222.HoverRef = u2.createRef();
    u222.SubStateManagers = {};
    local v253, v254 = u2.createBinding("");
    u222.RenamingBind = v253;
    u222.UpdRenamingBind = v254;
    u222.RenameButtonRef = u2.createRef();
    function u222.AttemptRename() --[[ Line: 891 ]]
        -- upvalues: u12 (ref), l__LocalClient__39 (copy), u222 (copy), u4 (ref)
        u12:Unfocus();
        local v255 = l__LocalClient__39.Loadouts[u222.state.Renaming];
        local v256 = u222.RenamingBind:getValue();
        if u4:InvokeServer("NameLoadout", u222.state.Renaming, v256) then
            v255.Name = v256;
        end;
        u222:setState({
            Renaming = false
        });
    end;
    function u222.LoadoutCallback(u257, p258) --[[ Line: 907 ]]
        -- upvalues: l__LocalClient__39 (copy), u16 (ref), u12 (ref), u4 (ref), u222 (copy), u32 (ref)
        if p258 == "Delete" then
            if #l__LocalClient__39.Loadouts == 1 then
                u16:Notify({
                    { "Cannot Delete", "You cannot delete your last loadout", Color3.new(1, 0, 0) }
                });
            else
                u12:Open("Delete loadout", "Are you sure you want to delete " .. l__LocalClient__39.Loadouts[u257].Name .. "?\nThis action CANNOT be undone", {
                    { "Yes", function() --[[ Line: 921 ]]
                            -- upvalues: u4 (ref), u257 (copy), l__LocalClient__39 (ref), u222 (ref), u12 (ref)
                            if u4:InvokeServer("DeleteLoadout", u257) then
                                table.remove(l__LocalClient__39.Loadouts, u257);
                                if u257 < l__LocalClient__39.ActiveLoadout then
                                    local v259 = l__LocalClient__39;
                                    v259.ActiveLoadout = v259.ActiveLoadout - 1;
                                elseif u257 == l__LocalClient__39.ActiveLoadout then
                                    l__LocalClient__39.ActiveLoadout = 1;
                                end;
                                u222:setState({});
                            end;
                            u12:Close();
                        end },
                    { "No", function() --[[ Line: 933 ]]
                            -- upvalues: u12 (ref)
                            u12:Close();
                        end }
                });
            end;
        elseif p258 == "Reset" then
            if l__LocalClient__39.ActiveLoadout then
                u12:Open("Restore default loadout", "Are you sure you want to reset all of " .. l__LocalClient__39.Loadouts[u257].Name .. " to the default configurations?\nThis action CANNOT be undone", {
                    { "Yes", function() --[[ Line: 943 ]]
                            -- upvalues: u4 (ref), u257 (copy), l__LocalClient__39 (ref), u32 (ref), u222 (ref), u12 (ref)
                            u4:FireServer("ResetLoadout", u257);
                            local v260 = table.remove(l__LocalClient__39.Loadouts, u257);
                            local l__Loadouts__41 = l__LocalClient__39.Loadouts;
                            local v261 = u257;
                            local v262 = u32(v260.Name);
                            table.insert(l__Loadouts__41, v261, v262);
                            u222:setState({});
                            u12:Close();
                        end },
                    { "No", function() --[[ Line: 950 ]]
                            -- upvalues: u12 (ref)
                            u12:Close();
                        end }
                });
            end;
        elseif p258 == "Rename" then
            if l__LocalClient__39.ActiveLoadout then
                u222:setState({
                    Renaming = u257
                });
                u12:Focus(u222.RenameButtonRef, u222.AttemptRename);
            end;
        elseif p258 == "Add" then
            if u4:InvokeServer("AddLoadout") then
                local l__Loadouts__42 = l__LocalClient__39.Loadouts;
                local v263 = u32("Loadout " .. tostring(#l__LocalClient__39.Loadouts + 1));
                table.insert(l__Loadouts__42, v263);
                u222:setState({});
            else
                u16:Notify({
                    { "HQ", "Upgrade the \'Gunsmith\' at your HQ for more loadout slots", Color3.new(0.274509, 0.274509, 1) }
                });
                u16:Notify({
                    { "Max Loadouts", "You have the maximum loadouts available", Color3.new(1, 0, 0) }
                });
            end;
        else
            if p258 == "Set" and l__LocalClient__39.ActiveLoadout ~= u257 then
                u4:FireServer("SetActiveLoadout", u257);
                l__LocalClient__39.ActiveLoadout = u257;
                u222:setState({
                    ActivePath = false
                });
            end;
        end;
    end;
    local v264 = u222.SetCamera("Loadout");
    u222.Viewer = u8.new(v224.PrimaryPart.Character.WorldCFrame, v264.CFrame, u222.BaseComponent, v224, function(p265, p266) --[[ Line: 997 ]]
        -- upvalues: u222 (copy)
        u222.BackToTop = true;
        u222:setState({
            ActivePath = p265
        });
        if p266 then
            u222.Viewer:SlideComponent(u222.RootComponent:GetChild(table.unpack(p265)));
        end;
    end, function(p267) --[[ Line: 1006 ]]
        -- upvalues: u140 (ref), l__LocalClient__39 (copy), u222 (copy)
        u140(l__LocalClient__39, u222, p267);
    end);
    u222.FrameUpdateSubStateManagers = l__RunService__3.RenderStepped:Connect(function(p268) --[[ Line: 1010 ]]
        -- upvalues: u222 (copy)
        for _, v269 in u222.SubStateManagers do
            v269:Update(p268, false);
        end;
    end);
end;
function v27.willUnmount(p270) --[[ Line: 1017 ]]
    -- upvalues: u23 (copy), u52 (copy), u7 (copy)
    u23.UseVirtualCursor = false;
    u52(u7.LocalClient, p270);
    if p270.LastRoot then
        p270.LastRoot:Destroy();
    end;
    p270.props.UpdateLoadout();
    p270.SetCamera();
    p270.Viewer:Destroy();
    p270.LoadoutSet:Destroy();
    if p270.FrameUpdateHover then
        p270.FrameUpdateHover:Disconnect();
    end;
    p270.FrameUpdateSubStateManagers:Disconnect();
end;
local function u282(p271, p272) --[[ Line: 1036 ]]
    local v273, v274;
    if p272 then
        v273 = p271:GetChildParent(table.unpack(p272));
        local v275 = p271:GetChild(table.unpack(p272));
        if v275 then
            v274 = v275;
        else
            local v276;
            v274, v276 = p271:GetClosestAttainableChild(table.unpack(p272));
            if v276 > 1 then
                p272 = v274:GetFullName();
            else
                v274 = v275;
            end;
        end;
    else
        v273 = p271;
        v274 = nil;
    end;
    local v277 = p272 and (table.clone(p272) or {}) or {};
    for v278 = #v277, 1, -1 do
        if type(v277[v278]) == "number" then
            table.remove(v277, v278);
        end;
    end;
    local v279;
    if p272 then
        v279 = p272[#p272];
    else
        v279 = p272;
    end;
    local v280;
    if v279 then
        v280 = type(v279) == "number";
    else
        v280 = v279;
    end;
    local v281;
    if v279 then
        v281 = string.find(string.lower(v279), "rail_%d");
    else
        v281 = v279;
    end;
    return v274, v273, v277, v279, v280, v281, p272;
end;
function v27.render(u283) --[[ Line: 1066 ]]
    -- upvalues: u7 (copy), l__HttpService__2 (copy), u11 (copy), u282 (copy), l__VIEW_CONFIGS__7 (copy), l__HANDS_UP__8 (copy), u26 (copy), u52 (copy), u12 (copy), u221 (copy), u99 (copy), u2 (copy), u6 (copy), u5 (copy), u212 (copy), u17 (copy), u152 (copy), u9 (copy), l__RunService__3 (copy), u89 (copy), u180 (copy), u162 (copy), u130 (copy), u115 (copy), l__GuiService__1 (copy), l__CurrentCamera__4 (copy), u14 (copy), u28 (copy), u20 (copy), u21 (copy), u19 (copy), u79 (copy), u10 (copy)
    local l__props__43 = u283.props;
    local l__state__44 = u283.state;
    local l__PopupActive__45 = l__props__43.PopupActive;
    local l__BackToTop__46 = u283.BackToTop;
    u283.BackToTop = nil;
    u283.Viewer:ConfigureSelectors(false);
    local l__LocalClient__47 = u7.LocalClient;
    local l__ActivePath__48 = l__state__44.ActivePath;
    local l__Tree__49 = l__LocalClient__47.Loadouts[l__LocalClient__47.ActiveLoadout].Tree;
    local v284 = l__HttpService__2:JSONEncode(l__Tree__49);
    local v285 = false;
    local v286 = false;
    local v287 = true;
    local l__LastPreview__50 = u283.LastPreview;
    local v288;
    if l__ActivePath__48 then
        if l__ActivePath__48[1] == "Character" then
            v288 = l__ActivePath__48[3] or "Character";
        else
            v288 = l__ActivePath__48[1];
            v287 = false;
        end;
    else
        v288 = "Character";
    end;
    local u289;
    if l__LastPreview__50 and (not u283.LastRoot._Destroyed and (l__LastPreview__50 == v284 and u283.LastBasePreview == v288)) then
        u289 = u283.LastRoot;
    else
        if u283.LastRoot then
            if u283.LastHadCharacter and v287 then
                local l__ParentModel__51 = u283.LastRoot:GetChild("Character").ParentModel;
                for _, v290 in l__ParentModel__51:GetDescendants() do
                    if v290:IsA("BasePart") then
                        v290.Anchored = true;
                    end;
                end;
                local u291 = l__ParentModel__51:Clone();
                u291.Parent = workspace;
                task.spawn(function() --[[ Line: 1117 ]]
                    -- upvalues: u291 (copy)
                    task.wait();
                    u291:Destroy();
                end);
                v285 = true;
            end;
            u283.LastRoot:Destroy();
        end;
        v286 = true;
        u289 = u11.Deserialize(l__Tree__49);
        local v292 = u289:GetChild("Character");
        local v293 = u289:GetChild("Primary");
        if v292 and v293 then
            local l__Weld__52 = v293.Weld;
            l__Weld__52.C0 = CFrame.new(-0.3, 0, -0.5) * CFrame.Angles(1.5707963267948966, 3.141592653589793, 3.141592653589793);
            l__Weld__52.C1 = v293.ParentModel.PrimaryPart.anchor.CFrame;
            l__Weld__52.Part0 = v292.Model.RightHand;
            l__Weld__52.Part1 = v293.ParentModel.PrimaryPart;
            v293.ParentModel.Parent = v292.ParentModel;
        end;
        u283.LastHadCharacter = v287;
        u283.LastBasePreview = v288;
        u283.LastPreview = v284;
        u283.LastRoot = u289;
    end;
    local v294, _, v295, _, v296, _, v297 = u282(u289, l__ActivePath__48);
    local u298 = v294;
    local u299 = v295;
    local v300 = v296;
    local u301 = v297;
    u283.Viewer:SetActivePath(u301);
    local u302 = nil;
    local u303 = nil;
    local u304 = {};
    local u305 = (1 / 0);
    local u306 = "center";
    local u307 = 1;
    local u308 = l__VIEW_CONFIGS__7;
    local function v312(p309) --[[ Line: 1165 ]]
        -- upvalues: u308 (ref), u304 (copy), u303 (ref), u302 (ref), u305 (ref), u307 (ref), u306 (ref)
        local l__Rotate__53 = u308.Rotate;
        local l__FocusMode__54 = u308.FocusMode;
        local l__Hide__55 = u308.Hide;
        local l__SelectorDepth__56 = u308.SelectorDepth;
        local l__PivotMode__57 = u308.PivotMode;
        local l__SelectorScale__58 = u308.SelectorScale;
        local v310;
        if l__FocusMode__54 then
            v310 = string.lower(l__FocusMode__54) == "alone";
        else
            v310 = l__FocusMode__54;
        end;
        if l__FocusMode__54 then
            l__FocusMode__54 = string.lower(l__FocusMode__54) == "focus";
        end;
        if not p309 then
            table.insert(u304, v310 and "alone" or (l__FocusMode__54 and "focus" or "none"));
        end;
        if v310 then
            if l__Hide__55 then
                u303 = table.clone(l__Hide__55);
            else
                u303 = nil;
            end;
        elseif l__Hide__55 then
            u303 = u303 or {};
            for v311 = 1, #l__Hide__55 do
                table.insert(u303, l__Hide__55[v311]);
            end;
        end;
        if l__Rotate__53 then
            u302 = l__Rotate__53;
        end;
        if l__SelectorDepth__56 then
            u305 = l__SelectorDepth__56;
        else
            u305 = (1 / 0);
        end;
        if l__SelectorScale__58 then
            u307 = l__SelectorScale__58;
        else
            u307 = 1;
        end;
        if l__PivotMode__57 then
            u306 = l__PivotMode__57;
        end;
    end;
    v312(true);
    local v313, v314;
    if u301 then
        v313 = u307;
        v314 = u305;
        local v315 = u308;
        for v316 = 1, #u299 do
            local v317 = u299[v316];
            if v315[v317] then
                u308 = v315[v317];
                v312();
                v315 = u308;
            end;
        end;
    else
        v313 = u307;
        v314 = u305;
    end;
    if u303 then
        for v318 = 1, #u303 do
            local v319 = u289:GetChild(table.unpack(u303[v318]));
            if v319 then
                v319:MakeBare();
            end;
        end;
    end;
    u283.Viewer:SetRotateDirections(u302.X, u302.Y);
    u283.Viewer:SetPivotMode(u306);
    local v320 = false;
    local u321, u322;
    if u301 then
        u321 = u289;
        local v323 = 0;
        local v324 = 0;
        local v325;
        for v326 = 1, #u304 do
            local v327 = u304[v326];
            local v328 = u299[v326];
            if v327 == "alone" or v327 == "focus" then
                local v329 = { v328 };
                for v330 = 1, v323 do
                    table.insert(v329, 1, u299[v326 - v330]);
                end;
                local v331 = u289:GetChild(table.unpack(v329));
                if v331 then
                    v325 = v331;
                else
                    v331 = u289;
                    v325 = false;
                end;
                v323 = 0;
                if v327 == "alone" then
                    local v332 = { v328 };
                    for v333 = 1, v324 do
                        table.insert(v332, 1, u299[v326 - v333]);
                    end;
                    u322 = u322:GetChild(table.unpack(v332));
                    u289 = v331;
                    v324 = 0;
                    v320 = false;
                else
                    v324 = v324 + 1;
                    u289 = v331;
                    v320 = true;
                end;
            elseif v327 == "none" then
                v323 = v323 + 1;
                v324 = v324 + 1;
            end;
        end;
        u283.Viewer:ConfigureSelectors(nil, v325, v314, v313);
    else
        u283.Viewer:ConfigureSelectors(nil, u289, v314, v313);
        local v334 = u289:GetChild("Character");
        u322 = u289:GetChild("Character");
        u321 = u289;
        u289 = v334;
    end;
    local l__CameraComponent__59 = u283.CameraComponent;
    u283.CameraComponent = u289;
    local v335 = u283.Viewer:GetComponent();
    if v286 or v335._Destroyed then
        local v336 = table.find(l__HANDS_UP__8, v288) and true or false;
        u283.Viewer:SetComponent(u322, v285, v336);
    end;
    u283.RootComponent = u321;
    local u337 = nil;
    local v338 = u283.GetModelCF(u299);
    if l__LocalClient__47.ActiveLoadout ~= u283.LastActiveLoadout or (not u322 or u322 and (not v335 or u322.Name ~= v335.Name)) then
        u283.Viewer:ResetModel(v338);
    end;
    if v320 and (u289 and u322) then
        local v339 = u322.ParentModel:GetBoundingBox();
        local v340 = nil;
        if u289.ParentModel.PrimaryPart then
            v340 = u289.ParentModel:GetBoundingBox();
        else
            local v341 = u289:GetFullName();
            table.remove(v341, #v341);
            local v342 = table.concat(v341, ".");
            for _, v343 in u289.ParentComponent:GetAttachments() do
                if table.concat(v343.Path, ".") == v342 then
                    v340 = v343.Attachment.WorldCFrame;
                    break;
                end;
            end;
            if not v340 then
                v340 = v339;
            end;
        end;
        u337 = v338 * (v339:Inverse() * v340);
    end;
    local v344 = u283.GetCameraCF(u299, u289, u337);
    if l__LocalClient__47.ActiveLoadout ~= u283.LastActiveLoadout or (not u289 or u289 and (not l__CameraComponent__59 or u289.Name ~= l__CameraComponent__59.Name)) then
        u283.Viewer:ResetCamera(v344);
    end;
    u283.Viewer:ConfigureSelectors(not u283.HiddenSelectors:getValue());
    u283.Viewer:SetPopupActive(l__PopupActive__45);
    u283.LastActiveLoadout = l__LocalClient__47.ActiveLoadout;
    for v345, v346 in u283.SubStateManagers do
        v346:Destroy();
        u283.SubStateManagers[v345] = nil;
    end;
    local v347 = {};
    if u322 then
        for _, v348 in u322:GetDescendants() do
            local l__File__60 = v348.File;
            if l__File__60 then
                l__File__60 = v348.File.Attachments;
            end;
            if l__File__60 and not v348.IsBare then
                local v349 = {};
                for v350 in l__File__60 do
                    if not v348.MetaData[v350 .. "State"] then
                        v349[v350 .. "State"] = 1;
                    end;
                end;
                v348:EditMetaData(v349);
                local v351 = v348:GetFullName();
                for _ = 1, #v348:GetBaseComponent():GetFullName() do
                    table.remove(v351, 1);
                end;
                for v352, v353 in l__File__60 do
                    local v354 = table.concat(v351, ".") .. "." .. v352;
                    u283.SubStateManagers[v354] = u26[v352 .. "AttachmentReplicator"].new(nil, v353, nil, v348, nil);
                    u283.SubStateManagers[v354]:SetState(v348.MetaData[v352 .. "State"]);
                end;
            end;
            if v348.DoSave then
                if not l__LocalClient__47:IsComponentUnlocked(v348.Path, false) then
                    local v355, v356 = v348:GetMenuConfig();
                    table.insert(v347, {
                        Component = v348,
                        Config = v355 and v356 and v356 or false
                    });
                end;
                if v348.MetaData.Camo then
                    local v357 = v348:GetCamoConfig(v348.MetaData.Camo);
                    if v357 and not l__LocalClient__47:IsComponentUnlocked(v357.CamoPath, true) then
                        table.insert(v347, {
                            Config = v357
                        });
                    end;
                end;
            end;
        end;
        if not l__LocalClient__47:IsComponentUnlocked(u322.Path, false) then
            local v358, v359 = u322:GetMenuConfig();
            table.insert(v347, {
                Component = u322,
                Config = v358 and v359 and v359 or false
            });
        end;
        if u322.MetaData.Camo then
            local v360 = u322:GetCamoConfig(u322.MetaData.Camo);
            if v360 and not l__LocalClient__47:IsComponentUnlocked(v360.CamoPath, true) then
                table.insert(v347, {
                    Config = v360
                });
            end;
        end;
    end;
    table.sort(v347, function(p361, p362) --[[ Line: 1412 ]]
        local v363 = p361.Config.Price or 0;
        local v364 = p362.Config.Price or 0;
        if v363 == v364 then
            return p361.Config.Name < p362.Config.Name;
        else
            return v363 < v364;
        end;
    end);
    local u365 = not u283.PreviewingState and {} or v347;
    if #u365 == 0 then
        u52(l__LocalClient__47, u283);
    end;
    local function v366() --[[ Line: 1442 ]]
        -- upvalues: u283 (copy)
        u283.UpdPasteDropDownActive(not u283.PasteDropDownActive:getValue());
        if u283.PasteDropDownActive:getValue() then
            u283.PasteDropDownTween:SetGoal(1);
        else
            u283.PasteDropDownTween:SetGoal(0);
        end;
    end;
    local function v369() --[[ Line: 1451 ]]
        -- upvalues: u301 (ref), l__LocalClient__47 (copy), u298 (ref), u12 (ref), u221 (ref), u283 (copy)
        local v367;
        if u301 then
            local _, v368 = u298:GetMenuConfig();
            v367 = v368 and v368.Name or u298.Name;
        else
            v367 = l__LocalClient__47.Loadouts[l__LocalClient__47.ActiveLoadout].Name;
        end;
        u12:Open("Restore default configuration", "Are you sure you want " .. v367 .. " to be restored to the default configuration?\nThis action CANNOT be undone", {
            { "Yes", function() --[[ Line: 1461 ]]
                    -- upvalues: u221 (ref), l__LocalClient__47 (ref), u283 (ref), u301 (ref)
                    u221(l__LocalClient__47, u283, u301);
                end },
            { "No", function() --[[ Line: 1464 ]]
                    -- upvalues: u12 (ref)
                    u12:Close();
                end }
        });
    end;
    local function v370() --[[ Line: 1469 ]]
        -- upvalues: u283 (copy), u298 (ref)
        u283.Viewer:SlideComponent(u298);
    end;
    local function v371() --[[ Line: 1472 ]]
        -- upvalues: u99 (ref), l__LocalClient__47 (copy), u283 (copy), u301 (ref)
        u99(l__LocalClient__47, u283, u301);
    end;
    local v372 = {};
    table.insert(v372, {
        Name = "HIDE",
        Activated = u283.HiddenSelectors,
        Callback = function() --[[ Name: hideCallback, Line 1429 ]]
            -- upvalues: u283 (copy)
            local v373 = not u283.HiddenSelectors:getValue();
            u283.UpdHiddenSelectors(v373);
            u283.Viewer:ConfigureSelectors(not v373);
            if v373 then
                u283.OldSelectionInfoPanelTweenValue = u283.ShowSelectionInfoPanelTween:GetGoal();
            end;
            u283.ShowSelectionInfoPanelTween:SetGoal(v373 and 0 or (u283.OldSelectionInfoPanelTweenValue or 1));
            u283.ShowAttachmentListPanelTween:SetGoal(v373 and 0 or 1);
        end
    });
    if not u301 and true or (u298 and u298.IsBase and true or false) then
        local u374 = {};
        for u375 = 1, #l__LocalClient__47.Loadouts do
            local v376 = l__LocalClient__47.Loadouts[u375];
            if l__LocalClient__47.ActiveLoadout ~= u375 then
                local l__createElement__61 = u2.createElement;
                local v377 = u6;
                local v379 = {
                    Size = UDim2.fromScale(0.9, 0.2727272727272727),
                    SizeConstraint = u5.SizeConstraint.RelativeXX,
                    LayoutOrder = u375,
                    Ignore = l__PopupActive__45 or u283.PasteDropDownTween:Map(function(p378) --[[ Line: 1505 ]]
                        return p378 < 0.2;
                    end),
                    Name = v376.Name,
                    Callback = function() --[[ Name: Callback, Line 1510 ]]
                        -- upvalues: u212 (ref), l__LocalClient__47 (copy), u283 (copy), u375 (copy), u301 (ref)
                        u212(l__LocalClient__47, u283, u375, u301);
                        u283.UpdPasteDropDownActive(false);
                        u283.PasteDropDownTween:SetGoal(0);
                    end
                };
                table.insert(u374, l__createElement__61(v377, v379));
            end;
        end;
        local v382 = {
            Name = "PASTE FROM",
            Callback = v366,
            Activated = u283.PasteDropDownActive,
            Children = { u2.createElement("Frame", {
                    ClipsDescendants = true,
                    BackgroundTransparency = 0.5,
                    BorderSizePixel = 0,
                    Size = u283.PasteDropDownTween:Map(function(p380) --[[ Line: 1524 ]]
                        -- upvalues: u374 (copy)
                        return UDim2.new(1.1, 0, (#u374 * 0.3 + 0.1) * p380, (#u374 - 1) * 3);
                    end),
                    Position = UDim2.new(-0.1, 0, 0, 0),
                    AnchorPoint = Vector2.new(1, 0),
                    BackgroundColor3 = Color3.fromRGB(0, 0, 0),
                    SizeConstraint = u5.SizeConstraint.RelativeXX,
                    Visible = u283.PasteDropDownTween:Map(function(p381) --[[ Line: 1534 ]]
                        return p381 > 0.2;
                    end)
                }, { u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0, 4)
                    }), u2.createElement("UIListLayout", {
                        HorizontalAlignment = u5.HorizontalAlignment.Center,
                        VerticalAlignment = u5.VerticalAlignment.Center,
                        FillDirection = u5.FillDirection.Vertical,
                        SortOrder = u5.SortOrder.LayoutOrder,
                        Padding = UDim.new(0, 3)
                    }), u2.createFragment(u374) }) }
        };
        table.insert(v372, v382);
        table.insert(v372, {
            Name = "RESET",
            Activated = false,
            Callback = v369
        });
    end;
    if u298 and (u298.MetaData.Lerp and v300) then
        table.insert(v372, {
            Name = "MOVE",
            Activated = false,
            Callback = v370
        });
    end;
    if u298 and (v300 and u298.ParentComponent:CanHaveNone(u298.ParentSubName)) then
        table.insert(v372, {
            Name = "REMOVE",
            Activated = false,
            Callback = v371
        });
    end;
    local v383 = {
        Name = "RESET VIEW",
        Activated = u283.Viewer:GetViewIsChangedBinding(),
        Callback = function() --[[ Name: Callback, Line 1579 ]]
            -- upvalues: u322 (ref), u283 (copy), u299 (ref), u289 (ref), u337 (ref)
            if u322 then
                u283.Viewer:ResetCamera(u283.GetCameraCF(u299, u289, u337));
                u283.Viewer:ResetModel(nil);
            else
                u283.Viewer:ResetCamera(nil);
                u283.Viewer:ResetModel(nil);
            end;
        end
    };
    table.insert(v372, v383);
    local v384 = #v372;
    local v385 = false;
    if u298 and (u298.File and u298.File.Config) then
        local l__Attachments__62 = u298.File.Attachments;
        if l__Attachments__62 then
            v385 = {};
            for v386, v387 in l__Attachments__62 do
                for v388 = 1, #v387 do
                    v387[v388].SubState = v388;
                    v387[v388].SubIndex = v386;
                    table.insert(v385, v387[v388]);
                end;
                table.insert(v385, {
                    SubState = 0,
                    SubIndex = v386
                });
            end;
            v384 = v384 + math.ceil(#v385 / 3);
        end;
    end;
    for v389, v390 in v372 do
        v372[v389] = u2.createElement(u6, {
            Size = UDim2.fromScale(0.85, 0.275),
            SizeConstraint = u5.SizeConstraint.RelativeXX,
            LayoutOrder = v389,
            Ignore = l__PopupActive__45,
            Activated = v390.Activated,
            Name = v390.Name,
            Callback = v390.Callback
        }, v390.Children);
    end;
    if v385 then
        local v391 = {};
        for v392 = 1, #v385 do
            local v393 = v385[v392];
            v391[v392] = u2.createElement(u17, {
                Callback = function(p394, p395) --[[ Name: Callback, Line 1634 ]]
                    -- upvalues: u152 (ref), l__LocalClient__47 (copy), u283 (copy), u301 (ref)
                    u152(l__LocalClient__47, u283, u301, p394, p395);
                    u283:setState({});
                end,
                ButtonInfo = v393,
                Ignore = l__PopupActive__45,
                Order = v392,
                Activated = u298.MetaData[v393.SubIndex .. "State"] == v393.SubState,
                SizeConstraint = u5.SizeConstraint.RelativeXX,
                Size = UDim2.fromScale(0.25, 0.25)
            });
        end;
        v372[#v372 + 1] = u2.createElement("Frame", {
            LayoutOrder = 100000,
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(0.85, math.ceil(#v385 / 3) * 0.25),
            SizeConstraint = u5.SizeConstraint.RelativeXX
        }, { u2.createFragment(v391), u2.createElement("UIListLayout", {
                Wraps = true,
                HorizontalAlignment = u5.HorizontalAlignment.Left,
                VerticalAlignment = u5.VerticalAlignment.Top,
                FillDirection = u5.FillDirection.Horizontal,
                SortOrder = u5.SortOrder.LayoutOrder,
                Padding = UDim.new(0.125, 0),
                VerticalFlex = u5.UIFlexAlignment.SpaceAround
            }) });
    end;
    local l__createFragment__63 = u2.createFragment;
    local v396 = {};
    local v421 = u2.createElement("Frame", {
        BackgroundTransparency = 1,
        ClipsDescendants = true,
        AnchorPoint = Vector2.new(0, 0),
        Position = UDim2.new(0.02, 0, 0.02, 0),
        Size = UDim2.new(0.3, 0, 0.98, 0),
        Visible = u283.ShowAttachmentListPanelTween:Map(function(p397) --[[ Line: 1672 ]]
            return p397 > 0.1;
        end),
        SizeConstraint = u5.SizeConstraint.RelativeYY
    }, { u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.new(1, 0, 1, 0),
            AnchorPoint = u283.ShowAttachmentListPanelTween:Map(function(p398) --[[ Line: 1681 ]]
                return Vector2.new(0, 1):Lerp(Vector2.new(0, 0), p398);
            end)
        }, { u2.createElement(u9, {
                AspectRatio = 0.30612244897959184,
                ActivePath = u301,
                Ignore = l__PopupActive__45,
                BackToTop = l__BackToTop__46,
                Renaming = l__state__44.Renaming,
                RenamingBind = u283.RenamingBind,
                UpdRenamingBind = u283.UpdRenamingBind,
                AttemptRename = u283.AttemptRename,
                RenameButtonRef = u283.RenameButtonRef,
                Pages = l__props__43.Pages,
                RootComponent = u321,
                Hover = function(u399, p400, p401) --[[ Name: Hover, Line 1702 ]]
                    -- upvalues: u283 (copy), l__RunService__3 (ref)
                    if p401 == false and u283.HoveringHoverPanel then
                        u283.PendingHoverPanelRelease = true;
                    else
                        u283.PendingHoverPanelRelease = nil;
                        if u283.FrameUpdateHover then
                            u283.FrameUpdateHover:Disconnect();
                            u283.FrameUpdateHover = nil;
                        end;
                        if p401 then
                            u283.UpdHoverConfig(p400);
                            u283.UpdHoverRBX(u399);
                            u283.FrameUpdateHover = l__RunService__3.RenderStepped:Connect(function() --[[ Line: 1719 ]]
                                -- upvalues: u283 (ref), u399 (copy)
                                u283.UpdHoverRBX(u399);
                            end);
                        else
                            if u283.HoverConfig:getValue() == p400 then
                                u283.UpdHoverConfig(nil);
                            end;
                            if u283.HoverRBX:getValue() == u399 then
                                u283.UpdHoverRBX(nil);
                            end;
                        end;
                    end;
                end,
                LoadoutCallback = u283.LoadoutCallback,
                Callback = function(p402, p403, p404) --[[ Name: Callback, Line 1734 ]]
                    -- upvalues: u301 (ref), l__props__43 (copy), u321 (ref), u52 (ref), l__LocalClient__47 (copy), u283 (copy), u89 (ref), u282 (ref), u180 (ref), u162 (ref), u130 (ref), u115 (ref)
                    if p404 then
                        if u301 then
                            local v405, v406 = u321:GetClosestAttainableChild(table.unpack(u301));
                            local v407;
                            if v405 then
                                if v406 > 0 then
                                    v407 = v405:GetBaseComponent(true);
                                elseif type(u301[#u301]) == "number" then
                                    v407 = v405:GetBaseComponent(true);
                                else
                                    v407 = v405:GetBaseComponent();
                                end;
                            else
                                v407 = u321;
                            end;
                            if v405 then
                                v405 = v405:GetBaseComponent(true);
                            end;
                            if v407 ~= v405 then
                                u52(l__LocalClient__47, u283);
                            end;
                            local v408 = v407:GetFullName();
                            if type(v408[#v408]) == "number" then
                                table.remove(v408, #v408);
                            end;
                            if #v408 == 0 then
                                v408 = false;
                            end;
                            u283.BackToTop = true;
                            u283:setState({
                                ActivePath = v408
                            });
                        else
                            l__props__43.ChangePage(l__props__43.Pages[1]);
                        end;
                    elseif p403 then
                        local v409 = u301 and table.clone(u301) or {};
                        table.insert(v409, p403);
                        u283.BackToTop = true;
                        u283:setState({
                            ActivePath = v409
                        });
                    elseif p402 then
                        local v410 = not p402[1] and { p402 } or p402;
                        for v411 = 1, #v410 do
                            local v412 = v410[v411];
                            local l__IsCamo__64 = v412.IsCamo;
                            local v413 = v412.TempFullNamePath or (v412.FullNamePath or u301);
                            if v412.TempFullNamePath then
                                v412.TempFullNamePath = nil;
                            end;
                            local v414, v415, _, v416, v417, v418, v419 = u282(u321, v413);
                            local v420 = not (v414 and v414.IsBase) and (v415.File and v415.File.BaseComponents);
                            if v420 then
                                v420 = v415.File.BaseComponents[v419[v417 and #v419 - 1 or #v419]];
                            end;
                            if v420 and not l__IsCamo__64 then
                                u180(l__LocalClient__47, u283, v412, v419, v415, v416);
                            elseif l__IsCamo__64 then
                                u162(l__LocalClient__47, u283, v412, v419, v414);
                            elseif v418 then
                                if u130(l__LocalClient__47, u283, v412, v419, v415) then
                                    return;
                                end;
                            else
                                u115(l__LocalClient__47, u283, v412, v419, v415);
                            end;
                            if v412.BuyDefaults then
                                break;
                            end;
                        end;
                        u283:setState({});
                    else
                        u89(l__LocalClient__47, u283, u301);
                        u283:setState({});
                    end;
                end
            }) }) });
    local v429 = u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Position = u283.HoverRBX:map(function(p422) --[[ Line: 1833 ]]
            -- upvalues: l__GuiService__1 (ref), u283 (copy), l__CurrentCamera__4 (ref), l__props__43 (copy)
            if not p422 then
                return UDim2.new(-100, 0, 0, 0);
            end;
            local v423 = p422;
            while p422 and not p422:IsA("ScreenGui") do
                p422 = p422.Parent;
            end;
            if not p422 then
                return UDim2.new(-100, 0, 0, 0);
            end;
            local v424 = v423.AbsolutePosition - Vector2.new(p422.AbsolutePosition.X, 0) + l__GuiService__1:GetGuiInset() + v423.AbsoluteSize * Vector2.xAxis;
            local v425 = u283.HoverRef:getValue();
            local v426 = math.clamp(v424.Y, l__CurrentCamera__4.ViewportSize.Y * 0.15, l__CurrentCamera__4.ViewportSize.Y * 0.95 - (v425 and v425.AbsoluteSize.Y or 0)) - l__props__43.Offset * l__CurrentCamera__4.ViewportSize.Y;
            return UDim2.new(0, v424.X + 6, 0, v426);
        end),
        Size = UDim2.new(0.35, 0, 0.4, 0),
        SizeConstraint = u5.SizeConstraint.RelativeYY,
        Visible = u283.HoverRBX:map(function(p427) --[[ Line: 1859 ]]
            return p427 and true or false;
        end)
    }, { u2.createElement(u14, {
            Config = u283.HoverConfig,
            RootComponent = u283.RootComponent,
            ActivePath = u301,
            LoadoutCallback = u283.LoadoutCallback,
            Renaming = l__state__44.Renaming,
            Ignore = l__PopupActive__45,
            Ref = u283.HoverRef,
            SetHoveringHoverPanel = function(p428) --[[ Name: SetHoveringHoverPanel, Line 1872 ]]
                -- upvalues: u283 (copy)
                u283.HoveringHoverPanel = p428;
                if p428 == false and u283.PendingHoverPanelRelease then
                    u283.PendingHoverPanelRelease = nil;
                    if u283.FrameUpdateHover then
                        u283.FrameUpdateHover:Disconnect();
                        u283.FrameUpdateHover = nil;
                    end;
                    u283.UpdHoverConfig(nil);
                    u283.UpdHoverRBX(nil);
                end;
            end
        }) });
    local v430;
    if #u365 > 0 then
        v430 = u2.createElement("Frame", {
            BackgroundTransparency = 0.7,
            ZIndex = -100,
            Size = UDim2.new(1, 0, 1, 0),
            BackgroundColor3 = Color3.new()
        }, { u2.createElement("TextLabel", {
                Text = "PREVIEW",
                BackgroundTransparency = 1,
                TextTransparency = 0.7,
                TextScaled = true,
                Size = UDim2.new(1, 0, 0.1, 0),
                TextColor3 = Color3.new(0.352941, 0.352941, 0.352941),
                Position = UDim2.new(0.5, 0, 0.5, 0),
                AnchorPoint = Vector2.new(0.5, 0.5),
                FontFace = u28
            }), u2.createElement("UIGradient", {
                Rotation = 90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.1, 0), NumberSequenceKeypoint.new(1, 0) })
            }) });
    else
        v430 = false;
    end;
    v396[1], v396[2], v396[3], v396[4], v396[5], v396[6] = v421, v429, v430, u2.createElement("Frame", {
    BackgroundTransparency = 1,
    Visible = u283.Viewer:GetSlidingBinding():map(function(p431) --[[ Line: 1916 ]]
        return p431 or false;
    end),
    Position = UDim2.fromScale(0.5, 0.9),
    AnchorPoint = Vector2.new(0.5, 0.5),
    Size = UDim2.new(0, 0, 1, 0)
}, {
    Aspect = u2.createElement("UIAspectRatioConstraint", {
        AspectRatio = 1.778,
        AspectType = u5.AspectType.ScaleWithParentSize,
        DominantAxis = u5.DominantAxis.Height
    }),
    u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 0.02, 0),
        Position = UDim2.fromScale(0, 0.5),
        AnchorPoint = Vector2.new(0, 0.5)
    }, { u2.createElement(u20, {
            Gamepad = false,
            Description = "Cancel",
            Down = false,
            Order = 1,
            VisibleOnGamepad = false,
            VisibleOnKeyboard = true,
            Position = UDim2.fromScale(0.5, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5),
            UsingGamepad = u21._gamepad,
            Key = u5.KeyCode.Space,
            ViewPort = l__CurrentCamera__4.ViewportSize
        }) })
}), u2.createElement("Frame", {
    BackgroundTransparency = 1,
    Size = UDim2.new(0.3, 0, 0.1, 0),
    Position = UDim2.new(0.5, 0, 0.9, 0),
    AnchorPoint = Vector2.new(0.5, 1),
    SizeConstraint = u5.SizeConstraint.RelativeXX
}, { u2.createElement(u19, {
        Ignore = u283.Viewer:GetSlidingBinding():map(function(p432) --[[ Line: 1959 ]]
            -- upvalues: l__PopupActive__45 (copy)
            return p432 or l__PopupActive__45;
        end),
        ChangePage = l__props__43.ChangePage,
        Components = u365,
        RemovedComponent = function(p433) --[[ Name: RemovedComponent, Line 1964 ]]
            -- upvalues: u365 (ref), u52 (ref), l__LocalClient__47 (copy), u283 (copy)
            if #u365 > 1 then
                u52(l__LocalClient__47, u283, u365[p433]);
            else
                u52(l__LocalClient__47, u283);
            end;
            u283:setState({});
        end,
        CanceledPreview = function() --[[ Name: CanceledPreview, Line 1972 ]]
            -- upvalues: u52 (ref), l__LocalClient__47 (copy), u283 (copy)
            u52(l__LocalClient__47, u283);
            u283:setState({});
        end,
        PurchasedPreview = function() --[[ Name: PurchasedPreview, Line 1976 ]]
            -- upvalues: l__LocalClient__47 (copy), u79 (ref), u283 (copy)
            if l__LocalClient__47.Processing then
            else
                l__LocalClient__47.Processing = true;
                local _, _ = pcall(u79, l__LocalClient__47, u283);
                u283.LastPreview = nil;
                u283:setState({});
                l__LocalClient__47.Processing = false;
            end;
        end
    }) }), u2.createElement("Frame", {
    BackgroundTransparency = 1,
    AnchorPoint = Vector2.new(1, 0),
    Position = UDim2.new(0.98, 0, 0.02, 0),
    Size = UDim2.new(0.52, 0, 0.95, 0),
    SizeConstraint = u5.SizeConstraint.RelativeYY
}, { u2.createElement("Frame", {
        BackgroundTransparency = 1,
        ClipsDescendants = true,
        Size = UDim2.new(0.8, 0, 1, 0),
        AnchorPoint = Vector2.new(1, 0),
        Position = UDim2.fromScale(1, 0)
    }, { u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(1, 1),
            AnchorPoint = u283.ShowSelectionInfoPanelTween:Map(function(p434) --[[ Line: 2011 ]]
                return Vector2.new(0, 0):Lerp(Vector2.new(1, 0), p434);
            end),
            Position = UDim2.fromScale(1, 0)
        }, { u2.createElement(u10, {
                ActivePath = u301,
                ShowSelectionInfoPanelTween = u283.ShowSelectionInfoPanelTween,
                HiddenSelectors = u283.HiddenSelectors,
                Ignore = l__PopupActive__45,
                RootComponent = u283.RootComponent
            }) }) }), u2.createElement("Frame", {
        BackgroundTransparency = 0.5,
        Size = UDim2.new(0.2, 0, v384 * 0.055 + 0.035, (v384 - 1) * 5),
        SizeConstraint = u5.SizeConstraint.RelativeXX,
        BackgroundColor3 = Color3.fromRGB(0, 0, 0),
        Position = u283.ShowSelectionInfoPanelTween:Map(function(p435) --[[ Line: 2033 ]]
            return UDim2.fromScale(1, 0):Lerp(UDim2.fromScale(0, 0), p435);
        end),
        AnchorPoint = u283.ShowSelectionInfoPanelTween:Map(function(p436) --[[ Line: 2036 ]]
            return Vector2.new(1, 0):Lerp(Vector2.new(0, 0), p436);
        end)
    }, { u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 4)
        }), u2.createElement("UIListLayout", {
            HorizontalAlignment = u5.HorizontalAlignment.Center,
            VerticalAlignment = u5.VerticalAlignment.Center,
            FillDirection = u5.FillDirection.Vertical,
            SortOrder = u5.SortOrder.LayoutOrder,
            Padding = UDim.new(0, 5)
        }), u2.createFragment(v372) }) });
    return l__createFragment__63(v396);
end;
return v27;