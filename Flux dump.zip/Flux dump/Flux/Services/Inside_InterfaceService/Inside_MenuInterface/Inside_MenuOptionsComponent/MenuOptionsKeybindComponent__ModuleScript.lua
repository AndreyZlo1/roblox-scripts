-- Services.InterfaceService.MenuInterface.MenuOptionsComponent.MenuOptionsKeybindComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "network");
local u4 = v1("InputService");
local u5 = v1("MenuButtonComponent");
local l__UserInputService__1 = game:GetService("UserInputService");
local u6 = {
    Enum.UserInputType.MouseButton1,
    Enum.UserInputType.MouseButton2,
    Enum.UserInputType.MouseButton3,
    Enum.UserInputType.Keyboard
};
local v7 = u2.Component:extend("MenuDeploy");
function v7.init(u8, u9) --[[ Line: 18 ]]
    -- upvalues: l__UserInputService__1 (copy), u6 (copy), u4 (copy), u3 (copy)
    function u8.Listen() --[[ Line: 19 ]]
        -- upvalues: u8 (copy), l__UserInputService__1 (ref), u6 (ref), u9 (copy), u4 (ref), u3 (ref)
        u8:setState({
            Active = true
        });
        local v10 = l__UserInputService__1.InputBegan:Wait();
        local v11 = false;
        for _, v12 in u6 do
            if v10.UserInputType == v12 then
                v11 = true;
                break;
            end;
        end;
        if v11 then
            local l__UserInputType__2 = v10.UserInputType;
            local l__KeyCode__3 = v10.KeyCode;
            local l__Keybind__4 = u9.Keybind;
            u4.Overrides[l__Keybind__4] = {
                KeyCode = l__KeyCode__3,
                InputType = l__UserInputType__2
            };
            u3:FireServer("UpdateSettings", "Keybind", l__Keybind__4, {
                Key = l__KeyCode__3.Name,
                Input = l__UserInputType__2.Name
            });
        end;
        u8:setState({
            Active = false
        });
    end;
    u8:setState({
        Active = false
    });
end;
function v7.render(u13) --[[ Line: 58 ]]
    -- upvalues: u2 (copy), u5 (copy), u4 (copy), u3 (copy)
    local l__props__5 = u13.props;
    local l__state__6 = u13.state;
    local l__Ignore__7 = l__props__5.Ignore;
    local l__Keybind__8 = l__props__5.Keybind;
    local v14 = { u2.createElement(u5, {
            Layout = 2,
            Scroller = l__props__5.Scroller,
            Size = UDim2.fromScale(0.2, 1),
            Ignore = l__Ignore__7,
            Name = u4:GetBind(l__Keybind__8).Name,
            Activated = l__state__6.Active,
            Callback = function() --[[ Name: Callback, Line 72 ]]
                -- upvalues: u13 (copy)
                u13.Listen();
            end
        }) };
    if u4.Overrides[l__Keybind__8] then
        v14[2] = u2.createElement(u5, {
            Layout = 1,
            Name = "Reset",
            Scroller = l__props__5.Scroller,
            Size = UDim2.fromScale(0.1, 1),
            Ignore = l__Ignore__7,
            Callback = function() --[[ Name: Callback, Line 85 ]]
                -- upvalues: u4 (ref), l__Keybind__8 (copy), u3 (ref), u13 (copy)
                u4.Overrides[l__Keybind__8] = nil;
                u3:FireServer("UpdateSettings", "Keybind", l__Keybind__8);
                u13:setState({});
            end
        });
    end;
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Position = UDim2.fromScale(0.99, 0.2),
        AnchorPoint = Vector2.new(1, 0),
        Size = UDim2.fromScale(1, 0.6)
    }, { u2.createFragment(v14), u2.createElement("UIListLayout", {
            SortOrder = Enum.SortOrder.LayoutOrder,
            FillDirection = Enum.FillDirection.Horizontal,
            VerticalAlignment = Enum.VerticalAlignment.Center,
            HorizontalAlignment = Enum.HorizontalAlignment.Right,
            Padding = UDim.new(0.01, 0)
        }) });
end;
return v7;