-- Services.InterfaceService.MenuInterface.MenuOptionsComponent.MenuOptionsSliderComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "network");
local u4 = v1("GameShellProxyButton");
local u5 = v1("InputService");
local u6 = v1("SoundService");
local u7 = v1("GameSettings");
local l__RunService__1 = game:GetService("RunService");
local l__UserInputService__2 = game:GetService("UserInputService");
local v8 = u2.Component:extend("MenuDeploy");
function v8.init(u9, u10) --[[ Line: 28 ]]
    -- upvalues: u2 (copy), u6 (copy), u7 (copy), u3 (copy), l__RunService__1 (copy), u5 (copy), l__UserInputService__2 (copy)
    local l__Channel__3 = u10.Channel;
    u9.This = u2.createRef();
    u9.Grabbing = false;
    if l__Channel__3 then
        local v11, v12 = u2.createBinding(u6:GetChannelVolume(l__Channel__3));
        u9.ValueBinding = v11;
        u9.UpdateValue = v12;
    elseif u10.Mode == "Callback" then
        local v13, v14 = u2.createBinding(u10.Setting);
        u9.ValueBinding = v13;
        u9.UpdateValue = v14;
    else
        local v15, v16 = u2.createBinding(u7[u10.Setting]);
        u9.ValueBinding = v15;
        u9.UpdateValue = v16;
    end;
    function u9.SetValue(p17) --[[ Line: 41 ]]
        -- upvalues: u9 (copy), u10 (copy), l__Channel__3 (copy), u6 (ref), u7 (ref), u3 (ref)
        u9.UpdateValue(p17);
        if u10.Mode == "Callback" then
            u10.Callback(p17);
        else
            if l__Channel__3 then
                u6:SetChannelVolume(l__Channel__3, p17);
            end;
            if u10.Mode == "Setting" then
                u7[u10.Setting] = p17;
            end;
            u3:FireServer("UpdateSettings", u10.Mode, l__Channel__3 or u10.Setting, p17);
        end;
    end;
    u9.Update = l__RunService__1.Heartbeat:Connect(function(p18) --[[ Line: 56 ]]
        -- upvalues: u5 (ref), u9 (copy), l__UserInputService__2 (ref), u10 (copy)
        if u5.Gamepad and u9.state.Hovering then
            for _, v19 in l__UserInputService__2:GetGamepadState(u5.Gamepad) do
                if v19.KeyCode == Enum.KeyCode.Thumbstick1 then
                    u9.Grabbing = false;
                    u9:setState({});
                    local l__X__4 = v19.Position.X;
                    if math.abs(l__X__4) > 0.05 then
                        local v20 = u10.Min or 0;
                        local v21 = u10.Max or 2;
                        local v22 = v21 - v20;
                        local v23 = u9.ValueBinding:getValue() + l__X__4 * p18 * v22;
                        local v24 = math.clamp(v23, v20, v21);
                        u9.SetValue(v24);
                    end;
                end;
            end;
        end;
        if u9.Grabbing then
            local v25 = u9.This:getValue();
            if v25 then
                local l__X__5 = v25.AbsolutePosition.X;
                local v26 = l__X__5 + v25.AbsoluteSize.X;
                local l__X__6 = l__UserInputService__2:GetMouseLocation().X;
                local v27 = u10.Min or 0;
                local v28 = math.clamp(v27 + (l__X__6 - l__X__5) / (v26 - l__X__5) * ((u10.Max or 2) - v27), u10.Min or 0, u10.Max or 2);
                u9.SetValue(v28);
            end;
        end;
    end);
    u9.Ended = l__UserInputService__2.InputEnded:Connect(function(p29) --[[ Line: 92 ]]
        -- upvalues: u9 (copy)
        if p29.UserInputType == Enum.UserInputType.MouseButton1 and u9.Grabbing then
            u9.Grabbing = false;
            u9:setState({});
        end;
    end);
    u9.TouchEnded = l__UserInputService__2.TouchEnded:Connect(function(_) --[[ Line: 98 ]]
        -- upvalues: u9 (copy)
        if u9.Grabbing then
            u9.Grabbing = false;
            u9:setState({});
        end;
    end);
    u9:setState({
        Hovering = false
    });
end;
function v8.willUnmount(p30) --[[ Line: 110 ]]
    p30.Update:Disconnect();
    p30.Ended:Disconnect();
    p30.TouchEnded:Disconnect();
end;
function v8.render(u31) --[[ Line: 116 ]]
    -- upvalues: u2 (copy), u4 (copy)
    local l__props__7 = u31.props;
    local v32 = u31.state.Hovering or u31.Grabbing;
    return u2.createElement(u4, {
        BackgroundTransparency = 1,
        Scroller = l__props__7.Scroller,
        AnchorPoint = Vector2.new(1, 0),
        Position = UDim2.fromScale(0.99, 0),
        Size = UDim2.fromScale(0.2, 1),
        Ignore = l__props__7.Ignore,
        Ref = u31.This,
        MouseDown = function() --[[ Name: MouseDown, Line 131 ]]
            -- upvalues: u31 (copy)
            u31.Grabbing = true;
        end,
        MouseEnter = function() --[[ Name: MouseEnter, Line 134 ]]
            -- upvalues: u31 (copy)
            u31:setState({
                Hovering = true
            });
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 139 ]]
            -- upvalues: u31 (copy)
            u31:setState({
                Hovering = false
            });
        end
    }, {
        Grabber = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 3,
            AnchorPoint = Vector2.new(0.5, 0.5),
            BackgroundColor3 = (v32 and Color3.fromRGB(255, 202, 94) or Color3.fromRGB(71, 71, 71)):Lerp(Color3.new(), 0.5),
            Size = UDim2.new(0.03, 0, 0.5, 0),
            Position = u31.ValueBinding:map(function(p33) --[[ Line: 151 ]]
                -- upvalues: l__props__7 (copy)
                local l__new__8 = UDim2.new;
                local v34 = l__props__7.Min or 0;
                return l__new__8((p33 - v34) / ((l__props__7.Max or 2) - v34), 0, 0.5, 0);
            end)
        }, {
            Corner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 1)
            }),
            Stroke = u2.createElement("UIStroke", {
                Thickness = 1,
                ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                Color = v32 and Color3.fromRGB(255, 202, 94) or Color3.fromRGB(71, 71, 71),
                LineJoinMode = Enum.LineJoinMode.Round
            })
        }),
        Slider = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0, 0.5),
            BackgroundColor3 = v32 and Color3.fromRGB(255, 202, 94) or Color3.fromRGB(71, 71, 71),
            Position = UDim2.new(0, 0, 0.5, 0),
            Size = u31.ValueBinding:map(function(p35) --[[ Line: 170 ]]
                -- upvalues: l__props__7 (copy)
                local l__new__9 = UDim2.new;
                local v36 = l__props__7.Min or 0;
                return l__new__9((p35 - v36) / ((l__props__7.Max or 2) - v36), 0, 0, 1);
            end)
        }),
        Black = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 1,
            AnchorPoint = Vector2.new(0, 0.5),
            BackgroundColor3 = Color3.new(),
            Position = UDim2.new(0, 0, 0.5, 0),
            Size = UDim2.new(1, 0, 0.2, 0)
        })
    });
end;
return v8;