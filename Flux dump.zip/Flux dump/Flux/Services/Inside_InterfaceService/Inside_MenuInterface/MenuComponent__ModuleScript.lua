-- Services.InterfaceService.MenuInterface.MenuComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "server");
v1("FlagService");
local u4 = v1("SoundService");
local u5 = v1("PostProcessingService");
local u6 = v1("MenuHeaderComponent");
local u7 = v1({
    "MenuDeployComponent",
    "MenuStoreComponent",
    "MenuPlayersComponent",
    "MenuOptionsComponent",
    "MenuLoadoutComponent",
    "MenuReduxLoadoutComponent",
    "MenuBriefingComponent",
    "MenuPlayComponent"
});
local u8 = v1("RoactTween");
game:GetService("Players");
local u9 = { "Options", "Store" };
local v10 = u2.Component:extend("Menu");
function v10.init(p11, p12) --[[ Line: 30 ]]
    -- upvalues: u4 (copy), u3 (copy), u8 (copy), u5 (copy)
    u4.DiegeticMix.Menu = 0;
    p11.Transparency = u3.MAIN_MENU and 1 or 0;
    p11.Blur = u8.new(0);
    p11.ExpandedTween = p12.ExpandedTween;
    p11._setCamera = p12.SetCamera;
    p11._logoTween = p12.LogoTween;
    p11._moneyBinding = p12.MoneyBinding;
    p11._expBinding = p12.ExpBinding;
    p11._pages = p12.Pages;
    p11.ExpandedTween:SetGoal(1);
    p11.BlurEffect = u5:AddBlur({
        Size = p11.Blur:Map(function(p13) --[[ Line: 46 ]]
            return p13 * 30;
        end)
    }, nil, true);
    p11.DOPEffect = u5:AddDepthOfField({
        FarIntensity = 0.646,
        FocusDistance = 1,
        InFocusRadius = 15,
        NearIntensity = 0,
        AutoFocus = false
    }, 3, true);
    p11:setState({
        Page = p12.Pages[1]
    });
end;
function v10.willUnmount(p14) --[[ Line: 70 ]]
    -- upvalues: u4 (copy)
    u4.DiegeticMix.Menu = 1;
    p14.BlurEffect.Destroy();
    p14.DOPEffect.Destroy();
end;
function v10.render(u15) --[[ Line: 78 ]]
    -- upvalues: u3 (copy), u9 (copy), u2 (copy), u7 (copy), u6 (copy)
    local l__props__1 = u15.props;
    local l__state__2 = u15.state;
    local l__Page__3 = l__state__2.Page;
    local l__MAIN_MENU__4 = u3.MAIN_MENU;
    local l__PopupActive__5 = l__props__1.PopupActive;
    local l__Transparency__6 = u15.Transparency;
    if l__Page__3 == "Loadout" then
        l__Transparency__6 = 1;
    else
        u15.ExpandedTween:SetGoal(1);
    end;
    if l__MAIN_MENU__4 then
        l__props__1.IconsEnabled(not table.find(u9, l__Page__3));
        u15.Blur:SetGoal(table.find(u9, l__Page__3) and 1 or 0);
    end;
    local v16 = l__Page__3 == "Loadout" and "ReduxLoadout" or l__state__2.Page;
    return u2.createFragment({
        Page = u2.createElement("Frame", {
            BorderSizePixel = 0,
            Size = u15.ExpandedTween:Map(function(p17) --[[ Line: 105 ]]
                return UDim2.fromScale(1, 0.94):Lerp(UDim2.fromScale(1, 0.85), p17);
            end),
            Position = u15.ExpandedTween:Map(function(p18) --[[ Line: 108 ]]
                return UDim2.fromScale(0, 0.06):Lerp(UDim2.fromScale(0, 0.15), p18);
            end),
            BackgroundTransparency = l__Transparency__6,
            BackgroundColor3 = Color3.new(0, 0, 0)
        }, u2.createElement(u7["Menu" .. v16 .. "Component"], {
            SetCamera = u15._setCamera,
            UpdateLoadout = l__props__1.UpdateLoadout,
            MatchmakingQueueData = l__props__1.MatchmakingQueueData,
            PrivateServerData = l__props__1.PrivateServerData,
            PopupActive = l__PopupActive__5,
            Offset = u15.ExpandedTween:GetGoal() == 1 and 0.15 or 0.0555,
            Pages = u15._pages,
            ChangePage = function(p19) --[[ Name: ChangePage, Line 122 ]]
                -- upvalues: u15 (copy)
                u15:setState({
                    Page = p19
                });
            end
        })),
        Header = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 2,
            Size = UDim2.fromScale(1, 0.15),
            BackgroundTransparency = l__Transparency__6,
            BackgroundColor3 = Color3.new(0, 0, 0),
            Position = u15.ExpandedTween:Map(function(p20) --[[ Line: 133 ]]
                return UDim2.fromScale(0, -(1 - p20) * 0.7 * 0.15);
            end)
        }, u2.createElement(u6, {
            LogoTween = u15._logoTween,
            MoneyBinding = u15._moneyBinding,
            ExpBinding = u15._expBinding,
            PopupActive = l__PopupActive__5,
            ExpandedTween = u15.ExpandedTween,
            MatchmakingQueueData = l__props__1.MatchmakingQueueData,
            Page = l__state__2.Page,
            Pages = u15._pages,
            ChangePage = function(p21) --[[ Name: ChangePage, Line 148 ]]
                -- upvalues: u15 (copy)
                u15:setState({
                    Page = p21
                });
            end
        }))
    });
end;
return v10;