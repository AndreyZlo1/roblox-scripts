-- Services.InterfaceService.MenuInterface.MenuButtonComponentOld
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local u3 = v1("GameShellProxyButton");
local u4 = v1("GameShellProxyTextLabel");
local l__RunService__1 = game:GetService("RunService");
local v5 = u2.Component:extend("MenuButton");
local u6 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
function v5.init(p7) --[[ Line: 13 ]]
    -- upvalues: u2 (copy)
    local v8, v9 = u2.createBinding(0);
    p7.Rotation = v8;
    p7.UpdateRotation = v9;
    p7:setState({
        Hovering = false
    });
end;
function v5.willUnmount(p10) --[[ Line: 21 ]]
    if p10.ConnectionRotation then
        p10.ConnectionRotation:Disconnect();
    end;
end;
function v5.render(u11) --[[ Line: 27 ]]
    -- upvalues: l__RunService__1 (copy), u2 (copy), u3 (copy), u4 (copy), u6 (copy)
    local l__props__2 = u11.props;
    local l__state__3 = u11.state;
    local l__Name__4 = l__props__2.Name;
    local l__Image__5 = l__props__2.Image;
    local l__Activated__6 = l__props__2.Activated;
    local l__Hovering__7 = l__state__3.Hovering;
    local l__MountTextLabelCalls__8 = l__props__2.MountTextLabelCalls;
    local l__NameChildren__9 = l__props__2.NameChildren;
    local v12;
    if type(l__Activated__6) == "table" and l__Activated__6.getValue then
        v12 = l__Activated__6:map(function(p13) --[[ Line: 40 ]]
            -- upvalues: l__Hovering__7 (copy)
            return p13 and Color3.fromRGB(255, 194, 89) or (l__Hovering__7 and Color3.new(1, 1, 1) or Color3.fromRGB(71, 71, 71));
        end);
    else
        v12 = l__Activated__6 and Color3.fromRGB(255, 194, 89) or (l__Hovering__7 and Color3.new(1, 1, 1) or Color3.fromRGB(71, 71, 71));
    end;
    if l__props__2.Loading then
        if u11.ConnectionRotation == nil then
            u11.ConnectionRotation = l__RunService__1.Heartbeat:Connect(function(p14) --[[ Line: 49 ]]
                -- upvalues: u11 (copy)
                u11.UpdateRotation(u11.Rotation:getValue() - p14 * 400);
            end);
        end;
    elseif u11.ConnectionRotation then
        u11.ConnectionRotation:Disconnect();
        u11.ConnectionRotation = nil;
    end;
    local l__createElement__10 = u2.createElement;
    local v15 = u3;
    local v16 = {
        Image = "rbxassetid://13867926930",
        BorderSizePixel = 0,
        SoundKit = "MainMenu",
        TileSize = UDim2.fromOffset(64, 64),
        ScaleType = Enum.ScaleType.Tile,
        ImageColor3 = v12,
        LayoutOrder = l__props__2.Layout or l__props__2.LayoutOrder,
        SizeConstraint = l__props__2.SizeConstraint,
        Ref = l__props__2[u2.Ref],
        Scroller = l__props__2.Scroller,
        Ignore = l__props__2.Ignore,
        Size = l__props__2.Size,
        Position = l__props__2.Position,
        ZIndex = l__props__2.ZIndex,
        AnchorPoint = l__props__2.AnchorPoint,
        MouseUp = function() --[[ Name: MouseUp, Line 77 ]]
            -- upvalues: l__props__2 (copy)
            l__props__2.Callback();
        end,
        MouseEnter = function() --[[ Name: MouseEnter, Line 80 ]]
            -- upvalues: u11 (copy)
            u11:setState({
                Hovering = true
            });
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 85 ]]
            -- upvalues: u11 (copy)
            u11:setState({
                Hovering = false
            });
        end
    };
    local v17 = {
        u2.createFragment(l__props__2[u2.Children]),
        Corner = u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 1)
        }),
        Gradient = u2.createElement("UIGradient", {
            Rotation = 0,
            Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(112, 112, 112)), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(54, 54, 54)), ColorSequenceKeypoint.new(1, Color3.fromRGB(112, 112, 112)) })
        }),
        Stroke = u2.createElement("UIStroke", {
            Thickness = 1,
            ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
            Color = v12,
            LineJoinMode = Enum.LineJoinMode.Round
        })
    };
    if l__Name__4 then
        local l__createElement__11 = u2.createElement;
        local v18 = l__MountTextLabelCalls__8 and u4 or "TextLabel";
        local v19 = {
            BackgroundTransparency = 1,
            TextScaled = true,
            Size = UDim2.fromScale(1, 0.6),
            AnchorPoint = Vector2.new(0.5, 0),
            Position = UDim2.fromScale(0.5, 0.2)
        };
        if l__props__2.Loading then
            l__Name__4 = "";
        elseif typeof(l__Name__4) == "string" then
            l__Name__4 = l__Name__4:upper() or l__Name__4;
        end;
        v19.Text = l__Name__4;
        v19.TextColor3 = v12;
        v19.FontFace = u6;
        v19.TextXAlignment = Enum.TextXAlignment.Center;
        v19.DidMount = l__MountTextLabelCalls__8 or nil;
        l__Name__4 = l__createElement__11(v18, v19, l__NameChildren__9);
    end;
    if l__Image__5 then
        l__Image__5 = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(1, l__props__2.ImageY or 1),
            Position = UDim2.fromScale(0.5, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5),
            ImageColor3 = v12,
            ScaleType = Enum.ScaleType.Fit,
            Image = l__props__2.Loading and "" or l__Image__5
        });
    end;
    local l__Loading__12 = l__props__2.Loading;
    if l__Loading__12 then
        l__Loading__12 = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://15478256777",
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = UDim2.fromScale(0.6, 0.6),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            Rotation = u11.Rotation,
            ImageColor3 = v12
        });
    end;
    v17[2], v17[3], v17[4] = l__Name__4, l__Image__5, l__Loading__12;
    return l__createElement__10(v15, v16, v17);
end;
return v5;