-- Services.InterfaceService.MenuInterface.MenuLoadoutComponent.MenuLoadoutAttachmentSelectionInfoComponent.TerminalPerformanceGraphComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "asset");
v1("Menu");
local u3 = v1("GameSettings");
local u4 = v1("BulletService");
v1("GameShellProxyButton");
v1("GameShellProxyTextLabel");
local v5 = u2.Component:extend("TerminalPerformanceGraphComponent");
Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u6 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u7 = {
    Head = { Color3.fromRGB(255, 59, 59), UDim2.fromScale(0.25, 0.2) },
    Torso = { Color3.fromRGB(233, 80, 195), UDim2.fromScale(0.5, 0.4) },
    Arms = { Color3.fromRGB(185, 159, 41), UDim2.fromScale(0.25, 0.4) },
    Legs = { Color3.fromRGB(255, 150, 89), UDim2.fromScale(0.25, 0.4) }
};
local function u10(p8) --[[ Line: 29 ]]
    -- upvalues: u7 (copy), u2 (copy)
    local v9 = u7[p8.Part];
    return u2.createElement("Frame", {
        BackgroundTransparency = 0.6,
        BorderSizePixel = 0,
        ZIndex = 6,
        BackgroundColor3 = v9[1],
        Size = v9[2],
        Position = p8.Position,
        AnchorPoint = p8.AnchorPoint
    }, { u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 1)
        }), u2.createElement("Frame", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.new(0.5, 0, 0.5, 0),
            Size = UDim2.new(1, -2, 1, -2)
        }, { u2.createElement("UIStroke", {
                Thickness = 0.6,
                Transparency = 0,
                Color = v9[1]
            }), u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 1)
            }) }) });
end;
local function u19(p11) --[[ Line: 62 ]]
    -- upvalues: u4 (copy), u2 (copy), u7 (copy), u6 (copy)
    local l__Caliber__1 = p11.Caliber;
    local l__OldCaliber__2 = p11.OldCaliber;
    local l__CaliberOffset__3 = p11.CaliberOffset;
    local l__OldCaliberOffset__4 = p11.OldCaliberOffset;
    local v12 = u4:GetDamageGraph(0, l__CaliberOffset__3, l__Caliber__1.Damage, l__Caliber__1.Dropoff, l__Caliber__1.Damp or 1, p11.Part);
    local v13;
    if l__OldCaliber__2 then
        v13 = u4:GetDamageGraph(0, l__OldCaliberOffset__4, l__OldCaliber__2.Damage, l__OldCaliber__2.Dropoff, l__OldCaliber__2.Damp or 1, p11.Part) or v12;
    else
        v13 = v12;
    end;
    local l__createElement__5 = u2.createElement;
    local v14 = "Frame";
    local v15 = {
        BackgroundTransparency = 1,
        Size = p11.Size,
        AnchorPoint = p11.AnchorPoint,
        Position = p11.Position
    };
    local v16 = {};
    local v17 = u2.createElement("TextLabel", {
        TextScaled = true,
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 0.5, 0),
        Position = UDim2.fromScale(0, 0.5),
        Text = math.ceil(v12),
        TextColor3 = u7[p11.Part][1],
        FontFace = u6,
        TextXAlignment = Enum.TextXAlignment.Center,
        TextYAlignment = Enum.TextYAlignment.Center
    });
    local v18;
    if v12 == v13 then
        v18 = false;
    else
        v18 = u2.createElement("TextLabel", {
            TextScaled = true,
            BackgroundTransparency = 1,
            Size = UDim2.new(1, 0, 0.4, 0),
            Position = UDim2.fromScale(0, 0.15),
            Text = math.ceil(v13),
            TextColor3 = u7[p11.Part][1]:Lerp(Color3.new(), 0.4),
            FontFace = u6,
            TextXAlignment = Enum.TextXAlignment.Center,
            TextYAlignment = Enum.TextYAlignment.Center
        });
    end;
    v16[1], v16[2] = v17, v18;
    return l__createElement__5(v14, v15, v16);
end;
function v5.init(p20) --[[ Line: 103 ]]
    -- upvalues: u2 (copy)
    p20.PathRefs = {
        New = {
            Head = u2.createRef(),
            Torso = u2.createRef(),
            Arms = u2.createRef(),
            Legs = u2.createRef()
        },
        Old = {
            Head = u2.createRef(),
            Torso = u2.createRef(),
            Arms = u2.createRef(),
            Legs = u2.createRef()
        }
    };
end;
local function u44(p21) --[[ Line: 120 ]]
    -- upvalues: u4 (copy)
    local l__props__6 = p21.props;
    local l__Caliber__7 = l__props__6.Caliber;
    local l__CaliberRange__8 = l__props__6.CaliberRange;
    local l__CaliberOffset__9 = l__props__6.CaliberOffset;
    local l__AppliedMaxDistance__10 = p21.AppliedMaxDistance;
    local l__AppliedMaxDamage__11 = p21.AppliedMaxDamage;
    local v22 = l__CaliberRange__8 / l__Caliber__7.Dropoff[#l__Caliber__7.Dropoff];
    local v23 = {
        Head = {},
        Arms = {},
        Legs = {},
        Torso = {}
    };
    for v24 = 1, #l__Caliber__7.Dropoff do
        local v25 = l__Caliber__7.Dropoff[v24] * v22;
        local v26 = u4:GetDamageGraph(v25, l__CaliberOffset__9, l__Caliber__7.Damage, l__Caliber__7.Dropoff, l__Caliber__7.Damp or 1, "Head");
        local v27 = u4:GetDamageGraph(v25, l__CaliberOffset__9, l__Caliber__7.Damage, l__Caliber__7.Dropoff, l__Caliber__7.Damp or 1, "Arms");
        local v28 = u4:GetDamageGraph(v25, l__CaliberOffset__9, l__Caliber__7.Damage, l__Caliber__7.Dropoff, l__Caliber__7.Damp or 1, "Legs");
        local v29 = u4:GetDamageGraph(v25, l__CaliberOffset__9, l__Caliber__7.Damage, l__Caliber__7.Dropoff, l__Caliber__7.Damp or 1, "Torso");
        local v30 = v25 / l__AppliedMaxDistance__10;
        v23.Head[v24] = Path2DControlPoint.new(UDim2.fromScale(v30, 1 - v26 / l__AppliedMaxDamage__11));
        v23.Arms[v24] = Path2DControlPoint.new(UDim2.fromScale(v30, 1 - v27 / l__AppliedMaxDamage__11));
        v23.Legs[v24] = Path2DControlPoint.new(UDim2.fromScale(v30, 1 - v28 / l__AppliedMaxDamage__11));
        v23.Torso[v24] = Path2DControlPoint.new(UDim2.fromScale(v30, 1 - v29 / l__AppliedMaxDamage__11));
    end;
    for v31, v32 in p21.PathRefs.New do
        v32:getValue():SetControlPoints(v23[v31]);
    end;
    local l__OldCaliber__12 = l__props__6.OldCaliber;
    local l__OldCaliberRange__13 = l__props__6.OldCaliberRange;
    local l__OldCaliberOffset__14 = l__props__6.OldCaliberOffset;
    local v33 = l__OldCaliberRange__13 / l__OldCaliber__12.Dropoff[#l__OldCaliber__12.Dropoff];
    local v34 = {
        Head = {},
        Arms = {},
        Legs = {},
        Torso = {}
    };
    for v35 = 1, #l__Caliber__7.Dropoff do
        local v36 = l__OldCaliber__12.Dropoff[v35] * v33;
        local v37 = u4:GetDamageGraph(v36, l__OldCaliberOffset__14, l__OldCaliber__12.Damage, l__OldCaliber__12.Dropoff, l__OldCaliber__12.Damp or 1, "Head");
        local v38 = u4:GetDamageGraph(v36, l__OldCaliberOffset__14, l__OldCaliber__12.Damage, l__OldCaliber__12.Dropoff, l__OldCaliber__12.Damp or 1, "Arms");
        local v39 = u4:GetDamageGraph(v36, l__OldCaliberOffset__14, l__OldCaliber__12.Damage, l__OldCaliber__12.Dropoff, l__OldCaliber__12.Damp or 1, "Legs");
        local v40 = u4:GetDamageGraph(v36, l__OldCaliberOffset__14, l__OldCaliber__12.Damage, l__OldCaliber__12.Dropoff, l__OldCaliber__12.Damp or 1, "Torso");
        local v41 = v36 / l__AppliedMaxDistance__10;
        v34.Head[v35] = Path2DControlPoint.new(UDim2.fromScale(v41, 1 - v37 / l__AppliedMaxDamage__11));
        v34.Arms[v35] = Path2DControlPoint.new(UDim2.fromScale(v41, 1 - v38 / l__AppliedMaxDamage__11));
        v34.Legs[v35] = Path2DControlPoint.new(UDim2.fromScale(v41, 1 - v39 / l__AppliedMaxDamage__11));
        v34.Torso[v35] = Path2DControlPoint.new(UDim2.fromScale(v41, 1 - v40 / l__AppliedMaxDamage__11));
    end;
    for v42, v43 in p21.PathRefs.Old do
        v43:getValue():SetControlPoints(v34[v42]);
    end;
end;
function v5.didMount(p45) --[[ Line: 209 ]]
    -- upvalues: u44 (copy)
    u44(p45);
end;
function v5.didUpdate(p46) --[[ Line: 213 ]]
    -- upvalues: u44 (copy)
    u44(p46);
end;
function v5.render(p47) --[[ Line: 217 ]]
    -- upvalues: u4 (copy), u3 (copy), u2 (copy), u6 (copy), u7 (copy), u10 (copy), u19 (copy)
    local l__props__15 = p47.props;
    local l__Caliber__16 = l__props__15.Caliber;
    local l__OldCaliber__17 = l__props__15.OldCaliber;
    local l__CaliberRange__18 = l__props__15.CaliberRange;
    local l__OldCaliberRange__19 = l__props__15.OldCaliberRange;
    local l__CaliberOffset__20 = l__props__15.CaliberOffset;
    local l__OldCaliberOffset__21 = l__props__15.OldCaliberOffset;
    local v48 = math.max(l__CaliberRange__18, l__OldCaliberRange__19);
    local v49 = u4:GetDamageGraph(0.01, l__CaliberOffset__20, l__Caliber__16.Damage, l__Caliber__16.Dropoff, l__Caliber__16.Damp or 1, "Head");
    local v50 = math.max(v49, u4:GetDamageGraph(0.01, l__OldCaliberOffset__21, l__OldCaliber__17.Damage, l__OldCaliber__17.Dropoff, l__OldCaliber__17.Damp or 1, "Head"));
    p47.AppliedMaxDistance = v48;
    p47.AppliedMaxDamage = v50;
    p47.MaxDistance = v48;
    p47.MaxDamage = v50;
    p47.LastAppliedMaxDistance = v48;
    p47.LastAppliedMaxDamage = v50;
    local v51 = {};
    local v52 = {};
    local v53 = {};
    local v54 = {};
    local l__MeasurementUnit__22 = u3.MeasurementUnit;
    if l__MeasurementUnit__22 then
        l__MeasurementUnit__22 = u3.MeasurementUnit == 2;
    end;
    for v55 = 0, 7 do
        local v56 = v55 / 7 * p47.AppliedMaxDistance;
        if not l__MeasurementUnit__22 then
            v56 = v56 / 3.281;
        end;
        local v57 = math.round(v56);
        v51[v55] = u2.createElement("TextLabel", {
            TextScaled = true,
            BackgroundTransparency = 1,
            Size = UDim2.new(0.3, 0, 1, 0),
            Position = UDim2.fromScale(v55 / 7, 0),
            AnchorPoint = Vector2.new(0.5, 0),
            Text = v57,
            TextColor3 = Color3.new(0.545098, 0.545098, 0.545098),
            FontFace = u6,
            TextXAlignment = Enum.TextXAlignment.Center,
            TextYAlignment = Enum.TextYAlignment.Top
        });
        v53[v55] = u2.createElement("Frame", {
            BorderSizePixel = 0,
            Size = UDim2.new(0, 1, 1, 0),
            Position = UDim2.fromScale(v55 / 7, 0),
            AnchorPoint = Vector2.new(0.5, 0),
            BackgroundColor3 = v55 == 0 and Color3.new(0.792157, 0.792157, 0.792157) or Color3.new(0.305882, 0.305882, 0.305882),
            ZIndex = v55 == 0 and 5 or 2
        });
    end;
    for v58 = 0, 3 do
        local v59 = math.round(v58 / 3 * p47.AppliedMaxDamage);
        v52[v58] = u2.createElement("TextLabel", {
            TextScaled = true,
            BackgroundTransparency = 1,
            Size = UDim2.new(1, 0, 1, 0),
            SizeConstraint = Enum.SizeConstraint.RelativeXX,
            Position = UDim2.fromScale(0, 1 - v58 / 3),
            AnchorPoint = Vector2.new(0, 0.5),
            Text = v59,
            TextColor3 = Color3.new(0.545098, 0.545098, 0.545098),
            FontFace = u6,
            TextXAlignment = Enum.TextXAlignment.Right,
            TextYAlignment = Enum.TextYAlignment.Center
        });
        v54[v58] = u2.createElement("Frame", {
            BorderSizePixel = 0,
            Size = UDim2.new(1, 0, 0, 1),
            Position = UDim2.fromScale(0, 1 - v58 / 3),
            AnchorPoint = Vector2.new(0, 0.5),
            BackgroundColor3 = v58 == 0 and Color3.new(0.792157, 0.792157, 0.792157) or Color3.new(0.305882, 0.305882, 0.305882),
            ZIndex = v58 == 0 and 5 or 2
        });
    end;
    local v60 = {
        u2.createElement("Path2D", {
            Thickness = 1,
            Color3 = u7.Head[1],
            [u2.Ref] = p47.PathRefs.New.Head,
            ZIndex = 4
        }),
        u2.createElement("Path2D", {
            Thickness = 1,
            Color3 = u7.Arms[1],
            [u2.Ref] = p47.PathRefs.New.Arms,
            ZIndex = 4
        }),
        u2.createElement("Path2D", {
            Thickness = 1,
            Color3 = u7.Legs[1],
            [u2.Ref] = p47.PathRefs.New.Legs,
            ZIndex = 4
        }),
        u2.createElement("Path2D", {
            Thickness = 1,
            Color3 = u7.Torso[1],
            [u2.Ref] = p47.PathRefs.New.Torso,
            ZIndex = 4
        }),
        u2.createElement("Path2D", {
            Thickness = 1,
            Color3 = u7.Head[1]:Lerp(Color3.new(), 0.4),
            [u2.Ref] = p47.PathRefs.Old.Head,
            ZIndex = 3
        }),
        u2.createElement("Path2D", {
            Thickness = 1,
            Color3 = u7.Arms[1]:Lerp(Color3.new(), 0.4),
            [u2.Ref] = p47.PathRefs.Old.Arms,
            ZIndex = 3
        }),
        u2.createElement("Path2D", {
            Thickness = 1,
            Color3 = u7.Legs[1]:Lerp(Color3.new(), 0.4),
            [u2.Ref] = p47.PathRefs.Old.Legs,
            ZIndex = 3
        }),
        u2.createElement("Path2D", {
            Thickness = 1,
            Color3 = u7.Torso[1]:Lerp(Color3.new(), 0.4),
            [u2.Ref] = p47.PathRefs.Old.Torso,
            ZIndex = 3
        })
    };
    return u2.createFragment({ u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.new(1, 0, 0.8, 0),
            Position = UDim2.fromScale(0, 0.19)
        }, {
            YLabel = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.new(0.1, 0, 1, 0),
                SizeConstraint = Enum.SizeConstraint.RelativeYY
            }, { u2.createElement("TextLabel", {
                    Rotation = -90,
                    Text = "DAMAGE (HITPOINTS)",
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Position = UDim2.fromScale(0.5, 0.45),
                    TextColor3 = Color3.new(1, 1, 1),
                    FontFace = u6,
                    TextXAlignment = Enum.TextXAlignment.Center,
                    SizeConstraint = Enum.SizeConstraint.RelativeYY,
                    Size = UDim2.fromScale(1, 0.1)
                }) }),
            XLabel = u2.createElement("TextLabel", {
                TextScaled = true,
                BackgroundTransparency = 1,
                Position = UDim2.fromScale(0.5, 1),
                AnchorPoint = Vector2.new(0.5, 1),
                Text = "DISTANCE (" .. (l__MeasurementUnit__22 and "FEET" or "METERS") .. ")",
                Size = UDim2.new(1, 0, 0.1, 0),
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u6,
                TextXAlignment = Enum.TextXAlignment.Center
            }),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.new(0.92, 0, 0.89, 0),
                AnchorPoint = Vector2.new(1, 0),
                Position = UDim2.new(0.97, 0, 0, 0)
            }, { u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Position = UDim2.fromScale(1, 1),
                    Size = UDim2.fromScale(0.92, 0.15),
                    AnchorPoint = Vector2.new(1, 1)
                }, v51), u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Size = UDim2.fromScale(0.15, 0.85),
                    SizeConstraint = Enum.SizeConstraint.RelativeYY
                }, v52), u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Size = UDim2.fromScale(0.92, 0.85),
                    Position = UDim2.fromScale(1, 0),
                    AnchorPoint = Vector2.new(1, 0)
                }, { u2.createFragment(v53), u2.createFragment(v54), u2.createFragment(v60) }) })
        }), u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Position = UDim2.new(0.13, 0, -0.05, 0),
            AnchorPoint = Vector2.new(0, 0),
            Size = UDim2.fromScale(0.8, 0.19)
        }, {
            BodyPartsDisplay = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ZIndex = 6,
                Size = UDim2.fromScale(0.6, 1),
                Position = UDim2.fromScale(0, 0),
                AnchorPoint = Vector2.new(0, 0),
                SizeConstraint = Enum.SizeConstraint.RelativeYY
            }, {
                u2.createElement(u10, {
                    Part = "Head",
                    Position = UDim2.fromScale(0.5, 0),
                    AnchorPoint = Vector2.new(0.5, 0)
                }),
                u2.createElement(u10, {
                    Part = "Torso",
                    Position = UDim2.fromScale(0.5, 0.4),
                    AnchorPoint = Vector2.new(0.5, 0.5)
                }),
                u2.createElement(u10, {
                    Part = "Arms",
                    Position = UDim2.fromScale(0, 0.2),
                    AnchorPoint = Vector2.new(0, 0)
                }),
                u2.createElement(u10, {
                    Part = "Arms",
                    Position = UDim2.fromScale(1, 0.2),
                    AnchorPoint = Vector2.new(1, 0)
                }),
                u2.createElement(u10, {
                    Part = "Legs",
                    Position = UDim2.fromScale(0.25, 1),
                    AnchorPoint = Vector2.new(0, 1)
                }),
                u2.createElement(u10, {
                    Part = "Legs",
                    Position = UDim2.fromScale(0.75, 1),
                    AnchorPoint = Vector2.new(1, 1)
                })
            }),
            u2.createElement(u19, {
                Part = "Head",
                Position = UDim2.fromScale(0.12, 0),
                AnchorPoint = Vector2.new(0, 0),
                Size = UDim2.fromScale(0.2, 1),
                Caliber = l__Caliber__16,
                OldCaliber = l__OldCaliber__17,
                CaliberOffset = l__CaliberOffset__20,
                OldCaliberOffset = l__OldCaliberOffset__21
            }),
            u2.createElement(u19, {
                Part = "Torso",
                Position = UDim2.fromScale(0.27, 0),
                AnchorPoint = Vector2.new(0, 0),
                Size = UDim2.fromScale(0.2, 1),
                Caliber = l__Caliber__16,
                OldCaliber = l__OldCaliber__17,
                CaliberOffset = l__CaliberOffset__20,
                OldCaliberOffset = l__OldCaliberOffset__21
            }),
            u2.createElement(u19, {
                Part = "Arms",
                Position = UDim2.fromScale(0.42, 0),
                AnchorPoint = Vector2.new(0, 0),
                Size = UDim2.fromScale(0.2, 1),
                Caliber = l__Caliber__16,
                OldCaliber = l__OldCaliber__17,
                CaliberOffset = l__CaliberOffset__20,
                OldCaliberOffset = l__OldCaliberOffset__21
            }),
            u2.createElement(u19, {
                Part = "Legs",
                Position = UDim2.fromScale(0.57, 0),
                AnchorPoint = Vector2.new(0, 0),
                Size = UDim2.fromScale(0.2, 1),
                Caliber = l__Caliber__16,
                OldCaliber = l__OldCaliber__17,
                CaliberOffset = l__CaliberOffset__20,
                OldCaliberOffset = l__OldCaliberOffset__21
            })
        }) });
end;
return v5;