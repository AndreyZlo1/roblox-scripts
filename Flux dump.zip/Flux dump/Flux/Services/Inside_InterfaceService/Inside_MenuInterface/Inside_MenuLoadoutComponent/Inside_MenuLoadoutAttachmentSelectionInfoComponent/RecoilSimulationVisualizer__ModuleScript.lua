-- Services.InterfaceService.MenuInterface.MenuLoadoutComponent.MenuLoadoutAttachmentSelectionInfoComponent.RecoilSimulationVisualizer
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

game:GetService("RunService");
local v1, u2, _ = shared.import("require", "Roact", "asset");
v1("Menu");
v1("Calibers");
v1("BulletService");
v1("GameShellProxyButton");
local u3 = v1("GameShellProxyTextLabel");
local u4 = v1("FirearmInventoryReplicator");
local u5 = v1("Recoiler");
v1("GameShellProxyInput");
local u6 = v1("MenuLoadoutSliderComponent");
local u7 = v1("DebugService");
local u8 = v1("InputService");
local v9 = u2.Component:extend("RecoilSimulationVisualizer");
Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u10 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u11 = 7;
local u12 = 0.08;
local u13 = Color3.fromRGB(105, 52, 52);
local u14 = Color3.fromRGB(52, 70, 110);
local u15 = Color3.fromRGB(243, 70, 70);
local u16 = Color3.fromRGB(48, 113, 252);
local u17 = UDim2.fromOffset(2, 2);
local u18 = Vector2.new(0.5, 0.5);
local u19 = {
    Hip = 1,
    Sight = 2,
    Canted = 3
};
local function u57(p20, p21) --[[ Line: 55 ]]
    -- upvalues: u5 (copy), u4 (copy)
    local v22 = {
        { "Hip", u5.new() }
    };
    local v23 = u4.getMoment(p20);
    local v24 = u4.getADSOffsets(p20);
    if v24 then
        for v25, v26 in v24 do
            local v27 = { v25 == 0 and "Sight" or "Canted", u5.new(), v26.Height };
            table.insert(v22, v27);
        end;
    end;
    local v28 = {};
    for _, v29 in v22 do
        v28[v29[1]] = {
            Camera = {
                {
                    IsDischarge = true,
                    Position = UDim2.fromScale(0.5, 0.8)
                }
            },
            Viewmodel = {
                {
                    IsDischarge = true,
                    Position = UDim2.fromScale(0.5, 0.8)
                }
            }
        };
    end;
    local v30 = 1 / (p21 / 60);
    local v31 = tick() + math.random() * 1000;
    local l__Ammo__1 = p20.Tune.Ammo;
    if not l__Ammo__1 then
        warn("No ammo count");
        l__Ammo__1 = 0;
    end;
    for v32 = 1, l__Ammo__1 + 1 do
        local v33 = v32 == l__Ammo__1 + 1;
        local v34 = v32 == 1;
        for _, v35 in v22 do
            local v36, v37, v38 = table.unpack(v35);
            if not v33 then
                local v39, v40, v41 = u4.getRecoil(p20.Tune, v23, v38, v31);
                v37:Impulse(v39, v40, v41);
            end;
            local v42 = v30 + (v33 and 2 or 0);
            while v42 > 0.001 do
                local v43 = math.min(v42, 0.03125);
                v42 = v42 - v43;
                v37:TimeSkip(v43);
                local v44 = v37:GetViewmodelAdjustment(v43, v38 and 1 or 0);
                local v45, v46 = v37:GetCameraAdjustment(v43, false);
                local v47 = v45 * CFrame.Angles(v46, 0, 0);
                local v48;
                if v42 <= 0.001 then
                    v48 = not v33;
                else
                    v48 = false;
                end;
                local l__LookVector__2 = v44.LookVector;
                local l__LookVector__3 = v47.LookVector;
                local v49 = l__LookVector__2:Dot(Vector3.new(-0, -0, -1));
                local v50 = 1 - math.abs(v49);
                local v51 = l__LookVector__3:Dot(Vector3.new(-0, -0, -1));
                local v52 = 1 - math.abs(v51);
                if v48 or (v50 >= 0.00001 or v52 >= 0.00001) then
                    local v53 = {
                        Position = UDim2.fromScale(l__LookVector__2.X / 0.3 + 0.5, -l__LookVector__2.Y / 0.3 + 0.8)
                    };
                    local v54;
                    if v48 then
                        v54 = not v34;
                    else
                        v54 = v48;
                    end;
                    v53.IsDischarge = v54;
                    local v55 = {
                        Position = UDim2.fromScale(l__LookVector__3.X / 0.3 + 0.5, -l__LookVector__3.Y / 0.3 + 0.8)
                    };
                    if v48 then
                        v48 = not v34;
                    end;
                    v55.IsDischarge = v48;
                    table.insert(v28[v36].Viewmodel, v53);
                    table.insert(v28[v36].Camera, v55);
                elseif v33 then
                    break;
                end;
            end;
        end;
        v31 = v31 + v30;
    end;
    for _, v56 in v22 do
        v56[2]:Destroy();
    end;
    return v28;
end;
local function u59(p58) --[[ Line: 141 ]]
    -- upvalues: u2 (copy), u3 (copy), u10 (copy)
    local l__Order__4 = p58.Order;
    local l__Color__5 = p58.Color;
    local l__Title__6 = p58.Title;
    return u2.createElement(u3, {
        BackgroundTransparency = 1,
        DidMount = p58.ParentSelf.MountTextLabelCalls,
        LayoutOrder = l__Order__4,
        Size = UDim2.fromScale(0.15, 1),
        Text = l__Title__6,
        TextColor3 = Color3.new(1, 1, 1),
        FontFace = u10,
        TextXAlignment = Enum.TextXAlignment.Center
    }, { u2.createElement("Frame", {
            BorderSizePixel = 0,
            Size = UDim2.fromOffset(4, 4),
            BackgroundColor3 = l__Color__5,
            Position = UDim2.new(0, -5, 0.5, 0),
            AnchorPoint = Vector2.new(1, 0.5)
        }, { u2.createElement("UICorner", {
                CornerRadius = UDim.new(1, 0)
            }) }) });
end;
function v9.willUnmount(p60) --[[ Line: 168 ]]
    if p60.UpdateConnect then
        task.cancel(p60.UpdateConnect);
        p60.UpdateConnect = nil;
    end;
end;
local function u73(p61, p62, p63, p64) --[[ Line: 175 ]]
    local v65 = { p61[1] };
    local v66 = 1;
    for v67 = 2, #p61 - 1 do
        local l__Position__7 = p61[v67 - v66].Position;
        local l__Position__8 = p61[v67].Position;
        local l__Position__9 = p61[v67 + 1].Position;
        local v68 = Vector2.new(l__Position__7.X.Scale, l__Position__7.Y.Scale);
        local v69 = Vector2.new(l__Position__8.X.Scale, l__Position__8.Y.Scale);
        local v70 = Vector2.new(l__Position__9.X.Scale, l__Position__9.Y.Scale);
        local v71 = v69 - v68;
        local l__Unit__10 = v71.Unit;
        local l__Unit__11 = (v70 - v69).Unit;
        if l__Unit__10.Magnitude == 0 or l__Unit__11.Magnitude == 0 then
            v66 = v66 + 1;
        else
            local v72 = l__Unit__10:Dot(l__Unit__11);
            if p64 then
                v72 = math.abs(v72);
            end;
            if 1 - p62 <= v72 or v71.Magnitude <= p63 then
                v66 = v66 + 1;
            else
                table.insert(v65, p61[v67]);
                v66 = 1;
            end;
        end;
    end;
    table.insert(v65, p61[#p61]);
    return v65;
end;
local function u85(p74, p75) --[[ Line: 213 ]]
    -- upvalues: u73 (copy), u11 (ref), u12 (ref)
    if p74 then
        local v76 = #p75;
        if #p75 > 100 then
            local v77 = u73;
            local v78 = math.rad(u11);
            p75 = v77(p75, 1 - math.cos(v78), u12, true);
            local v79 = #p75;
            local _ = v76 - v79;
            if v79 > 100 then
                local v80 = 0;
                local v81 = {};
                local v82 = {};
                while v80 < v79 - 100 do
                    local v83 = math.random(2, v79);
                    if not v81[v83] then
                        v81[v83] = true;
                        v80 = v80 + 1;
                    end;
                end;
                p75 = v82;
                for v84 = 1, v79 do
                    if v81[v84] then
                        v82 = p75;
                    else
                        table.insert(p75, p75[v84]);
                        v82 = p75;
                    end;
                    p75 = v82;
                end;
            end;
        end;
        p74:SetControlPoints(p75);
    end;
end;
local function u91(p86) --[[ Line: 253 ]]
    -- upvalues: u85 (copy)
    for v87, v88 in p86.PathRefs.C.Refs do
        u85(v88:getValue(), p86.PathRefs.C.Values[v87]);
    end;
    for v89, v90 in p86.PathRefs.VM.Refs do
        u85(v90:getValue(), p86.PathRefs.VM.Values[v89]);
    end;
end;
function v9.didUpdate(p92) --[[ Line: 268 ]]
    -- upvalues: u91 (copy)
    u91(p92);
end;
function v9.didMount(u93) --[[ Line: 272 ]]
    -- upvalues: u91 (copy), u7 (copy), u11 (ref), u12 (ref)
    u93.UpdateConnect = task.spawn(function() --[[ Line: 274 ]]
        -- upvalues: u93 (copy)
        repeat
            task.wait();
        until u93.props.ShowSelectionInfoPanelTween:GetValue() == 1;
        u93.UpdateConnect = nil;
        for _, v94 in u93.MountTextLabelCalls do
            v94();
        end;
    end);
    u91(u93);
    u7:Slider("Simplify", u11, 0, 50, nil, function(p95) --[[ Line: 289 ]]
        -- upvalues: u11 (ref), u91 (ref), u93 (copy)
        u11 = p95;
        u91(u93);
    end);
    u7:Slider("SimplifyD", u12, 0, 2, nil, function(p96) --[[ Line: 293 ]]
        -- upvalues: u12 (ref), u91 (ref), u93 (copy)
        u12 = p96;
        u91(u93);
    end);
end;
function v9.init(p97) --[[ Line: 299 ]]
    -- upvalues: u2 (copy)
    local v98, v99 = u2.createBinding("0");
    p97.RPMBinding = v98;
    p97.UpdRPMBinding = v99;
    p97.MountTextLabelCalls = {};
    p97.PathRefs = {
        C = {
            Refs = {},
            Values = {}
        },
        VM = {
            Refs = {},
            Values = {}
        }
    };
end;
function v9.render(u100) --[[ Line: 314 ]]
    -- upvalues: u57 (copy), u2 (copy), u15 (copy), u17 (copy), u18 (copy), u16 (copy), u19 (copy), u13 (copy), u14 (copy), u10 (copy), u59 (copy), u6 (copy), u8 (copy)
    local l__props__12 = u100.props;
    local _ = u100.state;
    local l__NewTune__13 = l__props__12.NewTune;
    local l__NewBaseComponent__14 = l__props__12.NewBaseComponent;
    local v101 = u100.RPMOverride or l__NewTune__13.RPM;
    u100.RPMOverride = nil;
    local l__RPM__15 = l__NewTune__13.RPM;
    local v102 = math.min(30, l__RPM__15 - 5);
    local v103 = math.clamp(v101, v102, l__RPM__15);
    u100.UpdRPMBinding((tostring(v103)));
    local v104 = {};
    for v105, v106 in { u57(l__NewBaseComponent__14, v103) } do
        for v107, v108 in v106 do
            local v109 = v107 .. tostring(v105);
            v104[v109] = v104[v109] or {};
            table.insert(v104[v109], v108);
        end;
    end;
    local v110 = 0;
    for _, _ in v104 do
        v110 = v110 + 1;
    end;
    u100.Groups = v104;
    u100.PathRefs.VM.Refs = {};
    u100.PathRefs.C.Refs = {};
    u100.PathRefs.VM.Values = {};
    u100.PathRefs.C.Values = {};
    local v111 = {};
    for v112, v113 in v104 do
        u100.PathRefs.VM.Refs[v112] = u2.createRef();
        u100.PathRefs.C.Refs[v112] = u2.createRef();
        u100.PathRefs.VM.Values[v112] = {};
        u100.PathRefs.C.Values[v112] = {};
        local v114 = {};
        for _, v115 in v113 do
            for v116 = 1, #v115.Viewmodel do
                local v117 = v115.Viewmodel[v116];
                if v117.IsDischarge then
                    table.insert(v114, u2.createElement("Frame", {
                        BorderSizePixel = 0,
                        ZIndex = 4,
                        BackgroundColor3 = u15,
                        Size = u17,
                        Position = v117.Position,
                        AnchorPoint = u18
                    }));
                end;
                table.insert(u100.PathRefs.VM.Values[v112], Path2DControlPoint.new(v117.Position));
            end;
            for v118 = 1, #v115.Camera do
                local v119 = v115.Camera[v118];
                if v119.IsDischarge then
                    table.insert(v114, u2.createElement("Frame", {
                        BorderSizePixel = 0,
                        ZIndex = 3,
                        BackgroundColor3 = u16,
                        Size = u17,
                        Position = v119.Position,
                        AnchorPoint = u18
                    }));
                end;
                table.insert(u100.PathRefs.C.Values[v112], Path2DControlPoint.new(v119.Position));
            end;
        end;
        v111[v112] = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            LayoutOrder = u19[v112],
            Size = UDim2.new(1, 0, 1, 0),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }, {
            u2.createFragment(v114),
            u2.createElement("Path2D", {
                Thickness = 1,
                ZIndex = 2,
                Color3 = u13,
                [u2.Ref] = u100.PathRefs.VM.Refs[v112]
            }),
            u2.createElement("Path2D", {
                Thickness = 1,
                ZIndex = 1,
                Color3 = u14,
                [u2.Ref] = u100.PathRefs.C.Refs[v112]
            }),
            u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }),
            u2.createElement("UIStroke", {
                Thickness = 1,
                Color = Color3.fromRGB(43, 43, 43)
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Position = UDim2.new(0, 0, 1, -2),
                AnchorPoint = Vector2.new(0, 1),
                Text = string.upper(v112),
                FontFace = u10,
                TextColor3 = Color3.new(0.721569, 0.721569, 0.721569),
                Size = UDim2.new(1, 0, 0.13, 0)
            })
        });
    end;
    v111[-1] = u2.createElement("UIListLayout", {
        FillDirection = Enum.FillDirection.Horizontal,
        HorizontalAlignment = Enum.HorizontalAlignment.Center,
        VerticalAlignment = Enum.VerticalAlignment.Bottom,
        SortOrder = Enum.SortOrder.LayoutOrder,
        Padding = UDim.new(0, 5)
    });
    return u2.createFragment({ u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.new(1, 0, 0.74, 0),
            Position = UDim2.fromScale(0, 0.1)
        }, v111), u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.new(1, 0, 0.105, 0),
            Position = UDim2.new(0, 0, 0, -2)
        }, {
            u2.createElement("UIListLayout", {
                FillDirection = Enum.FillDirection.Horizontal,
                HorizontalAlignment = Enum.HorizontalAlignment.Center,
                VerticalAlignment = Enum.VerticalAlignment.Center,
                SortOrder = Enum.SortOrder.LayoutOrder,
                Padding = UDim.new(0.05, 5)
            }),
            u2.createElement(u59, {
                Order = 1,
                Title = "Camera",
                Color = u14,
                ParentSelf = u100
            }),
            u2.createElement(u59, {
                Order = 2,
                Title = "Discharge",
                Color = u16,
                ParentSelf = u100
            }),
            u2.createElement(u59, {
                Order = 3,
                Title = "Viewmodel",
                Color = u13,
                ParentSelf = u100
            }),
            u2.createElement(u59, {
                Order = 4,
                Title = "Discharge",
                Color = u15,
                ParentSelf = u100
            })
        }), u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.new(1, 0, 0.15, 0),
            Position = UDim2.new(0, 0, 0.86, 0)
        }, { u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.new(0.8, 0, 1, 0),
                Position = UDim2.new(0.15, 0, 0, 0)
            }, { u2.createElement(u6, {
                    Increment = 1,
                    InitialValue = l__RPM__15,
                    Callback = function(p120) --[[ Name: Callback, Line 507 ]]
                        -- upvalues: u100 (copy)
                        u100.RPMOverride = p120;
                        u100:setState({});
                    end,
                    Min = v102,
                    Max = l__RPM__15,
                    Ignore = l__props__12.Ignore or u8.Gamepad
                }) }), u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Text = tostring(v103),
                FontFace = u10,
                TextColor3 = Color3.new(0.721569, 0.721569, 0.721569),
                Size = UDim2.new(0.1, 0, 1, 0)
            }) }) });
end;
return v9;