-- Services.InterfaceService.MenuInterface.MenuLoadoutComponent.MenuLoadoutAttachmentListComponent.MenuLoadoutAttachmentSearchBar
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "asset");
v1("GameShellProxyButton");
local u3 = v1("GameShellProxyInput");
local v4 = u2.Component:extend("MenuLoadoutAttachmentSearchBar");
Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u5 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
function v4.init(p6, _) --[[ Line: 11 ]]
    -- upvalues: u2 (copy)
    local v7, v8 = u2.createBinding("");
    p6.Text = v7;
    p6.UpdText = v8;
end;
function v4.render(u9) --[[ Line: 15 ]]
    -- upvalues: u2 (copy), u3 (copy), u5 (copy)
    local l__props__1 = u9.props;
    local l__Size__2 = l__props__1.Size;
    local l__Position__3 = l__props__1.Position;
    local l__Ignore__4 = l__props__1.Ignore;
    local l__Callback__5 = l__props__1.Callback;
    return u2.createElement("Frame", {
        BorderSizePixel = 0,
        BackgroundTransparency = 0.5,
        Size = l__Size__2,
        Position = l__Position__3,
        BackgroundColor3 = Color3.new(0, 0, 0)
    }, {
        u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 4)
        }),
        Search = u2.createElement(u3, {
            BackgroundTransparency = 1,
            PlaceholderText = "SEARCH",
            ClearTextOnFocus = true,
            Position = UDim2.fromScale(0.01, 0),
            Size = UDim2.fromScale(0.9, 1),
            FontFace = u5,
            TextXAlignment = Enum.TextXAlignment.Left,
            TextBind = u9.Text,
            TextBindUpdate = function(p10) --[[ Name: TextBindUpdate, Line 42 ]]
                -- upvalues: u9 (copy), l__Callback__5 (copy)
                if #p10 > 30 then
                    p10 = u9.Text:getValue();
                end;
                u9.UpdText(p10);
                l__Callback__5(p10);
            end,
            Ignore = l__Ignore__4
        })
    });
end;
return v4;