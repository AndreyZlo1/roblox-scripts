-- Services.InterfaceService.MenuInterface.MenuLoadoutComponent.MenuLoadoutAttachmentListComponent.MenuLoadoutAttachmentNoneButton
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "asset");
local u3 = v1("GameShellProxyButton");
local v4 = u2.Component:extend("MenuLoadoutAttachmentNoneButton");
local u5 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
function v4.init(_, _) --[[ Line: 10 ]] end;
function v4.render(u6) --[[ Line: 14 ]]
    -- upvalues: u2 (copy), u3 (copy), u5 (copy)
    local l__props__1 = u6.props;
    local l__state__2 = u6.state;
    local l__Size__3 = l__props__1.Size;
    local l__Position__4 = l__props__1.Position;
    local l__Ignore__5 = l__props__1.Ignore;
    local l__Active__6 = l__props__1.Active;
    local l__Callback__7 = l__props__1.Callback;
    local l__Hovering__8 = l__state__2.Hovering;
    local v7 = l__Hovering__8 and Color3.fromRGB(150, 150, 150) or (l__Active__6 and Color3.fromRGB(255, 194, 89) or Color3.new());
    local v8 = l__Hovering__8 and Color3.new(1, 1, 1) or (l__Active__6 and Color3.fromRGB(255, 255, 255) or Color3.new(0.392157, 0.392157, 0.392157));
    return u2.createElement(u3, {
        SoundKit = "MainMenuLoadout",
        BorderSizePixel = 0,
        BackgroundTransparency = 0.5,
        Ignore = l__Ignore__5,
        Size = l__Size__3,
        Position = l__Position__4,
        BackgroundColor3 = v7,
        MouseUp = function() --[[ Name: MouseUp, Line 37 ]]
            -- upvalues: l__Callback__7 (copy)
            l__Callback__7();
        end,
        MouseEnter = function() --[[ Name: MouseEnter, Line 40 ]]
            -- upvalues: u6 (copy)
            u6:setState({
                Hovering = true
            });
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 45 ]]
            -- upvalues: u6 (copy)
            u6:setState({
                Hovering = false
            });
        end
    }, { u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 4)
        }), u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "NONE",
            TextScaled = true,
            Size = UDim2.fromScale(1, 0.8),
            Position = UDim2.new(0, 0, 0.5, 0),
            AnchorPoint = Vector2.new(0, 0.5),
            TextColor3 = v8,
            FontFace = u5,
            TextXAlignment = Enum.TextXAlignment.Center
        }) });
end;
return v4;