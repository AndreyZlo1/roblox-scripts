-- Services.InterfaceService.MenuInterface.MenuLoadoutComponent.MenuLoadoutAttachmentListComponent.MenuLoadoutAttachmentHoverPanel
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

game:GetService("TextService");
local v1, u2, _, _ = shared.import("require", "Roact", "asset", "network");
v1("GameShellProxyButton");
local u3 = v1("MenuButtonComponent");
local u4 = v1("AttachableComponent");
v1("MenuLoadoutViewportFrame");
local u5 = v1("ClientService");
local u6 = v1("GameShellProxyTextLabel");
local u7 = v1("BaseComponent");
local u8 = v1("Manufacturers");
local u9 = v1("MenuLoadoutPreviewOptionButton");
local u10 = v1("StatsService");
local u11 = v1("MenuLoadoutConstants");
local u12 = v1("MenuLoadoutAttachmentIcon");
local v13 = u2.Component:extend("MenuLoadoutAttachmentHoverPanel");
local u14 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u15 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local v16 = Instance.new("Camera");
v16.FieldOfView = 50;
v16.CFrame = CFrame.new(Vector3.new(0, 0, -2), Vector3.new(0, 0, 0));
function v13.init(p17, p18) --[[ Line: 40 ]]
    -- upvalues: u2 (copy)
    p17.MountTextLabelCalls = {};
    p17.UpdateVPF = {};
    local v19, v20 = u2.createBinding(0.3);
    p17.DescriptionSizeBinding = v19;
    p17.UpdDescriptionSizeBinding = v20;
    p17:setState({
        Config = p18.Config:getValue() or false
    });
end;
function v13.didMount(p21) --[[ Line: 50 ]]
    for _, v22 in p21.MountTextLabelCalls do
        v22();
    end;
end;
function v13.didUpdate(p23, _) --[[ Line: 56 ]]
    for _, v24 in p23.MountTextLabelCalls do
        v24();
    end;
end;
function v13.render(u25) --[[ Line: 62 ]]
    -- upvalues: u2 (copy), u5 (copy), u7 (copy), u11 (copy), u3 (copy), u15 (copy), u10 (copy), u6 (copy), u4 (copy), u12 (copy), u9 (copy), u14 (copy), u8 (copy)
    local l__props__1 = u25.props;
    local l__state__2 = u25.state;
    local l__Config__3 = l__state__2.Config;
    local u26 = l__Config__3;
    local v29 = l__props__1.Config:map(function(p27) --[[ Line: 68 ]]
        -- upvalues: u26 (copy), u25 (copy)
        local v28 = p27 or false;
        if u26 ~= v28 then
            u25:setState({
                Config = v28
            });
        end;
        return true;
    end);
    if not l__Config__3 then
        return u2.createElement("Frame", {
            Visible = false,
            Archivable = v29
        });
    end;
    local l__LocalClient__4 = u5.LocalClient;
    local v30 = {};
    local v31 = type(l__Config__3) == "number";
    local v32 = not v31;
    if v32 then
        local v33 = l__Config__3[1];
        v32 = v33 and true or v33;
    end;
    local v34 = 0;
    local l__RootComponent__5 = l__props__1.RootComponent;
    if v32 then
        local v35 = l__Config__3[1];
        local v36 = v35.Level or 0;
        local l__Description__6 = v35.Description;
        local v37 = 0;
        local v38 = nil;
        local v39 = 0;
        local l__IsCamo__7 = v35.IsCamo;
        local l__BuyDefaults__8 = v35.BuyDefaults;
        local v40;
        if l__BuyDefaults__8 then
            v40 = nil;
        else
            v40 = u7.Deserialize(l__RootComponent__5:Serialize(), true);
        end;
        for _, v41 in l__Config__3 do
            if not l__BuyDefaults__8 then
                if l__IsCamo__7 then
                    v40:GetChild(table.unpack(v41.FullNamePath)):EditMetaData({
                        Camo = v35.CamoPath[#v35.CamoPath]
                    });
                else
                    v40:SetChild(v41.Path, {}, table.unpack(v41.FullNamePath));
                end;
            end;
            if not l__LocalClient__4:IsComponentUnlocked(v41.CamoPath or v41.Path, v41.IsCamo) then
                if v41 ~= v35 then
                    local v42 = v41.Path[#v41.Path - 1];
                    l__Description__6 = (l__Description__6 or "") .. (v41.Gamepass and "\n<font color=\"rgb(85,255,127)\">GP</font> (" or "\n<font color=\"rgb(255,205,122)\">+$" .. (v41.Price or 0) .. "</font> (") .. (u11.SubIndexDisplayNames[v42] or v42) .. " - " .. "<font color=\"rgb(170,170,170)\">" .. v41.Name .. "</font>)";
                end;
                v36 = math.max(v36, v41.Level or 0);
                if v41.OutOfStock then
                    v39 = v39 + 1;
                end;
                v34 = v34 + 1;
                v37 = v37 + (v41.Price or 0);
                v38 = v38 or v41.Gamepass;
            end;
        end;
        local v43;
        if l__BuyDefaults__8 then
            v43 = nil;
        else
            v43 = v40:GetChild(table.unpack(l__props__1.ActivePath)):GetBaseComponent(true);
            v43:Remove();
            v40:Destroy();
            v43:DeBare();
        end;
        l__Config__3 = {
            Level = v36,
            Name = v35.Name,
            FlavorText = v35.FlavorText,
            Text = v35.Name .. (l__IsCamo__7 and v34 - v39 > 0 and (" (x" .. tostring(v34 - v39) .. ")" or "") or ""),
            Manufacturer = v35.Manufacturer or "Generic",
            Description = l__Description__6,
            Price = v37 == 0 and v35.Price or (v37 or 0),
            Gamepass = v38
        };
        local v44;
        if v34 - v39 <= 0 then
            v44 = v34 > 0;
        else
            v44 = false;
        end;
        l__Config__3.OutOfStock = v44;
        l__Config__3.IsCamo = l__IsCamo__7;
        l__Config__3.CamoPath = v35.CamoPath;
        l__Config__3.UseComponent = v43;
        l__Config__3.Path = (v43 or v35).Path;
    elseif v31 then
        local u45 = l__Config__3;
        local v46 = l__LocalClient__4.Loadouts[u45];
        l__RootComponent__5 = u7.Deserialize(v46.Tree);
        l__Config__3 = {
            Manufacturer = "Loadout",
            Name = v46.Name
        };
        v30[1] = u2.createElement(u3, {
            LayoutOrder = 1,
            Name = "RESET",
            Image = "",
            Ignore = l__props__1.Ignore,
            Callback = function() --[[ Name: Callback, Line 183 ]]
                -- upvalues: l__props__1 (copy), u45 (copy)
                l__props__1.SetHoveringHoverPanel(false);
                l__props__1.LoadoutCallback(u45, "Reset");
            end
        });
        v30[2] = u2.createElement(u3, {
            LayoutOrder = 2,
            Name = "DELETE",
            Image = "",
            Ignore = l__props__1.Ignore,
            Callback = function() --[[ Name: Callback, Line 193 ]]
                -- upvalues: l__props__1 (copy), u45 (copy)
                l__props__1.SetHoveringHoverPanel(false);
                l__props__1.LoadoutCallback(u45, "Delete");
            end
        });
        v30[3] = u2.createElement(u3, {
            LayoutOrder = 3,
            Name = "RENAME",
            Image = "",
            Activated = l__props__1.Renaming,
            Ignore = l__props__1.Ignore,
            Callback = function() --[[ Name: Callback, Line 204 ]]
                -- upvalues: l__props__1 (copy), u45 (copy)
                l__props__1.SetHoveringHoverPanel(false);
                l__props__1.LoadoutCallback(u45, "Rename");
            end
        });
    end;
    local v47;
    if #v30 == 0 then
        local v48;
        if v34 > 0 then
            v48 = true;
        else
            v48 = not v32;
            if v48 then
                v48 = not l__LocalClient__4:IsComponentUnlocked(l__Config__3.CamoPath or l__Config__3.Path, l__Config__3.IsCamo);
            end;
        end;
        v47 = not v48;
    else
        v47 = false;
    end;
    if v47 then
        v30[1] = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "OWNED",
            TextScaled = true,
            TextColor3 = Color3.new(0.5, 0.5, 0.5),
            FontFace = u15,
            TextXAlignment = Enum.TextXAlignment.Center
        });
    end;
    local v49;
    if v31 or l__Config__3.Gamepass then
        v49 = false;
    else
        v49 = not l__Config__3.OutOfStock or false;
    end;
    local v50;
    if l__Config__3.OutOfStock then
        v50 = false;
    else
        v50 = l__Config__3.Gamepass or false;
    end;
    local v51 = l__Config__3.OutOfStock or false;
    local v52 = {};
    if v49 then
        local v53 = Color3.new(1, 1, 1);
        if v47 or u10.Level < (l__Config__3.Level or 0) then
            v53 = v53:Lerp(Color3.new(), 0.4);
        end;
        v52[1] = u2.createElement(u6, {
            LayoutOrder = 11,
            BackgroundTransparency = 1,
            RichText = true,
            TextColor3 = v53,
            Size = UDim2.new(1, 0, 0.9, 0),
            DidMount = u25.MountTextLabelCalls,
            Text = "LVL. <font weight=\"bold\">" .. (l__Config__3.Level or 0) .. "</font>",
            FontFace = u15
        });
    end;
    local v54 = u10.Money < (l__Config__3.Price or 0);
    local u55 = {};
    local v56 = {};
    local u57 = {
        Attachments = {}
    };
    local function v61(p58, p59) --[[ Line: 254 ]]
        -- upvalues: u57 (copy), l__state__2 (copy), u55 (copy)
        u57[p58 .. "State"] = l__state__2[p58 .. "State"] or 1;
        for v60 = 1, #p59 do
            p59[v60].SubState = v60;
            p59[v60].SubIndex = p58;
            table.insert(u55, p59[v60]);
        end;
        if p58 ~= "Sights" then
            table.insert(u55, {
                SubState = 0,
                SubIndex = p58
            });
        end;
    end;
    if not (v31 or (v32 or l__Config__3.IsCamo)) then
        local v62 = u4.new(l__Config__3.Path, nil, nil, true);
        local l__Attachments__9 = v62.File.Attachments;
        if l__Attachments__9 then
            for v63, v64 in l__Attachments__9 do
                v61(v63, v64);
            end;
        end;
        local l__Config__10 = v62.File.Config;
        if l__Config__10 then
            l__Config__10 = v62.File.Config.Sights;
        end;
        if l__Config__10 and u11.SightPreviews[l__Config__3.Path[#l__Config__3.Path - 1]] then
            u57.SightsState = l__state__2.SightsState or 1;
            for v65 = 1, #l__Config__10 do
                l__Config__10[v65].SubState = v65;
                l__Config__10[v65].SubIndex = "Sights";
                table.insert(u55, l__Config__10[v65]);
            end;
        end;
    end;
    local v66 = u2.createElement(u12, {
        IsHoverPanel = true,
        Config = l__Config__3,
        UpdateVPF = u25.UpdateVPF,
        MetaOverrides = u57,
        RootComponent = l__RootComponent__5
    });
    for v67 = 1, #u55 do
        local v68 = u55[v67];
        local l__createElement__11 = u2.createElement;
        local v69 = u9;
        local v74 = {
            Callback = function(p70, p71) --[[ Name: Callback, Line 298 ]]
                -- upvalues: u25 (copy), l__Config__3 (ref)
                for v72, v73 in u25.UpdateVPF do
                    if v72.Config == l__Config__3 then
                        v73({
                            [p70 .. "State"] = p71
                        });
                    end;
                end;
                u25:setState({
                    [p70 .. "State"] = p71
                });
            end,
            ButtonInfo = v68,
            Order = v67,
            Activated = (l__state__2[v68.SubIndex .. "State"] or 1) == v68.SubState,
            Ignore = l__props__1.Ignore,
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            Size = UDim2.fromScale(1, 1)
        };
        table.insert(v56, l__createElement__11(v69, v74));
    end;
    local u75 = 0.35 + ((l__Config__3.Text or l__Config__3.Name) and 0.1 or 0) + (l__Config__3.FlavorText and 0.07 or 0) + (l__Config__3.Manufacturer and 0.06 or 0) + ((v49 or (v50 or v51)) and 0.09 or 0) + (#v30 > 0 and 0.09 or 0);
    local u76 = 2 + ((l__Config__3.Text or l__Config__3.Name) and 1 or 0) + (l__Config__3.FlavorText and 1 or 0) + (l__Config__3.Manufacturer and 1 or 0) + ((v49 or (v50 or v51)) and 1 or 0) + (#v30 > 0 and 1 or 0);
    local l__createFragment__12 = u2.createFragment;
    local v77 = {};
    local v79 = u2.createElement("Frame", {
        Size = u25.DescriptionSizeBinding:map(function(p78) --[[ Line: 335 ]]
            -- upvalues: u75 (ref), u76 (ref)
            return UDim2.new(1, 0, u75 + p78 + 0.04 + (u76 - 1) * 0.015, 0);
        end),
        [u2.Ref] = l__props__1.Ref,
        BorderSizePixel = 0,
        BackgroundColor3 = Color3.new(),
        BackgroundTransparency = 0.5,
        ZIndex = -1,
        Archivable = v29
    }, { u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 4)
        }), u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(1.05, 1.05),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.new(0.5, 0, 0.5, 0),
            [u2.Event.MouseEnter] = function() --[[ Line: 353 ]]
                -- upvalues: l__props__1 (copy)
                l__props__1.SetHoveringHoverPanel(true);
            end,
            [u2.Event.MouseLeave] = function() --[[ Line: 357 ]]
                -- upvalues: l__props__1 (copy)
                l__props__1.SetHoveringHoverPanel(false);
            end
        }) });
    local l__createElement__13 = u2.createElement;
    local v80 = "Frame";
    local v81 = {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 1)
    };
    local v82 = {};
    local v83 = u2.createElement("UIPadding", {
        PaddingLeft = UDim.new(0.07, 0),
        PaddingTop = UDim.new(0.04, 0),
        PaddingBottom = UDim.new(0.04, 0),
        PaddingRight = UDim.new(0.07, 0)
    });
    local v84 = u2.createElement("UIListLayout", {
        SortOrder = Enum.SortOrder.LayoutOrder,
        FillDirection = Enum.FillDirection.Vertical,
        HorizontalAlignment = Enum.HorizontalAlignment.Center,
        VerticalAlignment = Enum.VerticalAlignment.Top,
        Padding = UDim.new(0.02, 0)
    });
    local v85 = l__Config__3.Text or l__Config__3.Name;
    if v85 then
        v85 = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            LayoutOrder = 0,
            Size = UDim2.fromScale(1, 0.1)
        }, { u2.createElement(u6, {
                OnlySizeIfOverExtend = true,
                BackgroundTransparency = 1,
                DidMount = u25.MountTextLabelCalls,
                Size = UDim2.fromScale(1, 1),
                Text = l__Config__3.Text or l__Config__3.Name,
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u14,
                TextXAlignment = Enum.TextXAlignment.Center
            }) });
    end;
    local l__FlavorText__14 = l__Config__3.FlavorText;
    if l__FlavorText__14 then
        l__FlavorText__14 = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            LayoutOrder = 0,
            Size = UDim2.fromScale(1, 0.07)
        }, { u2.createElement(u6, {
                OnlySizeIfOverExtend = true,
                BackgroundTransparency = 1,
                DidMount = u25.MountTextLabelCalls,
                Size = UDim2.fromScale(1, 1),
                Text = l__Config__3.FlavorText,
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u15,
                TextXAlignment = Enum.TextXAlignment.Center
            }) });
    end;
    local l__Manufacturer__15 = l__Config__3.Manufacturer;
    if l__Manufacturer__15 then
        local l__createElement__16 = u2.createElement;
        local v86 = u6;
        local v87 = {
            LayoutOrder = 2,
            BackgroundTransparency = 1,
            TextScaled = true,
            Size = UDim2.fromScale(1, 0.06),
            Text = u8[l__Config__3.Manufacturer] and u8[l__Config__3.Manufacturer].Name or l__Config__3.Manufacturer,
            TextColor3 = Color3.new(0.592157, 0.592157, 0.592157),
            FontFace = u15,
            TextXAlignment = Enum.TextXAlignment.Center,
            DidMount = u25.MountTextLabelCalls
        };
        local v88 = {};
        local v89 = u8[l__Config__3.Manufacturer] and u8[l__Config__3.Manufacturer].Logo;
        if v89 then
            v89 = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = u8[l__Config__3.Manufacturer].Logo,
                AnchorPoint = Vector2.new(1, 0.5),
                Position = UDim2.new(0, -2, 0.5, 0),
                Size = UDim2.new((u8[l__Config__3.Manufacturer].AspectRatio or 1) * (u8[l__Config__3.Manufacturer].Scale or 1), 0, u8[l__Config__3.Manufacturer].Scale or 1, 0),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                ScaleType = Enum.ScaleType.Fit
            });
        end;
        v88[1] = v89;
        l__Manufacturer__15 = l__createElement__16(v86, v87, v88);
    end;
    local l__createElement__17 = u2.createElement;
    local v90 = "ImageLabel";
    local v91 = {
        LayoutOrder = 3,
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 0.35, 0)
    };
    local v92 = {};
    local v93;
    if #v56 > 0 then
        v93 = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(1, 0.2),
            Position = UDim2.new(0, 3, 1, -3),
            AnchorPoint = Vector2.new(0, 1)
        }, { u2.createFragment(v56), u2.createElement("UIListLayout", {
                SortOrder = Enum.SortOrder.LayoutOrder,
                FillDirection = Enum.FillDirection.Horizontal,
                HorizontalAlignment = Enum.HorizontalAlignment.Left,
                VerticalAlignment = Enum.VerticalAlignment.Center,
                Padding = UDim.new(0, 3)
            }) });
    else
        v93 = false;
    end;
    v92[1], v92[2] = v66, v93;
    local v94 = l__createElement__17(v90, v91, v92);
    local v95 = u2.createElement(u6, {
        LayoutOrder = 4,
        BackgroundTransparency = 1,
        RichText = true,
        DidMount = u25.MountTextLabelCalls,
        UpdSizeBinding = u25.UpdDescriptionSizeBinding,
        Size = UDim2.fromScale(1, 0.07),
        Text = l__Config__3.Description or "",
        TextSize = l__Config__3.TextSize or 8,
        TextColor3 = Color3.new(1, 1, 1),
        FontFace = u15,
        TextXAlignment = Enum.TextXAlignment.Left,
        AutomaticSize = Enum.AutomaticSize.Y
    });
    if v49 or (v50 or v51) then
        local l__createElement__18 = u2.createElement;
        local v96 = "Frame";
        local v97 = {
            BackgroundTransparency = 1,
            LayoutOrder = 5,
            ClipsDescendants = true,
            Size = UDim2.new(1, 0, 0.09, 0)
        };
        local v98 = {};
        if v49 then
            v49 = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(1, 1)
            }, {
                u2.createElement("UIListLayout", {
                    SortOrder = Enum.SortOrder.LayoutOrder,
                    FillDirection = Enum.FillDirection.Horizontal,
                    HorizontalAlignment = Enum.HorizontalAlignment.Center,
                    VerticalAlignment = Enum.VerticalAlignment.Center,
                    Padding = UDim.new(0.02, 0)
                }),
                u2.createElement("ImageLabel", {
                    LayoutOrder = 1,
                    Image = "rbxassetid://3929430562",
                    BackgroundTransparency = 1,
                    Size = UDim2.new(1, 0, 1, 0),
                    ImageColor3 = (v47 or v54) and Color3.new(0.6, 0.6, 0.6) or Color3.new(1, 1, 1)
                }, { u2.createElement("UIAspectRatioConstraint", {
                        AspectRatio = 1
                    }) }),
                u2.createElement(u6, {
                    LayoutOrder = 2,
                    BackgroundTransparency = 1,
                    DidMount = u25.MountTextLabelCalls,
                    Size = UDim2.fromScale(1, 1),
                    Text = l__Config__3.Price or "0",
                    TextColor3 = Color3.fromRGB(255, 205, 122):Lerp(Color3.new(), (v47 or v54) and 0.4 or 0),
                    FontFace = u14,
                    TextXAlignment = Enum.TextXAlignment.Center
                }),
                u2.createElement("Frame", {
                    LayoutOrder = 3,
                    BackgroundTransparency = 1,
                    Size = UDim2.fromScale(0.02, 1)
                }),
                u2.createElement("Frame", {
                    LayoutOrder = 4,
                    BackgroundTransparency = 0,
                    BackgroundColor3 = Color3.new(1, 1, 1),
                    Size = UDim2.fromScale(1, 0.1)
                }, { u2.createElement("UIAspectRatioConstraint", {
                        AspectRatio = 1
                    }), u2.createElement("UICorner", {
                        CornerRadius = UDim.new(1, 0)
                    }) }),
                u2.createElement("Frame", {
                    LayoutOrder = 5,
                    BackgroundTransparency = 1,
                    Size = UDim2.fromScale(0.02, 1)
                }),
                u2.createFragment(v52)
            });
        end;
        if v50 then
            v50 = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(1, 1)
            }, { u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "GAMEPASS",
                    TextScaled = true,
                    Size = UDim2.fromScale(1, 1),
                    TextColor3 = Color3.fromRGB(85, 255, 127),
                    FontFace = u14,
                    TextXAlignment = Enum.TextXAlignment.Center
                }) });
        end;
        if v51 then
            v51 = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(1, 1)
            }, { u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "SOLD OUT",
                    TextScaled = true,
                    Size = UDim2.fromScale(1, 1),
                    TextColor3 = Color3.fromRGB(255, 89, 89),
                    FontFace = u14,
                    TextXAlignment = Enum.TextXAlignment.Center
                }) });
        end;
        v98[1], v98[2], v98[3] = v49, v50, v51;
        v51 = l__createElement__18(v96, v97, v98);
    end;
    local v99;
    if #v30 > 0 then
        v99 = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            LayoutOrder = 6,
            Size = UDim2.new(1, 0, 0.09, 0)
        }, { u2.createFragment(v30), u2.createElement("UIGridLayout", {
                CellPadding = UDim2.new(0, 5, 0, 3),
                CellSize = UDim2.new(1 / #v30, -(#v30 - 1) * 3, 1, 0),
                FillDirection = Enum.FillDirection.Horizontal,
                SortOrder = Enum.SortOrder.LayoutOrder,
                StartCorner = Enum.StartCorner.TopLeft,
                HorizontalAlignment = Enum.HorizontalAlignment.Center,
                VerticalAlignment = Enum.VerticalAlignment.Center
            }) });
    else
        v99 = false;
    end;
    v82[1], v82[2], v82[3], v82[4], v82[5], v82[6], v82[7], v82[8], v82[9] = v83, v84, v85, l__FlavorText__14, l__Manufacturer__15, v94, v95, v51, v99;
    v77[1], v77[2] = v79, l__createElement__13(v80, v81, v82);
    return l__createFragment__12(v77);
end;
return v13;