-- Services.InterfaceService.MenuInterface.MenuLoadoutComponent.MenuLoadoutAttachmentListComponent.MenuLoadoutAttachmentComponentButton
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

game:GetService("RunService");
game:GetService("TextService");
local v1, u2, _, _ = shared.import("require", "Roact", "asset", "network");
local u3 = v1("GameShellProxyButton");
local u4 = v1("ClientService");
local u5 = v1("AttachableComponent");
local u6 = v1("RoactTween");
local u7 = v1("Menu");
local u8 = v1("InputService");
local u9 = v1("GameShellProxyTextLabel");
v1("MenuLoadoutViewportFrame");
local u10 = v1("AttachmentComponentUpSellButton");
local v11 = v1("MenuLoadoutConstants");
local u12 = v1("MenuLoadoutAttachmentIcon");
local v13 = u2.Component:extend("MenuLoadoutAttachmentComponentButton");
local u14 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u15 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local l__SubIndexDisplayNames__1 = v11.SubIndexDisplayNames;
local l__PIN_COLORS__2 = v11.PIN_COLORS;
local l__TAGS__3 = v11.TAGS;
function v13.init(p16, _) --[[ Line: 38 ]]
    -- upvalues: u6 (copy)
    p16.MountTextLabelCalls = {};
    p16.UpSellDropDown = u6.new(0, TweenInfo.new(0.1, Enum.EasingStyle.Cubic, Enum.EasingDirection.In));
end;
function v13.didMount(p17) --[[ Line: 44 ]]
    for _, v18 in p17.MountTextLabelCalls do
        v18();
    end;
end;
function v13.didUpdate(p19, _) --[[ Line: 50 ]]
    for _, v20 in p19.MountTextLabelCalls do
        v20();
    end;
end;
function v13.render(u21) --[[ Line: 56 ]]
    -- upvalues: u4 (copy), u7 (copy), u5 (copy), l__PIN_COLORS__2 (copy), u8 (copy), u2 (copy), u12 (copy), l__TAGS__3 (copy), u9 (copy), u15 (copy), u3 (copy), u10 (copy), u14 (copy), l__SubIndexDisplayNames__1 (copy)
    local l__state__4 = u21.state;
    local l__props__5 = u21.props;
    local l__Order__6 = l__props__5.Order;
    local l__Ignore__7 = l__props__5.Ignore;
    local l__Callback__8 = l__props__5.Callback;
    local l__Size__9 = l__props__5.Size;
    local l__Config__10 = l__props__5.Config;
    local l__Active__11 = l__props__5.Active;
    local l__IsCamo__12 = l__props__5.IsCamo;
    local l__EndComponent__13 = l__props__5.EndComponent;
    local l__RootComponent__14 = l__props__5.RootComponent;
    if l__RootComponent__14 and l__RootComponent__14.GetChild then
        if l__EndComponent__13 and not l__EndComponent__13._Destroyed then
            local v22 = l__RootComponent__14:GetChild("Character");
            local l__LocalClient__15 = u4.LocalClient;
            local v23 = l__LocalClient__15:IsComponentUnlocked(l__Config__10.CamoPath or l__Config__10.Path, l__IsCamo__12);
            local v24 = l__state__4.Hovering and Color3.new(1, 1, 1) or l__Active__11 and Color3.fromRGB(255, 194, 89) or (v23 and Color3.new(0, 0, 0) or Color3.new(0.086275, 0.086275, 0.086275));
            local v25 = l__state__4.Hovering and Color3.new(1, 1, 1) or l__Active__11 and Color3.fromRGB(255, 255, 255) or (v23 and Color3.new(0.694118, 0.694118, 0.694118) or Color3.new(0.392157, 0.392157, 0.392157));
            local v26 = l__state__4.Hovering and Color3.new(1, 1, 1) or (l__Active__11 and Color3.new(1, 1, 1) or Color3.new(0.545098, 0.545098, 0.545098));
            local v27 = l__Config__10.Path[#l__Config__10.Path - 1] == "Shirt";
            local v28 = l__Config__10.Path[#l__Config__10.Path - 1] == "Pants";
            local v29 = l__Config__10.Path[#l__Config__10.Path - 1] == "Receiver";
            local v30;
            if v27 then
                v30 = u7.Character.Pants[l__Config__10.Path[#l__Config__10.Path]];
            else
                v30 = v27;
            end;
            if v30 then
                if v30.ForSale == false then
                    v30 = false;
                end;
            end;
            local v31;
            if v28 then
                v31 = u7.Character.Shirt[l__Config__10.Path[#l__Config__10.Path]];
            else
                v31 = v28;
            end;
            if v31 then
                if v31.ForSale == false then
                    v31 = false;
                end;
            end;
            local v32 = nil;
            local v33 = l__IsCamo__12 or (v30 or v31);
            local l__Name__16 = l__Config__10.Name;
            local _, _, v34 = u5:GetPinInfo(l__Config__10.Path[#l__Config__10.Path - 1], l__Name__16);
            if v34 and v34 > 0 then
                l__Config__10.Color = l__PIN_COLORS__2[v34];
            end;
            if l__Name__16:sub(1, 15) == "Weapon Function" then
                local v35 = l__Name__16:sub(18, 18);
                l__Name__16 = "Function #" .. v35 .. " (" .. u8:GetBind("WeaponFunction" .. v35).Name .. ")";
                v32 = "Keybind";
                v33 = false;
            end;
            if l__state__4.Hovering and v33 then
                u21.UpSellDropDown:SetGoal(1);
            else
                u21.UpSellDropDown:SetGoal(0);
            end;
            local u36;
            if v33 then
                u36 = {};
                local function v41(p37) --[[ Line: 122 ]]
                    -- upvalues: l__Config__10 (copy), l__LocalClient__15 (copy), l__IsCamo__12 (copy), u36 (ref)
                    local v38 = p37:GetCamoConfig(l__Config__10.CamoPath[#l__Config__10.CamoPath]);
                    if v38 then
                        if v38.ForSale == false then
                            return;
                        end;
                        local v39 = l__LocalClient__15:IsComponentUnlocked(v38.CamoPath, l__IsCamo__12);
                        local v40 = (p37.MetaData.Camo or "Default") == l__Config__10.CamoPath[#l__Config__10.CamoPath];
                        v38.FullNamePath = p37:GetFullName();
                        v38.Unlocked = v39;
                        v38.Active = v40;
                        table.insert(u36, v38);
                    end;
                end;
                if l__IsCamo__12 then
                    v41(l__EndComponent__13:GetBaseComponent(true));
                    for _, v42 in l__EndComponent__13:GetBaseComponent(true):GetDescendants() do
                        if v42.DoSave then
                            v41(v42);
                        end;
                    end;
                elseif v27 then
                    local v43 = l__LocalClient__15:IsComponentUnlocked(v30.Path);
                    v30.Active = v22:GetChild("Pants").Name == l__EndComponent__13.Name;
                    v30.Unlocked = v43;
                    v30.FullNamePath = v22:GetChild("Pants"):GetFullName();
                    table.insert(u36, v30);
                    local v44 = l__LocalClient__15:IsComponentUnlocked(l__Config__10.Path);
                    l__Config__10.Active = l__Config__10.Name == l__EndComponent__13.Name;
                    l__Config__10.Unlocked = v44;
                    l__Config__10.FullNamePath = l__EndComponent__13:GetFullName();
                    table.insert(u36, l__Config__10);
                elseif v28 then
                    local v45 = l__LocalClient__15:IsComponentUnlocked(v31.Path);
                    v31.Active = v22:GetChild("Shirt").Name == l__EndComponent__13.Name;
                    v31.Unlocked = v45;
                    v31.FullNamePath = v22:GetChild("Shirt"):GetFullName();
                    table.insert(u36, v31);
                    local v46 = l__LocalClient__15:IsComponentUnlocked(l__Config__10.Path);
                    l__Config__10.Active = l__Config__10.Name == l__EndComponent__13.Name;
                    l__Config__10.Unlocked = v46;
                    l__Config__10.FullNamePath = l__EndComponent__13:GetFullName();
                    table.insert(u36, l__Config__10);
                end;
            else
                u36 = nil;
            end;
            local u47 = {};
            local function u56(p48) --[[ Line: 180 ]]
                -- upvalues: l__LocalClient__15 (copy), u36 (ref), l__props__5 (copy), u47 (copy), u56 (copy)
                for v49, v50 in p48.Children do
                    if #v50 > 0 and not p48:CanHaveNone(v49) then
                        for _, v51 in v50 do
                            local v52, v53 = v51:GetMenuConfig();
                            if v52 and not l__LocalClient__15:IsComponentUnlocked(v53.Path) then
                                u36 = u36 or {};
                                table.insert(u36, v53);
                                local l__ActivePath__17 = l__props__5.ActivePath;
                                local v54 = v51:GetFullName();
                                for v55 = #l__ActivePath__17, 1, -1 do
                                    table.insert(v54, 1, l__ActivePath__17[v55]);
                                end;
                                u47[v53] = v54;
                            end;
                            u56(v51);
                        end;
                    end;
                end;
            end;
            local v57 = u36 and (#u36 or 0) or 0;
            local v58 = u5.new(l__Config__10.Path, nil, {}, true);
            u56(v58);
            v58:Destroy();
            local u59;
            if v57 < (u36 and (#u36 or 0) or 0) then
                l__Config__10.BuyDefaults = true;
                table.insert(u36, 1, l__Config__10);
                u59 = true;
            else
                u59 = false;
            end;
            local v60 = u2.createElement(u12, {
                IsHoverPanel = false,
                Config = l__Config__10,
                ImageTransparency = v23 and 0 or 0.15,
                StrokeColor = v24,
                StrokeThickness = v29 and 0 or 1,
                BackgroundTransparency = v29 and 1 or 0.5,
                RootComponent = l__props__5.RootComponent
            });
            local v61;
            if l__Config__10.MenuTags then
                local v62 = {};
                local v63 = {};
                for v64, v65 in l__Config__10.MenuTags do
                    if v65 then
                        local v66, v67, v68, v69 = table.unpack(l__TAGS__3[v64]);
                        local v70 = v64 == "LEVEL" and { l__Config__10.Level or 0 } or {};
                        local v71 = string.format(v66, table.unpack(v70));
                        v63[#v63 + 1] = v67;
                        v62[v67] = u2.createElement(u9, {
                            TextTransparency = 1,
                            DidMount = u21.MountTextLabelCalls,
                            Text = string.format(v66, table.unpack(v70)),
                            Size = UDim2.new(0, 0, 0.065, 0),
                            SizeConstraint = Enum.SizeConstraint.RelativeXX,
                            LayoutOrder = v67,
                            BackgroundTransparency = v69 and 0 or 0.5,
                            BackgroundColor3 = v69 or Color3.new(),
                            TextColor3 = v68,
                            TextXAlignment = Enum.TextXAlignment.Center,
                            TextYAlignment = Enum.TextYAlignment.Center,
                            FontFace = u15
                        }, { u2.createElement("UICorner", {
                                CornerRadius = UDim.new(0, 4)
                            }), u2.createElement("TextLabel", {
                                RichText = true,
                                BackgroundTransparency = 1,
                                TextScaled = true,
                                Text = v71,
                                TextColor3 = v68,
                                TextXAlignment = Enum.TextXAlignment.Center,
                                TextYAlignment = Enum.TextYAlignment.Center,
                                FontFace = u15,
                                Size = UDim2.new(1, -10, 1, 0),
                                AnchorPoint = Vector2.new(0.5, 0.5),
                                Position = UDim2.new(0.5, 0, 0.5, 0)
                            }) });
                    end;
                end;
                table.sort(v63, function(p72, p73) --[[ Line: 281 ]]
                    return p73 < p72;
                end);
                while #v63 > 3 do
                    v62[table.remove(v63, #v63)] = nil;
                end;
                v61 = u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    ClipsDescendants = true,
                    ZIndex = 4,
                    Size = UDim2.new(1, -8, 1, -8),
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Position = UDim2.new(0.5, 0, 0.5, 0)
                }, { u2.createElement("UIListLayout", {
                        FillDirection = Enum.FillDirection.Vertical,
                        SortOrder = Enum.SortOrder.LayoutOrder,
                        VerticalAlignment = Enum.VerticalAlignment.Bottom,
                        HorizontalAlignment = Enum.HorizontalAlignment.Right,
                        Padding = UDim.new(0.03, 0)
                    }), u2.createFragment(v62) });
            else
                v61 = false;
            end;
            local l__createElement__18 = u2.createElement;
            local v74 = "Frame";
            local v76 = {
                BackgroundTransparency = 1,
                Size = u21.UpSellDropDown:Map(function(p75) --[[ Line: 306 ]]
                    -- upvalues: l__Size__9 (copy)
                    return l__Size__9 + UDim2.fromScale(0, l__Size__9.Y.Scale * p75 * 0.35);
                end),
                LayoutOrder = l__Order__6
            };
            local v77 = {};
            local l__createElement__19 = u2.createElement;
            local v78 = u3;
            local v82 = {
                SoundKit = "MainMenuLoadout",
                BorderSizePixel = 0,
                BackgroundTransparency = 0.5,
                Scroller = l__props__5.Scroller,
                Ignore = l__Ignore__7,
                Size = v29 and UDim2.fromScale(1, 0.39) or UDim2.fromScale(1, 0.25),
                SizeConstraint = Enum.SizeConstraint.RelativeXX,
                BackgroundColor3 = v24,
                MouseUp = function() --[[ Name: MouseUp, Line 322 ]]
                    -- upvalues: l__Callback__8 (copy), u59 (ref), u36 (ref), l__Config__10 (copy)
                    l__Callback__8(u59 and u36 or l__Config__10);
                end,
                MouseEnter = function(p79) --[[ Name: MouseEnter, Line 325 ]]
                    -- upvalues: u59 (ref), u36 (ref), u47 (copy), l__props__5 (copy), l__Config__10 (copy), l__Callback__8 (copy), u21 (copy)
                    if u59 then
                        for _, v80 in u36 do
                            v80.TempFullNamePath = u47[v80];
                        end;
                    end;
                    l__props__5.Hover(p79, u59 and u36 or l__Config__10, true, function() --[[ Line: 332 ]]
                        -- upvalues: l__Callback__8 (ref), u59 (ref), u36 (ref), l__Config__10 (ref)
                        l__Callback__8(u59 and u36 or l__Config__10);
                    end);
                    u21:setState({
                        Hovering = true
                    });
                end,
                MouseLeave = function(p81) --[[ Name: MouseLeave, Line 340 ]]
                    -- upvalues: l__props__5 (copy), u59 (ref), u36 (ref), l__Config__10 (copy), u21 (copy)
                    l__props__5.Hover(p81, u59 and u36 or l__Config__10, false);
                    u21:setState({
                        Hovering = false
                    });
                end
            };
            local v83 = { (u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0, 4)
                })) };
            local l__createElement__20 = u2.createElement;
            local v84 = "Frame";
            local v85 = {
                BackgroundTransparency = 1,
                Position = v29 and UDim2.new(0.02, 0, 0.5, 0) or UDim2.new(0.04, 0, 0.5, 0),
                AnchorPoint = Vector2.new(0, 0.5),
                Size = v29 and UDim2.fromScale(0.96, 0.85) or UDim2.fromScale(0.92, 0.7)
            };
            local v86 = {};
            local v87 = not v29;
            if v87 then
                v87 = u2.createElement("UIAspectRatioConstraint", {
                    AspectRatio = 1
                });
            end;
            v86[1], v86[2] = v60, v87;
            v83.Preview = l__createElement__20(v84, v85, v86);
            if v33 then
                v33 = u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    ZIndex = -1,
                    Position = UDim2.new(0, 0, 1, -1),
                    Visible = u21.UpSellDropDown:Map(function(p88) --[[ Line: 369 ]]
                        return p88 > 0;
                    end),
                    AnchorPoint = u21.UpSellDropDown:Map(function(p89) --[[ Line: 372 ]]
                        return Vector2.new(0, 1 - p89);
                    end),
                    Size = v29 and UDim2.new(1, 0, 0.35) or UDim2.new(1, 0, 0.45)
                }, { u2.createElement(u10, {
                        Order = 1,
                        Text = "+ FULL SET",
                        Ignore = l__Ignore__7,
                        Scroller = l__props__5.Scroller,
                        Hover = l__props__5.Hover,
                        Callback = l__props__5.Callback,
                        Configs = u36,
                        IsCamo = l__IsCamo__12,
                        ParentHovering = l__state__4.Hovering,
                        UpSellDropDown = u21.UpSellDropDown
                    }) });
            end;
            local l__createElement__21 = u2.createElement;
            local v90 = "Frame";
            local v91 = {
                BackgroundTransparency = 1,
                Size = v29 and UDim2.new(0.9, 0, 0.5, 0) or UDim2.new(0.73, 0, 0.9, 0),
                Position = v29 and UDim2.new(0.05, 0, 0.95, 0) or UDim2.new(0.25, 0, 0.5, 0),
                AnchorPoint = v29 and Vector2.new(0, 1) or Vector2.new(0, 0.5)
            };
            local v92 = {};
            local v93 = u2.createElement(u9, {
                BackgroundTransparency = 1,
                TextTransparency = 0,
                Position = UDim2.new(0, 0, 1, 0),
                AnchorPoint = Vector2.new(0, 1),
                Size = UDim2.new(5, 0, 0.5, 0),
                DidMount = u21.MountTextLabelCalls,
                Text = l__Name__16,
                TextColor3 = v25,
                FontFace = u14,
                TextXAlignment = Enum.TextXAlignment.Left
            });
            local l__createElement__22 = u2.createElement;
            local v94 = "Frame";
            local v95 = {
                BackgroundTransparency = 1,
                Position = v29 and UDim2.new(0.5, 0, -0.8, 0) or UDim2.new(0, 0, 0.05, 0),
                AnchorPoint = v29 and Vector2.new(0.5, 0) or Vector2.new(0, 0),
                Size = UDim2.new(1, 0, 0.4, 0)
            };
            local v96 = {};
            local l__createElement__23 = u2.createElement;
            local v97 = u9;
            local v98 = {
                BackgroundTransparency = 1,
                DidMount = u21.MountTextLabelCalls,
                Size = UDim2.new(1, 0, 1, 0)
            };
            if not v32 then
                v32 = l__Config__10.Type;
                if v32 then
                    v32 = table.concat(v32, ", ");
                end;
                if not v32 then
                    local l__Category__24 = l__Config__10.Category;
                    if l__Category__24 then
                        l__Category__24 = table.concat(l__Category__24, ", ");
                    end;
                    v32 = l__Category__24 or (l__IsCamo__12 and "Camo" or (l__SubIndexDisplayNames__1[l__Config__10.Path[#l__Config__10.Path - 1]] or l__Config__10.Path[#l__Config__10.Path - 1]));
                end;
            end;
            v98.Text = v32;
            v98.TextColor3 = v26;
            v98.FontFace = u15;
            v98.Position = v29 and UDim2.new(0.5, 0, 0, 0) or UDim2.new(0, 0, 0, 0);
            v98.AnchorPoint = v29 and Vector2.new(0.5, 0) or Vector2.new(0, 0);
            v98.TextXAlignment = v29 and Enum.TextXAlignment.Center or Enum.TextXAlignment.Left;
            v96[1] = l__createElement__23(v97, v98);
            v92[1], v92[2] = v93, l__createElement__22(v94, v95, v96);
            v83[2], v83[3], v83[4] = v61, v33, l__createElement__21(v90, v91, v92);
            v77[1] = l__createElement__19(v78, v82, v83);
            return l__createElement__18(v74, v76, v77);
        end;
    end;
end;
return v13;