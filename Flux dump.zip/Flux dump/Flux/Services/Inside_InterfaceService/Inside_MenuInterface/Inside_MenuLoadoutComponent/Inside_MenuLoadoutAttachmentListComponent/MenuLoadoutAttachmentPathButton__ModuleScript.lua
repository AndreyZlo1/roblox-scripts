-- Services.InterfaceService.MenuInterface.MenuLoadoutComponent.MenuLoadoutAttachmentListComponent.MenuLoadoutAttachmentPathButton
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "asset");
local u3 = v1("GameShellProxyButton");
local u4 = v1("MenuLoadoutConstants");
local v5 = u2.Component:extend("MenuLoadoutAttachmentPathButton");
local u6 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
function v5.init(_, _) --[[ Line: 11 ]] end;
function v5.render(u7) --[[ Line: 15 ]]
    -- upvalues: u2 (copy), u3 (copy), u4 (copy), u6 (copy)
    local l__props__1 = u7.props;
    local l__state__2 = u7.state;
    local l__Order__3 = l__props__1.Order;
    local l__Ignore__4 = l__props__1.Ignore;
    local l__Callback__5 = l__props__1.Callback;
    local l__Size__6 = l__props__1.Size;
    local _ = l__props__1.RootComponent;
    local _ = l__props__1.ActivePath;
    local l__SubName__7 = l__props__1.SubName;
    return u2.createElement(u3, {
        SoundKit = "MainMenuLoadout",
        BorderSizePixel = 0,
        BackgroundTransparency = 0.5,
        Scroller = l__props__1.Scroller,
        LayoutOrder = l__Order__3,
        Ignore = l__Ignore__4,
        Size = l__Size__6,
        BackgroundColor3 = l__state__2.Hovering and Color3.fromRGB(150, 150, 150) or Color3.new(),
        MouseUp = function() --[[ Name: MouseUp, Line 36 ]]
            -- upvalues: l__Callback__5 (copy), l__SubName__7 (copy)
            l__Callback__5(nil, l__SubName__7);
        end,
        MouseEnter = function() --[[ Name: MouseEnter, Line 39 ]]
            -- upvalues: u7 (copy)
            u7:setState({
                Hovering = true
            });
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 44 ]]
            -- upvalues: u7 (copy)
            u7:setState({
                Hovering = false
            });
        end
    }, { u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 4)
        }), u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            Size = UDim2.fromScale(1, 0.4),
            Position = UDim2.fromScale(0.1, 0.3),
            Text = u4.SubIndexDisplayNames[l__SubName__7] or l__SubName__7,
            TextColor3 = l__state__2.Hovering and Color3.fromRGB(255, 255, 255) or Color3.new(0.392157, 0.392157, 0.392157),
            FontFace = u6,
            TextXAlignment = Enum.TextXAlignment.Left
        }) });
end;
return v5;