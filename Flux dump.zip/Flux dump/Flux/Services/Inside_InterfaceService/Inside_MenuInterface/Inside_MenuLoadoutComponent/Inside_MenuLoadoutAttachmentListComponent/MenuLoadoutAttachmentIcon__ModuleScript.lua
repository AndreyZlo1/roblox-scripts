-- Services.InterfaceService.MenuInterface.MenuLoadoutComponent.MenuLoadoutAttachmentListComponent.MenuLoadoutAttachmentIcon
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _, _ = shared.import("require", "Roact", "asset", "network");
v1("MenuLoadoutConstants");
local u3 = v1("BaseComponent");
local u4 = v1("AttachableComponent");
local u5 = v1("MenuLoadoutViewportFrame");
local v6 = u2.Component:extend("MenuLoadoutAttachmentIcon");
local u7 = CFrame.Angles(0, 3.141592653589793, 0);
local u8 = Instance.new("Camera");
u8.FieldOfView = 70;
u8.CFrame = CFrame.new(Vector3.new(0, 0, 0), Vector3.new(-0, -0, -1));
local u9 = nil;
u9 = {
    Device = function(p10, _, p11, p12) --[[ Line: 19 ]]
        -- upvalues: u4 (copy), u8 (copy)
        local l__IsHoverPanel__1 = p12.props.IsHoverPanel;
        local l__MetaOverrides__2 = p12.props.MetaOverrides;
        local v13 = nil;
        local v14 = nil;
        local v15 = nil;
        if l__IsHoverPanel__1 then
            local v16 = u4.GetFile(p10.Path);
            if v16 then
                v16 = v16.Config;
            end;
            if v16 and (v16.Sights or (v16.Reticles or v16.Magnifier)) then
                local v17 = l__MetaOverrides__2.SightsState or 1;
                local v18 = u4.new(p10.Path);
                v18.ParentModel:ScaleTo(v18.ParentModel:GetScale() * 3);
                local v19 = v18.Model:FindFirstChild("post");
                local v20 = v19 and v18.Model:FindFirstChild("flip", true);
                if v20 then
                    local v21 = v19.CFrame:Inverse() * v20.WorldCFrame;
                    local v22 = v19.CFrame * v21 * CFrame.Angles(-1.5707963267948966, 0, 0) * v21:Inverse();
                    local v23 = v19:FindFirstChildWhichIsA("Weld");
                    if v23 then
                        v23:Destroy();
                    end;
                    v19.CFrame = v22;
                end;
                local v24 = v18.Model:FindFirstChild("sight" .. (v17 == 1 and "" or tostring(v17)), true);
                local v25 = v18.Model:FindFirstChild("glass" .. (v17 == 1 and "" or tostring(v17)));
                v13 = CFrame.new(0, 0, 0);
                local v26, v27 = v18.ParentModel:GetBoundingBox();
                v15 = u8;
                local v28 = not (v16.Sights and v16.Sights[v17] and v16.Sights[v17].FOV) and v16.Magnifier;
                if v28 then
                    v28 = v16.Magnifier.FOV;
                end;
                if type(v28) == "table" then
                    v28 = v28[p12.state.FOVIndex or 2];
                end;
                v15:SetAttribute("SightFOV", 70 - v28);
                v15.FieldOfView = 3;
                local v29 = math.min(v25 and v25.Size.X or v27.X, v25 and v25.Size.Y or v27.Y) * 0.5 / 0.02618592156918693;
                v14 = (v24 and v24.WorldCFrame or (v25 and v25.CFrame * CFrame.new(0, 0, v25.Size.Z) or CFrame.identity)):Inverse() * v26 * CFrame.new(0, 0, -v29);
                v18:Destroy();
            end;
        end;
        return p11, v13, v14, v15;
    end,
    Ironsight = function(p30, p31, p32, p33) --[[ Line: 71 ]]
        -- upvalues: u9 (ref)
        return u9.Device(p30, p31, p32, p33);
    end,
    Shirt = function(p34, p35, _) --[[ Line: 75 ]]
        -- upvalues: u4 (copy)
        local v36 = p35:GetChild("Character");
        local v37 = u4.new({ "Character", "ShirtModel" });
        v37:AddChild(p34.Path, nil, "Shirt");
        v37:AddChild(v36:GetChild("Pants").Path, nil, "Pants");
        local _, v38 = v37:SetChild(v36:GetChild("Appearance", "SkinColor").Path, nil, "Appearance", "SkinColor");
        if v38 then
            v38:Destroy();
        end;
        return v37;
    end,
    Pants = function(p39, p40, _) --[[ Line: 84 ]]
        -- upvalues: u4 (copy)
        local v41 = p40:GetChild("Character");
        local v42 = u4.new({ "Character", "PantsModel" });
        v42:AddChild(p39.Path, nil, "Pants");
        local _, v43 = v42:SetChild(v41:GetChild("Appearance", "SkinColor").Path, nil, "Appearance", "SkinColor");
        if v43 then
            v43:Destroy();
        end;
        return v42;
    end,
    Boots = function(p44, p45, _) --[[ Line: 92 ]]
        -- upvalues: u4 (copy)
        local v46 = p45:GetChild("Character");
        local v47 = u4.new({ "Character", "PantsModel" });
        v47.ParentModel.PrimaryPart.Anchored = true;
        v47:AddChild(v46:GetChild("Pants").Path, nil, "Pants");
        local _, v48 = v47:SetChild(v46:GetChild("Appearance", "SkinColor").Path, nil, "Appearance", "SkinColor");
        if v48 then
            v48:Destroy();
        end;
        local l__Path__3 = p44.Path;
        local l__CamoPath__4 = p44.CamoPath;
        if l__CamoPath__4 then
            l__CamoPath__4 = p44.CamoPath[#p44.CamoPath];
        end;
        local _, v49 = v47:SetChild(l__Path__3, l__CamoPath__4, "LeftBoot");
        if v49 then
            v49:Destroy();
        end;
        local l__Path__5 = p44.Path;
        local l__CamoPath__6 = p44.CamoPath;
        if l__CamoPath__6 then
            l__CamoPath__6 = p44.CamoPath[#p44.CamoPath];
        end;
        local _, v50 = v47:SetChild(l__Path__5, l__CamoPath__6, "RightBoot");
        if v50 then
            v50:Destroy();
        end;
        return v47;
    end,
    Gloves = function(p51, p52, _) --[[ Line: 105 ]]
        -- upvalues: u4 (copy)
        local v53 = p52:GetChild("Character");
        local v54 = u4.new({ "Character", "ShirtModel" });
        v54.ParentModel.PrimaryPart.Anchored = true;
        v54:AddChild(v53:GetChild("Shirt").Path, nil, "Shirt");
        v54:AddChild(v53:GetChild("Pants").Path, nil, "Pants");
        local _, v55 = v54:SetChild(v53:GetChild("Appearance", "SkinColor").Path, nil, "Appearance", "SkinColor");
        if v55 then
            v55:Destroy();
        end;
        local l__Path__7 = p51.Path;
        local l__CamoPath__8 = p51.CamoPath;
        if l__CamoPath__8 then
            l__CamoPath__8 = p51.CamoPath[#p51.CamoPath];
        end;
        local _, v56 = v54:SetChild(l__Path__7, l__CamoPath__8, "LeftGlove");
        if v56 then
            v56:Destroy();
        end;
        local l__Path__9 = p51.Path;
        local l__CamoPath__10 = p51.CamoPath;
        if l__CamoPath__10 then
            l__CamoPath__10 = p51.CamoPath[#p51.CamoPath];
        end;
        local _, v57 = v54:SetChild(l__Path__9, l__CamoPath__10, "RightGlove");
        if v57 then
            v57:Destroy();
        end;
        return v54;
    end,
    Mouth = function(p58, p59, _) --[[ Line: 119 ]]
        -- upvalues: u4 (copy), u3 (copy), u7 (copy)
        local v60 = p59:GetChild("Character");
        local v61 = u4.new({ "Character", "HeadModel" });
        v61.ParentModel.PrimaryPart.Anchored = true;
        v61:GetChild("Appearance"):Destroy();
        local v62 = u3.Deserialize(v60:GetChild("Appearance"):Serialize());
        v62:AssignParent(v61, "Appearance");
        local _, v63 = v62:SetChild(p58.Path, {}, "Mouth");
        if v63 then
            v63:Destroy();
        end;
        p58.ModelCFrame = p58.ModelCFrame or u7;
        return v61;
    end,
    Eyebrows = function(p64, p65, _) --[[ Line: 132 ]]
        -- upvalues: u4 (copy), u3 (copy), u7 (copy)
        local v66 = p65:GetChild("Character");
        local v67 = u4.new({ "Character", "HeadModel" });
        v67.ParentModel.PrimaryPart.Anchored = true;
        v67:GetChild("Appearance"):Destroy();
        local v68 = u3.Deserialize(v66:GetChild("Appearance"):Serialize());
        v68:AssignParent(v67, "Appearance");
        local _, v69 = v68:SetChild(p64.Path, {}, "Eyebrows");
        if v69 then
            v69:Destroy();
        end;
        p64.ModelCFrame = p64.ModelCFrame or u7;
        return v67;
    end,
    Loadout = function(p70, p71, _) --[[ Line: 145 ]]
        -- upvalues: u7 (copy)
        local v72 = p71:GetChild("Character");
        p70.ModelCFrame = p70.ModelCFrame or u7;
        return v72;
    end,
    Receiver = function(p73, _, p74) --[[ Line: 150 ]]
        p73.ModelCFrame = p73.ModelCFrame or CFrame.Angles(0, -1.5707963267948966, 0);
        p73.CameraCFrame = p73.CameraCFrame or CFrame.new(0, 0, -14);
        return p74;
    end
};
function v6.init(_) --[[ Line: 157 ]] end;
function v6.willUnmount(_) --[[ Line: 161 ]] end;
function v6.render(p75) --[[ Line: 165 ]]
    -- upvalues: u9 (ref), u2 (copy), u5 (copy)
    local l__props__11 = p75.props;
    local l__Config__12 = l__props__11.Config;
    local l__IsHoverPanel__13 = l__props__11.IsHoverPanel;
    local l__UpdateVPF__14 = l__props__11.UpdateVPF;
    local l__MetaOverrides__15 = l__props__11.MetaOverrides;
    local l__RootComponent__16 = l__props__11.RootComponent;
    local l__Icon__17 = l__Config__12.Icon;
    local l__Color__18 = l__Config__12.Color;
    local l__UseComponent__19 = l__Config__12.UseComponent;
    local v76 = nil;
    local v77 = nil;
    local v78 = nil;
    local l__Path__20 = l__Config__12.Path;
    local v79 = l__Path__20 and l__Path__20[#l__Path__20 - 1] or "Loadout";
    if l__RootComponent__16 and l__RootComponent__16.GetChild then
        local v80 = u9[v79];
        if v80 then
            l__UseComponent__19, v76, v77, v78 = v80(l__Config__12, l__RootComponent__16, l__UseComponent__19, p75);
        end;
        l__Config__12.UseComponent = l__UseComponent__19;
        if l__Icon__17 or l__Color__18 then
            return u2.createElement("ImageLabel", {
                BorderSizePixel = 0,
                Size = UDim2.new(1, 0, 1, 0),
                BackgroundTransparency = l__props__11.BackgroundTransparency or 0,
                BackgroundColor3 = l__Color__18 or Color3.fromRGB(19, 20, 26),
                ImageColor3 = l__Color__18 or Color3.new(1, 1, 1),
                ImageTransparency = l__props__11.ImageTransparency or 0,
                Image = l__Icon__17 or "",
                ZIndex = l__IsHoverPanel__13 and 0 or 2
            }, { u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0, 4)
                }), u2.createElement("UIStroke", {
                    Thickness = l__props__11.StrokeThickness or 1,
                    Color = l__props__11.StrokeColor or Color3.new(0, 0, 0)
                }) });
        else
            return u2.createElement(u5, {
                LightDirection = Vector3.new(0.5, -1, 0.5),
                BorderSizePixel = 0,
                Ambient = Color3.new(1, 1, 1),
                LightColor = Color3.fromRGB(255, 255, 255),
                Size = UDim2.new(1, 0, 1, 0),
                BackgroundTransparency = l__props__11.BackgroundTransparency or 0.5,
                BackgroundColor3 = Color3.fromRGB(19, 20, 26),
                ImageColor3 = Color3.new(1, 1, 1),
                ImageTransparency = l__props__11.ImageTransparency or 0,
                ZIndex = l__IsHoverPanel__13 and 0 or 2,
                Config = l__Config__12,
                ModelCF = v76 or false,
                CameraCF = v77 or false,
                HoverPanel = l__IsHoverPanel__13,
                Camera = v78 or false,
                UpdateVPF = l__UpdateVPF__14,
                MetaOverrides = l__MetaOverrides__15
            }, { u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0, 4)
                }), u2.createElement("UIStroke", {
                    Thickness = l__props__11.StrokeThickness or 1,
                    Color = l__props__11.StrokeColor or Color3.new(0, 0, 0)
                }) });
        end;
    end;
end;
return v6;