-- Services.InterfaceService.MenuInterface.MenuLoadoutComponent.MenuLoadoutAttachmentListComponent.MenuLoadoutAttachmentLoadoutButton
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "asset");
local u3 = v1("GameShellProxyButton");
local u4 = v1("GameShellProxyInput");
local v5 = u2.Component:extend("MenuLoadoutAttachmentLoadoutButton");
local u6 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u7 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
function v5.init(_, _) --[[ Line: 11 ]] end;
function v5.render(u8) --[[ Line: 15 ]]
    -- upvalues: u2 (copy), u3 (copy), u7 (copy), u4 (copy), u6 (copy)
    local l__props__1 = u8.props;
    local l__state__2 = u8.state;
    local l__Order__3 = l__props__1.Order;
    local l__Ignore__4 = l__props__1.Ignore;
    local l__Callback__5 = l__props__1.Callback;
    local l__Loadout__6 = l__props__1.Loadout;
    local l__Size__7 = l__props__1.Size;
    local l__Hover__8 = l__props__1.Hover;
    local l__Hovering__9 = l__state__2.Hovering;
    local l__Active__10 = l__props__1.Active;
    local v9 = l__Hovering__9 and Color3.fromRGB(150, 150, 150) or (l__Active__10 and Color3.fromRGB(255, 194, 89) or Color3.new());
    local v10 = l__Hovering__9 and Color3.new(1, 1, 1) or (l__Active__10 and Color3.fromRGB(255, 255, 255) or Color3.new(0.392157, 0.392157, 0.392157));
    if l__props__1.IsAdder then
        return u2.createElement(u3, {
            SoundKit = "MainMenuLoadout",
            BorderSizePixel = 0,
            BackgroundTransparency = 0.5,
            Scroller = l__props__1.Scroller,
            LayoutOrder = l__Order__3,
            Ignore = l__Ignore__4,
            Size = l__Size__7,
            BackgroundColor3 = v9,
            MouseUp = function() --[[ Name: MouseUp, Line 42 ]]
                -- upvalues: l__Callback__5 (copy), l__Order__3 (copy)
                l__Callback__5(l__Order__3, "Add");
            end,
            MouseEnter = function(_) --[[ Name: MouseEnter, Line 45 ]]
                -- upvalues: u8 (copy)
                u8:setState({
                    Hovering = true
                });
            end,
            MouseLeave = function(_) --[[ Name: MouseLeave, Line 50 ]]
                -- upvalues: u8 (copy)
                u8:setState({
                    Hovering = false
                });
            end
        }, { u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }), u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "+",
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.8),
                Position = UDim2.fromScale(0.5, 0.5),
                AnchorPoint = Vector2.new(0.5, 0.5),
                TextColor3 = v10,
                FontFace = u7,
                TextXAlignment = Enum.TextXAlignment.Center
            }) });
    elseif l__props__1.Renaming then
        return u2.createElement("Frame", {
            Size = l__Size__7,
            LayoutOrder = l__Order__3,
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(),
            [u2.Ref] = l__props__1.RenameButtonRef
        }, { u2.createElement(u4, {
                BackgroundTransparency = 1,
                ClearTextOnFocus = false,
                Ignore = false,
                InstantFocus = true,
                Size = UDim2.new(1, 0, 1, 0),
                FontFace = u7,
                PlaceholderText = l__Loadout__6.Name,
                TextXAlignment = Enum.TextXAlignment.Left,
                TextYAlignment = Enum.TextYAlignment.Center,
                TextBind = l__props__1.RenamingBind,
                TextBindUpdate = l__props__1.UpdRenamingBind,
                EnterPressed = l__props__1.AttemptRename,
                Content = {}
            }) });
    else
        return u2.createElement(u3, {
            SoundKit = "MainMenuLoadout",
            BorderSizePixel = 0,
            BackgroundTransparency = 0.5,
            Scroller = l__props__1.Scroller,
            LayoutOrder = l__Order__3,
            Ignore = l__Ignore__4,
            Size = l__Size__7,
            BackgroundColor3 = v9,
            MouseUp = function() --[[ Name: MouseUp, Line 110 ]]
                -- upvalues: l__Callback__5 (copy), l__Order__3 (copy)
                l__Callback__5(l__Order__3, "Set");
            end,
            MouseEnter = function(p11) --[[ Name: MouseEnter, Line 113 ]]
                -- upvalues: u8 (copy), l__Hover__8 (copy), l__Order__3 (copy)
                u8:setState({
                    Hovering = true
                });
                l__Hover__8(p11, l__Order__3, true);
            end,
            MouseLeave = function(p12) --[[ Name: MouseLeave, Line 119 ]]
                -- upvalues: u8 (copy), l__Hover__8 (copy), l__Order__3 (copy)
                u8:setState({
                    Hovering = false
                });
                l__Hover__8(p12, l__Order__3, false);
            end
        }, { u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }), u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.4),
                Position = UDim2.fromScale(0.1, 0.3),
                Text = l__Loadout__6.Name,
                TextColor3 = v10,
                FontFace = u6,
                TextXAlignment = Enum.TextXAlignment.Left
            }) });
    end;
end;
return v5;