-- Services.InterfaceService.MenuInterface.MenuLoadoutComponent.MenuLoadoutAttachmentSelectionInfoComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "asset");
v1("Menu");
local u3 = v1("Calibers");
local u4 = v1("BulletService");
local u5 = v1("GameSettings");
local u6 = v1("GameShellProxyTextLabel");
local u7 = v1("TerminalPerformanceGraphComponent");
local u8 = v1("RecoilSimulationVisualizer");
local u9 = v1("FirearmInventoryReplicator");
local u10 = v1("Manufacturers");
local l__TOOL_TIPS__1 = v1("MenuLoadoutConstants").TOOL_TIPS;
local v11 = u2.Component:extend("MenuLoadoutAttachmentSelectionInfo");
local u12 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u13 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u14 = Color3.fromRGB(108, 255, 89);
local u15 = Color3.fromRGB(255, 89, 89);
local l__FIREMODES__2 = l__TOOL_TIPS__1.FIREMODES;
local function u17(p16) --[[ Line: 57 ]]
    -- upvalues: u2 (copy)
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        LayoutOrder = p16.LayoutOrder,
        Size = UDim2.new(1, 0, 0.02, 0)
    }, { u2.createElement("Frame", {
            BorderSizePixel = 0,
            Size = UDim2.new(1, 0, 0, 1),
            BackgroundColor3 = Color3.new(1, 1, 1),
            Position = UDim2.fromScale(0.5, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5)
        }) });
end;
local function u22(p18) --[[ Line: 73 ]]
    -- upvalues: u2 (copy), u6 (copy), u13 (copy)
    local l__Self__3 = p18.Self;
    local l__Name__4 = p18.Name;
    local v19 = p18.Stat or "";
    local v20 = (p18.Color or Color3.new(1, 1, 1)):ToHex();
    local v21 = p18.AppendText or "";
    local l__StatAlignment__5 = p18.StatAlignment;
    if l__StatAlignment__5 == "Left" then
        return u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = p18.Size,
            LayoutOrder = p18.LayoutOrder,
            SizeConstraint = Enum.SizeConstraint.RelativeXX
        }, { u2.createElement("UIListLayout", {
                HorizontalAlignment = Enum.HorizontalAlignment.Left,
                VerticalAlignment = Enum.VerticalAlignment.Center,
                FillDirection = Enum.FillDirection.Horizontal,
                SortOrder = Enum.SortOrder.LayoutOrder,
                Padding = UDim.new(0.025, 0)
            }), u2.createElement(u6, {
                LayoutOrder = 1,
                BackgroundTransparency = 1,
                RichText = true,
                Size = UDim2.new(1, 0, 1, 0),
                Text = l__Name__4,
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u13,
                TextXAlignment = Enum.TextXAlignment.Left,
                DidMount = l__Self__3.MountTextLabelCalls
            }), u2.createElement("TextLabel", {
                LayoutOrder = 2,
                TextScaled = true,
                BackgroundTransparency = 1,
                RichText = true,
                Size = UDim2.new(1, 0, 1, 0),
                Text = "<font color=\"#" .. v20 .. "\">" .. v19 .. "</font> " .. v21,
                TextColor3 = Color3.new(0.545098, 0.545098, 0.545098),
                FontFace = u13,
                TextXAlignment = Enum.TextXAlignment.Left
            }) });
    end;
    if l__StatAlignment__5 == "Right" then
        return u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = p18.Size,
            LayoutOrder = p18.LayoutOrder
        }, { u2.createElement("TextLabel", {
                TextScaled = true,
                BackgroundTransparency = 1,
                RichText = true,
                Size = UDim2.new(1, 0, 1, 0),
                Text = l__Name__4,
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u13,
                TextXAlignment = Enum.TextXAlignment.Left
            }), u2.createElement("TextLabel", {
                TextScaled = true,
                BackgroundTransparency = 1,
                RichText = true,
                Position = UDim2.new(1, 0, 0, 0),
                AnchorPoint = Vector2.new(1, 0),
                Size = UDim2.new(1, 0, 1, 0),
                Text = "<font color=\"#" .. v20 .. "\">" .. v19 .. "</font> " .. v21,
                TextColor3 = Color3.new(0.545098, 0.545098, 0.545098),
                FontFace = u13,
                TextXAlignment = Enum.TextXAlignment.Right
            }) });
    end;
    if l__StatAlignment__5 == "Center" then
        return u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = p18.Size,
            LayoutOrder = p18.LayoutOrder
        }, { u2.createElement("TextLabel", {
                TextScaled = true,
                BackgroundTransparency = 1,
                RichText = true,
                Size = UDim2.new(1, 0, 1, 0),
                Text = l__Name__4,
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u13,
                TextXAlignment = Enum.TextXAlignment.Left
            }), u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Position = UDim2.new(0.5, 0, 0, 0),
                Size = UDim2.new(0.5, 0, 1, 0)
            }, { u2.createElement(u6, {
                    BackgroundTransparency = 1,
                    RichText = true,
                    DidMount = l__Self__3.MountTextLabelCalls,
                    Size = UDim2.new(1, 0, 1, 0),
                    Text = "<font color=\"#" .. v20 .. "\">" .. v19 .. "</font> " .. v21,
                    TextColor3 = Color3.new(0.545098, 0.545098, 0.545098),
                    FontFace = u13,
                    TextXAlignment = Enum.TextXAlignment.Left
                }) }) });
    end;
    error("Wrong stat position: " .. l__StatAlignment__5);
end;
function v11.init(p23, _) --[[ Line: 186 ]]
    p23.LastBaseComponentStats = nil;
    p23.MountTextLabelCalls = {};
end;
function v11.didMount(p24, _) --[[ Line: 191 ]]
    p24.LastBaseComponentStats = nil;
    for _, v25 in p24.MountTextLabelCalls do
        v25();
    end;
end;
function v11.didUpdate(p26, _) --[[ Line: 197 ]]
    for _, v27 in p26.MountTextLabelCalls do
        v27();
    end;
end;
function v11.render(p28) --[[ Line: 215 ]]
    -- upvalues: u3 (copy), u4 (copy), u9 (copy), u5 (copy), u10 (copy), u2 (copy), u12 (copy), u6 (copy), u13 (copy), u22 (copy), u14 (copy), u15 (copy), u17 (copy), u7 (copy), l__FIREMODES__2 (copy), u8 (copy)
    local l__props__6 = p28.props;
    local l__ActivePath__7 = l__props__6.ActivePath;
    local l__RootComponent__8 = l__props__6.RootComponent;
    if l__ActivePath__7 then
        l__RootComponent__8 = l__RootComponent__8:GetClosestAttainableChild(table.unpack(l__ActivePath__7)) or l__RootComponent__8;
    end;
    local v29 = l__RootComponent__8:GetBaseComponent(true);
    if not v29 or v29.Path[2] ~= "Receiver" then
        l__props__6.ShowSelectionInfoPanelTween:SetGoal(0);
        p28.LastBaseComponentStats = nil;
        return false;
    end;
    if not l__props__6.HiddenSelectors:getValue() then
        l__props__6.ShowSelectionInfoPanelTween:SetGoal(1);
    end;
    local l__Tune__9 = v29.Tune;
    local v30 = p28.LastBaseComponentStats or l__Tune__9;
    p28.LastBaseComponentStats = l__Tune__9;
    local v31 = u3[l__Tune__9.Caliber];
    local v32 = u3[v30.Caliber];
    local v33, v34, v35 = u4:GetInfo(l__Tune__9.Caliber, l__Tune__9.Barrel);
    local v36, v37, v38 = u4:GetInfo(v30.Caliber, v30.Barrel);
    local v39 = u9.getADSOffsets(v29);
    local v40 = p28.OldSights or v39;
    p28.OldSights = v39;
    local v41 = nil;
    if v39 then
        for _, v42 in v39 do
            local v43 = u9.getADSSpeed(v42, l__Tune__9);
            if v41 then
                v41 = math.min(v41, v43);
            else
                v41 = v43;
            end;
        end;
    end;
    local v44 = nil;
    if v40 then
        for _, v45 in v40 do
            local v46 = u9.getADSSpeed(v45, v30);
            if v44 then
                v44 = math.min(v44, v46);
            else
                v44 = v46;
            end;
        end;
    end;
    local v47;
    if v41 then
        local v48 = 0.013333333333333334 * v41;
        v47 = v48 >= 1 and 0.013333333333333334 or -2.99573227355399 / math.log(1 - v48) * 0.013333333333333334;
    else
        v47 = 0;
    end;
    local v49;
    if v44 then
        local v50 = 0.013333333333333334 * v44;
        v49 = v50 >= 1 and 0.013333333333333334 or -2.99573227355399 / math.log(1 - v50) * 0.013333333333333334;
    else
        v49 = 0;
    end;
    local v51 = l__Tune__9.Firemodes or 0;
    local v52 = l__Tune__9.RPM or 0;
    local v53 = l__Tune__9.Weight or 0;
    local v54 = l__Tune__9.Draw_Loaded or 0;
    local v55 = l__Tune__9.Draw_Ready or 0;
    local v56 = l__Tune__9.Reload_Partial_Ready or 0;
    local v57 = l__Tune__9.Reload_Partial_Loaded or 0;
    local v58 = l__Tune__9.Reload_Empty_Loaded or 0;
    local v59 = l__Tune__9.Reload_Empty_Ready or 0;
    local v60 = v30.RPM or 0;
    local v61 = v30.Weight or 0;
    local v62 = v30.Draw_Loaded or 0;
    local v63 = v30.Draw_Ready or 0;
    local v64 = v30.Reload_Partial_Loaded or 0;
    local v65 = v30.Reload_Partial_Ready or 0;
    local v66 = v30.Reload_Empty_Loaded or 0;
    local v67 = v30.Reload_Empty_Ready or 0;
    local _, v68 = v29:GetMenuConfig();
    local l__MeasurementUnit__10 = u5.MeasurementUnit;
    if l__MeasurementUnit__10 then
        l__MeasurementUnit__10 = u5.MeasurementUnit == 2;
    end;
    local v69 = u10[v68.Manufacturer or "Generic"] or u10.Generic;
    local l__createElement__11 = u2.createElement;
    local v70 = "Frame";
    local v72 = {
        BackgroundTransparency = 0.5,
        Size = UDim2.fromScale(1, 1),
        BackgroundColor3 = Color3.new(),
        Visible = l__props__6.ShowSelectionInfoPanelTween:Map(function(p71) --[[ Line: 311 ]]
            return p71 > 0.2;
        end)
    };
    local v73 = {};
    local v74 = u2.createElement("UICorner", {
        CornerRadius = UDim.new(0, 4)
    });
    local v75 = u2.createElement("UIListLayout", {
        HorizontalAlignment = Enum.HorizontalAlignment.Center,
        VerticalAlignment = Enum.VerticalAlignment.Center,
        FillDirection = Enum.FillDirection.Vertical,
        SortOrder = Enum.SortOrder.LayoutOrder,
        Padding = UDim.new(0.015, 0)
    });
    local v76 = u2.createElement("Frame", {
        BackgroundTransparency = 1,
        LayoutOrder = 0,
        Size = UDim2.new(1, 0, 0.035, 0)
    }, { u2.createElement("TextLabel", {
            TextScaled = true,
            BackgroundTransparency = 1,
            Size = UDim2.new(1, 0, 1.4285714285714286, 0),
            Text = v68.Name,
            TextColor3 = Color3.new(1, 1, 1),
            FontFace = u12,
            TextXAlignment = Enum.TextXAlignment.Center
        }) });
    local l__createElement__12 = u2.createElement;
    local v77 = "Frame";
    local v78 = {
        BackgroundTransparency = 1,
        LayoutOrder = 1,
        Size = UDim2.new(1, 0, 0.015, 0)
    };
    local v79 = {};
    local l__createElement__13 = u2.createElement;
    local v80 = u6;
    local v81 = {
        OnlySizeIfOverExtend = true,
        TextScaled = true,
        BackgroundTransparency = 1,
        DidMount = p28.MountTextLabelCalls,
        Size = UDim2.new(1, 0, 1.6666666666666667, 0)
    };
    local l__FlavorText__14 = v68.FlavorText;
    if not l__FlavorText__14 then
        local l__Category__15 = v68.Category;
        if l__Category__15 then
            l__Category__15 = table.concat(l__Category__15, ", ");
        end;
        l__FlavorText__14 = l__Category__15 or "Item";
    end;
    v81.Text = l__FlavorText__14;
    v81.TextColor3 = Color3.new(1, 1, 1);
    v81.FontFace = u13;
    v81.TextXAlignment = Enum.TextXAlignment.Center;
    v79[1] = l__createElement__13(v80, v81);
    local v82 = l__createElement__12(v77, v78, v79);
    local v83 = u2.createElement("Frame", {
        BackgroundTransparency = 1,
        LayoutOrder = 2,
        Size = UDim2.new(1, 0, 0.02, 0)
    }, { u2.createElement(u6, {
            TextScaled = true,
            BackgroundTransparency = 1,
            DidMount = p28.MountTextLabelCalls,
            Size = UDim2.new(1, 0, 1, 0),
            Text = v69.Name,
            TextColor3 = Color3.new(0.545098, 0.545098, 0.545098),
            FontFace = u13,
            TextXAlignment = Enum.TextXAlignment.Center,
            Position = UDim2.fromScale(0.5, 0),
            AnchorPoint = Vector2.new(0.5, 0)
        }, { u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = v69.Logo or "",
                AnchorPoint = Vector2.new(1, 0.5),
                Position = UDim2.new(0, -2, 0.5, 0),
                Size = UDim2.new((v69.AspectRatio or 1) * (v69.Scale or 1), 0, v69.Scale or 1, 0),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                ScaleType = Enum.ScaleType.Fit
            }) }) });
    local l__createElement__16 = u2.createElement;
    local v84 = "Frame";
    local v85 = {
        LayoutOrder = 3,
        BackgroundTransparency = 0.5,
        Size = UDim2.fromScale(0.9, 0.41),
        BackgroundColor3 = Color3.new()
    };
    local v86 = {};
    local v87 = u2.createElement("UICorner", {
        CornerRadius = UDim.new(0, 4)
    });
    local v88 = u2.createElement("UIListLayout", {
        HorizontalAlignment = Enum.HorizontalAlignment.Center,
        VerticalAlignment = Enum.VerticalAlignment.Top,
        FillDirection = Enum.FillDirection.Vertical,
        SortOrder = Enum.SortOrder.LayoutOrder,
        Padding = UDim.new(0.01, 0)
    });
    local v89 = u2.createElement("UIPadding", {
        PaddingLeft = UDim.new(0.03, 0),
        PaddingRight = UDim.new(0.03, 0),
        PaddingTop = UDim.new(0.03, 0),
        PaddingBottom = UDim.new(0.03, 0)
    });
    local v90 = u2.createElement("TextLabel", {
        LayoutOrder = 1,
        Text = "BALLISTICS",
        TextScaled = true,
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 0.07, 0),
        TextColor3 = Color3.new(1, 1, 1),
        FontFace = u12,
        TextXAlignment = Enum.TextXAlignment.Center,
        SizeConstraint = Enum.SizeConstraint.RelativeXX
    });
    local v91 = u2.createElement(u22, {
        Name = "AMMUNITION",
        AppendText = nil,
        StatAlignment = "Center",
        LayoutOrder = 2,
        Color = Color3.new(1, 1, 1),
        Stat = v31.FamilyName .. " (" .. v31.VariantName .. ")",
        Size = UDim2.new(1, 0, 0.055, 0),
        Self = p28
    });
    local l__createElement__17 = u2.createElement;
    local v92 = u22;
    local v93 = {
        Name = "MUZZLE VELOCITY",
        StatAlignment = "Center",
        LayoutOrder = 4,
        Color = v36 < v33 and u14 or (v33 < v36 and u15 or Color3.new(1, 1, 1))
    };
    local v94 = l__MeasurementUnit__10 and v33 and v33 or v33 / 3.281;
    if type(v94) ~= "string" then
        if math.round(v94) == v94 then
            v94 = tostring(v94);
        else
            v94 = string.format("%.2f", v94);
        end;
    end;
    v93.Stat = v94;
    v93.AppendText = (l__MeasurementUnit__10 and "feet" or "metres") .. "/second";
    v93.Size = UDim2.new(1, 0, 0.055, 0);
    v93.Self = p28;
    local v95 = l__createElement__17(v92, v93);
    local l__createElement__18 = u2.createElement;
    local v96 = u22;
    local v97 = {
        Name = "MAXIMUM RANGE",
        StatAlignment = "Center",
        LayoutOrder = 5,
        Color = v38 < v35 and u14 or (v35 < v38 and u15 or Color3.new(1, 1, 1))
    };
    local v98 = l__MeasurementUnit__10 and v35 and v35 or v35 / 3.281;
    if type(v98) ~= "string" then
        if math.round(v98) == v98 then
            v98 = tostring(v98);
        else
            v98 = string.format("%.2f", v98);
        end;
    end;
    v97.Stat = v98;
    v97.AppendText = l__MeasurementUnit__10 and "feet" or "metres";
    v97.Size = UDim2.new(1, 0, 0.055, 0);
    v97.Self = p28;
    local v99 = l__createElement__18(v96, v97);
    local l__createElement__19 = u2.createElement;
    local v100 = u22;
    local v101 = {
        Name = "DISPERSION",
        StatAlignment = "Center",
        LayoutOrder = 6,
        Color = v31.Spread < v32.Spread and u14 or (v31.Spread > v32.Spread and u15 or Color3.new(1, 1, 1))
    };
    local v102 = l__MeasurementUnit__10 and v31.Spread * 10800 / 3141.592653589793 or v31.Spread;
    if type(v102) ~= "string" then
        if math.round(v102) == v102 then
            v102 = tostring(v102);
        else
            v102 = string.format("%.2f", v102);
        end;
    end;
    v101.Stat = v102;
    v101.AppendText = l__MeasurementUnit__10 and "moa" or "mrad";
    v101.Size = UDim2.new(1, 0, 0.055, 0);
    v101.Self = p28;
    v86[1], v86[2], v86[3], v86[4], v86[5], v86[6], v86[7], v86[8], v86[9], v86[10], v86[11] = v87, v88, v89, v90, v91, v95, v99, l__createElement__19(v100, v101), u2.createElement(u17, {
    LayoutOrder = 7
}), u2.createElement("TextLabel", {
    LayoutOrder = 9,
    Text = "TERMINAL PERFORMANCE",
    TextScaled = true,
    BackgroundTransparency = 1,
    Size = UDim2.new(1, 0, 0.055, 0),
    TextColor3 = Color3.new(1, 1, 1),
    FontFace = u13,
    TextXAlignment = Enum.TextXAlignment.Center,
    SizeConstraint = Enum.SizeConstraint.RelativeXX
}), u2.createElement("Frame", {
    BackgroundTransparency = 1,
    LayoutOrder = 10,
    Size = UDim2.new(1, 0, 0.5, 0)
}, { u2.createElement(u7, {
        Caliber = v31,
        OldCaliber = v32,
        CaliberRange = v35,
        OldCaliberRange = v38,
        CaliberOffset = v34,
        OldCaliberOffset = v37
    }) });
    local v103 = l__createElement__16(v84, v85, v86);
    local l__createElement__20 = u2.createElement;
    local v104 = {
        LayoutOrder = 4,
        BackgroundTransparency = 0.5,
        Size = UDim2.fromScale(0.9, 0.41),
        BackgroundColor3 = Color3.new()
    };
    local v105 = u2.createElement("UICorner", {
        CornerRadius = UDim.new(0, 4)
    });
    local v106 = u2.createElement("UIListLayout", {
        HorizontalAlignment = Enum.HorizontalAlignment.Center,
        VerticalAlignment = Enum.VerticalAlignment.Top,
        FillDirection = Enum.FillDirection.Vertical,
        SortOrder = Enum.SortOrder.LayoutOrder,
        Padding = UDim.new(0.01, 0)
    });
    local v107 = u2.createElement("UIPadding", {
        PaddingLeft = UDim.new(0.03, 0),
        PaddingRight = UDim.new(0.03, 0),
        PaddingTop = UDim.new(0.03, 0),
        PaddingBottom = UDim.new(0.03, 0)
    });
    local v108 = u2.createElement("TextLabel", {
        LayoutOrder = 1,
        Text = "HANDLING/OPERATION",
        TextScaled = true,
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 0.07, 0),
        TextColor3 = Color3.new(1, 1, 1),
        FontFace = u12,
        TextXAlignment = Enum.TextXAlignment.Center,
        SizeConstraint = Enum.SizeConstraint.RelativeXX
    });
    local l__createElement__21 = u2.createElement;
    local v109 = u22;
    local v110 = {
        Name = "FIRE MODES",
        AppendText = nil,
        StatAlignment = "Right",
        LayoutOrder = 2,
        Color = Color3.new(1, 1, 1)
    };
    local v111 = "";
    local v112 = "Frame";
    local v113 = {};
    for v114 = 1, #v51 do
        v111 = v111 .. l__FIREMODES__2[v51[v114]];
        if v114 ~= #v51 then
            v111 = v111 .. " | ";
        end;
    end;
    v110.Stat = v111;
    v110.Size = UDim2.new(1, 0, 0.055, 0);
    v110.Self = p28;
    local v115 = l__createElement__21(v109, v110);
    local l__createElement__22 = u2.createElement;
    local v116 = u22;
    local v117 = {
        Name = "RATE OF FIRE",
        AppendText = "rounds/minute",
        StatAlignment = "Right",
        LayoutOrder = 3,
        Color = v60 < v52 and u14 or (v52 < v60 and u15 or Color3.new(1, 1, 1))
    };
    if type(v52) ~= "string" then
        if math.round(v52) == v52 then
            v52 = tostring(v52);
        else
            v52 = string.format("%.2f", v52);
        end;
    end;
    v117.Stat = v52;
    v117.Size = UDim2.new(1, 0, 0.055, 0);
    v117.Self = p28;
    local v118 = l__createElement__22(v116, v117);
    local l__createElement__23 = u2.createElement;
    local v119 = u22;
    local v120 = {
        Name = "CUMULATIVE MASS",
        StatAlignment = "Right",
        LayoutOrder = 4,
        Color = math.round(v53) < math.round(v61) and u14 or (math.round(v53) > math.round(v61) and u15 or Color3.new(1, 1, 1))
    };
    if l__MeasurementUnit__10 then
        v53 = v53 / 453.6 or v53;
    end;
    if type(v53) ~= "string" then
        if math.round(v53) == v53 then
            v53 = tostring(v53);
        else
            v53 = string.format("%.2f", v53);
        end;
    end;
    v120.Stat = v53;
    v120.AppendText = l__MeasurementUnit__10 and "pounds" or "grams";
    v120.Size = UDim2.new(1, 0, 0.055, 0);
    v120.Self = p28;
    local v121 = l__createElement__23(v119, v120);
    local v122 = u2.createElement(u22, {
        Name = "DRAW TIME",
        AppendText = "seconds",
        StatAlignment = "Right",
        LayoutOrder = 5,
        Color = v54 + v55 < v62 + v63 and u14 or (v54 + v55 > v62 + v63 and u15 or Color3.new(1, 1, 1)),
        Stat = v54 + v55,
        Size = UDim2.new(1, 0, 0.055, 0),
        Self = p28
    });
    local l__createElement__24 = u2.createElement;
    local v123 = u22;
    local v124 = {
        Name = "ADS TIME",
        AppendText = "seconds",
        StatAlignment = "Right",
        LayoutOrder = 6,
        Color = v47 < v49 and u14 or (v49 < v47 and u15 or Color3.new(1, 1, 1))
    };
    if type(v47) ~= "string" then
        if math.round(v47) == v47 then
            v47 = tostring(v47);
        else
            v47 = string.format("%.2f", v47);
        end;
    end;
    v124.Stat = v47;
    v124.Size = UDim2.new(1, 0, 0.055, 0);
    v124.Self = p28;
    local v125 = l__createElement__24(v123, v124);
    local l__createElement__25 = u2.createElement;
    local v126 = u22;
    local v127 = {
        Name = "PARTIAL RELOAD TIME",
        AppendText = "seconds",
        StatAlignment = "Right",
        LayoutOrder = 7,
        Color = v57 + v56 < v64 + v65 and u14 or (v57 + v56 > v64 + v65 and u15 or Color3.new(1, 1, 1))
    };
    if type(v57) ~= "string" then
        if math.round(v57) == v57 then
            v57 = tostring(v57);
        else
            v57 = string.format("%.2f", v57);
        end;
    end;
    local v128 = " + ";
    if type(v56) ~= "string" then
        if math.round(v56) == v56 then
            v56 = tostring(v56);
        else
            v56 = string.format("%.2f", v56);
        end;
    end;
    v127.Stat = v57 .. v128 .. v56;
    v127.Size = UDim2.new(1, 0, 0.055, 0);
    v127.Self = p28;
    local v129 = l__createElement__25(v126, v127);
    local l__createElement__26 = u2.createElement;
    local v130 = u22;
    local v131 = {
        Name = "EMPTY RELOAD TIME",
        AppendText = "seconds",
        StatAlignment = "Right",
        LayoutOrder = 8,
        Color = v58 + v59 < v66 + v67 and u14 or (v58 + v59 > v66 + v67 and u15 or Color3.new(1, 1, 1))
    };
    if type(v58) ~= "string" then
        if math.round(v58) == v58 then
            v58 = tostring(v58);
        else
            v58 = string.format("%.2f", v58);
        end;
    end;
    local v132 = " + ";
    if type(v59) ~= "string" then
        if math.round(v59) == v59 then
            v59 = tostring(v59);
        else
            v59 = string.format("%.2f", v59);
        end;
    end;
    v131.Stat = v58 .. v132 .. v59;
    v131.Size = UDim2.new(1, 0, 0.055, 0);
    v131.Self = p28;
    v113[1], v113[2], v113[3], v113[4], v113[5], v113[6], v113[7], v113[8], v113[9], v113[10], v113[11], v113[12], v113[13], v113[14] = v105, v106, v107, v108, v115, v118, v121, v122, v125, v129, l__createElement__26(v130, v131), u2.createElement(u17, {
    LayoutOrder = 9
}), u2.createElement("TextLabel", {
    LayoutOrder = 10,
    Text = "RECOIL BREAKDOWN",
    TextScaled = true,
    BackgroundTransparency = 1,
    Size = UDim2.new(1, 0, 0.055, 0),
    SizeConstraint = Enum.SizeConstraint.RelativeXX,
    TextColor3 = Color3.new(1, 1, 1),
    FontFace = u13,
    TextXAlignment = Enum.TextXAlignment.Center
}), u2.createElement("Frame", {
    BackgroundTransparency = 1,
    LayoutOrder = 11,
    Size = UDim2.new(1, 0, 0.4, 0)
}, { u2.createElement(u8, {
        NewTune = l__Tune__9,
        OldTune = v30,
        NewBaseComponent = v29,
        ShowSelectionInfoPanelTween = l__props__6.ShowSelectionInfoPanelTween,
        Ignore = l__props__6.Ignore
    }) });
    v73[1], v73[2], v73[3], v73[4], v73[5], v73[6], v73[7] = v74, v75, v76, v82, v83, v103, l__createElement__20(v112, v104, v113);
    return l__createElement__11(v70, v72, v73);
end;
return v11;