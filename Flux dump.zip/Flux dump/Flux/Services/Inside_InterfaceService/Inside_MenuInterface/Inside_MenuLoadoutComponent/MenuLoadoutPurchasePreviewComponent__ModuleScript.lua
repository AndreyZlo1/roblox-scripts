-- Services.InterfaceService.MenuInterface.MenuLoadoutComponent.MenuLoadoutPurchasePreviewComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "Enum");
local u4 = v1("StatsService");
local u5 = v1("PopupInterface");
local u6 = v1("skipLevel");
local u7 = v1("formatNumber");
local u8 = v1("GameShellProxyButton");
local u9 = v1("GameShellProxyTextLabel");
local u10 = v1("MenuLoadoutConstants");
local u11 = v1("MenuButtonComponent");
local v12 = u2.Component:extend("MenuLoadoutPurchasePreviewComponent");
local u13 = Font.fromId(12187375422, u3.FontWeight.Bold, u3.FontStyle.Normal);
local u14 = Font.fromId(12187375422, u3.FontWeight.Regular, u3.FontStyle.Normal);
function v12.init(p15) --[[ Line: 42 ]]
    p15.MountTextLabelCalls = {};
    p15.CloseHoverBindings = {};
    p15.UpdCloseHoverBindings = {};
end;
function v12.didMount(p16) --[[ Line: 48 ]]
    for _, v17 in p16.MountTextLabelCalls do
        v17();
    end;
end;
function v12.didUpdate(p18) --[[ Line: 53 ]]
    for _, v19 in p18.MountTextLabelCalls do
        v19();
    end;
end;
function v12.render(u20) --[[ Line: 59 ]]
    -- upvalues: u2 (copy), u6 (copy), u4 (copy), u10 (copy), u7 (copy), u3 (copy), u9 (copy), u14 (copy), u8 (copy), u13 (copy), u11 (copy), u5 (copy)
    local l__props__1 = u20.props;
    local l__Ignore__2 = l__props__1.Ignore;
    local l__Components__3 = l__props__1.Components;
    local l__RemovedComponent__4 = l__props__1.RemovedComponent;
    local l__CanceledPreview__5 = l__props__1.CanceledPreview;
    local l__PurchasedPreview__6 = l__props__1.PurchasedPreview;
    for v21, _ in u20.CloseHoverBindings do
        if not l__Components__3[v21] then
            u20.CloseHoverBindings[v21] = nil;
            u20.UpdCloseHoverBindings[v21] = nil;
        end;
    end;
    local v22 = #l__Components__3;
    if v22 ~= 0 then
        local v23 = {};
        local u24 = 0;
        local v25 = {};
        for u26, v27 in l__Components__3 do
            local l__Config__7 = v27.Config;
            if not u20.CloseHoverBindings[u26] then
                local v28, v29 = u2.createBinding(false);
                u20.CloseHoverBindings[u26] = v28;
                u20.UpdCloseHoverBindings[u26] = v29;
            end;
            local v30 = u6(u4.Level, l__Config__7.Level or 0, l__Config__7.Price or 0);
            local v31 = l__Config__7.CamoPath or l__Config__7.Path;
            local v32 = "";
            for v33 = 1, #v31 do
                v32 = v32 .. v31[v33] .. "$";
            end;
            local v34 = v23[v32] and 0 or v30;
            v23[v32] = true;
            u24 = u24 + v34;
            local v35 = l__Config__7.Path[#l__Config__7.Path - 1];
            local v36 = u10.SubIndexDisplayNames[v35] or v35;
            local v37 = not (v27.Component and v27.Component:IsNecessary());
            local v38 = l__Config__7.Gamepass and "<font color=\"rgb(85,255,127)\">GP</font>" or "<font color=\"rgb(255,205,122)\">+" .. u7(v34) .. "</font>";
            local v39 = "(" .. v36 .. " - " .. "<font color=\"rgb(170,170,170)\">" .. l__Config__7.Name .. "</font>)";
            local l__createElement__8 = u2.createElement;
            local v40 = "Frame";
            local v41 = {
                BackgroundTransparency = 1,
                LayoutOrder = u26,
                Size = UDim2.new(1, 0, 0.12, 0)
            };
            local v42 = {};
            local v43 = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(0.95, 1)
            }, { u2.createElement("UIListLayout", {
                    SortOrder = u3.SortOrder.LayoutOrder,
                    FillDirection = u3.FillDirection.Horizontal,
                    HorizontalAlignment = u3.HorizontalAlignment.Left,
                    VerticalAlignment = u3.VerticalAlignment.Center,
                    Padding = UDim.new(0, 3)
                }), u2.createElement(u9, {
                    BackgroundTransparency = 1,
                    LayoutOrder = 1,
                    RichText = true,
                    DidMount = u20.MountTextLabelCalls,
                    Text = v38,
                    TextColor3 = Color3.new(1, 1, 1),
                    FontFace = u14,
                    TextXAlignment = u3.TextXAlignment.Left,
                    Size = UDim2.new(1, 0, 1, 0)
                }), u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    LayoutOrder = 2,
                    Size = UDim2.fromScale(0.8, 1)
                }, { u2.createElement(u9, {
                        BackgroundTransparency = 1,
                        RichText = true,
                        DidMount = u20.MountTextLabelCalls,
                        Size = UDim2.new(2, 0, 1, 0),
                        Text = v39,
                        TextColor3 = Color3.new(1, 1, 1),
                        FontFace = u14,
                        TextXAlignment = u3.TextXAlignment.Left
                    }) }) });
            if v37 then
                v37 = u2.createElement(u8, {
                    Image = "rbxassetid://264596039",
                    BackgroundTransparency = 1,
                    Ignore = l__Ignore__2,
                    AnchorPoint = Vector2.new(1, 0),
                    Position = UDim2.fromScale(0.95, 0.15),
                    Size = UDim2.fromScale(0.6, 0.6),
                    SizeConstraint = u3.SizeConstraint.RelativeYY,
                    ImageColor3 = u20.CloseHoverBindings[u26]:map(function(p44) --[[ Line: 163 ]]
                        return p44 and Color3.fromRGB(255, 194, 89) or Color3.new(1, 1, 1);
                    end),
                    MouseUp = function() --[[ Name: MouseUp, Line 166 ]]
                        -- upvalues: l__RemovedComponent__4 (copy), u26 (copy)
                        l__RemovedComponent__4(u26);
                    end,
                    MouseEnter = function() --[[ Name: MouseEnter, Line 169 ]]
                        -- upvalues: u20 (copy), u26 (copy)
                        u20.UpdCloseHoverBindings[u26](true);
                    end,
                    MouseLeave = function() --[[ Name: MouseLeave, Line 172 ]]
                        -- upvalues: u20 (copy), u26 (copy)
                        u20.UpdCloseHoverBindings[u26](false);
                    end
                });
            end;
            v42[1], v42[2] = v43, v37;
            v25[u26] = l__createElement__8(v40, v41, v42);
        end;
        local v45 = v22 * 0.12 + 0.18 + (v22 + 1) * 0.04 + 0.2;
        return u2.createFragment({ u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundTransparency = 0,
                ZIndex = -1,
                BackgroundColor3 = Color3.fromRGB(24, 24, 24),
                AnchorPoint = Vector2.new(0, 1),
                Position = UDim2.fromScale(0, 1),
                Size = UDim2.new(1, 0, v45 * 0.8 + 0.15000000000000002, 0)
            }, { u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Image = "rbxassetid://13867939464",
                    Size = UDim2.fromScale(1, 1),
                    ImageColor3 = Color3.fromRGB(160, 160, 160),
                    TileSize = UDim2.fromOffset(6, 6),
                    ScaleType = u3.ScaleType.Tile
                }, { u2.createElement("UIGradient", {
                        Rotation = 90,
                        Transparency = NumberSequence.new({
                            NumberSequenceKeypoint.new(0, 0.7),
                            NumberSequenceKeypoint.new(0.45, 1),
                            NumberSequenceKeypoint.new(0.56, 1),
                            NumberSequenceKeypoint.new(1, 0)
                        })
                    }) }) }), u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(1, 1),
                Position = UDim2.fromScale(0, 1),
                AnchorPoint = Vector2.new(0, 1)
            }, {
                u2.createElement("UIPadding", {
                    PaddingLeft = UDim.new(0.04, 0),
                    PaddingTop = UDim.new(0.1, 0),
                    PaddingBottom = UDim.new(0.1, 0),
                    PaddingRight = UDim.new(0.04, 0)
                }),
                u2.createElement("UIListLayout", {
                    SortOrder = u3.SortOrder.LayoutOrder,
                    FillDirection = u3.FillDirection.Vertical,
                    HorizontalAlignment = u3.HorizontalAlignment.Center,
                    VerticalAlignment = u3.VerticalAlignment.Bottom,
                    Padding = UDim.new(0.04, 0)
                }),
                u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "PURCHASE PREVIEW",
                    TextScaled = true,
                    LayoutOrder = 0,
                    Size = UDim2.fromScale(1, 0.2),
                    TextColor3 = Color3.fromRGB(255, 255, 255),
                    FontFace = u13,
                    TextXAlignment = u3.TextXAlignment.Center
                }),
                u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    LayoutOrder = 999,
                    Size = UDim2.fromScale(1, 0.18)
                }, { u2.createElement(u11, {
                        Activated = false,
                        Name = "PURCHASE - " .. u7(u24),
                        Size = UDim2.new(0.78, 0, 1, 0),
                        Ignore = l__Ignore__2,
                        Callback = function() --[[ Name: Callback, Line 252 ]]
                            -- upvalues: u4 (ref), u24 (ref), l__PurchasedPreview__6 (copy), u5 (ref), u3 (ref)
                            if u24 <= u4.Money then
                                l__PurchasedPreview__6();
                            else
                                u5:Open("Insufficient Funds", nil, {
                                    { "Close", function() --[[ Line: 257 ]]
                                            -- upvalues: u5 (ref)
                                            u5:Close();
                                        end }
                                }, u3.PopupType.Shop);
                            end;
                        end
                    }), u2.createElement(u11, {
                        Name = "CANCEL",
                        Activated = false,
                        Size = UDim2.new(0.2, -3, 1, 0),
                        Position = UDim2.new(1, 0, 0, 0),
                        AnchorPoint = Vector2.new(1, 0),
                        Ignore = l__Ignore__2,
                        Callback = function() --[[ Name: Callback, Line 271 ]]
                            -- upvalues: l__CanceledPreview__5 (copy)
                            l__CanceledPreview__5();
                        end
                    }) }),
                u2.createFragment(v25)
            }) });
    end;
end;
return v12;