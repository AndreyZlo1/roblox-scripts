-- Services.InterfaceService.MenuInterface.MenuLoadoutComponent.MenuLoadoutSliderComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "network");
local u3 = v1("GameShellProxyButton");
local l__RunService__1 = game:GetService("RunService");
local l__UserInputService__2 = game:GetService("UserInputService");
local v4 = u2.Component:extend("MenuLoadoutSliderComponent");
function v4.init(u5, _) --[[ Line: 30 ]]
    -- upvalues: u2 (copy), l__RunService__1 (copy), l__UserInputService__2 (copy)
    u5.This = u2.createRef();
    u5.Grabbing = false;
    u5.LastInitialValue = u5.props.InitialValue or 0;
    local v6, v7 = u2.createBinding(u5.props.InitialValue or 0);
    u5.ValueBinding = v6;
    u5.UpdateValue = v7;
    function u5.SetValue(p8) --[[ Line: 36 ]]
        -- upvalues: u5 (copy)
        local v9 = u5.ValueBinding:getValue();
        if u5.props.Callback then
            u5.props.Callback(p8, v9);
        end;
        u5.UpdateValue(p8);
    end;
    u5.Update = l__RunService__1.Heartbeat:Connect(function() --[[ Line: 44 ]]
        -- upvalues: u5 (copy), l__UserInputService__2 (ref)
        if u5.Grabbing then
            local v10 = u5.This:getValue();
            if v10 then
                local l__X__3 = v10.AbsolutePosition.X;
                local v11 = l__X__3 + v10.AbsoluteSize.X;
                local l__X__4 = l__UserInputService__2:GetMouseLocation().X;
                local v12 = u5.props.Min or 0;
                local v13 = v12 + (l__X__4 - l__X__3) / (v11 - l__X__3) * ((u5.props.Max or 1) - v12);
                local v14 = u5.props.Increment or 1;
                if v14 then
                    local v15 = 1 / v14;
                    v13 = math.floor(v13 * v15 + 0.5) / v15;
                end;
                local v16 = math.clamp(v13, u5.props.Min or 0, u5.props.Max or 1);
                u5.SetValue(v16);
            end;
        end;
    end);
    u5.Ended = l__UserInputService__2.InputEnded:Connect(function(p17) --[[ Line: 61 ]]
        -- upvalues: u5 (copy)
        if p17.UserInputType == Enum.UserInputType.MouseButton1 then
            u5.Grabbing = false;
            u5:setState({});
        end;
    end);
    u5.TouchEnded = l__UserInputService__2.TouchEnded:Connect(function(_) --[[ Line: 67 ]]
        -- upvalues: u5 (copy)
        if u5.Grabbing then
            u5.Grabbing = false;
            u5:setState({});
        end;
    end);
    u5.Changed = l__UserInputService__2.InputChanged:Connect(function(p18) --[[ Line: 73 ]]
        -- upvalues: u5 (copy)
        if u5.state.Hovering then
            if p18.UserInputType == Enum.UserInputType.Gamepad1 and p18.KeyCode == Enum.KeyCode.Thumbstick1 then
                u5.Grabbing = false;
                u5:setState({});
                local l__X__5 = p18.Position.X;
                if math.abs(l__X__5) < 0.05 then
                    return;
                end;
                local v19 = u5.ValueBinding:getValue() + l__X__5 * 0.05;
                local v20 = math.clamp(v19, u5.props.Min or 0, u5.props.Max or 1);
                u5.SetValue(v20);
            end;
        end;
    end);
    u5:setState({
        Hovering = false
    });
end;
function v4.willUnmount(p21) --[[ Line: 99 ]]
    p21.Update:Disconnect();
    p21.Ended:Disconnect();
    p21.TouchEnded:Disconnect();
    p21.Changed:Disconnect();
end;
function v4.render(u22) --[[ Line: 106 ]]
    -- upvalues: u2 (copy), u3 (copy)
    local v23 = u22.state.Hovering or u22.Grabbing;
    local v24 = u22.props.InitialValue or 0;
    if u22.LastInitialValue ~= v24 then
        u22.LastInitialValue = v24;
        u22.UpdateValue(u22.LastInitialValue);
    end;
    return u2.createElement(u3, {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 1),
        Ignore = u22.props.Ignore,
        Ref = u22.This,
        MouseDown = function() --[[ Name: MouseDown, Line 124 ]]
            -- upvalues: u22 (copy)
            u22.Grabbing = true;
        end,
        MouseEnter = function() --[[ Name: MouseEnter, Line 127 ]]
            -- upvalues: u22 (copy)
            u22:setState({
                Hovering = true
            });
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 132 ]]
            -- upvalues: u22 (copy)
            u22:setState({
                Hovering = false
            });
        end
    }, {
        Grabber = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 3,
            AnchorPoint = Vector2.new(0.5, 0.5),
            BackgroundColor3 = (v23 and Color3.fromRGB(255, 202, 94) or Color3.fromRGB(71, 71, 71)):Lerp(Color3.new(), 0.5),
            Size = UDim2.new(0.03, 0, 0.5, 0),
            Position = u22.ValueBinding:map(function(p25) --[[ Line: 144 ]]
                -- upvalues: u22 (copy)
                local l__new__6 = UDim2.new;
                local l__Min__7 = u22.props.Min;
                return l__new__6((p25 - l__Min__7) / (u22.props.Max - l__Min__7), 0, 0.5, 0);
            end)
        }, {
            Corner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 1)
            }),
            Stroke = u2.createElement("UIStroke", {
                Thickness = 1,
                ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                Color = v23 and Color3.fromRGB(255, 202, 94) or Color3.fromRGB(71, 71, 71),
                LineJoinMode = Enum.LineJoinMode.Round
            })
        }),
        Slider = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0, 0.5),
            BackgroundColor3 = v23 and Color3.fromRGB(255, 202, 94) or Color3.fromRGB(71, 71, 71),
            Position = UDim2.new(0, 0, 0.5, 0),
            Size = u22.ValueBinding:map(function(p26) --[[ Line: 163 ]]
                -- upvalues: u22 (copy)
                local l__new__8 = UDim2.new;
                local l__Min__9 = u22.props.Min;
                return l__new__8((p26 - l__Min__9) / (u22.props.Max - l__Min__9), 0, 0, 1);
            end)
        }),
        Black = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 1,
            AnchorPoint = Vector2.new(0, 0.5),
            BackgroundColor3 = Color3.new(),
            Position = UDim2.new(0, 0, 0.5, 0),
            Size = UDim2.new(1, 0, 0.2, 0)
        })
    });
end;
return v4;