-- Services.InterfaceService.MenuInterface.MenuLoadoutComponent.MenuLoadoutViewportFrame
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _, _ = shared.import("require", "Roact", "asset", "network");
local u3 = v1("AttachableComponent");
local u4 = v1({ "FlashlightAttachmentReplicator", "LaserAttachmentReplicator", "StrobeAttachmentReplicator" });
local u5 = v1("ReticleService");
local v6 = u2.Component:extend("MenuLoadoutViewportFrame");
local u7 = v1("MenuLoadoutConstants");
local u8 = Instance.new("Camera");
u8.FieldOfView = 10;
u8.CFrame = CFrame.new(Vector3.new(0, 0, 0), Vector3.new(-0, -0, -1));
local u9 = Instance.new("Part");
u9.CFrame = CFrame.new(0, 0, -50);
u9.Size = Vector3.new(2043, 2043, 1);
u9.Material = Enum.Material.Wood;
u9.Transparency = 0.5;
u9.Color = Color3.new(0.423529, 0.458824, 0.494118);
u9.Anchored = true;
local u10 = CFrame.Angles(0, -2.356194490192345, 0) * CFrame.Angles(-0.39269908169872414, 0, -0.39269908169872414);
function v6.init(p11, p12) --[[ Line: 28 ]]
    -- upvalues: u2 (copy)
    p11.WorldModelRef = u2.createRef();
    p11.VPFRef = u2.createRef();
    p11.MetaOverrides = p12.MetaOverrides;
    p11.Reticles = {};
end;
local function u31(p13, p14) --[[ Line: 43 ]]
    -- upvalues: u4 (copy), u7 (copy), u5 (copy), u9 (copy)
    local l__Attachments__1 = p13.File.Attachments;
    if l__Attachments__1 then
        for v15, v16 in l__Attachments__1 do
            local v17 = p13.MetaData[v15 .. "State"];
            if v17 and v17 > 0 then
                local v18 = u4[v15 .. "AttachmentReplicator"].new(nil, v16, nil, p13, nil);
                v18:SetState(v17);
                v18:Update(0.016666666666666666, false, true);
                for _, v19 in v18:GetVPFModels() do
                    v19.Parent = p13.ParentModel;
                end;
                v18:Destroy();
            end;
        end;
    end;
    local l__Config__2 = p13.File.Config;
    if l__Config__2 and (l__Config__2.Reticles or (l__Config__2.Sights or l__Config__2.Magnifier)) and (p14.HoverPanel and u7.SightPreviews[p13.Path[#p13.Path - 1]]) then
        local l__Model__3 = p13.Model;
        for v20, v21 in l__Config__2.Reticles or {} do
            local v22 = l__Model__3:FindFirstChild(v21.Glass or "glass");
            if v22 then
                p14.Reticles[#p14.Reticles + 1] = u5:RegisterReticle(v22, v21, v20, p14.VPFRef:getValue());
            end;
        end;
        local v23 = l__Config__2.Sights and l__Config__2.Sights[p14.MetaOverrides.SightsState or 1] or l__Config__2.Magnifier;
        if v23 then
            for _, v24 in v23.Cutaway or {} do
                local v25 = p13.Model:FindFirstChild(v24);
                if v25 then
                    v25.Transparency = 1;
                end;
            end;
            for _, v26 in v23.CutawayInverted or {} do
                local v27 = p13.Model:FindFirstChild(v26);
                if v27 then
                    v27.Transparency = 0;
                end;
            end;
        end;
        local v28 = p14.Camera:GetAttribute("SightFOV") or p14.Camera.FieldOfView;
        local v29 = math.rad(v28) / 2;
        local v30 = 1 / (-0.013092960784593466 / math.tan(v29));
        u9.CFrame = CFrame.new(0, 0, v30 * 8);
        u9.Parent = p13.ParentModel;
    end;
end;
local function u51(u32) --[[ Line: 112 ]]
    -- upvalues: u5 (copy), u9 (copy), u3 (copy), u7 (copy), u10 (copy), u31 (copy)
    local l__Config__4 = u32.Config;
    if l__Config__4.getValue then
        l__Config__4 = l__Config__4:getValue();
    end;
    for v33 = #u32.Reticles, 1, -1 do
        u5:UnregisterReticle(table.remove(u32.Reticles, v33));
    end;
    if u32.AComp then
        if u9.Parent == u32.AComp.ParentModel then
            u9.Parent = nil;
        end;
        if u32.AComp.Destroy then
            u32.AComp:Destroy();
        end;
        u32.AComp = nil;
    end;
    if l__Config__4 and not (l__Config__4.Icon or l__Config__4.Color) then
        local v34 = u32.WorldModelRef:getValue();
        if l__Config__4.UseComponent then
            u32.AComp = l__Config__4.UseComponent;
        elseif l__Config__4.IsCamo then
            u32.AComp = u3.new(l__Config__4.Path, {
                Camo = l__Config__4.CamoPath[#l__Config__4.CamoPath]
            }, nil);
        else
            u32.AComp = u3.new(l__Config__4.Path, nil, nil);
        end;
        if u32.AComp.ParentModel.PrimaryPart then
            u32.AComp.ParentModel.PrimaryPart.Anchored = true;
            local l__Config__5 = u32.AComp.File.Config;
            if l__Config__5 and (l__Config__5.Reticles or (l__Config__5.Sights or l__Config__5.Magnifier)) and (u32.HoverPanel and u7.SightPreviews[u32.AComp.Path[#u32.AComp.Path - 1]]) then
                u32.AComp.ParentModel:ScaleTo(u32.AComp.ParentModel:GetScale() * 3);
            end;
            if u32.MetaOverrides then
                u32.AComp:EditMetaData(u32.MetaOverrides);
            end;
            local u35 = u32.ModelCF or (l__Config__4.ModelCFrame or u10);
            local v36 = u32.AComp.Model:FindFirstChild("post");
            local v37 = v36 and u32.AComp.Model:FindFirstChild("flip", true);
            if v37 then
                local v38 = v36.CFrame:Inverse() * v37.WorldCFrame;
                local v39 = v36.CFrame * v38 * CFrame.Angles(-1.5707963267948966, 0, 0) * v38:Inverse();
                local v40 = v36:FindFirstChildWhichIsA("Weld");
                if v40 then
                    v40:Destroy();
                end;
                v36.CFrame = v39;
            end;
            local l__AComp__6 = u32.AComp;
            l__AComp__6.ParentModel.Parent = v34;
            task.defer(function() --[[ Line: 185 ]]
                -- upvalues: u32 (copy), l__AComp__6 (copy), l__Config__4 (copy), u35 (copy), u31 (ref)
                if u32.AComp == l__AComp__6 then
                    if u32.CameraCF or l__Config__4.CameraCFrame then
                        local l__ParentModel__7 = u32.AComp.ParentModel;
                        local v41 = (u32.CameraCF or l__Config__4.CameraCFrame) * u35;
                        local v42 = l__ParentModel__7:GetBoundingBox();
                        local v43 = l__ParentModel__7:GetPivot();
                        l__ParentModel__7:PivotTo(v41 * (v42:Inverse() * v43));
                    else
                        local l__ParentModel__8 = u32.AComp.ParentModel;
                        local l__new__9 = CFrame.new;
                        local l__FieldOfView__10 = u32.Camera.FieldOfView;
                        local v44 = u35:VectorToObjectSpace(u32.AComp.ParentModel:GetExtentsSize());
                        local v45 = math.sqrt(v44.X ^ 2 + v44.Y ^ 2 + v44.Z ^ 2);
                        local v46 = math.rad(l__FieldOfView__10) / 2;
                        local v47 = math.tan(v46);
                        local v48 = l__new__9(0, 0, -(v45 * 0.5 / v47 * 1.05)) * u35;
                        local v49 = l__ParentModel__8:GetBoundingBox();
                        local v50 = l__ParentModel__8:GetPivot();
                        l__ParentModel__8:PivotTo(v48 * (v49:Inverse() * v50));
                    end;
                    task.defer(function() --[[ Line: 196 ]]
                        -- upvalues: u32 (ref), l__AComp__6 (ref), u31 (ref)
                        if u32.AComp == l__AComp__6 then
                            u31(u32.AComp, u32);
                        end;
                    end);
                end;
            end);
        else
            if u9.Parent == u32.AComp.ParentModel then
                u9.Parent = nil;
            end;
            if u32.AComp.Destroy then
                u32.AComp:Destroy();
            end;
            u32.AComp = nil;
        end;
    end;
end;
function v6.didMount(u52) --[[ Line: 206 ]]
    -- upvalues: u51 (copy)
    u51(u52);
    if u52.UpdateVPF then
        u52.UpdateVPF[u52] = function(p53) --[[ Line: 210 ]]
            -- upvalues: u52 (copy), u51 (ref)
            for v54, v55 in p53 do
                u52.MetaOverrides[v54] = v55;
            end;
            u51(u52);
        end;
    end;
end;
function v6.willUnmount(p56) --[[ Line: 219 ]]
    -- upvalues: u9 (copy), u5 (copy)
    if p56.UpdateVPF then
        p56.UpdateVPF[p56] = nil;
    end;
    if p56.AComp then
        if u9.Parent == p56.AComp.ParentModel then
            u9.Parent = nil;
        end;
        if p56.AComp.Destroy then
            p56.AComp:Destroy();
        end;
        p56.AComp = nil;
    end;
    for v57 = #p56.Reticles, 1, -1 do
        u5:UnregisterReticle(table.remove(p56.Reticles, v57));
    end;
end;
function v6.didUpdate(p58) --[[ Line: 239 ]]
    -- upvalues: u51 (copy)
    u51(p58);
end;
function v6.render(p59) --[[ Line: 243 ]]
    -- upvalues: u8 (copy), u2 (copy)
    local l__props__11 = p59.props;
    l__props__11.MetaOverrides = nil;
    p59.Config = l__props__11.Config;
    l__props__11.Config = nil;
    p59.UpdateVPF = l__props__11.UpdateVPF;
    l__props__11.UpdateVPF = nil;
    p59.ModelCF = l__props__11.ModelCF;
    l__props__11.ModelCF = nil;
    p59.CameraCF = l__props__11.CameraCF;
    l__props__11.CameraCF = nil;
    p59.HoverPanel = l__props__11.HoverPanel;
    l__props__11.HoverPanel = nil;
    l__props__11.ClipsDescendants = true;
    p59.Camera = l__props__11.Camera or u8;
    l__props__11.Camera = nil;
    l__props__11[u2.Children] = l__props__11[u2.Children] or {};
    l__props__11[u2.Children].ViewportWorldModel = u2.createElement("WorldModel", {
        [u2.Ref] = p59.WorldModelRef
    });
    l__props__11.CurrentCamera = p59.Camera;
    l__props__11[u2.Ref] = p59.VPFRef;
    return u2.createElement("ViewportFrame", l__props__11);
end;
return v6;