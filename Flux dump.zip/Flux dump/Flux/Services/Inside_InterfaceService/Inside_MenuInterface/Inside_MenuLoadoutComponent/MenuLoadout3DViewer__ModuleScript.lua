-- Services.InterfaceService.MenuInterface.MenuLoadoutComponent.MenuLoadout3DViewer
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _, u3 = shared.import("require", "Roact", "asset", "Enum");
local l__UserInputService__1 = game:GetService("UserInputService");
local u4 = v1("Quaternion");
local u5 = v1("InputService");
local u6 = v1("PostProcessingService");
local u7 = v1("GameSettings");
local u8 = v1("MenuLoadout3DViewerSelectorComponent");
local u9 = v1("GameShellProxyService");
local u10 = v1("MenuLoadoutConstants");
local u11 = u9:CreateProxy(2, u3.ShellPriority.AlwaysVisible, "MenuLoadout3DViewerSelector");
local l__PlayerGui__2 = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui");
local u12 = { "Vest", "Helmet", "Belt" };
local l__CurrentCamera__3 = workspace.CurrentCamera;
local u13 = {};
local u14 = {};
u14.__index = u14;
function u14.new(p15, p16, p17, p18, p19, p20) --[[ Line: 71 ]]
    -- upvalues: u2 (copy), l__PlayerGui__2 (copy), u4 (copy), u14 (copy), u6 (copy), u13 (copy)
    local v21, v22 = u2.createBinding(true);
    local v23, v24 = u2.createBinding(nil);
    local v25, v26 = u2.createBinding(nil);
    local v27 = Instance.new("Highlight");
    v27.FillTransparency = 0.9;
    v27.FillColor = Color3.new(1, 1, 1);
    v27.Parent = l__PlayerGui__2;
    local v28 = {
        _position = p15.Position,
        _rotation = u4.FromCFrame(p15),
        _targetPosition = p15.Position,
        _originalCF = p15,
        _targetRotation = u4.FromCFrame(p15),
        _globalHighlight = v27,
        _originalCameraCF = p16,
        _targetCameraCF = p16,
        _mx = 0,
        _my = 0,
        _cameraCF = p16,
        _rx = 1,
        _ry = 1,
        _pivotMode = "center",
        _viewIsChanged = v25,
        _updViewIsChanged = v26,
        DraggingEnabled = true,
        Callback = p19,
        SlideCallback = p20,
        SlidingEnabled = true,
        _slidingComponent = nil,
        _slidingAmount = nil,
        _slidingDelta = 0,
        _slidingMousePosition = nil,
        _slidingConnections = {},
        _slidingBinding = v23,
        _updSlidingBinding = v24,
        _component = nil,
        _selectors = nil,
        _selectorsEnabled = v21,
        _updSelectorsEnabled = v22,
        _doBuildSelectors = true,
        _selectorsDescendants = true,
        _selectorsParent = false,
        _selectorDepth = nil,
        _selectorScale = 1,
        _activePath = nil,
        _parent = p18
    };
    local v29 = setmetatable(v28, u14);
    v29.DOPEffect = u6:AddDepthOfField({
        FarIntensity = 0.258,
        FocusDistance = 0,
        InFocusRadius = 6,
        NearIntensity = 0,
        AutoFocus = false
    }, 4, true);
    if p17 then
        v29:SetComponent(p17);
    end;
    table.insert(u13, v29);
    return v29;
end;
function u14.Destroy(p30) --[[ Line: 148 ]]
    -- upvalues: u13 (copy), u2 (copy)
    p30.DOPEffect.Destroy();
    p30._globalHighlight:Destroy();
    local v31 = table.find(u13, p30);
    if v31 then
        table.remove(u13, v31);
    end;
    p30:SetComponent(nil);
    if p30._selectors then
        u2.unmount(p30._selectors);
        p30._selectors = nil;
    end;
end;
function u14.SetActivePath(p32, p33) --[[ Line: 165 ]]
    p32._activePath = p33;
end;
function u14.SetPopupActive(p34, p35) --[[ Line: 169 ]]
    p34._updSelectorsEnabled(not p35);
end;
function u14.ConfigureSelectors(p36, p37, p38, p39, p40) --[[ Line: 173 ]]
    -- upvalues: u2 (copy)
    if p36._selectors then
        u2.unmount(p36._selectors);
        p36._selectors = nil;
    end;
    if p37 ~= nil then
        p36._doBuildSelectors = p37;
    end;
    if p38 ~= nil then
        p36._selectorsComponent = p38;
    end;
    if p39 ~= nil then
        p36._selectorDepth = p39;
    end;
    if p40 ~= nil then
        p36._selectorScale = p40;
    end;
    if p37 then
        p36:_buildSelectors();
    end;
end;
function u14._buildSelectors(u41) --[[ Line: 200 ]]
    -- upvalues: u12 (copy), u10 (copy), u2 (copy), u8 (copy), u11 (copy)
    if not u41._doBuildSelectors then
        return;
    end;
    if not (u41._component and u41._component.GetRootComponent) then
        return;
    end;
    local u42 = {};
    local l___selectorsComponent__4 = u41._selectorsComponent;
    if not l___selectorsComponent__4 then
        return;
    end;
    local v43 = u41._selectorDepth or (1 / 0);
    local v44 = l___selectorsComponent__4:GetAttachments(1, v43);
    local l___activePath__5 = u41._activePath;
    local u45 = l___activePath__5 and table.find(u12, l___activePath__5[3]) and true or false;
    for v46 = 1, #v44 do
        local u47 = v44[v46];
        if not u10.HideSubName[u47.SubName] and (u47.ParentComponent.Children[u47.SubName] and not (u47.ParentComponent.File.Invisible and u47.ParentComponent.File.Invisible[u47.SubName])) then
            local v48;
            if string.sub(u47.Attachment.Name, -6, -1) == "_start" then
                local u49 = u47.Attachment.Parent:FindFirstChild(string.sub(u47.Attachment.Name, 1, -7) .. "_center") or Instance.new("Attachment", u47.Attachment.Parent);
                u49.Name = string.sub(u47.Attachment.Name, 1, -7) .. "_center";
                local l__CFrame__6 = u47.Attachment.CFrame;
                local l__CFrame__7 = u47.Attachment.Parent[string.sub(u47.Attachment.Name, 1, -7) .. "_finish"].CFrame;
                u49.CFrame = l__CFrame__6:Lerp(l__CFrame__7, 0.5);
                u47.Attachment = u49;
                v48 = function(p50) --[[ Line: 251 ]]
                    -- upvalues: l__CFrame__6 (copy), l__CFrame__7 (copy), u49 (copy), u47 (copy)
                    if p50 then
                        local v51 = Instance.new("CylinderHandleAdornment");
                        v51.Height = (l__CFrame__6.Position - l__CFrame__7.Position).Magnitude;
                        v51.Color3 = Color3.new(1, 1, 1);
                        v51.Transparency = 0.5;
                        v51.AlwaysOnTop = true;
                        v51.InnerRadius = 0.005;
                        v51.Radius = 0.01;
                        v51.CFrame = u49.CFrame;
                        v51.Adornee = u49.Parent;
                        v51.Parent = u49.Parent;
                        u47.CylinderAdornment = v51;
                    else
                        if u47.CylinderAdornment then
                            u47.CylinderAdornment:Destroy();
                            u47.CylinderAdornment = nil;
                        end;
                    end;
                end;
            else
                v48 = nil;
            end;
            local v52 = nil;
            local v53, _, v54 = u41._component:GetRootComponent():GetChildren(table.unpack(u47.Path));
            local v55, v56, v57, v58, v59, v60, v61;
            if l___activePath__5 and (v53 and (v53[v54] and not string.find(string.lower(v53[v54].ParentSubName), "rail_%d"))) then
                local v62 = v53[v54];
                local v63, v64 = v53[v54]:GetMenuConfig();
                if not (v62.MetaData.Camo or (v62.MetaData.Lerp or v62.File and (v62.File.Textures or v62.File.Camos)) or v63 and (v64.Textures or v64.Camos)) then
                    v55 = v63 and (v64.Shortname or v64.Name) or v62.Name;
                    v56 = u2.createElement;
                    v57 = u8;
                    v58 = {
                        IsAdder = true,
                        Attachment = u47.Attachment,
                        FullPath = u47.Path
                    };
                    if l___activePath__5 then
                        v59 = u47.Path;
                        v60 = u42;
                        for v91, v92 in v59 do
                            if l___activePath__5[v91] ~= v92 then
                                v61 = false;
                                v58.Activated = v61;
                                v58.NonAdderInfo = v52;
                                v58.Childname = v55;
                                v58.Scale = u41._selectorScale;
                                v58.MegaFocus = not l___activePath__5;
                                v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                                v58.SpecialHoverCallback = v48;
                                v58.DoDistanceFade = u45;
                                v58.GlobalHighlight = u41._globalHighlight;
                                v58.Name = u47.SubName;
                                v58.Enabled = u41._selectorsEnabled;
                                v58.Callback = u41.Callback;
                                table.insert(u42, v56(v57, v58));
                                u42 = v60;
                            end;
                        end;
                        for v93, v94 in l___activePath__5 do
                            if v59[v93] ~= v94 then
                                v61 = false;
                                v58.Activated = v61;
                                v58.NonAdderInfo = v52;
                                v58.Childname = v55;
                                v58.Scale = u41._selectorScale;
                                v58.MegaFocus = not l___activePath__5;
                                v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                                v58.SpecialHoverCallback = v48;
                                v58.DoDistanceFade = u45;
                                v58.GlobalHighlight = u41._globalHighlight;
                                v58.Name = u47.SubName;
                                v58.Enabled = u41._selectorsEnabled;
                                v58.Callback = u41.Callback;
                                table.insert(u42, v56(v57, v58));
                                u42 = v60;
                            end;
                        end;
                        v61 = true;
                        v58.Activated = v61;
                        v58.NonAdderInfo = v52;
                        v58.Childname = v55;
                        v58.Scale = u41._selectorScale;
                        v58.MegaFocus = not l___activePath__5;
                        v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                        v58.SpecialHoverCallback = v48;
                        v58.DoDistanceFade = u45;
                        v58.GlobalHighlight = u41._globalHighlight;
                        v58.Name = u47.SubName;
                        v58.Enabled = u41._selectorsEnabled;
                        v58.Callback = u41.Callback;
                        table.insert(u42, v56(v57, v58));
                        u42 = v60;
                    end;
                    v60 = u42;
                    v61 = l___activePath__5;
                    v58.Activated = v61;
                    v58.NonAdderInfo = v52;
                    v58.Childname = v55;
                    v58.Scale = u41._selectorScale;
                    v58.MegaFocus = not l___activePath__5;
                    v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                    v58.SpecialHoverCallback = v48;
                    v58.DoDistanceFade = u45;
                    v58.GlobalHighlight = u41._globalHighlight;
                    v58.Name = u47.SubName;
                    v58.Enabled = u41._selectorsEnabled;
                    v58.Callback = u41.Callback;
                    table.insert(u42, v56(v57, v58));
                    u42 = v60;
                end;
                v52 = {
                    FullPath = v62:GetFullName()
                };
                local v69;
                if l___activePath__5 then
                    local v70 = v62:GetFullName();
                    for v71, v72 in v70 do
                        if l___activePath__5[v71] ~= v72 then
                            v69 = false;
                            v52.Activated = v69;
                            v52.Name = v63 and (v64.Shortname or v64.Name) or v62.Name;
                            v52.Keybind = v62.MetaData.Camo or v62.File.DefaultCamo;
                            v55 = v63 and (v64.Shortname or v64.Name) or v62.Name;
                            v56 = u2.createElement;
                            v57 = u8;
                            v58 = {
                                IsAdder = true,
                                Attachment = u47.Attachment,
                                FullPath = u47.Path
                            };
                            if l___activePath__5 then
                                v59 = u47.Path;
                                v60 = u42;
                                for v91, v92 in v59 do
                                    if l___activePath__5[v91] ~= v92 then
                                        v61 = false;
                                        v58.Activated = v61;
                                        v58.NonAdderInfo = v52;
                                        v58.Childname = v55;
                                        v58.Scale = u41._selectorScale;
                                        v58.MegaFocus = not l___activePath__5;
                                        v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                                        v58.SpecialHoverCallback = v48;
                                        v58.DoDistanceFade = u45;
                                        v58.GlobalHighlight = u41._globalHighlight;
                                        v58.Name = u47.SubName;
                                        v58.Enabled = u41._selectorsEnabled;
                                        v58.Callback = u41.Callback;
                                        table.insert(u42, v56(v57, v58));
                                        u42 = v60;
                                    end;
                                end;
                                for v93, v94 in l___activePath__5 do
                                    if v59[v93] ~= v94 then
                                        v61 = false;
                                        v58.Activated = v61;
                                        v58.NonAdderInfo = v52;
                                        v58.Childname = v55;
                                        v58.Scale = u41._selectorScale;
                                        v58.MegaFocus = not l___activePath__5;
                                        v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                                        v58.SpecialHoverCallback = v48;
                                        v58.DoDistanceFade = u45;
                                        v58.GlobalHighlight = u41._globalHighlight;
                                        v58.Name = u47.SubName;
                                        v58.Enabled = u41._selectorsEnabled;
                                        v58.Callback = u41.Callback;
                                        table.insert(u42, v56(v57, v58));
                                        u42 = v60;
                                    end;
                                end;
                                v61 = true;
                                v58.Activated = v61;
                                v58.NonAdderInfo = v52;
                                v58.Childname = v55;
                                v58.Scale = u41._selectorScale;
                                v58.MegaFocus = not l___activePath__5;
                                v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                                v58.SpecialHoverCallback = v48;
                                v58.DoDistanceFade = u45;
                                v58.GlobalHighlight = u41._globalHighlight;
                                v58.Name = u47.SubName;
                                v58.Enabled = u41._selectorsEnabled;
                                v58.Callback = u41.Callback;
                                table.insert(u42, v56(v57, v58));
                                u42 = v60;
                            end;
                            v60 = u42;
                            v61 = l___activePath__5;
                            v58.Activated = v61;
                            v58.NonAdderInfo = v52;
                            v58.Childname = v55;
                            v58.Scale = u41._selectorScale;
                            v58.MegaFocus = not l___activePath__5;
                            v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                            v58.SpecialHoverCallback = v48;
                            v58.DoDistanceFade = u45;
                            v58.GlobalHighlight = u41._globalHighlight;
                            v58.Name = u47.SubName;
                            v58.Enabled = u41._selectorsEnabled;
                            v58.Callback = u41.Callback;
                            table.insert(u42, v56(v57, v58));
                            u42 = v60;
                        end;
                    end;
                    for v77, v78 in l___activePath__5 do
                        if v70[v77] ~= v78 then
                            v69 = false;
                            v52.Activated = v69;
                            v52.Name = v63 and (v64.Shortname or v64.Name) or v62.Name;
                            v52.Keybind = v62.MetaData.Camo or v62.File.DefaultCamo;
                            v55 = v63 and (v64.Shortname or v64.Name) or v62.Name;
                            v56 = u2.createElement;
                            v57 = u8;
                            v58 = {
                                IsAdder = true,
                                Attachment = u47.Attachment,
                                FullPath = u47.Path
                            };
                            if l___activePath__5 then
                                v59 = u47.Path;
                                v60 = u42;
                                for v91, v92 in v59 do
                                    if l___activePath__5[v91] ~= v92 then
                                        v61 = false;
                                        v58.Activated = v61;
                                        v58.NonAdderInfo = v52;
                                        v58.Childname = v55;
                                        v58.Scale = u41._selectorScale;
                                        v58.MegaFocus = not l___activePath__5;
                                        v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                                        v58.SpecialHoverCallback = v48;
                                        v58.DoDistanceFade = u45;
                                        v58.GlobalHighlight = u41._globalHighlight;
                                        v58.Name = u47.SubName;
                                        v58.Enabled = u41._selectorsEnabled;
                                        v58.Callback = u41.Callback;
                                        table.insert(u42, v56(v57, v58));
                                        u42 = v60;
                                    end;
                                end;
                                for v93, v94 in l___activePath__5 do
                                    if v59[v93] ~= v94 then
                                        v61 = false;
                                        v58.Activated = v61;
                                        v58.NonAdderInfo = v52;
                                        v58.Childname = v55;
                                        v58.Scale = u41._selectorScale;
                                        v58.MegaFocus = not l___activePath__5;
                                        v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                                        v58.SpecialHoverCallback = v48;
                                        v58.DoDistanceFade = u45;
                                        v58.GlobalHighlight = u41._globalHighlight;
                                        v58.Name = u47.SubName;
                                        v58.Enabled = u41._selectorsEnabled;
                                        v58.Callback = u41.Callback;
                                        table.insert(u42, v56(v57, v58));
                                        u42 = v60;
                                    end;
                                end;
                                v61 = true;
                                v58.Activated = v61;
                                v58.NonAdderInfo = v52;
                                v58.Childname = v55;
                                v58.Scale = u41._selectorScale;
                                v58.MegaFocus = not l___activePath__5;
                                v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                                v58.SpecialHoverCallback = v48;
                                v58.DoDistanceFade = u45;
                                v58.GlobalHighlight = u41._globalHighlight;
                                v58.Name = u47.SubName;
                                v58.Enabled = u41._selectorsEnabled;
                                v58.Callback = u41.Callback;
                                table.insert(u42, v56(v57, v58));
                                u42 = v60;
                            end;
                            v60 = u42;
                            v61 = l___activePath__5;
                            v58.Activated = v61;
                            v58.NonAdderInfo = v52;
                            v58.Childname = v55;
                            v58.Scale = u41._selectorScale;
                            v58.MegaFocus = not l___activePath__5;
                            v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                            v58.SpecialHoverCallback = v48;
                            v58.DoDistanceFade = u45;
                            v58.GlobalHighlight = u41._globalHighlight;
                            v58.Name = u47.SubName;
                            v58.Enabled = u41._selectorsEnabled;
                            v58.Callback = u41.Callback;
                            table.insert(u42, v56(v57, v58));
                            u42 = v60;
                        end;
                    end;
                    v69 = true;
                    v52.Activated = v69;
                    v52.Name = v63 and (v64.Shortname or v64.Name) or v62.Name;
                    v52.Keybind = v62.MetaData.Camo or v62.File.DefaultCamo;
                    v55 = v63 and (v64.Shortname or v64.Name) or v62.Name;
                    v56 = u2.createElement;
                    v57 = u8;
                    v58 = {
                        IsAdder = true,
                        Attachment = u47.Attachment,
                        FullPath = u47.Path
                    };
                    if l___activePath__5 then
                        v59 = u47.Path;
                        v60 = u42;
                        for v91, v92 in v59 do
                            if l___activePath__5[v91] ~= v92 then
                                v61 = false;
                                v58.Activated = v61;
                                v58.NonAdderInfo = v52;
                                v58.Childname = v55;
                                v58.Scale = u41._selectorScale;
                                v58.MegaFocus = not l___activePath__5;
                                v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                                v58.SpecialHoverCallback = v48;
                                v58.DoDistanceFade = u45;
                                v58.GlobalHighlight = u41._globalHighlight;
                                v58.Name = u47.SubName;
                                v58.Enabled = u41._selectorsEnabled;
                                v58.Callback = u41.Callback;
                                table.insert(u42, v56(v57, v58));
                                u42 = v60;
                            end;
                        end;
                        for v93, v94 in l___activePath__5 do
                            if v59[v93] ~= v94 then
                                v61 = false;
                                v58.Activated = v61;
                                v58.NonAdderInfo = v52;
                                v58.Childname = v55;
                                v58.Scale = u41._selectorScale;
                                v58.MegaFocus = not l___activePath__5;
                                v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                                v58.SpecialHoverCallback = v48;
                                v58.DoDistanceFade = u45;
                                v58.GlobalHighlight = u41._globalHighlight;
                                v58.Name = u47.SubName;
                                v58.Enabled = u41._selectorsEnabled;
                                v58.Callback = u41.Callback;
                                table.insert(u42, v56(v57, v58));
                                u42 = v60;
                            end;
                        end;
                        v61 = true;
                        v58.Activated = v61;
                        v58.NonAdderInfo = v52;
                        v58.Childname = v55;
                        v58.Scale = u41._selectorScale;
                        v58.MegaFocus = not l___activePath__5;
                        v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                        v58.SpecialHoverCallback = v48;
                        v58.DoDistanceFade = u45;
                        v58.GlobalHighlight = u41._globalHighlight;
                        v58.Name = u47.SubName;
                        v58.Enabled = u41._selectorsEnabled;
                        v58.Callback = u41.Callback;
                        table.insert(u42, v56(v57, v58));
                        u42 = v60;
                    end;
                    v60 = u42;
                    v61 = l___activePath__5;
                    v58.Activated = v61;
                    v58.NonAdderInfo = v52;
                    v58.Childname = v55;
                    v58.Scale = u41._selectorScale;
                    v58.MegaFocus = not l___activePath__5;
                    v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                    v58.SpecialHoverCallback = v48;
                    v58.DoDistanceFade = u45;
                    v58.GlobalHighlight = u41._globalHighlight;
                    v58.Name = u47.SubName;
                    v58.Enabled = u41._selectorsEnabled;
                    v58.Callback = u41.Callback;
                    table.insert(u42, v56(v57, v58));
                    u42 = v60;
                else
                    v69 = l___activePath__5;
                    v52.Activated = v69;
                    v52.Name = v63 and (v64.Shortname or v64.Name) or v62.Name;
                    v52.Keybind = v62.MetaData.Camo or v62.File.DefaultCamo;
                    v55 = v63 and (v64.Shortname or v64.Name) or v62.Name;
                    v56 = u2.createElement;
                    v57 = u8;
                    v58 = {
                        IsAdder = true,
                        Attachment = u47.Attachment,
                        FullPath = u47.Path
                    };
                    if l___activePath__5 then
                        v59 = u47.Path;
                        v60 = u42;
                        for v91, v92 in v59 do
                            if l___activePath__5[v91] ~= v92 then
                                v61 = false;
                                v58.Activated = v61;
                                v58.NonAdderInfo = v52;
                                v58.Childname = v55;
                                v58.Scale = u41._selectorScale;
                                v58.MegaFocus = not l___activePath__5;
                                v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                                v58.SpecialHoverCallback = v48;
                                v58.DoDistanceFade = u45;
                                v58.GlobalHighlight = u41._globalHighlight;
                                v58.Name = u47.SubName;
                                v58.Enabled = u41._selectorsEnabled;
                                v58.Callback = u41.Callback;
                                table.insert(u42, v56(v57, v58));
                                u42 = v60;
                            end;
                        end;
                        for v93, v94 in l___activePath__5 do
                            if v59[v93] ~= v94 then
                                v61 = false;
                                v58.Activated = v61;
                                v58.NonAdderInfo = v52;
                                v58.Childname = v55;
                                v58.Scale = u41._selectorScale;
                                v58.MegaFocus = not l___activePath__5;
                                v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                                v58.SpecialHoverCallback = v48;
                                v58.DoDistanceFade = u45;
                                v58.GlobalHighlight = u41._globalHighlight;
                                v58.Name = u47.SubName;
                                v58.Enabled = u41._selectorsEnabled;
                                v58.Callback = u41.Callback;
                                table.insert(u42, v56(v57, v58));
                                u42 = v60;
                            end;
                        end;
                        v61 = true;
                        v58.Activated = v61;
                        v58.NonAdderInfo = v52;
                        v58.Childname = v55;
                        v58.Scale = u41._selectorScale;
                        v58.MegaFocus = not l___activePath__5;
                        v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                        v58.SpecialHoverCallback = v48;
                        v58.DoDistanceFade = u45;
                        v58.GlobalHighlight = u41._globalHighlight;
                        v58.Name = u47.SubName;
                        v58.Enabled = u41._selectorsEnabled;
                        v58.Callback = u41.Callback;
                        table.insert(u42, v56(v57, v58));
                        u42 = v60;
                    end;
                    v60 = u42;
                    v61 = l___activePath__5;
                    v58.Activated = v61;
                    v58.NonAdderInfo = v52;
                    v58.Childname = v55;
                    v58.Scale = u41._selectorScale;
                    v58.MegaFocus = not l___activePath__5;
                    v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                    v58.SpecialHoverCallback = v48;
                    v58.DoDistanceFade = u45;
                    v58.GlobalHighlight = u41._globalHighlight;
                    v58.Name = u47.SubName;
                    v58.Enabled = u41._selectorsEnabled;
                    v58.Callback = u41.Callback;
                    table.insert(u42, v56(v57, v58));
                    u42 = v60;
                end;
            end;
            v55 = nil;
            v56 = u2.createElement;
            v57 = u8;
            v58 = {
                IsAdder = true,
                Attachment = u47.Attachment,
                FullPath = u47.Path
            };
            if l___activePath__5 then
                v59 = u47.Path;
                v60 = u42;
                for v91, v92 in v59 do
                    if l___activePath__5[v91] ~= v92 then
                        v61 = false;
                        v58.Activated = v61;
                        v58.NonAdderInfo = v52;
                        v58.Childname = v55;
                        v58.Scale = u41._selectorScale;
                        v58.MegaFocus = not l___activePath__5;
                        v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                        v58.SpecialHoverCallback = v48;
                        v58.DoDistanceFade = u45;
                        v58.GlobalHighlight = u41._globalHighlight;
                        v58.Name = u47.SubName;
                        v58.Enabled = u41._selectorsEnabled;
                        v58.Callback = u41.Callback;
                        table.insert(u42, v56(v57, v58));
                        u42 = v60;
                    end;
                end;
                for v93, v94 in l___activePath__5 do
                    if v59[v93] ~= v94 then
                        v61 = false;
                        v58.Activated = v61;
                        v58.NonAdderInfo = v52;
                        v58.Childname = v55;
                        v58.Scale = u41._selectorScale;
                        v58.MegaFocus = not l___activePath__5;
                        v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                        v58.SpecialHoverCallback = v48;
                        v58.DoDistanceFade = u45;
                        v58.GlobalHighlight = u41._globalHighlight;
                        v58.Name = u47.SubName;
                        v58.Enabled = u41._selectorsEnabled;
                        v58.Callback = u41.Callback;
                        table.insert(u42, v56(v57, v58));
                        u42 = v60;
                    end;
                end;
                v61 = true;
                v58.Activated = v61;
                v58.NonAdderInfo = v52;
                v58.Childname = v55;
                v58.Scale = u41._selectorScale;
                v58.MegaFocus = not l___activePath__5;
                v58.Component = u47.ParentComponent:GetChild(u47.SubName);
                v58.SpecialHoverCallback = v48;
                v58.DoDistanceFade = u45;
                v58.GlobalHighlight = u41._globalHighlight;
                v58.Name = u47.SubName;
                v58.Enabled = u41._selectorsEnabled;
                v58.Callback = u41.Callback;
                table.insert(u42, v56(v57, v58));
                u42 = v60;
            end;
            v60 = u42;
            v61 = l___activePath__5;
            v58.Activated = v61;
            v58.NonAdderInfo = v52;
            v58.Childname = v55;
            v58.Scale = u41._selectorScale;
            v58.MegaFocus = not l___activePath__5;
            v58.Component = u47.ParentComponent:GetChild(u47.SubName);
            v58.SpecialHoverCallback = v48;
            v58.DoDistanceFade = u45;
            v58.GlobalHighlight = u41._globalHighlight;
            v58.Name = u47.SubName;
            v58.Enabled = u41._selectorsEnabled;
            v58.Callback = u41.Callback;
            table.insert(u42, v56(v57, v58));
            u42 = v60;
        end;
    end;
    local function v107(p95) --[[ Line: 312 ]]
        -- upvalues: u42 (copy), u2 (ref), u8 (ref), u41 (copy), u45 (ref)
        if not (p95.ParentModel and p95.ParentModel.PrimaryPart) then
            return;
        end;
        if not p95.ParentComponent.Children[p95.ParentSubName] then
            return;
        end;
        if p95.ParentComponent.File.Invisible and p95.ParentComponent.File.Invisible[p95.ParentSubName] then
            return;
        end;
        local v96, v97 = p95:GetMenuConfig();
        if not (p95.MetaData.Camo or (p95.MetaData.Lerp or p95.File and (p95.File.Textures or p95.File.Camos)) or v96 and (v97.Textures or v97.Camos)) then
            return;
        end;
        local l__PrimaryPart__8 = p95.ParentModel.PrimaryPart;
        local v98 = l__PrimaryPart__8:FindFirstChild("anchor") or l__PrimaryPart__8.start;
        local v99 = u42;
        local l__createElement__9 = u2.createElement;
        local v100 = u8;
        local v101 = {
            IsAdder = false,
            Attachment = p95.Model or v98,
            FullPath = p95:GetFullName(),
            Component = p95
        };
        local l___activePath__10 = u41._activePath;
        if l___activePath__10 then
            local v102 = p95:GetFullName();
            local l___activePath__11 = u41._activePath;
            for v103, v104 in v102 do
                if l___activePath__11[v103] ~= v104 then
                    l___activePath__10 = false;
                    v101.Activated = l___activePath__10;
                    v101.Name = v96 and (v97.Shortname or v97.Name) or p95.Name;
                    v101.Enabled = u41._selectorsEnabled;
                    v101.DoDistanceFade = u45;
                    v101.CanLerp = p95.MetaData.Lerp and true or false;
                    v101.Scale = u41._selectorScale;
                    v101.GlobalHighlight = u41._globalHighlight;
                    v101.Callback = u41.Callback;
                    table.insert(v99, l__createElement__9(v100, v101));
                    return;
                end;
            end;
            for v105, v106 in l___activePath__11 do
                if v102[v105] ~= v106 then
                    l___activePath__10 = false;
                    v101.Activated = l___activePath__10;
                    v101.Name = v96 and (v97.Shortname or v97.Name) or p95.Name;
                    v101.Enabled = u41._selectorsEnabled;
                    v101.DoDistanceFade = u45;
                    v101.CanLerp = p95.MetaData.Lerp and true or false;
                    v101.Scale = u41._selectorScale;
                    v101.GlobalHighlight = u41._globalHighlight;
                    v101.Callback = u41.Callback;
                    table.insert(v99, l__createElement__9(v100, v101));
                    return;
                end;
            end;
            l___activePath__10 = true;
            v101.Activated = l___activePath__10;
            v101.Name = v96 and (v97.Shortname or v97.Name) or p95.Name;
            v101.Enabled = u41._selectorsEnabled;
            v101.DoDistanceFade = u45;
            v101.CanLerp = p95.MetaData.Lerp and true or false;
            v101.Scale = u41._selectorScale;
            v101.GlobalHighlight = u41._globalHighlight;
            v101.Callback = u41.Callback;
            table.insert(v99, l__createElement__9(v100, v101));
        else
            v101.Activated = l___activePath__10;
            v101.Name = v96 and (v97.Shortname or v97.Name) or p95.Name;
            v101.Enabled = u41._selectorsEnabled;
            v101.DoDistanceFade = u45;
            v101.CanLerp = p95.MetaData.Lerp and true or false;
            v101.Scale = u41._selectorScale;
            v101.GlobalHighlight = u41._globalHighlight;
            v101.Callback = u41.Callback;
            table.insert(v99, l__createElement__9(v100, v101));
        end;
    end;
    if u41._activePath then
        v107(l___selectorsComponent__4);
        local v108 = l___selectorsComponent__4:GetDescendants(1, v43);
        for v109 = 1, #v108 do
            local v110 = v108[v109];
            if string.find(string.lower(v110.ParentSubName), "rail_%d") then
                v107(v110);
            end;
        end;
    end;
    if u41._selectors then
        u2.unmount(u41._selectors);
    end;
    u41._selectors = u2.mount(u2.createFragment(u42), u11);
end;
function u14.GetComponent(p111) --[[ Line: 368 ]]
    return p111._component;
end;
function u14.SetComponent(u112, u113, p114, p115) --[[ Line: 372 ]]
    -- upvalues: l__PlayerGui__2 (copy)
    local l___component__12 = u112._component;
    if l___component__12 == u113 then
    else
        if l___component__12 then
            l___component__12.ParentModel.Parent = nil;
        end;
        u112._component = u113;
        if u113 then
            local u116;
            if p114 then
                u116 = Instance.new("WorldModel");
                u116.Parent = l__PlayerGui__2;
            else
                u116 = nil;
            end;
            local l__ParentModel__13 = u113.ParentModel;
            local v117 = u112._rotation:ToCFrame(u112._position.X, u112._position.Y, u112._position.Z);
            if u112._pivotMode == "pivot" then
                l__ParentModel__13:PivotTo(v117);
            else
                local v118 = l__ParentModel__13:GetBoundingBox();
                local v119 = l__ParentModel__13:GetPivot();
                l__ParentModel__13:PivotTo(v117 * (v118:Inverse() * v119));
            end;
            u113.ParentModel.PrimaryPart.Anchored = true;
            u113.ParentModel.Parent = u116 or u112._parent;
            if u113.ParentSubName == "Character" then
                local v120 = Instance.new("AnimationController");
                v120.Parent = u113.Model;
                local v121 = Instance.new("Animator");
                v121.Parent = v120;
                local v122 = Instance.new("Animation");
                v122.AnimationId = p115 and "rbxassetid://107633364537656" or "rbxassetid://8588579661";
                v121:LoadAnimation(v122):Play(0);
                if u116 then
                    task.spawn(function() --[[ Line: 410 ]]
                        -- upvalues: u113 (copy), u112 (copy), u116 (ref)
                        task.wait();
                        u113.ParentModel.Parent = u112._parent;
                        u116:Destroy();
                    end);
                end;
            end;
            u112:_buildSelectors();
        end;
    end;
end;
function u14.PlaceSlideComponent(p123) --[[ Line: 421 ]]
    local l___slidingComponent__14 = p123._slidingComponent;
    if l___slidingComponent__14 then
        p123._oldSlideLerp = nil;
        p123:SlideComponent(nil);
        p123.SlideCallback(l___slidingComponent__14);
    end;
end;
function u14.SlideComponent(u124, u125, u126) --[[ Line: 431 ]]
    -- upvalues: l__UserInputService__1 (copy), u3 (copy), u7 (copy), u5 (copy)
    local l___slidingComponent__15 = u124._slidingComponent;
    u124._slidingComponent = u125;
    u124._updSlidingBinding(u124._slidingComponent);
    if u125 == nil and l___slidingComponent__15 then
        for v127 = #u124._slidingConnections, 1, -1 do
            u124._slidingConnections[v127]:Disconnect();
            u124._slidingConnections[v127] = nil;
        end;
        u124._slidingAmount = nil;
        u124._slidingDelta = 0;
        u124._slidingMousePosition = nil;
        u124._updSelectorsEnabled(true);
        if u124._oldSlideLerp and not l___slidingComponent__15._Destroyed then
            l___slidingComponent__15:EditMetaData({
                Lerp = u124._oldSlideLerp
            });
        end;
    elseif u125 == nil then
    else
        u124._oldSlideLerp = u125.MetaData.Lerp;
        u124._updSelectorsEnabled(false);
        u124._slidingConnections[1] = l__UserInputService__1.InputChanged:Connect(function(p128) --[[ Line: 462 ]]
            -- upvalues: u3 (ref), u7 (ref), u124 (copy), u5 (ref)
            if p128.UserInputType.Name:sub(1, 7) == "Gamepad" then
                local l__X__16 = p128.Position.X;
                local v129 = -p128.Position.Y;
                local v130 = p128.KeyCode == u3.KeyCode.Thumbstick1 and u7.Thumbstick1DeadZone or u7.Thumbstick2DeadZone;
                if v130 < math.abs(l__X__16) or v130 < math.abs(v129) then
                    u124._slidingAmount = nil;
                    u124._slidingMousePosition = u5.VirtualCursorPosition;
                end;
            elseif p128.UserInputType == u3.UserInputType.MouseMovement then
                u124._slidingAmount = nil;
                u124._slidingMousePosition = Vector2.new(p128.Position.X, p128.Position.Y);
            end;
        end);
        u124._slidingConnections[2] = l__UserInputService__1.InputBegan:Connect(function(p131) --[[ Line: 477 ]]
            -- upvalues: u3 (ref), u126 (copy), u125 (copy), u124 (copy)
            if p131.UserInputType.Name:sub(1, 7) == "Gamepad" then
                if p131.KeyCode == u3.KeyCode.ButtonB then
                    if u126 then
                        u125:Destroy();
                    end;
                    u124:SlideComponent(nil);
                end;
            elseif p131.KeyCode == u3.KeyCode.Space then
                if u126 then
                    u125:Destroy();
                end;
                u124:SlideComponent(nil);
            end;
        end);
        u124._slidingConnections[3] = l__UserInputService__1.InputEnded:Connect(function(p132) --[[ Line: 493 ]]
            -- upvalues: u3 (ref), u124 (copy)
            if p132.UserInputType == u3.UserInputType.MouseButton1 then
                u124:PlaceSlideComponent();
            else
                if p132.KeyCode == u3.KeyCode.ButtonA then
                    u124:PlaceSlideComponent();
                end;
            end;
        end);
        u124._slidingConnections[4] = l__UserInputService__1.TouchMoved:Connect(function(p133) --[[ Line: 501 ]]
            -- upvalues: u124 (copy)
            u124._slidingAmount = nil;
            u124._slidingMousePosition = Vector2.new(p133.Position.X, p133.Position.Y);
        end);
    end;
end;
function u14.GetSlidingBinding(p134) --[[ Line: 507 ]]
    return p134._slidingBinding;
end;
function u14.Lerp(p135, p136) --[[ Line: 511 ]]
    -- upvalues: l__CurrentCamera__3 (copy)
    p135._rotation = p135._rotation:Nlerp(p135._targetRotation, (math.min(20 * p136, 1)));
    p135._position = p135._position:Lerp(p135._targetPosition, (math.min(20 * p136, 1)));
    p135._cameraCF = p135._cameraCF:Lerp(p135._targetCameraCF, (math.min(20 * p136, 1)));
    l__CurrentCamera__3.CFrame = p135._cameraCF;
    local l___component__17 = p135._component;
    if l___component__17 then
        local v137 = p135._rotation:ToCFrame(p135._position.X, p135._position.Y, p135._position.Z);
        local l__ParentModel__18 = l___component__17.ParentModel;
        if p135._pivotMode == "pivot" then
            l__ParentModel__18:PivotTo(v137);
            return;
        end;
        local v138 = l__ParentModel__18:GetBoundingBox();
        local v139 = l__ParentModel__18:GetPivot();
        l__ParentModel__18:PivotTo(v137 * (v138:Inverse() * v139));
    end;
end;
function u14.SetTargetCF(p140, p141) --[[ Line: 525 ]]
    -- upvalues: u4 (copy)
    p140._targetPosition = p141.Position;
    p140._targetRotation = u4.FromCFrame(p141);
end;
local u142 = 50;
local u143 = 50;
function u14.ResetCamera(p144, p145) --[[ Line: 533 ]]
    -- upvalues: u143 (ref)
    p144._originalCameraCF = p145 or p144._originalCameraCF;
    p144._mx = 0;
    p144._my = 0;
    p144._targetCameraCF = p144._originalCameraCF;
    u143 = 50;
end;
function u14.ResetModel(p146, p147) --[[ Line: 543 ]]
    -- upvalues: u4 (copy)
    p146._originalCF = p147 or p146._originalCF;
    p146._targetPosition = p146._originalCF.Position;
    p146._targetRotation = u4.FromCFrame(p146._originalCF);
end;
function u14.GetViewIsChangedBinding(p148) --[[ Line: 550 ]]
    return p148._viewIsChanged;
end;
function u14._getSlideAmount(p149, p150, p151) --[[ Line: 561 ]]
    -- upvalues: l__CurrentCamera__3 (copy)
    local l___slidingComponent__19 = p149._slidingComponent;
    local l__PrimaryPart__20 = l___slidingComponent__19.ParentComponent.ParentModel.PrimaryPart;
    local v152 = string.lower(l___slidingComponent__19.ParentSubName);
    local l__Position__21 = l__PrimaryPart__20[v152 .. "_start"].WorldCFrame.Position;
    local l__Position__22 = l__PrimaryPart__20[v152 .. "_finish"].WorldCFrame.Position;
    local l__Magnitude__23 = (l__Position__21 - l__Position__22).Magnitude;
    local v153;
    if p151 then
        p149._slidingDelta = math.clamp(p149._slidingDelta + p151, 0, 1);
        v153 = p149._slidingDelta;
    else
        local v154 = l__CurrentCamera__3:WorldToViewportPoint(l__Position__21);
        local v155 = l__CurrentCamera__3:WorldToViewportPoint(l__Position__22);
        local v156 = Vector2.new(v154.X, v154.Y);
        local v157 = Vector2.new(v155.X, v155.Y) - v156;
        v153 = (p150 - v156):Dot(v157.Unit) / v157.Magnitude;
    end;
    local v158 = 1 / (math.max(l___slidingComponent__19.ParentComponent.File and (l___slidingComponent__19.ParentComponent.File.RailSnap and l___slidingComponent__19.ParentComponent.File.RailSnap[l___slidingComponent__19.ParentSubName]) or 0, 0.001) / l__Magnitude__23 or 1);
    local v159 = math.floor(v153 * v158 + 0.5) / v158;
    return math.clamp(v159, 0, 1);
end;
function u14.SetPivotMode(p160, p161) --[[ Line: 593 ]]
    p160._pivotMode = p161;
end;
function u14.SetRotateDirections(p162, p163, p164) --[[ Line: 597 ]]
    p162._rx = p163;
    p162._ry = p164;
end;
function u14.Update(p165, p166) --[[ Line: 602 ]]
    -- upvalues: u13 (copy), u9 (copy), l__UserInputService__1 (copy), u3 (copy), u143 (ref), u142 (ref), l__CurrentCamera__3 (copy), u5 (copy), u4 (copy)
    if #u13 < 1 then
    else
        local v167 = math.min(p166, 0.041666666666666664);
        local v168 = u9:IsScrollBarActive() and Vector3.new(0, 0, 0) or p165;
        local l__Z__24 = v168.Z;
        if l__UserInputService__1:IsKeyDown(u3.KeyCode.W) then
            l__Z__24 = l__Z__24 + 0.02;
        end;
        if l__UserInputService__1:IsKeyDown(u3.KeyCode.S) then
            l__Z__24 = l__Z__24 - 0.02;
        end;
        u143 = math.clamp(u143 - l__Z__24 * 6, 5, 80);
        local v169 = u142;
        local v170 = u143;
        local v171 = 12 * v167;
        u142 = math.clamp(v169 * (1 - v171) + v170 * v171, 5, 80);
        l__CurrentCamera__3.FieldOfView = u142;
        for _, v172 in u13 do
            if l__UserInputService__1:IsKeyDown(u3.KeyCode.E) then
                v172._my = math.clamp(v172._my + 4 * v167, -2, 2);
            end;
            if l__UserInputService__1:IsKeyDown(u3.KeyCode.A) then
                v172._mx = math.clamp(v172._mx - 4 * v167, -2, 2);
            end;
            if l__UserInputService__1:IsKeyDown(u3.KeyCode.Q) then
                v172._my = math.clamp(v172._my - 4 * v167, -2, 2);
            end;
            if l__UserInputService__1:IsKeyDown(u3.KeyCode.D) then
                v172._mx = math.clamp(v172._mx + 4 * v167, -2, 2);
            end;
            v172._targetCameraCF = v172._originalCameraCF * CFrame.new(v172._mx, v172._my, 0);
            if v172.DraggingEnabled then
                if l__UserInputService__1:IsMouseButtonPressed(u3.UserInputType.MouseButton2) or u5.FingersTouching > 0 and not v172._slidingComponent or u5.Gamepad then
                    local v173 = CFrame.Angles(v168.Y * v172._rx, v168.X * v172._ry, 0);
                    v172._targetRotation = (u4.FromCFrame(v173) * v172._targetRotation):Normalize();
                else
                    v172._targetRotation = u4.new(v172._targetRotation.w, 0, v172._targetRotation.y, 0):Normalize();
                end;
            end;
            v172:Lerp(v167);
            if v172._targetCameraCF:FuzzyEq(v172._originalCameraCF) and v172._targetRotation:ToCFrame(v172._targetPosition.X, v172._targetPosition.Y, v172._targetPosition.Z):FuzzyEq(v172._originalCF) then
                v172._updViewIsChanged(false);
            else
                v172._updViewIsChanged(true);
            end;
            if v172._slidingComponent and (v172._slidingMousePosition or v172._slidingAmount) then
                if u5.Touch and u5.FingersTouching == 0 then
                    v172:PlaceSlideComponent();
                else
                    local l___slidingMousePosition__25 = v172._slidingMousePosition;
                    local l___slidingAmount__26 = v172._slidingAmount;
                    if l___slidingAmount__26 then
                        l___slidingAmount__26 = v172._slidingAmount * v167;
                    end;
                    local v174 = v172:_getSlideAmount(l___slidingMousePosition__25, l___slidingAmount__26);
                    v172._slidingComponent:EditMetaData({
                        Lerp = v174
                    });
                end;
            end;
        end;
    end;
end;
return u14;