-- Services.InterfaceService.MenuInterface.MenuLoadoutComponent.MenuLoadoutPreviewOptionButton
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "asset");
local u3 = v1("GameShellProxyButton");
local v4 = u2.Component:extend("MenuLoadoutPreviewOptionButton");
local u5 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u6 = {
    Laser = "L",
    Flashlight = "F",
    Strobe = "F",
    Sights = "S"
};
function v4.init(_, _) --[[ Line: 17 ]] end;
function v4.render(u7) --[[ Line: 21 ]]
    -- upvalues: u2 (copy), u3 (copy), u6 (copy), u5 (copy)
    local l__props__1 = u7.props;
    local l__state__2 = u7.state;
    local l__ButtonInfo__3 = l__props__1.ButtonInfo;
    local l__Order__4 = l__props__1.Order;
    local l__Ignore__5 = l__props__1.Ignore;
    local l__Callback__6 = l__props__1.Callback;
    local l__Hovering__7 = l__state__2.Hovering;
    local l__Activated__8 = l__props__1.Activated;
    local v8 = l__ButtonInfo__3.Color or Color3.new(1, 1, 1);
    if l__ButtonInfo__3.SubState == 0 then
        v8 = v8:Lerp(Color3.new(0, 0, 0), 0.6);
    end;
    return u2.createElement(u3, {
        SoundKit = "MainMenuLoadout",
        BorderSizePixel = 0,
        BackgroundTransparency = 1,
        LayoutOrder = l__Order__4,
        Ignore = l__Ignore__5,
        Size = l__props__1.Size,
        SizeConstraint = l__props__1.SizeConstraint,
        MouseUp = function() --[[ Name: MouseUp, Line 47 ]]
            -- upvalues: l__Callback__6 (copy), l__ButtonInfo__3 (copy), u7 (copy)
            l__Callback__6(l__ButtonInfo__3.SubIndex, l__ButtonInfo__3.SubState);
            u7:setState({});
        end,
        MouseEnter = function() --[[ Name: MouseEnter, Line 51 ]]
            -- upvalues: u7 (copy)
            u7:setState({
                Hovering = true
            });
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 56 ]]
            -- upvalues: u7 (copy)
            u7:setState({
                Hovering = false
            });
        end
    }, { u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 4)
        }), u2.createElement("UIStroke", {
            Thickness = 1,
            Color = l__Hovering__7 and Color3.new(1, 1, 1) or (l__Activated__8 and Color3.fromRGB(255, 194, 89) or Color3.new())
        }), u2.createElement("TextLabel", {
            TextScaled = true,
            BackgroundTransparency = 1,
            Text = u6[l__ButtonInfo__3.SubIndex] or "-",
            TextColor3 = v8,
            FontFace = u5,
            Size = UDim2.new(0.8, 0, 0.8, 0),
            Position = UDim2.new(0.5, 0, 0.5, 0),
            AnchorPoint = Vector2.new(0.5, 0.5)
        }, { u2.createElement("UIStroke", {
                Thickness = l__ButtonInfo__3.IsIR and 1 or 0,
                Color = Color3.new(0, 0, 0)
            }) }) });
end;
return v4;