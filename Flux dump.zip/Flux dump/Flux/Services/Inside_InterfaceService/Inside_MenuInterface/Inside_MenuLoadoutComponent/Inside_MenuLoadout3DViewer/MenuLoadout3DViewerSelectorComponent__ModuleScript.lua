-- Services.InterfaceService.MenuInterface.MenuLoadoutComponent.MenuLoadout3DViewer.MenuLoadout3DViewerSelectorComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local l__RunService__1 = game:GetService("RunService");
local v1, u2, _ = shared.import("require", "Roact", "asset");
local u3 = v1("GameShellProxyWorldToScreenPosition");
local u4 = v1("GameShellProxyButton");
local u5 = v1("RoactTween");
local u6 = v1("InputService");
local u7 = v1("MenuLoadoutConstants");
local u8 = v1("AttachableComponent");
local u9 = u2.Component:extend("MenuLoadout3DViewerSelector");
local u10 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local l__PIN_COLORS__2 = u7.PIN_COLORS;
function u9.init(u11, p12) --[[ Line: 20 ]]
    -- upvalues: u2 (copy), u5 (copy), l__RunService__1 (copy)
    local v13, v14 = u2.createBinding(0);
    u11.Transparency = v13;
    u11.UpdTransparency = v14;
    u11.Size = u5.new(0.59, TweenInfo.new(0.1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out));
    u11.NameTween = u5.new(0, TweenInfo.new(0.1));
    if p12.NonAdderInfo then
        u11.SlideOutTween = u5.new(0, TweenInfo.new(0.1));
    else
        u11.SlideOutTween = p12.SlideOutTween;
    end;
    if p12.MegaFocus then
        local v15, v16 = u2.createBinding(0);
        u11.Timer = v15;
        u11.UpdTimer = v16;
        u11._conn = l__RunService__1.Heartbeat:Connect(function() --[[ Line: 32 ]]
            -- upvalues: u11 (copy)
            u11.UpdTimer(os.clock() * 4);
        end);
    end;
end;
function u9.willUnmount(p17) --[[ Line: 44 ]]
    if p17._highlight then
        p17._highlight:Destroy();
    end;
    if p17.props.SpecialHoverCallback then
        p17.props.SpecialHoverCallback(false);
    end;
    if p17._conn then
        p17._conn:Disconnect();
    end;
end;
function u9.render(u18) --[[ Line: 56 ]]
    -- upvalues: u8 (copy), l__PIN_COLORS__2 (copy), u6 (copy), u7 (copy), u2 (copy), u10 (copy), u10 (copy), u3 (copy), u4 (copy), u9 (copy)
    local l__Activated__3 = u18.props.Activated;
    local l__Hovering__4 = u18.state.Hovering;
    local l__IsAdder__5 = u18.props.IsAdder;
    local l__NonAdderInfo__6 = u18.props.NonAdderInfo;
    local l__Name__7 = u18.props.Name;
    local v19, v20, u21 = u8:GetPinInfo(l__Name__7, u18.props.Childname);
    local v23 = u18.props.Enabled:map(function(p22) --[[ Line: 66 ]]
        -- upvalues: u21 (copy), l__PIN_COLORS__2 (ref), l__Activated__3 (copy), l__Hovering__4 (copy)
        if u21 and l__PIN_COLORS__2[u21] then
            return l__PIN_COLORS__2[u21];
        else
            return not p22 and Color3.new(0.3, 0.3, 0.3) or l__Activated__3 and Color3.fromRGB(255, 194, 89) or (l__Hovering__4 and Color3.new(1, 1, 1) or Color3.new(0.678431, 0.678431, 0.678431));
        end;
    end);
    u18.Size:SetGoal(l__Hovering__4 and 1 or (l__Activated__3 and 0.75 or 0.59));
    u18.NameTween:SetGoal((l__Hovering__4 or l__Activated__3) and 1 or 0);
    if l__Activated__3 or l__Hovering__4 then
        if u18.SlideOutTween then
            u18.SlideOutTween:SetGoal(1);
        end;
    elseif not l__IsAdder__5 and (not u18.props.ParentActivated and (not u18.props.ParentHovering and u18.SlideOutTween)) then
        u18.SlideOutTween:SetGoal(0);
    end;
    local v24;
    if u18.props.IsFunc then
        v24 = u18.props.Keybind and ("Keybind (" .. u6:GetBind(u18.props.Keybind).Name .. ")" or "Keybind (Unbound)") or "Keybind (Unbound)";
    else
        v24 = string.gsub(u7.SubIndexDisplayNames[l__Name__7] or l__Name__7, "_", " ");
    end;
    local v25;
    if v20 then
        v25 = { u2.createElement("Frame", {
                Rotation = 0,
                BorderSizePixel = 0,
                BackgroundTransparency = 1,
                Size = u18.Size:Map(function(p26) --[[ Line: 102 ]]
                    return UDim2.fromScale(0.2 * p26, 0.2 * p26);
                end),
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.5)
            }, { u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.5, 0)
                }), u2.createElement("UIStroke", {
                    Thickness = 1,
                    Transparency = u18.props.SlideOutTween and u2.joinBindings({ u18.props.SlideOutTween:Map(function(p27) --[[ Line: 113 ]]
                            return p27;
                        end), u18.Transparency }):map(function(p28) --[[ Line: 113 ]]
                        return 1 - (1 - p28[2]) * p28[1];
                    end) or u18.Transparency,
                    LineJoinMode = Enum.LineJoinMode.Miter,
                    Color = v23
                }), u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    LayoutOrder = 1,
                    TextScaled = true,
                    Size = UDim2.fromScale(1, 1),
                    Position = UDim2.fromScale(0, 0),
                    Text = u21,
                    TextColor3 = v23,
                    FontFace = u10,
                    TextXAlignment = Enum.TextXAlignment.Center
                }) }) };
    elseif l__IsAdder__5 then
        if l__Name__7:sub(1, 4) == "Rail" then
            v25 = { u2.createElement("ImageLabel", {
                    BorderSizePixel = 0,
                    Image = "rbxassetid://135356210908329",
                    BackgroundTransparency = 1,
                    Size = u18.Size:Map(function(p29) --[[ Line: 136 ]]
                        return UDim2.new(0.35 * p29, 0, 0.35 * p29, 0);
                    end),
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Position = UDim2.fromScale(0.5, 0.5),
                    ImageColor3 = v23,
                    ImageTransparency = u18.Transparency
                }) };
        else
            v25 = {};
            local v32 = u2.createElement("Frame", {
                BorderSizePixel = 0,
                ZIndex = 2,
                Size = u18.Size:Map(function(p30) --[[ Line: 151 ]]
                    return UDim2.new(0.2 * p30, 0, 0.2 * p30, 0);
                end),
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.5),
                BackgroundColor3 = v23,
                BackgroundTransparency = u18.Transparency
            }, { u2.createElement("UICorner", {
                    CornerRadius = UDim.new(1, 0)
                }), u2.createElement("UIStroke", {
                    Thickness = 1,
                    ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                    Color = Color3.new(0, 0, 0),
                    Transparency = u18.Transparency:map(function(p31) --[[ Line: 167 ]]
                        return p31 * 0.5 + 0.5;
                    end),
                    LineJoinMode = Enum.LineJoinMode.Round
                }) });
            local v33 = u18.props.MegaFocus and not u18.state.Hovering;
            if v33 then
                v33 = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    Size = u18.Timer:map(function(p34) --[[ Line: 176 ]]
                        local v35 = math.sin(p34) + 1;
                        return UDim2.new(0.2 * v35, 0, 0.2 * v35, 0);
                    end),
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Position = UDim2.fromScale(0.5, 0.5),
                    BackgroundColor3 = v23,
                    BackgroundTransparency = u18.Timer:map(function(p36) --[[ Line: 184 ]]
                        return math.cos(p36) + 1;
                    end)
                }, { u2.createElement("UICorner", {
                        CornerRadius = UDim.new(1, 0)
                    }) });
            end;
            v25[1], v25[2] = v32, v33;
        end;
    else
        v25 = { u2.createElement("Frame", {
                Rotation = 45,
                BorderSizePixel = 0,
                BackgroundTransparency = 1,
                Size = u18.Size:Map(function(p37) --[[ Line: 200 ]]
                    return UDim2.fromScale(0.2 * p37, 0.2 * p37);
                end),
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.5)
            }, { u2.createElement("UIStroke", {
                    Thickness = 1,
                    Transparency = u18.props.SlideOutTween and u2.joinBindings({ u18.props.SlideOutTween:Map(function(p38) --[[ Line: 208 ]]
                            return p38;
                        end), u18.Transparency }):map(function(p39) --[[ Line: 208 ]]
                        return 1 - (1 - p39[2]) * p39[1];
                    end) or u18.Transparency,
                    LineJoinMode = Enum.LineJoinMode.Miter,
                    Color = v23
                }) }) };
    end;
    local l__createElement__8 = u2.createElement;
    local v41 = {
        BackgroundTransparency = 1,
        LayoutOrder = 1,
        TextStrokeTransparency = 0.5,
        TextScaled = true,
        Size = u18.Size:Map(function(p40) --[[ Line: 221 ]]
            return UDim2.fromScale(5, 0.25 * p40);
        end),
        AnchorPoint = l__IsAdder__5 and Vector2.new(0.5, 1) or Vector2.new(1, 0.5),
        Position = l__IsAdder__5 and UDim2.fromScale(0.5, 0.2) or UDim2.fromScale(0.2, 0.5),
        Text = v24,
        TextStrokeColor3 = Color3.new(0, 0, 0),
        TextColor3 = v23,
        FontFace = u10,
        TextXAlignment = l__IsAdder__5 and Enum.TextXAlignment.Center or Enum.TextXAlignment.Right
    };
    local v43 = { u2.createElement("UIGradient", {
            Transparency = u18.NameTween:Map(function(p42) --[[ Line: 235 ]]
                if p42 == 0 then
                    return NumberSequence.new(1);
                elseif p42 == 1 then
                    return NumberSequence.new(0);
                else
                    return NumberSequence.new({
                        NumberSequenceKeypoint.new(0, 1),
                        NumberSequenceKeypoint.new(math.max((1 - p42) / 2 - 0.05, 0), 1),
                        NumberSequenceKeypoint.new((1 - p42) / 2, 0),
                        NumberSequenceKeypoint.new((p42 + 1) / 2, 0),
                        NumberSequenceKeypoint.new(math.min((p42 + 1) / 2 + 0.05, 1), 1),
                        NumberSequenceKeypoint.new(1, 1)
                    });
                end;
            end)
        }) };
    table.insert(v25, l__createElement__8("TextLabel", v41, v43));
    local l__GlobalHighlight__9 = u18.props.GlobalHighlight;
    local l__Component__10 = u18.props.Component;
    if l__Component__10 then
        l__Component__10 = u18.props.Component[u18.props.MegaFocus and "ParentModel" or "Model"];
    end;
    local v49 = u2.createElement(u3, {
        Adornee = u18.props.Attachment,
        Size = UDim2.new(0.12 * u18.props.Scale, 0, 0.12 * u18.props.Scale, 0),
        AffectDistance = function(p44) --[[ Name: AffectDistance, Line 259 ]]
            -- upvalues: u18 (copy)
            if u18.props.DoDistanceFade then
                u18.Distance = p44;
                u18.UpdTransparency(p44);
            end;
        end,
        StudsSize = UDim2.fromScale(0.15, 0.15)
    }, { u2.createElement("UIAspectRatioConstraint", {
            AspectRatio = 1,
            AspectType = Enum.AspectType.ScaleWithParentSize,
            DominantAxis = Enum.DominantAxis.Height
        }), u2.createElement(u4, {
            SoundKit = "MainMenuLoadoutNode",
            Center = true,
            ZIndex = -1,
            BackgroundTransparency = 1,
            Size = UDim2.new(0.4, 0, 0.4, 0),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = u18.props.SlideOutTween and u18.props.SlideOutTween:Map(function(p45) --[[ Line: 280 ]]
                return UDim2.fromScale(0.5, 0.5):Lerp(UDim2.fromScale(0.38, 0.62), p45);
            end) or UDim2.fromScale(0.5, 0.5),
            Ignore = u18.props.SlideOutTween and u2.joinBindings({ u18.props.SlideOutTween:Map(function(p46) --[[ Line: 284 ]]
                    return p46;
                end), u18.props.Enabled }):map(function(p47) --[[ Line: 284 ]]
                return not p47[2] or p47[1] < 0.9;
            end) or u2.joinBindings({ u18.Transparency, u18.props.Enabled }):map(function(p48) --[[ Line: 286 ]]
                return not p48[2] or p48[1] > 0.7;
            end),
            MouseEnter = function() --[[ Name: MouseEnter, Line 290 ]]
                -- upvalues: u18 (copy), l__GlobalHighlight__9 (copy), l__Component__10 (copy)
                if u18.props.DoDistanceFade and (u18.Distance and u18.Distance > 0.7) then
                else
                    if u18.props.SpecialHoverCallback then
                        u18.props.SpecialHoverCallback(true);
                    elseif l__GlobalHighlight__9 and l__Component__10 then
                        l__GlobalHighlight__9.Adornee = l__Component__10;
                    end;
                    u18:setState({
                        Hovering = true
                    });
                end;
            end,
            MouseLeave = function() --[[ Name: MouseLeave, Line 305 ]]
                -- upvalues: u18 (copy), l__GlobalHighlight__9 (copy), l__Component__10 (copy)
                if u18.state.Hovering then
                    if u18.props.SpecialHoverCallback then
                        u18.props.SpecialHoverCallback(false);
                    elseif l__GlobalHighlight__9 and l__GlobalHighlight__9.Adornee == l__Component__10 then
                        l__GlobalHighlight__9.Adornee = nil;
                    end;
                    u18:setState({
                        Hovering = false
                    });
                end;
            end,
            MouseUp = function() --[[ Name: MouseUp, Line 321 ]]
                -- upvalues: u18 (copy)
                if u18.props.DoDistanceFade and (u18.Distance and u18.Distance > 0.7) then
                else
                    if not u18.props.CanLerp and u18.props.Enabled:getValue() then
                        u18.props.Callback(u18.props.FullPath);
                    end;
                end;
            end,
            MouseDown = function() --[[ Name: MouseDown, Line 332 ]]
                -- upvalues: u18 (copy)
                if u18.props.DoDistanceFade and (u18.Distance and u18.Distance > 0.7) then
                else
                    if u18.props.CanLerp and u18.props.Enabled:getValue() then
                        u18.props.Callback(u18.props.FullPath, true);
                    end;
                end;
            end
        }, v25) });
    if l__NonAdderInfo__6 then
        return u2.createFragment({ v49, u2.createElement(u9, {
                IsAdder = false,
                Attachment = u18.props.Attachment,
                FullPath = l__NonAdderInfo__6.FullPath,
                Activated = l__NonAdderInfo__6.Activated,
                IsFunc = v19,
                Name = l__NonAdderInfo__6.Name,
                Enabled = u18.props.Enabled,
                Callback = u18.props.Callback,
                Scale = u18.props.Scale,
                Keybind = l__NonAdderInfo__6.Keybind,
                Component = u18.props.Component,
                DoDistanceFade = u18.props.DoDistanceFade,
                SlideOutTween = u18.SlideOutTween,
                ParentActivated = l__Activated__3,
                ParentHovering = u18.state.Hovering
            }) });
    else
        return v49;
    end;
end;
return u9;