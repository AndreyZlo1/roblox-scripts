-- Services.InterfaceService.MenuInterface.MenuLoadoutComponent.MenuLoadoutAttachmentListComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "asset");
local u3 = v1("Menu");
local u4 = v1("RoactTween");
local u5 = v1("MenuButtonComponent");
local u6 = v1("GameShellProxyScroller");
local u7 = v1("GameShellProxyTextLabel");
local u8 = v1("MenuLoadoutAttachmentPathButton");
local u9 = v1("MenuLoadoutAttachmentLoadoutButton");
local u10 = v1("MenuLoadoutAttachmentComponentButton");
local u11 = v1("MenuLoadoutAttachmentNoneButton");
local u12 = v1("MenuLoadoutAttachmentSearchBar");
local u13 = v1("ClientService");
v1("InputService");
local u14 = v1("MenuLoadoutConstants");
local u15 = v1("Manufacturers");
local u16 = v1("StatsService");
local u17 = v1("stringDistance");
local l__UserInputService__1 = game:GetService("UserInputService");
local v18 = u2.Component:extend("MenuLoadoutAttachmentList");
local u19 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local l__SORT_ORDER__2 = u14.SORT_ORDER;
local l__PATH_ORDER__3 = u14.PATH_ORDER;
local l__CATEGORY_ORDER__4 = u14.CATEGORY_ORDER;
table.insert(l__SORT_ORDER__2, { "LastResort" });
for v20 = 1, #l__SORT_ORDER__2 do
    if l__SORT_ORDER__2[v20][1] == "Category" then
        local v21 = l__SORT_ORDER__2[v20][2];
        table.remove(l__SORT_ORDER__2, v20);
        for v22 = 1, 4 do
            local v23 = v20 + v22 - 1;
            local v24 = { "Category" .. tostring(v22), v21 };
            table.insert(l__SORT_ORDER__2, v23, v24);
        end;
        break;
    end;
end;
for v25, v26 in l__CATEGORY_ORDER__4 do
    l__CATEGORY_ORDER__4[v26] = v25;
end;
local function u33(p27) --[[ Line: 70 ]]
    local l__File__5 = p27.File;
    local v28, v29 = p27:GetMenuConfig();
    local v30 = {};
    if v28 and v29.Camos then
        for v31, _ in v29.Camos do
            v30[v31] = p27:GetCamoConfig(v31);
        end;
    end;
    if l__File__5 and l__File__5.Textures then
        for v32, _ in l__File__5.Textures do
            if not v30[v32] then
                v30[v32] = p27:GetCamoConfig(v32);
            end;
        end;
    end;
    return v30;
end;
local function u45(p34, p35, p36, p37, p38) --[[ Line: 92 ]]
    -- upvalues: u45 (copy)
    local v39 = p37 or {};
    for v40, v41 in p35 do
        local l____IsLast__6 = p35.__IsLast;
        local v42 = type(v41) == "table";
        local v43 = nil;
        if l____IsLast__6 and (v42 and v41.Category) then
            for _, v44 in v41.Category do
                if p34[v44] then
                    v43 = true;
                    break;
                end;
            end;
        end;
        if l____IsLast__6 and (v42 and (v43 or (p34[p38] or p34[v40] and p38 == p36))) then
            table.insert(v39, v41);
        end;
        if v42 and not l____IsLast__6 then
            u45(p34, v41, p36, v39, v40);
        end;
    end;
    return v39;
end;
function v18.init(u46, _) --[[ Line: 121 ]]
    -- upvalues: u4 (copy), u2 (copy), l__UserInputService__1 (copy)
    u46.FilterDropDownTween = u4.new(0);
    u46.FilterHeight = 0.1;
    u46:setState({
        Ascending = true
    });
    u46.FilterClipRef = u2.createRef();
    u46.ButtonsClipRef = u2.createRef();
    u46.Filters = {};
    u46.Input = l__UserInputService__1.InputBegan:Connect(function(p47) --[[ Line: 132 ]]
        -- upvalues: u46 (copy)
        if p47.KeyCode == Enum.KeyCode.ButtonB and u46.Callback then
            u46.Callback(nil, nil, true);
        end;
    end);
    u46.MountTextLabelCalls = {};
    u46.GroupSizeBindings = {};
end;
function v18.willUnmount(p48) --[[ Line: 142 ]]
    p48.Input:Disconnect();
end;
function v18.didUpdate(p49) --[[ Line: 146 ]]
    for _, v50 in p49.MountTextLabelCalls do
        v50();
    end;
end;
function v18.didMount(p51) --[[ Line: 152 ]]
    for _, v52 in p51.MountTextLabelCalls do
        v52();
    end;
end;
function v18.render(u53) --[[ Line: 158 ]]
    -- upvalues: u13 (copy), u33 (copy), u45 (copy), u3 (copy), u14 (copy), u16 (copy), l__CATEGORY_ORDER__4 (copy), u17 (copy), l__SORT_ORDER__2 (copy), l__PATH_ORDER__3 (copy), u2 (copy), u8 (copy), u7 (copy), u19 (copy), u9 (copy), u10 (copy), u15 (copy), u5 (copy), u6 (copy), u11 (copy), u12 (copy)
    local l__props__7 = u53.props;
    local l__state__8 = u53.state;
    local l__Filters__9 = u53.Filters;
    local v54 = l__props__7.ActivePath or {};
    local l__Ignore__10 = l__props__7.Ignore;
    local l__RootComponent__11 = l__props__7.RootComponent;
    local l__LocalClient__12 = u13.LocalClient;
    local v55 = nil;
    local v56 = nil;
    local v57 = nil;
    local v58 = nil;
    local u59 = nil;
    local v60 = false;
    local v61 = v54[#v54];
    if type(v61) == "number" then
        local v62 = u33((l__RootComponent__11:GetChild(table.unpack(v54))));
        local v63 = 0;
        for _, _ in v62 do
            v63 = v63 + 1;
        end;
        if v63 > 0 then
            v58 = {};
            for _, v64 in v62 do
                table.insert(v58, v64);
            end;
            u59 = true;
        else
            v57 = true;
        end;
    else
        local v65 = table.clone(v54);
        table.remove(v65, #v65);
        local v66;
        if #v65 > 0 then
            v66 = l__RootComponent__11:GetChild(table.unpack(v65));
        else
            v66 = false;
        end;
        if #v54 == 1 then
            v66 = l__RootComponent__11;
        end;
        if v66 then
            local v67 = v66:GetCompatibleNames(v61);
            local v68 = {};
            for _, v69 in type(v67) ~= "table" and { v67 } or v67 do
                v68[v69] = true;
            end;
            local v70 = u45(v68, u3, v61);
            if v66.File and (v66.File.BaseComponents and v66.File.BaseComponents[v61]) then
                if #v70 > 0 then
                    v60 = v68.none or v68.None;
                    v58 = v70;
                else
                    v55 = l__RootComponent__11:GetChild(table.unpack(v54));
                end;
            elseif #v70 > 0 then
                v60 = v68.none or v68.None;
                v58 = v70;
            else
                v57 = true;
            end;
        else
            v56 = true;
        end;
    end;
    if v61 then
        v61 = string.find(string.lower(v61), "rail_%d");
    end;
    local v71;
    if #v54 > 0 and not v61 then
        v71 = l__RootComponent__11:GetChild(table.unpack(v54)) or l__RootComponent__11;
    else
        v71 = l__RootComponent__11;
    end;
    local v72, u73 = v71:GetMenuConfig();
    if u59 then
        u73 = v71:GetCamoConfig(v71.MetaData.Camo);
    end;
    local u74 = {};
    local v75 = v58 or {};
    for _, v76 in u14.FILTERS do
        u74[v76[1]] = {};
    end;
    local v77 = {};
    for v78, v79 in v75 do
        local v80 = l__LocalClient__12:IsComponentUnlocked(v79.CamoPath or v79.Path, u59);
        if v79.ForSale == false and not v80 then
            v75[v78] = nil;
        else
            for v81, v82 in u74 do
                local v83;
                if v81 == "Category" then
                    v83 = v79.Type or v79.Category;
                else
                    v83 = v79[v81];
                end;
                if v83 then
                    if type(v83) == "table" then
                        for _, v84 in v83 do
                            v82[v84] = true;
                        end;
                    elseif v83 ~= "" then
                        v82[v83] = true;
                    end;
                end;
            end;
        end;
    end;
    for v85 = #l__Filters__9, 1, -1 do
        local v86 = l__Filters__9[v85];
        if u74[v86.Type][v86.Name] then
            u74[v86.Type][v86.Name] = "Activated";
        else
            table.remove(l__Filters__9, v85);
        end;
    end;
    for _, v87 in v75 do
        local v88 = false;
        for _, v89 in l__Filters__9 do
            local l__Type__13 = v89.Type;
            local l__Name__14 = v89.Name;
            local v90;
            if l__Type__13 == "Category" then
                v90 = v87.Type or v87.Category;
            else
                v90 = v87[l__Type__13];
            end;
            if type(v90) == "table" then
                local v91 = false;
                for _, v92 in v90 do
                    if v92 == l__Name__14 then
                        v91 = true;
                        break;
                    end;
                end;
                if not v91 then
                    v88 = true;
                end;
            elseif v90 ~= l__Name__14 then
                v88 = true;
            end;
        end;
        if not v88 then
            v87.MenuTags = v87.MenuTags or {};
            v87.MenuTags.OGL = nil;
            v87.MenuTags.ORL = nil;
            v87.MenuTags.LEVEL = (v87.Level or 0) > u16.Level;
            if v87.Type and type(v87.Type) == "table" then
                table.sort(v87.Type, function(p93, p94) --[[ Line: 343 ]]
                    -- upvalues: l__CATEGORY_ORDER__4 (ref)
                    return (l__CATEGORY_ORDER__4[p93] or 10000000000) < (l__CATEGORY_ORDER__4[p94] or 10000000000);
                end);
            end;
            if v87.Category and type(v87.Category) == "table" then
                table.sort(v87.Category, function(p95, p96) --[[ Line: 349 ]]
                    -- upvalues: l__CATEGORY_ORDER__4 (ref)
                    return (l__CATEGORY_ORDER__4[p95] or 10000000000) < (l__CATEGORY_ORDER__4[p96] or 10000000000);
                end);
            end;
            table.insert(v77, v87);
        end;
    end;
    if v61 then
        local v97 = table.clone(v54);
        table.remove(v97, #v97);
        local v98 = l__RootComponent__11:GetChild(table.unpack(v97));
        if v98 then
            for _, v99 in v77 do
                local _, v100 = v98:HasEnoughSpace(v54[#v54], v99);
                if v100 then
                    v99.MenuTags.ORL = true;
                end;
            end;
        end;
    end;
    if v54 then
        local v101 = l__RootComponent__11:GetChild(v54[1]);
        if v101 then
            for _, v102 in v77 do
                local v103;
                if v71 == l__RootComponent__11 or not v71 then
                    v103 = nil;
                else
                    v103 = v71;
                end;
                local _, v104 = v101:IsUnderCategoryLimit(v102, v103);
                if v104 then
                    v102.MenuTags.OGL = true;
                end;
            end;
        end;
    end;
    local l__SearchString__15 = u53.state.SearchString;
    local u105;
    if l__SearchString__15 then
        u105 = l__SearchString__15 ~= "";
    else
        u105 = l__SearchString__15;
    end;
    if u105 then
        for _, v106 in v77 do
            local v107 = u17(string.lower(l__SearchString__15), string.lower(v106.Name));
            if v106.Description then
                local v108 = u17;
                local v109 = string.lower(l__SearchString__15);
                v107 = math.min(v107, v108(v109, string.lower(v106.Description)));
            end;
            v106.SearchStringDistance = v107;
        end;
    end;
    local u124 = {
        Active = function(p110) --[[ Line: 402 ]]
            -- upvalues: u73 (ref)
            return u73 == p110;
        end,
        Unlocked = function(p111) --[[ Line: 405 ]]
            -- upvalues: l__LocalClient__12 (copy), u59 (ref)
            return l__LocalClient__12:IsComponentUnlocked(p111.CamoPath or p111.Path, u59);
        end,
        OutOfStock = function(p112) --[[ Line: 411 ]]
            return p112.OutOfStock == true;
        end,
        Category1 = function(p113) --[[ Line: 414 ]]
            local l__Type__16 = p113.Type;
            if l__Type__16 then
                l__Type__16 = l__Type__16[1] or table.concat(l__Type__16, ", ");
            end;
            if not l__Type__16 then
                local l__Category__17 = p113.Category;
                if l__Category__17 then
                    l__Category__17 = l__Category__17[1] or table.concat(l__Category__17, ", ");
                end;
                l__Type__16 = l__Category__17 or p113.Path[#p113.Path - 1];
            end;
            return l__Type__16;
        end,
        Category2 = function(p114) --[[ Line: 417 ]]
            local l__Type__18 = p114.Type;
            if l__Type__18 then
                l__Type__18 = l__Type__18[2] or table.concat(l__Type__18, ", ");
            end;
            if not l__Type__18 then
                local l__Category__19 = p114.Category;
                if l__Category__19 then
                    l__Category__19 = l__Category__19[2] or table.concat(l__Category__19, ", ");
                end;
                l__Type__18 = l__Category__19 or true;
            end;
            return l__Type__18;
        end,
        Category3 = function(p115) --[[ Line: 420 ]]
            local l__Type__20 = p115.Type;
            if l__Type__20 then
                l__Type__20 = l__Type__20[3] or table.concat(l__Type__20, ", ");
            end;
            if not l__Type__20 then
                local l__Category__21 = p115.Category;
                if l__Category__21 then
                    l__Category__21 = l__Category__21[3] or table.concat(l__Category__21, ", ");
                end;
                l__Type__20 = l__Category__21 or true;
            end;
            return l__Type__20;
        end,
        Category4 = function(p116) --[[ Line: 423 ]]
            local l__Type__22 = p116.Type;
            if l__Type__22 then
                l__Type__22 = l__Type__22[4] or table.concat(l__Type__22, ", ");
            end;
            if not l__Type__22 then
                local l__Category__23 = p116.Category;
                if l__Category__23 then
                    l__Category__23 = l__Category__23[4] or table.concat(l__Category__23, ", ");
                end;
                l__Type__22 = l__Category__23 or true;
            end;
            return l__Type__22;
        end,
        Price = function(p117) --[[ Line: 426 ]]
            return p117.Price or 0;
        end,
        Gamepass = function(p118) --[[ Line: 429 ]]
            return p118.Gamepass and true or false;
        end,
        Name = function(p119) --[[ Line: 432 ]]
            return p119.Name;
        end,
        Order = function(p120) --[[ Line: 435 ]]
            return p120.Order or 0;
        end,
        New = function(p121) --[[ Line: 438 ]]
            -- upvalues: u105 (copy)
            return not u105 and (p121.MenuTags and p121.MenuTags.NEW) or false;
        end,
        Search = function(p122) --[[ Line: 441 ]]
            -- upvalues: u105 (copy)
            return u105 and p122.SearchStringDistance or 0;
        end,
        LastResort = function(p123) --[[ Line: 445 ]]
            return tostring(p123);
        end
    };
    local u125 = {
        Category1 = true,
        Category2 = true,
        Category3 = true,
        Category4 = true
    };
    local l__Ascending__24 = l__state__8.Ascending;
    table.sort(v77, function(p126, p127) --[[ Line: 474 ]]
        -- upvalues: l__SORT_ORDER__2 (ref), u124 (copy), u125 (copy), l__Ascending__24 (copy), l__CATEGORY_ORDER__4 (ref)
        local v128 = true;
        local v129 = true;
        local v130 = true;
        local v131 = true;
        for v132 = 1, #l__SORT_ORDER__2 do
            local v133 = l__SORT_ORDER__2[v132];
            local v134 = v133[1];
            local v135 = v133[2];
            local v136 = u124[v134];
            local v137 = u125[v134];
            if v137 then
                if v128 then
                    v130 = v136(p126);
                    if v130 == true then
                        v128 = false;
                    end;
                end;
                if v129 then
                    v131 = v136(p127);
                    if v131 == true then
                        v129 = false;
                    end;
                end;
            else
                v130 = v136(p126);
                v131 = v136(p127);
            end;
            if v130 ~= v131 then
                if l__Ascending__24 or v135 then
                    if v130 == true or v130 == false then
                        return v130;
                    elseif v131 == true or v131 == false then
                        return not v131;
                    elseif v137 and (l__CATEGORY_ORDER__4[v130] and l__CATEGORY_ORDER__4[v131]) then
                        return l__CATEGORY_ORDER__4[v130] < l__CATEGORY_ORDER__4[v131];
                    else
                        return v130 < v131;
                    end;
                else
                    if v130 ~= true and v130 ~= false then
                        if v131 == true or v131 == false then
                            v130 = not v131;
                        elseif v137 and (l__CATEGORY_ORDER__4[v130] and l__CATEGORY_ORDER__4[v131]) then
                            v130 = l__CATEGORY_ORDER__4[v130] < l__CATEGORY_ORDER__4[v131];
                        else
                            v130 = v130 < v131;
                        end;
                    end;
                    return not v130;
                end;
            end;
        end;
    end);
    local v138 = 0;
    if v55 then
        for v139, _ in v55.ChildrenFolders do
            if not (v55.File.Invisible and v55.File.Invisible[v139]) then
                local v140 = table.find(l__PATH_ORDER__3, v139);
                if v140 and type(l__PATH_ORDER__3[v140 - 1]) == "table" then
                    v138 = v138 + 1;
                end;
            end;
        end;
    end;
    local v141, v142, v143, u144, v145, v146, v147, v148, v149, v150, v151, u152, v153, v154, v155, v156, v157, v158, v159, v160, v161, v162, v163, v164, v165, v166, v167, v168, v169, v170, v171, v172, v173, v174, v175, v176, v177, v178, v179, v180;
    if v55 then
        v141 = 0;
        for _, _ in v55.ChildrenFolders do
            v141 = v141 + 1;
        end;
        if v141 then
            v142 = 0;
            for v208, v209 in v77 do
                v143 = v209.Path;
                if v143 then
                    v143 = v209.Path[#v209.Path - 1] == "Receiver";
                end;
                if v143 then
                    v142 = v142 + 1;
                end;
            end;
            u144 = math.max(1, #v77 - v142 + v141 + v142 * 1.5 + v138 * 0.5 + 0.5);
            v145 = {};
            if v55 then
                v146 = 0;
                for v210, _ in v55.ChildrenFolders do
                    if not (v55.File.Invisible and v55.File.Invisible[v210]) then
                        v146 = v146 + 1;
                        v147 = table.find(l__PATH_ORDER__3, v210);
                        v145["SubName" .. v210] = u2.createElement(u8, {
                            Scroller = u53.ButtonsClipRef,
                            Order = (v147 or v146) * 10,
                            Ignore = l__Ignore__10,
                            Callback = l__props__7.Callback,
                            Size = UDim2.new(1, -2, 1 / u144, -2),
                            RootComponent = l__RootComponent__11,
                            ActivePath = v54,
                            SubName = v210
                        });
                        if v147 then
                            v148 = l__PATH_ORDER__3[v147 - 1];
                            if type(v148) == "table" then
                                v149 = v148[1];
                                u53.GroupSizeBindings[v149] = u53.GroupSizeBindings[v149] or { u2.createBinding(0) };
                                v145["Group" .. v149] = u2.createElement("Frame", {
                                    BackgroundTransparency = 1,
                                    LayoutOrder = (v147 or v146) * 10 - 1,
                                    Size = UDim2.new(1, -2, 0.5 / u144, -2)
                                }, { u2.createElement(u7, {
                                        BackgroundTransparency = 1,
                                        DidMount = u53.MountTextLabelCalls,
                                        UpdSizeBinding = u53.GroupSizeBindings[v149][2],
                                        Size = UDim2.fromScale(1, 0.6),
                                        Position = UDim2.new(0, 0, 0.5, 0),
                                        AnchorPoint = Vector2.new(0, 0.5),
                                        Text = v149,
                                        TextColor3 = Color3.new(1, 1, 1),
                                        FontFace = u19
                                    }), u2.createElement("Frame", {
                                        BorderSizePixel = 0,
                                        AnchorPoint = Vector2.new(1, 0.5),
                                        BackgroundColor3 = Color3.new(1, 1, 1),
                                        Size = u53.GroupSizeBindings[v149][1]:map(function(p211) --[[ Line: 592 ]]
                                            return UDim2.new(0.96 - p211, 0, 0, 2);
                                        end),
                                        Position = UDim2.fromScale(1, 0.5)
                                    }) });
                            end;
                        end;
                    end;
                end;
            end;
            if v56 then
                for v212 = 1, #l__LocalClient__12.Loadouts do
                    v150 = l__LocalClient__12.Loadouts[v212];
                    v145["Loadout" .. tostring(v212)] = u2.createElement(u9, {
                        Scroller = u53.ButtonsClipRef,
                        Order = v212,
                        Ignore = l__Ignore__10,
                        Callback = l__props__7.LoadoutCallback,
                        Loadout = v150,
                        Hover = l__props__7.Hover,
                        Active = l__LocalClient__12.ActiveLoadout == v212,
                        Renaming = l__props__7.Renaming == v212,
                        RenamingBind = l__props__7.RenamingBind,
                        UpdRenamingBind = l__props__7.UpdRenamingBind,
                        AttemptRename = l__props__7.AttemptRename,
                        RenameButtonRef = l__props__7.RenameButtonRef,
                        Size = UDim2.new(1, -2, 1 / u144, -2)
                    });
                end;
                v145[-5] = u2.createElement(u9, {
                    Order = 1000,
                    IsAdder = true,
                    Scroller = u53.ButtonsClipRef,
                    Ignore = l__Ignore__10,
                    Callback = l__props__7.LoadoutCallback,
                    Size = UDim2.new(1, -2, 1 / u144, -2)
                });
            end;
            for v213, v214 in v77 do
                v151 = v214.Path;
                if v151 then
                    v151 = v214.Path[#v214.Path - 1] == "Receiver";
                end;
                v145[v213] = u2.createElement(u10, {
                    Scroller = u53.ButtonsClipRef,
                    Order = v213,
                    Ignore = l__Ignore__10,
                    Hover = l__props__7.Hover,
                    Callback = l__props__7.Callback,
                    Active = u73 == v214,
                    IsCamo = u59,
                    EndComponent = v71,
                    RootComponent = l__RootComponent__11,
                    ActivePath = v54,
                    Size = UDim2.new(1, -2, v151 and 1.5 / u144 or 1 / u144, -2),
                    Config = v214
                });
            end;
            if not v57 then
                for _, _ in v145 do
                    v57 = false;
                    break;
                end;
                v57 = true;
            end;
            if v57 then
                v145[-1] = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundTransparency = 0.5,
                    Size = UDim2.new(1, -2, 1 / u144, -2),
                    BackgroundColor3 = Color3.new()
                }, { u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0, 4)
                    }), u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        Text = "NO OPTIONS",
                        TextScaled = true,
                        Size = UDim2.fromScale(1, 0.4),
                        Position = UDim2.fromScale(0.5, 0.5),
                        AnchorPoint = Vector2.new(0.5, 0.5),
                        TextColor3 = Color3.new(0.392157, 0.392157, 0.392157),
                        FontFace = u19,
                        TextXAlignment = Enum.TextXAlignment.Center
                    }) });
            end;
            v145[-2] = u2.createElement("UIPadding", {
                PaddingTop = UDim.new(0, 1),
                PaddingBottom = UDim.new(0, 1)
            });
            v145[-3] = u2.createElement("UIListLayout", {
                FillDirection = Enum.FillDirection.Vertical,
                SortOrder = Enum.SortOrder.LayoutOrder,
                VerticalAlignment = Enum.VerticalAlignment.Top,
                HorizontalAlignment = Enum.HorizontalAlignment.Center,
                Padding = UDim.new(0, 2)
            });
            u152 = {};
            v153 = false;
            if l__state__8.FilterState == "Filter" then
                for v215 = 1, #u14.FILTERS do
                    v154 = u14.FILTERS[v215];
                    v155 = false;
                    v156 = {};
                    for v216, _ in u74[v154[1]] do
                        if not v155 then
                            table.insert(u152, {
                                Type = "Title",
                                Name = v154[2]
                            });
                            v155 = true;
                        end;
                        table.insert(v156, {
                            Type = v154[1],
                            Name = v216
                        });
                    end;
                    table.sort(v156, function(p217, p218) --[[ Line: 715 ]]
                        -- upvalues: l__CATEGORY_ORDER__4 (ref)
                        local l__Name__27 = p217.Name;
                        local l__Name__28 = p218.Name;
                        if l__CATEGORY_ORDER__4[l__Name__27] and l__CATEGORY_ORDER__4[l__Name__28] then
                            return l__CATEGORY_ORDER__4[l__Name__27] < l__CATEGORY_ORDER__4[l__Name__28];
                        else
                            return l__Name__27 < l__Name__28;
                        end;
                    end);
                    for v219 = 1, #v156 do
                        table.insert(u152, v156[v219]);
                    end;
                end;
                if #u152 > 1 then
                    v157 = {
                        Sort = u2.createElement("UIListLayout", {
                            FillDirection = Enum.FillDirection.Vertical,
                            SortOrder = Enum.SortOrder.LayoutOrder,
                            VerticalAlignment = Enum.VerticalAlignment.Center,
                            HorizontalAlignment = Enum.HorizontalAlignment.Center,
                            Padding = UDim.new(0, 0)
                        })
                    };
                    u53.FilterHeight = math.min(#u152, 8.3) / 8.3;
                    if #u152 <= 8.3 then
                        u53.FilterHeight = u53.FilterHeight + 0.1;
                    end;
                    for v220, u221 in u152 do
                        if u221.Type == "Title" then
                            v158 = u2.createElement;
                            v159 = {
                                BackgroundTransparency = 1,
                                Size = UDim2.new(0.9, 0, 0.12048192771084336, 0),
                                SizeConstraint = Enum.SizeConstraint.RelativeXX,
                                LayoutOrder = v220
                            };
                            v160 = { u2.createElement("TextLabel", {
                                    TextScaled = true,
                                    BackgroundTransparency = 1,
                                    Text = u221.Name,
                                    Size = UDim2.new(1, 0, 1, -4),
                                    TextColor3 = Color3.new(0.592157, 0.592157, 0.592157),
                                    FontFace = u19,
                                    TextXAlignment = Enum.TextXAlignment.Center
                                }) };
                            table.insert(v157, v158("Frame", v159, v160));
                        elseif u221.Type == "Manufacturer" then
                            v161 = u15[u221.Name];
                            v162 = u2.createElement;
                            v163 = "Frame";
                            v164 = {
                                BackgroundTransparency = 1,
                                Size = UDim2.new(0.9, 0, 0.12048192771084336, 0),
                                SizeConstraint = Enum.SizeConstraint.RelativeXX,
                                LayoutOrder = v220
                            };
                            v165 = {};
                            v166 = u2.createElement;
                            v167 = u5;
                            v168 = {
                                Name = v161 and (v161.UpperName or v161.Name) or u221.Name,
                                MountTextLabelCalls = u53.MountTextLabelCalls
                            };
                            v169 = {};
                            v170 = v161 and v161.Logo;
                            if v170 then
                                v170 = u2.createElement("ImageLabel", {
                                    BackgroundTransparency = 1,
                                    Image = v161.Logo,
                                    AnchorPoint = Vector2.new(1, 0.5),
                                    Position = UDim2.new(0, -2, 0.5, 0),
                                    Size = UDim2.new((v161.AspectRatio or 1) * (v161.Scale or 1), 0, v161.Scale or 1, 0),
                                    SizeConstraint = Enum.SizeConstraint.RelativeYY,
                                    ScaleType = Enum.ScaleType.Fit
                                });
                            end;
                            v169[1] = v170;
                            v168.NameChildren = v169;
                            v168.Scroller = u53.FilterClipRef;
                            v168.Size = UDim2.new(1, 0, 1, -4);
                            v168.Ignore = l__Ignore__10;
                            v168.Activated = u74[u221.Type][u221.Name] == "Activated";
                            function v168.Callback() --[[ Line: 791 ]]
                                -- upvalues: u53 (copy), u221 (copy), u74 (copy)
                                u53.FilterDropDownTween:SetGoal(0);
                                for v222, v223 in u53.Filters do
                                    if v223.Type == u221.Type then
                                        table.remove(u53.Filters, v222);
                                        break;
                                    end;
                                end;
                                if u74[u221.Type][u221.Name] ~= "Activated" then
                                    table.insert(u53.Filters, {
                                        Type = u221.Type,
                                        Name = u221.Name
                                    });
                                end;
                                u53:setState({
                                    FilterState = false
                                });
                            end;
                            v165[1] = v166(v167, v168);
                            table.insert(v157, v162(v163, v164, v165));
                        else
                            v171 = u2.createElement;
                            v172 = {
                                BackgroundTransparency = 1,
                                Size = UDim2.new(0.9, 0, 0.12048192771084336, 0),
                                SizeConstraint = Enum.SizeConstraint.RelativeXX,
                                LayoutOrder = v220
                            };
                            v173 = { u2.createElement(u5, {
                                    Name = u221.Name,
                                    Scroller = u53.FilterClipRef,
                                    Size = UDim2.new(1, 0, 1, -4),
                                    Ignore = l__Ignore__10,
                                    Activated = u74[u221.Type][u221.Name] == "Activated",
                                    Callback = function() --[[ Name: Callback, Line 824 ]]
                                        -- upvalues: u53 (copy), u221 (copy), u74 (copy)
                                        u53.FilterDropDownTween:SetGoal(0);
                                        for v224, v225 in u53.Filters do
                                            if v225.Type == u221.Type then
                                                table.remove(u53.Filters, v224);
                                                break;
                                            end;
                                        end;
                                        if u74[u221.Type][u221.Name] ~= "Activated" then
                                            table.insert(u53.Filters, {
                                                Type = u221.Type,
                                                Name = u221.Name
                                            });
                                        end;
                                        u53:setState({
                                            FilterState = false
                                        });
                                    end
                                }) };
                            table.insert(v157, v171("Frame", v172, v173));
                        end;
                    end;
                else
                    u53.FilterHeight = 0.24;
                    v157 = { u2.createElement("TextLabel", {
                            Text = "NO FILTERS",
                            TextScaled = true,
                            BackgroundTransparency = 1,
                            Size = UDim2.new(1, 0, 0.5, 0),
                            TextColor3 = Color3.new(0.494118, 0.494118, 0.494118),
                            FontFace = u19,
                            TextXAlignment = Enum.TextXAlignment.Center,
                            Position = UDim2.new(0.5, 0, 0.5, 0),
                            AnchorPoint = Vector2.new(0.5, 0.5)
                        }) };
                end;
            else
                v157 = nil;
            end;
            if u53.LastCategoriesList and #u53.LastCategoriesList == #u152 then
                for v226, v227 in u152 do
                    if not u53.LastCategoriesList[v226] or u53.LastCategoriesList[v226].Name ~= v227.Name then
                        v153 = true;
                        break;
                    end;
                end;
            else
                v153 = true;
            end;
            u53.LastCategoriesList = u152;
            u53.YFilterHeight = u53.FilterHeight * l__props__7.AspectRatio + 0.01;
            u53.NoneOption = v60 and 1 or 0;
            u53.NoneHeight = 0.03;
            u53.SearchBarOption = #v75 > 0 and 1 or 0;
            u53.SearchBarHeight = 0.04;
            v174 = u53.ResetFilterToTop or v153;
            u53.ResetFilterToTop = false;
            if v56 then
                u53.Callback = nil;
            else
                u53.Callback = l__props__7.Callback;
            end;
            v175 = u2.createFragment;
            v176 = {};
            v177 = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                Size = UDim2.fromScale(1, 0.06),
                BackgroundColor3 = Color3.new()
            }, {
                u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0, 4)
                }),
                u2.createElement("UIPadding", {
                    PaddingLeft = UDim.new(0, 0),
                    PaddingRight = UDim.new(0, 0),
                    PaddingTop = UDim.new(0.2, 0),
                    PaddingBottom = UDim.new(0.2, 0)
                }),
                u2.createElement("UIListLayout", {
                    FillDirection = Enum.FillDirection.Horizontal,
                    SortOrder = Enum.SortOrder.LayoutOrder,
                    VerticalAlignment = Enum.VerticalAlignment.Center,
                    HorizontalAlignment = Enum.HorizontalAlignment.Center,
                    Padding = UDim.new(0.03, 0)
                }),
                u2.createElement(u5, {
                    LayoutOrder = 1,
                    Name = v56 and (l__props__7.Pages[1] or "Back") or "Back",
                    Size = UDim2.new(0.29, 0, 1, 0),
                    Ignore = l__Ignore__10,
                    Callback = function() --[[ Name: Callback, Line 923 ]]
                        -- upvalues: l__props__7 (copy)
                        l__props__7.Callback(nil, nil, true);
                    end
                }),
                u2.createElement(u5, {
                    LayoutOrder = 2,
                    Name = "Filter",
                    Size = UDim2.new(0.39, 0, 1, 0),
                    Ignore = l__Ignore__10,
                    Activated = l__state__8.FilterState == "Filter" or #u53.Filters > 0,
                    Callback = function() --[[ Name: Callback, Line 933 ]]
                        -- upvalues: l__state__8 (copy), u53 (copy)
                        if l__state__8.FilterState == "Filter" then
                            u53.FilterDropDownTween:SetGoal(0);
                            u53:setState({
                                FilterState = false
                            });
                        else
                            u53.ResetFilterToTop = true;
                            u53.FilterDropDownTween:SetGoal(1);
                            u53:setState({
                                FilterState = "Filter"
                            });
                        end;
                    end
                }),
                u2.createElement(u5, {
                    LayoutOrder = 3,
                    Activated = false,
                    Size = UDim2.new(0.18999999999999997, 0, 1, 0),
                    Ignore = l__Ignore__10,
                    Name = l__state__8.Ascending and "↓" or "↑",
                    Callback = function() --[[ Name: Callback, Line 954 ]]
                        -- upvalues: u53 (copy), l__state__8 (copy)
                        u53:setState({
                            Ascending = not l__state__8.Ascending
                        });
                    end
                })
            });
            v178 = u2.createElement("Frame", {
                ClipsDescendants = true,
                BackgroundTransparency = 0.5,
                Size = u53.FilterDropDownTween:Map(function(p228) --[[ Line: 963 ]]
                    -- upvalues: u53 (copy)
                    return UDim2.new(1, 0, p228 * u53.FilterHeight, 0);
                end),
                SizeConstraint = Enum.SizeConstraint.RelativeXX,
                BackgroundColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 0.07)
            }, { u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0, 4)
                }), u2.createElement(u6, {
                    BackgroundTransparency = 1,
                    RequiresFocus = true,
                    ScrollingSize = 0,
                    BackToTop = v174,
                    Size = UDim2.new(1, 0, 1, 0),
                    CanvasSize = u53.FilterDropDownTween:Map(function(_) --[[ Line: 980 ]]
                        -- upvalues: u152 (copy), l__props__7 (copy), u53 (copy)
                        return #u152 > 8.3 and math.max(#u152 / 8.3 + 0.1 * l__props__7.AspectRatio / u53.YFilterHeight, 1) or 1;
                    end),
                    Ref = u53.FilterClipRef,
                    Ignore = l__Ignore__10,
                    Content = v157 or {}
                }) });
            if u53.NoneOption == 1 then
                v179 = u2.createElement(u11, {
                    Size = UDim2.fromScale(1, u53.NoneHeight),
                    Position = u53.FilterDropDownTween:Map(function(p229) --[[ Line: 994 ]]
                        -- upvalues: u53 (copy)
                        return UDim2.fromScale(0, 0.075 + u53.SearchBarHeight + p229 * u53.YFilterHeight - 0.006);
                    end),
                    Ignore = l__Ignore__10,
                    Active = not v72,
                    Callback = function() --[[ Name: Callback, Line 999 ]]
                        -- upvalues: l__props__7 (copy)
                        l__props__7.Callback(nil, nil, nil);
                    end
                });
            else
                v179 = false;
            end;
            if u53.SearchBarOption == 1 then
                v180 = u2.createElement(u12, {
                    Size = UDim2.fromScale(1, u53.SearchBarHeight),
                    Position = u53.FilterDropDownTween:Map(function(p230) --[[ Line: 1006 ]]
                        -- upvalues: u53 (copy)
                        return UDim2.fromScale(0, 0.07 + p230 * u53.YFilterHeight - 0.006);
                    end),
                    Ignore = l__Ignore__10,
                    Active = not v72,
                    Callback = function(p231) --[[ Name: Callback, Line 1011 ]]
                        -- upvalues: u53 (copy)
                        u53:setState({
                            SearchString = p231
                        });
                    end
                });
            else
                v180 = false;
            end;
            v176[1], v176[2], v176[3], v176[4], v176[5] = v177, v178, v179, v180, u2.createElement(u6, {
    BackgroundTransparency = 1,
    RequiresFocus = true,
    ScrollingSize = 0.015,
    Ref = u53.ButtonsClipRef,
    BackToTop = l__props__7.BackToTop or v57,
    Size = u53.FilterDropDownTween:Map(function(p232) --[[ Line: 1023 ]]
        -- upvalues: u53 (copy)
        return UDim2.fromScale(1, 0.89 - p232 * u53.YFilterHeight - u53.NoneOption * u53.NoneHeight - u53.SearchBarOption * u53.SearchBarHeight);
    end),
    Position = u53.FilterDropDownTween:Map(function(p233) --[[ Line: 1026 ]]
        -- upvalues: u53 (copy)
        return UDim2.fromScale(0, 0.071 + p233 * u53.YFilterHeight + u53.NoneOption * u53.NoneHeight + u53.SearchBarOption * u53.SearchBarHeight);
    end),
    CanvasSize = u53.FilterDropDownTween:Map(function(p234) --[[ Line: 1029 ]]
        -- upvalues: u144 (copy), u53 (copy)
        return u144 / 12 / (0.89 - p234 * u53.YFilterHeight - u53.NoneOption * u53.NoneHeight - u53.SearchBarOption * u53.SearchBarHeight);
    end),
    Ignore = l__Ignore__10,
    Content = v145
});
            return v175(v176);
        end;
    end;
    if v56 then
        v141 = #l__LocalClient__12.Loadouts;
        if not v141 then
            v141 = 0;
        end;
    else
        v141 = 0;
    end;
    v142 = 0;
    for v208, v209 in v77 do
        v143 = v209.Path;
        if v143 then
            v143 = v209.Path[#v209.Path - 1] == "Receiver";
        end;
        if v143 then
            v142 = v142 + 1;
        end;
    end;
    u144 = math.max(1, #v77 - v142 + v141 + v142 * 1.5 + v138 * 0.5 + 0.5);
    v145 = {};
    if v55 then
        v146 = 0;
        for v210, _ in v55.ChildrenFolders do
            if not (v55.File.Invisible and v55.File.Invisible[v210]) then
                v146 = v146 + 1;
                v147 = table.find(l__PATH_ORDER__3, v210);
                v145["SubName" .. v210] = u2.createElement(u8, {
                    Scroller = u53.ButtonsClipRef,
                    Order = (v147 or v146) * 10,
                    Ignore = l__Ignore__10,
                    Callback = l__props__7.Callback,
                    Size = UDim2.new(1, -2, 1 / u144, -2),
                    RootComponent = l__RootComponent__11,
                    ActivePath = v54,
                    SubName = v210
                });
                if v147 then
                    v148 = l__PATH_ORDER__3[v147 - 1];
                    if type(v148) == "table" then
                        v149 = v148[1];
                        u53.GroupSizeBindings[v149] = u53.GroupSizeBindings[v149] or { u2.createBinding(0) };
                        v145["Group" .. v149] = u2.createElement("Frame", {
                            BackgroundTransparency = 1,
                            LayoutOrder = (v147 or v146) * 10 - 1,
                            Size = UDim2.new(1, -2, 0.5 / u144, -2)
                        }, { u2.createElement(u7, {
                                BackgroundTransparency = 1,
                                DidMount = u53.MountTextLabelCalls,
                                UpdSizeBinding = u53.GroupSizeBindings[v149][2],
                                Size = UDim2.fromScale(1, 0.6),
                                Position = UDim2.new(0, 0, 0.5, 0),
                                AnchorPoint = Vector2.new(0, 0.5),
                                Text = v149,
                                TextColor3 = Color3.new(1, 1, 1),
                                FontFace = u19
                            }), u2.createElement("Frame", {
                                BorderSizePixel = 0,
                                AnchorPoint = Vector2.new(1, 0.5),
                                BackgroundColor3 = Color3.new(1, 1, 1),
                                Size = u53.GroupSizeBindings[v149][1]:map(function(p211) --[[ Line: 592 ]]
                                    return UDim2.new(0.96 - p211, 0, 0, 2);
                                end),
                                Position = UDim2.fromScale(1, 0.5)
                            }) });
                    end;
                end;
            end;
        end;
    end;
    if v56 then
        for v212 = 1, #l__LocalClient__12.Loadouts do
            v150 = l__LocalClient__12.Loadouts[v212];
            v145["Loadout" .. tostring(v212)] = u2.createElement(u9, {
                Scroller = u53.ButtonsClipRef,
                Order = v212,
                Ignore = l__Ignore__10,
                Callback = l__props__7.LoadoutCallback,
                Loadout = v150,
                Hover = l__props__7.Hover,
                Active = l__LocalClient__12.ActiveLoadout == v212,
                Renaming = l__props__7.Renaming == v212,
                RenamingBind = l__props__7.RenamingBind,
                UpdRenamingBind = l__props__7.UpdRenamingBind,
                AttemptRename = l__props__7.AttemptRename,
                RenameButtonRef = l__props__7.RenameButtonRef,
                Size = UDim2.new(1, -2, 1 / u144, -2)
            });
        end;
        v145[-5] = u2.createElement(u9, {
            Order = 1000,
            IsAdder = true,
            Scroller = u53.ButtonsClipRef,
            Ignore = l__Ignore__10,
            Callback = l__props__7.LoadoutCallback,
            Size = UDim2.new(1, -2, 1 / u144, -2)
        });
    end;
    for v213, v214 in v77 do
        v151 = v214.Path;
        if v151 then
            v151 = v214.Path[#v214.Path - 1] == "Receiver";
        end;
        v145[v213] = u2.createElement(u10, {
            Scroller = u53.ButtonsClipRef,
            Order = v213,
            Ignore = l__Ignore__10,
            Hover = l__props__7.Hover,
            Callback = l__props__7.Callback,
            Active = u73 == v214,
            IsCamo = u59,
            EndComponent = v71,
            RootComponent = l__RootComponent__11,
            ActivePath = v54,
            Size = UDim2.new(1, -2, v151 and 1.5 / u144 or 1 / u144, -2),
            Config = v214
        });
    end;
    if not v57 then
        for _, _ in v145 do
            v57 = false;
            break;
        end;
        v57 = true;
    end;
    if v57 then
        v145[-1] = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.5,
            Size = UDim2.new(1, -2, 1 / u144, -2),
            BackgroundColor3 = Color3.new()
        }, { u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }), u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "NO OPTIONS",
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.4),
                Position = UDim2.fromScale(0.5, 0.5),
                AnchorPoint = Vector2.new(0.5, 0.5),
                TextColor3 = Color3.new(0.392157, 0.392157, 0.392157),
                FontFace = u19,
                TextXAlignment = Enum.TextXAlignment.Center
            }) });
    end;
    v145[-2] = u2.createElement("UIPadding", {
        PaddingTop = UDim.new(0, 1),
        PaddingBottom = UDim.new(0, 1)
    });
    v145[-3] = u2.createElement("UIListLayout", {
        FillDirection = Enum.FillDirection.Vertical,
        SortOrder = Enum.SortOrder.LayoutOrder,
        VerticalAlignment = Enum.VerticalAlignment.Top,
        HorizontalAlignment = Enum.HorizontalAlignment.Center,
        Padding = UDim.new(0, 2)
    });
    u152 = {};
    v153 = false;
    if l__state__8.FilterState == "Filter" then
        for v215 = 1, #u14.FILTERS do
            v154 = u14.FILTERS[v215];
            v155 = false;
            v156 = {};
            for v216, _ in u74[v154[1]] do
                if not v155 then
                    table.insert(u152, {
                        Type = "Title",
                        Name = v154[2]
                    });
                    v155 = true;
                end;
                table.insert(v156, {
                    Type = v154[1],
                    Name = v216
                });
            end;
            table.sort(v156, function(p217, p218) --[[ Line: 715 ]]
                -- upvalues: l__CATEGORY_ORDER__4 (ref)
                local l__Name__27 = p217.Name;
                local l__Name__28 = p218.Name;
                if l__CATEGORY_ORDER__4[l__Name__27] and l__CATEGORY_ORDER__4[l__Name__28] then
                    return l__CATEGORY_ORDER__4[l__Name__27] < l__CATEGORY_ORDER__4[l__Name__28];
                else
                    return l__Name__27 < l__Name__28;
                end;
            end);
            for v219 = 1, #v156 do
                table.insert(u152, v156[v219]);
            end;
        end;
        if #u152 > 1 then
            v157 = {
                Sort = u2.createElement("UIListLayout", {
                    FillDirection = Enum.FillDirection.Vertical,
                    SortOrder = Enum.SortOrder.LayoutOrder,
                    VerticalAlignment = Enum.VerticalAlignment.Center,
                    HorizontalAlignment = Enum.HorizontalAlignment.Center,
                    Padding = UDim.new(0, 0)
                })
            };
            u53.FilterHeight = math.min(#u152, 8.3) / 8.3;
            if #u152 <= 8.3 then
                u53.FilterHeight = u53.FilterHeight + 0.1;
            end;
            for v220, u221 in u152 do
                if u221.Type == "Title" then
                    v158 = u2.createElement;
                    v159 = {
                        BackgroundTransparency = 1,
                        Size = UDim2.new(0.9, 0, 0.12048192771084336, 0),
                        SizeConstraint = Enum.SizeConstraint.RelativeXX,
                        LayoutOrder = v220
                    };
                    v160 = { u2.createElement("TextLabel", {
                            TextScaled = true,
                            BackgroundTransparency = 1,
                            Text = u221.Name,
                            Size = UDim2.new(1, 0, 1, -4),
                            TextColor3 = Color3.new(0.592157, 0.592157, 0.592157),
                            FontFace = u19,
                            TextXAlignment = Enum.TextXAlignment.Center
                        }) };
                    table.insert(v157, v158("Frame", v159, v160));
                elseif u221.Type == "Manufacturer" then
                    v161 = u15[u221.Name];
                    v162 = u2.createElement;
                    v163 = "Frame";
                    v164 = {
                        BackgroundTransparency = 1,
                        Size = UDim2.new(0.9, 0, 0.12048192771084336, 0),
                        SizeConstraint = Enum.SizeConstraint.RelativeXX,
                        LayoutOrder = v220
                    };
                    v165 = {};
                    v166 = u2.createElement;
                    v167 = u5;
                    v168 = {
                        Name = v161 and (v161.UpperName or v161.Name) or u221.Name,
                        MountTextLabelCalls = u53.MountTextLabelCalls
                    };
                    v169 = {};
                    v170 = v161 and v161.Logo;
                    if v170 then
                        v170 = u2.createElement("ImageLabel", {
                            BackgroundTransparency = 1,
                            Image = v161.Logo,
                            AnchorPoint = Vector2.new(1, 0.5),
                            Position = UDim2.new(0, -2, 0.5, 0),
                            Size = UDim2.new((v161.AspectRatio or 1) * (v161.Scale or 1), 0, v161.Scale or 1, 0),
                            SizeConstraint = Enum.SizeConstraint.RelativeYY,
                            ScaleType = Enum.ScaleType.Fit
                        });
                    end;
                    v169[1] = v170;
                    v168.NameChildren = v169;
                    v168.Scroller = u53.FilterClipRef;
                    v168.Size = UDim2.new(1, 0, 1, -4);
                    v168.Ignore = l__Ignore__10;
                    v168.Activated = u74[u221.Type][u221.Name] == "Activated";
                    function v168.Callback() --[[ Line: 791 ]]
                        -- upvalues: u53 (copy), u221 (copy), u74 (copy)
                        u53.FilterDropDownTween:SetGoal(0);
                        for v222, v223 in u53.Filters do
                            if v223.Type == u221.Type then
                                table.remove(u53.Filters, v222);
                                break;
                            end;
                        end;
                        if u74[u221.Type][u221.Name] ~= "Activated" then
                            table.insert(u53.Filters, {
                                Type = u221.Type,
                                Name = u221.Name
                            });
                        end;
                        u53:setState({
                            FilterState = false
                        });
                    end;
                    v165[1] = v166(v167, v168);
                    table.insert(v157, v162(v163, v164, v165));
                else
                    v171 = u2.createElement;
                    v172 = {
                        BackgroundTransparency = 1,
                        Size = UDim2.new(0.9, 0, 0.12048192771084336, 0),
                        SizeConstraint = Enum.SizeConstraint.RelativeXX,
                        LayoutOrder = v220
                    };
                    v173 = { u2.createElement(u5, {
                            Name = u221.Name,
                            Scroller = u53.FilterClipRef,
                            Size = UDim2.new(1, 0, 1, -4),
                            Ignore = l__Ignore__10,
                            Activated = u74[u221.Type][u221.Name] == "Activated",
                            Callback = function() --[[ Name: Callback, Line 824 ]]
                                -- upvalues: u53 (copy), u221 (copy), u74 (copy)
                                u53.FilterDropDownTween:SetGoal(0);
                                for v224, v225 in u53.Filters do
                                    if v225.Type == u221.Type then
                                        table.remove(u53.Filters, v224);
                                        break;
                                    end;
                                end;
                                if u74[u221.Type][u221.Name] ~= "Activated" then
                                    table.insert(u53.Filters, {
                                        Type = u221.Type,
                                        Name = u221.Name
                                    });
                                end;
                                u53:setState({
                                    FilterState = false
                                });
                            end
                        }) };
                    table.insert(v157, v171("Frame", v172, v173));
                end;
            end;
        else
            u53.FilterHeight = 0.24;
            v157 = { u2.createElement("TextLabel", {
                    Text = "NO FILTERS",
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    Size = UDim2.new(1, 0, 0.5, 0),
                    TextColor3 = Color3.new(0.494118, 0.494118, 0.494118),
                    FontFace = u19,
                    TextXAlignment = Enum.TextXAlignment.Center,
                    Position = UDim2.new(0.5, 0, 0.5, 0),
                    AnchorPoint = Vector2.new(0.5, 0.5)
                }) };
        end;
    else
        v157 = nil;
    end;
    if u53.LastCategoriesList and #u53.LastCategoriesList == #u152 then
        for v226, v227 in u152 do
            if not u53.LastCategoriesList[v226] or u53.LastCategoriesList[v226].Name ~= v227.Name then
                v153 = true;
                break;
            end;
        end;
    else
        v153 = true;
    end;
    u53.LastCategoriesList = u152;
    u53.YFilterHeight = u53.FilterHeight * l__props__7.AspectRatio + 0.01;
    u53.NoneOption = v60 and 1 or 0;
    u53.NoneHeight = 0.03;
    u53.SearchBarOption = #v75 > 0 and 1 or 0;
    u53.SearchBarHeight = 0.04;
    v174 = u53.ResetFilterToTop or v153;
    u53.ResetFilterToTop = false;
    if v56 then
        u53.Callback = nil;
    else
        u53.Callback = l__props__7.Callback;
    end;
    v175 = u2.createFragment;
    v176 = {};
    v177 = u2.createElement("Frame", {
        BackgroundTransparency = 0.5,
        Size = UDim2.fromScale(1, 0.06),
        BackgroundColor3 = Color3.new()
    }, {
        u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 4)
        }),
        u2.createElement("UIPadding", {
            PaddingLeft = UDim.new(0, 0),
            PaddingRight = UDim.new(0, 0),
            PaddingTop = UDim.new(0.2, 0),
            PaddingBottom = UDim.new(0.2, 0)
        }),
        u2.createElement("UIListLayout", {
            FillDirection = Enum.FillDirection.Horizontal,
            SortOrder = Enum.SortOrder.LayoutOrder,
            VerticalAlignment = Enum.VerticalAlignment.Center,
            HorizontalAlignment = Enum.HorizontalAlignment.Center,
            Padding = UDim.new(0.03, 0)
        }),
        u2.createElement(u5, {
            LayoutOrder = 1,
            Name = v56 and (l__props__7.Pages[1] or "Back") or "Back",
            Size = UDim2.new(0.29, 0, 1, 0),
            Ignore = l__Ignore__10,
            Callback = function() --[[ Name: Callback, Line 923 ]]
                -- upvalues: l__props__7 (copy)
                l__props__7.Callback(nil, nil, true);
            end
        }),
        u2.createElement(u5, {
            LayoutOrder = 2,
            Name = "Filter",
            Size = UDim2.new(0.39, 0, 1, 0),
            Ignore = l__Ignore__10,
            Activated = l__state__8.FilterState == "Filter" or #u53.Filters > 0,
            Callback = function() --[[ Name: Callback, Line 933 ]]
                -- upvalues: l__state__8 (copy), u53 (copy)
                if l__state__8.FilterState == "Filter" then
                    u53.FilterDropDownTween:SetGoal(0);
                    u53:setState({
                        FilterState = false
                    });
                else
                    u53.ResetFilterToTop = true;
                    u53.FilterDropDownTween:SetGoal(1);
                    u53:setState({
                        FilterState = "Filter"
                    });
                end;
            end
        }),
        u2.createElement(u5, {
            LayoutOrder = 3,
            Activated = false,
            Size = UDim2.new(0.18999999999999997, 0, 1, 0),
            Ignore = l__Ignore__10,
            Name = l__state__8.Ascending and "↓" or "↑",
            Callback = function() --[[ Name: Callback, Line 954 ]]
                -- upvalues: u53 (copy), l__state__8 (copy)
                u53:setState({
                    Ascending = not l__state__8.Ascending
                });
            end
        })
    });
    v178 = u2.createElement("Frame", {
        ClipsDescendants = true,
        BackgroundTransparency = 0.5,
        Size = u53.FilterDropDownTween:Map(function(p228) --[[ Line: 963 ]]
            -- upvalues: u53 (copy)
            return UDim2.new(1, 0, p228 * u53.FilterHeight, 0);
        end),
        SizeConstraint = Enum.SizeConstraint.RelativeXX,
        BackgroundColor3 = Color3.new(),
        Position = UDim2.fromScale(0, 0.07)
    }, { u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 4)
        }), u2.createElement(u6, {
            BackgroundTransparency = 1,
            RequiresFocus = true,
            ScrollingSize = 0,
            BackToTop = v174,
            Size = UDim2.new(1, 0, 1, 0),
            CanvasSize = u53.FilterDropDownTween:Map(function(_) --[[ Line: 980 ]]
                -- upvalues: u152 (copy), l__props__7 (copy), u53 (copy)
                return #u152 > 8.3 and math.max(#u152 / 8.3 + 0.1 * l__props__7.AspectRatio / u53.YFilterHeight, 1) or 1;
            end),
            Ref = u53.FilterClipRef,
            Ignore = l__Ignore__10,
            Content = v157 or {}
        }) });
    if u53.NoneOption == 1 then
        v179 = u2.createElement(u11, {
            Size = UDim2.fromScale(1, u53.NoneHeight),
            Position = u53.FilterDropDownTween:Map(function(p229) --[[ Line: 994 ]]
                -- upvalues: u53 (copy)
                return UDim2.fromScale(0, 0.075 + u53.SearchBarHeight + p229 * u53.YFilterHeight - 0.006);
            end),
            Ignore = l__Ignore__10,
            Active = not v72,
            Callback = function() --[[ Name: Callback, Line 999 ]]
                -- upvalues: l__props__7 (copy)
                l__props__7.Callback(nil, nil, nil);
            end
        });
    else
        v179 = false;
    end;
    if u53.SearchBarOption == 1 then
        v180 = u2.createElement(u12, {
            Size = UDim2.fromScale(1, u53.SearchBarHeight),
            Position = u53.FilterDropDownTween:Map(function(p230) --[[ Line: 1006 ]]
                -- upvalues: u53 (copy)
                return UDim2.fromScale(0, 0.07 + p230 * u53.YFilterHeight - 0.006);
            end),
            Ignore = l__Ignore__10,
            Active = not v72,
            Callback = function(p231) --[[ Name: Callback, Line 1011 ]]
                -- upvalues: u53 (copy)
                u53:setState({
                    SearchString = p231
                });
            end
        });
    else
        v180 = false;
    end;
    v176[1], v176[2], v176[3], v176[4], v176[5] = v177, v178, v179, v180, u2.createElement(u6, {
    BackgroundTransparency = 1,
    RequiresFocus = true,
    ScrollingSize = 0.015,
    Ref = u53.ButtonsClipRef,
    BackToTop = l__props__7.BackToTop or v57,
    Size = u53.FilterDropDownTween:Map(function(p232) --[[ Line: 1023 ]]
        -- upvalues: u53 (copy)
        return UDim2.fromScale(1, 0.89 - p232 * u53.YFilterHeight - u53.NoneOption * u53.NoneHeight - u53.SearchBarOption * u53.SearchBarHeight);
    end),
    Position = u53.FilterDropDownTween:Map(function(p233) --[[ Line: 1026 ]]
        -- upvalues: u53 (copy)
        return UDim2.fromScale(0, 0.071 + p233 * u53.YFilterHeight + u53.NoneOption * u53.NoneHeight + u53.SearchBarOption * u53.SearchBarHeight);
    end),
    CanvasSize = u53.FilterDropDownTween:Map(function(p234) --[[ Line: 1029 ]]
        -- upvalues: u144 (copy), u53 (copy)
        return u144 / 12 / (0.89 - p234 * u53.YFilterHeight - u53.NoneOption * u53.NoneHeight - u53.SearchBarOption * u53.SearchBarHeight);
    end),
    Ignore = l__Ignore__10,
    Content = v145
});
    return v175(v176);
end;
return v18;