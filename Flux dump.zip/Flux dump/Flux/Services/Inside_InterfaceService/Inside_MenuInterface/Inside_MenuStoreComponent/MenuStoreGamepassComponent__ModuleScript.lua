-- Services.InterfaceService.MenuInterface.MenuStoreComponent.MenuStoreGamepassComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local u3 = v1("GameShellProxyButton");
local u4 = v1("RoactTween");
local l__MarketplaceService__1 = game:GetService("MarketplaceService");
local l__LocalPlayer__2 = game:GetService("Players").LocalPlayer;
local u5 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u6 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local v7 = u2.Component:extend("MenuStoreGamepass");
function v7.init(p8) --[[ Line: 16 ]]
    -- upvalues: u4 (copy)
    p8.Hover = u4.new(0);
    p8:setState({
        Hovering = false
    });
end;
function v7.render(u9) --[[ Line: 23 ]]
    -- upvalues: u2 (copy), u5 (copy), u3 (copy), l__MarketplaceService__1 (copy), l__LocalPlayer__2 (copy), u6 (copy)
    local l__props__3 = u9.props;
    local l__Hovering__4 = u9.state.Hovering;
    local v10 = {};
    for v11, v12 in l__props__3.Description do
        v10[v11] = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            Size = UDim2.fromScale(1, 0.1),
            Text = "• " .. v12,
            TextColor3 = Color3.fromRGB(255, 194, 89),
            TextTransparency = u9.Hover:Map(function(p13) --[[ Line: 36 ]]
                return 1 - p13;
            end),
            FontFace = u5,
            TextXAlignment = Enum.TextXAlignment.Left
        });
    end;
    return u2.createElement(u3, {
        SoundKit = "MainMenuBig",
        Image = "",
        BorderSizePixel = 0,
        ClipsDescendants = true,
        Scroller = l__props__3.Scroller,
        BackgroundColor3 = Color3.new(),
        AnchorPoint = l__props__3.AnchorPoint,
        Size = l__props__3.Size,
        Position = l__props__3.Position,
        Ignore = l__props__3.Ignore,
        MouseUp = function() --[[ Name: MouseUp, Line 56 ]]
            -- upvalues: l__MarketplaceService__1 (ref), l__LocalPlayer__2 (ref), l__props__3 (copy)
            l__MarketplaceService__1:PromptGamePassPurchase(l__LocalPlayer__2, l__props__3.Gamepass);
        end,
        MouseEnter = function() --[[ Name: MouseEnter, Line 59 ]]
            -- upvalues: u9 (copy)
            u9.Hover:SetGoal(1);
            u9:setState({
                Hovering = true
            });
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 65 ]]
            -- upvalues: u9 (copy)
            u9.Hover:SetGoal(0);
            u9:setState({
                Hovering = false
            });
        end
    }, {
        Corner = u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 1)
        }),
        Stroke = u2.createElement("UIStroke", {
            Thickness = 1,
            ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
            Color = l__Hovering__4 and Color3.fromRGB(255, 194, 89) or Color3.fromRGB(71, 71, 71),
            LineJoinMode = Enum.LineJoinMode.Round
        }),
        Hover = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = u9.Hover:Map(function(p14) --[[ Line: 86 ]]
                local v15 = p14 / 5;
                return UDim2.fromScale(v15 + 1, v15 + 1);
            end),
            ImageTransparency = u9.Hover:Map(function(p16) --[[ Line: 90 ]]
                return p16 / 2;
            end),
            Image = l__props__3.Image
        }, {
            Gradient = u2.createElement("UIGradient", {
                Rotation = 90,
                Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.new(1, 1, 1)), ColorSequenceKeypoint.new(0.6, Color3.new(1, 1, 1)), ColorSequenceKeypoint.new(1, Color3.new(0, 0, 0)) })
            })
        }),
        Symbol = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxasset://textures/ui/common/robux@2x.png",
            ZIndex = 2,
            AnchorPoint = Vector2.new(1, 0.5),
            Position = UDim2.fromScale(0.84, 0.8),
            Size = UDim2.fromScale(0.1, 0.1),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            ImageTransparency = u9.Hover:Map(function(p17) --[[ Line: 111 ]]
                return p17 * 0.5;
            end),
            ImageColor3 = Color3.new(1, 1, 1)
        }),
        Robux = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            ZIndex = 2,
            Size = UDim2.fromScale(0.89, 0.18),
            AnchorPoint = Vector2.new(0, 0.5),
            Position = UDim2.fromScale(0.05, 0.8),
            Text = l__props__3.Robux,
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = Enum.TextXAlignment.Right,
            TextTransparency = u9.Hover:Map(function(p18) --[[ Line: 128 ]]
                return p18 * 0.5;
            end),
            FontFace = u6
        }),
        Name = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            ZIndex = 2,
            Size = UDim2.fromScale(0.9, 0.2),
            Position = UDim2.fromScale(0.05, 0.7),
            Text = l__props__3.Name:upper(),
            TextColor3 = l__Hovering__4 and Color3.fromRGB(255, 194, 89) or Color3.new(1, 1, 1),
            TextXAlignment = Enum.TextXAlignment.Left,
            FontFace = u5
        }),
        Description = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            Size = UDim2.fromScale(0.9, 0.7),
            Position = UDim2.fromScale(0.05, 0.7),
            AnchorPoint = Vector2.new(0, 1)
        }, { u2.createElement("UIListLayout", {
                FillDirection = Enum.FillDirection.Vertical,
                HorizontalAlignment = Enum.HorizontalAlignment.Left,
                SortOrder = Enum.SortOrder.LayoutOrder,
                VerticalAlignment = Enum.VerticalAlignment.Bottom,
                Padding = UDim.new(0, 0)
            }), u2.createFragment(v10) })
    });
end;
return v7;