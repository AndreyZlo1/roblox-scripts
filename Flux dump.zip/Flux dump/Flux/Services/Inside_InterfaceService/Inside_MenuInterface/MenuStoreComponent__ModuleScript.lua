-- Services.InterfaceService.MenuInterface.MenuStoreComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "asset");
local u4 = v1("StatsService");
local u5 = v1("SoundService");
local u6 = v1("RoactTween");
local u7 = v1("CreditPurchaseOptions");
local u8 = v1("GameShellProxyScroller");
local u9 = v1("PopupShopButtonComponent");
local u10 = v1("MenuStoreGamepassComponent");
local v11 = u2.Component:extend("MenuStore");
local l__RunService__1 = game:GetService("RunService");
local u12 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u13 = {
    {
        Image = "rbxassetid://71825578400917",
        Robux = 49,
        Length = "30 mins",
        Product = 500756759,
        Position = 0.25,
        Anchor = 0,
        Color = Color3.new(1, 0.5, 0)
    },
    {
        Image = "rbxassetid://4538211518",
        Robux = 75,
        Length = "1 hour",
        Product = 500770461,
        Position = 0.61,
        Anchor = 0.5,
        Extra = "Extra 15 minutes",
        Color = Color3.new(1, 0.5, 0)
    },
    {
        Image = "rbxassetid://4538211834",
        Robux = 125,
        Length = "2 hours",
        Product = 500770611,
        Position = 0.97,
        Anchor = 1,
        Extra = "Extra 45 minutes",
        Color = Color3.new(1, 0.5, 0)
    }
};
local function u18(p14) --[[ Line: 51 ]]
    local v15 = p14 % 60;
    local v16 = math.floor(p14 / 60) % 60;
    local v17 = math.floor(p14 / 3600) % 24;
    if p14 <= 0 then
        v17 = 0;
        v16 = 0;
        v15 = 0;
    end;
    return string.format("%02i", v17) .. ":" .. string.format("%02i", v16) .. ":" .. string.format("%02i", v15);
end;
local function u21(p19, p20) --[[ Line: 64 ]]
    -- upvalues: u2 (copy)
    return u2.createElement("Frame", {
        BorderSizePixel = 0,
        BackgroundColor3 = Color3.new(),
        Position = p20,
        BorderColor3 = Color3.new(),
        Size = UDim2.fromScale(1, 0.04)
    }, {
        Dots = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://13867939464",
            ImageColor3 = Color3.fromRGB(71, 71, 71),
            ScaleType = Enum.ScaleType.Tile,
            Size = UDim2.fromScale(1, 1),
            TileSize = UDim2.fromOffset(6, 6)
        }, {
            Count = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
                Position = UDim2.fromScale(0.025, 0.5),
                Size = UDim2.fromScale(0.3, 0.6),
                Text = p19,
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            Gradient = u2.createElement("UIGradient", {
                Rotation = 139,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
            })
        })
    });
end;
function v11.init(u22, _) --[[ Line: 107 ]]
    -- upvalues: u5 (copy), u6 (copy), u2 (copy), u4 (copy), l__RunService__1 (copy)
    u5:CreateSound("Button", nil, true, "UISounds", "ShopOpen").Destroy(10);
    u22.Landing = u6.new(0);
    u22.Landing:SetGoal(1);
    u22.ScrollerRef = u2.createRef();
    local v23, v24 = u2.createBinding(os.difftime(u4.Expires, os.time()));
    u22.Expiry = v23;
    u22.UpdateExpiry = v24;
    u22.Update = l__RunService__1.Heartbeat:Connect(function() --[[ Line: 116 ]]
        -- upvalues: u22 (copy), u4 (ref)
        u22.UpdateExpiry(os.difftime(u4.Expires, os.time()));
    end);
end;
function v11.willUnmount(p25) --[[ Line: 121 ]]
    p25.Update:Disconnect();
end;
function v11.render(p26) --[[ Line: 125 ]]
    -- upvalues: u7 (copy), u2 (copy), u9 (copy), u4 (copy), u13 (copy), u3 (copy), u21 (copy), u12 (copy), u18 (copy), u10 (copy), u8 (copy)
    local l__props__2 = p26.props;
    local _ = p26.Landing;
    local l__PopupActive__3 = l__props__2.PopupActive;
    local u27 = 1;
    local v28 = {};
    for v29, u30 in u7 do
        local v31, u32 = u2.createBinding(u27);
        v28[v29] = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ZIndex = v31,
            LayoutOrder = v29
        }, {
            Inner = u2.createElement(u9, {
                Option = u30,
                Ignore = l__PopupActive__3,
                Callback = function() --[[ Name: Callback, Line 142 ]]
                    -- upvalues: u4 (ref), u30 (copy)
                    u4:PromptProduct(u30.Product, true, true);
                end,
                IncreaseZIndex = function() --[[ Name: IncreaseZIndex, Line 145 ]]
                    -- upvalues: u27 (ref), u32 (copy)
                    u27 = u27 + 1;
                    u32(u27);
                end,
                Scroller = p26.ScrollerRef,
                SoundKit = u30.Big and "ShopCreditsBig" or "ShopCredits"
            })
        });
    end;
    local v33 = {};
    for v34, u35 in u13 do
        local v36, u37 = u2.createBinding(u27);
        v33[v34] = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ZIndex = v36,
            Position = UDim2.fromScale(u35.Position, 0),
            Size = UDim2.fromScale(0.24, 1),
            AnchorPoint = Vector2.new(u35.Anchor, 0)
        }, {
            Inner = u2.createElement(u9, {
                SoundKit = "ShopEXP",
                Option = u35,
                Ignore = l__PopupActive__3,
                Callback = function() --[[ Name: Callback, Line 168 ]]
                    -- upvalues: u3 (ref), u4 (ref), u35 (copy)
                    u3:Get("Sound", "UISounds", "EXPPurchase"):Preload();
                    u4:PromptProduct(u35.Product);
                end,
                IncreaseZIndex = function() --[[ Name: IncreaseZIndex, Line 172 ]]
                    -- upvalues: u27 (ref), u37 (copy)
                    u27 = u27 + 1;
                    u37(u27);
                end,
                Scroller = p26.ScrollerRef
            })
        });
    end;
    local v39 = {
        CreditsHeader = u21("CURRENCY", UDim2.fromScale(0, 0)),
        CreditsBackground = u2.createElement("Frame", {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0, 0.04),
            Size = UDim2.fromScale(1, 0.305)
        }, {
            Line = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 1),
                SizeConstraint = Enum.SizeConstraint.RelativeXX,
                Size = UDim2.fromScale(1, 0.002)
            }),
            Gradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.5375) })
            })
        }),
        Credits = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            Position = UDim2.fromScale(0.05, 0.04),
            Size = UDim2.fromScale(0.9, 0.3)
        }, {
            u2.createFragment(v28),
            UIGridLayout = u2.createElement("UIGridLayout", {
                CellPadding = UDim2.new(),
                CellSize = UDim2.fromScale(0.25, 0.5),
                SortOrder = Enum.SortOrder.LayoutOrder
            })
        }),
        BoosterHeader = u21("DOUBLE EXP BOOSTERS", UDim2.fromScale(0, 0.345)),
        BoosterBackground = u2.createElement("Frame", {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.fromRGB(253, 255, 255),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0, 0.385),
            Size = UDim2.fromScale(1, 0.175)
        }, {
            Line = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 1),
                SizeConstraint = Enum.SizeConstraint.RelativeXX,
                Size = UDim2.fromScale(1, 0.002)
            }),
            Gradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 147, 0)), ColorSequenceKeypoint.new(0.256667, Color3.fromRGB(59, 34, 0)), ColorSequenceKeypoint.new(1, Color3.new()) }),
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.5375) })
            })
        }),
        BoosterOptions = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            Size = UDim2.new(0.96, 0, 0.165, 0),
            Position = UDim2.new(0.02, 0, 0.39, 0)
        }, {
            u2.createFragment(v33),
            Boost = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.new(1, 1, 1),
                Position = UDim2.fromScale(0, 0.05),
                Size = UDim2.fromScale(0.24, 0.9)
            }, {
                u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "2x",
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
                    Position = UDim2.fromScale(0.2, 0.22),
                    Size = UDim2.fromScale(1, 0.4),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = Enum.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "ON EVERY <u>KILL</u>",
                    RichText = true,
                    TextScaled = true,
                    FontFace = Font.new("rbxassetid://12187375422"),
                    Position = UDim2.fromScale(0.45, 0.21),
                    Size = UDim2.fromScale(1, 0.12),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = Enum.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "EXP",
                    TextScaled = true,
                    FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
                    Position = UDim2.fromScale(0.45, 0.1),
                    Size = UDim2.fromScale(1, 0.12),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = Enum.TextXAlignment.Left
                }),
                Image = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Image = "rbxassetid://4520264138",
                    AnchorPoint = Vector2.new(0, 0.5),
                    Position = UDim2.new(0.26, 0, 0.7, 0),
                    Size = UDim2.new(0.13, 0, 0, 0),
                    ImageColor3 = Color3.new(1, 1, 1),
                    ScaleType = Enum.ScaleType.Fit
                }, {
                    Aspect = u2.createElement("UIAspectRatioConstraint", {
                        AspectRatio = 1,
                        AspectType = Enum.AspectType.ScaleWithParentSize,
                        DominantAxis = Enum.DominantAxis.Width
                    }),
                    Amount = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        AnchorPoint = Vector2.new(0, 0.5),
                        Position = UDim2.new(1.25, 0, 0.5, 0),
                        Size = UDim2.new(10, 0, 0.8, 0),
                        FontFace = u12,
                        Text = p26.Expiry:map(function(p38) --[[ Line: 329 ]]
                            -- upvalues: u18 (ref)
                            return u18(p38);
                        end),
                        TextColor3 = Color3.new(1, 1, 1),
                        TextXAlignment = Enum.TextXAlignment.Left
                    })
                }),
                Remaining = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "REMAINING",
                    TextScaled = true,
                    Position = UDim2.new(0, 0, 0.8, 0),
                    Size = UDim2.new(1, 0, 0.12, 0),
                    FontFace = u12,
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = Enum.TextXAlignment.Center
                }),
                u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "LEVEL UP FAST ⬆",
                    TextScaled = true,
                    FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
                    Position = UDim2.fromScale(0, 0.4),
                    Size = UDim2.fromScale(1, 0.12),
                    TextColor3 = Color3.fromRGB(239, 155, 55)
                })
            })
        }),
        PassesHeader = u21("PASSES", UDim2.fromScale(0, 0.56)),
        PassesBackground = u2.createElement("Frame", {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0, 0.6),
            Size = UDim2.fromScale(1, 0.4)
        }, {
            Line = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 1),
                SizeConstraint = Enum.SizeConstraint.RelativeXX,
                Size = UDim2.fromScale(1, 0.002)
            }),
            Gradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.5375) })
            })
        }),
        GamepassOptions = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            Size = UDim2.new(0.95, 0, 0.18, 0),
            Position = UDim2.new(0.02, 0, 0.61, 0)
        }, {
            Chinook = u2.createElement(u10, {
                Name = "Chinook CH-47",
                Image = "rbxassetid://123986803315593",
                Robux = 200,
                Gamepass = 6133997,
                Ignore = l__PopupActive__3,
                Size = UDim2.fromScale(0.49, 1),
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.fromScale(0, 0),
                Description = { "CH-47D \'Chinook\' medium-lift transport helicopter", "A2CU \'RL1\' flight suit (OCP)" },
                Scroller = p26.ScrollerRef
            }),
            Shadow = u2.createElement(u10, {
                Name = "Shadow Raid Pack",
                Image = "rbxassetid://138238678115016",
                Robux = 450,
                Gamepass = 7233611,
                Ignore = l__PopupActive__3,
                Size = UDim2.fromScale(0.49, 1),
                AnchorPoint = Vector2.new(1, 0),
                Position = UDim2.fromScale(1, 0),
                Description = { "GPNVG-18 panoramic night vision device", "XTREM combat suit (SRC)", "Shadow Raid camouflage finish for most weapon systems" },
                Scroller = p26.ScrollerRef
            })
        }),
        GamepassOptionsSecond = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            Size = UDim2.new(0.95, 0, 0.18, 0),
            Position = UDim2.new(0.02, 0, 0.805, 0)
        }, {
            RAL8000 = u2.createElement(u10, {
                Name = "RAL 8000 Camo Pack",
                Image = "rbxassetid://15542929981",
                Robux = 250,
                Gamepass = 131945411,
                Ignore = l__PopupActive__3,
                Size = UDim2.fromScale(0.49, 1),
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.fromScale(0, 0),
                Description = {
                    "UMP45 RAL 8000 Camo",
                    "G36 RAL 8000 Camo",
                    "USP RAL 8000 Camo",
                    "MP5 RAL 8000 Camo",
                    "DWF 416 RAL 8000 Camo"
                },
                Scroller = p26.ScrollerRef
            }),
            Scout = u2.createElement(u10, {
                Name = "Airborne Recon Pack",
                Image = "rbxassetid://130415207816154",
                Robux = 600,
                Gamepass = 194157058,
                Ignore = l__PopupActive__3,
                Size = UDim2.fromScale(0.49, 1),
                AnchorPoint = Vector2.new(1, 0),
                Position = UDim2.fromScale(1, 0),
                Description = {
                    "SRTV all-terrain vehicle",
                    "MPC 2.0 \'Special Tactics\' plate carrier",
                    "PCU Block 0, level 5 softshell jacket (VariCam)",
                    "\'Scrim\' accessories for various headgear items (Leaf Covers)",
                    "Special Tactics camouflage finish for select weapon systems"
                },
                Scroller = p26.ScrollerRef
            })
        })
    };
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        AnchorPoint = Vector2.new(0.5, 0),
        Size = UDim2.fromScale(0, 0.85),
        Position = UDim2.fromScale(0.5, 0.05)
    }, { u2.createElement("UIAspectRatioConstraint", {
            AspectRatio = 2,
            AspectType = Enum.AspectType.ScaleWithParentSize,
            DominantAxis = Enum.DominantAxis.Height
        }), u2.createElement(u8, {
            BackgroundTransparency = 1,
            NoGradient = true,
            CanvasSize = 2,
            Size = UDim2.new(1, 0, 1, 0),
            Ignore = l__PopupActive__3,
            Content = v39,
            Ref = p26.ScrollerRef
        }) });
end;
return v11;