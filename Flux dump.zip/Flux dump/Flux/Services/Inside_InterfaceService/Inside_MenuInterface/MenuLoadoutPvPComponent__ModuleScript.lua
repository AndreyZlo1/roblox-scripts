-- Services.InterfaceService.MenuInterface.MenuLoadoutPvPComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _, u3 = shared.import("require", "Roact", "server", "network");
local u4 = v1("ClientService");
local u5 = v1("SoundService");
local u6 = v1("GameShellProxyScroller");
local u7 = v1("MenuLoadoutAttachmentLoadoutButton");
local u8 = v1("BaseComponent");
local v9 = u2.Component:extend("MenuLoadoutPvP");
local u10 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
function v9.init(u11, _) --[[ Line: 16 ]]
    -- upvalues: u5 (copy), u4 (copy), u2 (copy), u8 (copy)
    u5:CreateSound("Button", nil, true, "UISounds", "LoadoutOpen").Destroy(10);
    local l__LocalClient__1 = u4.LocalClient;
    local v12 = Instance.new("Camera");
    v12.CFrame = CFrame.new(0, 0, -10) * CFrame.Angles(0, 3.141592653589793, 0);
    v12.FieldOfView = 50;
    u11.camera = v12;
    u11.viewModel = u2.createRef();
    u11.previewModel = u2.createRef();
    function u11.genModels() --[[ Line: 29 ]]
        -- upvalues: l__LocalClient__1 (copy), u11 (copy), u8 (ref)
        local l__ActiveLoadout__2 = l__LocalClient__1.ActiveLoadout;
        if u11.oldLoadout ~= l__ActiveLoadout__2 then
            if u11.oldModel then
                u11.oldModel:Destroy();
            end;
            u11.oldLoadout = l__ActiveLoadout__2;
            local v13 = u8.Deserialize(l__LocalClient__1.Loadouts[l__ActiveLoadout__2].Tree);
            local v14 = v13:GetChild("Character");
            local l__ParentModel__3 = v14.ParentModel;
            l__ParentModel__3.PrimaryPart.Anchored = true;
            l__ParentModel__3.PrimaryPart:PivotTo(CFrame.new());
            local v15 = v13:GetChild("Primary");
            if v15 then
                local l__Weld__4 = v15.Weld;
                l__Weld__4.C0 = CFrame.new(-0.3, 0, -0.5) * CFrame.Angles(1.5707963267948966, 3.141592653589793, 3.141592653589793);
                l__Weld__4.C1 = v15.ParentModel.PrimaryPart.anchor.CFrame;
                l__Weld__4.Part0 = v14.Model.RightHand;
                l__Weld__4.Part1 = v15.ParentModel.PrimaryPart;
                v15.ParentModel.Parent = l__ParentModel__3;
            end;
            local v16 = Instance.new("AnimationController");
            v16.Parent = v14.Model;
            local u17 = Instance.new("Animator");
            u17.Parent = v16;
            local u18 = Instance.new("Animation");
            u18.AnimationId = "rbxassetid://8588572507";
            l__ParentModel__3.Parent = u11.viewModel:getValue();
            pcall(task.defer, function() --[[ Line: 64 ]]
                -- upvalues: u17 (copy), u18 (copy)
                u17:LoadAnimation(u18):Play();
            end);
            u11.oldModel = l__ParentModel__3;
        end;
        if u11.oldPreview ~= u11.state.Preview then
            if u11.oldModelPreview then
                u11.oldModelPreview:Destroy();
            end;
            u11.oldPreview = u11.state.Preview;
            local v19 = u8.Deserialize(l__LocalClient__1.Loadouts[u11.state.Preview].Tree);
            local v20 = v19:GetChild("Character");
            local l__ParentModel__5 = v20.ParentModel;
            l__ParentModel__5.PrimaryPart.Anchored = true;
            l__ParentModel__5.PrimaryPart:PivotTo(CFrame.new());
            local v21 = v19:GetChild("Primary");
            if v21 then
                local l__Weld__6 = v21.Weld;
                l__Weld__6.C0 = CFrame.new(-0.3, 0, -0.5) * CFrame.Angles(1.5707963267948966, 3.141592653589793, 3.141592653589793);
                l__Weld__6.C1 = v21.ParentModel.PrimaryPart.anchor.CFrame;
                l__Weld__6.Part0 = v20.Model.RightHand;
                l__Weld__6.Part1 = v21.ParentModel.PrimaryPart;
                v21.ParentModel.Parent = l__ParentModel__5;
            end;
            local v22 = Instance.new("AnimationController");
            v22.Parent = v20.Model;
            local u23 = Instance.new("Animator");
            u23.Parent = v22;
            local u24 = Instance.new("Animation");
            u24.AnimationId = "rbxassetid://8588572507";
            l__ParentModel__5.Parent = u11.previewModel:getValue();
            pcall(task.defer, function() --[[ Line: 103 ]]
                -- upvalues: u23 (copy), u24 (copy)
                u23:LoadAnimation(u24):Play();
            end);
            u11.oldModelPreview = l__ParentModel__5;
        end;
    end;
    u11:setState({
        Preview = l__LocalClient__1.ActiveLoadout
    });
end;
function v9.willUnmount(p25) --[[ Line: 115 ]]
    p25.camera:Destroy();
end;
function v9.didUpdate(p26) --[[ Line: 119 ]]
    p26.genModels();
end;
function v9.didMount(p27) --[[ Line: 123 ]]
    p27.genModels();
end;
function v9.render(u28) --[[ Line: 127 ]]
    -- upvalues: u4 (copy), u2 (copy), u7 (copy), u3 (copy), u10 (copy), u6 (copy)
    local l__props__7 = u28.props;
    local l__LocalClient__8 = u4.LocalClient;
    local l__PopupActive__9 = l__props__7.PopupActive;
    local v29 = math.max(12, #l__LocalClient__8.Loadouts);
    local v30 = {};
    for u31 = 1, #l__LocalClient__8.Loadouts do
        local v32 = l__LocalClient__8.Loadouts[u31];
        v30["Loadout" .. tostring(u31)] = u2.createElement(u7, {
            Renaming = false,
            Order = u31,
            Ignore = l__PopupActive__9,
            Callback = function() --[[ Name: Callback, Line 139 ]]
                -- upvalues: l__LocalClient__8 (copy), u31 (copy), u3 (ref), u28 (copy)
                if l__LocalClient__8.ActiveLoadout ~= u31 then
                    u3:FireServer("SetActiveLoadout", u31);
                    l__LocalClient__8.ActiveLoadout = u31;
                    u28:setState({});
                end;
            end,
            Loadout = v32,
            Hover = function() --[[ Name: Hover, Line 147 ]]
                -- upvalues: u28 (copy), u31 (copy)
                u28:setState({
                    Preview = u31
                });
            end,
            Active = l__LocalClient__8.ActiveLoadout == u31,
            Size = UDim2.new(1, -2, 1 / v29, -2)
        });
    end;
    v30[-2] = u2.createElement("UIPadding", {
        PaddingTop = UDim.new(0, 1),
        PaddingBottom = UDim.new(0, 1)
    });
    v30[-3] = u2.createElement("UIListLayout", {
        FillDirection = Enum.FillDirection.Vertical,
        SortOrder = Enum.SortOrder.LayoutOrder,
        VerticalAlignment = Enum.VerticalAlignment.Top,
        HorizontalAlignment = Enum.HorizontalAlignment.Center,
        Padding = UDim.new(0, 2)
    });
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        AnchorPoint = Vector2.new(0.5, 0),
        Size = UDim2.fromScale(0, 0.85),
        Position = UDim2.fromScale(0.5, 0.05)
    }, {
        u2.createElement("UIAspectRatioConstraint", {
            AspectRatio = 2,
            AspectType = Enum.AspectType.ScaleWithParentSize,
            DominantAxis = Enum.DominantAxis.Height
        }),
        u2.createElement("Frame", {
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(0.5, 1),
            BackgroundColor3 = Color3.fromRGB(255, 194, 89),
            Size = UDim2.fromScale(0.3, 0.3),
            Position = UDim2.fromScale(0.75, 1)
        }, { u2.createElement("UIGradient", {
                Rotation = -90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.1, 0.5), NumberSequenceKeypoint.new(1, 1) })
            }), u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "SELECTED",
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.1),
                Position = UDim2.fromScale(0, 0.55),
                TextColor3 = Color3.fromRGB(255, 194, 89),
                FontFace = u10
            }), u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.2),
                Position = UDim2.fromScale(0, 0.65),
                Text = l__LocalClient__8.Loadouts[l__LocalClient__8.ActiveLoadout].Name,
                TextColor3 = Color3.fromRGB(255, 194, 89),
                FontFace = u10
            }) }),
        u2.createElement("ViewportFrame", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            LightDirection = Vector3.new(0, 1, 0.2),
            Position = UDim2.fromScale(0.5, 0),
            Size = UDim2.fromScale(0.5, 1),
            CurrentCamera = u28.camera,
            LightColor = Color3.fromRGB(255, 194, 89),
            Ambient = Color3.fromRGB(115, 115, 115)
        }, { u2.createElement("WorldModel", {
                [u2.Ref] = u28.viewModel
            }) }),
        u2.createElement("ViewportFrame", {
            BackgroundTransparency = 1,
            LightDirection = Vector3.new(0, 1, 0.2),
            Position = UDim2.fromScale(0.1, 0),
            Size = UDim2.fromScale(0.5, 1),
            CurrentCamera = u28.camera,
            LightColor = Color3.fromRGB(255, 255, 255),
            Ambient = Color3.fromRGB(115, 115, 115)
        }, { u2.createElement("WorldModel", {
                [u2.Ref] = u28.previewModel
            }) }),
        u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ClipsDescendants = true,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.new(0, 0, 0, 0),
            Size = UDim2.new(0.3, 0, 1, 0),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }, { u2.createElement(u6, {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(1, 1),
                Position = UDim2.fromScale(0, 0),
                CanvasSize = v29 / 12,
                Ignore = l__PopupActive__9,
                Content = v30
            }) })
    });
end;
return v9;