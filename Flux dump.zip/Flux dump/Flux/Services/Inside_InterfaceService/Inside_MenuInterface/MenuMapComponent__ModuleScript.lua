-- Services.InterfaceService.MenuInterface.MenuMapComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
game:GetService("UserInputService");
local u3 = v1("MenuInteractiveMapMarkerComponent");
local u4 = v1("MenuInteractiveMapComponent");
v1("GameShellProxyButton");
local v5 = u2.Component:extend("MenuMap");
local u6 = {
    "rbxassetid://15604514064",
    "rbxassetid://15604513794",
    "rbxassetid://15604514167",
    "rbxassetid://15604513938",
    "rbxassetid://15604513686",
    "rbxassetid://15604514259"
};
function v5.init(p7, _) --[[ Line: 21 ]]
    -- upvalues: u2 (copy)
    local v8, v9 = u2.createBinding(Vector2.new());
    p7.Position = v8;
    p7.UpdatePosition = v9;
end;
function v5.render(p10) --[[ Line: 25 ]]
    -- upvalues: u2 (copy), u3 (copy), u6 (copy), u4 (copy)
    local l__PopupActive__1 = p10.props.PopupActive;
    local v11 = { u2.createElement(u3, {
            Index = 0,
            Ignore = l__PopupActive__1,
            Position = p10.Position
        }) };
    for v12, v13 in u6 do
        v11[v12] = u2.createElement(u3, {
            Index = v12,
            Icon = v13,
            Ignore = l__PopupActive__1,
            Position = p10.Position
        });
    end;
    return u2.createFragment({
        u2.createElement(u4, {
            PopupActive = l__PopupActive__1,
            Position = p10.UpdatePosition
        }),
        u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.7,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0.5, 0.5),
            BackgroundColor3 = Color3.new(1, 1, 1),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = UDim2.new(0.3, 0, 0, 1),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }),
        u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.7,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0.5, 0.5),
            BackgroundColor3 = Color3.new(1, 1, 1),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = UDim2.new(0, 1, 0.3, 0),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }),
        u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0.5, 1),
            Position = UDim2.fromScale(0.5, 0.95),
            Size = UDim2.fromScale(0.3, 0.04),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }, { u2.createElement("UIListLayout", {
                SortOrder = Enum.SortOrder.LayoutOrder,
                FillDirection = Enum.FillDirection.Horizontal,
                VerticalAlignment = Enum.VerticalAlignment.Center,
                HorizontalAlignment = Enum.HorizontalAlignment.Center,
                Padding = UDim.new(0.1, 0)
            }), u2.createFragment(v11) }),
        Glow = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.85,
            Size = UDim2.fromScale(0.7, 0.08),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            Position = UDim2.fromScale(0.5, 1),
            AnchorPoint = Vector2.new(0.5, 1),
            BackgroundColor3 = Color3.new(1, 1, 1)
        }, {
            Gradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
            })
        })
    });
end;
return v5;