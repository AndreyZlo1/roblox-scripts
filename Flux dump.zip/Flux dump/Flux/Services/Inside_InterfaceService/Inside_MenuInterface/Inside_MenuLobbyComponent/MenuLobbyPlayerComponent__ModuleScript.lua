-- Services.InterfaceService.MenuInterface.MenuLobbyComponent.MenuLobbyPlayerComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "network");
local u4 = v1("GameShellProxyButton");
local u5 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u6 = v1("RankedIcons");
local v7 = u2.Component:extend("MenuDeploy");
function v7.init(p8, _) --[[ Line: 11 ]]
    p8:setState({
        Hovering = false
    });
end;
function v7.willUnmount(_) --[[ Line: 17 ]] end;
function v7.render(u9) --[[ Line: 21 ]]
    -- upvalues: u6 (copy), u2 (copy), u4 (copy), u3 (copy), u5 (copy)
    local l__props__1 = u9.props;
    local l__Index__2 = l__props__1.Index;
    local v10 = (l__Index__2 - 1) / 4;
    local l__LobbyMember__3 = l__props__1.LobbyMember;
    local l__Hovering__4 = u9.state.Hovering;
    local v11;
    if l__LobbyMember__3 and l__LobbyMember__3.Elo then
        v11 = u6:GetRankFromElo(l__LobbyMember__3.Elo);
    else
        v11 = nil;
    end;
    local v12 = l__Hovering__4 and Color3.fromRGB(255, 194, 89) or Color3.new(1, 1, 1);
    local l__createElement__5 = u2.createElement;
    local v13 = u4;
    local v14 = {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 1),
        Position = UDim2.fromScale(v10, 0),
        AnchorPoint = Vector2.new(v10, 0),
        SizeConstraint = Enum.SizeConstraint.RelativeYY
    };
    local v15;
    if l__LobbyMember__3 == nil then
        v15 = true;
    else
        v15 = not l__props__1.PopupActive and l__props__1.ExpandedTween;
        if v15 then
            v15 = l__props__1.ExpandedTween:Map(function(p16) --[[ Line: 38 ]]
                return p16 < 0.5;
            end);
        end;
    end;
    v14.Ignore = v15;
    v14.BackgroundColor3 = Color3.new();
    v14.Image = l__LobbyMember__3 and ("https://www.roblox.com/headshot-thumbnail/image?userId=" .. l__LobbyMember__3.UserId .. "&width=420&height=420&format=png" or "") or "";
    v14.ImageTransparency = l__Hovering__4 and 0.5 or 0;
    function v14.MouseUp() --[[ Line: 47 ]]
        -- upvalues: u3 (ref), l__Index__2 (copy)
        u3:FireServer("LobbyKick", l__Index__2);
    end;
    function v14.MouseEnter() --[[ Line: 50 ]]
        -- upvalues: u9 (copy)
        u9:setState({
            Hovering = true
        });
    end;
    function v14.MouseLeave() --[[ Line: 55 ]]
        -- upvalues: u9 (copy)
        u9:setState({
            Hovering = false
        });
    end;
    local v17 = {
        Corner = u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 1)
        })
    };
    local v18;
    if l__LobbyMember__3 then
        v18 = u2.createElement("UIStroke", {
            Thickness = 1,
            ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
            Color = v12,
            LineJoinMode = Enum.LineJoinMode.Round
        });
    else
        v18 = l__LobbyMember__3;
    end;
    local v19;
    if l__LobbyMember__3 == nil then
        v19 = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "+",
            TextScaled = true,
            Size = UDim2.fromScale(1, 1),
            TextColor3 = v12,
            FontFace = u5
        });
    else
        v19 = false;
    end;
    if l__Hovering__4 then
        l__Hovering__4 = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "http://www.roblox.com/asset/?id=264596039",
            Size = UDim2.fromScale(0.6, 0.6),
            Position = UDim2.fromScale(0.2, 0.2),
            ImageColor3 = Color3.new(0.960784, 0.364705, 0.364705)
        });
    end;
    if v11 then
        v11 = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Size = UDim2.fromScale(0.5, 0.5),
            Position = UDim2.fromScale(0.9, 0.9),
            Image = v11.Icon
        });
    end;
    v17[1], v17[2], v17[3], v17[4] = v18, v19, l__Hovering__4, v11;
    return l__createElement__5(v13, v14, v17);
end;
return v7;