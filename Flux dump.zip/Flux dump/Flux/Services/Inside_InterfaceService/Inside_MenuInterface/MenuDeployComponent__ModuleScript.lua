-- Services.InterfaceService.MenuInterface.MenuDeployComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "network");
local u3 = v1("SoundService");
local u4 = v1("RoactTween");
local v5 = u2.Component:extend("MenuDeploy");
local u6 = v1("MenuInteractiveMapComponent");
local u7 = v1("MenuArmouryPresetComponent");
Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
function v5.init(p8, _) --[[ Line: 14 ]]
    -- upvalues: u3 (copy), u4 (copy)
    u3:CreateSound("Button", nil, true, "UISounds", "PlayOpen").Destroy(10);
    p8.Transition = u4.new(0);
end;
function v5.render(p9) --[[ Line: 21 ]]
    -- upvalues: u2 (copy), u6 (copy), u7 (copy)
    return u2.createFragment({ u2.createElement(u6, {
            Deploys = true,
            Transition = p9.Transition,
            PopupActive = p9.props.PopupActive
        }), u2.createElement(u7, {
            Transition = p9.Transition,
            PopupActive = p9.props.PopupActive
        }) });
end;
return v5;