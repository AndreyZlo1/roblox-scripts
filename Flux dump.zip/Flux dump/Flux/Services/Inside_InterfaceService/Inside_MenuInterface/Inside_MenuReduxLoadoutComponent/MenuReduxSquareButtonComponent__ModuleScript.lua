-- Services.InterfaceService.MenuInterface.MenuReduxLoadoutComponent.MenuReduxSquareButtonComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "signal");
local u3 = v1("RoactTween");
local u4 = v1("GameShellProxyButton");
local v5 = u2.Component:extend("MenuReduxSquareButtonComponent");
function v5.init(p6, _) --[[ Line: 9 ]]
    -- upvalues: u3 (copy)
    p6.Hover = u3.new(0);
end;
function v5.render(p7) --[[ Line: 13 ]]
    -- upvalues: u2 (copy), u4 (copy)
    local l__props__1 = p7.props;
    local l__Hover__2 = p7.Hover;
    return u2.createElement(u4, {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        ZIndex = 2,
        SoundKit = "MainMenu",
        BackgroundColor3 = Color3.new(),
        Position = l__props__1.Position,
        Size = UDim2.fromScale(0.08, 0.08),
        AnchorPoint = Vector2.new(1, 1),
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        Ignore = l__props__1.PopupActive,
        MouseUp = function() --[[ Name: MouseUp, Line 30 ]]
            -- upvalues: l__props__1 (copy)
            l__props__1.Callback();
        end,
        MouseEnter = function() --[[ Name: MouseEnter, Line 33 ]]
            -- upvalues: l__Hover__2 (copy)
            l__Hover__2:SetGoal(1);
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 36 ]]
            -- upvalues: l__Hover__2 (copy)
            l__Hover__2:SetGoal(0);
        end
    }, {
        Image = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = l__Hover__2:Map(function(p8) --[[ Line: 44 ]]
                local v9 = 0.6 - p8 / 5;
                return UDim2.fromScale(v9, v9);
            end),
            Image = l__props__1.Image
        }),
        u2.createFragment(l__props__1.Children or {})
    });
end;
return v5;