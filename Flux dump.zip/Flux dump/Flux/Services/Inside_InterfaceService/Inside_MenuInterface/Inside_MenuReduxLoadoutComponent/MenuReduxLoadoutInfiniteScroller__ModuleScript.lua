-- Services.InterfaceService.MenuInterface.MenuReduxLoadoutComponent.MenuReduxLoadoutInfiniteScroller
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "signal");
local u4 = v1("GameShellProxyScroller");
local u5 = v1("MenuReduxLoadoutInfiniteScrollerRow");
local v6 = u2.Component:extend("MenuReduxLoadoutInfiniteScroller");
function v6.init(u7, _) --[[ Line: 9 ]]
    -- upvalues: u2 (copy), u3 (copy)
    local u8 = 0;
    local u9 = 0;
    local u10 = {};
    u7._items = {};
    u7._itemsPerRow = 0;
    u7._rowCount = 0;
    u7._scrollerRef = u2.createRef();
    function u7._scrollerCallback(p11) --[[ Line: 19 ]]
        -- upvalues: u7 (copy), u9 (ref), u8 (ref), u10 (copy)
        local v12 = 1 / math.max(6, u7._rowCount);
        if p11 then
            u9 = p11;
        end;
        local l___reRender__1 = u7._reRender;
        local v13 = math.floor((p11 or u9) * 6) + 1;
        if v13 == u8 and not l___reRender__1 then
            return;
        end;
        u7._reRender = nil;
        u8 = v13;
        local v14 = {};
        local v15 = {};
        for v16 = 1, 7 do
            local v17 = v13 + (v16 - 1);
            local v18 = false;
            for _, v19 in u10 do
                if v19.Index == v17 then
                    v18 = true;
                    break;
                end;
            end;
            if v18 then
                v14[v17] = true;
            else
                v15[v17] = true;
            end;
        end;
        local l___itemsPerRow__2 = u7._itemsPerRow;
        for v20 = 1, 7 do
            local v21 = u10[v20];
            local l__Index__3 = v21.Index;
            if not (l__Index__3 and v14[l__Index__3]) then
                l__Index__3 = nil;
                goto l1;
            end;
            if l___reRender__1 then
                local v22 = 0;
                while true do
                    if v22 == 0 then
                        v22 = -1;
                        if l__Index__3 then
                            v21.Index = l__Index__3;
                            v21.UpdatePosition(UDim2.fromScale(0, v12 * (l__Index__3 - 1)));
                            local v23 = (l__Index__3 - 1) * l___itemsPerRow__2;
                            local v24 = {};
                            for v25 = v23 + 1, v23 + l___itemsPerRow__2 do
                                local v26 = u7._items[v25];
                                if v26 then
                                    v24[#v24 + 1] = v26;
                                end;
                            end;
                            v21.Render:Fire(l__Index__3, l___itemsPerRow__2, v24, l___reRender__1);
                        else
                            l__Index__3 = next(v15);
                            if l__Index__3 then
                                v15[l__Index__3] = nil;
                                goto l0;
                            end;
                        end;
                        break;
                    else
                        break;
                    end;
                end;
            end;
        end;
    end;
    for v27 = 1, 7 do
        local v28, v29 = u2.createBinding(UDim2.fromScale(0, (v27 - 1) / 6));
        u10[v27] = {
            Render = u3.new(),
            PositionBinding = v28,
            UpdatePosition = v29
        };
    end;
    u7._virtualRows = u10;
end;
function v6.didUpdate(p30) --[[ Line: 102 ]]
    p30._reRender = true;
end;
function v6.render(p31) --[[ Line: 106 ]]
    -- upvalues: u2 (copy), u5 (copy), u4 (copy)
    local l__props__4 = p31.props;
    local l__PopupActive__5 = l__props__4.PopupActive;
    local l__HoverComponent__6 = l__props__4.HoverComponent;
    local l___scrollerRef__7 = p31._scrollerRef;
    local l__ItemsPerRow__8 = l__props__4.ItemsPerRow;
    local l__Items__9 = l__props__4.Items;
    local v32 = math.ceil(#l__Items__9 / l__ItemsPerRow__8);
    local v33 = math.max(6, v32);
    local v34 = {};
    for v35 = 1, 7 do
        local v36 = p31._virtualRows[v35];
        v34[v35] = u2.createElement(u5, {
            Position = v36.PositionBinding,
            Size = UDim2.fromScale(1, 1 / v33),
            Render = v36.Render,
            HoverComponent = l__HoverComponent__6,
            PopupActive = l__PopupActive__5,
            ScrollerRef = l___scrollerRef__7
        });
    end;
    p31._items = l__Items__9;
    p31._itemsPerRow = l__ItemsPerRow__8;
    p31._rowCount = v32;
    return u2.createElement(u4, {
        BackgroundTransparency = 1,
        RequiresFocus = true,
        NoGradient = true,
        Size = l__props__4.Size,
        Position = l__props__4.Position,
        Callback = p31._scrollerCallback,
        Ignore = l__PopupActive__5,
        CanvasSize = v33 / 6,
        Content = v34,
        Ref = l___scrollerRef__7
    });
end;
return v6;