-- Services.InterfaceService.MenuInterface.MenuReduxLoadoutComponent.MenuReduxLoadoutViewAreaComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Roact", "frc", "signal");
local l__GuiService__1 = game:GetService("GuiService");
local l__Players__2 = game:GetService("Players");
local u5 = v1("MenuLoadoutConstants");
local u6 = v1("ClientService");
local u7 = v1("BaseComponent");
local l__PlayerGui__3 = l__Players__2.LocalPlayer:WaitForChild("PlayerGui");
local l__CurrentCamera__4 = workspace.CurrentCamera;
local u8 = l__GuiService__1:GetGuiInset();
local u9 = {
    Vest = "UpperTorso",
    Belt = "LowerTorso",
    Helmet = "Head"
};
local u10 = v1("MenuReduxLoadoutViewAreaNodeComponent");
local v11 = u2.Component:extend("MenuReduxLoadoutViewAreaComponent");
function v11.init(u12, u13) --[[ Line: 26 ]]
    -- upvalues: l__PlayerGui__3 (copy), u4 (copy), u3 (copy), u5 (copy), u2 (copy), u9 (copy), l__CurrentCamera__4 (copy), u8 (copy), u6 (copy), u7 (copy)
    local l__Ref__5 = u13.Ref;
    u12._currentNodes = {};
    local u14 = Instance.new("Highlight");
    u14.FillColor = Color3.new(1, 1, 1);
    u14.FillTransparency = 0.9;
    u14.OutlineTransparency = 0.5;
    u14.Parent = l__PlayerGui__3;
    u12._highlight = u14;
    local u15 = false;
    local u16 = 0;
    function u12._changeHighlight(p17, p18) --[[ Line: 39 ]]
        -- upvalues: u14 (copy), u15 (ref)
        if p18 then
            u14.Adornee = p17;
            u15 = true;
        else
            if u14.Adornee == p17 then
                u15 = false;
            end;
        end;
    end;
    local u19 = nil;
    u12._hoverSignal = u4.new();
    function u12._changeHover(p20, p21) --[[ Line: 50 ]]
        -- upvalues: u19 (ref), u12 (copy)
        if p21 then
            u19 = p20;
            u12._hoverSignal:Fire(p20);
        else
            if u19 == p20 then
                u19 = nil;
                u12._hoverSignal:Fire(nil);
            end;
        end;
    end;
    u12._update = u13.UpdateNodes:Connect(function(p22) --[[ Line: 60 ]]
        -- upvalues: u16 (ref), u15 (ref), u3 (ref), u14 (copy), u12 (copy)
        u16 = math.lerp(u16, u15 and 1 or 0, u3(p22 * 15));
        u14.FillTransparency = math.lerp(1, 0.9, u16);
        u14.OutlineTransparency = math.lerp(1, 0.5, u16);
        if u12._updateNodes() then
            u12:setState({});
        end;
    end);
    function u12._updateNodes() --[[ Line: 71 ]]
        -- upvalues: u12 (copy), l__Ref__5 (copy), u13 (copy), u5 (ref), u2 (ref), u9 (ref), l__CurrentCamera__4 (ref), u8 (ref)
        local l___currentComponent__6 = u12._currentComponent;
        if l___currentComponent__6 then
            local v23 = l__Ref__5:getValue();
            if v23 then
                local v24 = {};
                local v25 = false;
                local l__Path__7 = u12.props.Path;
                local v26;
                if #l__Path__7 > 0 then
                    v26 = l___currentComponent__6:GetChild(unpack(l__Path__7));
                else
                    v26 = l___currentComponent__6;
                end;
                local v27 = (#l__Path__7 == 0 or #l__Path__7 <= 2 and l__Path__7[1] == "Character") and 0 or (1 / 0);
                local l___currentNodes__8 = u12._currentNodes;
                local v28 = not v26 and {} or v26:GetAttachments(1, v27);
                for _, v29 in (u13.Hide:GetValue() > 0.05 or u12._hide) and {} or v28 do
                    local l__Attachment__9 = v29.Attachment;
                    local l__SubName__10 = v29.SubName;
                    if not u5.HideSubName[l__SubName__10] then
                        local v30 = l__SubName__10:sub(1, 4) == "Rail";
                        if v30 then
                            for v31, v32 in v29.ParentComponent:GetChildren(l__SubName__10) do
                                local l__PrimaryPart__11 = v32.ParentModel.PrimaryPart;
                                if l__PrimaryPart__11 then
                                    local v33 = l__PrimaryPart__11:FindFirstChild("start");
                                    if v33 then
                                        v24[v33] = true;
                                        if not l___currentNodes__8[v33] then
                                            local l__Name__12 = v32.Name;
                                            local v34, v35 = v32:GetMenuConfig();
                                            if v34 then
                                                l__Name__12 = v35.Name;
                                            end;
                                            local v36, v37 = u2.createBinding(UDim2.new());
                                            local v38, v39 = u2.createBinding(true);
                                            l___currentNodes__8[v33] = {
                                                IsRailAttachment = true,
                                                Component = v32,
                                                Attachment = {
                                                    Attachment = v33,
                                                    ParentComponent = v29.ParentComponent,
                                                    Path = v32:GetFullName(),
                                                    SubName = tostring(v31),
                                                    Name = l__Name__12
                                                },
                                                Position = v36,
                                                UpdatePosition = v37,
                                                Visible = v38,
                                                UpdateVisible = v39,
                                                Model = v32.ParentModel
                                            };
                                            v25 = true;
                                        end;
                                    end;
                                end;
                            end;
                        end;
                        v24[l__Attachment__9] = true;
                        if not l___currentNodes__8[l__Attachment__9] then
                            local v40;
                            if v30 then
                                v40 = l__Attachment__9.Parent[l__Attachment__9.Name:sub(1, -7) .. "_finish"];
                            else
                                v40 = nil;
                            end;
                            local v41, v42 = u2.createBinding(UDim2.new());
                            local v43, v44 = u2.createBinding(true);
                            l___currentNodes__8[l__Attachment__9] = {
                                Attachment = v29,
                                FinishAttachment = v40,
                                Position = v41,
                                UpdatePosition = v42,
                                Visible = v43,
                                UpdateVisible = v44,
                                IsRail = v30
                            };
                            v25 = true;
                        end;
                    end;
                end;
                local v45 = nil;
                if l__Path__7[1] == "Character" then
                    local v46 = u9[l__Path__7[3]];
                    if v46 then
                        local v47 = l___currentComponent__6:GetChild("Character");
                        if v47 then
                            v47 = v47.Model:FindFirstChild(v46);
                        end;
                        if v47 then
                            v45 = v47.Position;
                        end;
                    end;
                end;
                local l__AbsolutePosition__13 = v23.AbsolutePosition;
                for v48, v49 in l___currentNodes__8 do
                    if v24[v48] then
                        local l__WorldPosition__14 = v48.WorldPosition;
                        if v49.IsRail then
                            if v49.FinishAttachment then
                                l__WorldPosition__14 = l__WorldPosition__14:Lerp(v49.FinishAttachment.WorldPosition, 0.5);
                            end;
                        elseif v49.IsRailAttachment and v49.Model then
                            local v50 = nil;
                            for _, v51 in u5.RailConsolidate do
                                v50 = v49.Model:FindFirstChild(v51);
                                if v50 then
                                    break;
                                end;
                            end;
                            if v50 then
                                v50 = v50:GetChildren()[1];
                            end;
                            if v50 and (v50:IsA("Model") and v50.PrimaryPart) then
                                l__WorldPosition__14 = v50.PrimaryPart.Position;
                            else
                                l__WorldPosition__14 = v49.Model.PrimaryPart.Position;
                            end;
                        end;
                        local v52 = l__CurrentCamera__4:WorldToViewportPoint(l__WorldPosition__14);
                        v49.UpdatePosition(UDim2.fromOffset(v52.X - l__AbsolutePosition__13.X, v52.Y - l__AbsolutePosition__13.Y - u8.Y));
                        if v45 then
                            local v53 = (l__WorldPosition__14 - v45):Dot(l__CurrentCamera__4.CFrame.LookVector) <= 0;
                            v49.UpdateVisible(v53);
                        end;
                    else
                        l___currentNodes__8[v48] = nil;
                        v25 = true;
                    end;
                end;
                return v25;
            end;
        end;
    end;
    local l__LocalClient__15 = u6.LocalClient;
    u12._changeModel = u13.ChangeModel:Connect(function(p54, p55) --[[ Line: 252 ]]
        -- upvalues: u7 (ref), l__LocalClient__15 (copy), u12 (copy), u13 (copy)
        local v56;
        if p54 then
            v56 = false;
        else
            p54 = "Character";
            v56 = true;
        end;
        local v57 = u7.Deserialize(l__LocalClient__15.Loadouts[l__LocalClient__15.ActiveLoadout].Tree);
        if v57 then
            local v58 = v57:GetChild(p54) or {
                Model = Instance.new("Model"),
                ParentModel = Instance.new("Model")
            };
            if u12._currentComponent then
                u12._currentComponent:Destroy();
            end;
            u12._currentComponent = v57;
            local l__ParentModel__16 = v58.ParentModel;
            local l__PrimaryPart__17 = l__ParentModel__16.PrimaryPart;
            if l__PrimaryPart__17 then
                l__PrimaryPart__17.Anchored = true;
            end;
            local v59 = {};
            if v56 then
                local v60 = v57:GetChild("Primary");
                if v60 then
                    local l__Weld__18 = v60.Weld;
                    l__Weld__18.C0 = CFrame.new(-0.3, 0, -0.5) * CFrame.Angles(1.5707963267948966, 3.141592653589793, 3.141592653589793);
                    l__Weld__18.C1 = v60.ParentModel.PrimaryPart.anchor.CFrame;
                    l__Weld__18.Part0 = v58.Model.RightHand;
                    l__Weld__18.Part1 = v60.ParentModel.PrimaryPart;
                    v60.ParentModel.Parent = l__ParentModel__16;
                end;
            else
                v59 = { p54 };
            end;
            if p54 == "Character" then
                l__ParentModel__16:PivotTo(CFrame.new());
                l__ParentModel__16.Parent = workspace;
                local v61 = Instance.new("AnimationController");
                v61.Parent = v58.Model;
                local u62 = Instance.new("Animator");
                u62.Parent = v61;
                local u63 = Instance.new("Animation");
                u63.AnimationId = v56 and "rbxassetid://8588579661" or "rbxassetid://107633364537656";
                task.defer(function() --[[ Line: 312 ]]
                    -- upvalues: u62 (copy), u63 (copy), l__ParentModel__16 (copy), u13 (ref)
                    u62:LoadAnimation(u63):Play(0.5);
                    l__ParentModel__16:PivotTo(u13.Origin * CFrame.Angles(0, 3.141592653589793, 0));
                end);
            else
                l__ParentModel__16:PivotTo(u13.Origin * CFrame.Angles(0, 3.141592653589793, 0));
                l__ParentModel__16.Parent = workspace;
            end;
            u13.SetComponent(v57, l__ParentModel__16);
            if not p55 then
                u13.SetPath(v59);
            end;
        else
            v57:Destroy();
        end;
    end);
    u13.ChangeModel:Fire();
end;
function v11.willUnmount(p64) --[[ Line: 330 ]]
    p64._changeModel:Disconnect();
    p64._update:Disconnect();
    p64._highlight:Destroy();
    if p64._currentComponent then
        p64._currentComponent:Destroy();
    end;
end;
function v11.render(p65) --[[ Line: 340 ]]
    -- upvalues: u2 (copy), u10 (copy)
    local l__props__19 = p65.props;
    local l__PopupActive__20 = l__props__19.PopupActive;
    local l__UpdateNodes__21 = l__props__19.UpdateNodes;
    p65._hide = l__props__19.HideBoolean;
    p65._updateNodes();
    local v66 = #l__props__19.Path > 0 and {} or nil;
    local v67 = {};
    for v68, v69 in p65._currentNodes do
        v67[v68] = u2.createElement(u10, {
            ChangeModel = l__props__19.ChangeModel,
            ChangeHighlight = p65._changeHighlight,
            ChangeHover = p65._changeHover,
            BigButtons = v66,
            WorldAttachment = v68,
            HoverSignal = p65._hoverSignal,
            UpdateNodes = l__UpdateNodes__21,
            MoveComponent = l__props__19.MoveComponent,
            PopupActive = l__PopupActive__20,
            SetAdditionalPath = l__props__19.SetAdditionalPath,
            SetPath = l__props__19.SetPath,
            Path = l__props__19.Path,
            FullPath = l__props__19.FullPath,
            Ref = l__props__19.Ref,
            Node = v69
        });
    end;
    local v70;
    if v66 then
        v70 = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Position = UDim2.fromScale(-0.125, 0.1),
            Size = UDim2.fromScale(0.7, 0.9),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }, v66);
    else
        v70 = nil;
    end;
    return u2.createElement("Frame", {
        Size = l__props__19.Size,
        Position = l__props__19.Position,
        AnchorPoint = Vector2.new(0.5, 0),
        BackgroundTransparency = 1,
        [u2.Ref] = l__props__19.Ref
    }, { u2.createFragment(v67), v70 });
end;
return v11;