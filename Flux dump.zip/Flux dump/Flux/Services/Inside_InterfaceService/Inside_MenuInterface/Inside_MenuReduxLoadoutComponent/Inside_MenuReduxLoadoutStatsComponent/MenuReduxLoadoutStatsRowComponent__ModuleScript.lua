-- Services.InterfaceService.MenuInterface.MenuReduxLoadoutComponent.MenuReduxLoadoutStatsComponent.MenuReduxLoadoutStatsRowComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "signal");
v1("RoactTween");
local u3 = v1("GameShellProxyGlobals");
local v4 = u2.Component:extend("MenuReduxLoadoutStatsRowComponent");
function v4.init(_, _) --[[ Line: 21 ]] end;
function v4.render(p5) --[[ Line: 25 ]]
    -- upvalues: u3 (copy), u2 (copy)
    local l__props__1 = p5.props;
    local l__Stat__2 = l__props__1.Stat;
    local l__Data__3 = l__props__1.Data;
    local v6 = {};
    if typeof(l__Data__3) ~= "string" then
        local v7 = l__Data__3[1];
        local v8 = l__Data__3[2];
        local v9 = l__Data__3[3] or 0;
        local v10 = l__Data__3[4] or 0;
        local v11 = v9 ~= v10;
        local v12 = nil;
        local v13 = "<font color=\"#ffffff\">";
        local v14 = v11 and "Ⓐ " or "";
        local v15 = v10 * (l__Data__3[5] or 1);
        if type(v15) ~= "string" then
            if math.round(v15) == v15 then
                v15 = tostring(v15);
            else
                v15 = string.format("%.2f", v15);
            end;
        end;
        local v16 = v13 .. v14 .. v15 .. "</font>";
        local v17;
        if v11 then
            if v10 >= v9 or not v8 then
                if v9 < v10 then
                    v8 = not v8;
                else
                    v8 = false;
                end;
            end;
            v12 = v8 and u3.Colors.Green or u3.Colors.Red;
            local v18 = "<font color=\"#";
            local v19 = v12:ToHex();
            local v20 = "\"> Ⓑ ";
            local v21 = v9 * (l__Data__3[5] or 1);
            if type(v21) ~= "string" then
                if math.round(v21) == v21 then
                    v21 = tostring(v21);
                else
                    v21 = string.format("%.2f", v21);
                end;
            end;
            v17 = v18 .. v19 .. v20 .. v21 .. "</font>";
            v16 = v16 .. " > ";
        else
            v17 = "";
        end;
        local v22 = (v9 - l__Stat__2[3]) / (l__Stat__2[4] - l__Stat__2[3]);
        local v23 = math.abs(v9 - v10) / (l__Stat__2[4] - l__Stat__2[3]);
        if v10 < v9 then
            v22 = v22 - v23;
        end;
        local v24 = math.clamp((v9 - l__Stat__2[3]) / (l__Stat__2[4] - l__Stat__2[3]), 0, 1);
        local l__createElement__4 = u2.createElement;
        local v25 = "Frame";
        local v26 = {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.5,
            AnchorPoint = Vector2.new(0, 1),
            BackgroundColor3 = Color3.fromRGB(139, 139, 139),
            Position = UDim2.fromScale(0, 0.95),
            Size = UDim2.new(1, 0, 0, 1)
        };
        local v27 = {};
        local l__createElement__5 = u2.createElement;
        local v28 = "Frame";
        local v29 = {
            BackgroundTransparency = 1,
            ClipsDescendants = true,
            Size = UDim2.fromScale(1, 1)
        };
        local v30 = {
            Percent = u2.createElement("Frame", {
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 0),
                BackgroundColor3 = Color3.new(1, 1, 1),
                Position = UDim2.fromScale(0, 0),
                Size = UDim2.fromScale(v24, 1)
            })
        };
        if v11 then
            v11 = u2.createElement("Frame", {
                BorderSizePixel = 0,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0),
                BackgroundColor3 = v12,
                Position = UDim2.fromScale(v22, 0),
                Size = UDim2.fromScale(v23, 1)
            });
        end;
        v30.Different = v11;
        v27.Clip = l__createElement__5(v28, v29, v30);
        v27.Block = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 3,
            AnchorPoint = Vector2.new(0.5, 0.5),
            BackgroundColor3 = Color3.new(1, 1, 1),
            Position = UDim2.fromScale(v24, 0.5),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            Size = UDim2.fromScale(3, 3)
        });
        v6.Bar = l__createElement__4(v25, v26, v27);
        l__Data__3 = v16 .. v17 .. " " .. v7;
    end;
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Position = l__props__1.Position,
        Size = UDim2.fromScale(1, 0.143)
    }, {
        Title = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            RichText = true,
            TextScaled = true,
            FontFace = Font.new("rbxassetid://12187375422"),
            Position = UDim2.fromScale(0, 0.2),
            Size = UDim2.fromScale(1, 0.6),
            Text = l__Stat__2[2]:upper(),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = Enum.TextXAlignment.Left
        }),
        Value = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            RichText = true,
            TextScaled = true,
            AnchorPoint = Vector2.new(1, 0),
            FontFace = Font.new("rbxassetid://12187375422"),
            Position = UDim2.fromScale(1, 0.2),
            Size = UDim2.fromScale(1, 0.6),
            Text = l__Data__3,
            TextColor3 = Color3.fromRGB(139, 139, 139),
            TextXAlignment = Enum.TextXAlignment.Right
        }),
        u2.createFragment(v6)
    });
end;
return v4;