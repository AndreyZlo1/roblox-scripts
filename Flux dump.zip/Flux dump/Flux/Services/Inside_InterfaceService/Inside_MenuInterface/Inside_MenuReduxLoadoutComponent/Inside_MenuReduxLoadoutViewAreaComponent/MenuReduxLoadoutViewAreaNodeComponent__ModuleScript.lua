-- Services.InterfaceService.MenuInterface.MenuReduxLoadoutComponent.MenuReduxLoadoutViewAreaComponent.MenuReduxLoadoutViewAreaNodeComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "Enum");
local l__UserInputService__1 = game:GetService("UserInputService");
local l__GuiService__2 = game:GetService("GuiService");
local l__RunService__3 = game:GetService("RunService");
local u4 = v1("GameShellProxyService");
v1("PlaceService");
local u5 = v1("InputService");
local u6 = v1("GameShellProxyGlobals");
local u7 = v1("MenuLoadoutConstants");
local u8 = v1("RoactTween");
local u9 = l__GuiService__2:GetGuiInset();
local u10 = {
    Primary = {
        Left = true,
        Position = Vector2.new(0.2, 0.35),
        Size = Vector2.new(0.4, 0.2),
        Offset = CFrame.new(0, 0, -3) * CFrame.Angles(0, -1.5707963267948966, 0)
    },
    Secondary = {
        Left = true,
        Position = Vector2.new(0.2, 0.6),
        Size = Vector2.new(0.3, 0.2),
        Offset = CFrame.new(0, 0, -2.5) * CFrame.Angles(0, -1.5707963267948966, 0)
    },
    Character = {
        Position = Vector2.new(0.8, 0.35),
        Offset = CFrame.new(0, 0, -15) * CFrame.Angles(0, 3.141592653589793, 0),
        Size = Vector2.new(0.3, 0.3)
    },
    Melee = {
        Position = Vector2.new(0.8, 0.65),
        Offset = CFrame.new(0, 0, -2.5) * CFrame.Angles(0, -1.5707963267948966, 0),
        Size = Vector2.new(0.3, 0.2)
    },
    Helmet = {
        Left = true,
        AnchorPoint = Vector2.new(0.5, 0),
        Position = Vector2.new(0.5, 0),
        Offset = CFrame.new(0, 0, -4) * CFrame.Angles(0, 3.141592653589793, 0),
        Size = Vector2.new(0.32, 0.32),
        SizeConstraint = u3.SizeConstraint.RelativeXX
    },
    Earwear = {
        AnchorPoint = Vector2.new(0, 0),
        Position = Vector2.new(0, 0.132),
        Offset = CFrame.new(0, 0, -4) * CFrame.Angles(0, 3.141592653589793, 0),
        Size = Vector2.new(0.32, 0.15),
        SizeConstraint = u3.SizeConstraint.RelativeXX
    },
    Facewear = {
        Left = true,
        AnchorPoint = Vector2.new(0, 0),
        Position = Vector2.new(0.68, 0.132),
        Offset = CFrame.new(0, 0, -4) * CFrame.Angles(0, 3.141592653589793, 0),
        Size = Vector2.new(0.32, 0.15),
        SizeConstraint = u3.SizeConstraint.RelativeXX
    },
    Eyewear = {
        Left = true,
        AnchorPoint = Vector2.new(0, 0),
        Position = Vector2.new(0.68, 0),
        Offset = CFrame.new(0, 0, -4) * CFrame.Angles(0, 3.141592653589793, 0),
        Size = Vector2.new(0.32, 0.15),
        SizeConstraint = u3.SizeConstraint.RelativeXX
    },
    Backpack = {
        AnchorPoint = Vector2.new(0, 0),
        Position = Vector2.new(0, 0.263),
        Offset = CFrame.new(0, 0, -4) * CFrame.Angles(0, 0, 0),
        Size = Vector2.new(0.32, 0.32),
        SizeConstraint = u3.SizeConstraint.RelativeXX
    },
    Wrist = {
        Left = true,
        AnchorPoint = Vector2.new(1, 0),
        Position = Vector2.new(1, 0.662),
        Offset = CFrame.new(0, 0, -4) * CFrame.Angles(0, 3.141592653589793, 0),
        Size = Vector2.new(0.32, 0.15),
        SizeConstraint = u3.SizeConstraint.RelativeXX
    },
    Belt = {
        Left = true,
        AnchorPoint = Vector2.new(0.5, 0),
        Position = Vector2.new(0.5, 0.528),
        Offset = CFrame.new(0, 0, -4) * CFrame.Angles(0, 3.141592653589793, 0),
        Size = Vector2.new(0.32, 0.15),
        SizeConstraint = u3.SizeConstraint.RelativeXX
    },
    Vest = {
        Left = true,
        AnchorPoint = Vector2.new(1, 0),
        Position = Vector2.new(1, 0.263),
        Offset = CFrame.new(0, 0, -5) * CFrame.Angles(0, 3.141592653589793, 0),
        Size = Vector2.new(0.32, 0.32),
        SizeConstraint = u3.SizeConstraint.RelativeXX
    },
    Shirt = {
        Left = true,
        AnchorPoint = Vector2.new(0.5, 0),
        Position = Vector2.new(0.5, 0.263),
        Offset = CFrame.new(0, 0, -4) * CFrame.Angles(0, 3.141592653589793, 0),
        Size = Vector2.new(0.32, 0.32),
        SizeConstraint = u3.SizeConstraint.RelativeXX
    },
    Pants = {
        Left = true,
        AnchorPoint = Vector2.new(0.5, 0),
        Position = Vector2.new(0.5, 0.662),
        Offset = CFrame.new(0, 0, -4) * CFrame.Angles(0, 3.141592653589793, 0),
        Size = Vector2.new(0.32, 0.32),
        SizeConstraint = u3.SizeConstraint.RelativeXX
    },
    RightBoot = {
        Redirect = "Boots",
        Left = true,
        AnchorPoint = Vector2.new(0, 1),
        Position = Vector2.new(0.68, 0.911),
        Offset = CFrame.new(0, 0, -4) * CFrame.Angles(0, 3.141592653589793, 0),
        Size = Vector2.new(0.32, 0.15),
        SizeConstraint = u3.SizeConstraint.RelativeXX
    },
    LeftGlove = {
        Redirect = "Gloves",
        Left = true,
        AnchorPoint = Vector2.new(0, 0),
        Position = Vector2.new(0.68, 0.528),
        Offset = CFrame.new(0, 0, -4) * CFrame.Angles(0, 3.141592653589793, 0),
        Size = Vector2.new(0.32, 0.15),
        SizeConstraint = u3.SizeConstraint.RelativeXX
    },
    Appearance = {
        AnchorPoint = Vector2.new(0, 0),
        Position = Vector2.new(0, 0),
        Offset = CFrame.new(0, 0, -4) * CFrame.Angles(0, 3.141592653589793, 0),
        Size = Vector2.new(0.32, 0.15),
        SizeConstraint = u3.SizeConstraint.RelativeXX
    },
    LeftBoot = {
        Hidden = true
    },
    RightGlove = {
        Hidden = true
    },
    Boots = {
        Hidden = true
    },
    Gloves = {
        Hidden = true
    }
};
local u15 = { function(p11, p12) --[[ Line: 168 ]]
        return p11.Position, p12.Position;
    end, function(p13) --[[ Line: 171 ]]
        return p13:PointToWorldSpace(Vector3.new(0.05, 0, 0)), p13:PointToWorldSpace(Vector3.new(-0.05, 0, 0));
    end, function(_, p14) --[[ Line: 174 ]]
        return p14:PointToWorldSpace(Vector3.new(0.05, 0, 0)), p14:PointToWorldSpace(Vector3.new(-0.05, 0, 0));
    end };
local l__CurrentCamera__4 = workspace.CurrentCamera;
local u16 = v1("GameShellProxyButton");
local u17 = v1("MenuReduxLoadoutInfiniteScrollerCell");
local v18 = u2.PureComponent:extend("MenuReduxLoadoutViewAreaNodeComponent");
function v18._getLinePosition(p19, p20, p21) --[[ Line: 192 ]]
    -- upvalues: u6 (copy)
    local v22 = p19._ref:getValue();
    if v22 then
        local v23 = p19._buttonRef:getValue();
        if v23 then
            local l__AbsolutePosition__5 = v23.AbsolutePosition;
            local l__AbsoluteSize__6 = v23.AbsoluteSize;
            local v24 = l__AbsolutePosition__5 - v22.AbsolutePosition;
            return Vector2.new(v24.X + l__AbsoluteSize__6.X * (p20.Left and 1 or 0), v24.Y + l__AbsoluteSize__6.Y - u6.Sizes.LineThickness / 2), Vector2.new(p21.X.Offset, p21.Y.Offset);
        end;
    end;
end;
function v18._startAttachmentMove(u25, u26, p27) --[[ Line: 214 ]]
    -- upvalues: l__RunService__3 (copy), u5 (copy), l__UserInputService__1 (copy), u3 (copy), l__CurrentCamera__4 (copy)
    if u25._moveLoop then
    else
        local v28 = p27.Path[#p27.Path - 1];
        local l__PrimaryPart__7 = p27.ParentComponent.ParentModel.PrimaryPart;
        if l__PrimaryPart__7 then
            local v29 = v28:lower();
            local u30 = l__PrimaryPart__7:FindFirstChild(v29 .. "_start");
            local u31 = l__PrimaryPart__7:FindFirstChild(v29 .. "_finish");
            if u30 and u31 then
                u25._updateHand("rbxassetid://136707287194651");
                local l__Magnitude__8 = (u30.WorldPosition - u31.WorldPosition).Magnitude;
                local u32 = math.max(p27.ParentComponent.File and (p27.ParentComponent.File.RailSnap and p27.ParentComponent.File.RailSnap[v28]) or 0, 0.001);
                local u33 = nil;
                u25._moveLoop = l__RunService__3.Heartbeat:Connect(function(_) --[[ Line: 238 ]]
                    -- upvalues: u5 (ref), l__UserInputService__1 (ref), u3 (ref), u25 (copy), l__CurrentCamera__4 (ref), u30 (copy), u31 (copy), u33 (ref), u26 (copy), u32 (copy), l__Magnitude__8 (copy)
                    if u5.Gamepad then
                        if not l__UserInputService__1:IsGamepadButtonDown(u5.Gamepad, u3.KeyCode.ButtonA) then
                            u25:_endAttachmentMove();
                            return;
                        end;
                    elseif not l__UserInputService__1:IsMouseButtonPressed(u3.UserInputType.MouseButton1) then
                        u25:_endAttachmentMove();
                        return;
                    end;
                    local l__X__9 = l__CurrentCamera__4:WorldToViewportPoint(u30.WorldPosition).X;
                    local l__X__10 = l__CurrentCamera__4:WorldToViewportPoint(u31.WorldPosition).X;
                    local v34 = ((u5.VirtualCursorPosition or l__UserInputService__1:GetMouseLocation()).X - l__X__9) / (l__X__10 - l__X__9);
                    if not u33 then
                        u33 = u26.MetaData.Lerp - v34;
                    end;
                    local v35 = v34 + u33;
                    local v36 = 1 / (u32 / l__Magnitude__8 or 1);
                    local v37 = math.floor(v35 * v36 + 0.5) / v36;
                    u26:EditMetaData({
                        Lerp = math.clamp(v37, 0, 1)
                    });
                end);
            end;
        end;
    end;
end;
function v18._endAttachmentMove(p38) --[[ Line: 263 ]]
    p38._updateHand("rbxassetid://84186556623247");
    if p38._moveLoop and p38._moveLoop.Connected then
        p38._moveLoop:Disconnect();
        p38._moveLoop = nil;
        p38.MoveComponent(p38.Node.Component);
    end;
end;
function v18.init(u39, u40) --[[ Line: 274 ]]
    -- upvalues: u8 (copy), u3 (copy), u2 (copy), u15 (copy), u9 (copy), l__CurrentCamera__4 (copy), u6 (copy)
    u39.Open = u8.new(0, TweenInfo.new(0.6, u3.EasingStyle.Exponential, u3.EasingDirection.Out, 0, false, 0));
    u39.Open:SetGoal(1);
    u39.Blink = u8.new(0, TweenInfo.new(1, u3.EasingStyle.Exponential, u3.EasingDirection.Out, 0, false, 0));
    u39.Faded = u8.new(0);
    local u41 = u8.new(0);
    u39.Node = u40.Node;
    u39.MoveComponent = u40.MoveComponent;
    u39.Hover = u41;
    u39._ref = u40.Ref;
    u39._buttonRef = u2.createRef();
    u39._path = table.concat(u40.Node.Attachment.Path, ",");
    local v42, v43 = u2.createBinding("rbxassetid://84186556623247");
    u39._handTexture = v42;
    u39._updateHand = v43;
    function u39._changeHover(p44) --[[ Line: 292 ]]
        -- upvalues: u40 (copy)
        u40.ChangeHover(u40.WorldAttachment, p44);
    end;
    u39._hoverSignal = u40.HoverSignal:Connect(function(p45) --[[ Line: 295 ]]
        -- upvalues: u39 (copy), u40 (copy)
        u39.Faded:SetGoal(p45 and p45 ~= u40.WorldAttachment and 1 or 0);
    end);
    local l__Node__11 = u40.Node;
    if l__Node__11.IsRail then
        local l__Attachment__12 = l__Node__11.Attachment.Attachment;
        local l__FinishAttachment__13 = l__Node__11.FinishAttachment;
        if l__Attachment__12 and l__FinishAttachment__13 then
            local u46 = {};
            for v47, v48 in u15 do
                local v49, v50 = u2.createBinding({
                    Rotation = 0,
                    Size = UDim2.fromScale(),
                    Position = UDim2.fromScale()
                });
                u46[v47] = {
                    Bind = v49,
                    Update = v50,
                    Transform = v48
                };
            end;
            u39._segments = u46;
            local v51, v52 = u2.createBinding(1);
            u39._segmentTransparency = v51;
            u39._updateTransparency = v52;
            u39._update = u40.UpdateNodes:Connect(function() --[[ Line: 322 ]]
                -- upvalues: u39 (copy), u41 (copy), u9 (ref), l__Attachment__12 (copy), l__FinishAttachment__13 (copy), l__CurrentCamera__4 (ref), u46 (copy), u6 (ref)
                local v53 = u39._ref:getValue();
                if v53 then
                    local v54 = u41:GetValue();
                    local v55 = u39._selected and 1 or v54;
                    if v55 < 0.05 then
                        u39._updateTransparency(1);
                    else
                        local l__AbsolutePosition__14 = v53.AbsolutePosition;
                        local v56 = Vector3.new(l__AbsolutePosition__14.X, l__AbsolutePosition__14.Y + u9.Y, 0);
                        local l__WorldCFrame__15 = l__Attachment__12.WorldCFrame;
                        local l__WorldCFrame__16 = l__FinishAttachment__13.WorldCFrame;
                        local v57 = (l__CurrentCamera__4.CFrame.Position - l__WorldCFrame__15.Position):Dot(l__WorldCFrame__15.UpVector) > 0 and 0 or 0.5;
                        u39._updateTransparency((math.lerp(1, v57, v55)));
                        for _, v58 in u46 do
                            local v59, v60 = v58.Transform(l__WorldCFrame__15, l__WorldCFrame__16);
                            local v61 = l__CurrentCamera__4:WorldToViewportPoint(v59) - v56;
                            local v62 = l__CurrentCamera__4:WorldToViewportPoint(v60) - v56;
                            local v63 = (v61 + v62) / 2;
                            local v64 = v61 - v62;
                            local l__Update__17 = v58.Update;
                            local v65 = {
                                Size = UDim2.fromOffset((v61 - v62).Magnitude * v55, (math.ceil(u6.Sizes.LineThickness / 4))),
                                Position = UDim2.fromOffset(v63.X, v63.Y)
                            };
                            local v66 = math.atan2(v64.Y, v64.X);
                            v65.Rotation = math.deg(v66);
                            l__Update__17(v65);
                        end;
                    end;
                end;
            end);
        end;
    end;
end;
function v18.willUnmount(p67) --[[ Line: 369 ]]
    if p67._moveLoop then
        p67._moveLoop:Disconnect();
    end;
    if p67._update then
        p67._update:Disconnect();
    end;
    p67._hoverSignal:Disconnect();
end;
function v18.render(u68) --[[ Line: 379 ]]
    -- upvalues: u7 (copy), u10 (copy), u2 (copy), u6 (copy), u16 (copy), u3 (copy), u17 (copy), u4 (copy)
    local l__props__18 = u68.props;
    local l__Open__19 = u68.Open;
    local l__Hover__20 = u68.Hover;
    local l__Faded__21 = u68.Faded;
    local l__Blink__22 = u68.Blink;
    local l__PopupActive__23 = l__props__18.PopupActive;
    local l__Node__24 = l__props__18.Node;
    local l__Visible__25 = l__Node__24.Visible;
    local l__Attachment__26 = l__Node__24.Attachment;
    local l__IsRail__27 = l__Node__24.IsRail;
    local l__IsRailAttachment__28 = l__Node__24.IsRailAttachment;
    local u69 = u68._path == l__props__18.FullPath;
    if u69 then
        l__Blink__22:SetValue(0);
        l__Blink__22:SetGoal(1);
    end;
    u68._selected = u69;
    local l__SubName__29 = l__Attachment__26.SubName;
    if u7.SubIndexDisplayNames[l__SubName__29] then
        l__SubName__29 = u7.SubIndexDisplayNames[l__SubName__29];
    end;
    if l__Attachment__26.Name then
        l__SubName__29 = l__Attachment__26.Name;
    end;
    local u70 = u10[l__Attachment__26.SubName];
    if not u70 then
        local v71 = {};
        local v72 = {};
        u69 = u69;
        local u73;
        if u69 then
            u73 = u6.Colors.Selected;
        end;
        local u74 = math.ceil(u6.Sizes.LineThickness / 2);
        if u7.PinSubName[l__Attachment__26.SubName] then
            local v75 = l__Attachment__26.ParentComponent:GetChild(l__Attachment__26.SubName);
            local v76 = v75 and tonumber(v75.Name:sub(5)) or 0;
            if v76 > 0 then
                u73 = u6.PinColor[v76];
            end;
            v72.Number = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                AnchorPoint = Vector2.new(0.5, 0.5),
                FontFace = Font.new("rbxassetid://12187375422", u69 and u3.FontWeight.Bold or u3.FontWeight.Regular, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0.5, 0.5),
                Size = UDim2.new(50, 0, 0, u6.Sizes.TagTextSize * (u69 and 1.25 or 1)),
                Text = v76,
                TextTransparency = l__Hover__20:Map(function(p77) --[[ Line: 582 ]]
                    return p77;
                end),
                TextColor3 = u73 or u6.Colors.Idle,
                TextXAlignment = u3.TextXAlignment.Center
            });
        elseif l__IsRail__27 then
            if not u69 then
                v72.Verticle = u2.createElement("Frame", {
                    BackgroundTransparency = 0.5,
                    BorderSizePixel = 0,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    BackgroundColor3 = u73 or u6.Colors.Hover,
                    Position = UDim2.fromScale(0.5, 0.5),
                    Size = l__Hover__20:Map(function(p78) --[[ Line: 597 ]]
                        -- upvalues: u74 (copy)
                        return UDim2.new(0, math.ceil(u74 / 2), (1 - p78) * 0.3, 0);
                    end)
                });
                v72.Horizontal = u2.createElement("Frame", {
                    BackgroundTransparency = 0.5,
                    BorderSizePixel = 0,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    BackgroundColor3 = u73 or u6.Colors.Hover,
                    Position = UDim2.fromScale(0.5, 0.5),
                    Size = l__Hover__20:Map(function(p79) --[[ Line: 607 ]]
                        -- upvalues: u74 (copy)
                        return UDim2.new((1 - p79) * 0.3, 0, 0, (math.ceil(u74 / 2)));
                    end)
                });
            end;
            local l___segments__30 = u68._segments;
            if l___segments__30 then
                for v80, v81 in l___segments__30 do
                    local l__Bind__31 = v81.Bind;
                    v71["Line" .. v80] = u2.createElement("Frame", {
                        BorderSizePixel = 0,
                        Position = l__Bind__31:map(function(p82) --[[ Line: 618 ]]
                            return p82.Position;
                        end),
                        Size = l__Bind__31:map(function(p83) --[[ Line: 621 ]]
                            return p83.Size;
                        end),
                        Rotation = l__Bind__31:map(function(p84) --[[ Line: 624 ]]
                            return p84.Rotation;
                        end),
                        BackgroundColor3 = l__Hover__20:Map(function(p85) --[[ Line: 627 ]]
                            -- upvalues: u73 (ref), u6 (ref)
                            return u73 or u6.Colors.Idle:Lerp(u6.Colors.Hover, p85);
                        end),
                        BackgroundTransparency = u68._segmentTransparency,
                        AnchorPoint = Vector2.new(0.5, 0.5)
                    });
                end;
            end;
        elseif l__IsRailAttachment__28 then
            v72.Hand = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Image = u68._handTexture,
                ImageColor3 = l__Hover__20:Map(function(p86) --[[ Line: 641 ]]
                    -- upvalues: u73 (ref), u6 (ref)
                    return u73 or u6.Colors.Idle:Lerp(u6.Colors.Hover, p86);
                end),
                ImageTransparency = l__Hover__20:Map(function(p87) --[[ Line: 644 ]]
                    return math.lerp(0.5, 0, p87);
                end),
                Position = UDim2.fromScale(0.5, 0.48),
                ResampleMode = u3.ResamplerMode.Pixelated,
                Size = u69 and UDim2.fromScale(0.25, 0.25) or l__Faded__21:Map(function(p88) --[[ Line: 649 ]]
                    return UDim2.fromScale(0.25 - p88 / 10, 0.25 - p88 / 10);
                end)
            });
        else
            v72.Dot = u2.createElement("Frame", {
                AnchorPoint = Vector2.new(0.5, 0.5),
                BackgroundColor3 = u73 or u6.Colors.Hover,
                BackgroundTransparency = u69 and 0 or l__Faded__21:Map(function(p89) --[[ Line: 657 ]]
                    return p89 / 2;
                end),
                Position = UDim2.fromScale(0.5, 0.5),
                Size = u69 and UDim2.fromOffset(u74 * 4, u74 * 4) or l__Faded__21:Map(function(p90) --[[ Line: 661 ]]
                    -- upvalues: u74 (copy)
                    local v91 = u74 * (p90 * 3 + 1);
                    return UDim2.fromOffset(v91, v91);
                end)
            }, {
                UICorner = u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.5, 0)
                })
            });
        end;
        if u69 then
            v71.Blink = u2.createElement("Frame", {
                Position = l__Node__24.Position,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Size = l__Blink__22:Map(function(p92) --[[ Line: 676 ]]
                    return UDim2.fromScale(p92 / 10 + 0.05, p92 / 10 + 0.05);
                end),
                SizeConstraint = u3.SizeConstraint.RelativeYY,
                BackgroundColor3 = u6.Colors.Selected,
                BackgroundTransparency = l__Blink__22:Map(function(p93) --[[ Line: 681 ]]
                    return p93;
                end)
            }, {
                UICorner = u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.5, 0)
                })
            });
        end;
        local l__createElement__32 = u2.createElement;
        local v94 = u16;
        local v95 = {
            BackgroundTransparency = 1,
            ZIndex = 2,
            SoundKit = "MainMenuLoadoutNode",
            SizeConstraint = u3.SizeConstraint.RelativeYY,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Size = UDim2.fromScale(0.1, 0.1),
            Visible = l__Visible__25,
            Position = l__Node__24.Position
        };
        if u69 then
            l__PopupActive__23 = not l__IsRailAttachment__28 or l__PopupActive__23;
        end;
        v95.Ignore = l__PopupActive__23;
        function v95.MouseUp() --[[ Line: 703 ]]
            -- upvalues: u68 (copy), u4 (ref), u69 (copy), l__props__18 (copy), l__Attachment__26 (copy)
            if u68._moveLoop then
                u68:_endAttachmentMove();
            end;
            if u4:IsScrollBarActive() then
            elseif u69 then
            else
                local v96 = {};
                for v97 = #l__props__18.Path + 1, #l__Attachment__26.Path do
                    v96[#v96 + 1] = l__Attachment__26.Path[v97];
                end;
                l__props__18.SetAdditionalPath(v96);
            end;
        end;
        function v95.MouseDown() --[[ Line: 723 ]]
            -- upvalues: l__IsRailAttachment__28 (copy), u68 (copy), l__Node__24 (copy), l__Attachment__26 (copy)
            if l__IsRailAttachment__28 then
                u68:_startAttachmentMove(l__Node__24.Component, l__Attachment__26);
            end;
        end;
        function v95.MouseEnter() --[[ Line: 728 ]]
            -- upvalues: u68 (copy), l__IsRail__27 (copy), l__Node__24 (copy), l__Attachment__26 (copy), l__props__18 (copy), l__Hover__20 (copy)
            u68._changeHover(true);
            local v98 = not l__IsRail__27 and (l__Node__24.Component or l__Attachment__26.ParentComponent:GetChild(l__Attachment__26.SubName));
            if v98 then
                l__props__18.ChangeHighlight(v98.ParentModel, true);
            end;
            l__Hover__20:SetGoal(1);
        end;
        function v95.MouseLeave() --[[ Line: 739 ]]
            -- upvalues: u68 (copy), l__IsRail__27 (copy), l__Node__24 (copy), l__Attachment__26 (copy), l__props__18 (copy), l__Hover__20 (copy)
            u68._changeHover(false);
            local v99 = not l__IsRail__27 and (l__Node__24.Component or l__Attachment__26.ParentComponent:GetChild(l__Attachment__26.SubName));
            if v99 then
                l__props__18.ChangeHighlight(v99.ParentModel, false);
            end;
            l__Hover__20:SetGoal(0);
        end;
        local v100 = {};
        local v101 = not l__IsRail__27;
        if v101 then
            v101 = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(l__IsRailAttachment__28 and 0.725 or 0.65, 0.5),
                Size = UDim2.new(50, 0, 0, u6.Sizes.TagTextSize),
                Text = l__SubName__29,
                TextTransparency = l__Hover__20:Map(function(p102) --[[ Line: 762 ]]
                    return 1 - p102;
                end),
                TextColor3 = u73 or Color3.fromRGB(239, 239, 239),
                TextXAlignment = u3.TextXAlignment.Left
            });
        end;
        v100.Title = v101;
        local v103 = not l__IsRailAttachment__28;
        if v103 then
            v103 = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Size = u69 and UDim2.fromScale(0.3, 0.3) or l__Hover__20:Map(function(p104) --[[ Line: 772 ]]
                    return UDim2.fromScale(0.2 - p104 / 10, 0.2 - p104 / 10);
                end),
                Position = UDim2.fromScale(0.5, 0.5)
            }, {
                Corner = u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.5, 0)
                }),
                Stroke = u2.createElement("UIStroke", {
                    Color = u73 or l__Hover__20:Map(function(p105) --[[ Line: 782 ]]
                        -- upvalues: u73 (ref), u6 (ref)
                        return u73 or u6.Colors.Idle:Lerp(u6.Colors.Hover, p105);
                    end),
                    Thickness = math.ceil(u6.Sizes.LineThickness / 4),
                    Transparency = u69 and 0 or l__Faded__21:Map(function(p106) --[[ Line: 789 ]]
                        return math.lerp(0.5, 1, p106);
                    end)
                })
            });
        end;
        v100.Circle = v103;
        v100[1] = u2.createFragment(v72);
        v71.Button = l__createElement__32(v94, v95, v100);
        return u2.createFragment(v71);
    end;
    if not u70.Hidden then
        local function v108() --[[ Line: 418 ]]
            -- upvalues: l__Attachment__26 (copy), u70 (copy), l__props__18 (copy)
            local v107 = table.clone(l__Attachment__26.Path);
            if u70.Redirect then
                table.remove(v107, #v107);
                v107[#v107 + 1] = u70.Redirect;
            end;
            if #v107 == 1 then
                l__props__18.ChangeModel:Fire(l__Attachment__26.SubName);
            else
                l__props__18.SetPath(v107);
            end;
        end;
        local v127 = {
            Line = u2.createElement("Frame", {
                BorderSizePixel = 0,
                Position = l__Node__24.Position:map(function(p109) --[[ Line: 434 ]]
                    -- upvalues: u68 (copy), u70 (copy), l__Open__19 (copy)
                    local v110, v111 = u68:_getLinePosition(u70, p109);
                    if v110 then
                        local v112 = (v110 + v111) / 2;
                        return UDim2.fromOffset(v110.X, v110.Y):Lerp(UDim2.fromOffset(v112.X, v112.Y), l__Open__19:GetValue());
                    end;
                end),
                Size = l__Node__24.Position:map(function(p113) --[[ Line: 443 ]]
                    -- upvalues: u68 (copy), u70 (copy), l__props__18 (copy), l__Hover__20 (copy), l__Open__19 (copy), u6 (ref)
                    local v114, v115 = u68:_getLinePosition(u70, p113);
                    if v114 then
                        local l__Magnitude__33 = (v114 - v115).Magnitude;
                        local v116;
                        if l__props__18.BigButtons then
                            v116 = l__Magnitude__33 * l__Hover__20:GetValue();
                        else
                            v116 = l__Magnitude__33 * l__Open__19:GetValue();
                        end;
                        return UDim2.fromOffset(v116, (math.ceil(u6.Sizes.LineThickness / 4)));
                    end;
                end),
                Rotation = l__Node__24.Position:map(function(p117) --[[ Line: 458 ]]
                    -- upvalues: u68 (copy), u70 (copy)
                    local v118, v119 = u68:_getLinePosition(u70, p117);
                    if v118 then
                        local v120 = v118 - v119;
                        local v121 = math.atan2(v120.Y, v120.X);
                        return math.deg(v121);
                    end;
                end),
                BackgroundColor3 = l__Hover__20:Map(function(p122) --[[ Line: 467 ]]
                    -- upvalues: u6 (ref)
                    return u6.Colors.Idle:Lerp(u6.Colors.Hover, p122);
                end),
                BackgroundTransparency = l__Hover__20:Map(function(p123) --[[ Line: 470 ]]
                    return 0.5 - p123 * 0.5;
                end),
                AnchorPoint = Vector2.new(0.5, 0.5)
            }),
            Pin = u2.createElement(u16, {
                BackgroundTransparency = 1,
                ZIndex = 2,
                SoundKit = "MainMenuLoadoutNode",
                SizeConstraint = u3.SizeConstraint.RelativeYY,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Size = UDim2.fromScale(0.1, 0.1),
                Position = l__Node__24.Position,
                Ignore = l__PopupActive__23,
                MouseUp = v108,
                MouseDown = function() --[[ Name: MouseDown, Line 488 ]] end,
                MouseEnter = function() --[[ Name: MouseEnter, Line 490 ]]
                    -- upvalues: l__Hover__20 (copy)
                    l__Hover__20:SetGoal(1);
                end,
                MouseLeave = function() --[[ Name: MouseLeave, Line 493 ]]
                    -- upvalues: l__Hover__20 (copy)
                    l__Hover__20:SetGoal(0);
                end
            }, {
                Circle = u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Size = l__Hover__20:Map(function(p124) --[[ Line: 500 ]]
                        return UDim2.fromScale(0.2 - p124 / 10, 0.2 - p124 / 10);
                    end),
                    Position = UDim2.fromScale(0.5, 0.5)
                }, {
                    Corner = u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0.5, 0)
                    }),
                    Stroke = u2.createElement("UIStroke", {
                        Color = l__Hover__20:Map(function(p125) --[[ Line: 509 ]]
                            -- upvalues: u6 (ref)
                            return u6.Colors.Idle:Lerp(u6.Colors.Hover, p125);
                        end),
                        Thickness = math.ceil(u6.Sizes.LineThickness / 4),
                        Transparency = l__Hover__20:Map(function(p126) --[[ Line: 513 ]]
                            return 0.5 - p126 * 0.5;
                        end)
                    })
                }),
                Dot = u2.createElement("Frame", {
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    BackgroundColor3 = u6.Colors.Hover,
                    Position = UDim2.fromScale(0.5, 0.5),
                    Size = UDim2.fromOffset(math.ceil(u6.Sizes.LineThickness / 2), (math.ceil(u6.Sizes.LineThickness / 2)))
                }, {
                    UICorner = u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0.5, 0)
                    })
                })
            })
        };
        local v128 = u2.createElement(u17, {
            SoundKit = "MainMenu",
            ItemsPerRow = 1,
            AnchorPoint = u70.AnchorPoint or Vector2.new(0.5, 0.5),
            SizeConstraint = u70.SizeConstraint or u3.SizeConstraint.RelativeYY,
            Size = UDim2.fromScale(u70.Size.X, u70.Size.Y),
            Position = UDim2.fromScale(u70.Position.X, u70.Position.Y),
            PopupActive = l__PopupActive__23,
            Left = u70.Left,
            Hover = l__Hover__20,
            Ref = u68._buttonRef,
            Item = {
                Type = u3.LoadoutButtonType.ViewAreaButton,
                Redirect = u70.Redirect,
                Attachment = l__Attachment__26,
                Offset = u70.Offset,
                Callback = v108
            }
        });
        if l__props__18.BigButtons then
            l__props__18.BigButtons[l__SubName__29] = v128;
        else
            v127.Button = v128;
        end;
        return u2.createFragment(v127);
    end;
end;
return v18;