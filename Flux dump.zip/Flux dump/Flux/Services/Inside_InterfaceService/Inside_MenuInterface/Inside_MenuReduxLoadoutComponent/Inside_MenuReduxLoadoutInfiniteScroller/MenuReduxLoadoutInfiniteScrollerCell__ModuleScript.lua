-- Services.InterfaceService.MenuInterface.MenuReduxLoadoutComponent.MenuReduxLoadoutInfiniteScroller.MenuReduxLoadoutInfiniteScrollerCell
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Roact", "Enum", "asset");
local l__ContentProvider__1 = game:GetService("ContentProvider");
local l__RunService__2 = game:GetService("RunService");
local u5 = v1("InputService");
local u6 = v1("ClientService");
local u7 = v1("AttachableComponent");
local u8 = v1("Appearance");
local u9 = v1("formatNumber");
local u10 = v1("RoactTween");
local u11 = v1("BaseComponent");
local u12 = v1("Manufacturers");
local u13 = v1("GameShellProxyService");
local u14 = v1("MenuLoadoutConstants");
local u15 = v1("GameShellProxyTextLabel");
local u16 = v1("GameShellProxyButton");
local u17 = v1("GameShellProxyGlobals");
local _ = u14.SAVE_CONFIGS;
local u18 = {
    Color3.fromRGB(238, 27, 36),
    Color3.fromRGB(241, 89, 42),
    Color3.fromRGB(247, 148, 29),
    Color3.fromRGB(254, 241, 0),
    Color3.fromRGB(0, 166, 83),
    Color3.fromRGB(1, 119, 193),
    Color3.fromRGB(103, 46, 145),
    Color3.fromRGB(160, 31, 97)
};
local function u27(p19, p20) --[[ Line: 38 ]]
    -- upvalues: u6 (copy), u7 (copy), u11 (copy)
    local l__LocalClient__3 = u6.LocalClient;
    local v21 = l__LocalClient__3.Loadouts[l__LocalClient__3.ActiveLoadout];
    local v22 = u7.new({ "Character", "HeadModel" });
    v22:GetChild("Appearance"):Destroy();
    local v23 = u11.Deserialize(v21.Tree):GetChild("Character"):GetChild("Appearance"):Serialize();
    local v24 = u11.Deserialize(v23);
    local _, v25 = v24:SetChild(p19, nil, p20);
    if v25 then
        v25:Destroy();
    end;
    v24:AssignParent(v22, "Appearance");
    local v26 = v22.ParentModel:Clone();
    v22:Destroy();
    return v26;
end;
local u41 = {
    Shirt = function(p28) --[[ Name: Shirt, Line 62 ]]
        -- upvalues: u4 (copy)
        local v29 = Instance.new("Model");
        local v30 = u4:Get("Shared", "Models", "Outfit", "Physical", "Shirt").Asset:Clone();
        u4:Get("Shared", "Models", "Outfit", "ShirtTransparent", p28[#p28]).Asset:Clone().Parent = v30;
        v30.Parent = v29;
        return v29;
    end,
    Pants = function(p31) --[[ Name: Pants, Line 70 ]]
        -- upvalues: u4 (copy)
        local v32 = Instance.new("Model");
        local v33 = u4:Get("Shared", "Models", "Outfit", "Physical", "Pants").Asset:Clone();
        u4:Get("Shared", "Models", "Outfit", "Pants", p31[#p31]).Asset:Clone().Parent = v33;
        v33.Parent = v32;
        return v32;
    end,
    SkinColor = function(p34) --[[ Name: SkinColor, Line 79 ]]
        -- upvalues: u27 (copy)
        return u27(p34, "SkinColor");
    end,
    Hair = function(p35) --[[ Name: Hair, Line 82 ]]
        -- upvalues: u27 (copy)
        return u27(p35, "Hair");
    end,
    HairColor = function(p36) --[[ Name: HairColor, Line 85 ]]
        -- upvalues: u27 (copy)
        return u27(p36, "HairColor");
    end,
    Eyebrows = function(p37) --[[ Name: Eyebrows, Line 88 ]]
        -- upvalues: u27 (copy)
        return u27(p37, "Eyebrows");
    end,
    Mouth = function(p38) --[[ Name: Mouth, Line 91 ]]
        -- upvalues: u27 (copy)
        return u27(p38, "Mouth");
    end,
    EyeColor = function(p39) --[[ Name: EyeColor, Line 94 ]]
        -- upvalues: u27 (copy)
        return u27(p39, "EyeColor");
    end,
    FacialHair = function(p40) --[[ Name: FacialHair, Line 97 ]]
        -- upvalues: u27 (copy)
        return u27(p40, "FacialHair");
    end
};
local v42 = u2.PureComponent:extend("MenuReduxLoadoutInfiniteScrollerCell");
local function u49(p43, p44, p45) --[[ Line: 104 ]]
    -- upvalues: u6 (copy)
    local v46 = p43:GetCamoConfig(p44);
    if v46 then
        if v46.ForSale ~= false then
            local v47 = u6.LocalClient:IsComponentUnlocked(v46.CamoPath, true);
            local v48 = (p43.MetaData.Camo or "Default") == p44;
            v46.FullNamePath = p43:GetFullName();
            v46.Unlocked = v47;
            v46.Active = v48;
            table.insert(p45, v46);
            return v46;
        end;
    end;
end;
local function u57(p50, p51, p52) --[[ Line: 124 ]]
    -- upvalues: u57 (copy)
    for _, v53 in p52.Children do
        for _, v54 in v53 do
            local v55, v56 = v54:GetMenuConfig();
            if v55 and not p50:IsComponentUnlocked(v56.Path) then
                table.insert(p51, {
                    Component = v54,
                    Config = v56
                });
            end;
            u57(p50, p51, v54);
        end;
    end;
end;
function v42.init(u58, p59) --[[ Line: 136 ]]
    -- upvalues: u10 (copy), u3 (copy), u2 (copy), u6 (copy), u13 (copy), u11 (copy), u4 (copy), u41 (copy), u57 (copy), u9 (copy), u17 (copy), u49 (copy), u12 (copy), l__ContentProvider__1 (copy), l__RunService__2 (copy)
    u58.Open = u10.new(0);
    u58.Open:SetGoal(1);
    u58.CamoPopup = u10.new(0, TweenInfo.new(2, u3.EasingStyle.Exponential, u3.EasingDirection.Out, 0, false, 0));
    u58.Loading = u10.new(1);
    u58.Hover = p59.Hover or u10.new(0);
    local u60 = 0;
    local v61, u62 = u2.createBinding(0);
    u58._loadCircle = v61;
    u58._viewPort = u2.createBinding();
    u58._buttonRef = p59.Ref or u2.createRef();
    u58._renamingRef = u2.createRef();
    local v63 = Instance.new("Camera");
    v63.FieldOfView = 30;
    v63.CFrame = CFrame.new(0, 0, 0);
    u58._camera = v63;
    local v64, v65 = u2.createBinding(false);
    u58._ownedBinding = v64;
    u58._updateOwned = v65;
    local v66, v67 = u2.createBinding("");
    u58._priceBinding = v66;
    u58._updatePrice = v67;
    local l__Item__4 = p59.Item;
    local l__LocalClient__5 = u6.LocalClient;
    local l__Tree__6 = l__LocalClient__5.Loadouts[l__LocalClient__5.ActiveLoadout].Tree;
    u58._textLabels = {};
    u58._environment = {
        Camera = v63,
        ViewPort = u58._viewPort,
        Loading = u58.Loading
    };
    if l__Item__4.Config and not l__Item__4.KeyBind then
        u58._hoverComponent = {
            Config = l__Item__4.Config,
            Button = u58._buttonRef
        };
    end;
    local l__Type__7 = l__Item__4.Type;
    if l__Type__7 == u3.LoadoutButtonType.Loadout then
        u58._hoverComponent = {
            Config = {
                Loadout = l__Item__4.Loadout,
                LoadoutIndex = l__Item__4.LoadoutIndex,
                Path = {}
            },
            Button = u58._buttonRef
        };
        u13:QueueBaseComponent(u58._environment, function() --[[ Line: 188 ]]
            -- upvalues: u11 (ref), l__Item__4 (copy)
            return u11.Deserialize(l__Item__4.Loadout.Tree):GetChild("Character");
        end, function(p68) --[[ Line: 190 ]]
            return p68.ParentModel:Clone(), CFrame.new(0, -2.5, -5) * CFrame.Angles(0, 3.141592653589793, 0);
        end);
    elseif l__Type__7 == u3.LoadoutButtonType.LoadoutSet then
        local v69 = "<b>Created by:</b>";
        for _, v70 in l__Item__4.Authors do
            v69 = v69 .. "\n• " .. v70;
        end;
        u58._hoverComponent = {
            Config = {
                Name = l__Item__4.Name,
                Description = v69,
                Path = {}
            },
            Button = u58._buttonRef
        };
        u13:QueueBaseComponent(u58._environment, function() --[[ Line: 208 ]]
            -- upvalues: u4 (ref), l__Item__4 (copy)
            return {
                ParentModel = u4:Get("Shared", "Models", "LoadoutSets", l__Item__4.ID, "Character").Asset:Clone(),
                Path = {},
                Destroy = function() --[[ Name: Destroy, Line 213 ]] end
            };
        end, function(p71) --[[ Line: 215 ]]
            -- upvalues: u3 (ref)
            local v72 = Instance.new("Part");
            v72.CFrame = CFrame.new(0, -2500, 0);
            v72.Color = Color3.fromRGB(8, 25, 39);
            v72.Size = Vector3.new(1, 1, 1);
            v72.Anchored = true;
            local v73 = Instance.new("SpecialMesh");
            v73.MeshId = "rbxassetid://554089739";
            v73.MeshType = u3.MeshType.FileMesh;
            v73.Scale = Vector3.new(-1, -1, -1);
            v73.VertexColor = Vector3.new();
            v73.Parent = v72;
            v72.Parent = p71.ParentModel;
            return p71.ParentModel, true;
        end);
    elseif l__Type__7 == u3.LoadoutButtonType.Add then
        u58.Loading:SetValue(0);
    elseif l__Type__7 == u3.LoadoutButtonType.ViewAreaButton then
        u13:QueueBaseComponent(u58._environment, function() --[[ Line: 235 ]]
            -- upvalues: u11 (ref), l__Tree__6 (copy), l__Item__4 (copy), u58 (copy)
            local v74 = u11.Deserialize(l__Tree__6):GetChild(unpack(l__Item__4.Attachment.Path));
            if not v74 then
                u58._makeX = true;
                u58:setState({});
            end;
            return v74;
        end, function(p75) --[[ Line: 243 ]]
            -- upvalues: u41 (ref), u58 (copy)
            local l__Path__8 = p75.Path;
            local v76 = u41[l__Path__8[2]];
            local v77;
            if v76 then
                v77 = v76(l__Path__8);
            else
                v77 = nil;
            end;
            u58._gotModel = true;
            return v77 or p75.ParentModel:Clone();
        end);
    elseif l__Type__7 == u3.LoadoutButtonType.Item then
        if l__Item__4.None or l__Item__4.KeyBind then
            u58.Loading:SetValue(0);
        else
            local l__Config__9 = l__Item__4.Config;
            local l__Path__10 = l__Config__9.Path;
            u13:QueueBaseComponent(u58._environment, function() --[[ Line: 261 ]]
                -- upvalues: l__Item__4 (copy), u11 (ref), l__Path__10 (copy)
                if l__Item__4.SavedConfig then
                    return u11.Deserialize(l__Item__4.SavedConfig);
                else
                    return u11.new(l__Path__10);
                end;
            end, function(p78) --[[ Line: 267 ]]
                -- upvalues: l__Item__4 (copy), l__Config__9 (copy), u57 (ref), l__LocalClient__5 (copy), u58 (copy), u9 (ref), u17 (ref), u49 (ref), u41 (ref), l__Path__10 (copy)
                local v79 = {};
                local v80 = 0;
                if not l__Item__4.Unlocked and l__Config__9.Price then
                    v80 = v80 + l__Config__9.Price;
                end;
                u57(l__LocalClient__5, v79, p78);
                for _, v81 in v79 do
                    if v81.Config.Price then
                        v80 = v80 + v81.Config.Price;
                    end;
                end;
                local l___hoverComponent__11 = u58._hoverComponent;
                local v82;
                if v80 > 0 then
                    u58._upsells = v79;
                    v82 = u9(v80);
                    if l__Config__9.Level and l__Config__9.Level > 0 then
                        v82 = "<font color=\"#ffffff\">LVL. " .. l__Config__9.Level .. " </font>" .. v82;
                    end;
                    l___hoverComponent__11.Upsells = v79;
                else
                    v82 = "";
                end;
                if l__Config__9.Gamepass and l__Config__9.Gamepass > 0 then
                    v82 = "<font color=\"#" .. u17.Colors.Green:ToHex() .. "\">GAMEPASS</font>";
                end;
                u58._updatePrice(v82);
                if l__Item__4.Unlocked then
                    u58._updateOwned(true);
                    l___hoverComponent__11.Owned = true;
                end;
                if l__Config__9.IsCamo and l__Item__4.ChildComponent then
                    p78:EditMetaData({
                        Camo = l__Config__9.CamoPath[#l__Config__9.CamoPath]
                    });
                    local v83 = {};
                    local v84 = l__Config__9.CamoPath[#l__Config__9.CamoPath];
                    local v85 = l__Item__4.ChildComponent:GetBaseComponent(true);
                    local v86 = u49(v85, v84, v83);
                    for _, v87 in v85:GetDescendants() do
                        u49(v87, v84, v83);
                    end;
                    if (#v83 ~= 1 or v83[1] ~= v86) and #v83 > 0 then
                        local v88 = #v85:GetFullName();
                        for _, v89 in v83 do
                            local v90 = table.clone(v89.FullNamePath);
                            for _ = 1, v88 do
                                table.remove(v89.FullNamePath, 1);
                            end;
                            v89.TargetPath = v90;
                        end;
                        l___hoverComponent__11.ChildComponent = v85:Serialize();
                        l___hoverComponent__11.CamoUpsells = v83;
                    end;
                end;
                if l___hoverComponent__11.ReRender then
                    l___hoverComponent__11.ReRender();
                end;
                local v91 = u41[l__Path__10[2]];
                local v92;
                if v91 then
                    v92 = v91(l__Path__10);
                else
                    v92 = nil;
                end;
                return v92 or p78.ParentModel:Clone();
            end);
        end;
        if l__Item__4.CamoOption then
            u58.CamoPopup:SetGoal(1);
        end;
    elseif l__Type__7 == u3.LoadoutButtonType.Icon then
        u58.Loading:SetValue(0);
    elseif l__Type__7 == u3.LoadoutButtonType.Category then
        local l__Path__12 = l__Item__4.Path;
        if l__Path__12 then
            u13:QueueBaseComponent(u58._environment, function() --[[ Line: 354 ]]
                -- upvalues: u11 (ref), l__Path__12 (copy)
                return u11.new(l__Path__12);
            end, function(p93) --[[ Line: 356 ]]
                -- upvalues: u41 (ref), l__Path__12 (copy), u3 (ref)
                local v94 = u41[l__Path__12[2]];
                local v95;
                if v94 then
                    v95 = v94(l__Path__12);
                else
                    v95 = p93.ParentModel:Clone();
                    for _, v96 in v95:GetDescendants() do
                        if v96:IsA("MeshPart") then
                            v96.TextureID = "";
                            v96.Material = u3.Material.SmoothPlastic;
                            v96.Color = Color3.new(1, 1, 1);
                        end;
                    end;
                end;
                return v95, nil, true;
            end);
        else
            u58.Loading:SetValue(0);
        end;
    elseif l__Type__7 == u3.LoadoutButtonType.Colorway then
        u58.Loading:SetValue(0);
        u58.CamoPopup:SetGoal(1);
    elseif l__Type__7 == u3.LoadoutButtonType.Manufacturer then
        if l__Item__4.Manufacturer then
            u58._manufacturer = u12[l__Item__4.Manufacturer];
            local u97 = Instance.new("ImageLabel");
            u97.Image = u58._manufacturer.Logo;
            task.spawn(function() --[[ Line: 387 ]]
                -- upvalues: l__ContentProvider__1 (ref), u97 (copy), u58 (copy)
                l__ContentProvider__1:PreloadAsync({ u97 });
                u97:Destroy();
                if u58._environment.Destroyed then
                else
                    u58.Loading:SetGoal(0);
                end;
            end);
        else
            u58.Loading:SetValue(0);
            local u98 = {};
            local v99 = {};
            for v100 in l__Item__4.Manufacturers do
                local v101 = u12[v100];
                if v101.Logo and #v101.Logo > 0 then
                    local v102 = Instance.new("ImageLabel");
                    v102.Image = v101.Logo;
                    u98[#u98 + 1] = v101.Logo;
                    v99[#v99 + 1] = v102;
                end;
            end;
            local u103 = math.random(1, #u98);
            local u104 = tick();
            local u105 = true;
            u58._logoTransparency = u10.new(0.999);
            u58._logoRef = u2.createRef();
            local v106, v107 = u2.createBinding(u98[u103]);
            u58._manufacturerLogo = v106;
            u58._updateLogo = v107;
            u58._updateManufacturers = l__RunService__2.Heartbeat:Connect(function(_) --[[ Line: 420 ]]
                -- upvalues: u58 (copy), u105 (ref), u104 (ref), u103 (ref), u98 (copy)
                local v108 = u58._logoRef:getValue();
                if v108 then
                    local v109 = tick();
                    if v108.IsLoaded then
                        local v110 = v109 - u104;
                        if v110 > 2 then
                            if not u105 then
                                u58._logoTransparency:SetGoal(1);
                                u105 = true;
                            end;
                            if v110 > 2.3 then
                                u104 = v109;
                                if u103 == #u98 then
                                    u103 = 1;
                                else
                                    u103 = u103 + 1;
                                end;
                                u58._updateLogo(u98[u103]);
                            end;
                        elseif u105 then
                            u58._logoTransparency:SetGoal(0);
                            u105 = false;
                        end;
                    else
                        u58._logoTransparency:SetValue(0.999);
                        u105 = true;
                        u104 = v109;
                    end;
                end;
            end);
        end;
    end;
    u58._update = l__RunService__2.Heartbeat:Connect(function(p111) --[[ Line: 461 ]]
        -- upvalues: u58 (copy), u60 (ref), u62 (copy)
        if u58.Loading:GetValue() < 0.01 then
            u58._update:Disconnect();
            u58._update = nil;
        else
            u60 = u60 + p111 * 1000;
            u62(u60);
        end;
    end);
end;
function v42.didMount(u112) --[[ Line: 473 ]]
    u112._environment.Ready = true;
    task.defer(function() --[[ Line: 475 ]]
        -- upvalues: u112 (copy)
        for _, v113 in u112._textLabels do
            v113();
        end;
    end);
    local v114 = u112._renamingRef:getValue();
    if v114 then
        v114:CaptureFocus();
    end;
end;
function v42.didUpdate(p115) --[[ Line: 487 ]]
    for _, v116 in p115._textLabels do
        v116();
    end;
    local v117 = p115._renamingRef:getValue();
    if v117 then
        v117:CaptureFocus();
    end;
end;
function v42.willUnmount(p118) --[[ Line: 498 ]]
    p118._environment.Destroyed = true;
    p118._destroyed = true;
    if p118._camera then
        p118._camera:Destroy();
    end;
    if p118._updateManufacturers then
        p118._updateManufacturers:Disconnect();
        p118._updateManufacturers = nil;
    end;
    if p118._update then
        p118._update:Disconnect();
        p118._update = nil;
    end;
end;
function v42.render(u119) --[[ Line: 514 ]]
    -- upvalues: u17 (copy), u3 (copy), u14 (copy), u8 (copy), u2 (copy), u18 (copy), u15 (copy), u5 (copy), u16 (copy)
    local l__props__13 = u119.props;
    local _ = u119.state;
    local l__Item__14 = l__props__13.Item;
    local l__PopupActive__15 = l__props__13.PopupActive;
    local l__ItemsPerRow__16 = l__props__13.ItemsPerRow;
    local l__ScrollerRef__17 = l__props__13.ScrollerRef;
    local l__LineThickness__18 = u17.Sizes.LineThickness;
    local v120 = {};
    local l__Open__19 = u119.Open;
    local l__Hover__20 = u119.Hover;
    local l__Loading__21 = u119.Loading;
    local l__CamoPopup__22 = u119.CamoPopup;
    local l___hoverComponent__23 = u119._hoverComponent;
    local v121 = false;
    local u122 = true;
    local u123 = false;
    local v124 = 0;
    local v125 = false;
    local v126 = false;
    local v127 = nil;
    local v128 = (l__Item__14.NoRailSpace or l__Item__14.NoCategoryLimit) and true or false;
    local v129 = false;
    local v130 = nil;
    local v131 = false;
    local v132 = {};
    local l__Type__24 = l__Item__14.Type;
    local v133 = nil;
    if l__Type__24 == u3.LoadoutButtonType.Loadout then
        v127 = l__Item__14.Loadout.Name;
        u123 = l__Item__14.Selected;
        if l__Item__14.Renaming then
            v121 = true;
        end;
    elseif l__Type__24 == u3.LoadoutButtonType.LoadoutSet then
        v127 = l__Item__14.Name;
        u123 = l__Item__14.Selected;
        v129 = true;
    elseif l__Type__24 == u3.LoadoutButtonType.Add then
        v124 = 1;
    elseif l__Type__24 == u3.LoadoutButtonType.ViewAreaButton then
        v127 = l__Item__14.Redirect or l__Item__14.Attachment.SubName;
        if u14.SubIndexDisplayNames[v127] then
            v127 = u14.SubIndexDisplayNames[v127];
        end;
        if u119._makeX then
            v125 = true;
        end;
    elseif l__Type__24 == u3.LoadoutButtonType.Item then
        u123 = l__Item__14.Selected;
        v127 = l__Item__14.Config.Name;
        if l__Item__14.None then
            v125 = true;
            v127 = "None";
            u122 = false;
        end;
        local l__Path__25 = l__Item__14.Config.Path;
        if l__Path__25[1] == "Character" and u8.Default[l__Path__25[2]] then
            u122 = false;
        end;
        if l__Item__14.DoComparison then
            v130 = u123 and not l__Item__14.TopComponent and "B" or (l__Item__14.TopComponent and not u123 and "A" or v130);
        end;
        if l__Item__14.CamoOption then
            v133 = 0.8;
        end;
    elseif l__Type__24 == u3.LoadoutButtonType.Icon then
        local l__Icon__26 = l__Item__14.Icon;
        if l__Icon__26 == "None" then
            v125 = true;
            v127 = "None";
        elseif l__Icon__26 == "ShowAll" then
            v126 = true;
            v127 = "Show all";
        elseif l__Icon__26 == "Remove" then
            v125 = true;
            v127 = "Remove";
        end;
        u123 = l__Item__14.Selected;
    elseif l__Type__24 == u3.LoadoutButtonType.Category then
        v127 = u14.ListCategoriesDisplayNames[l__Item__14.Name] or l__Item__14.Name;
        v131 = true;
    elseif l__Type__24 == u3.LoadoutButtonType.Colorway then
        v133 = 0.65;
        v127 = "Colorways";
    elseif l__Type__24 == u3.LoadoutButtonType.Manufacturer then
        local l___manufacturer__27 = u119._manufacturer;
        local v134, v135;
        if l___manufacturer__27 then
            v134 = l___manufacturer__27.Logo;
            v135 = l__Loading__21;
        else
            v134 = u119._manufacturerLogo;
            v135 = u119._logoTransparency;
        end;
        v127 = l___manufacturer__27 and l___manufacturer__27.Name or "Manufacturers";
        v132.Back = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Image = v134,
            ImageTransparency = v135:Map(function(p136) --[[ Line: 635 ]]
                return 1 - (1 - p136) * 0.1;
            end),
            Position = UDim2.fromScale(0.5, 0.5),
            ScaleType = u3.ScaleType.Fit,
            Size = UDim2.fromScale(3, 3),
            SizeConstraint = u3.SizeConstraint.RelativeYY
        });
        v132.Logo = u2.createElement("ImageLabel", {
            AnchorPoint = Vector2.new(0.5, 0.5),
            BackgroundTransparency = 1,
            Image = v134,
            ImageTransparency = v135:Map(function(p137) --[[ Line: 648 ]]
                return p137;
            end),
            Position = UDim2.fromScale(0.5, 0.4),
            Size = UDim2.fromScale(0.8, 0.5),
            ScaleType = u3.ScaleType.Fit,
            ZIndex = 3,
            [u2.Ref] = u119._logoRef
        });
    end;
    local v139 = u123 and u17.Colors.Selected or l__Hover__20:Map(function(p138) --[[ Line: 659 ]]
        -- upvalues: u17 (ref)
        return u17.Colors.Idle:Lerp(u17.Colors.Hover, p138);
    end);
    if v125 then
        local v140 = l__ItemsPerRow__16 > 1 and 0.65 or 0.5;
        v120.LineLeft = u2.createElement("Frame", {
            BorderSizePixel = 0,
            Rotation = 45,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0.5, 0.5),
            BackgroundColor3 = v139,
            BackgroundTransparency = u123 and 0 or l__Hover__20:Map(function(p141) --[[ Line: 668 ]]
                return 0.5 - p141 * 0.5;
            end),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(v140, 0.5),
            Size = l__Open__19:Map(function(p142) --[[ Line: 675 ]]
                -- upvalues: l__LineThickness__18 (copy)
                return UDim2.new(0, l__LineThickness__18, p142 * 0.5, 0);
            end)
        });
        v120.LineRight = u2.createElement("Frame", {
            BorderSizePixel = 0,
            Rotation = -45,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0.5, 0.5),
            BackgroundColor3 = v139,
            BackgroundTransparency = u123 and 0 or l__Hover__20:Map(function(p143) --[[ Line: 683 ]]
                return 0.5 - p143 * 0.5;
            end),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(v140, 0.5),
            Size = l__Open__19:Map(function(p144) --[[ Line: 690 ]]
                -- upvalues: l__LineThickness__18 (copy)
                return UDim2.new(0, l__LineThickness__18, p144 * 0.5, 0);
            end)
        });
    end;
    if v126 then
        for v145 = 1, 3 do
            local u146 = v145 / 3;
            local u147 = u146 - 0.16666666666666666;
            v120["Line" .. v145] = u2.createElement("Frame", {
                BorderSizePixel = 0,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                BackgroundColor3 = v139,
                BackgroundTransparency = u123 and 0 or l__Hover__20:Map(function(p148) --[[ Line: 706 ]]
                    return 0.5 - p148 * 0.5;
                end),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0.55, v145 * 0.1 + 0.3),
                Size = l__Open__19:Map(function(p149) --[[ Line: 712 ]]
                    -- upvalues: u147 (copy), u146 (copy), l__LineThickness__18 (copy)
                    local v150 = (math.clamp(p149, u147, u146) - u147) / 0.16666666666666666;
                    return UDim2.new(v150 * 0.2, 0, 0, l__LineThickness__18);
                end)
            });
        end;
    end;
    if v133 then
        local v151 = #u18;
        local u152 = 1 / v151 * 2;
        local v153 = 360 / v151;
        local v154 = {};
        for u155 = 1, v151 do
            local v156 = u155 * v153;
            local u157 = u155 / v151;
            local u158 = u157 - u152;
            v154[u155] = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://128607757623998",
                AnchorPoint = Vector2.new(0.5, 0.5),
                Rotation = v156,
                ImageColor3 = l__Hover__20:Map(function(p159) --[[ Line: 735 ]]
                    -- upvalues: u18 (ref), u155 (copy), u123 (ref), u17 (ref)
                    return u18[u155]:Lerp(Color3.new(1, 1, 1), 0.35):Lerp(u123 and u17.Colors.Selected or u17.Colors.Hover, p159);
                end),
                Position = UDim2.fromScale(0.5, 0.5),
                ImageTransparency = l__CamoPopup__22:Map(function(p160) --[[ Line: 739 ]]
                    -- upvalues: u158 (copy), u157 (copy), u152 (copy)
                    return 1 - (math.clamp(p160, u158, u157) - u158) / u152;
                end),
                Size = l__CamoPopup__22:Map(function(p161) --[[ Line: 743 ]]
                    -- upvalues: u158 (copy), u157 (copy), u152 (copy)
                    local v162 = (math.clamp(p161, u158, u157) - u158) / u152;
                    local v163 = math.lerp(1.2, 1, v162);
                    return UDim2.fromScale(v163, v163);
                end)
            });
        end;
        v120.Wheel = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(v133, 0.5),
            Rotation = l__Hover__20:Map(function(p164) --[[ Line: 755 ]]
                return p164 * 90;
            end),
            Size = UDim2.fromScale(0.5, 0.5),
            SizeConstraint = u3.SizeConstraint.RelativeYY
        }, v154);
    end;
    if l__Item__14.NoCategoryLimit then
        v120.NoCategoryLimit = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            ZIndex = 10,
            TextScaled = true,
            Text = "OVER GROUP LIMIT",
            AnchorPoint = Vector2.new(0.5, 0.5),
            Size = UDim2.new(1, -u17.Sizes.TagTextSize * 2, 0, u17.Sizes.TagTextSize),
            Position = UDim2.fromScale(0.5, l__Item__14.NoRailSpace and 0.4 or 0.5),
            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
            TextColor3 = u17.Colors.Red,
            TextTransparency = l__Loading__21:Map(function(p165) --[[ Line: 779 ]]
                return p165;
            end),
            TextXAlignment = u3.TextXAlignment.Center
        });
    end;
    if l__Item__14.NoRailSpace then
        v120.NoRailSpace = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            ZIndex = 10,
            TextScaled = true,
            Text = "NO RAIL SPACE",
            AnchorPoint = Vector2.new(0.5, 0.5),
            Size = UDim2.new(1, -u17.Sizes.TagTextSize * 2, 0, u17.Sizes.TagTextSize),
            Position = UDim2.fromScale(0.5, l__Item__14.NoCategoryLimit and 0.6 or 0.5),
            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
            TextColor3 = u17.Colors.Red,
            TextTransparency = l__Loading__21:Map(function(p166) --[[ Line: 801 ]]
                return p166;
            end),
            TextXAlignment = u3.TextXAlignment.Center
        });
    end;
    local v167 = 0;
    local v168 = not l__Item__14.Tags and l__Item__14.Config;
    if v168 then
        v168 = l__Item__14.Config.MenuTags;
    end;
    if v168 and not v130 then
        local v169 = v168.NEW or v168.REDUX;
        local v170;
        if typeof(v169) == "number" then
            v170 = v169;
        else
            v170 = nil;
        end;
        if v169 then
            local v171 = u17.Sizes.TagTextSize * (v168.NEW and 2.71 or 3.33);
            local v172 = v168.NEW and "NEW" or "REDUX";
            local v173;
            if v170 then
                v171 = v171 + u17.Sizes.TagTextSize;
                v167 = v167 + u17.Sizes.TagTextSize;
                v172 = v172 .. (v170 > 9 and "       " or "   ");
                v173 = u2.createElement("Frame", {
                    BackgroundTransparency = 0,
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.fromRGB(252, 250, 255),
                    Size = UDim2.fromScale(v170 > 9 and 1.5 or 1, 1),
                    Position = UDim2.fromScale(1, 0),
                    AnchorPoint = Vector2.new(1, 0),
                    SizeConstraint = u3.SizeConstraint.RelativeYY
                }, {
                    Corner = u2.createElement("UICorner", {
                        CornerRadius = UDim.new(1, 0)
                    }),
                    Title = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        ZIndex = 2,
                        FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                        Size = UDim2.fromScale(1, 1),
                        Text = v170,
                        TextColor3 = Color3.new()
                    })
                });
            else
                v173 = nil;
            end;
            v120.Tag = u2.createElement("Frame", {
                ZIndex = 3,
                AnchorPoint = Vector2.new(0, 0),
                BackgroundColor3 = Color3.new(1, 1, 1),
                Position = UDim2.new(0, u17.Sizes.TagTextSize, 0, u17.Sizes.TagTextSize),
                Size = UDim2.fromOffset(v171, u17.Sizes.TagTextSize),
                Visible = u119._ownedBinding:map(function(p174) --[[ Line: 860 ]]
                    -- upvalues: u122 (ref)
                    return not (u122 and p174);
                end)
            }, {
                Corner = u2.createElement("UICorner", {
                    CornerRadius = UDim.new(1, 0)
                }),
                Title = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    ZIndex = 2,
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Size = UDim2.fromScale(1, 1),
                    Text = v172,
                    TextColor3 = Color3.new()
                }),
                Gradient = u2.createElement("UIGradient", {
                    Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 172, 71)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 214, 178)) })
                }),
                Count = v173
            });
        end;
        if v168.REWARD_ITEM then
            local v175 = u17.Sizes.TagTextSize * 4.16;
            v167 = v167 + (v175 + u17.Sizes.TagTextSize);
            v120.Tag = u2.createElement("Frame", {
                ZIndex = 3,
                AnchorPoint = Vector2.new(1, 1),
                BackgroundColor3 = Color3.fromRGB(232, 232, 232),
                Position = UDim2.new(1, -u17.Sizes.TagTextSize, 1, -u17.Sizes.TagTextSize),
                Size = UDim2.fromOffset(v175, u17.Sizes.TagTextSize)
            }, {
                Corner = u2.createElement("UICorner", {
                    CornerRadius = UDim.new(1, 0)
                }),
                Title = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "REWARD",
                    TextScaled = true,
                    ZIndex = 2,
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Size = UDim2.fromScale(1, 1),
                    TextColor3 = Color3.new(1, 1, 1)
                }),
                Gradient = u2.createElement("UIGradient", {
                    Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 138, 79)), ColorSequenceKeypoint.new(1, Color3.fromRGB(113, 11, 255)) })
                })
            });
        end;
    end;
    if v124 == 0 then
        local l__Left__28 = l__props__13.Left;
        v120.Line = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 2,
            BackgroundColor3 = v139,
            BackgroundTransparency = u123 and 0 or l__Hover__20:Map(function(p176) --[[ Line: 931 ]]
                return 0.5 - p176 * 0.5;
            end),
            BorderColor3 = Color3.new(),
            AnchorPoint = Vector2.new(l__Left__28 and 1 or 0, 1),
            Position = UDim2.fromScale(l__Left__28 and 1 or 0, 1),
            Size = l__Open__19:Map(function(p177) --[[ Line: 938 ]]
                -- upvalues: l__LineThickness__18 (copy)
                return UDim2.new(p177, 0, 0, l__LineThickness__18);
            end)
        });
        if l__ItemsPerRow__16 > 1 then
            v120.LineVertical = u2.createElement("Frame", {
                BorderSizePixel = 0,
                ZIndex = 2,
                BackgroundColor3 = v139,
                BackgroundTransparency = u123 and 0 or l__Hover__20:Map(function(p178) --[[ Line: 946 ]]
                    return 0.5 - p178 * 0.5;
                end),
                BorderColor3 = Color3.new(),
                AnchorPoint = Vector2.new(1, 0),
                Position = UDim2.fromScale(1, 0.5),
                Size = l__Open__19:Map(function(p179) --[[ Line: 953 ]]
                    -- upvalues: l__LineThickness__18 (copy)
                    return UDim2.new(0, l__LineThickness__18, p179 * 0.5, -l__LineThickness__18);
                end)
            });
        end;
        local l__createElement__29 = u2.createElement;
        local v180 = "Frame";
        local v183 = {
            ClipsDescendants = true,
            BorderSizePixel = 0,
            BackgroundColor3 = l__Hover__20:Map(function(p181) --[[ Line: 960 ]]
                return Color3.new():Lerp(Color3.new(1, 1, 1), p181);
            end),
            BackgroundTransparency = l__Open__19:Map(function(p182) --[[ Line: 963 ]]
                return 1 - p182 * 0.8;
            end),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0, 0),
            Size = UDim2.fromScale(1, 1)
        };
        local v184 = {
            Gradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.8) })
            })
        };
        local l__createElement__30 = u2.createElement;
        local v185 = "ViewportFrame";
        local v188 = {
            BackgroundTransparency = 1,
            ZIndex = 2,
            Position = l__CamoPopup__22:Map(function(p186) --[[ Line: 981 ]]
                return UDim2.fromScale(p186 * -0.2, 0);
            end),
            Size = UDim2.new(1, 0, 1, -l__LineThickness__18),
            ImageColor3 = v128 and Color3.new(0.5, 0.5, 0.5) or Color3.new(1, 1, 1),
            ImageTransparency = l__Loading__21:Map(function(p187) --[[ Line: 986 ]]
                return p187;
            end),
            CurrentCamera = u119._camera
        };
        local v189 = {
            World = u2.createElement("WorldModel", {
                [u2.Ref] = u119._viewPort
            })
        };
        if v131 then
            v131 = u2.createElement("UIGradient", {
                Rotation = 90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.48125), NumberSequenceKeypoint.new(1, 1) })
            });
        end;
        v189.Fade = v131;
        if v129 then
            v129 = u2.createElement("UIGradient", {
                Rotation = -20,
                Transparency = NumberSequence.new({
                    NumberSequenceKeypoint.new(0, 1),
                    NumberSequenceKeypoint.new(0.208229, 0.4625),
                    NumberSequenceKeypoint.new(0.467581, 0.20625),
                    NumberSequenceKeypoint.new(0.776808, 0),
                    NumberSequenceKeypoint.new(1, 0)
                })
            });
        end;
        v189.SideFade = v129;
        v184.Viewport = l__createElement__30(v185, v188, v189);
        v184.Loading = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://93026081002023",
            Position = l__CamoPopup__22:Map(function(p190) --[[ Line: 1014 ]]
                return UDim2.fromScale(0.5 - p190 * 0.2, 0.5);
            end),
            Size = UDim2.fromOffset(u17.Sizes.TagTextSize, u17.Sizes.TagTextSize),
            AnchorPoint = Vector2.new(0.5, 0.5),
            ImageTransparency = l__Loading__21:Map(function(p191) --[[ Line: 1020 ]]
                return math.lerp(1, 0.5, p191);
            end),
            SizeConstraint = u3.SizeConstraint.RelativeYY,
            Rotation = u119._loadCircle
        });
        v184.Owned = u2.createElement("ImageLabel", {
            Image = "rbxassetid://100122624145286",
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(0.3, 0.3),
            SizeConstraint = u3.SizeConstraint.RelativeYY,
            ImageColor3 = v128 and Color3.new(0.5, 0.5, 0.5) or (u123 and u17.Colors.Selected or u17.Colors.Green),
            ImageTransparency = l__Loading__21:Map(function(p192) --[[ Line: 1033 ]]
                return p192;
            end),
            Visible = u119._ownedBinding:map(function(p193) --[[ Line: 1036 ]]
                -- upvalues: u122 (ref)
                return u122 and p193;
            end)
        });
        v184[1] = u2.createFragment(v132);
        v120.Background = l__createElement__29(v180, v183, v184);
        if v130 then
            v167 = v167 + u17.Sizes.TagTextSize * 2;
            v120.Comparison = u2.createElement("Frame", {
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                ZIndex = 3,
                BackgroundColor3 = Color3.fromRGB(252, 250, 255),
                Size = UDim2.new(0, u17.Sizes.TagTextSize, 0, u17.Sizes.TagTextSize),
                Position = UDim2.new(1, -u17.Sizes.TagTextSize, 1, -u17.Sizes.TagTextSize),
                AnchorPoint = Vector2.new(1, 1)
            }, {
                Corner = u2.createElement("UICorner", {
                    CornerRadius = UDim.new(1, 0)
                }),
                Title = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    ZIndex = 2,
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Size = UDim2.fromScale(1, 1),
                    Text = v130:upper(),
                    TextColor3 = Color3.new()
                })
            });
        end;
        if v127 then
            if v121 then
                v120.TitleContainer = u2.createElement("TextBox", {
                    BackgroundTransparency = 1,
                    Size = UDim2.new(1, -u17.Sizes.TagTextSize * 2, 0, u17.Sizes.TagTextSize),
                    Position = UDim2.new(0, u17.Sizes.TagTextSize, 1, -u17.Sizes.TagTextSize),
                    AnchorPoint = Vector2.new(0, 1),
                    ZIndex = 2,
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Text = v127,
                    TextColor3 = u17.Colors.Hover,
                    TextTransparency = 0,
                    TextXAlignment = u3.TextXAlignment.Left,
                    TextScaled = true,
                    [u2.Ref] = u119._renamingRef,
                    [u2.Event.FocusLost] = function(p194, p195) --[[ Line: 1095 ]]
                        -- upvalues: l__Item__14 (copy)
                        l__Item__14.Rename(p194.Text, p195);
                    end
                });
            else
                local l__createElement__31 = u2.createElement;
                local v196 = "Frame";
                local v197 = {
                    BackgroundTransparency = 1,
                    ZIndex = 2,
                    Size = UDim2.new(1, -u17.Sizes.TagTextSize * 2 - v167, 0, u17.Sizes.TagTextSize),
                    Position = UDim2.new(0, u17.Sizes.TagTextSize, 1, -u17.Sizes.TagTextSize),
                    AnchorPoint = Vector2.new(0, 1)
                };
                local v198 = {};
                local l__createElement__32 = u2.createElement;
                local v199 = u15;
                local v200 = {
                    BackgroundTransparency = 1,
                    FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                    Size = UDim2.fromScale(1, 1),
                    Text = v127
                };
                local v201;
                if v128 then
                    v201 = Color3.new(0.5, 0.5, 0.5) or v139;
                else
                    v201 = v139;
                end;
                v200.TextColor3 = v201;
                v200.TextTransparency = u123 and 0 or l__Hover__20:Map(function(p202) --[[ Line: 1117 ]]
                    return 0.5 - p202 * 0.5;
                end);
                v200.TextXAlignment = u3.TextXAlignment.Left;
                v200.DidMount = u119._textLabels;
                v198.Title = l__createElement__32(v199, v200);
                v120.TitleContainer = l__createElement__31(v196, v197, v198);
            end;
        end;
        v120.Price = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            TextScaled = true,
            RichText = true,
            Size = UDim2.new(1, -u17.Sizes.TagTextSize * 2, 0, u17.Sizes.TagTextSize),
            Position = UDim2.new(0, u17.Sizes.TagTextSize, 0, u17.Sizes.TagTextSize),
            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
            Text = u119._priceBinding:map(function(p203) --[[ Line: 1139 ]]
                return #p203 == 0 and "" or p203;
            end),
            TextColor3 = u17.Colors.Price:Lerp(Color3.new(), v128 and 0.5 or 0),
            TextTransparency = l__Loading__21:Map(function(p204) --[[ Line: 1147 ]]
                return p204;
            end),
            TextXAlignment = u3.TextXAlignment.Right,
            Visible = u119._ownedBinding:map(function(p205) --[[ Line: 1151 ]]
                -- upvalues: u122 (ref)
                return not (u122 and p205);
            end)
        });
    elseif v124 == 1 then
        v120.Background = u2.createElement("Frame", {
            ClipsDescendants = true,
            BorderSizePixel = 0,
            BackgroundColor3 = l__Hover__20:Map(function(p206) --[[ Line: 1157 ]]
                return Color3.new():Lerp(Color3.new(1, 1, 1), p206);
            end),
            BackgroundTransparency = l__Open__19:Map(function(p207) --[[ Line: 1160 ]]
                return 1 - p207 * 0.5;
            end),
            BorderColor3 = Color3.new(),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = UDim2.fromScale(0.5, 0.5),
            SizeConstraint = u3.SizeConstraint.RelativeYY
        }, {
            Gradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.8) })
            }),
            Line = u2.createElement("Frame", {
                BorderSizePixel = 0,
                ZIndex = 2,
                BackgroundColor3 = v139,
                BackgroundTransparency = l__Hover__20:Map(function(p208) --[[ Line: 1180 ]]
                    return 0.5 - p208 * 0.5;
                end),
                BorderColor3 = Color3.new(),
                AnchorPoint = Vector2.new(0, 1),
                Position = UDim2.fromScale(0, 1),
                Size = l__Open__19:Map(function(p209) --[[ Line: 1187 ]]
                    -- upvalues: l__LineThickness__18 (copy)
                    return UDim2.new(p209, 0, 0, l__LineThickness__18);
                end)
            }),
            LineLeft = u2.createElement("Frame", {
                BorderSizePixel = 0,
                Rotation = 0,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0.5, 0.5),
                BackgroundColor3 = v139,
                BackgroundTransparency = l__Hover__20:Map(function(p210) --[[ Line: 1195 ]]
                    return 0.5 - p210 * 0.5;
                end),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0.5, 0.5),
                Size = l__Hover__20:Map(function(p211) --[[ Line: 1202 ]]
                    -- upvalues: l__LineThickness__18 (copy)
                    return UDim2.new(0, l__LineThickness__18, p211 / 10 + 0.5, 0);
                end)
            }),
            LineRight = u2.createElement("Frame", {
                BorderSizePixel = 0,
                Rotation = 90,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0.5, 0.5),
                BackgroundColor3 = v139,
                BackgroundTransparency = l__Hover__20:Map(function(p212) --[[ Line: 1210 ]]
                    return 0.5 - p212 * 0.5;
                end),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0.5, 0.5),
                Size = l__Hover__20:Map(function(p213) --[[ Line: 1217 ]]
                    -- upvalues: l__LineThickness__18 (copy)
                    return UDim2.new(0, l__LineThickness__18, p213 / 10 + 0.5, 0);
                end)
            })
        });
    end;
    if l__Item__14.KeyBind then
        v120.Key = u2.createElement("Frame", {
            ZIndex = 3,
            AnchorPoint = Vector2.new(0.5, 0.5),
            BackgroundColor3 = Color3.fromRGB(43, 43, 43),
            Position = UDim2.fromScale(0.8, 0.5),
            Size = UDim2.fromScale(0.5, 0.5),
            SizeConstraint = u3.SizeConstraint.RelativeYY
        }, {
            UICorner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0.2, 0)
            }),
            UIGradient = u2.createElement("UIGradient", {
                Rotation = 90,
                Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.new(1, 1, 1)), ColorSequenceKeypoint.new(0.65917, Color3.fromRGB(236, 236, 236)), ColorSequenceKeypoint.new(1, Color3.fromRGB(91, 91, 91)) })
            }),
            UIStroke = u2.createElement("UIStroke", {
                Thickness = 3,
                Color = Color3.fromRGB(61, 61, 61)
            }),
            Key = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                RichText = true,
                TextScaled = true,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
                Position = UDim2.fromScale(0.1, 0.5),
                Size = UDim2.new(0.8, 0, 0.6, 6),
                Text = u5:GetBind("WeaponFunction" .. l__Item__14.KeyBind).Name,
                TextColor3 = v139
            })
        });
    end;
    return u2.createElement("Frame", {
        Position = l__props__13.Position,
        Size = l__props__13.Size,
        AnchorPoint = l__props__13.AnchorPoint,
        SizeConstraint = l__props__13.SizeConstraint,
        BackgroundTransparency = 1,
        [u2.Ref] = u119._buttonRef,
        ZIndex = 3
    }, { u2.createElement(u16, {
            BackgroundTransparency = 1,
            ZIndex = 5,
            Size = UDim2.fromScale(1, 1),
            Ignore = l__PopupActive__15,
            Scroller = l__ScrollerRef__17,
            SoundKit = l__props__13.SoundKit or "MainMenuLoadoutNode",
            MouseUp = function() --[[ Name: MouseUp, Line 1286 ]]
                -- upvalues: l__Item__14 (copy), l__props__13 (copy), u119 (copy)
                l__Item__14.Callback();
                if l__props__13.HoverComponent then
                    l__props__13.HoverComponent:Fire(nil);
                end;
                local v214 = tick();
                if u119._lastClick and (v214 - u119._lastClick < 0.25 and l__Item__14.DoubleClick) then
                    l__Item__14.DoubleClick();
                end;
                u119._lastClick = v214;
            end,
            MouseDown = function() --[[ Name: MouseDown, Line 1300 ]] end,
            MouseEnter = function() --[[ Name: MouseEnter, Line 1303 ]]
                -- upvalues: l__props__13 (copy), l___hoverComponent__23 (copy), l__Hover__20 (copy)
                if l__props__13.HoverComponent then
                    l__props__13.HoverComponent:Fire(l___hoverComponent__23);
                end;
                l__Hover__20:SetGoal(1);
            end,
            MouseLeave = function() --[[ Name: MouseLeave, Line 1309 ]]
                -- upvalues: l__Hover__20 (copy)
                l__Hover__20:SetGoal(0);
            end
        }), u2.createFragment(v120) });
end;
return v42;