-- Services.InterfaceService.MenuInterface.MenuReduxLoadoutComponent.MenuReduxLoadoutInfiniteScroller.MenuReduxLoadoutInfiniteScrollerRow
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local u3 = v1("MenuReduxLoadoutInfiniteScrollerCell");
local v4 = u2.PureComponent:extend("MenuReduxLoadoutInfiniteScrollerRow");
function v4.init(u5, p6) --[[ Line: 6 ]]
    u5._prefix = 0;
    local u7 = 0;
    local u8 = {};
    p6.Render:Connect(function(p9, p10, p11, p12) --[[ Line: 11 ]]
        -- upvalues: u7 (ref), u8 (ref), u5 (copy)
        local v13;
        if u7 == p10 then
            v13 = false;
        else
            v13 = true;
            u7 = p10;
        end;
        if not v13 then
            for v14, v15 in p11 do
                local v16 = u8[v14];
                if not v16 or (v16.Type ~= v15.Type or (v16.Name ~= v15.Name or (v16.Unlocked ~= v15.Unlocked or (v16.CamoOption ~= v15.CamoOption or v16.SavedConfig ~= v15.SavedConfig)))) then
                    v13 = true;
                end;
                local v17 = v15.Config and (v15.Config.CamoPath or (v15.Config.Path or {})) or {};
                if #v17 ~= #v16.Path then
                    v13 = true;
                end;
                local v18 = true;
                for v19 = 1, #v17 do
                    if v16.Path[v19] ~= v17[v19] then
                        v18 = false;
                        break;
                    end;
                end;
                if not v18 then
                    v13 = true;
                end;
            end;
        end;
        if not p12 or v13 then
            local v20 = u5;
            v20._prefix = v20._prefix + 1;
        end;
        u8 = {};
        for v21, v22 in p11 do
            u8[v21] = {
                Type = v22.Type,
                Path = v22.Config and (v22.Config.CamoPath or (v22.Config.Path or {})) or {},
                Name = v22.Name,
                Unlocked = v22.Unlocked,
                CamoOption = v22.CamoOption,
                SavedConfig = v22.SavedConfig
            };
        end;
        u5:setState({
            Index = p9,
            ItemsPerRow = p10,
            Items = p11
        });
    end);
end;
function v4.render(p23) --[[ Line: 96 ]]
    -- upvalues: u2 (copy), u3 (copy)
    local l__props__1 = p23.props;
    local l__state__2 = p23.state;
    local l__PopupActive__3 = l__props__1.PopupActive;
    local l__HoverComponent__4 = l__props__1.HoverComponent;
    local l__ScrollerRef__5 = l__props__1.ScrollerRef;
    if l__state__2.Items then
        local l___prefix__6 = p23._prefix;
        local l__ItemsPerRow__7 = l__state__2.ItemsPerRow;
        local v24 = 1 / l__ItemsPerRow__7;
        local v25 = {};
        for v26, v27 in l__state__2.Items do
            v25[l___prefix__6 .. v26] = u2.createElement(u3, {
                Size = UDim2.fromScale(v24, 1),
                Position = UDim2.fromScale((v26 - 1) * v24, 0),
                HoverComponent = l__HoverComponent__4,
                PopupActive = l__PopupActive__3,
                ItemsPerRow = l__ItemsPerRow__7,
                ScrollerRef = l__ScrollerRef__5,
                Index = l__state__2.Index,
                Item = v27
            });
        end;
        return u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = l__props__1.Size,
            Position = l__props__1.Position
        }, v25);
    end;
end;
return v4;