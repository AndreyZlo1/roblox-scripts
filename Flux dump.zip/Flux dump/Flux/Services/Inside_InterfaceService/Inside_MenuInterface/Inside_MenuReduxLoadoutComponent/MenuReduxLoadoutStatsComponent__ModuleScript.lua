-- Services.InterfaceService.MenuInterface.MenuReduxLoadoutComponent.MenuReduxLoadoutStatsComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "signal");
local u3 = v1("BulletService");
local u4 = v1("BaseComponent");
local u5 = v1("RoactTween");
local u6 = v1("deepCopy");
local u7 = v1("Calibers");
local u8 = v1("GameSettings");
local v9 = v1("MenuLoadoutConstants");
local u10 = v1("FirearmInventoryReplicator");
local u11 = v1("TerminalPerformanceGraphComponent");
local u12 = v1("GameShellProxyGlobals");
local u13 = v1("MenuReduxLoadoutStatsRowComponent");
local v14 = u2.Component:extend("MenuReduxLoadoutStatsComponent");
local l__FIREMODES__1 = v9.TOOL_TIPS.FIREMODES;
local u15 = {
    Primary = true,
    Secondary = true
};
local u16 = {
    {
        "RateOfFire",
        "Rate Of Fire",
        0,
        1200
    },
    {
        "Weight",
        "Cumulative Mass",
        0,
        8000
    },
    {
        "DrawTime",
        "Draw Time",
        0,
        6
    },
    {
        "AdsTime",
        "ADS Time",
        0,
        3
    },
    {
        "PartialTime",
        "Partial Reload Time",
        0,
        10
    },
    {
        "EmptyTime",
        "Empty Reload Time",
        0,
        10
    }
};
local u17 = {
    {
        "MuzzleVelocity",
        "Muzzle Velocity",
        500,
        3000
    },
    {
        "MaxRange",
        "Maximum Range",
        500,
        4000
    },
    {
        "Dispersion",
        "Dispersion",
        0,
        10
    }
};
local function u26(p18, p19, p20, p21) --[[ Line: 47 ]]
    -- upvalues: u2 (copy)
    local l__createElement__2 = u2.createElement;
    local v22 = {
        BackgroundTransparency = 1,
        ClipsDescendants = true,
        LayoutOrder = p19,
        Size = UDim2.new(0.5, -5, 1, 0)
    };
    local v23 = {
        Bar = u2.createElement("Frame", {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.fromRGB(139, 139, 139),
            Size = UDim2.new(1, 0, 0, 1)
        }),
        Bar2 = u2.createElement("Frame", {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.fromRGB(139, 139, 139),
            Size = UDim2.new(0, 1, 1, 0)
        }),
        Bar3 = u2.createElement("Frame", {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(1, 0),
            BackgroundColor3 = Color3.fromRGB(139, 139, 139),
            Position = UDim2.fromScale(1, 0),
            Size = UDim2.new(0, 1, 1, 0)
        }),
        Bar4 = u2.createElement("Frame", {
            BackgroundTransparency = 0.5,
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(0, 1),
            BackgroundColor3 = Color3.fromRGB(139, 139, 139),
            Position = UDim2.fromScale(0, 1),
            Size = UDim2.new(1, 0, 0, 1)
        }),
        Circle = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://282305376",
            ImageTransparency = 0.5,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = UDim2.fromScale(p20, p21),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            ImageColor3 = Color3.fromRGB(255, 194, 89)
        }),
        Title = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            RichText = true,
            TextScaled = true,
            ZIndex = 3,
            AnchorPoint = Vector2.new(0, 1),
            FontFace = Font.new("rbxassetid://12187375422"),
            Position = UDim2.fromScale(0, 0.9),
            Size = UDim2.fromScale(1, 0.22),
            Text = p18,
            TextColor3 = Color3.new(1, 1, 1)
        })
    };
    local l__createElement__3 = u2.createElement;
    local v24 = {
        BackgroundTransparency = 1,
        RichText = true,
        TextScaled = true,
        ZIndex = 3,
        AnchorPoint = Vector2.new(0, 0.5),
        FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
        Position = UDim2.fromScale(0, 0.5),
        Size = UDim2.fromScale(1, 0.22)
    };
    local v25 = Vector2.new(p20, p21).Magnitude * 10;
    v24.Text = math.round(v25);
    v24.TextColor3 = Color3.new(1, 1, 1);
    v23.Kick = l__createElement__3("TextLabel", v24);
    return l__createElement__2("Frame", v22, v23);
end;
function v14.init(u27, p28) --[[ Line: 167 ]]
    -- upvalues: u5 (copy), u15 (copy), u4 (copy), u6 (copy), u10 (copy)
    u27.Visible = u5.new(1);
    u27._captureStats = p28.CaptureStats:Connect(function(p29, p30) --[[ Line: 170 ]]
        -- upvalues: u15 (ref), u4 (ref), u6 (ref), u10 (ref), u27 (copy)
        local v31 = u15[p30[1]] and (p29 and p29:GetChild(unpack(p30)));
        if v31 then
            if v31.Tune then
                v31:Calculate();
            else
                u4.ConvertToBase(v31);
            end;
        else
            v31 = nil;
        end;
        if v31 then
            local v32 = u6(v31.Tune);
            local v33 = u10.getADSOffsets(v31);
            local v34 = nil;
            if v33 then
                for _, v35 in v33 do
                    local v36 = u10.getADSSpeed(v35, v32);
                    if v34 then
                        v34 = math.min(v34, v36) or v36;
                    else
                        v34 = v36;
                    end;
                end;
            end;
            local v37;
            if v34 then
                local v38 = 0.013333333333333334 * v34;
                v37 = v38 >= 1 and 0.013333333333333334 or -2.99573227355399 / math.log(1 - v38) * 0.013333333333333334;
            else
                v37 = 0;
            end;
            v32._ADSTIME = v37;
            u27._lastTune = v32;
        end;
    end);
end;
function v14.willUnmount(p39) --[[ Line: 190 ]]
    p39._captureStats:Disconnect();
end;
function v14.render(p40) --[[ Line: 194 ]]
    -- upvalues: u8 (copy), u15 (copy), u4 (copy), u10 (copy), u7 (copy), u3 (copy), u2 (copy), u11 (copy), u13 (copy), l__FIREMODES__1 (copy), u16 (copy), u17 (copy), u26 (copy), u12 (copy)
    local l__props__4 = p40.props;
    local l__Visible__5 = p40.Visible;
    local v41 = {};
    local v42 = {};
    local v43 = {};
    if l__props__4.Path then
        p40._path = l__props__4.Path;
    end;
    if l__props__4.CurrentComponent then
        p40._currentComponent = l__props__4.CurrentComponent;
    end;
    local l__MeasurementUnit__6 = u8.MeasurementUnit;
    if l__MeasurementUnit__6 then
        l__MeasurementUnit__6 = u8.MeasurementUnit == 2;
    end;
    local l___currentComponent__7 = p40._currentComponent;
    local l___path__8 = p40._path;
    local v44 = u15[l___path__8[1]] and (l___currentComponent__7 and l___currentComponent__7:GetChild(unpack(l___path__8)));
    if v44 then
        if v44.Tune then
            v44:Calculate();
        else
            u4.ConvertToBase(v44);
        end;
    else
        v44 = nil;
    end;
    if v44 then
        l__Visible__5:SetGoal(0);
        local l__Tune__9 = v44.Tune;
        local v45 = p40._lastTune or l__Tune__9;
        local v46 = {
            { "Hip" }
        };
        local v47 = u10.getADSOffsets(v44);
        local v48 = nil;
        if v47 then
            for v49, v50 in v47 do
                local v51 = u10.getADSSpeed(v50, l__Tune__9);
                if v48 then
                    v48 = math.min(v48, v51) or v51;
                else
                    v48 = v51;
                end;
                v46[#v46 + 1] = { v49 == 0 and "Sight" or "Canted", v50.Height };
            end;
        end;
        local v52;
        if v48 then
            local v53 = 0.013333333333333334 * v48;
            v52 = v53 >= 1 and 0.013333333333333334 or -2.99573227355399 / math.log(1 - v53) * 0.013333333333333334;
        else
            v52 = 0;
        end;
        local v54 = u7[l__Tune__9.Caliber];
        local v55 = u7[v45.Caliber];
        local v56, v57, v58 = u3:GetInfo(l__Tune__9.Caliber, l__Tune__9.Barrel);
        local v59, v60, v61 = u3:GetInfo(v45.Caliber, v45.Barrel);
        local v62 = {
            RateOfFire = {
                "rounds/minute",
                true,
                l__Tune__9.RPM,
                v45.RPM
            },
            Weight = {
                l__MeasurementUnit__6 and "pounds" or "grams",
                false,
                l__Tune__9.Weight,
                v45.Weight,
                l__MeasurementUnit__6 and 0.002204585537918871
            },
            DrawTime = {
                "seconds",
                false,
                (l__Tune__9.Draw_Loaded or 0) + (l__Tune__9.Draw_Ready or 0),
                (v45.Draw_Loaded or 0) + (v45.Draw_Ready or 0)
            },
            PartialTime = {
                "seconds",
                false,
                (l__Tune__9.Reload_Partial_Loaded or 0) + (l__Tune__9.Reload_Partial_Ready or 0),
                (v45.Reload_Partial_Loaded or 0) + (v45.Reload_Partial_Ready or 0)
            },
            EmptyTime = {
                "seconds",
                false,
                (l__Tune__9.Reload_Empty_Loaded or 0) + (l__Tune__9.Reload_Empty_Ready or 0),
                (v45.Reload_Empty_Loaded or 0) + (v45.Reload_Empty_Ready or 0)
            },
            AdsTime = {
                "seconds",
                false,
                v52,
                v45._ADSTIME or v52
            },
            MuzzleVelocity = {
                (l__MeasurementUnit__6 and "feet" or "metres") .. "/second",
                true,
                v56,
                v59,
                l__MeasurementUnit__6 and 1 or 0.30478512648582745
            },
            MaxRange = {
                l__MeasurementUnit__6 and "feet" or "metres",
                true,
                v58,
                v61,
                l__MeasurementUnit__6 and 1 or 0.30478512648582745
            },
            Dispersion = {
                l__MeasurementUnit__6 and "moa" or "mrad",
                false,
                (l__Tune__9.Barrel_Spread or 1) * v54.Spread,
                (v45.Barrel_Spread or 1) * v55.Spread,
                l__MeasurementUnit__6 and 3.4377467707849396
            }
        };
        v43 = u2.createElement(u11, {
            Caliber = v54,
            OldCaliber = v55,
            CaliberRange = v58,
            OldCaliberRange = v61,
            CaliberOffset = v57,
            OldCaliberOffset = v60
        });
        local l__createElement__10 = u2.createElement;
        local v63 = u13;
        local v64 = {
            Position = UDim2.fromScale(0, 0),
            Stat = { "FireModes", "Fire Modes" }
        };
        local v65 = l__Tune__9.Firemodes or {};
        local v66 = "";
        local v67 = 0;
        for v68 = 1, #v65 do
            v66 = v66 .. l__FIREMODES__1[v65[v68]];
            if v68 ~= #v65 then
                v66 = v66 .. " | ";
            end;
        end;
        v64.Data = v66;
        v41[v67] = l__createElement__10(v63, v64);
        for v69, v70 in u16 do
            v41[v69] = u2.createElement(u13, {
                Position = UDim2.fromScale(0, v69 * 0.14285714285714285),
                Stat = v70,
                Data = v62[v70[1]]
            });
        end;
        v42[0] = u2.createElement(u13, {
            Position = UDim2.fromScale(0, 0),
            Stat = { "Ammunition", "Ammunition" },
            Data = v54.FamilyName .. " (" .. v54.VariantName .. ")"
        });
        for v71, v72 in u17 do
            v42[v71] = u2.createElement(u13, {
                Position = UDim2.fromScale(0, v71 * 0.14285714285714285),
                Stat = v72,
                Data = v62[v72[1]]
            });
        end;
        local v73 = {
            Grid = u2.createElement("UIGridLayout", {
                CellPadding = UDim2.fromOffset(10, 0),
                CellSize = UDim2.new(1 / #v46, -7, 1, 0),
                SortOrder = Enum.SortOrder.LayoutOrder,
                HorizontalAlignment = Enum.HorizontalAlignment.Center
            })
        };
        local v74 = u10.getMoment(v44);
        for v75, v76 in v46 do
            local _, _, v77 = u10.getRecoil(l__Tune__9, v74, v76[2], true, 0, v75 > 1);
            v73[v75] = u26(v76[1], v75, v77.X / 2, v77.Y / 10);
        end;
        v42.RecoilPreview = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Position = UDim2.new(0, 0, 0.572, 10),
            Size = UDim2.new(1, 0, 0.428, -10)
        }, v73);
    else
        l__Visible__5:SetGoal(1);
    end;
    local l__LineThickness__11 = u12.Sizes.LineThickness;
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        AnchorPoint = Vector2.new(0.5, 1),
        Position = l__props__4.Position,
        Size = UDim2.fromScale(1.2, 0.25),
        SizeConstraint = Enum.SizeConstraint.RelativeYY
    }, {
        Widget = u2.createElement("Frame", {
            BackgroundTransparency = 0.2,
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(),
            BorderColor3 = Color3.new(),
            Position = l__Visible__5:Map(function(p78) --[[ Line: 373 ]]
                return UDim2.fromScale(0, p78 * 1.5);
            end),
            Size = UDim2.fromScale(1, 1)
        }, {
            Gradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.8) })
            }),
            Line = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 1),
                Size = UDim2.new(1, 0, 0, l__LineThickness__11)
            }),
            Left = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                LayoutOrder = 10,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.175, 0.5),
                Size = UDim2.fromScale(0.3, 0.85)
            }, v43),
            Middle = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                LayoutOrder = 10,
                AnchorPoint = Vector2.new(0.5, 0),
                Position = UDim2.new(0.5, 0, 0, l__LineThickness__11),
                Size = UDim2.new(0.333, -20, 1, -(l__LineThickness__11 + 20))
            }, v42),
            Right = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                LayoutOrder = 10,
                AnchorPoint = Vector2.new(0.5, 0),
                Position = UDim2.new(0.833, -5, 0, l__LineThickness__11),
                Size = UDim2.new(0.333, -20, 1, -(l__LineThickness__11 + 20))
            }, v41)
        })
    });
end;
return v14;