-- Services.InterfaceService.MenuInterface.MenuReduxLoadoutComponent.MenuReduxLoadoutHoverComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "frc");
local l__UserInputService__1 = game:GetService("UserInputService");
local l__GuiService__2 = game:GetService("GuiService");
local l__TextService__3 = game:GetService("TextService");
local u3 = v1("InputService");
local u4 = v1("RoactTween");
local u5 = v1("formatNumber");
local u6 = v1("Manufacturers");
local u7 = v1("BaseComponent");
local u8 = v1("GameShellProxyService");
local u9 = v1("GameShellProxyGlobals");
local u10 = v1("MenuButtonComponent");
local v11 = u2.Component:extend("MenuReduxLoadoutHover");
local l__Y__4 = l__GuiService__2:GetGuiInset().Y;
local u12 = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u13 = Font.new("rbxassetid://12187375422", Enum.FontWeight.Regular, Enum.FontStyle.Normal);
function v11.init(u14, u15) --[[ Line: 36 ]]
    -- upvalues: u4 (copy), u2 (copy), u3 (copy), l__UserInputService__1 (copy), l__Y__4 (copy)
    u14.Hover = u4.new(0);
    u14.Loading = u4.new(1);
    u14._hoverComponent = u15.HoverComponent:Connect(function(u16) --[[ Line: 39 ]]
        -- upvalues: u14 (copy)
        if u14._component then
            u14._component.ReRender = nil;
        end;
        u14._component = u16;
        u14.Hover:SetValue(0);
        u14:setState({});
        if u16 then
            function u16.ReRender() --[[ Line: 48 ]]
                -- upvalues: u16 (copy), u14 (ref)
                u16.ReRender = nil;
                u14:setState({});
            end;
            u14.Hover:SetGoal(1);
        end;
    end);
    u14._height = 0;
    local v17, v18 = u2.createBinding(0);
    u14._position = v17;
    u14._updatePosition = v18;
    local u19 = 0;
    local v20, u21 = u2.createBinding(0);
    u14._loadCircle = v20;
    local l__LeftPanel__5 = u15.LeftPanel;
    u14._updateNodes = u15.UpdateNodes:Connect(function(p22) --[[ Line: 65 ]]
        -- upvalues: u19 (ref), u21 (copy), l__LeftPanel__5 (copy), u14 (copy), u15 (copy), u3 (ref), l__UserInputService__1 (ref), l__Y__4 (ref)
        u19 = u19 + p22 * 1000;
        u21(u19);
        local v23 = l__LeftPanel__5:getValue();
        if v23 then
            local l___component__6 = u14._component;
            if l___component__6 then
                local v24 = l___component__6.Button:getValue();
                if v24 then
                    local l___hasButton__7 = u14._hasButton;
                    local v25 = u3.VirtualCursorPosition or l__UserInputService__1:GetMouseLocation();
                    local l__AbsoluteSize__8 = v23.AbsoluteSize;
                    local l__AbsolutePosition__9 = v23.AbsolutePosition;
                    local l___height__10 = u14._height;
                    local v26 = v24.AbsolutePosition.Y - l__AbsolutePosition__9.Y;
                    if l___hasButton__7 then
                        v26 = v26 + v24.AbsoluteSize.Y / 2 - l___height__10 / 2;
                    end;
                    local v27 = math.clamp(v26, 0, l__AbsoluteSize__8.Y - l___height__10);
                    if v25.X > l__AbsolutePosition__9.X + l__AbsoluteSize__8.X then
                        local v28 = v25.Y - l__Y__4 - l__AbsolutePosition__9.Y;
                        local v29;
                        if v27 < v28 then
                            v29 = v28 < v27 + u14._height;
                        else
                            v29 = false;
                        end;
                        if not l___hasButton__7 or (v25.X >= l__AbsolutePosition__9.X + l__AbsoluteSize__8.X + l__AbsoluteSize__8.X * 0.8 or not v29) then
                            u15.HoverComponent:Fire();
                            return;
                        end;
                    elseif v25.Y - l__Y__4 < l__AbsolutePosition__9.Y + l__AbsoluteSize__8.Y * 0.08 then
                        u15.HoverComponent:Fire();
                        return;
                    end;
                    u14._updatePosition(v27);
                else
                    u15.HoverComponent:Fire();
                end;
            end;
        end;
    end);
    local v30 = Instance.new("Camera");
    v30.FieldOfView = 30;
    v30.CFrame = CFrame.new(0, 0, 0);
    u14._viewPort = u2.createRef();
    u14._camera = v30;
end;
function v11.willUnmount(p31) --[[ Line: 124 ]]
    p31._hoverComponent:Disconnect();
    p31._updateNodes:Disconnect();
    p31._camera:Destroy();
    if p31._environment then
        p31._environment.Destroyed = true;
    end;
end;
function v11.didMount(p32) --[[ Line: 134 ]]
    if p32._environment then
        p32._environment.Ready = true;
    end;
end;
function v11.didUpdate(p33) --[[ Line: 140 ]]
    if p33._environment then
        p33._environment.Ready = true;
    end;
end;
function v11.render(u34) --[[ Line: 146 ]]
    -- upvalues: u9 (copy), u2 (copy), u10 (copy), u6 (copy), u12 (copy), u5 (copy), l__TextService__3 (copy), u13 (copy), u8 (copy), u7 (copy)
    local l__props__11 = u34.props;
    local l__Hover__12 = u34.Hover;
    local l__Loading__13 = u34.Loading;
    u34._hasButton = false;
    if u34._environment then
        u34._environment.Destroyed = true;
        u34._environment = nil;
    end;
    if u34._model then
        u34._model:Destroy();
        u34._model = nil;
    end;
    local l__PopupActive__14 = l__props__11.PopupActive;
    local l___position__15 = u34._position;
    local l___component__16 = u34._component;
    if l___component__16 then
        local l__Config__17 = l___component__16.Config;
        if l__Config__17 then
            local v35 = l__props__11.LeftPanel:getValue();
            if v35 then
                local u37 = l__Hover__12:Map(function(p36) --[[ Line: 178 ]]
                    return 1 - p36;
                end);
                local v38 = v35.AbsoluteSize.Y * 0.5 * 0.8;
                local l__TagTextSize__18 = u9.Sizes.TagTextSize;
                local u39 = l__TagTextSize__18 * 1.4;
                local u40 = u39 * 2;
                local u41 = u39;
                local u42 = {};
                local function v45(p43, p44) --[[ Line: 189 ]]
                    -- upvalues: u41 (ref), u39 (copy), u42 (copy), u2 (ref), u10 (ref), l__PopupActive__14 (copy), u40 (copy), l__TagTextSize__18 (copy), u34 (copy)
                    u41 = u41 + u39 / 2;
                    u42[p43] = u2.createElement(u10, {
                        ZIndex = 6,
                        Ignore = l__PopupActive__14,
                        Position = UDim2.new(0, u39, 0, u41),
                        Size = UDim2.new(1, -u40, 0, l__TagTextSize__18 * 1.5),
                        Name = p43,
                        Callback = p44
                    });
                    u34._hasButton = true;
                    u41 = u41 + l__TagTextSize__18 * 1.5;
                end;
                if l__Config__17.Manufacturer then
                    local v46 = u6[l__Config__17.Manufacturer];
                    if v46 and v46.Logo then
                        u42.Logo = u2.createElement("ImageLabel", {
                            BackgroundTransparency = 1,
                            ZIndex = 2,
                            AnchorPoint = Vector2.new(0.5, 0.5),
                            Image = v46.Logo,
                            ImageTransparency = l__Hover__12:Map(function(p47) --[[ Line: 211 ]]
                                return 1 - p47 * 0.1;
                            end),
                            Position = UDim2.new(0.8, 0, 0, 100),
                            ScaleType = Enum.ScaleType.Fit,
                            Size = UDim2.fromScale(0.7, 0.7),
                            SizeConstraint = Enum.SizeConstraint.RelativeXX
                        });
                    end;
                end;
                if l__Config__17.Loadout then
                    l__Config__17.Name = l__Config__17.Loadout.Name;
                end;
                u42.Title = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    FontFace = u12,
                    Position = UDim2.fromOffset(u39, u41),
                    Size = UDim2.new(1, -u40, 0, l__TagTextSize__18),
                    Text = l__Config__17.Name,
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = Enum.TextXAlignment.Left,
                    TextTransparency = u37
                });
                if not l___component__16.Owned and (l__Config__17.Price and l__Config__17.Price > 0) then
                    u42.Price = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        FontFace = u12,
                        Position = UDim2.fromOffset(u39, u41),
                        Size = UDim2.new(1, -u40, 0, l__TagTextSize__18),
                        Text = u5(l__Config__17.Price),
                        TextColor3 = u9.Colors.Price,
                        TextXAlignment = Enum.TextXAlignment.Right,
                        TextTransparency = u37
                    });
                end;
                u41 = u41 + l__TagTextSize__18;
                if l__Config__17.FlavorText then
                    u41 = u41 + u39 / 6;
                    local v48 = Instance.new("GetTextBoundsParams");
                    v48.RichText = true;
                    v48.Text = l__Config__17.FlavorText;
                    v48.Font = u12;
                    v48.Size = l__TagTextSize__18 * 0.75;
                    v48.Width = v38 - u40;
                    local l__Y__19 = l__TextService__3:GetTextBoundsAsync(v48).Y;
                    u42.FlavorText = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        RichText = true,
                        TextScaled = true,
                        FontFace = u12,
                        Position = UDim2.fromOffset(u39, u41),
                        Size = UDim2.new(1, -u40, 0, l__Y__19),
                        Text = l__Config__17.FlavorText,
                        TextColor3 = Color3.new(1, 1, 1),
                        TextXAlignment = Enum.TextXAlignment.Left,
                        TextTransparency = u37
                    });
                    u41 = u41 + l__Y__19;
                end;
                if l__Config__17.Description then
                    u41 = u41 + u39 / 3;
                    local v49 = Instance.new("GetTextBoundsParams");
                    v49.RichText = true;
                    v49.Text = l__Config__17.Description;
                    v49.Font = u13;
                    v49.Size = l__TagTextSize__18 * 0.75;
                    v49.Width = v38 - u40;
                    local l__Y__20 = l__TextService__3:GetTextBoundsAsync(v49).Y;
                    u42.Description = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        RichText = true,
                        TextScaled = true,
                        FontFace = u13,
                        Position = UDim2.fromOffset(u39, u41),
                        Size = UDim2.new(1, -u40, 0, l__Y__20),
                        Text = l__Config__17.Description,
                        TextColor3 = Color3.new(1, 1, 1),
                        TextXAlignment = Enum.TextXAlignment.Left,
                        TextTransparency = u37
                    });
                    u41 = u41 + l__Y__20;
                end;
                local u50 = 0;
                local function v53(p51, p52) --[[ Line: 306 ]]
                    -- upvalues: u42 (copy), u50 (ref), u41 (ref), u39 (copy), u2 (ref), u12 (ref), u40 (copy), l__TagTextSize__18 (copy), u37 (copy), u5 (ref), u9 (ref)
                    if u42.Description and u50 == 0 then
                        u41 = u41 + u39 / 3;
                    end;
                    u50 = u50 + 1;
                    u42["Name" .. u50] = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        FontFace = u12,
                        Position = UDim2.fromOffset(u39, u41),
                        Size = UDim2.new(1, -u40, 0, l__TagTextSize__18),
                        Text = p51,
                        TextColor3 = Color3.new(1, 1, 1),
                        TextXAlignment = Enum.TextXAlignment.Left,
                        TextTransparency = u37
                    });
                    u42["Price" .. u50] = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        FontFace = u12,
                        Position = UDim2.fromOffset(u39, u41),
                        Size = UDim2.new(1, -u40, 0, l__TagTextSize__18),
                        Text = u5(p52),
                        TextColor3 = u9.Colors.Price,
                        TextXAlignment = Enum.TextXAlignment.Right,
                        TextTransparency = u37
                    });
                    u41 = u41 + l__TagTextSize__18;
                end;
                if l___component__16.Upsells then
                    for _, v54 in l___component__16.Upsells do
                        if v54.Config.Price and v54.Config.Price > 0 then
                            v53(v54.Config.Name, v54.Config.Price);
                        end;
                    end;
                end;
                local l__CamoUpsells__21 = l___component__16.CamoUpsells;
                if l__CamoUpsells__21 then
                    u41 = u41 + u39 / 2;
                    local l___camera__22 = u34._camera;
                    local l___viewPort__23 = u34._viewPort;
                    local v55 = u39 * 5;
                    u42.CamoPreview = u2.createElement("Frame", {
                        BackgroundTransparency = 0.5,
                        BackgroundColor3 = Color3.new(),
                        BorderColor3 = Color3.fromRGB(63, 63, 63),
                        Position = UDim2.new(0, u39, 0, u41),
                        Size = UDim2.new(1, -u40, 0, v55)
                    }, {
                        Loading = u2.createElement("ImageLabel", {
                            BackgroundTransparency = 1,
                            Image = "rbxassetid://93026081002023",
                            ZIndex = 2,
                            Position = UDim2.fromScale(0.5, 0.5),
                            Size = UDim2.fromOffset(u9.Sizes.TagTextSize, u9.Sizes.TagTextSize),
                            AnchorPoint = Vector2.new(0.5, 0.5),
                            ImageTransparency = l__Loading__13:Map(function(p56) --[[ Line: 364 ]]
                                return math.lerp(1, 0.5, p56);
                            end),
                            SizeConstraint = Enum.SizeConstraint.RelativeYY,
                            Rotation = u34._loadCircle
                        }),
                        Viewport = u2.createElement("ViewportFrame", {
                            BackgroundTransparency = 1,
                            Size = UDim2.new(1, 0, 1, 0),
                            ImageTransparency = l__Loading__13:Map(function(p57) --[[ Line: 375 ]]
                                return p57;
                            end),
                            CurrentCamera = l___camera__22
                        }, {
                            World = u2.createElement("WorldModel", {
                                [u2.Ref] = l___viewPort__23
                            })
                        })
                    });
                    u41 = u41 + v55;
                    u34._environment = {
                        Camera = l___camera__22,
                        ViewPort = l___viewPort__23,
                        Loading = l__Loading__13
                    };
                    l__Loading__13:SetValue(1);
                    u8:QueueBaseComponent(u34._environment, function() --[[ Line: 394 ]]
                        -- upvalues: l___component__16 (copy), u7 (ref), l__Config__17 (copy)
                        if l___component__16.ChildComponent then
                            return u7.Deserialize(l___component__16.ChildComponent);
                        else
                            return u7.new(l__Config__17.Path);
                        end;
                    end, function(p58) --[[ Line: 400 ]]
                        -- upvalues: l__CamoUpsells__21 (copy), u34 (copy)
                        for _, v59 in l__CamoUpsells__21 do
                            if #v59.FullNamePath == 0 then
                                p58:EditMetaData({
                                    Camo = v59.CamoPath[#v59.CamoPath]
                                });
                            else
                                local v60 = p58:GetChild(unpack(v59.FullNamePath));
                                if v60 then
                                    v60:EditMetaData({
                                        Camo = v59.CamoPath[#v59.CamoPath]
                                    });
                                end;
                            end;
                        end;
                        local v61 = p58.ParentModel:Clone();
                        u34._model = v61;
                        return v61;
                    end);
                    local v62 = 0;
                    for _, v63 in l__CamoUpsells__21 do
                        if v63.Price and not v63.Unlocked then
                            v62 = v62 + v63.Price;
                        end;
                    end;
                    v45("APPLY FULL SET" .. (v62 <= 0 and "" or " (" .. u5(v62) .. ")"), function() --[[ Line: 430 ]]
                        -- upvalues: l__CamoUpsells__21 (copy), l__props__11 (copy)
                        for v64, v65 in l__CamoUpsells__21 do
                            l__props__11.ChangeComponent(v64 == #l__CamoUpsells__21, v65.TargetPath, v65, false);
                        end;
                    end);
                end;
                local l__Path__24 = l__Config__17.Path;
                if #l__Path__24 == 3 and (l__Path__24[2] == "Receiver" and (not l__Config__17.IsCamo and l___component__16.Owned)) then
                    v45("RESET WEAPON BUILD", function() --[[ Line: 439 ]]
                        -- upvalues: l__props__11 (copy), l__Config__17 (copy), l__Path__24 (copy)
                        l__props__11.ResetBuild(l__Config__17.Name, false, l__Path__24[#l__Path__24]);
                    end);
                    if not l__props__11.CartOpen then
                        v45("PASTE FROM LOADOUT", function() --[[ Line: 443 ]]
                            -- upvalues: l__props__11 (copy), l__Path__24 (copy)
                            l__props__11.PasteFrom(l__Path__24[#l__Path__24]);
                        end);
                    end;
                end;
                if l__Config__17.Loadout then
                    v45("RENAME", function() --[[ Line: 450 ]]
                        -- upvalues: l__props__11 (copy), l__Config__17 (copy), l___component__16 (copy)
                        l__props__11.RenameLoadout(l__Config__17.LoadoutIndex, l___component__16.Button);
                    end);
                    v45("DELETE", function() --[[ Line: 453 ]]
                        -- upvalues: l__props__11 (copy), l__Config__17 (copy)
                        l__props__11.DeleteLoadout(l__Config__17.LoadoutIndex);
                    end);
                end;
                if u41 ~= u39 + l__TagTextSize__18 or u42.Price then
                    u41 = u41 + u39;
                    u34._height = u41;
                    return u2.createElement("Frame", {
                        ClipsDescendants = true,
                        BorderSizePixel = 0,
                        BackgroundTransparency = u37,
                        BackgroundColor3 = Color3.new(),
                        BorderColor3 = Color3.new(),
                        Position = l___position__15:map(function(p66) --[[ Line: 471 ]]
                            return UDim2.new(1, 0, 0, p66);
                        end),
                        Size = UDim2.new(0.8, 0, 0, u41)
                    }, {
                        u2.createFragment(u42),
                        Gradient = u2.createElement("UIGradient", {
                            Rotation = -30,
                            Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.5625), NumberSequenceKeypoint.new(1, 0.30625) })
                        })
                    });
                end;
            end;
        end;
    end;
end;
return v11;