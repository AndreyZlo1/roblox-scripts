-- Services.InterfaceService.MenuInterface.MenuReduxLoadoutComponent.MenuReduxLoadoutShoppingCartComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "frc");
local u3 = v1("StatsService");
local u4 = v1("RoactTween");
local u5 = v1("skipLevel");
local u6 = v1("formatNumber");
local u7 = v1("GameShellProxyButton");
local u8 = v1("GameShellProxyGlobals");
local u9 = v1("MenuButtonComponent");
local v10 = u2.Component:extend("MenuReduxLoadoutShoppingCart");
function v10.init(p11, _) --[[ Line: 16 ]]
    -- upvalues: u4 (copy)
    p11.Open = u4.new(0);
    p11.Discard = u4.new(1);
    p11.Purchase = u4.new(0);
    p11.Discard:SetGoal(0);
    p11.Open:SetGoal(1);
end;
function v10.render(p12) --[[ Line: 25 ]]
    -- upvalues: u8 (copy), u5 (copy), u3 (copy), u2 (copy), u6 (copy), u7 (copy), u9 (copy)
    local l__props__1 = p12.props;
    local l__ApplyQueue__2 = l__props__1.ApplyQueue;
    local l__PopupActive__3 = l__props__1.PopupActive;
    local l__Open__4 = p12.Open;
    local l__Discard__5 = p12.Discard;
    local l__TagTextSize__6 = u8.Sizes.TagTextSize;
    local l__LineThickness__7 = u8.Sizes.LineThickness;
    local v13 = 0;
    local v14 = {};
    local v15 = 0.08;
    for _, v16 in l__ApplyQueue__2 do
        if not v16.Owned and v16.Config then
            local v17 = u5(u3.Level, v16.Config.Level or 0, v16.Config.Price or 0);
            if v17 ~= 0 then
                v13 = v13 + v17;
                local l__Name__8 = v16.Config.Name;
                if v16.IsCamo then
                    l__Name__8 = "> " .. l__Name__8;
                end;
                v14[#v14 + 1] = u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.fromScale(0, v15),
                    Size = UDim2.fromScale(1, 0.06)
                }, {
                    Background = u2.createElement("Frame", {
                        BackgroundTransparency = 0.5,
                        BorderSizePixel = 0,
                        ClipsDescendants = true,
                        BackgroundColor3 = Color3.new(),
                        BorderColor3 = Color3.new(),
                        Size = UDim2.fromScale(1, 1)
                    }, {
                        Gradient = u2.createElement("UIGradient", {
                            Rotation = -90,
                            Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.8) })
                        }),
                        Title = u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            TextScaled = true,
                            TextTransparency = 0.5,
                            FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
                            AnchorPoint = Vector2.new(0, 0.5),
                            Position = UDim2.new(0, l__TagTextSize__6, 0.5, 0),
                            Size = UDim2.new(1, 0, 0, l__TagTextSize__6),
                            Text = l__Name__8,
                            TextColor3 = Color3.fromRGB(239, 239, 239),
                            TextXAlignment = Enum.TextXAlignment.Left
                        }),
                        Price = u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            TextScaled = true,
                            FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
                            AnchorPoint = Vector2.new(0, 0.5),
                            Position = UDim2.new(0, 0, 0.5, 0),
                            Size = UDim2.new(1, -l__TagTextSize__6, 0, l__TagTextSize__6),
                            Text = u6(v17),
                            TextColor3 = u8.Colors.Price,
                            TextXAlignment = Enum.TextXAlignment.Right
                        })
                    }),
                    Line = u2.createElement("Frame", {
                        BackgroundTransparency = 0.5,
                        BorderSizePixel = 0,
                        ZIndex = 2,
                        AnchorPoint = Vector2.new(0, 1),
                        BackgroundColor3 = Color3.fromRGB(239, 239, 239),
                        BorderColor3 = Color3.new(),
                        Position = UDim2.fromScale(0, 1),
                        Size = UDim2.new(1, 0, 0, l__LineThickness__7)
                    })
                });
                v15 = v15 + 0.06;
            end;
        end;
    end;
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        ZIndex = 3,
        AnchorPoint = Vector2.new(1, 0),
        Position = UDim2.fromScale(1, 0),
        Size = UDim2.fromScale(0.5, 1),
        SizeConstraint = Enum.SizeConstraint.RelativeYY
    }, {
        Header = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0, 0),
            BackgroundColor3 = l__Open__4:Map(function(p18) --[[ Line: 139 ]]
                return Color3.new(1, 1, 1):Lerp(Color3.new(), p18);
            end),
            Position = UDim2.fromScale(0, 0),
            Size = UDim2.fromScale(1, 0.08)
        }, {
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                ScaleType = Enum.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Title = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "SHOPPING CART",
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
                    Position = UDim2.fromScale(0.1, 0.5),
                    Size = UDim2.fromScale(0.9, 0.4),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = Enum.TextXAlignment.Left
                }),
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 139,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                })
            }),
            Discard = u2.createElement(u7, {
                BackgroundTransparency = 1,
                ZIndex = 10,
                SoundKit = "MainMenu",
                Position = UDim2.fromScale(0.8, 0),
                Size = UDim2.fromScale(0.2, 1),
                Ignore = l__PopupActive__3,
                MouseUp = function() --[[ Name: MouseUp, Line 187 ]]
                    -- upvalues: l__props__1 (copy)
                    l__props__1.Discard();
                end,
                MouseEnter = function() --[[ Name: MouseEnter, Line 190 ]]
                    -- upvalues: l__Discard__5 (copy)
                    l__Discard__5:SetGoal(1);
                end,
                MouseLeave = function() --[[ Name: MouseLeave, Line 193 ]]
                    -- upvalues: l__Discard__5 (copy)
                    l__Discard__5:SetGoal(0);
                end
            }, {
                ArrowBottom = u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Rotation = -45,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Position = UDim2.fromScale(0.4, 0.5),
                    Size = UDim2.new(1, 0, 0, l__LineThickness__7),
                    SizeConstraint = Enum.SizeConstraint.RelativeYY
                }, {
                    White = u2.createElement("Frame", {
                        BorderSizePixel = 0,
                        AnchorPoint = Vector2.new(0.5, 0),
                        BackgroundColor3 = Color3.new(1, 1, 1),
                        BorderColor3 = Color3.new(),
                        Position = UDim2.fromScale(0.5, 0),
                        Size = l__Discard__5:Map(function(p19) --[[ Line: 211 ]]
                            return UDim2.fromScale(p19 * 0.2 + 0.5, 1);
                        end)
                    })
                }),
                ArrowTop = u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Rotation = 45,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Position = UDim2.fromScale(0.4, 0.5),
                    Size = UDim2.new(1, 0, 0, l__LineThickness__7),
                    SizeConstraint = Enum.SizeConstraint.RelativeYY
                }, {
                    White = u2.createElement("Frame", {
                        BorderSizePixel = 0,
                        AnchorPoint = Vector2.new(0.5, 0),
                        BackgroundColor3 = Color3.new(1, 1, 1),
                        BorderColor3 = Color3.new(),
                        Position = UDim2.fromScale(0.5, 0),
                        Size = l__Discard__5:Map(function(p20) --[[ Line: 230 ]]
                            return UDim2.fromScale(p20 * 0.2 + 0.5, 1);
                        end)
                    })
                })
            })
        }),
        Footer = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0, 0),
            BackgroundColor3 = l__Open__4:Map(function(p21) --[[ Line: 239 ]]
                return Color3.new(1, 1, 1):Lerp(Color3.new(), p21);
            end),
            Position = UDim2.fromScale(0, (math.min(v15, 0.92))),
            Size = UDim2.fromScale(1, 0.08)
        }, {
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                ImageColor3 = Color3.fromRGB(71, 71, 71),
                ScaleType = Enum.ScaleType.Tile,
                Size = UDim2.fromScale(1, 1),
                TileSize = UDim2.fromOffset(6, 6)
            }, {
                Title = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
                    Position = UDim2.fromScale(0, 0.5),
                    Size = UDim2.new(1, -l__TagTextSize__6, 0.4, 0),
                    Text = u6(v13),
                    TextColor3 = u8.Colors.Price,
                    TextXAlignment = Enum.TextXAlignment.Right
                }),
                Purchase = u2.createElement(u9, {
                    Name = "PURCHASE",
                    ZIndex = 10,
                    Ignore = l__PopupActive__3,
                    Size = UDim2.fromScale(0.35, 0.6),
                    Position = UDim2.new(0, l__TagTextSize__6, 0.5, 0),
                    AnchorPoint = Vector2.new(0, 0.5),
                    Callback = function() --[[ Name: Callback, Line 276 ]]
                        -- upvalues: l__props__1 (copy)
                        l__props__1.Purchase();
                    end
                }),
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 139,
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
                })
            })
        }),
        u2.createFragment(v14)
    });
end;
return v10;