-- Services.InterfaceService.MenuInterface.MenuInteractiveMapComponent.MenuInteractiveMapDeployComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "network");
local u4 = v1("RoactTween");
local u5 = v1("StatsService");
local u6 = v1("GameShellProxyButton");
local u7 = v1("PopupInterface");
local u8 = v1("LandingInterface");
local l__RunService__1 = game:GetService("RunService");
local u9 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u10 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local v11 = u2.Component:extend("MenuInteractiveMapDeploy");
function v11.init(u12, _) --[[ Line: 17 ]]
    -- upvalues: u2 (copy), l__RunService__1 (copy), u4 (copy)
    local v13, v14 = u2.createBinding(0);
    u12.CircleBinding = v13;
    u12.UpdateCircle = v14;
    u12.Update = l__RunService__1.Heartbeat:Connect(function(_) --[[ Line: 19 ]]
        -- upvalues: u12 (copy)
        local l__UpdateCircle__2 = u12.UpdateCircle;
        local v15 = tick() * 3;
        l__UpdateCircle__2((math.sin(v15) + 1) / 2);
    end);
    u12.Deploying = false;
    u12.Hover = u4.new(0);
end;
function v11.willUnmount(p16) --[[ Line: 26 ]]
    p16.Update:Disconnect();
end;
function v11.render(u17) --[[ Line: 30 ]]
    -- upvalues: u5 (copy), u2 (copy), u6 (copy), u7 (copy), u8 (copy), u3 (copy), u9 (copy), u10 (copy)
    local l__props__3 = u17.props;
    local l__Position__4 = l__props__3.Position;
    local u18 = l__props__3.Level > u5.Level;
    return u2.createElement(u6, {
        BackgroundTransparency = 1,
        Position = l__Position__4,
        Size = l__props__3.Size,
        AnchorPoint = Vector2.new(0.5, 0.5),
        Ignore = l__props__3.PopupActive,
        MouseEnter = function() --[[ Name: MouseEnter, Line 42 ]]
            -- upvalues: u17 (copy)
            u17.Hover:SetGoal(1);
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 45 ]]
            -- upvalues: u17 (copy)
            u17.Hover:SetGoal(0);
        end,
        MouseUp = function() --[[ Name: MouseUp, Line 48 ]]
            -- upvalues: u18 (copy), u7 (ref), l__props__3 (copy), u17 (copy), u8 (ref), u3 (ref)
            if u18 then
                u7:Open("Location Unavailable", "You must be atleast level " .. l__props__3.Level .. " to deploy at this location.", {
                    { "Close", function() --[[ Line: 51 ]]
                            -- upvalues: u7 (ref)
                            u7:Close();
                        end }
                });
            elseif u17.Deploying then
            else
                u17.Deploying = true;
                u8:Message("Deploying Character");
                task.delay(0.5, function() --[[ Line: 63 ]]
                    -- upvalues: u3 (ref), l__props__3 (ref), u17 (ref)
                    u3:FireServer("DeployCharacter", l__props__3.Location);
                    u17.Deploying = false;
                end);
            end;
        end
    }, {
        u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ClipsDescendants = true,
            Position = UDim2.fromScale(1.6, 0),
            Size = UDim2.fromScale(5, 1)
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.5),
                Position = u17.Hover:Map(function(p19) --[[ Line: 78 ]]
                    return UDim2.fromScale(p19 + -1, 0);
                end),
                Text = u18 and "LOCATION UNAVAILABLE" or "DEPLOY HERE",
                TextColor3 = Color3.fromRGB(255, 194, 89),
                TextXAlignment = Enum.TextXAlignment.Left,
                FontFace = u9
            }), u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.5),
                Position = u17.Hover:Map(function(p20) --[[ Line: 90 ]]
                    return UDim2.fromScale(p20 + -1, 0.5);
                end),
                Text = u18 and "YOU MUST BE LEVEL " .. l__props__3.Level or l__props__3.Name:upper(),
                TextColor3 = Color3.fromRGB(255, 194, 89),
                TextXAlignment = Enum.TextXAlignment.Left,
                FontFace = u10
            }) }),
        u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0.5, 0.5),
            BackgroundColor3 = Color3.fromRGB(255, 194, 89),
            BackgroundTransparency = u17.CircleBinding:map(function(p21) --[[ Line: 104 ]]
                return p21 / 2 + 0.5;
            end),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = u17.CircleBinding:map(function(p22) --[[ Line: 108 ]]
                return UDim2.fromScale(p22 * 3 + 0.5, p22 * 3 + 0.5);
            end)
        }, { u2.createElement("UICorner", {
                CornerRadius = UDim.new(0.5, 0)
            }) }),
        u18 and u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://15595203751",
            ZIndex = 2,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = u17.Hover:Map(function(p23) --[[ Line: 121 ]]
                local v24 = p23 / 3;
                return UDim2.fromScale(1 - v24, 1 - v24);
            end),
            ImageColor3 = Color3.fromRGB(255, 194, 89),
            ImageTransparency = u17.Hover:Map(function(p25) --[[ Line: 127 ]]
                return 1 - p25;
            end)
        }) or u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = u17.Hover:Map(function(p26) --[[ Line: 135 ]]
                local v27 = p26 / 3;
                return UDim2.fromScale(1 - v27, 1 - v27);
            end)
        }, { u2.createElement("Frame", {
                BorderSizePixel = 0,
                Rotation = 45,
                AnchorPoint = Vector2.new(0.5, 0.5),
                BackgroundTransparency = u17.Hover:Map(function(p28) --[[ Line: 143 ]]
                    return 1 - p28;
                end),
                BackgroundColor3 = Color3.fromRGB(255, 194, 89),
                Position = UDim2.fromScale(0.5, 0.5),
                Size = UDim2.fromScale(1, 0.2)
            }), u2.createElement("Frame", {
                BorderSizePixel = 0,
                Rotation = -45,
                AnchorPoint = Vector2.new(0.5, 0.5),
                BackgroundTransparency = u17.Hover:Map(function(p29) --[[ Line: 154 ]]
                    return 1 - p29;
                end),
                BackgroundColor3 = Color3.fromRGB(255, 194, 89),
                Position = UDim2.fromScale(0.5, 0.5),
                Size = UDim2.fromScale(1, 0.2)
            }) }),
        u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = u17.Hover:Map(function(p30) --[[ Line: 168 ]]
                local v31 = p30 / 2;
                return UDim2.fromScale(v31 + 1, v31 + 1);
            end)
        }, {
            u2.createElement("Frame", {
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 0),
                BackgroundColor3 = Color3.fromRGB(255, 194, 89),
                Position = UDim2.fromScale(0, 0),
                Size = UDim2.fromScale(0.3, 0.1)
            }),
            u2.createElement("Frame", {
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(1, 0),
                BackgroundColor3 = Color3.fromRGB(255, 194, 89),
                Position = UDim2.fromScale(1, 0),
                Size = UDim2.fromScale(0.3, 0.1)
            }),
            u2.createElement("Frame", {
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(255, 194, 89),
                Position = UDim2.fromScale(0, 1),
                Size = UDim2.fromScale(0.3, 0.1)
            }),
            u2.createElement("Frame", {
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(1, 1),
                BackgroundColor3 = Color3.fromRGB(255, 194, 89),
                Position = UDim2.fromScale(1, 1),
                Size = UDim2.fromScale(0.3, 0.1)
            }),
            u2.createElement("Frame", {
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 0),
                BackgroundColor3 = Color3.fromRGB(255, 194, 89),
                Position = UDim2.fromScale(0, 0),
                Size = UDim2.fromScale(0.1, 0.3)
            }),
            u2.createElement("Frame", {
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(1, 0),
                BackgroundColor3 = Color3.fromRGB(255, 194, 89),
                Position = UDim2.fromScale(1, 0),
                Size = UDim2.fromScale(0.1, 0.3)
            }),
            u2.createElement("Frame", {
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.fromRGB(255, 194, 89),
                Position = UDim2.fromScale(0, 1),
                Size = UDim2.fromScale(0.1, 0.3)
            }),
            u2.createElement("Frame", {
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(1, 1),
                BackgroundColor3 = Color3.fromRGB(255, 194, 89),
                Position = UDim2.fromScale(1, 1),
                Size = UDim2.fromScale(0.1, 0.3)
            })
        })
    });
end;
return v11;