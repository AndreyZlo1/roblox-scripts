-- Services.InterfaceService.MenuInterface.MenuInteractiveMapComponent.MenuInteractiveMapMarkerComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "network");
local u4 = v1("RoactTween");
local u5 = v1("GameShellProxyButton");
local v6 = u2.Component:extend("MenuMap");
function v6.init(p7, p8) --[[ Line: 8 ]]
    -- upvalues: u4 (copy)
    p7:setState({
        Hovering = false
    });
    p7.Position = p8.Position;
    p7.Hover = u4.new(0);
    p7.Click = u4.new(1);
end;
function v6.render(u9) --[[ Line: 17 ]]
    -- upvalues: u2 (copy), u5 (copy), u3 (copy)
    local v10 = u9.state.Hovering and Color3.fromRGB(255, 194, 89) or Color3.new(1, 1, 1);
    local l__props__1 = u9.props;
    local l__createElement__2 = u2.createElement;
    local v11 = u5;
    local v13 = {
        BackgroundTransparency = 1,
        LayoutOrder = l__props__1.Index,
        Size = UDim2.fromScale(1, 1),
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        Ignore = l__props__1.Ignore,
        MouseUp = function() --[[ Name: MouseUp, Line 28 ]]
            -- upvalues: u9 (copy), u3 (ref), l__props__1 (copy)
            u9.Click:SetValue(0);
            u9.Click:SetGoal(1);
            local v12 = u9.Position:getValue();
            u3:FireServer("PlaceMarker", l__props__1.Index, v12.X, v12.Y);
        end,
        MouseEnter = function() --[[ Name: MouseEnter, Line 35 ]]
            -- upvalues: u9 (copy)
            u9.Hover:SetGoal(1);
            u9:setState({
                Hovering = true
            });
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 41 ]]
            -- upvalues: u9 (copy)
            u9.Hover:SetGoal(0);
            u9:setState({
                Hovering = false
            });
        end
    };
    local v14 = {};
    local v17 = u2.createElement("Frame", {
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(0.5, 0.5),
        BackgroundColor3 = v10,
        BackgroundTransparency = u9.Click:Map(function(p15) --[[ Line: 52 ]]
            return p15 / 2 + 0.5;
        end),
        Position = UDim2.fromScale(0.5, 0.5),
        Size = u9.Click:Map(function(p16) --[[ Line: 56 ]]
            return UDim2.fromScale(p16 * 3 + 0.5, p16 * 3 + 0.5);
        end)
    }, { u2.createElement("UICorner", {
            CornerRadius = UDim.new(0.5, 0)
        }) });
    local v19 = u2.createElement("ImageLabel", {
        BackgroundTransparency = 1,
        ZIndex = 2,
        Position = UDim2.fromScale(0.5, 0.5),
        AnchorPoint = Vector2.new(0.5, 0.5),
        Size = u9.Hover:Map(function(p18) --[[ Line: 67 ]]
            return UDim2.fromScale(0.6 - p18 / 7, 0.6 - p18 / 7);
        end),
        Image = l__props__1.Icon or "",
        ImageColor3 = v10
    });
    local l__createElement__3 = u2.createElement;
    local v20 = "Frame";
    local v23 = {
        BackgroundTransparency = 1,
        ZIndex = 2,
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.fromScale(0.5, 0.5),
        Size = u9.Hover:Map(function(p21) --[[ Line: 79 ]]
            local v22 = p21 / 2;
            return UDim2.fromScale(v22 + 1, v22 + 1);
        end)
    };
    local v24 = {};
    local v25 = u2.createElement("Frame", {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(0, 0),
        BackgroundColor3 = v10,
        Position = UDim2.fromScale(0, 0),
        Size = UDim2.fromScale(0.3, 0.1)
    });
    local v26 = u2.createElement("Frame", {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(1, 0),
        BackgroundColor3 = v10,
        Position = UDim2.fromScale(1, 0),
        Size = UDim2.fromScale(0.3, 0.1)
    });
    local v27 = u2.createElement("Frame", {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(0, 1),
        BackgroundColor3 = v10,
        Position = UDim2.fromScale(0, 1),
        Size = UDim2.fromScale(0.3, 0.1)
    });
    local v28 = u2.createElement("Frame", {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(1, 1),
        BackgroundColor3 = v10,
        Position = UDim2.fromScale(1, 1),
        Size = UDim2.fromScale(0.3, 0.1)
    });
    local v29 = u2.createElement("Frame", {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(0, 0),
        BackgroundColor3 = v10,
        Position = UDim2.fromScale(0, 0),
        Size = UDim2.fromScale(0.1, 0.3)
    });
    local v30 = u2.createElement("Frame", {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(1, 0),
        BackgroundColor3 = v10,
        Position = UDim2.fromScale(1, 0),
        Size = UDim2.fromScale(0.1, 0.3)
    });
    local v31 = u2.createElement("Frame", {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(0, 1),
        BackgroundColor3 = v10,
        Position = UDim2.fromScale(0, 1),
        Size = UDim2.fromScale(0.1, 0.3)
    });
    local v32 = u2.createElement("Frame", {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(1, 1),
        BackgroundColor3 = v10,
        Position = UDim2.fromScale(1, 1),
        Size = UDim2.fromScale(0.1, 0.3)
    });
    local v33;
    if l__props__1.Index == 0 then
        v33 = u2.createElement("Frame", {
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            Rotation = -45,
            AnchorPoint = Vector2.new(0.5, 0.5),
            BackgroundColor3 = v10,
            Position = UDim2.fromScale(0.5, 0.5),
            Size = UDim2.fromScale(0.1, 1.2)
        });
    else
        v33 = false;
    end;
    v24[1], v24[2], v24[3], v24[4], v24[5], v24[6], v24[7], v24[8], v24[9] = v25, v26, v27, v28, v29, v30, v31, v32, v33;
    v14[1], v14[2], v14[3] = v17, v19, l__createElement__3(v20, v23, v24);
    return l__createElement__2(v11, v13, v14);
end;
return v6;