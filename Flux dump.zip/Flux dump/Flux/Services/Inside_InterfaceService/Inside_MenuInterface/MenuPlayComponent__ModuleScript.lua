-- Services.InterfaceService.MenuInterface.MenuPlayComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "network");
local u4 = v1("PostProcessingService");
local u5 = v1("PopupInterface");
local u6 = v1("Patchnotes");
local u7 = v1("GameShellProxyScroller");
local u8 = v1("RoactTween");
local u9 = v1("CompanyConfig");
local u10 = v1("versionToNumber");
local u11 = v1("StatsService");
local u12 = v1("SoundService");
local u13 = v1("PlaceService");
local u14 = v1("InputService");
local u15 = v1("MenuButtonComponent");
local u16 = v1("MenuGamemodeComponent");
local u17 = v1("MenuGamemodeReturnComponent");
local u18 = v1("MenuGamemodeCardComponent");
local u19 = v1("MenuPrivateServerComponent");
local u20 = v1("MenuServerBrowserComponent");
local u21 = v1("MenuPlayerFriendComponent");
local u22 = v1("MenuPlayerOptionComponent");
local u23 = v1("MenuPlayerPatchComponent");
local v24 = u2.Component:extend("MenuPlayers");
local l__GuiService__1 = game:GetService("GuiService");
local l__Players__2 = game:GetService("Players");
local l__UserInputService__3 = game:GetService("UserInputService");
local l__RunService__4 = game:GetService("RunService");
local l__LocalPlayer__5 = l__Players__2.LocalPlayer;
local u25 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u26 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u42 = {
    Openworld = {
        {
            Image = "rbxassetid://71684578067957",
            HoverImage = "rbxassetid://71684578067957",
            Name = "Ronograd",
            Players = "25 Players",
            Banner = "11 NEW MISSIONS",
            ServerBrowser = "OW_Ronograd",
            Callback = function(u27) --[[ Name: Callback, Line 51 ]]
                -- upvalues: u5 (copy)
                local v28 = true;
                for _, v29 in u27.props.MatchmakingQueueData.CurrentLobby do
                    if not v29.VoiceChat then
                        v28 = false;
                        break;
                    end;
                end;
                if v28 then
                    u5:Open("Voice-chat Only", "Would you like to join a voice-chat only server?\n\nIt is recommended to only join if you have a microphone to communicate.", {
                        { "Yes", function() --[[ Line: 62 ]]
                                -- upvalues: u27 (copy), u5 (ref)
                                u27.JoinPlace("OW_Ronograd", true);
                                u5:Close();
                            end },
                        { "No", function() --[[ Line: 66 ]]
                                -- upvalues: u27 (copy), u5 (ref)
                                u27.JoinPlace("OW_Ronograd");
                                u5:Close();
                            end },
                        { "Cancel", function() --[[ Line: 70 ]]
                                -- upvalues: u5 (ref)
                                u5:Close();
                            end }
                    });
                else
                    u27.JoinPlace("OW_Ronograd");
                end;
            end
        },
        {
            Image = "rbxassetid://72426062526557",
            HoverImage = "rbxassetid://72426062526557",
            Name = "Zombies",
            Players = "2 MODES AVAILABLE",
            ButtonText = "VIEW MODES",
            Callback = function(p30) --[[ Name: Callback, Line 85 ]]
                p30.SetSubPage("Zombies");
            end
        }
    },
    Zombies = {
        {
            Image = "rbxassetid://129733022034006",
            HoverImage = "rbxassetid://129733022034006",
            Name = "Survival",
            Players = "Player vs. Player",
            Banner = "EXPERIMENTAL (ALPHA)",
            ButtonText = "QUICK PLAY",
            Callback = function(u31) --[[ Name: Callback, Line 97 ]]
                -- upvalues: u5 (copy)
                u5:Open("Experimental Mode", "This mode is still in Alpha. Expect bugs.\n\nPlease choose your server type:\nFIRST PERSON - First person camera only\nTHIRD PERSON - Mixed first and third person camera", {
                    { "First Person", function() --[[ Line: 99 ]]
                            -- upvalues: u31 (copy), u5 (ref)
                            u31.JoinPlace("ZMP_NYC", false, false);
                            u5:Close();
                        end },
                    { "Third Person", function() --[[ Line: 103 ]]
                            -- upvalues: u31 (copy), u5 (ref)
                            u31.JoinPlace("ZMP_NYC", false, true);
                            u5:Close();
                        end },
                    { "Cancel", function() --[[ Line: 107 ]]
                            -- upvalues: u5 (ref)
                            u5:Close();
                        end }
                });
            end
        },
        {
            Image = "rbxassetid://100808592328405",
            HoverImage = "rbxassetid://100808592328405",
            Name = "Rescue",
            Players = "Player vs. Zombies",
            ServerBrowser = "ZME_NYC",
            Callback = function(u32) --[[ Name: Callback, Line 120 ]]
                -- upvalues: u5 (copy)
                local v33 = true;
                for _, v34 in u32.props.MatchmakingQueueData.CurrentLobby do
                    if not v34.VoiceChat then
                        v33 = false;
                        break;
                    end;
                end;
                if v33 then
                    u5:Open("Voice-chat Only", "Would you like to join a voice-chat only server?\n\nIt is recommended to only join if you have a microphone to communicate.", {
                        { "Yes", function() --[[ Line: 131 ]]
                                -- upvalues: u32 (copy), u5 (ref)
                                u32.JoinPlace("ZME_NYC", true);
                                u5:Close();
                            end },
                        { "No", function() --[[ Line: 135 ]]
                                -- upvalues: u32 (copy), u5 (ref)
                                u32.JoinPlace("ZME_NYC");
                                u5:Close();
                            end },
                        { "Cancel", function() --[[ Line: 139 ]]
                                -- upvalues: u5 (ref)
                                u5:Close();
                            end }
                    });
                else
                    u32.JoinPlace("ZME_NYC");
                end;
            end
        }
    },
    Competitive = {
        {
            Image = "rbxassetid://126143709327791",
            HoverImage = "rbxassetid://126143709327791",
            Name = "2v2",
            Players = "Duo",
            Callback = function(p35) --[[ Name: Callback, Line 156 ]]
                p35.JoinQueue("Duo");
            end
        },
        {
            Image = "rbxassetid://81138960718309",
            HoverImage = "rbxassetid://81138960718309",
            Name = "5v5",
            Players = "Classic",
            ButtonText = "VIEW MODES",
            Callback = function(p36) --[[ Name: Callback, Line 165 ]]
                p36.SetSubPage("Classic");
            end
        },
        {
            Image = "rbxassetid://135147377956311",
            HoverImage = "rbxassetid://135147377956311",
            Name = "8v8",
            Players = "TDM",
            ServerBrowser = "PVP_Sandbox",
            Banner = "2 NEW MAPS",
            Callback = function(p37) --[[ Name: Callback, Line 175 ]]
                p37.JoinPlace("PVP_Sandbox");
            end
        }
    },
    Classic = {
        {
            Image = "rbxassetid://90578514757161",
            HoverImage = "rbxassetid://90578514757161",
            Name = "Ranked",
            Players = "9 rounds",
            Callback = function(u38) --[[ Name: Callback, Line 188 ]]
                -- upvalues: u5 (copy)
                u5:Open("Ranked match", "Ranked matches can last up to 10 rounds (up to 20 minutes)\nLeaving a ranked match will result in a suspension\n\nAre you sure you want to queue for ranked?", {
                    { "Yes", function() --[[ Line: 190 ]]
                            -- upvalues: u38 (copy), u5 (ref)
                            u38.JoinQueue("Ranked");
                            u5:Close();
                        end },
                    { "No", function() --[[ Line: 194 ]]
                            -- upvalues: u5 (ref)
                            u5:Close();
                        end }
                });
            end
        },
        {
            Image = "rbxassetid://81138960718309",
            HoverImage = "rbxassetid://81138960718309",
            Name = "Casual",
            Players = "5 rounds",
            Callback = function(p39) --[[ Name: Callback, Line 205 ]]
                p39.JoinQueue("Casual");
            end
        }
    },
    Missions = {
        {
            Image = "rbxassetid://91062598050655",
            HoverImage = "rbxassetid://91062598050655",
            Name = "Tutorial",
            Players = "1 Player",
            ButtonText = "LAUNCH MISSION",
            Callback = function(u40) --[[ Name: Callback, Line 217 ]]
                -- upvalues: u5 (copy)
                u5:Open("Launch Mission", "This tutorial is designed for new players.\n\nIt is recommened that all players complete the tutorial.", {
                    { "Yes", function() --[[ Line: 219 ]]
                            -- upvalues: u40 (copy), u5 (ref)
                            u40.JoinMission("CM_Mission1");
                            u5:Close();
                        end },
                    { "No", function() --[[ Line: 223 ]]
                            -- upvalues: u5 (ref)
                            u5:Close();
                        end }
                });
            end
        }
    },
    Survival = {
        {
            Image = "rbxassetid://11259109518",
            HoverImage = "rbxassetid://11259109518",
            Name = "Ronograd",
            Players = "5 Players",
            Callback = function(p41) --[[ Name: Callback, Line 236 ]]
                p41.JoinPlace("Survival");
            end
        }
    }
};
function v24.init(u43, p44) --[[ Line: 250 ]]
    -- upvalues: u12 (copy), u8 (copy), u2 (copy), u3 (copy), l__RunService__4 (copy), l__LocalPlayer__5 (copy), u14 (copy), l__UserInputService__3 (copy), l__GuiService__1 (copy), u4 (copy)
    u12:CreateSound("Button", nil, true, "UISounds", "PlayOpen").Destroy(10);
    u43.Blur = u8.new(0);
    function u43.SetSubPage(p45) --[[ Line: 255 ]]
        -- upvalues: u43 (copy)
        u43.Blur:SetGoal(p45 == "Home" and 0 or 1);
        u43:setState({
            RightBar = "Friend",
            Page = p45
        });
    end;
    u43.ScrollerRef = u2.createRef();
    local l__MatchmakingQueueData__6 = p44.MatchmakingQueueData;
    function u43.JoinQueue(p46) --[[ Line: 266 ]]
        -- upvalues: l__MatchmakingQueueData__6 (copy), u43 (copy), u3 (ref), u12 (ref)
        if l__MatchmakingQueueData__6.IsMatchmaking or l__MatchmakingQueueData__6.JoiningSession then
        else
            l__MatchmakingQueueData__6.MatchmakingQueue = p46;
            l__MatchmakingQueueData__6.MatchmakingStarted = tick();
            l__MatchmakingQueueData__6.IsMatchmaking = true;
            u43:setState({
                Page = "Home"
            });
            u3:FireServer("JoinQueueSession", p46);
            u12:CreateSound("Button", nil, true, "UISounds", "JoinQueue").Destroy(6);
        end;
    end;
    function u43.JoinMission(p47) --[[ Line: 282 ]]
        -- upvalues: l__MatchmakingQueueData__6 (copy), u43 (copy), u3 (ref)
        if l__MatchmakingQueueData__6.IsMatchmaking or l__MatchmakingQueueData__6.JoiningSession then
        else
            l__MatchmakingQueueData__6.JoiningSession = true;
            u43:setState({
                Page = "Home"
            });
            u3:FireServer("JoinMission", p47);
        end;
    end;
    function u43.JoinPlace(p48, p49, p50) --[[ Line: 292 ]]
        -- upvalues: l__MatchmakingQueueData__6 (copy), u43 (copy), u3 (ref)
        if l__MatchmakingQueueData__6.IsMatchmaking or l__MatchmakingQueueData__6.JoiningSession then
        else
            l__MatchmakingQueueData__6.JoiningSession = true;
            u43:setState({
                Page = "Home"
            });
            u3:FireServer("JoinOpenSession", p48, p49, p50);
        end;
    end;
    function u43.JoinSession(p51, p52) --[[ Line: 302 ]]
        -- upvalues: l__MatchmakingQueueData__6 (copy), u3 (ref)
        if l__MatchmakingQueueData__6.IsMatchmaking or l__MatchmakingQueueData__6.JoiningSession then
        else
            l__MatchmakingQueueData__6.JoiningSession = true;
            u3:FireServer("JoinServerSession", p51, p52);
        end;
    end;
    function u43.JoinHQ() --[[ Line: 310 ]]
        -- upvalues: l__MatchmakingQueueData__6 (copy), u43 (copy), u3 (ref)
        if l__MatchmakingQueueData__6.IsMatchmaking or l__MatchmakingQueueData__6.JoiningSession then
        else
            l__MatchmakingQueueData__6.JoiningSession = true;
            u43:setState({
                Page = "Home"
            });
            u3:FireServer("PrivateHQHost");
        end;
    end;
    u43.RightBackground = u8.new(0);
    u43.RightBackgroundRef = u2.createRef();
    local v53, u54 = u2.createBinding(0);
    u43._rightBackground = v53;
    u43._fade = 0;
    local l__PrivateServerData__7 = p44.PrivateServerData;
    u43.UpdateStart = tick();
    local v55, v56 = u2.createBinding(u43.UpdateStart);
    u43.UpdateBinding = v55;
    u43.UpdateUpdate = v56;
    u43.Update = l__RunService__4.Heartbeat:Connect(function(p57) --[[ Line: 330 ]]
        -- upvalues: u43 (copy), l__PrivateServerData__7 (copy), l__LocalPlayer__5 (ref), u14 (ref), l__UserInputService__3 (ref), u54 (copy), l__GuiService__1 (ref)
        local v58 = tick();
        u43.UpdateUpdate(v58);
        if not l__PrivateServerData__7.GetOnlineFriends or l__PrivateServerData__7.GetOnlineFriends < v58 then
            l__PrivateServerData__7.GetOnlineFriends = v58 + 35;
            local v59, v60 = pcall(l__LocalPlayer__5.GetFriendsOnlineAsync, l__LocalPlayer__5, 50);
            if v59 then
                l__PrivateServerData__7.OnlineFriends = v60;
                if u43.Update.Connected then
                    u43:setState({});
                end;
            end;
        end;
        local v61 = u43.RightBackgroundRef:getValue();
        if v61 then
            local v62 = u14.VirtualCursorPosition or l__UserInputService__3:GetMouseLocation();
            if u14.Gamepad or u14.Touch then
                u54(u43.RightBackground:GetValue());
                return;
            end;
            local l__AbsoluteSize__8 = v61.AbsoluteSize;
            local v63 = v61.AbsolutePosition + l__GuiService__1:GetGuiInset();
            local v64;
            if v62.X > v63.X and (v62.X < v63.X + l__AbsoluteSize__8.X and v62.Y > v63.Y) then
                v64 = v62.Y < v63.Y + l__AbsoluteSize__8.Y;
            else
                v64 = false;
            end;
            u43._fade = math.lerp(u43._fade, v64 and 1 or 0, p57 * 10);
            u54(u43._fade);
        end;
    end);
    u43.BlurEffect = u4:AddBlur({
        Size = u43.Blur:Map(function(p65) --[[ Line: 362 ]]
            return p65 * 30;
        end)
    }, nil, true);
    u43.SetSubPage("Home");
end;
function v24.willUnmount(p66) --[[ Line: 370 ]]
    p66.BlurEffect.Destroy();
    p66.Update:Disconnect();
end;
function v24.render(u67) --[[ Line: 375 ]]
    -- upvalues: u2 (copy), u25 (copy), u26 (copy), u15 (copy), u3 (copy), u13 (copy), u21 (copy), u6 (copy), u10 (copy), u23 (copy), u22 (copy), u9 (copy), u11 (copy), u7 (copy), u16 (copy), u5 (copy), u19 (copy), u20 (copy), u42 (copy), u17 (copy), u18 (copy)
    local l__Page__9 = u67.state.Page;
    local l__props__10 = u67.props;
    local l__PopupActive__11 = l__props__10.PopupActive;
    local l__MatchmakingQueueData__12 = l__props__10.MatchmakingQueueData;
    local v68;
    if l__MatchmakingQueueData__12.JoiningSession then
        u67.Blur:SetGoal(0);
        v68 = u2.createElement("ImageLabel", {
            BackgroundTransparency = 0.25,
            BorderSizePixel = 0,
            Image = "rbxassetid://13867939464",
            BackgroundColor3 = Color3.new(0, 0, 0),
            Position = UDim2.fromScale(0, 0.5),
            Size = UDim2.fromScale(1, 0.5),
            ImageColor3 = Color3.fromRGB(163, 121, 82),
            TileSize = UDim2.fromOffset(6, 6),
            ScaleType = Enum.ScaleType.Tile
        }, {
            Gradient = u2.createElement("UIGradient", {
                Rotation = 90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
            }),
            Header = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.08),
                Position = UDim2.fromScale(0, 0.5),
                Text = (l__MatchmakingQueueData__12.JoinMessage or "SEARCHING FOR AVAILABLE SERVER"):upper(),
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u25,
                TextXAlignment = Enum.TextXAlignment.Center
            }),
            Loading = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://15478256777",
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.7),
                Size = UDim2.fromScale(0.08, 0.08),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                Rotation = u67.UpdateBinding:map(function(p69) --[[ Line: 417 ]]
                    -- upvalues: u67 (copy)
                    return (u67.UpdateStart - p69) * 600;
                end),
                ImageColor3 = Color3.new(1, 1, 1)
            })
        });
    elseif l__MatchmakingQueueData__12.IsMatchmaking then
        u67.Blur:SetGoal(0);
        v68 = u2.createElement("ImageLabel", {
            BackgroundTransparency = 0.25,
            BorderSizePixel = 0,
            Image = "rbxassetid://13867939464",
            BackgroundColor3 = Color3.new(0, 0, 0),
            Position = UDim2.fromScale(0, 0.5),
            Size = UDim2.fromScale(1, 0.5),
            ImageColor3 = Color3.fromRGB(163, 82, 82),
            TileSize = UDim2.fromOffset(6, 6),
            ScaleType = Enum.ScaleType.Tile
        }, {
            Gradient = u2.createElement("UIGradient", {
                Rotation = 90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
            }),
            RedBall1 = u2.createElement("Frame", {
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                ZIndex = 3,
                AnchorPoint = Vector2.new(0.5, 0.5),
                BackgroundColor3 = Color3.fromRGB(255, 49, 49),
                Position = UDim2.fromScale(0.53, 0.61),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                Size = UDim2.fromScale(0.06, 0.06)
            }, {
                Corner = u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.5, 0)
                })
            }),
            RedBall2 = u2.createElement("Frame", {
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0.5, 0.5),
                BackgroundColor3 = Color3.fromRGB(115, 22, 22),
                Position = UDim2.fromScale(0.53, 0.61),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                Size = u67.UpdateBinding:map(function(p70) --[[ Line: 466 ]]
                    local v71 = math.sin(p70 * 3);
                    local v72 = math.abs(v71);
                    return UDim2.fromScale(v72 * 0.08 + 0.06, v72 * 0.08 + 0.06);
                end)
            }, {
                Corner = u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.5, 0)
                })
            }),
            RedBall3 = u2.createElement("Frame", {
                BackgroundTransparency = 0.75,
                BorderSizePixel = 0,
                ZIndex = 1,
                AnchorPoint = Vector2.new(0.5, 0.5),
                BackgroundColor3 = Color3.fromRGB(190, 37, 37),
                Position = UDim2.fromScale(0.53, 0.61),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                Size = u67.UpdateBinding:map(function(p73) --[[ Line: 483 ]]
                    local v74 = math.cos(p73 * 3);
                    local v75 = math.abs(v74);
                    return UDim2.fromScale(v75 * 0.05 + 0.1, v75 * 0.05 + 0.1);
                end)
            }, {
                Corner = u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.5, 0)
                })
            }),
            Header = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "SEARCHING FOR MATCH",
                TextScaled = true,
                Size = UDim2.fromScale(0.5, 0.08),
                Position = UDim2.fromScale(0, 0.5),
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u25,
                TextXAlignment = Enum.TextXAlignment.Right
            }),
            Match = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(0.5, 0.06),
                Position = UDim2.fromScale(0, 0.58),
                Text = l__MatchmakingQueueData__12.MatchmakingQueue:upper(),
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u26,
                TextXAlignment = Enum.TextXAlignment.Right
            }),
            Elapsed = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(0.5, 0.06),
                Position = UDim2.fromScale(0, 0.66),
                Text = u67.UpdateBinding:map(function(p76) --[[ Line: 517 ]]
                    -- upvalues: l__MatchmakingQueueData__12 (copy)
                    local v77 = p76 - l__MatchmakingQueueData__12.MatchmakingStarted;
                    local v78 = (v77 - v77 % 60) / 60;
                    return v78 - 0 .. ":" .. string.format("%02i", v77 - v78 * 60);
                end),
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u26,
                TextXAlignment = Enum.TextXAlignment.Right
            }),
            Cancel = u2.createElement(u15, {
                Name = "Cancel",
                Activated = false,
                AnchorPoint = Vector2.new(0, 0.5),
                Size = UDim2.fromScale(0.1, 0.1),
                Position = UDim2.fromScale(0.56, 0.61),
                Ignore = l__PopupActive__11,
                Loading = l__MatchmakingQueueData__12.CancellingQueue,
                Callback = function() --[[ Name: Callback, Line 534 ]]
                    -- upvalues: l__MatchmakingQueueData__12 (copy), u67 (copy), u3 (ref)
                    if l__MatchmakingQueueData__12.CancellingQueue then
                    else
                        l__MatchmakingQueueData__12.CancellingQueue = true;
                        u67:setState({});
                        u3:FireServer("CancelQueueSession");
                    end;
                end
            })
        });
    elseif l__Page__9 == "Home" then
        local v79 = {};
        local v80 = 15;
        local v81 = 0;
        local l__RightBar__13 = u67.state.RightBar;
        if l__RightBar__13 == "Friend" then
            for _, v82 in l__props__10.PrivateServerData.OnlineFriends or {} do
                local l__LocationType__14 = v82.LocationType;
                local v83 = nil;
                local v84 = u13:FromPlaceId(v82.PlaceId);
                if v84 then
                    local _, v85 = u13:GetPlace(v84);
                    v83 = v85 == 0 and "Main Menu" or (v85 == 1 and "Openworld" or (v85 == 2 and "Competitive" or (v85 == 3 and "Head Quarters" or (v85 == 4 and "Mission" or (v85 == 5 and "Zombies" or (v85 == 6 and "8v8 Competitive" or v83))))));
                end;
                v79[(v83 and "A" or ((l__LocationType__14 == 0 and true or l__LocationType__14 == 2) and "C" or (l__LocationType__14 == 3 and "D" or "B"))) .. v82.DisplayName] = u2.createElement(u21, {
                    Scroller = u67.ScrollerRef,
                    Friend = v82,
                    Here = v83,
                    Ignore = l__PopupActive__11,
                    Join = function(p86, p87) --[[ Name: Join, Line 584 ]]
                        -- upvalues: l__MatchmakingQueueData__12 (copy), u67 (copy), u3 (ref)
                        if l__MatchmakingQueueData__12.IsMatchmaking or l__MatchmakingQueueData__12.JoiningSession then
                        else
                            l__MatchmakingQueueData__12.JoiningSession = true;
                            u67:setState({
                                Page = "Home"
                            });
                            u3:FireServer("FollowUser", p86, p87);
                        end;
                    end,
                    Hover = u67.RightBackground
                });
                v81 = v81 + 1;
            end;
            v80 = math.max(15, v81);
            local v88 = 1 / v80;
            v79._Grid = u2.createElement("UIGridLayout", {
                CellPadding = UDim2.fromScale(0, v88 * 0.1),
                CellSize = UDim2.fromScale(1, v88 * 0.9),
                FillDirection = Enum.FillDirection.Vertical,
                HorizontalAlignment = Enum.HorizontalAlignment.Right,
                SortOrder = Enum.SortOrder.Name,
                StartCorner = Enum.StartCorner.TopRight,
                VerticalAlignment = Enum.VerticalAlignment.Bottom
            });
        elseif l__RightBar__13 == "Patch" then
            local v89 = {};
            for v90, v91 in u6 do
                local v92 = u10(v90);
                v89[#v89 + 1] = {
                    v92,
                    v90,
                    v91.Major,
                    v91.Sub
                };
            end;
            table.sort(v89, function(p93, p94) --[[ Line: 617 ]]
                return p93[1] > p94[1];
            end);
            for v95, v96 in v89 do
                v79["Patch_" .. v95] = u2.createElement(u23, {
                    Scroller = u67.ScrollerRef,
                    Order = v95,
                    Patch = v96,
                    Ignore = l__PopupActive__11,
                    Hover = u67.RightBackground
                });
                v81 = v81 + 1;
            end;
            v80 = math.max(15, v81);
            local v97 = 1 / v80;
            v79._Grid = u2.createElement("UIGridLayout", {
                CellPadding = UDim2.fromScale(0, v97 * 0.1),
                CellSize = UDim2.fromScale(1, v97 * 0.9),
                FillDirection = Enum.FillDirection.Vertical,
                HorizontalAlignment = Enum.HorizontalAlignment.Right,
                SortOrder = Enum.SortOrder.LayoutOrder,
                StartCorner = Enum.StartCorner.TopRight,
                VerticalAlignment = Enum.VerticalAlignment.Bottom
            });
        end;
        local v99 = u2.createElement("Frame", {
            AnchorPoint = Vector2.new(1, 1),
            Position = UDim2.fromScale(1, 1.13),
            Size = UDim2.fromScale(1, math.min(v81, 15) * 0.06666666666666667 + 0.14),
            BackgroundColor3 = Color3.fromRGB(16, 16, 16),
            BorderSizePixel = 0,
            BackgroundTransparency = u67._rightBackground:map(function(p98) --[[ Line: 651 ]]
                return 1 - p98;
            end),
            [u2.Ref] = u67.RightBackgroundRef
        }, {
            Stroke = u2.createElement("UIStroke", {
                Thickness = 1,
                ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                Color = Color3.fromRGB(79, 79, 79),
                LineJoinMode = Enum.LineJoinMode.Round
            }, {
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 0,
                    Transparency = NumberSequence.new({
                        NumberSequenceKeypoint.new(0, 0),
                        NumberSequenceKeypoint.new(0.2, 1),
                        NumberSequenceKeypoint.new(0.8, 1),
                        NumberSequenceKeypoint.new(1, 0)
                    })
                })
            }),
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                Position = UDim2.fromScale(0, 1),
                AnchorPoint = Vector2.new(0, 1),
                Size = UDim2.fromScale(1, 0.5),
                SizeConstraint = Enum.SizeConstraint.RelativeXX,
                ImageColor3 = Color3.fromRGB(168, 168, 168),
                TileSize = UDim2.fromOffset(6, 6),
                ScaleType = Enum.ScaleType.Tile
            }, {
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 90,
                    Transparency = NumberSequence.new({
                        NumberSequenceKeypoint.new(0, 1),
                        NumberSequenceKeypoint.new(0.4, 1),
                        NumberSequenceKeypoint.new(0.8, 0),
                        NumberSequenceKeypoint.new(1, 0)
                    })
                })
            }),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ZIndex = 2,
                Position = UDim2.fromScale(0, 1),
                AnchorPoint = Vector2.new(0, 1),
                Size = UDim2.fromScale(1, 0.2),
                SizeConstraint = Enum.SizeConstraint.RelativeXX
            }, {
                FriendButton = u2.createElement(u22, {
                    Image = "rbxassetid://73684922680281",
                    AnchorPoint = Vector2.new(1, 0),
                    Size = UDim2.fromScale(0.6, 0.6),
                    Position = UDim2.fromScale(0.9, 0),
                    Activated = l__RightBar__13 == "Friend",
                    Ignore = l__PopupActive__11,
                    Hover = u67.RightBackground,
                    Callback = function() --[[ Name: Callback, Line 709 ]]
                        -- upvalues: u67 (copy)
                        u67:setState({
                            RightBar = "Friend"
                        });
                    end
                }),
                PatchButton = u2.createElement(u22, {
                    Image = "rbxassetid://97883923915337",
                    AnchorPoint = Vector2.new(1, 0),
                    Size = UDim2.fromScale(0.6, 0.6),
                    Position = UDim2.fromScale(0.7, 0),
                    Activated = l__RightBar__13 == "Patch",
                    Ignore = l__PopupActive__11,
                    Hover = u67.RightBackground,
                    Callback = function() --[[ Name: Callback, Line 723 ]]
                        -- upvalues: u67 (copy)
                        u67:setState({
                            RightBar = "Patch"
                        });
                    end
                })
            })
        });
        local l__Image__15 = u9.Upgradeables[1].Levels[u11.Main].Image;
        v68 = u2.createFragment({
            Right = u2.createElement(u7, {
                BackgroundTransparency = 1,
                NoGradient = true,
                AnchorPoint = Vector2.new(1, 0),
                Position = UDim2.fromScale(0.92, 0.05),
                Size = UDim2.fromScale(0.35, 0.748),
                Children = { v99 },
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                Ref = u67.ScrollerRef,
                CanvasSize = v80 / 15,
                Content = v79
            }),
            Left = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Position = UDim2.fromScale(0.08, 0.05),
                Size = UDim2.fromScale(0.4, 0.85),
                SizeConstraint = Enum.SizeConstraint.RelativeYY
            }, {
                Openworld = u2.createElement(u16, {
                    Name = "Openworld",
                    Image = "rbxassetid://71531686577966",
                    Banner = "ADDED RONOGRAD MISSIONS",
                    Position = UDim2.fromScale(0, 0),
                    Size = UDim2.fromScale(1, 0.3),
                    Ignore = l__PopupActive__11,
                    Callback = function() --[[ Name: Callback, Line 759 ]]
                        -- upvalues: u67 (copy)
                        u67.SetSubPage("Openworld");
                    end
                }),
                Competitive = u2.createElement(u16, {
                    Name = "Competitive",
                    Image = "rbxassetid://139126293504728",
                    Position = UDim2.fromScale(0, 0.31),
                    Size = UDim2.fromScale(1, 0.2),
                    Ignore = l__PopupActive__11,
                    Callback = function() --[[ Name: Callback, Line 770 ]]
                        -- upvalues: u67 (copy)
                        u67.SetSubPage("Competitive");
                    end
                }),
                Missions = u2.createElement(u16, {
                    Name = "Missions",
                    Image = "rbxassetid://122750228308912",
                    Position = UDim2.fromScale(0, 0.52),
                    Size = UDim2.fromScale(1, 0.2),
                    Ignore = l__PopupActive__11,
                    Callback = function() --[[ Name: Callback, Line 780 ]]
                        -- upvalues: u67 (copy)
                        u67.SetSubPage("Missions");
                    end
                }),
                Base = u2.createElement(u16, {
                    Name = "Your Headquarters",
                    Position = UDim2.fromScale(0, 0.73),
                    Size = UDim2.fromScale(1, 0.2),
                    Image = l__Image__15,
                    Ignore = l__PopupActive__11,
                    Callback = function() --[[ Name: Callback, Line 790 ]]
                        -- upvalues: l__MatchmakingQueueData__12 (copy), u5 (ref), u67 (copy)
                        if l__MatchmakingQueueData__12.JoiningSession or l__MatchmakingQueueData__12.IsMatchmaking then
                        else
                            local v100 = "Are you sure you want to travel to your HQ with:";
                            for _, v101 in l__MatchmakingQueueData__12.CurrentLobby do
                                v100 = v100 .. "\n" .. v101.Username;
                            end;
                            u5:Open("Travel to private HQ", v100, {
                                { "Yes", function() --[[ Line: 801 ]]
                                        -- upvalues: u67 (ref), u5 (ref)
                                        u67.JoinHQ();
                                        u5:Close();
                                    end },
                                { "No", function() --[[ Line: 805 ]]
                                        -- upvalues: u5 (ref)
                                        u5:Close();
                                    end }
                            });
                        end;
                    end
                }),
                Custom = u2.createElement(u15, {
                    Name = "Custom Game",
                    Activated = false,
                    Size = UDim2.fromScale(1, 0.055),
                    Position = UDim2.fromScale(0, 0.94),
                    Ignore = l__PopupActive__11,
                    Callback = function() --[[ Name: Callback, Line 818 ]]
                        -- upvalues: u67 (copy)
                        u67.SetSubPage("Custom");
                    end
                })
            })
        });
    elseif l__Page__9 == "Custom" then
        v68 = u2.createElement(u19, {
            MatchmakingQueueData = l__props__10.MatchmakingQueueData,
            PrivateServerData = l__props__10.PrivateServerData,
            PopupActive = l__PopupActive__11,
            Return = function() --[[ Name: Return, Line 829 ]]
                -- upvalues: u67 (copy)
                u67.SetSubPage("Home");
            end
        });
    elseif l__Page__9 == "ServerBrowser" then
        v68 = u2.createElement(u20, {
            BrowserQueue = u67.BrowserQueue,
            JoinSession = u67.JoinSession,
            PopupActive = l__PopupActive__11,
            Return = function() --[[ Name: Return, Line 838 ]]
                -- upvalues: u67 (copy)
                u67.SetSubPage(u67.LastPage);
            end
        });
    else
        local v102 = u42[l__Page__9];
        local v103 = { u2.createElement(u17, {
                Ignore = l__PopupActive__11,
                Callback = function() --[[ Name: Callback, Line 847 ]]
                    -- upvalues: l__Page__9 (copy), u67 (copy)
                    if l__Page__9 == "Zombies" then
                        u67.SetSubPage("Openworld");
                    elseif l__Page__9 == "Classic" then
                        u67.SetSubPage("Competitive");
                    else
                        u67.SetSubPage("Home");
                    end;
                end
            }) };
        for v104, u105 in v102 do
            local v106 = v104 + 2;
            local l__createElement__16 = u2.createElement;
            local v107 = u18;
            local v108 = {
                Ignore = l__PopupActive__11,
                Name = u105.Name,
                Image = u105.Image,
                HoverImage = u105.HoverImage,
                Players = u105.Players,
                ButtonText = u105.ButtonText,
                Banner = u105.Banner
            };
            local l__ServerBrowser__17 = u105.ServerBrowser;
            v108.ServerBrowser = l__ServerBrowser__17 and function() --[[ Line: 867 ]]
                -- upvalues: u67 (copy), l__Page__9 (copy), u105 (copy)
                u67.LastPage = l__Page__9;
                u67.BrowserQueue = u105.ServerBrowser;
                u67.SetSubPage("ServerBrowser");
            end or l__ServerBrowser__17;
            function v108.Callback() --[[ Line: 872 ]]
                -- upvalues: u105 (copy), u67 (copy)
                u105.Callback(u67);
            end;
            v108.LayoutOrder = v104 + 2;
            v103[v106] = l__createElement__16(v107, v108);
        end;
        v68 = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0.5, 0),
            Position = UDim2.fromScale(0.5, 0.05),
            Size = UDim2.fromScale(0, 0.85)
        }, {
            Aspect = u2.createElement("UIAspectRatioConstraint", {
                AspectRatio = 2,
                AspectType = Enum.AspectType.ScaleWithParentSize,
                DominantAxis = Enum.DominantAxis.Height
            }),
            List = u2.createElement("UIListLayout", {
                Padding = UDim.new(0.01, 0),
                FillDirection = Enum.FillDirection.Horizontal,
                HorizontalAlignment = Enum.HorizontalAlignment.Left,
                SortOrder = Enum.SortOrder.LayoutOrder,
                VerticalAlignment = Enum.VerticalAlignment.Top
            }),
            u2.createFragment(v103)
        });
    end;
    return u2.createFragment(v68);
end;
return v24;