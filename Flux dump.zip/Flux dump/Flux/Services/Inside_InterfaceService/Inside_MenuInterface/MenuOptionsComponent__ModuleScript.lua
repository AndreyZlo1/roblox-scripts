-- Services.InterfaceService.MenuInterface.MenuOptionsComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local l__HttpService__1 = game:GetService("HttpService");
local v1, u2, _, u3 = shared.import("require", "Roact", "server", "network");
local u4 = v1("RoactTween");
local u5 = v1("SoundService");
local u6 = v1("InputService");
local u7 = v1("GameShellProxyScroller");
local u8 = v1("MenuButtonComponent");
local u9 = v1("MenuOptionsKeybindComponent");
local u10 = v1("MenuOptionsSliderComponent");
local u11 = v1("PopupInterface");
v1("InputBinds");
local u12 = v1("InputList");
local u13 = v1("GameSettings");
local u14 = v1("GameSettingsTemplate");
local v15 = u2.Component:extend("MenuStore");
local u16 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
function v15.init(u17, _) --[[ Line: 28 ]]
    -- upvalues: u5 (copy), u4 (copy), u6 (copy), u2 (copy)
    u5:CreateSound("Button", nil, true, "UISounds", "SettingsOpen").Destroy(10);
    u17.Landing = u4.new(0);
    u17.Landing:SetGoal(1);
    local function v21() --[[ Line: 35 ]]
        -- upvalues: u17 (copy), u6 (ref)
        local v18 = u17;
        local v19 = {
            Page = "Options"
        };
        local v20 = not u6.Gamepad;
        if v20 then
            v20 = not u6.Touch;
        end;
        v19.Keyboard = v20;
        v18:setState(v19);
    end;
    u17.Gamepad = u6.GamepadInput:Connect(v21);
    u17.Touch = u6.TouchInput:Connect(v21);
    u17.ScrollerRef = u2.createRef();
    local v22 = not u6.Gamepad;
    if v22 then
        v22 = not u6.Touch;
    end;
    u17:setState({
        Page = "Options",
        Keyboard = v22
    });
end;
function v15.willUnmount(p23) --[[ Line: 52 ]]
    p23.Gamepad:Disconnect();
    p23.Touch:Disconnect();
end;
function v15.render(u24) --[[ Line: 57 ]]
    -- upvalues: u6 (copy), u12 (copy), u2 (copy), l__HttpService__1 (copy), u16 (copy), u14 (copy), u8 (copy), u13 (copy), u3 (copy), u11 (copy), u9 (copy), u10 (copy), u7 (copy)
    local l__props__2 = u24.props;
    local l__state__3 = u24.state;
    local l__Landing__4 = u24.Landing;
    local l__PopupActive__5 = l__props__2.PopupActive;
    local l__Page__6 = l__state__3.Page;
    local l__Keyboard__7 = l__state__3.Keyboard;
    local v25;
    if l__Page__6 == "Options" then
        v25 = {
            { "Header", "Sensitivity", 0.9 },
            { "Slider", "Camera Sensitivity", "CameraSensitivity" },
            { "Slider", "Aiming Sensitivity", "AimingSensitivity" },
            { "Header", "User Interface", 0.88 },
            { "Radio", "Units of Measurement", "MeasurementUnit" },
            { "Radio", "Show EXP Meter", "ExpBar" },
            { "Header", "Audio", 0.95 },
            { "SoundSlider", "Music", "Music" },
            { "SoundSlider", "SFX", "SFX" },
            { "SoundSlider", "Vehicles", "Vehicle" },
            { "SoundSlider", "World (Weather/Players)", "World" },
            { "SoundSlider", "Action (Gunshots/Explosions)", "Action" },
            { "SoundSlider", "Voice Chat (Talking/Radio)", "VoiceChat" },
            { "Header", "Graphics", 0.92 },
            { "Radio", "World Detail (Animations, Particles, Environment)", "WorldDetail" },
            {
                "Radio",
                "Sound Detail",
                "SoundDetail",
                "Sound detail does NOT affect FPS. If you have slow internet and notice sounds not playing then lower this setting.\n\nLOW = Mobile Data\nMEDIUM = Slow Internet (<10mb/s Download)\nHIGH = Stable Internet Connection"
            },
            {
                "Radio",
                "Texture Detail",
                "TextureDetail",
                "Texture detail does not drastically improve FPS. If you have low amounts of RAM (<4gb) then lower this setting to prevent crashing.\n\nSome textures may remain the same until game is restarted."
            },
            { "Radio", "Render Distance", "RenderDistance" },
            { "Radio", "Cinematic Lights", "CinematicLights" },
            { "Radio", "Tree Shaking", "TreeShaking" },
            { "Radio", "Water Movement", "WaterMovement" },
            { "Header", "Keybinds", 0.92 },
            { "Radio", "Sprinting", "SprintHold" },
            { "Radio", "Leaning", "LeanHold" },
            { "Radio", "Aiming", "AimHold" },
            { "Radio", "Stand After Slide", "StandAfterSlide" },
            { "Slider", "Mouse Steer Horizontal Sensitivity", "MouseSteerXSensitivity" },
            { "Slider", "Mouse Steer Vertical Sensitivity", "MouseSteerYSensitivity" },
            { "Radio", "Invert Vertical Mouse Steer", "MouseSteerInvertYAxis" }
        };
        if u6.Gamepad then
            table.insert(v25, 1, { "Slider", "Thumbstick 2 Deadzone", "Thumbstick2DeadZone" });
            table.insert(v25, 1, { "Slider", "Thumbstick 1 Deadzone", "Thumbstick1DeadZone" });
        end;
    else
        v25 = u12;
    end;
    local v26 = math.max(9, #v25);
    local v27 = 1 / v26;
    local v28 = {
        Grid = u2.createElement("UIGridLayout", {
            CellPadding = UDim2.fromScale(0, v27 * 0.2),
            CellSize = UDim2.fromScale(0.98, v27 * 0.8),
            FillDirection = Enum.FillDirection.Vertical,
            HorizontalAlignment = Enum.HorizontalAlignment.Left,
            SortOrder = Enum.SortOrder.LayoutOrder,
            StartCorner = Enum.StartCorner.TopLeft,
            VerticalAlignment = Enum.VerticalAlignment.Top
        })
    };
    for v29, u39 in v25 do
        local v31 = l__HttpService__1:GenerateGUID(false);
        local v32 = u39[1];
        if v32 == "Header" then
            v28[v31] = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                LayoutOrder = v29
            }, { u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    Size = UDim2.fromScale(1, 0.5),
                    Position = UDim2.fromScale(0, 0.4),
                    Text = u39[2]:upper(),
                    TextColor3 = Color3.new(1, 1, 1),
                    FontFace = u16,
                    TextXAlignment = Enum.TextXAlignment.Left
                }, { u2.createElement("Frame", {
                        BorderSizePixel = 0,
                        AnchorPoint = Vector2.new(1, 0.5),
                        BackgroundColor3 = Color3.new(1, 1, 1),
                        Size = l__Landing__4:Map(function(p33) --[[ Line: 147 ]]
                            -- upvalues: u39 (ref)
                            return UDim2.new(p33 * u39[3], 0, 0, 2);
                        end),
                        Position = UDim2.fromScale(1, 0.5)
                    }) }) });
        else
            local v34 = nil;
            if v32 == "Radio" then
                local u35 = u39[3];
                local v36 = {};
                for u37, v38 in u14[u35] do
                    v36[u37] = u2.createElement(u8, {
                        Scroller = u24.ScrollerRef,
                        Size = UDim2.fromScale(0.1, 1),
                        Ignore = l__PopupActive__5,
                        Name = v38,
                        Activated = u13[u35] == u37,
                        Callback = function() --[[ Name: Callback, Line 166 ]]
                            -- upvalues: u13 (ref), u35 (copy), u37 (copy), u3 (ref), u24 (copy), u39 (ref), u11 (ref)
                            u13[u35] = u37;
                            u3:FireServer("UpdateSettings", "Setting", u35, u37);
                            u24:setState({});
                            if u39[4] then
                                u11:Open(u39[2], u39[4], {
                                    { "Close", function() --[[ Line: 173 ]]
                                            -- upvalues: u11 (ref)
                                            u11:Close();
                                        end }
                                });
                            end;
                        end
                    });
                end;
                v34 = u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Position = UDim2.fromScale(0.99, 0.2),
                    AnchorPoint = Vector2.new(1, 0),
                    Size = UDim2.fromScale(1, 0.6)
                }, { u2.createFragment(v36), u2.createElement("UIListLayout", {
                        SortOrder = Enum.SortOrder.LayoutOrder,
                        FillDirection = Enum.FillDirection.Horizontal,
                        VerticalAlignment = Enum.VerticalAlignment.Center,
                        HorizontalAlignment = Enum.HorizontalAlignment.Right,
                        Padding = UDim.new(0.01, 0)
                    }) });
            elseif v32 == "Keybind" then
                local u39 = { "Keybind", u39[3] or u39[2], u39[2] };
                v34 = u2.createElement(u9, {
                    Scroller = u24.ScrollerRef,
                    Keybind = u39[3],
                    Ignore = l__PopupActive__5
                });
            elseif v32 == "SoundSlider" then
                v34 = u2.createElement(u10, {
                    Mode = "Sound",
                    Scroller = u24.ScrollerRef,
                    Channel = u39[3],
                    Ignore = l__PopupActive__5
                });
            elseif v32 == "Slider" then
                local v40 = u39[3];
                v34 = u2.createElement(u10, {
                    Mode = "Setting",
                    Scroller = u24.ScrollerRef,
                    Ignore = l__PopupActive__5,
                    Min = u14[v40][2],
                    Max = u14[v40][3],
                    Setting = v40
                });
            end;
            v28[v31] = u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundTransparency = 0.5,
                LayoutOrder = v29,
                BackgroundColor3 = Color3.new()
            }, { u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    Size = UDim2.fromScale(1, 0.4),
                    Position = UDim2.fromScale(0.02, 0.3),
                    Text = u39[2]:upper(),
                    TextColor3 = Color3.new(1, 1, 1),
                    FontFace = u16,
                    TextXAlignment = Enum.TextXAlignment.Left
                }), u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0, 4)
                }), v34 });
        end;
    end;
    local l__createElement__8 = u2.createElement;
    local v41 = "Frame";
    local v42 = {
        BackgroundTransparency = 1,
        AnchorPoint = Vector2.new(0.5, 0),
        Size = UDim2.fromScale(0, 0.85),
        Position = UDim2.fromScale(0.5, 0.05)
    };
    local v43 = {};
    local v44 = u2.createElement("UIAspectRatioConstraint", {
        AspectRatio = 2,
        AspectType = Enum.AspectType.ScaleWithParentSize,
        DominantAxis = Enum.DominantAxis.Height
    });
    local v45;
    if l__Keyboard__7 then
        v45 = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.5,
            BackgroundColor3 = Color3.new(),
            Size = UDim2.fromScale(1, 0.08),
            Position = UDim2.fromScale(0, 0)
        }, {
            u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }),
            Options = u2.createElement(u8, {
                Name = "Options",
                Size = UDim2.fromScale(0.485, 0.6),
                Position = UDim2.fromScale(0.01, 0.2),
                Ignore = l__PopupActive__5,
                Activated = l__Page__6 == "Options",
                Callback = function() --[[ Name: Callback, Line 275 ]]
                    -- upvalues: l__Page__6 (copy), u24 (copy)
                    if l__Page__6 ~= "Options" then
                        u24:setState({
                            Page = "Options"
                        });
                    end;
                end
            }),
            Keybinds = u2.createElement(u8, {
                Name = "Keybinds",
                Size = UDim2.fromScale(0.485, 0.6),
                Position = UDim2.fromScale(0.99, 0.2),
                AnchorPoint = Vector2.new(1, 0),
                Ignore = l__PopupActive__5,
                Activated = l__Page__6 == "Keybinds",
                Callback = function() --[[ Name: Callback, Line 291 ]]
                    -- upvalues: l__Page__6 (copy), u24 (copy)
                    if l__Page__6 ~= "Keybinds" then
                        u24:setState({
                            Page = "Keybinds"
                        });
                    end;
                end
            })
        });
    else
        v45 = l__Keyboard__7;
    end;
    v43[1], v43[2], v43[3] = v44, v45, u2.createElement(u7, {
    BackgroundTransparency = 1,
    Position = UDim2.fromScale(0, l__Keyboard__7 and 0.1 or 0),
    Size = UDim2.new(1, 0, l__Keyboard__7 and 0.9 or 1, 0),
    Ignore = l__PopupActive__5,
    CanvasSize = v26 / 9,
    Content = v28,
    Ref = u24.ScrollerRef
});
    return l__createElement__8(v41, v42, v43);
end;
return v15;