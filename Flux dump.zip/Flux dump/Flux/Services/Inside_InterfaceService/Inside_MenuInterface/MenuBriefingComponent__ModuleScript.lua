-- Services.InterfaceService.MenuInterface.MenuBriefingComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4, u5 = shared.import("require", "Roact", "network", "server", "asset");
local u6 = v1("ClientService");
local u7 = v1("StatsService");
local u8 = v1("LandingInterface");
local u9 = v1("BaseComponent");
local u10 = v1("PopupInterface");
local u11 = v1("SoundService");
local u12 = v1("RoactTween");
local u13 = v1("SharedInventory");
local u14 = v1("ActorClass");
local l__MarketplaceService__1 = game:GetService("MarketplaceService");
local l__RunService__2 = game:GetService("RunService");
local l__LocalPlayer__3 = game:GetService("Players").LocalPlayer;
local u15 = v1("MenuButtonComponent");
local v16 = u2.Component:extend("MenuDeploy");
local u17 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u18 = {
    "Vest",
    "Belt",
    "Eyewear",
    "Earwear",
    "Facewear",
    "Backpack",
    "Wrist",
    "Helmet",
    "Shirt",
    "Pants",
    "Gloves",
    "Boots"
};
function v16.init(u19, _) --[[ Line: 30 ]]
    -- upvalues: u6 (copy), u7 (copy), u12 (copy), u2 (copy), l__RunService__2 (copy), u11 (copy), u10 (copy), u3 (copy), u9 (copy), u13 (copy), u18 (copy), u14 (copy)
    local l__LocalClient__4 = u6.LocalClient;
    local u20 = os.clock();
    u19.inGold = u7.OperatorTokens > 0;
    u19.gold = u12.new(u19.inGold and 1 or 0, TweenInfo.new(3, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out, 0, false, 0));
    u19.purchase = u12.new(0, TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out, 0, false, 0));
    local v21, v22 = u2.createBinding(0);
    u19.timer = v21;
    u19.updateTimer = v22;
    u19.conn = l__RunService__2.Heartbeat:Connect(function() --[[ Line: 39 ]]
        -- upvalues: u19 (copy), u20 (copy), u7 (ref), u11 (ref)
        u19.updateTimer(os.clock() - u20);
        if u7.OperatorTokens > 0 and not u19.inGold then
            u11:CreateSound("Button", nil, true, "UISounds", "BuyToken").Destroy(10);
            u19.inGold = true;
            u19.gold:SetGoal(1);
            u19.purchase:SetValue(1);
            u19.purchase:SetGoal(0);
        end;
    end);
    if l__LocalClient__4.FreeToken then
        task.defer(function() --[[ Line: 54 ]]
            -- upvalues: u10 (ref), l__LocalClient__4 (copy), u3 (ref)
            u10:Open("DAILY FREE OPERATOR TOKEN", "Every day you may redeem one free operator token.\n\nThese tokens do not stack, you must use it within the day or you will not receive another free one the next day.", {
                { "Claim", function() --[[ Line: 56 ]]
                        -- upvalues: l__LocalClient__4 (ref), u3 (ref), u10 (ref)
                        l__LocalClient__4.FreeToken = false;
                        u3:FireServer("ClaimFreeToken");
                        u10:Close();
                    end }
            });
        end);
    end;
    local v23 = Instance.new("Camera");
    v23.CFrame = CFrame.new(0, 0, -10) * CFrame.Angles(0, 3.141592653589793, 0);
    v23.FieldOfView = 50;
    u19.survivor = l__LocalClient__4.Survivor;
    u19.combatLogged = l__LocalClient__4.CombatLogged;
    u19.camera = v23;
    u19.viewModel = u2.createRef();
    u19.previewModel = u2.createRef();
    function u19.genModels() --[[ Line: 76 ]]
        -- upvalues: l__LocalClient__4 (copy), u9 (ref), u19 (copy), u13 (ref), u18 (ref), u14 (ref)
        local v24 = u9.Deserialize(l__LocalClient__4.Loadouts[l__LocalClient__4.ActiveLoadout].Tree);
        local v25 = v24:GetChild("Character");
        local l__ParentModel__5 = v25.ParentModel;
        l__ParentModel__5.PrimaryPart.Anchored = true;
        l__ParentModel__5.PrimaryPart:PivotTo(CFrame.new());
        local v26 = v24:GetChild("Primary");
        if v26 then
            local l__Weld__6 = v26.Weld;
            l__Weld__6.C0 = CFrame.new(-0.3, 0, -0.5) * CFrame.Angles(1.5707963267948966, 3.141592653589793, 3.141592653589793);
            l__Weld__6.C1 = v26.ParentModel.PrimaryPart.anchor.CFrame;
            l__Weld__6.Part0 = v25.Model.RightHand;
            l__Weld__6.Part1 = v26.ParentModel.PrimaryPart;
            v26.ParentModel.Parent = l__ParentModel__5;
        end;
        local v27 = Instance.new("AnimationController");
        v27.Parent = v25.Model;
        local u28 = Instance.new("Animator");
        u28.Parent = v27;
        local u29 = Instance.new("Animation");
        u29.AnimationId = "rbxassetid://8588572507";
        l__ParentModel__5.Parent = u19.viewModel:getValue();
        local v30 = v24:GetChild("Character"):GetChild("Appearance");
        local v31 = {
            Orientation = 0,
            Position = Vector3.new(),
            Skin = v30:GetChild("SkinColor").File.Color,
            EyeColor = v30:GetChild("EyeColor").File.Color,
            Eyebrows = v30:GetChild("Eyebrows").File.Texture,
            Mouth = v30:GetChild("Mouth").File.Texture,
            State = {}
        };
        local v32 = v30:GetChild("Hair");
        if v32 then
            v31.Hair = v32.Name;
        end;
        local v33 = v30:GetChild("FacialHair");
        if v33 then
            v31.FacialHair = v33.Name;
        end;
        local v34 = v30:GetChild("HairColor");
        if v34 then
            v31.HairColor = v34 and (v34.File and v34.File.Color) or Color3.new();
        end;
        local l__survivor__7 = u19.survivor;
        if l__survivor__7 and l__survivor__7[1] then
            local v35, v36 = u13.DeserializeData(l__survivor__7[1]);
            for _, v37 in u13.GetAllFunctional({
                Storages = v35,
                StorageID = v36
            }, 1, 1) do
                for _, v38 in u18 do
                    if v37.Name:sub(1, #v38) == v38 then
                        v31.State[v38] = { v37.Name, v37.MetaData };
                        break;
                    end;
                end;
            end;
        end;
        local u39 = u14.new(nil, nil, v31);
        u39.Character.PrimaryPart.Anchored = true;
        u39.Character.PrimaryPart:PivotTo(CFrame.new());
        u39.Character.Parent = u19.previewModel:getValue();
        u19.survivorModel = u39;
        pcall(task.defer, function() --[[ Line: 158 ]]
            -- upvalues: u28 (copy), u29 (copy), u39 (copy)
            u28:LoadAnimation(u29):Play();
            u39:LoadAnimation(15605227537):Play();
        end);
    end;
end;
function v16.willUnmount(p40) --[[ Line: 165 ]]
    p40.conn:Disconnect();
    p40.camera:Destroy();
    if p40.survivorModel then
        p40.survivorModel:Destroy();
    end;
end;
function v16.didMount(u41) --[[ Line: 173 ]]
    pcall(function() --[[ Line: 174 ]]
        -- upvalues: u41 (copy)
        u41.genModels();
    end);
end;
function v16.render(p42) --[[ Line: 179 ]]
    -- upvalues: u2 (copy), u17 (copy), u7 (copy), u15 (copy), u10 (copy), u8 (copy), u3 (copy), u5 (copy), u4 (copy), l__MarketplaceService__1 (copy), l__LocalPlayer__3 (copy)
    local l__PopupActive__8 = p42.props.PopupActive;
    local l__survivor__9 = p42.survivor;
    local v43, v44;
    if l__survivor__9 and not l__survivor__9[6] then
        v43 = "CONTINUE AS OPERATOR";
        if l__survivor__9[2] then
            v44 = "Continue as an operator; You last logged out on-board the UNS New York.";
        else
            v44 = "Continue as an operator; You last logged out in the <i>Quarantine Zone</i>.";
        end;
    else
        v44 = "Spawn as a survivor; Survive while finding a way to escape from the <i>Quarantine Zone</i>.";
        v43 = "CONTINUE AS SURVIVOR";
    end;
    local l__createFragment__10 = u2.createFragment;
    local v45 = {};
    local l__combatLogged__11 = p42.combatLogged;
    if l__combatLogged__11 then
        l__combatLogged__11 = u2.createElement("Frame", {
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            ZIndex = 4,
            Size = UDim2.fromScale(0.45, 0.08),
            Position = UDim2.fromScale(0.7, 0.075),
            BackgroundColor3 = Color3.fromRGB(42, 0, 0),
            AnchorPoint = Vector2.new(0.5, 0.5),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }, {
            u2.createElement("UIGradient", {
                Rotation = -90,
                Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.new(1, 1, 1)), ColorSequenceKeypoint.new(1, Color3.new()) })
            }),
            u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://80619550813478",
                Size = UDim2.fromScale(0.6, 0.6),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                AnchorPoint = Vector2.new(0, 0.5),
                Position = UDim2.fromScale(0.05, 0.5),
                ImageColor3 = Color3.new(1, 0, 0)
            }, { u2.createElement("UIGradient", {
                    Color = ColorSequence.new(Color3.new(1, 1, 1), Color3.fromRGB(67, 67, 67)),
                    Rotation = p42.timer:map(function(p46) --[[ Line: 225 ]]
                        return p46 * 40 + 180;
                    end)
                }) }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "You left the game during combat in your last session. Your survivor loadout has been reset.",
                TextScaled = true,
                Size = UDim2.fromScale(0.75, 0.6),
                AnchorPoint = Vector2.new(0, 0.5),
                Position = UDim2.fromScale(0.2, 0.5),
                TextColor3 = Color3.new(1, 0, 0),
                FontFace = u17,
                TextXAlignment = Enum.TextXAlignment.Center
            }),
            u2.createElement("UIStroke", {
                Thickness = 4,
                Transparency = 0.6,
                Color = Color3.new(1, 0, 0)
            }, { u2.createElement("UIGradient", {
                    Color = ColorSequence.new(Color3.new(1, 1, 1), Color3.fromRGB(67, 67, 67)),
                    Rotation = p42.timer:map(function(p47) --[[ Line: 250 ]]
                        return p47 * 40;
                    end)
                }) })
        });
    end;
    v45[1], v45[2], v45[3], v45[4], v45[5], v45[6], v45[7], v45[8] = l__combatLogged__11, u2.createElement("Frame", {
    BorderSizePixel = 0,
    Size = UDim2.fromScale(1, 1),
    BackgroundColor3 = Color3.new(1, 1, 1)
}, { u2.createElement("UIGradient", {
        Rotation = 12,
        Color = p42.timer:map(function(p48) --[[ Line: 262 ]]
            return ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(61, 22, 0)), ColorSequenceKeypoint.new(math.sin(p48 / 10) / 5 + 0.5, Color3.fromRGB()), ColorSequenceKeypoint.new(1, Color3.fromRGB()) });
        end)
    }) }), u2.createElement("Frame", {
    BorderSizePixel = 0,
    ZIndex = 2,
    Size = UDim2.fromScale(1, 1),
    BackgroundColor3 = Color3.new(1, 1, 1)
}, { u2.createElement("UIGradient", {
        Rotation = -23,
        Color = p42.timer:map(function(p49) --[[ Line: 279 ]]
            return ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(0, 2, 34)), ColorSequenceKeypoint.new(math.cos(p49 / 10) / 5 + 0.6, Color3.fromRGB()), ColorSequenceKeypoint.new(1, Color3.fromRGB()) });
        end),
        Transparency = NumberSequence.new({
            NumberSequenceKeypoint.new(0, 0),
            NumberSequenceKeypoint.new(0.1, 0.45),
            NumberSequenceKeypoint.new(0.27, 1),
            NumberSequenceKeypoint.new(1, 1)
        })
    }) }), u2.createElement("ImageLabel", {
    BackgroundTransparency = 1,
    Image = "rbxassetid://120043002834458",
    ImageTransparency = 0.72,
    Position = UDim2.fromScale(1, 0),
    AnchorPoint = Vector2.new(1, 0),
    SizeConstraint = Enum.SizeConstraint.RelativeYY,
    Size = UDim2.fromScale(1, 1)
}, { u2.createElement("UIGradient", {
        Rotation = -175,
        Transparency = NumberSequence.new({
            NumberSequenceKeypoint.new(0, 0),
            NumberSequenceKeypoint.new(0.3, 0.1),
            NumberSequenceKeypoint.new(0.728, 0.4),
            NumberSequenceKeypoint.new(0.889, 0.919),
            NumberSequenceKeypoint.new(1, 1)
        })
    }) }), u2.createElement("ViewportFrame", {
    BackgroundTransparency = 1,
    ZIndex = 3,
    LightDirection = Vector3.new(-0.5, -1, 0.2),
    Position = UDim2.fromScale(0.3, 0),
    AnchorPoint = Vector2.new(0.5, 0),
    Size = UDim2.fromScale(0.5, 1),
    CurrentCamera = p42.camera,
    LightColor = p42.purchase:Map(function(p50) --[[ Line: 322 ]]
        return Color3.fromRGB(255, 194, 89):Lerp(Color3.fromRGB(255, 219, 158), p50);
    end),
    Ambient = Color3.fromRGB(81, 81, 81)
}, { u2.createElement("WorldModel", {
        [u2.Ref] = p42.viewModel
    }), u2.createElement("UIGradient", {
        Rotation = 90,
        Transparency = NumberSequence.new({
            NumberSequenceKeypoint.new(0, 0),
            NumberSequenceKeypoint.new(0.6, 0),
            NumberSequenceKeypoint.new(0.77, 1),
            NumberSequenceKeypoint.new(1, 1)
        })
    }) }), u2.createElement("ViewportFrame", {
    BackgroundTransparency = 1,
    ZIndex = 3,
    LightDirection = Vector3.new(-0.5, -1, 0.2),
    Position = UDim2.fromScale(0.7, 0),
    AnchorPoint = Vector2.new(0.5, 0),
    Size = UDim2.fromScale(0.5, 1),
    CurrentCamera = p42.camera,
    LightColor = Color3.fromRGB(219, 219, 219),
    Ambient = Color3.fromRGB(81, 81, 81)
}, { u2.createElement("WorldModel", {
        [u2.Ref] = p42.previewModel
    }), u2.createElement("UIGradient", {
        Rotation = 90,
        Transparency = NumberSequence.new({
            NumberSequenceKeypoint.new(0, 0),
            NumberSequenceKeypoint.new(0.6, 0),
            NumberSequenceKeypoint.new(0.77, 1),
            NumberSequenceKeypoint.new(1, 1)
        })
    }) }), u2.createElement("Frame", {
    BackgroundTransparency = 0,
    ZIndex = 4,
    Size = UDim2.fromScale(0.575, 0.25),
    Position = UDim2.fromScale(0.3, 0.787),
    BackgroundColor3 = Color3.new(1, 1, 1),
    AnchorPoint = Vector2.new(0.5, 0.5),
    SizeConstraint = Enum.SizeConstraint.RelativeYY
}, {
    u2.createElement("UIGradient", {
        Rotation = 52,
        Offset = p42.purchase:Map(function(p51) --[[ Line: 375 ]]
            local v52 = p51 * 2 - 1;
            return Vector2.new(v52, v52);
        end),
        Color = ColorSequence.new(Color3.fromRGB(255, 241, 161)),
        Transparency = NumberSequence.new({
            NumberSequenceKeypoint.new(0, 1),
            NumberSequenceKeypoint.new(0.2, 0),
            NumberSequenceKeypoint.new(0.8, 0),
            NumberSequenceKeypoint.new(1, 1)
        })
    }),
    u2.createElement("Frame", {
        Position = UDim2.fromScale(0.5, 0),
        Size = UDim2.fromScale(0.35, 0.35),
        AnchorPoint = Vector2.new(0.5, 0.5),
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        BackgroundColor3 = Color3.fromRGB(99, 72, 30)
    }, {
        u2.createElement("UICorner", {
            CornerRadius = UDim.new(0.5, 0)
        }),
        u2.createElement("UIStroke", {
            Thickness = 8,
            Color = Color3.fromRGB(195, 161, 74)
        }, { u2.createElement("UIGradient", {
                Color = ColorSequence.new(Color3.new(1, 1, 1), Color3.fromRGB(67, 67, 67)),
                Rotation = p42.timer:map(function(p53) --[[ Line: 406 ]]
                    return p53 * 40;
                end)
            }) }),
        u2.createElement("UIGradient", {
            Color = ColorSequence.new(Color3.new(1, 1, 1), Color3.fromRGB(67, 67, 67)),
            Rotation = p42.timer:map(function(p54) --[[ Line: 413 ]]
                return p54 * 40;
            end)
        }),
        u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            RichText = true,
            Size = p42.purchase:Map(function(p55) --[[ Line: 419 ]]
                return UDim2.fromScale(1, 0.8 + p55 * 3);
            end),
            Position = UDim2.fromScale(0, 0.5),
            AnchorPoint = Vector2.new(0, 0.5),
            Text = u7.TokenBinding,
            TextColor3 = Color3.fromRGB(195, 161, 74),
            FontFace = u17,
            TextXAlignment = Enum.TextXAlignment.Center
        }, { u2.createElement("UIGradient", {
                Color = ColorSequence.new(Color3.new(1, 1, 1), Color3.fromRGB(67, 67, 67)),
                Rotation = p42.timer:map(function(p56) --[[ Line: 433 ]]
                    return p56 * 40 + 180;
                end)
            }) })
    }),
    u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        Text = "Deploy as operator; complete missions to earn money, EXP and more tokens. Find and rescue survivors.",
        TextScaled = true,
        Size = UDim2.fromScale(0.8, 0.2),
        AnchorPoint = Vector2.new(0, 0),
        Position = UDim2.fromScale(0.1, 0.25),
        TextColor3 = p42.gold:Map(function(p57) --[[ Line: 445 ]]
            return Color3.new(1, 1, 1):Lerp(Color3.fromRGB(195, 161, 74), p57);
        end),
        FontFace = u17,
        TextXAlignment = Enum.TextXAlignment.Center
    }),
    u2.createElement(u15, {
        Size = UDim2.fromScale(0.8, 0.19),
        Ignore = l__PopupActive__8,
        Position = UDim2.fromScale(0.1, 0.55),
        Name = u7.TokenBinding:map(function(p58) --[[ Line: 456 ]]
            return p58 > 0 and "DEPLOY AS OPERATOR (1 TOKEN)" or "PURCHASE OPERATOR TOKEN (R$30)";
        end),
        Callback = function() --[[ Name: Callback, Line 462 ]]
            -- upvalues: u7 (ref), u10 (ref), u8 (ref), u3 (ref), u5 (ref), u4 (ref), l__MarketplaceService__1 (ref), l__LocalPlayer__3 (ref)
            if u7.OperatorTokens > 0 then
                u10:Open("SPEND OPERATOR TOKEN", "Are you sure you want to spend an operator token?\n\nYou will deploy on the ship with your full loadout.", {
                    { "Yes", function() --[[ Line: 465 ]]
                            -- upvalues: u8 (ref), u3 (ref), u10 (ref)
                            u8:Message("Deploying Operator");
                            task.delay(0.5, function() --[[ Line: 467 ]]
                                -- upvalues: u3 (ref)
                                u3:FireServer("DeployCharacter", true);
                            end);
                            u10:Close();
                        end },
                    { "Cancel", function() --[[ Line: 472 ]]
                            -- upvalues: u10 (ref)
                            u10:Close();
                        end }
                });
            else
                u5:Get("Sound", "UISounds", "BuyToken"):Preload();
                u10:Open("NO OPERATOR TOKENS", "You do not have any operator tokens.\n\nEarn operator tokens by escaping as a survivor or by completing missions as an operator.\n\nAlternatively, you can purchase operator tokens for Robux.", {
                    { "Purchase (R$30)", function() --[[ Line: 479 ]]
                            -- upvalues: u4 (ref), l__MarketplaceService__1 (ref), l__LocalPlayer__3 (ref), u10 (ref)
                            if not u4.CHEATS_ENABLED then
                                l__MarketplaceService__1:PromptProductPurchase(l__LocalPlayer__3, 3439470168);
                            end;
                            u10:Close();
                        end },
                    { "Cancel", function() --[[ Line: 485 ]]
                            -- upvalues: u10 (ref)
                            u10:Close();
                        end }
                });
            end;
        end
    }),
    u2.createElement("UIStroke", {
        Thickness = 4,
        Transparency = 0.6,
        Color = p42.gold:Map(function(p59) --[[ Line: 493 ]]
            return Color3.new(1, 1, 1):Lerp(Color3.fromRGB(195, 161, 74), p59);
        end)
    }, { u2.createElement("UIGradient", {
            Color = ColorSequence.new(Color3.new(1, 1, 1), Color3.fromRGB(67, 67, 67)),
            Rotation = p42.timer:map(function(p60) --[[ Line: 503 ]]
                return p60 * 40;
            end)
        }) })
}), u2.createElement("Frame", {
    BackgroundTransparency = 1,
    ZIndex = 4,
    Size = UDim2.fromScale(0.575, 0.25),
    Position = UDim2.fromScale(0.7, 0.787),
    AnchorPoint = Vector2.new(0.5, 0.5),
    SizeConstraint = Enum.SizeConstraint.RelativeYY
}, { u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        RichText = true,
        Size = UDim2.fromScale(0.8, 0.2),
        AnchorPoint = Vector2.new(0, 0),
        Position = UDim2.fromScale(0.1, 0.25),
        Text = v44,
        TextColor3 = Color3.new(1, 1, 1),
        FontFace = u17,
        TextXAlignment = Enum.TextXAlignment.Center
    }), u2.createElement(u15, {
        Size = UDim2.fromScale(0.8, 0.19),
        Ignore = l__PopupActive__8,
        Position = UDim2.fromScale(0.1, 0.55),
        Name = v43,
        Callback = function() --[[ Name: Callback, Line 534 ]]
            -- upvalues: u8 (ref), u3 (ref)
            u8:Message("Deploying Character");
            task.delay(0.5, function() --[[ Line: 536 ]]
                -- upvalues: u3 (ref)
                u3:FireServer("DeployCharacter", false);
            end);
        end
    }), u2.createElement("UIStroke", {
        Thickness = 4,
        Transparency = 0.6,
        Color = Color3.new(1, 1, 1)
    }, { u2.createElement("UIGradient", {
            Color = ColorSequence.new(Color3.new(1, 1, 1), Color3.fromRGB(67, 67, 67)),
            Rotation = p42.timer:map(function(p61) --[[ Line: 550 ]]
                return p61 * 40;
            end)
        }) }) });
    return l__createFragment__10(v45);
end;
return v16;