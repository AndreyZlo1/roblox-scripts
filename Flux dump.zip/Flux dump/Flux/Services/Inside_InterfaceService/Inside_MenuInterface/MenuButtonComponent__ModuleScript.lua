-- Services.InterfaceService.MenuInterface.MenuButtonComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local u3 = v1("GameShellProxyButton");
local u4 = v1("GameShellProxyTextLabel");
local l__RunService__1 = game:GetService("RunService");
local u5 = v1("RoactTween");
local v6 = u2.Component:extend("MenuButton");
local u7 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
function v6.init(p8, _) --[[ Line: 15 ]]
    -- upvalues: u2 (copy), u5 (copy)
    local v9, v10 = u2.createBinding(0);
    p8.Rotation = v9;
    p8.UpdateRotation = v10;
    p8.Tween = u5.new(0);
    p8:setState({
        Hovering = false
    });
end;
function v6.willUnmount(p11) --[[ Line: 24 ]]
    if p11.ConnectionRotation then
        p11.ConnectionRotation:Disconnect();
    end;
end;
function v6.render(u12) --[[ Line: 30 ]]
    -- upvalues: l__RunService__1 (copy), u2 (copy), u3 (copy), u4 (copy), u7 (copy)
    local l__props__2 = u12.props;
    local l__state__3 = u12.state;
    local l__Name__4 = l__props__2.Name;
    local l__Image__5 = l__props__2.Image;
    local l__Disabled__6 = l__props__2.Disabled;
    local l__Activated__7 = l__props__2.Activated;
    local l__Hovering__8 = l__state__3.Hovering;
    local l__MountTextLabelCalls__9 = l__props__2.MountTextLabelCalls;
    local l__NameChildren__10 = l__props__2.NameChildren;
    local v13;
    if type(l__Activated__7) == "table" and l__Activated__7.getValue then
        v13 = l__Activated__7:map(function(p14) --[[ Line: 49 ]]
            -- upvalues: l__Hovering__8 (copy)
            return p14 and Color3.fromRGB(255, 194, 89) or (l__Hovering__8 and Color3.new(1, 1, 1) or Color3.fromRGB(71, 71, 71));
        end);
    else
        v13 = l__Activated__7 and Color3.fromRGB(255, 194, 89) or (l__Hovering__8 and Color3.new(1, 1, 1) or Color3.fromRGB(71, 71, 71));
    end;
    if l__props__2.Loading then
        if u12.ConnectionRotation == nil then
            u12.ConnectionRotation = l__RunService__1.Heartbeat:Connect(function(p15) --[[ Line: 58 ]]
                -- upvalues: u12 (copy)
                u12.UpdateRotation(u12.Rotation:getValue() - p15 * 400);
            end);
        end;
    elseif u12.ConnectionRotation then
        u12.ConnectionRotation:Disconnect();
        u12.ConnectionRotation = nil;
    end;
    local l__createElement__11 = u2.createElement;
    local v16 = u3;
    local v18 = {
        Image = "",
        BorderSizePixel = 0,
        SoundKit = "MainMenu",
        ImageColor3 = v13,
        LayoutOrder = l__props__2.Layout or l__props__2.LayoutOrder,
        SizeConstraint = l__props__2.SizeConstraint,
        Ref = l__props__2[u2.Ref],
        Scroller = l__props__2.Scroller,
        BackgroundColor3 = l__Activated__7 and Color3.fromRGB(31, 23, 11) or u12.Tween:Map(function(p17) --[[ Line: 75 ]]
            return Color3.fromRGB(16, 16, 16):Lerp(Color3.fromRGB(24, 24, 24), p17);
        end),
        Ignore = l__Disabled__6 or l__props__2.Ignore,
        Size = l__props__2.Size,
        Position = l__props__2.Position,
        ZIndex = l__props__2.ZIndex,
        AnchorPoint = l__props__2.AnchorPoint,
        MouseUp = function() --[[ Name: MouseUp, Line 87 ]]
            -- upvalues: l__props__2 (copy)
            l__props__2.Callback();
        end,
        MouseEnter = function() --[[ Name: MouseEnter, Line 90 ]]
            -- upvalues: u12 (copy)
            u12.Tween:SetGoal(1);
            u12:setState({
                Hovering = true
            });
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 96 ]]
            -- upvalues: u12 (copy)
            u12.Tween:SetGoal(0);
            u12:setState({
                Hovering = false
            });
        end
    };
    local v20 = {
        u2.createFragment(l__props__2[u2.Children]),
        Corner = u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 0)
        }),
        Stroke = u2.createElement("UIStroke", {
            Thickness = 1,
            ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
            Color = v13,
            LineJoinMode = Enum.LineJoinMode.Round,
            Transparency = l__Disabled__6 and 0.5 or 0
        }, {
            Gradient = u2.createElement("UIGradient", {
                Rotation = 0,
                Transparency = u12.Tween:Map(function(p19) --[[ Line: 115 ]]
                    return NumberSequence.new({
                        NumberSequenceKeypoint.new(0, 0),
                        NumberSequenceKeypoint.new(0.2, 1 - p19),
                        NumberSequenceKeypoint.new(0.8, 1 - p19),
                        NumberSequenceKeypoint.new(1, 0)
                    });
                end)
            })
        }),
        Dots = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://13867939464",
            Size = UDim2.fromScale(1, 1),
            ImageColor3 = v13,
            TileSize = UDim2.fromOffset(6, 6),
            ScaleType = Enum.ScaleType.Tile
        }, {
            Gradient = u2.createElement("UIGradient", {
                Transparency = u12.Tween:Map(function(_) --[[ Line: 135 ]]
                    return NumberSequence.new({
                        NumberSequenceKeypoint.new(0, 0),
                        NumberSequenceKeypoint.new(0.1, 0),
                        NumberSequenceKeypoint.new(0.4, 0.75),
                        NumberSequenceKeypoint.new(0.6, 0.75),
                        NumberSequenceKeypoint.new(0.9, 0),
                        NumberSequenceKeypoint.new(1, 0)
                    });
                end)
            })
        })
    };
    if l__Name__4 then
        local l__createElement__12 = u2.createElement;
        local v21 = l__MountTextLabelCalls__9 and u4 or "TextLabel";
        local v22 = {
            BackgroundTransparency = 1,
            TextScaled = true,
            ZIndex = 2,
            Size = UDim2.fromScale(1, l__props__2.SizeY or 0.6),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5)
        };
        if l__props__2.Loading then
            l__Name__4 = "";
        elseif typeof(l__Name__4) == "string" and not (l__props__2.NoUpper and l__Name__4) then
            l__Name__4 = l__Name__4:upper() or l__Name__4;
        end;
        v22.Text = l__Name__4;
        v22.TextColor3 = v13;
        v22.TextTransparency = l__Disabled__6 and 0.5 or 0;
        v22.FontFace = u7;
        v22.TextXAlignment = Enum.TextXAlignment.Center;
        v22.DidMount = l__MountTextLabelCalls__9 or nil;
        l__Name__4 = l__createElement__12(v21, v22, l__NameChildren__10);
    end;
    if l__Image__5 then
        l__Image__5 = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            Size = UDim2.fromScale(1, l__props__2.ImageY or 1),
            Position = UDim2.fromScale(0.5, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5),
            ImageColor3 = v13,
            ScaleType = Enum.ScaleType.Fit,
            Image = l__props__2.Loading and "" or l__Image__5
        });
    end;
    local l__Loading__13 = l__props__2.Loading;
    if l__Loading__13 then
        l__Loading__13 = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://15478256777",
            ZIndex = 2,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = UDim2.fromScale(0.6, 0.6),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            Rotation = u12.Rotation,
            ImageColor3 = v13
        });
    end;
    if l__Disabled__6 then
        if typeof(l__Disabled__6) == "string" then
            l__Disabled__6 = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                TextTransparency = 0.5,
                ZIndex = 2,
                Size = UDim2.fromScale(1, l__props__2.SizeY or 0.6),
                AnchorPoint = Vector2.new(1, 0.5),
                Position = UDim2.fromScale(0.9, 0.5),
                Text = l__Disabled__6,
                TextColor3 = v13,
                FontFace = u7,
                TextXAlignment = Enum.TextXAlignment.Right
            });
        else
            l__Disabled__6 = false;
        end;
    end;
    v20[2], v20[3], v20[4], v20[5] = l__Name__4, l__Image__5, l__Loading__13, l__Disabled__6;
    return l__createElement__11(v16, v18, v20);
end;
return v6;