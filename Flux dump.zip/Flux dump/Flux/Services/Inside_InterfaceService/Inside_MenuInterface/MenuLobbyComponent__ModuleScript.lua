-- Services.InterfaceService.MenuInterface.MenuLobbyComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "asset");
local u3 = v1("MenuLobbyPlayerComponent");
local v4 = u2.Component:extend("MenuDeploy");
function v4.init(_, _) --[[ Line: 7 ]] end;
function v4.willUnmount(_) --[[ Line: 11 ]] end;
function v4.render(p5) --[[ Line: 15 ]]
    -- upvalues: u2 (copy), u3 (copy)
    local l__props__1 = p5.props;
    local l__MatchmakingQueueData__2 = l__props__1.MatchmakingQueueData;
    local l__PopupActive__3 = l__props__1.PopupActive;
    local v6 = {};
    for v7 = 1, 5 do
        v6[v7] = u2.createElement(u3, {
            Index = v7,
            ExpandedTween = l__props__1.ExpandedTween,
            LobbyMember = l__MatchmakingQueueData__2.CurrentLobby[v7],
            PopupActive = l__PopupActive__3
        });
    end;
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        AnchorPoint = l__props__1.AnchorPoint,
        Size = l__props__1.Size,
        Position = l__props__1.Position
    }, {
        Aspect = u2.createElement("UIAspectRatioConstraint", {
            AspectRatio = 7,
            AspectType = Enum.AspectType.ScaleWithParentSize,
            DominantAxis = Enum.DominantAxis.Height
        }),
        u2.createFragment(v6)
    });
end;
return v4;