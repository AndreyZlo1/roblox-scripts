-- Services.InterfaceService.MenuInterface.MenuPlayComponent.MenuPrivateServerComponent.MenuPrivateServerBlacklistComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "network");
local u4 = v1("GameShellProxyScroller");
local u5 = v1("GameShellProxyInput");
local u6 = v1("MenuButtonComponent");
local u7 = v1("PopupInterface");
local l__Players__1 = game:GetService("Players");
local v8 = u2.Component:extend("MenuPrivateServerBlacklist");
local u9 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u10 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
function v8.init(u11, p12) --[[ Line: 20 ]]
    -- upvalues: u2 (copy), l__Players__1 (copy), u7 (copy)
    local l__PrivateServerData__2 = p12.PrivateServerData;
    local v13, v14 = u2.createBinding();
    u11.AddUser = v13;
    u11.AddUserUpdate = v14;
    function u11.AddUserPressed() --[[ Line: 24 ]]
        -- upvalues: u11 (copy), l__Players__1 (ref), l__PrivateServerData__2 (copy), u7 (ref)
        if u11.state.AddingUser then
            return;
        end;
        u11:setState({
            AddingUser = true
        });
        local l__AwaitingUsers__3 = u11.state.AwaitingUsers;
        local v15 = u11.AddUser:getValue();
        local v16, v17 = pcall(l__Players__1.GetUserIdFromNameAsync, l__Players__1, v15);
        if v16 then
            local v18, v19 = pcall(l__Players__1.GetNameFromUserIdAsync, l__Players__1, v17);
            if v18 then
                local v20 = false;
                for _, v21 in l__AwaitingUsers__3 do
                    if v21.UserId == v17 then
                        v20 = true;
                        break;
                    end;
                end;
                for _, v22 in l__PrivateServerData__2.PrivateServerBlacklist.Users do
                    if v22.UserId == v17 then
                        v20 = true;
                        break;
                    end;
                end;
                if v20 then
                    u7:Slide("User already added", "This user is already in the blacklist.", {});
                else
                    l__AwaitingUsers__3[#l__AwaitingUsers__3 + 1] = {
                        Name = v19,
                        UserId = v17
                    };
                end;
            end;
        else
            u7:Slide("Invalid Username", "Could not find a match for \'" .. v15 .. "\'", {});
        end;
        u11:setState({
            AddingUser = false,
            AwaitingUsers = l__AwaitingUsers__3
        });
    end;
    u11:setState({
        AddingUser = false,
        AwaitingUsers = {}
    });
end;
function v8.willUnmount(_) --[[ Line: 78 ]] end;
function v8.render(u23) --[[ Line: 81 ]]
    -- upvalues: u2 (copy), u10 (copy), u6 (copy), l__Players__1 (copy), u3 (copy), u5 (copy), u9 (copy), u4 (copy)
    local l__props__4 = u23.props;
    local l__state__5 = u23.state;
    local l__PopupActive__6 = l__props__4.PopupActive;
    local l__PrivateServerData__7 = l__props__4.PrivateServerData;
    local l__UpdatingPrivateServerConfig__8 = l__PrivateServerData__7.UpdatingPrivateServerConfig;
    local l__PrivateServerBlacklist__9 = l__PrivateServerData__7.PrivateServerBlacklist;
    local v24 = math.max(7, #l__state__5.AwaitingUsers);
    local v25 = 1 / v24;
    local v26 = {
        Grid = u2.createElement("UIGridLayout", {
            FillDirection = Enum.FillDirection.Vertical,
            SortOrder = Enum.SortOrder.LayoutOrder,
            CellPadding = UDim2.fromScale(0, v25 * 0.2),
            CellSize = UDim2.fromScale(1, v25 * 0.8)
        })
    };
    for u27, v28 in l__state__5.AwaitingUsers do
        v26[u27] = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            LayoutOrder = u27
        }, {
            Headshot = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                BackgroundColor3 = Color3.fromRGB(0, 0, 0),
                Image = "https://www.roblox.com/headshot-thumbnail/image?userId=" .. v28.UserId .. "&width=420&height=420&format=png",
                Size = UDim2.new(0.9, 0, 0.9, 0),
                Position = UDim2.new(0.01, 0, 0.05, 0)
            }, { u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0, 1)
                }), u2.createElement("UIStroke", {
                    Color = Color3.fromRGB(255, 255, 255)
                }) }),
            HostHeader = u2.createElement("TextLabel", {
                TextWrapped = true,
                TextScaled = true,
                BackgroundTransparency = 1,
                FontFace = u10,
                Size = UDim2.new(0.92, 0, 0.4, 0),
                TextColor3 = Color3.fromRGB(255, 255, 255),
                Text = "@" .. v28.Name,
                Position = UDim2.new(0.13, 0, 0.3, 0),
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            Remove = u2.createElement(u6, {
                Name = "Remove",
                Ignore = l__PopupActive__6,
                Size = UDim2.new(0.2, 0, 0.8, 0),
                Position = UDim2.new(0.75, 0, 0.1, 0),
                Callback = function() --[[ Name: Callback, Line 135 ]]
                    -- upvalues: u23 (copy), u27 (copy)
                    u23:setState(function(p29) --[[ Line: 136 ]]
                        -- upvalues: u27 (ref)
                        table.remove(p29.AwaitingUsers, u27);
                        return p29;
                    end);
                end
            })
        });
    end;
    local v30 = math.max(10, #l__PrivateServerBlacklist__9.Users);
    local v31 = 1 / v30;
    local v32 = {
        Grid = u2.createElement("UIGridLayout", {
            FillDirection = Enum.FillDirection.Vertical,
            SortOrder = Enum.SortOrder.LayoutOrder,
            CellPadding = UDim2.fromScale(0, v31 * 0.2),
            CellSize = UDim2.fromScale(1, v31 * 0.8)
        })
    };
    for u33, u34 in l__PrivateServerBlacklist__9.Users do
        if not (u34.UserNameCache or u34.UserNameCacheStarted) then
            u34.UserNameCacheStarted = true;
            task.defer(function() --[[ Line: 158 ]]
                -- upvalues: l__Players__1 (ref), u34 (copy), u23 (copy)
                local v35, v36 = pcall(l__Players__1.GetNameFromUserIdAsync, l__Players__1, u34.UserId);
                if v35 then
                    u34.UserNameCache = v36;
                    u23:setState({});
                end;
            end);
        end;
        if not (u34.AuthorNameCache or u34.AuthorNameCacheStarted) then
            u34.AuthorNameCacheStarted = true;
            task.defer(function() --[[ Line: 169 ]]
                -- upvalues: l__Players__1 (ref), u34 (copy), u23 (copy)
                local v37, v38 = pcall(l__Players__1.GetNameFromUserIdAsync, l__Players__1, u34.Author);
                if v37 then
                    u34.AuthorNameCache = v38;
                    u23:setState({});
                end;
            end);
        end;
        v32[u33] = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            LayoutOrder = u33
        }, {
            u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                BackgroundColor3 = Color3.fromRGB(0, 0, 0),
                Image = "https://www.roblox.com/headshot-thumbnail/image?userId=" .. u34.UserId .. "&width=420&height=420&format=png",
                Size = UDim2.new(0.9, 0, 0.9, 0),
                Position = UDim2.new(0.01, 0, 0.05, 0)
            }, { u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0, 1)
                }), u2.createElement("UIStroke", {
                    Color = Color3.fromRGB(255, 255, 255)
                }) }),
            u2.createElement("TextLabel", {
                TextWrapped = true,
                TextScaled = true,
                BackgroundTransparency = 1,
                FontFace = u10,
                Size = UDim2.new(0.92, 0, 0.4, 0),
                TextColor3 = Color3.fromRGB(255, 255, 255),
                Text = "@" .. (u34.UserNameCache or "______________"),
                Position = UDim2.new(0.08, 0, 0.3, 0),
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                BackgroundColor3 = Color3.fromRGB(0, 0, 0),
                Image = "https://www.roblox.com/headshot-thumbnail/image?userId=" .. u34.Author .. "&width=420&height=420&format=png",
                Size = UDim2.new(0.9, 0, 0.9, 0),
                Position = UDim2.new(0.31, 0, 0.05, 0)
            }, { u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0, 1)
                }), u2.createElement("UIStroke", {
                    Color = Color3.fromRGB(255, 255, 255)
                }) }),
            u2.createElement("TextLabel", {
                TextWrapped = true,
                TextScaled = true,
                BackgroundTransparency = 1,
                FontFace = u10,
                Size = UDim2.new(0.92, 0, 0.4, 0),
                TextColor3 = Color3.fromRGB(255, 255, 255),
                Text = "@" .. (u34.AuthorNameCache or "______________"),
                Position = UDim2.new(0.38, 0, 0.3, 0),
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            u2.createElement("TextLabel", {
                TextWrapped = true,
                TextScaled = true,
                BackgroundTransparency = 1,
                FontFace = u10,
                Size = UDim2.new(0.92, 0, 0.4, 0),
                TextColor3 = Color3.fromRGB(255, 255, 255),
                Text = os.date("%x", u34.Date),
                Position = UDim2.new(0.6, 0, 0.3, 0),
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            Revoke = u2.createElement(u6, {
                Name = "Revoke",
                Size = UDim2.new(0.1, 0, 0.8, 0),
                Position = UDim2.new(0.8, 0, 0.1, 0),
                Ignore = l__PopupActive__6,
                Loading = l__UpdatingPrivateServerConfig__8,
                Callback = function() --[[ Name: Callback, Line 251 ]]
                    -- upvalues: l__UpdatingPrivateServerConfig__8 (copy), l__state__5 (copy), l__PrivateServerData__7 (copy), u23 (copy), u3 (ref), u33 (copy)
                    if l__UpdatingPrivateServerConfig__8 or (l__state__5.AddingUser or l__PrivateServerData__7.UpdatingPrivateServerCode) then
                    else
                        l__PrivateServerData__7.UpdatingPrivateServerConfig = true;
                        u23:setState({});
                        u3:FireServer("PrivateServerBlacklistRemove", u33);
                    end;
                end
            })
        });
    end;
    return u2.createFragment({
        Settings = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.5,
            Size = UDim2.new(0.4, 0, 1, 0),
            Position = UDim2.fromScale(0, 0),
            BackgroundColor3 = Color3.fromRGB(0, 0, 0)
        }, {
            Corner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }),
            Username = u2.createElement(u5, {
                PlaceholderText = "USERNAME",
                ClearTextOnFocus = true,
                BackgroundColor3 = Color3.new(),
                Size = UDim2.new(0.58, 0, 0.07, 0),
                Position = UDim2.new(0.05, 0, 0.04, 0),
                FontFace = u9,
                TextXAlignment = Enum.TextXAlignment.Center,
                TextBind = u23.AddUser,
                TextBindUpdate = u23.AddUserUpdate,
                EnterPressed = u23.AddUserPressed,
                Ignore = l__PopupActive__6,
                Content = { u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0, 4)
                    }) }
            }),
            Add = u2.createElement(u6, {
                Name = "Preview",
                AnchorPoint = Vector2.new(1, 0),
                Size = UDim2.new(0.29, 0, 0.07, 0),
                Position = UDim2.new(0.95, 0, 0.04, 0),
                Loading = l__state__5.AddingUser,
                Ignore = l__PopupActive__6,
                Callback = u23.AddUserPressed
            }),
            Scroller = u2.createElement(u4, {
                BackgroundTransparency = 1,
                Size = UDim2.new(0.9, 0, 0.68, 0),
                Position = UDim2.new(0.05, 0, 0.15, 0),
                CanvasSize = v24 / 7,
                Content = v26
            }),
            Apply = u2.createElement(u6, {
                Name = "Add Users To Blacklist (" .. #l__state__5.AwaitingUsers .. ")",
                Size = UDim2.new(0.9, 0, 0.07, 0),
                Position = UDim2.new(0.05, 0, 0.895, 0),
                Ignore = l__PopupActive__6,
                Loading = l__UpdatingPrivateServerConfig__8,
                Callback = function() --[[ Name: Callback, Line 316 ]]
                    -- upvalues: l__UpdatingPrivateServerConfig__8 (copy), l__state__5 (copy), l__PrivateServerData__7 (copy), u23 (copy), u3 (ref)
                    if l__UpdatingPrivateServerConfig__8 or (l__state__5.AddingUser or l__PrivateServerData__7.UpdatingPrivateServerCode) then
                    else
                        l__PrivateServerData__7.UpdatingPrivateServerConfig = true;
                        u23:setState({
                            AwaitingUsers = {}
                        });
                        u3:FireServer("PrivateServerBlacklistAdd", l__state__5.AwaitingUsers);
                    end;
                end
            })
        }),
        List = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.5,
            AnchorPoint = Vector2.new(1, 0),
            Size = UDim2.new(0.59, 0, 1, 0),
            Position = UDim2.new(1, 0, 0, 0),
            BackgroundColor3 = Color3.fromRGB(0, 0, 0)
        }, {
            Corner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }),
            Scroller = u2.createElement(u4, {
                BackgroundTransparency = 1,
                Size = UDim2.new(0.95, 0, 0.85, 0),
                Position = UDim2.new(0.025, 0, 0.12, 0),
                CanvasSize = v30 / 10,
                Content = v32
            }),
            Divider = u2.createElement("Frame", {
                BorderSizePixel = 0,
                Size = UDim2.new(1, 0, 0, 2),
                Position = UDim2.new(0, 0, 0.1, 0),
                BorderColor3 = Color3.fromRGB(0, 0, 0),
                BackgroundColor3 = Color3.fromRGB(84, 84, 84)
            }),
            Key = u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundTransparency = 1,
                Size = UDim2.new(0.95, 0, 0.07, 0),
                Position = UDim2.new(0.025, 0, 0.013, 0),
                BorderColor3 = Color3.fromRGB(0, 0, 0),
                BackgroundColor3 = Color3.fromRGB(255, 255, 255)
            }, {
                u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    SizeConstraint = Enum.SizeConstraint.RelativeYY,
                    BackgroundColor3 = Color3.fromRGB(0, 0, 0),
                    Size = UDim2.new(0.9, 0, 0.9, 0),
                    Position = UDim2.new(0.01, 0, 0.05, 0)
                }, { u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0, 1)
                    }), u2.createElement("UIStroke", {
                        Color = Color3.fromRGB(84, 84, 84)
                    }), u2.createElement("TextLabel", {
                        TextWrapped = true,
                        TextScaled = true,
                        Text = "?",
                        BackgroundTransparency = 1,
                        FontFace = u10,
                        Size = UDim2.new(1, 0, 1, 0),
                        TextColor3 = Color3.fromRGB(84, 84, 84)
                    }) }),
                u2.createElement("TextLabel", {
                    TextWrapped = true,
                    TextScaled = true,
                    Text = "BLACKLISTED USER",
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    Size = UDim2.new(0.92, 0, 0.4, 0),
                    TextColor3 = Color3.fromRGB(84, 84, 84),
                    Position = UDim2.new(0.08, 0, 0.3, 0),
                    TextXAlignment = Enum.TextXAlignment.Left
                }),
                u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    SizeConstraint = Enum.SizeConstraint.RelativeYY,
                    BackgroundColor3 = Color3.fromRGB(0, 0, 0),
                    Size = UDim2.new(0.9, 0, 0.9, 0),
                    Position = UDim2.new(0.31, 0, 0.05, 0)
                }, { u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0, 1)
                    }), u2.createElement("UIStroke", {
                        Color = Color3.fromRGB(84, 84, 84)
                    }), u2.createElement("TextLabel", {
                        TextWrapped = true,
                        TextScaled = true,
                        Text = "?",
                        BackgroundTransparency = 1,
                        FontFace = u10,
                        Size = UDim2.new(1, 0, 1, 0),
                        TextColor3 = Color3.fromRGB(84, 84, 84)
                    }) }),
                u2.createElement("TextLabel", {
                    TextWrapped = true,
                    TextScaled = true,
                    Text = "BLACKLISTED BY",
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    Size = UDim2.new(0.92, 0, 0.4, 0),
                    TextColor3 = Color3.fromRGB(84, 84, 84),
                    Position = UDim2.new(0.38, 0, 0.3, 0),
                    TextXAlignment = Enum.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    TextWrapped = true,
                    TextScaled = true,
                    Text = "DATE ADDED",
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    Size = UDim2.new(0.92, 0, 0.4, 0),
                    TextColor3 = Color3.fromRGB(84, 84, 84),
                    Position = UDim2.new(0.6, 0, 0.3, 0),
                    TextXAlignment = Enum.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    TextWrapped = true,
                    TextScaled = true,
                    Text = "ACTION",
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    Size = UDim2.new(0.92, 0, 0.4, 0),
                    TextColor3 = Color3.fromRGB(84, 84, 84),
                    Position = UDim2.new(0.8, 0, 0.3, 0),
                    TextXAlignment = Enum.TextXAlignment.Left
                })
            })
        })
    });
end;
return v8;