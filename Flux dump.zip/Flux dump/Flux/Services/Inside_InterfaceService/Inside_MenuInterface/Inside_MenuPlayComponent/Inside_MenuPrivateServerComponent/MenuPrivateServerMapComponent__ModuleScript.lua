-- Services.InterfaceService.MenuInterface.MenuPlayComponent.MenuPrivateServerComponent.MenuPrivateServerMapComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "network");
local u4 = v1("GameShellProxyScroller");
local u5 = v1("GameShellProxyInput");
local u6 = v1("MenuButtonComponent");
local u7 = v1("MenuPrivateServerMapButtonComponent");
local u8 = v1("PopupInterface");
local l__RunService__1 = game:GetService("RunService");
local v9 = u2.Component:extend("MenuPrivateServerWhitelist");
local u10 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u11 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u12 = {
    Sort = {
        Y = 0.51,
        Options = { "Openworld", "Competitive", "Your Maps" }
    },
    Filter = {
        Y = 0.755,
        Options = {
            "Highest Rating",
            "Lowest Rating",
            "Most Downloads",
            "Least Downloads"
        }
    }
};
function v9.init(u13, p14) --[[ Line: 39 ]]
    -- upvalues: u2 (copy), u3 (copy), l__RunService__1 (copy)
    local _ = p14.MatchmakingQueueData;
    local l__PrivateServerData__2 = p14.PrivateServerData;
    u13.LastResult = u2.createRef();
    u13.ScrollerResult = u2.createRef();
    local v15, v16 = u2.createBinding();
    u13.SearchInput = v15;
    u13.SearchInputUpdate = v16;
    function u13.SearchPressed() --[[ Line: 47 ]]
        -- upvalues: l__PrivateServerData__2 (copy), u3 (ref), u13 (copy)
        if l__PrivateServerData__2.UpdatingCommunityMapResults then
        else
            l__PrivateServerData__2.UpdatingCommunityMapResults = true;
            l__PrivateServerData__2.CommunityMapResults = {};
            u3:FireServer("CommunityMapSearch", u13.SearchInput:getValue(), u13.state.Sort, u13.state.Filter);
            u13:setState({
                Open = ""
            });
        end;
    end;
    if not l__PrivateServerData__2.UpdatingCommunityMapResults then
        l__PrivateServerData__2.UpdatingCommunityMapResults = true;
        l__PrivateServerData__2.CommunityMapResults = {};
        u3:FireServer("CommunityMapSearch", "", 1, 1);
    end;
    local u17 = true;
    u13.UpdateStart = tick();
    local v18, v19 = u2.createBinding(u13.UpdateStart);
    u13.UpdateBinding = v18;
    u13.UpdateUpdate = v19;
    u13.Connection = l__RunService__1.Heartbeat:Connect(function(_) --[[ Line: 68 ]]
        -- upvalues: u13 (copy), l__PrivateServerData__2 (copy), u17 (ref), u3 (ref)
        u13.UpdateUpdate(tick());
        if l__PrivateServerData__2.UpdatingCommunityMapResults then
            u17 = true;
        else
            local v20 = u13.LastResult:getValue();
            if v20 then
                local v21 = u13.ScrollerResult:getValue();
                if v20.AbsolutePosition.Y + v20.AbsoluteSize.Y / 3 < v21.AbsolutePosition.Y + v21.AbsoluteSize.Y then
                    if u17 or l__PrivateServerData__2.UpdatingCommunityMapResults then
                    else
                        l__PrivateServerData__2.UpdatingCommunityMapResults = true;
                        u3:FireServer("CommunityMapSearchNext");
                        u13:setState({
                            Open = ""
                        });
                    end;
                else
                    u17 = false;
                end;
            end;
        end;
    end);
    u13:setState({
        Open = "",
        Sort = 1,
        Filter = 1
    });
end;
function v9.willUnmount(p22) --[[ Line: 103 ]]
    p22.Connection:Disconnect();
end;
function v9.render(u23) --[[ Line: 107 ]]
    -- upvalues: u12 (copy), u2 (copy), u6 (copy), u7 (copy), u8 (copy), u3 (copy), u5 (copy), u10 (copy), u4 (copy), u11 (copy)
    local l__props__3 = u23.props;
    local l__state__4 = u23.state;
    local l__PopupActive__5 = l__props__3.PopupActive;
    local _ = l__props__3.MatchmakingQueueData;
    local l__PrivateServerData__6 = l__props__3.PrivateServerData;
    local v24 = {};
    for u25, v26 in u12 do
        local u27 = l__state__4.Open == u25;
        v24[u25] = u2.createElement(u6, {
            Size = UDim2.fromScale(0.23, 0.6),
            Position = UDim2.fromScale(v26.Y, 0.2),
            Ignore = l__PopupActive__5 or l__PrivateServerData__6.UpdatingCommunityMapResults,
            Name = u25 .. ": " .. v26.Options[l__state__4[u25]],
            Callback = function() --[[ Name: Callback, Line 122 ]]
                -- upvalues: u23 (copy), u27 (copy), u25 (copy)
                u23:setState({
                    Open = u27 and "" or u25
                });
            end
        });
        if u27 then
            local v28 = {};
            local v29 = 0;
            for u30, v31 in v26.Options do
                if u30 ~= l__state__4[u25] then
                    v28[v31] = u2.createElement(u6, {
                        Ignore = l__PopupActive__5,
                        Layout = u30,
                        Name = v31,
                        Callback = function() --[[ Name: Callback, Line 141 ]]
                            -- upvalues: l__PrivateServerData__6 (copy), u23 (copy), u25 (copy), u30 (copy)
                            if l__PrivateServerData__6.UpdatingCommunityMapResults then
                            else
                                u23.state[u25] = u30;
                                u23.SearchPressed();
                            end;
                        end
                    });
                    v29 = v29 + 1;
                end;
            end;
            local v32 = 1 / v29;
            v24[u25 .. "Dropdown"] = u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundTransparency = 0.5,
                Position = UDim2.fromScale(v26.Y - 0.01, 1),
                Size = UDim2.fromScale(0.25, v29 * 0.6),
                BackgroundColor3 = Color3.new(0, 0, 0)
            }, { u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Position = UDim2.fromScale(0.05, 0),
                    Size = UDim2.fromScale(0.9, 1)
                }, { u2.createFragment(v28), u2.createElement("UIGridLayout", {
                        CellSize = UDim2.fromScale(1, v32 * 0.7),
                        CellPadding = UDim2.fromScale(0, v32 * 0.3),
                        FillDirection = Enum.FillDirection.Vertical,
                        SortOrder = Enum.SortOrder.LayoutOrder
                    }) }) });
        end;
    end;
    local l__CommunityMapMetadata__7 = l__PrivateServerData__6.CommunityMapMetadata;
    local l__CommunityMapResults__8 = l__PrivateServerData__6.CommunityMapResults;
    local l__FullCommunityMapResults__9 = l__PrivateServerData__6.FullCommunityMapResults;
    local v33 = #l__CommunityMapResults__8;
    local v34 = math.max(8, v33 + (l__FullCommunityMapResults__9 and 0 or 4)) / 4;
    local v35 = math.ceil(v34);
    local v36 = 1 / v35;
    local v37 = {
        Grid = u2.createElement("UIGridLayout", {
            CellPadding = UDim2.fromScale(0, 0),
            CellSize = UDim2.fromScale(0.25, v36),
            FillDirection = Enum.FillDirection.Horizontal,
            HorizontalAlignment = Enum.HorizontalAlignment.Left,
            SortOrder = Enum.SortOrder.LayoutOrder,
            StartCorner = Enum.StartCorner.TopLeft,
            VerticalAlignment = Enum.VerticalAlignment.Top
        })
    };
    for v38, u39 in l__CommunityMapResults__8 do
        local u40 = l__PrivateServerData__6.CurrentMap == u39.ID;
        v37[v38] = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            LayoutOrder = v38
        }, { u2.createElement(u7, {
                Ignore = l__PopupActive__5 or l__state__4.Open ~= "",
                Metadata = l__CommunityMapMetadata__7[u39.ID] or {},
                Fetchdata = u39,
                Selected = u40,
                Callback = function() --[[ Name: Callback, Line 207 ]]
                    -- upvalues: u40 (copy), u8 (ref), u3 (ref), u39 (copy), l__PrivateServerData__6 (copy)
                    if u40 then
                        u8:Open("Change Map", "This map is already selected, choose a different map.", {
                            { "Close", function() --[[ Line: 210 ]]
                                    -- upvalues: u8 (ref)
                                    u8:Close();
                                end }
                        });
                    else
                        u8:Open("Change Map", "Are you sure you want to switch map?\nThis will shutdown your private server.\nYou do not need to refresh your join code.", {
                            { "Yes", function() --[[ Line: 217 ]]
                                    -- upvalues: u3 (ref), u39 (ref), l__PrivateServerData__6 (ref), u8 (ref)
                                    u3:FireServer("PrivateServerMapUpdate", u39.ID);
                                    l__PrivateServerData__6.UpdatingPrivateServerCode = true;
                                    u8:Close();
                                end },
                            { "No", function() --[[ Line: 222 ]]
                                    -- upvalues: u8 (ref)
                                    u8:Close();
                                end }
                        });
                    end;
                end
            }) });
    end;
    if not (l__FullCommunityMapResults__9 or l__PrivateServerData__6.UpdatingCommunityMapResults) then
        for v41 = 1, 4 do
            local v42 = v33 + v41;
            local l__createElement__10 = u2.createElement;
            local v43 = "Frame";
            local v44 = {
                BackgroundTransparency = 1,
                LayoutOrder = v33 + v41
            };
            local l__Ref__11 = u2.Ref;
            local v45;
            if v41 == 4 then
                v45 = u23.LastResult or nil;
            else
                v45 = nil;
            end;
            v44[l__Ref__11] = v45;
            v37[v42] = l__createElement__10(v43, v44);
        end;
    end;
    local l__createFragment__12 = u2.createFragment;
    local v46 = {
        SearchBar = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.5,
            ZIndex = 2,
            BackgroundColor3 = Color3.new(),
            Size = UDim2.fromScale(1, 0.12),
            Position = UDim2.fromScale(0, 0)
        }, {
            Corner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }),
            Search = u2.createElement(u5, {
                PlaceholderText = "SEARCH COMMUNITY MAPS...",
                ClearTextOnFocus = true,
                BackgroundColor3 = Color3.new(),
                Position = UDim2.fromScale(0.01, 0.2),
                Size = UDim2.fromScale(0.356, 0.6),
                FontFace = u10,
                TextXAlignment = Enum.TextXAlignment.Left,
                TextBind = u23.SearchInput,
                TextBindUpdate = u23.SearchInputUpdate,
                EnterPressed = u23.SearchPressed,
                Ignore = l__PopupActive__5,
                Content = { u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0, 4)
                    }) }
            }),
            Find = u2.createElement(u6, {
                Name = "Search",
                Size = UDim2.fromScale(0.115, 0.6),
                Position = UDim2.fromScale(0.38, 0.2),
                Ignore = l__PopupActive__5,
                Loading = l__PrivateServerData__6.UpdatingCommunityMapResults,
                Callback = u23.SearchPressed
            }),
            u2.createFragment(v24)
        }),
        SearchResults = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.5,
            BackgroundColor3 = Color3.new(),
            Size = UDim2.fromScale(1, 0.86),
            Position = UDim2.fromScale(0, 0.14)
        }, {
            Corner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }),
            Scroller = u2.createElement(u4, {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(0.98, 0.94),
                Position = UDim2.fromScale(0.01, 0.03),
                Ignore = l__PopupActive__5,
                Ref = u23.ScrollerResult,
                CanvasSize = v35 / 2,
                Content = v37
            })
        })
    };
    local v47;
    if l__PrivateServerData__6.UpdatingCommunityMapResults then
        v47 = u2.createElement("ImageLabel", {
            BackgroundTransparency = 0.25,
            BorderSizePixel = 0,
            Image = "rbxassetid://13867939464",
            ZIndex = 3,
            BackgroundColor3 = Color3.new(0, 0, 0),
            Position = UDim2.fromScale(0, 0.6),
            Size = UDim2.fromScale(1, 0.4),
            ImageColor3 = Color3.fromRGB(163, 121, 82),
            TileSize = UDim2.fromOffset(6, 6),
            ScaleType = Enum.ScaleType.Tile
        }, {
            Gradient = u2.createElement("UIGradient", {
                Rotation = 90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
            }),
            Header = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.15),
                Position = UDim2.fromScale(0, 0.3),
                Text = #l__CommunityMapResults__8 > 0 and "FINDING MORE MAPS" or "FINDING MAPS",
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u11,
                TextXAlignment = Enum.TextXAlignment.Center
            }),
            Loading = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://15478256777",
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.6),
                Size = UDim2.fromScale(0.15, 0.15),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                Rotation = u23.UpdateBinding:map(function(p48) --[[ Line: 338 ]]
                    -- upvalues: u23 (copy)
                    return (u23.UpdateStart - p48) * 600;
                end),
                ImageColor3 = Color3.new(1, 1, 1)
            })
        }) or nil;
    else
        v47 = nil;
    end;
    v46.SearchFade = v47;
    return l__createFragment__12(v46);
end;
return v9;