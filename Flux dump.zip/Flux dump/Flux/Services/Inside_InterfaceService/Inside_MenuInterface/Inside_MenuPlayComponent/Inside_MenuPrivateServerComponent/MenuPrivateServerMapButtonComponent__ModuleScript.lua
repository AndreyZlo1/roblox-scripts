-- Services.InterfaceService.MenuInterface.MenuPlayComponent.MenuPrivateServerComponent.MenuPrivateServerMapButtonComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

game:GetService("Players");
local v1, u2, u3 = shared.import("require", "Roact", "network");
local u4 = v1("PopupInterface");
local u5 = v1("GameShellProxyButton");
local u6 = v1("RoactTween");
local v7 = u2.Component:extend("MenuPrivateServerWhitelist");
local u8 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u9 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local function u15(u10) --[[ Line: 15 ]]
    -- upvalues: u2 (copy), u5 (copy)
    local l__Position__1 = u10.Position;
    local l__Ignore__2 = u10.Ignore;
    local l__Rating__3 = u10.Rating;
    return u2.createElement(u5, {
        BackgroundTransparency = 1,
        Image = "rbxassetid://2925606659",
        ZIndex = 2,
        Ignore = l__Ignore__2,
        Position = UDim2.fromScale(l__Position__1 / 10, 0.85),
        Size = UDim2.fromScale(0.06, 0.06),
        SizeConstraint = Enum.SizeConstraint.RelativeXX,
        ImageColor3 = l__Rating__3 and Color3.new(1, 1, 1) or Color3.new(0.5, 0.5, 0.5),
        ImageTransparency = u10.StarBinding:map(function(p11) --[[ Line: 28 ]]
            return p11 and 0 or 0.5;
        end),
        MouseUp = function() --[[ Name: MouseUp, Line 36 ]]
            -- upvalues: u10 (copy), l__Position__1 (copy)
            u10.Callback(l__Position__1);
        end,
        MouseEnter = function() --[[ Name: MouseEnter, Line 39 ]]
            -- upvalues: u10 (copy), l__Position__1 (copy)
            u10.UpdateStar(l__Position__1);
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 42 ]]
            -- upvalues: u10 (copy), l__Position__1 (copy)
            if u10.StarBinding:getValue() == l__Position__1 then
                u10.UpdateStar(nil);
            end;
        end
    }, { u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ClipsDescendants = true,
            Size = u10.StarBinding:map(function(p12) --[[ Line: 51 ]]
                -- upvalues: l__Position__1 (copy), l__Rating__3 (copy)
                local v13 = 0;
                if p12 then
                    v13 = l__Position__1 <= p12 and 1 or 0;
                elseif l__Rating__3 then
                    v13 = math.clamp(l__Rating__3, l__Position__1 - 1, l__Position__1) - (l__Position__1 - 1);
                end;
                return UDim2.fromScale(v13, 1);
            end)
        }, { u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://2925606659",
                ImageColor3 = Color3.fromRGB(255, 198, 55),
                Size = UDim2.fromScale(1, 1),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                ImageTransparency = u10.StarBinding:map(function(p14) --[[ Line: 68 ]]
                    return p14 and 0 or 0.5;
                end)
            }) }) });
end;
function v7.init(u16, u17) --[[ Line: 79 ]]
    -- upvalues: u2 (copy), u4 (copy), u3 (copy), u6 (copy)
    local v18, v19 = u2.createBinding();
    u16.StarBinding = v18;
    u16.UpdateStar = v19;
    u16.Name = "";
    function u16.RateMap(u20) --[[ Line: 83 ]]
        -- upvalues: u4 (ref), u16 (copy), u3 (ref), u17 (copy)
        local v21 = {
            { "Yes", function() --[[ Line: 85 ]]
                    -- upvalues: u3 (ref), u17 (ref), u20 (copy), u4 (ref)
                    u3:FireServer("CommunityMapRate", u17.Fetchdata.ID, u20);
                    u4:Close();
                end },
            { "No", function() --[[ Line: 89 ]]
                    -- upvalues: u4 (ref)
                    u4:Close();
                end }
        };
        u4:Open("Rate Map", "Are you sure you want to rate \'" .. u16.Name .. "\' " .. tostring(u20) .. "/5 stars?", v21);
    end;
    u16.Hover = u6.new(0);
    u16:setState({
        Hovering = false
    });
end;
function v7.render(u22) --[[ Line: 101 ]]
    -- upvalues: u2 (copy), u9 (copy), u15 (copy), u5 (copy), u8 (copy)
    local l__props__4 = u22.props;
    local l__Ignore__5 = l__props__4.Ignore;
    local l__Metadata__6 = l__props__4.Metadata;
    local l__Fetchdata__7 = l__props__4.Fetchdata;
    local v23 = l__Fetchdata__7.Rating or l__Metadata__6.Rating;
    local l__ID__8 = l__Fetchdata__7.ID;
    local v24 = l__ID__8:sub(l__ID__8:find("_") + 1);
    u22.Name = v24;
    local v25 = {};
    if l__props__4.Selected then
        v25.Selected = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.5,
            LayoutOrder = 2,
            Size = UDim2.fromScale(1, 0.2),
            BackgroundColor3 = Color3.new()
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "CURRENTLY SELECTED",
                TextScaled = true,
                Size = UDim2.fromScale(0.8, 0.6),
                Position = UDim2.fromScale(0.1, 0.2),
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u9,
                TextXAlignment = Enum.TextXAlignment.Center
            }) });
    end;
    if l__Fetchdata__7.ReviewActive then
        v25.ReviewActive = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.2,
            Size = UDim2.fromScale(1, 0.2),
            BackgroundColor3 = Color3.new()
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "UNDER REVIEW",
                TextScaled = true,
                Size = UDim2.fromScale(0.8, 0.6),
                Position = UDim2.fromScale(0.1, 0.2),
                TextColor3 = Color3.new(0.72549, 0.482352, 0.164705),
                FontFace = u9,
                TextXAlignment = Enum.TextXAlignment.Center
            }) });
    end;
    if l__Fetchdata__7.ReviewDenied then
        v25.ReviewDenied = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.2,
            Size = UDim2.fromScale(1, 0.2),
            BackgroundColor3 = Color3.new()
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "FAILED REVIEW",
                TextScaled = true,
                Size = UDim2.fromScale(0.8, 0.6),
                Position = UDim2.fromScale(0.1, 0.2),
                TextColor3 = Color3.new(0.72549, 0.164705, 0.164705),
                FontFace = u9,
                TextXAlignment = Enum.TextXAlignment.Center
            }) });
    end;
    if l__Fetchdata__7.ReviewPassed then
        v25.ReviewPassed = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.2,
            Size = UDim2.fromScale(1, 0.2),
            BackgroundColor3 = Color3.new()
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "PASSED REVIEW",
                TextScaled = true,
                Size = UDim2.fromScale(0.8, 0.6),
                Position = UDim2.fromScale(0.1, 0.2),
                TextColor3 = Color3.new(0.321568, 0.72549, 0.164705),
                FontFace = u9,
                TextXAlignment = Enum.TextXAlignment.Center
            }) });
    end;
    if l__Fetchdata__7.Private then
        v25.Private = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.2,
            Size = UDim2.fromScale(1, 0.2),
            BackgroundColor3 = Color3.new()
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "🔒 PRIVATE",
                TextScaled = true,
                Size = UDim2.fromScale(0.8, 0.6),
                Position = UDim2.fromScale(0.1, 0.2),
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u9,
                TextXAlignment = Enum.TextXAlignment.Center
            }) });
    end;
    local v26 = {};
    for v27 = 1, 5 do
        v26["Star" .. v27] = u15({
            Position = v27,
            Ignore = l__Ignore__5,
            Rating = v23,
            UpdateStar = u22.UpdateStar,
            StarBinding = u22.StarBinding,
            Callback = u22.RateMap
        });
    end;
    return u2.createElement("Frame", {
        BorderSizePixel = 0,
        ClipsDescendants = true,
        Position = UDim2.fromScale(0.05, 0.05),
        Size = UDim2.fromScale(0.9, 0.9)
    }, {
        Button = u2.createElement(u5, {
            BackgroundTransparency = 1,
            Image = "",
            Size = UDim2.fromScale(1, 0.8),
            Ignore = l__Ignore__5,
            MouseUp = function() --[[ Name: MouseUp, Line 235 ]]
                -- upvalues: l__props__4 (copy)
                l__props__4.Callback();
            end,
            MouseEnter = function() --[[ Name: MouseEnter, Line 238 ]]
                -- upvalues: u22 (copy)
                u22.Hover:SetGoal(1);
                u22:setState({
                    Hovering = true
                });
            end,
            MouseLeave = function() --[[ Name: MouseLeave, Line 244 ]]
                -- upvalues: u22 (copy)
                u22.Hover:SetGoal(0);
                u22:setState({
                    Hovering = false
                });
            end
        }),
        Icon = u2.createElement("ImageLabel", {
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = u22.Hover:Map(function(p28) --[[ Line: 254 ]]
                return UDim2.fromScale(p28 / 5 + 1, p28 / 5 + 1);
            end),
            BackgroundColor3 = Color3.fromRGB(48, 48, 48),
            Image = l__Metadata__6.Image or (l__Fetchdata__7.Image or "")
        }, { u2.createElement("UIGradient", {
                Rotation = 90,
                Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.new(1, 1, 1)), ColorSequenceKeypoint.new(0.5, Color3.new(1, 1, 1)), ColorSequenceKeypoint.new(1, Color3.new(0, 0, 0)) })
            }) }),
        Stroke = u2.createElement("UIStroke", {
            Thickness = 1,
            Color = u22.state.Hovering and Color3.fromRGB(255, 194, 89) or Color3.fromRGB(71, 71, 71),
            LineJoinMode = Enum.LineJoinMode.Round
        }),
        Name = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            ZIndex = 2,
            Size = UDim2.fromScale(0.8, 0.12),
            Position = UDim2.fromScale(0.1, 0.65),
            Text = v24,
            TextColor3 = Color3.new(1, 1, 1),
            FontFace = u9,
            TextXAlignment = Enum.TextXAlignment.Left
        }),
        Author = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            ZIndex = 2,
            Size = UDim2.fromScale(0.8, 0.08),
            Position = UDim2.fromScale(0.1, 0.75),
            Text = "By " .. (l__Metadata__6.Owner or "___________________"),
            TextColor3 = Color3.new(1, 1, 1),
            FontFace = u8,
            TextXAlignment = Enum.TextXAlignment.Left
        }),
        Downloads = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            ZIndex = 2,
            Size = UDim2.fromScale(0.8, 0.08),
            Position = UDim2.fromScale(0.1, 0.76),
            Text = l__Metadata__6.Downloads or (l__Fetchdata__7.Downloads or "____"),
            TextColor3 = Color3.new(1, 1, 1),
            FontFace = u9,
            TextXAlignment = Enum.TextXAlignment.Right
        }),
        Download = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "Downloads",
            TextScaled = true,
            ZIndex = 2,
            Size = UDim2.fromScale(0.8, 0.08),
            Position = UDim2.fromScale(0.1, 0.855),
            TextColor3 = Color3.new(1, 1, 1),
            FontFace = u8,
            TextXAlignment = Enum.TextXAlignment.Right
        }),
        Tags = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            Size = UDim2.fromScale(1, 1)
        }, { u2.createElement("UIListLayout", {
                SortOrder = Enum.SortOrder.LayoutOrder,
                FillDirection = Enum.FillDirection.Vertical,
                VerticalAlignment = Enum.VerticalAlignment.Top,
                HorizontalAlignment = Enum.HorizontalAlignment.Left,
                Padding = UDim.new(0, 0)
            }), u2.createFragment(v25) }),
        u2.createFragment(v26)
    });
end;
return v7;