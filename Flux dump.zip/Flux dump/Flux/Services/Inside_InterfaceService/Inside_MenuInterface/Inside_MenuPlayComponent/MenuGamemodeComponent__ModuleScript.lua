-- Services.InterfaceService.MenuInterface.MenuPlayComponent.MenuGamemodeComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "network");
local u3 = v1("GameShellProxyButton");
local u4 = v1("RoactTween");
v1("PopupInterface");
local v5 = u2.Component:extend("MenuGamemode");
local u6 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
function v5.init(p7, _) --[[ Line: 12 ]]
    -- upvalues: u4 (copy)
    p7.Hover = u4.new(0);
    p7:setState({
        Hovering = false
    });
end;
function v5.render(u8) --[[ Line: 19 ]]
    -- upvalues: u2 (copy), u3 (copy), u6 (copy)
    local l__props__1 = u8.props;
    local l__state__2 = u8.state;
    local l__Name__3 = l__props__1.Name;
    local l__Hovering__4 = l__state__2.Hovering;
    local v9 = l__Hovering__4 and Color3.fromRGB(255, 194, 89) or Color3.fromRGB(71, 71, 71);
    local l__createElement__5 = u2.createElement;
    local v10 = u3;
    local v11 = {
        SoundKit = "MainMenuBig",
        Image = "",
        BorderSizePixel = 0,
        ClipsDescendants = true,
        BackgroundColor3 = Color3.fromRGB(15, 15, 15),
        Ignore = l__props__1.Ignore,
        Size = l__props__1.Size,
        Position = l__props__1.Position,
        MouseUp = function() --[[ Name: MouseUp, Line 38 ]]
            -- upvalues: l__props__1 (copy)
            l__props__1.Callback();
        end,
        MouseEnter = function() --[[ Name: MouseEnter, Line 41 ]]
            -- upvalues: u8 (copy)
            u8.Hover:SetGoal(1);
            u8:setState({
                Hovering = true
            });
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 47 ]]
            -- upvalues: u8 (copy)
            u8.Hover:SetGoal(0);
            u8:setState({
                Hovering = false
            });
        end
    };
    local v14 = {
        Hover = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = u8.Hover:Map(function(p12) --[[ Line: 58 ]]
                local v13 = p12 / 3;
                return UDim2.fromScale(v13 + 1, v13 + 1);
            end),
            ScaleType = Enum.ScaleType.Crop,
            Image = l__Hovering__4 and l__props__1.HoverImage or l__props__1.Image
        }),
        Frame = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0, 1),
            Size = UDim2.fromScale(1, 0.1),
            SizeConstraint = Enum.SizeConstraint.RelativeXX,
            Position = UDim2.fromScale(0, 1),
            BackgroundColor3 = Color3.fromRGB(16, 16, 16)
        }, {
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                Size = UDim2.fromScale(1, 1),
                ImageColor3 = v9,
                TileSize = UDim2.fromOffset(6, 6),
                ScaleType = Enum.ScaleType.Tile
            }, {
                Gradient = u2.createElement("UIGradient", {
                    Transparency = NumberSequence.new({
                        NumberSequenceKeypoint.new(0, 0.8),
                        NumberSequenceKeypoint.new(0.4, 0.8),
                        NumberSequenceKeypoint.new(0.6, 0),
                        NumberSequenceKeypoint.new(1, 0)
                    })
                }),
                Name = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    ZIndex = 3,
                    Size = UDim2.fromScale(1, 0.6),
                    Position = UDim2.fromScale(0.05, 0.5),
                    AnchorPoint = Vector2.new(0, 0.5),
                    Text = l__Name__3:upper(),
                    TextColor3 = v9,
                    TextXAlignment = Enum.TextXAlignment.Left,
                    FontFace = u6
                })
            })
        })
    };
    local l__Banner__6 = l__props__1.Banner;
    if l__Banner__6 then
        l__Banner__6 = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0, 0),
            Size = UDim2.fromScale(1, 0.1),
            SizeConstraint = Enum.SizeConstraint.RelativeXX,
            Position = UDim2.fromScale(0, 0),
            BackgroundColor3 = Color3.fromRGB(255, 149, 0)
        }, {
            Name = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                ZIndex = 3,
                Size = UDim2.fromScale(1, 0.6),
                Position = UDim2.fromScale(0, 0.5),
                AnchorPoint = Vector2.new(0, 0.5),
                Text = l__props__1.Banner:upper(),
                TextColor3 = Color3.new(),
                TextXAlignment = Enum.TextXAlignment.Center,
                FontFace = u6
            })
        });
    end;
    v14.Banner = l__Banner__6;
    v14.Stroke = u2.createElement("UIStroke", {
        Thickness = 1,
        ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
        Color = v9,
        LineJoinMode = Enum.LineJoinMode.Round
    }, {
        Gradient = u2.createElement("UIGradient", {
            Rotation = 0,
            Transparency = u8.Hover:Map(function(p15) --[[ Line: 134 ]]
                return NumberSequence.new({
                    NumberSequenceKeypoint.new(0, 0),
                    NumberSequenceKeypoint.new(0.2, 1 - p15),
                    NumberSequenceKeypoint.new(0.8, 1 - p15),
                    NumberSequenceKeypoint.new(1, 0)
                });
            end)
        })
    });
    return l__createElement__5(v10, v11, v14);
end;
return v5;