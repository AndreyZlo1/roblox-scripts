-- Services.InterfaceService.MenuInterface.MenuPlayComponent.MenuPlayerFriendComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "network");
local u4 = v1("GameShellProxyButton");
v1("MenuButtonComponent");
local u5 = v1("RoactTween");
local v6 = u2.Component:extend("MenuGamemode");
local u7 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u8 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
function v6.init(p9, _) --[[ Line: 13 ]]
    -- upvalues: u5 (copy)
    p9.Hover = u5.new(0);
    p9.Clicked = u5.new(1);
    p9:setState({
        Hovering = false
    });
end;
function v6.render(u10) --[[ Line: 21 ]]
    -- upvalues: u2 (copy), u4 (copy), u3 (copy), u7 (copy), u8 (copy)
    local l__props__1 = u10.props;
    local l__state__2 = u10.state;
    local l__Friend__3 = l__props__1.Friend;
    local l__LocationType__4 = l__Friend__3.LocationType;
    local l__Here__5 = l__props__1.Here;
    local v11 = l__LocationType__4 == 3;
    local v12 = l__LocationType__4 == 0 and true or l__LocationType__4 == 2;
    local l__createElement__6 = u2.createElement;
    local v13 = "Frame";
    local v15 = {
        BackgroundTransparency = 1,
        ZIndex = u10.Hover:Map(function(p14) --[[ Line: 32 ]]
            return p14 > 0.02 and 2 or 1;
        end)
    };
    local v19 = {
        Click = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 3,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = u10.Clicked:Map(function(p16) --[[ Line: 42 ]]
                return UDim2.fromScale(p16, 1.52);
            end),
            BackgroundColor3 = Color3.new(1, 1, 1),
            BackgroundTransparency = u10.Clicked:Map(function(p17) --[[ Line: 47 ]]
                return p17;
            end)
        }),
        Invite = u2.createElement(u4, {
            SoundKit = "MainMenu",
            Image = "",
            BorderSizePixel = 0,
            BackgroundTransparency = 1,
            ZIndex = 3,
            Ignore = l__props__1.Ignore,
            Scroller = l__props__1.Scroller,
            Size = UDim2.fromScale(l__Here__5 and 0.5 or 1, 1),
            MouseUp = function() --[[ Name: MouseUp, Line 63 ]]
                -- upvalues: u10 (copy), u3 (ref), l__Friend__3 (copy)
                u10.Clicked:SetValue(0);
                u10.Clicked:SetGoal(1);
                u3:FireServer("SendInvite", l__Friend__3.VisitorId);
            end,
            MouseEnter = function() --[[ Name: MouseEnter, Line 68 ]]
                -- upvalues: l__props__1 (copy), u10 (copy)
                l__props__1.Hover:SetGoal(1);
                u10.Hover:SetGoal(1);
                u10:setState({
                    Type = "Invite"
                });
            end,
            MouseLeave = function() --[[ Name: MouseLeave, Line 75 ]]
                -- upvalues: l__props__1 (copy), u10 (copy)
                l__props__1.Hover:SetGoal(0);
                u10.Hover:SetGoal(0);
            end
        }, {
            Icon = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://15543313048",
                Size = UDim2.fromScale(0.4, 0.4),
                Position = UDim2.fromScale(0.5, 0.3),
                AnchorPoint = Vector2.new(0.5, 0),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                ImageColor3 = l__state__2.Type == "Invite" and Color3.fromRGB(255, 194, 89) or Color3.new(1, 1, 1),
                ImageTransparency = u10.Hover:Map(function(p18) --[[ Line: 88 ]]
                    return 1 - p18;
                end)
            })
        })
    };
    local v20;
    if l__Here__5 then
        v20 = u2.createElement(u4, {
            SoundKit = "MainMenu",
            Image = "",
            BorderSizePixel = 0,
            BackgroundTransparency = 1,
            ZIndex = 3,
            Ignore = l__props__1.Ignore,
            Position = UDim2.fromScale(0.5, 0),
            Size = UDim2.fromScale(0.5, 1),
            MouseUp = function() --[[ Name: MouseUp, Line 104 ]]
                -- upvalues: u10 (copy), l__props__1 (copy), l__Friend__3 (copy)
                u10.Clicked:SetValue(0);
                u10.Clicked:SetGoal(1);
                l__props__1.Join(l__Friend__3.PlaceId, l__Friend__3.GameId);
            end,
            MouseEnter = function() --[[ Name: MouseEnter, Line 109 ]]
                -- upvalues: l__props__1 (copy), u10 (copy)
                l__props__1.Hover:SetGoal(1);
                u10.Hover:SetGoal(1);
                u10:setState({
                    Type = "Join"
                });
            end,
            MouseLeave = function() --[[ Name: MouseLeave, Line 116 ]]
                -- upvalues: l__props__1 (copy), u10 (copy)
                l__props__1.Hover:SetGoal(0);
                u10.Hover:SetGoal(0);
            end
        }, {
            Icon = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://15543312915",
                Size = UDim2.fromScale(0.4, 0.4),
                Position = UDim2.fromScale(0.5, 0.3),
                AnchorPoint = Vector2.new(0.5, 0),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                ImageColor3 = l__state__2.Type == "Join" and Color3.fromRGB(255, 194, 89) or Color3.new(1, 1, 1),
                ImageTransparency = u10.Hover:Map(function(p21) --[[ Line: 129 ]]
                    return 1 - p21;
                end)
            })
        }) or nil;
    else
        v20 = nil;
    end;
    v19.Join = v20;
    v19.Hover = u2.createElement("Frame", {
        BorderSizePixel = 0,
        BackgroundTransparency = 0.5,
        ZIndex = 2,
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.fromScale(0.5, 0.5),
        Size = u10.Hover:Map(function(p22) --[[ Line: 137 ]]
            return UDim2.fromScale(1, p22 * 1.52);
        end),
        BackgroundColor3 = Color3.new()
    });
    v19.Icon = u2.createElement("ImageLabel", {
        BackgroundTransparency = 1,
        Position = UDim2.fromScale(0.05, 0),
        Size = UDim2.fromScale(1, 1),
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        Image = "rbxthumb://type=AvatarHeadShot&id=" .. l__Friend__3.VisitorId .. "&w=60&h=60"
    });
    v19.Name = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextStrokeTransparency = 0.8,
        TextScaled = true,
        Size = UDim2.fromScale(0.8, 0.4),
        Position = UDim2.fromScale(0.22, 0.1),
        Text = l__Friend__3.DisplayName,
        TextColor3 = Color3.new(1, 1, 1),
        TextStrokeColor3 = Color3.new(),
        FontFace = u7,
        TextXAlignment = Enum.TextXAlignment.Left
    });
    v19.Activity = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        RichText = true,
        TextStrokeTransparency = 0.8,
        TextScaled = true,
        Size = UDim2.fromScale(10, 0.4),
        Position = UDim2.fromScale(0.22, 0.5),
        TextColor3 = l__Here__5 and Color3.new(0, 1, 0) or ((v12 or v11) and Color3.fromRGB(255, 189, 20) or Color3.fromRGB(0, 170, 255)),
        Text = v12 and "<i>WEBSITE</i>" or (v11 and "<i>IN-STUDIO</i>" or (l__Here__5 and "<i>IN-GAME</i> " .. l__Here__5 or "<i>PLAYING</i> " .. l__Friend__3.LastLocation)),
        TextStrokeColor3 = Color3.new(),
        FontFace = u8,
        TextXAlignment = Enum.TextXAlignment.Left
    });
    return l__createElement__6(v13, v15, v19);
end;
return v6;