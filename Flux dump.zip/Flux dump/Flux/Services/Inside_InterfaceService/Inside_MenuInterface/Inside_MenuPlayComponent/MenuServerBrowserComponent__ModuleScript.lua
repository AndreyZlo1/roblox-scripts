-- Services.InterfaceService.MenuInterface.MenuPlayComponent.MenuServerBrowserComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "network");
local u4 = v1("GameShellProxyScroller");
local u5 = v1("GameShellProxyInput");
local u6 = v1("MenuButtonComponent");
local u7 = v1("RoactTween");
v1("PopupInterface");
local u8 = v1("GameVersion");
local l__Players__1 = game:GetService("Players");
local l__RunService__2 = game:GetService("RunService");
local l__UserInputService__3 = game:GetService("UserInputService");
game:GetService("MarketplaceService");
local v9 = u2.Component:extend("MenuGamemode");
local _ = l__Players__1.LocalPlayer;
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u10 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u11 = Font.fromEnum(Enum.Font.Code);
local function u14(u12) --[[ Line: 37 ]]
    -- upvalues: u2 (copy), u10 (copy)
    return u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        Size = UDim2.fromScale(u12.Width, 0.03),
        Position = u12.Position,
        Text = u12.Name,
        TextColor3 = Color3.new(1, 1, 1),
        FontFace = u10,
        TextXAlignment = Enum.TextXAlignment.Left
    }, { u2.createElement("Frame", {
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(1, 0.5),
            BackgroundColor3 = Color3.new(1, 1, 1),
            Size = u12.Landing:Map(function(p13) --[[ Line: 52 ]]
                -- upvalues: u12 (copy)
                return UDim2.new(p13 * u12.LineWidth, 0, 0, 2);
            end),
            Position = UDim2.fromScale(1, 0.5)
        }) });
end;
function v9.init(u15, u16) --[[ Line: 60 ]]
    -- upvalues: u3 (copy), u2 (copy), u7 (copy), l__RunService__2 (copy), l__UserInputService__3 (copy)
    local u17 = false;
    local u18 = 0;
    function u15.GetServers(u19) --[[ Line: 63 ]]
        -- upvalues: u17 (ref), u18 (ref), u15 (copy), u3 (ref), u16 (copy)
        if u17 or tick() - u18 < 5 and not u19 then
        else
            u18 = tick();
            u17 = true;
            u15:setState({
                Fetching = true,
                Servers = u15.state.Servers or {}
            });
            task.spawn(function() --[[ Line: 74 ]]
                -- upvalues: u3 (ref), u16 (ref), u15 (ref), u17 (ref), u19 (copy)
                local v20, v21 = u3:InvokeServer("GetServers", u16.BrowserQueue, u15.LastKey);
                if u15.Destroyed then
                else
                    u17 = false;
                    u15.LastKey = v21;
                    if u19 then
                        local l__Servers__4 = u15.state.Servers;
                        for _, v22 in v20 do
                            l__Servers__4[#l__Servers__4 + 1] = v22;
                        end;
                        u15:setState({
                            Fetching = false,
                            Servers = l__Servers__4
                        });
                    else
                        u15:setState({
                            Fetching = false,
                            Servers = v20
                        });
                    end;
                end;
            end);
        end;
    end;
    local v23, v24 = u2.createBinding();
    u15.JoinCode = v23;
    u15.JoinCodeUpdate = v24;
    function u15.JoinPressed() --[[ Line: 102 ]]
        -- upvalues: u16 (copy), u15 (copy)
        u16.JoinSession(u16.BrowserQueue, u15.JoinCode:getValue());
    end;
    u15.Landing = u7.new(0);
    u15.LastResult = u2.createRef();
    u15.ScrollerResult = u2.createRef();
    local u25 = false;
    u15.UpdateStart = tick();
    local v26, v27 = u2.createBinding(u15.UpdateStart);
    u15.UpdateBinding = v26;
    u15.UpdateUpdate = v27;
    u15.Connection = l__RunService__2.Heartbeat:Connect(function(_) --[[ Line: 113 ]]
        -- upvalues: u15 (copy), u17 (ref), u25 (ref)
        u15.UpdateUpdate(tick());
        local v28 = u15.LastResult:getValue();
        if v28 then
            local v29 = u15.ScrollerResult:getValue();
            if v28.AbsolutePosition.Y < v29.AbsolutePosition.Y + v29.AbsoluteSize.Y then
                if u15.LastKey and not (u17 or u25) then
                    u15.GetServers(u15.LastKey);
                end;
                u25 = true;
            else
                u25 = false;
            end;
        end;
    end);
    u15.Input = l__UserInputService__3.InputBegan:Connect(function(p30) --[[ Line: 132 ]]
        -- upvalues: u16 (copy)
        if p30.KeyCode == Enum.KeyCode.ButtonB then
            u16.Return();
        end;
    end);
    u15.Landing:SetGoal(1);
    u15.GetServers();
end;
function v9.willUnmount(p31) --[[ Line: 142 ]]
    p31.Destroyed = true;
    p31.Connection:Disconnect();
    p31.Input:Disconnect();
end;
function v9.render(u32) --[[ Line: 148 ]]
    -- upvalues: u2 (copy), u8 (copy), u10 (copy), u6 (copy), u14 (copy), u5 (copy), u11 (copy), u4 (copy)
    local l__props__5 = u32.props;
    local l__state__6 = u32.state;
    local l__PopupActive__7 = l__props__5.PopupActive;
    local l__Landing__8 = u32.Landing;
    local l__Servers__9 = l__state__6.Servers;
    local v33 = math.max(20, #l__Servers__9);
    local v34 = 1 / v33;
    local v35 = {
        Grid = u2.createElement("UIGridLayout", {
            FillDirection = Enum.FillDirection.Vertical,
            SortOrder = Enum.SortOrder.LayoutOrder,
            CellPadding = UDim2.fromScale(0, v34 * 0.2),
            CellSize = UDim2.fromScale(1, v34 * 0.8)
        })
    };
    local v36 = #l__Servers__9;
    for v37, u38 in l__Servers__9 do
        local v39 = u8 ~= u38.vr;
        local v40 = u38.count >= u38.max;
        local l__createElement__10 = u2.createElement;
        local v41 = "Frame";
        local v42 = {};
        local l__Ref__11 = u2.Ref;
        local v43;
        if v37 == v36 then
            v43 = u32.LastResult or nil;
        else
            v43 = nil;
        end;
        v42[l__Ref__11] = v43;
        v42.BackgroundTransparency = 1;
        local v44 = {};
        local l__createElement__12 = u2.createElement;
        local v45 = "TextLabel";
        local v46 = {
            TextWrapped = true,
            TextScaled = true,
            BackgroundTransparency = 1,
            FontFace = u10,
            Size = UDim2.new(0.92, 0, 1, 0),
            TextColor3 = Color3.fromRGB(255, 255, 255)
        };
        local v47;
        if u38.iso == "N/A" then
            v47 = "N/A";
        else
            local v48 = string.upper(u38.iso);
            local v49 = string.byte(v48, 1) + 127397;
            local v50 = string.byte(v48, 2) + 127397;
            v47 = utf8.char(v49) .. utf8.char(v50);
        end;
        v46.Text = v47;
        v46.Position = UDim2.new(0.01, 0, 0, 0);
        v46.TextXAlignment = Enum.TextXAlignment.Left;
        local v51 = l__createElement__12(v45, v46);
        local v52 = u2.createElement("TextLabel", {
            TextWrapped = true,
            TextScaled = true,
            BackgroundTransparency = 1,
            FontFace = u10,
            Size = UDim2.new(0.92, 0, 1, 0),
            TextColor3 = Color3.fromRGB(255, 255, 255),
            Text = u38.id,
            Position = UDim2.new(0.1, 0, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Left
        });
        local v53 = u2.createElement("TextLabel", {
            TextWrapped = true,
            TextScaled = true,
            BackgroundTransparency = 1,
            FontFace = u10,
            Size = UDim2.new(0.92, 0, 1, 0),
            TextColor3 = Color3.fromRGB(255, 255, 255),
            Text = u38.vr .. (v39 and " (OUT-DATED)" or ""),
            Position = UDim2.new(0.4, 0, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Left
        });
        local v54 = u2.createElement("TextLabel", {
            TextWrapped = true,
            TextScaled = true,
            BackgroundTransparency = 1,
            FontFace = u10,
            Size = UDim2.new(0.92, 0, 1, 0),
            TextColor3 = Color3.fromRGB(255, 255, 255),
            Text = u38.vc and "VC-ONLY" or "-",
            Position = UDim2.new(0.55, 0, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Left
        });
        local v55 = u2.createElement("TextLabel", {
            TextWrapped = true,
            TextScaled = true,
            BackgroundTransparency = 1,
            FontFace = u10,
            Size = UDim2.new(0.92, 0, 1, 0),
            TextColor3 = Color3.fromRGB(255, 255, 255),
            Text = u38.count .. "/" .. u38.max .. (v40 and " (FULL)" or ""),
            Position = UDim2.new(0.7, 0, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Left
        });
        local v56 = not (v39 or v40);
        if v56 then
            v56 = u2.createElement(u6, {
                Name = "JOIN",
                Size = UDim2.new(0.1, 0, 1, -2),
                Position = UDim2.new(0.85, 0, 0, 1),
                Callback = function() --[[ Name: Callback, Line 234 ]]
                    -- upvalues: l__props__5 (copy), u38 (copy)
                    l__props__5.JoinSession(l__props__5.BrowserQueue, u38.id);
                end,
                Ignore = l__PopupActive__7,
                Scroller = l__props__5.ScrollerResult
            });
        end;
        v44[1], v44[2], v44[3], v44[4], v44[5], v44[6] = v51, v52, v53, v54, v55, v56;
        v35[v37] = l__createElement__10(v41, v42, v44);
    end;
    local l__createElement__13 = u2.createElement;
    local v57 = "Frame";
    local v58 = {
        BackgroundTransparency = 1,
        AnchorPoint = Vector2.new(0.5, 0),
        Size = UDim2.fromScale(0, 0.85),
        Position = UDim2.fromScale(0.5, 0.05)
    };
    local v59 = {
        Aspect = u2.createElement("UIAspectRatioConstraint", {
            AspectRatio = 2,
            AspectType = Enum.AspectType.ScaleWithParentSize,
            DominantAxis = Enum.DominantAxis.Height
        }),
        JoinHeader = u14({
            Name = "JOIN SERVER BY CODE",
            Width = 0.495,
            LineWidth = 0.77,
            Position = UDim2.fromScale(0, 0),
            Landing = l__Landing__8
        }),
        JoinBody = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.5,
            BackgroundColor3 = Color3.new(),
            Size = UDim2.fromScale(0.495, 0.1),
            Position = UDim2.fromScale(0, 0.035)
        }, {
            u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }),
            Code = u2.createElement(u5, {
                PlaceholderText = "ENTER PUBLIC SERVER CODE HERE",
                ClearTextOnFocus = true,
                BackgroundColor3 = Color3.new(),
                Position = UDim2.fromScale(0.02, 0.2),
                Size = UDim2.fromScale(0.7, 0.6),
                FontFace = u11,
                TextXAlignment = Enum.TextXAlignment.Center,
                TextBind = u32.JoinCode,
                TextBindUpdate = u32.JoinCodeUpdate,
                EnterPressed = u32.JoinPressed,
                Ignore = l__PopupActive__7,
                Content = { u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0, 4)
                    }) }
            }),
            Join = u2.createElement(u6, {
                Name = "Join",
                Size = UDim2.fromScale(0.23, 0.6),
                Position = UDim2.fromScale(0.75, 0.2),
                Ignore = l__PopupActive__7,
                Callback = u32.JoinPressed
            })
        }),
        HostHeader = u14({
            Name = "BROWSER FILTER",
            Width = 0.495,
            LineWidth = 0.81,
            Position = UDim2.fromScale(0.505, 0),
            Landing = l__Landing__8
        }),
        HostBody = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.5,
            BackgroundColor3 = Color3.new(),
            Size = UDim2.fromScale(0.495, 0.1),
            Position = UDim2.fromScale(0.505, 0.035)
        }, {
            u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }),
            Refresh = u2.createElement(u6, {
                Name = "Refresh",
                Size = UDim2.fromScale(0.28, 0.6),
                Position = UDim2.fromScale(0.7, 0.2),
                Ignore = l__PopupActive__7,
                Callback = function() --[[ Name: Callback, Line 323 ]]
                    -- upvalues: u32 (copy)
                    u32.GetServers();
                end
            })
        }),
        YourHeader = u14({
            Name = "SERVER BROWSER",
            Width = 1,
            LineWidth = 0.905,
            Position = UDim2.fromScale(0, 0.145),
            Landing = l__Landing__8
        })
    };
    local l__createElement__14 = u2.createElement;
    local v60 = "Frame";
    local v61 = {
        BorderSizePixel = 0,
        BackgroundTransparency = 0.5,
        BackgroundColor3 = Color3.new(),
        Size = UDim2.fromScale(1, 0.75),
        Position = UDim2.fromScale(0, 0.18)
    };
    local v62 = {
        Corner = u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 4)
        }),
        Scroller = u2.createElement(u4, {
            BackgroundTransparency = 1,
            Size = UDim2.new(0.95, 0, 0.85, 0),
            Position = UDim2.new(0.025, 0, 0.12, 0),
            Ignore = l__PopupActive__7,
            Ref = u32.ScrollerResult,
            CanvasSize = v33 / 20,
            Content = v35
        })
    };
    local l__Fetching__15 = l__state__6.Fetching;
    if l__Fetching__15 then
        l__Fetching__15 = u2.createElement("ImageLabel", {
            BackgroundTransparency = 0.25,
            BorderSizePixel = 0,
            Image = "rbxassetid://13867939464",
            ZIndex = 3,
            BackgroundColor3 = Color3.new(0, 0, 0),
            Position = UDim2.fromScale(0, 0.6),
            Size = UDim2.fromScale(1, 0.4),
            ImageColor3 = Color3.fromRGB(163, 121, 82),
            TileSize = UDim2.fromOffset(6, 6),
            ScaleType = Enum.ScaleType.Tile
        }, {
            Gradient = u2.createElement("UIGradient", {
                Rotation = 90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
            }),
            Header = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "FINDING SERVERS",
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.15),
                Position = UDim2.fromScale(0, 0.3),
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u10,
                TextXAlignment = Enum.TextXAlignment.Center
            }),
            Loading = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://15478256777",
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.6),
                Size = UDim2.fromScale(0.15, 0.15),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                Rotation = u32.UpdateBinding:map(function(p63) --[[ Line: 390 ]]
                    -- upvalues: u32 (copy)
                    return (u32.UpdateStart - p63) * 600;
                end),
                ImageColor3 = Color3.new(1, 1, 1)
            })
        });
    end;
    v62.SearchFade = l__Fetching__15;
    v62.Divider = u2.createElement("Frame", {
        BorderSizePixel = 0,
        Size = UDim2.new(1, 0, 0, 2),
        Position = UDim2.new(0, 0, 0.1, 0),
        BorderColor3 = Color3.fromRGB(0, 0, 0),
        BackgroundColor3 = Color3.fromRGB(84, 84, 84)
    });
    v62.Key = u2.createElement("Frame", {
        BorderSizePixel = 0,
        BackgroundTransparency = 1,
        Size = UDim2.new(0.95, 0, 0.07, 0),
        Position = UDim2.new(0.025, 0, 0.013, 0),
        BorderColor3 = Color3.fromRGB(0, 0, 0),
        BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    }, {
        u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            BackgroundColor3 = Color3.fromRGB(0, 0, 0),
            Size = UDim2.new(0.9, 0, 0.9, 0),
            Position = UDim2.new(0.01, 0, 0.05, 0)
        }, { u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 1)
            }), u2.createElement("UIStroke", {
                Color = Color3.fromRGB(84, 84, 84)
            }), u2.createElement("TextLabel", {
                TextWrapped = true,
                TextScaled = true,
                Text = "?",
                BackgroundTransparency = 1,
                FontFace = u10,
                Size = UDim2.new(1, 0, 1, 0),
                TextColor3 = Color3.fromRGB(84, 84, 84)
            }) }),
        u2.createElement("TextLabel", {
            TextWrapped = true,
            TextScaled = true,
            Text = "REGION",
            BackgroundTransparency = 1,
            FontFace = u10,
            Size = UDim2.new(0.92, 0, 0.4, 0),
            TextColor3 = Color3.fromRGB(84, 84, 84),
            Position = UDim2.new(0.05, 0, 0.3, 0),
            TextXAlignment = Enum.TextXAlignment.Left
        }),
        u2.createElement("TextLabel", {
            TextWrapped = true,
            TextScaled = true,
            Text = "SERVER CODE",
            BackgroundTransparency = 1,
            FontFace = u10,
            Size = UDim2.new(0.92, 0, 0.4, 0),
            TextColor3 = Color3.fromRGB(84, 84, 84),
            Position = UDim2.new(0.1, 0, 0.3, 0),
            TextXAlignment = Enum.TextXAlignment.Left
        }),
        u2.createElement("TextLabel", {
            TextWrapped = true,
            TextScaled = true,
            Text = "VERSION",
            BackgroundTransparency = 1,
            FontFace = u10,
            Size = UDim2.new(0.92, 0, 0.4, 0),
            TextColor3 = Color3.fromRGB(84, 84, 84),
            Position = UDim2.new(0.4, 0, 0.3, 0),
            TextXAlignment = Enum.TextXAlignment.Left
        }),
        u2.createElement("TextLabel", {
            TextWrapped = true,
            TextScaled = true,
            Text = "VC-ONLY",
            BackgroundTransparency = 1,
            FontFace = u10,
            Size = UDim2.new(0.92, 0, 0.4, 0),
            TextColor3 = Color3.fromRGB(84, 84, 84),
            Position = UDim2.new(0.55, 0, 0.3, 0),
            TextXAlignment = Enum.TextXAlignment.Left
        }),
        u2.createElement("TextLabel", {
            TextWrapped = true,
            TextScaled = true,
            Text = "CAPACITY",
            BackgroundTransparency = 1,
            FontFace = u10,
            Size = UDim2.new(0.92, 0, 0.4, 0),
            TextColor3 = Color3.fromRGB(84, 84, 84),
            Position = UDim2.new(0.7, 0, 0.3, 0),
            TextXAlignment = Enum.TextXAlignment.Left
        }),
        u2.createElement("TextLabel", {
            TextWrapped = true,
            TextScaled = true,
            Text = "ACTION",
            BackgroundTransparency = 1,
            FontFace = u10,
            Size = UDim2.new(0.92, 0, 0.4, 0),
            TextColor3 = Color3.fromRGB(84, 84, 84),
            Position = UDim2.new(0.85, 0, 0.3, 0),
            TextXAlignment = Enum.TextXAlignment.Left
        })
    });
    v59.YourBody = l__createElement__14(v60, v61, v62);
    v59[1] = u2.createElement(u6, {
    Name = "Return",
    Ignore = l__PopupActive__7,
    Size = UDim2.fromScale(0.2, 0.05),
    Position = UDim2.fromScale(0, 0.95),
    Callback = function() --[[ Name: Callback, Line 509 ]]
        -- upvalues: l__props__5 (copy)
        l__props__5.Return();
    end
});
    return l__createElement__13(v57, v58, v59);
end;
return v9;