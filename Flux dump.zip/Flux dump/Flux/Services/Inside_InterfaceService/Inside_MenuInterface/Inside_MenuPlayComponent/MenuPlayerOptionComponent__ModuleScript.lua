-- Services.InterfaceService.MenuInterface.MenuPlayComponent.MenuPlayerOptionComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "network");
local u3 = v1("GameShellProxyButton");
v1("MenuButtonComponent");
local u4 = v1("RoactTween");
local v5 = u2.Component:extend("MenuGamemode");
Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
function v5.init(p6, _) --[[ Line: 13 ]]
    -- upvalues: u4 (copy)
    p6.Hover = u4.new(0);
    p6:setState({
        Hovering = false
    });
end;
function v5.render(u7) --[[ Line: 20 ]]
    -- upvalues: u2 (copy), u3 (copy)
    local l__props__1 = u7.props;
    local _ = u7.state;
    return u2.createElement(u3, {
        SoundKit = "MainMenu",
        Image = "",
        BorderSizePixel = 0,
        BackgroundTransparency = 1,
        Ignore = l__props__1.Ignore,
        Size = l__props__1.Size,
        Position = l__props__1.Position,
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        AnchorPoint = l__props__1.AnchorPoint,
        MouseUp = function() --[[ Name: MouseUp, Line 35 ]]
            -- upvalues: l__props__1 (copy)
            l__props__1.Callback();
        end,
        MouseEnter = function() --[[ Name: MouseEnter, Line 38 ]]
            -- upvalues: l__props__1 (copy), u7 (copy)
            l__props__1.Hover:SetGoal(1);
            u7.Hover:SetGoal(1);
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 42 ]]
            -- upvalues: l__props__1 (copy), u7 (copy)
            l__props__1.Hover:SetGoal(0);
            u7.Hover:SetGoal(0);
        end
    }, {
        Icon = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(1, 1),
            Position = UDim2.fromScale(0.5, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            Image = l__props__1.Image,
            ImageColor3 = l__props__1.Activated and Color3.fromRGB(255, 194, 89) or Color3.new(1, 1, 1),
            ImageTransparency = u7.Hover:Map(function(p8) --[[ Line: 55 ]]
                return p8 * 0.5 + 0;
            end)
        })
    });
end;
return v5;