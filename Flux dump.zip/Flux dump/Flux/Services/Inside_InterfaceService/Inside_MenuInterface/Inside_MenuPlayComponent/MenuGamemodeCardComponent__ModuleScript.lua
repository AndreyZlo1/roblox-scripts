-- Services.InterfaceService.MenuInterface.MenuPlayComponent.MenuGamemodeCardComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

game:GetService("Players");
local v1, u2, _ = shared.import("require", "Roact", "network");
local u3 = v1("GameShellProxyButton");
local u4 = v1("RoactTween");
local v5 = u2.Component:extend("MenuGamemode");
local u6 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
function v5.init(p7, _) --[[ Line: 12 ]]
    -- upvalues: u4 (copy)
    p7.Hover = u4.new(0);
    p7:setState({
        Hovering = false
    });
end;
function v5.render(u8) --[[ Line: 19 ]]
    -- upvalues: u2 (copy), u3 (copy), u6 (copy)
    local l__props__1 = u8.props;
    local l__state__2 = u8.state;
    local l__Name__3 = l__props__1.Name;
    local l__Players__4 = l__props__1.Players;
    local l__Hovering__5 = l__state__2.Hovering;
    local v9 = l__Hovering__5 and Color3.fromRGB(255, 194, 89) or Color3.fromRGB(71, 71, 71);
    local l__ServerBrowser__6 = l__props__1.ServerBrowser;
    local l__createElement__7 = u2.createElement;
    local v10 = "Frame";
    local v11 = {
        BorderSizePixel = 0,
        ClipsDescendants = true,
        Size = UDim2.fromScale(0.28, 1),
        BackgroundColor3 = Color3.new(),
        LayoutOrder = l__props__1.LayoutOrder
    };
    local v12 = {
        Button = u2.createElement(u3, {
            SoundKit = "MainMenuBig",
            Image = "",
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(1, l__ServerBrowser__6 and 0.91 or 1),
            Ignore = l__props__1.Ignore,
            MouseUp = function() --[[ Name: MouseUp, Line 44 ]]
                -- upvalues: l__props__1 (copy)
                l__props__1.Callback();
            end,
            MouseEnter = function() --[[ Name: MouseEnter, Line 47 ]]
                -- upvalues: u8 (copy)
                u8.Hover:SetGoal(1);
                u8:setState({
                    QuickPlay = true,
                    Hovering = true
                });
            end,
            MouseLeave = function() --[[ Name: MouseLeave, Line 54 ]]
                -- upvalues: u8 (copy)
                u8.Hover:SetGoal(0);
                u8:setState({
                    Hovering = false
                });
            end
        })
    };
    local l__Banner__8 = l__props__1.Banner;
    if l__Banner__8 then
        l__Banner__8 = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 5,
            AnchorPoint = Vector2.new(0, 0),
            Size = UDim2.fromScale(1, 0.1),
            SizeConstraint = Enum.SizeConstraint.RelativeXX,
            Position = UDim2.fromScale(0, 0),
            BackgroundColor3 = Color3.fromRGB(255, 0, 0)
        }, {
            Name = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                ZIndex = 3,
                Size = UDim2.fromScale(1, 0.6),
                Position = UDim2.fromScale(0, 0.5),
                AnchorPoint = Vector2.new(0, 0.5),
                Text = l__props__1.Banner:upper(),
                TextColor3 = Color3.new(),
                TextXAlignment = Enum.TextXAlignment.Center,
                FontFace = u6
            })
        });
    end;
    v12.Banner = l__Banner__8;
    local v13;
    if l__ServerBrowser__6 then
        v13 = u2.createElement(u3, {
            SoundKit = "MainMenuBig",
            Image = "",
            BackgroundTransparency = 1,
            Position = UDim2.fromScale(0, 0.91),
            Size = UDim2.fromScale(1, 0.09),
            Ignore = l__props__1.Ignore,
            MouseUp = function() --[[ Name: MouseUp, Line 92 ]]
                -- upvalues: l__ServerBrowser__6 (copy)
                l__ServerBrowser__6();
            end,
            MouseEnter = function() --[[ Name: MouseEnter, Line 95 ]]
                -- upvalues: u8 (copy)
                u8.Hover:SetGoal(1);
                u8:setState({
                    QuickPlay = false,
                    Hovering = true
                });
            end,
            MouseLeave = function() --[[ Name: MouseLeave, Line 102 ]]
                -- upvalues: u8 (copy)
                u8.Hover:SetGoal(0);
                u8:setState({
                    Hovering = false
                });
            end
        });
    else
        v13 = l__ServerBrowser__6;
    end;
    v12.Browser = v13;
    v12.Hover = u2.createElement("ImageLabel", {
        BackgroundTransparency = 1,
        ZIndex = 2,
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.fromScale(0.5, 0.5),
        Size = u8.Hover:Map(function(p14) --[[ Line: 113 ]]
            local v15 = p14 / 3;
            return UDim2.fromScale(v15 + 1, v15 + 1);
        end),
        Image = l__Hovering__5 and l__props__1.HoverImage or l__props__1.Image,
        ImageColor3 = u8.Hover:Map(function(p16) --[[ Line: 118 ]]
            return Color3.new(1, 1, 1):Lerp(Color3.new(0.5, 0.5, 0.5), p16);
        end)
    }, {
        Gradient = u2.createElement("UIGradient", {
            Rotation = 90,
            Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.new(1, 1, 1)), ColorSequenceKeypoint.new(0, Color3.new(1, 1, 1)), ColorSequenceKeypoint.new(1, Color3.new(0, 0, 0)) })
        })
    });
    v12.Image = u2.createElement("ImageLabel", {
        BackgroundTransparency = 1,
        ZIndex = 1,
        Size = UDim2.fromScale(1, 1),
        Image = l__props__1.HoverImage
    });
    v12.Stroke = u2.createElement("UIStroke", {
        Thickness = 1,
        ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
        Color = v9,
        LineJoinMode = Enum.LineJoinMode.Round
    });
    v12.Name = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        ZIndex = 3,
        Size = UDim2.fromScale(1, 0.1),
        Position = u8.Hover:Map(function(p17) --[[ Line: 151 ]]
            return UDim2.fromScale(0, 0.73 - p17 * 0.28);
        end),
        Text = l__Name__3:upper(),
        TextColor3 = v9,
        FontFace = u6
    });
    v12.Players = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        ZIndex = 3,
        Size = UDim2.fromScale(1, 0.05),
        Position = u8.Hover:Map(function(p18) --[[ Line: 163 ]]
            return UDim2.fromScale(0, 0.85 - p18 * 0.28);
        end),
        Text = l__Players__4:upper(),
        TextColor3 = v9,
        FontFace = u6
    });
    local v19;
    if l__Hovering__5 then
        v19 = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            ZIndex = 3,
            Size = UDim2.fromScale(0.8, 0.05),
            Position = UDim2.fromScale(0.2, l__ServerBrowser__6 and 0.85 or 0.91),
            Text = l__ServerBrowser__6 and "QUICK PLAY" or (l__props__1.ButtonText or "JOIN QUEUE"),
            TextColor3 = l__state__2.QuickPlay and Color3.fromRGB(255, 194, 89) or Color3.fromRGB(71, 71, 71),
            TextXAlignment = Enum.TextXAlignment.Left,
            FontFace = u6
        }, { u2.createElement("ImageLabel", {
                Image = "rbxassetid://105277314441014",
                BackgroundTransparency = 1,
                ImageColor3 = l__state__2.QuickPlay and Color3.fromRGB(255, 194, 89) or Color3.fromRGB(71, 71, 71),
                Size = UDim2.fromScale(0.6, 0.6),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                AnchorPoint = Vector2.new(1, 0.5),
                Position = UDim2.fromScale(-0.05, 0.5)
            }) });
    else
        v19 = l__Hovering__5;
    end;
    v12.QuickPlay = v19;
    if l__ServerBrowser__6 then
        if l__Hovering__5 then
            l__Hovering__5 = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "SERVER BROWSER",
                TextScaled = true,
                ZIndex = 3,
                Size = UDim2.fromScale(0.8, 0.05),
                Position = UDim2.fromScale(0.2, 0.91),
                TextColor3 = not l__state__2.QuickPlay and Color3.fromRGB(255, 194, 89) or Color3.fromRGB(71, 71, 71),
                TextXAlignment = Enum.TextXAlignment.Left,
                FontFace = u6
            }, { u2.createElement("ImageLabel", {
                    Image = "rbxassetid://134652333701986",
                    BackgroundTransparency = 1,
                    ImageColor3 = not l__state__2.QuickPlay and Color3.fromRGB(255, 194, 89) or Color3.fromRGB(71, 71, 71),
                    Size = UDim2.fromScale(0.6, 0.6),
                    SizeConstraint = Enum.SizeConstraint.RelativeYY,
                    AnchorPoint = Vector2.new(1, 0.5),
                    Position = UDim2.fromScale(-0.05, 0.5)
                }) });
        end;
    else
        l__Hovering__5 = l__ServerBrowser__6;
    end;
    v12.ServerBrowser = l__Hovering__5;
    return l__createElement__7(v10, v11, v12);
end;
return v5;