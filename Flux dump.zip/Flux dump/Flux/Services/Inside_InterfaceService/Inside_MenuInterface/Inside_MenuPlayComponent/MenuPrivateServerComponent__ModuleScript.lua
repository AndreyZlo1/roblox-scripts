-- Services.InterfaceService.MenuInterface.MenuPlayComponent.MenuPrivateServerComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "network");
local u4 = v1("GameShellProxyScroller");
local u5 = v1("GameShellProxyInput");
local u6 = v1({
    "MenuPrivateServerWhitelistComponent",
    "MenuPrivateServerBlacklistComponent",
    "MenuPrivateServerAdminlistComponent",
    "MenuPrivateServerMapComponent"
});
local u7 = v1("MenuButtonComponent");
local u8 = v1("MenuLobbyComponent");
local u9 = v1("RoactTween");
local u10 = v1("PopupInterface");
local l__Players__1 = game:GetService("Players");
local l__RunService__2 = game:GetService("RunService");
local l__UserInputService__3 = game:GetService("UserInputService");
game:GetService("MarketplaceService");
local v11 = u2.Component:extend("MenuGamemode");
local _ = l__Players__1.LocalPlayer;
local u12 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u13 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u14 = Font.fromEnum(Enum.Font.Code);
local u15 = {
    { "Whitelist", "Whitelist" },
    { "Blacklist", "Blacklist" },
    { "Server Admins", "Adminlist" },
    { "Current Map", "Map" }
};
local function u21(p16) --[[ Line: 40 ]]
    local v17 = p16 % 60;
    local v18 = math.floor(p16 / 60) % 60;
    local v19 = math.floor(p16 / 3600) % 24;
    local v20 = math.floor(p16 / 86400);
    if p16 <= 0 then
        v20 = 0;
        v19 = 0;
        v18 = 0;
        v17 = 0;
    end;
    return "(" .. v20 .. ":" .. string.format("%02i", v19) .. ":" .. string.format("%02i", v18) .. ":" .. string.format("%02i", v17) .. ")";
end;
local function u24(u22) --[[ Line: 55 ]]
    -- upvalues: u2 (copy), u13 (copy)
    return u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        Size = UDim2.fromScale(u22.Width, 0.03),
        Position = u22.Position,
        Text = u22.Name,
        TextColor3 = Color3.new(1, 1, 1),
        FontFace = u13,
        TextXAlignment = Enum.TextXAlignment.Left
    }, { u2.createElement("Frame", {
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(1, 0.5),
            BackgroundColor3 = Color3.new(1, 1, 1),
            Size = u22.Landing:Map(function(p23) --[[ Line: 70 ]]
                -- upvalues: u22 (copy)
                return UDim2.new(p23 * u22.LineWidth, 0, 0, 2);
            end),
            Position = UDim2.fromScale(1, 0.5)
        }) });
end;
function v11.init(u25, u26) --[[ Line: 78 ]]
    -- upvalues: u3 (copy), u2 (copy), u10 (copy), l__RunService__2 (copy), u9 (copy), l__UserInputService__3 (copy)
    local l__MatchmakingQueueData__4 = u26.MatchmakingQueueData;
    local l__PrivateServerData__5 = u26.PrivateServerData;
    if l__PrivateServerData__5.CurrentMap == nil then
        l__PrivateServerData__5.CurrentMap = "";
        u3:FireServer("GetPrivateServerMap");
    end;
    local v27, v28 = u2.createBinding();
    u25.ServerCode = v27;
    u25.ServerCodeUpdate = v28;
    local v29, v30 = u2.createBinding();
    u25.JoinCode = v29;
    u25.JoinCodeUpdate = v30;
    function u25.JoinPressed() --[[ Line: 89 ]]
        -- upvalues: l__MatchmakingQueueData__4 (copy), u10 (ref), u25 (copy), u3 (ref)
        if l__MatchmakingQueueData__4.JoiningSession or l__MatchmakingQueueData__4.IsMatchmaking then
        else
            local v31 = "Are you sure you want to launch game with:";
            for _, v32 in l__MatchmakingQueueData__4.CurrentLobby do
                v31 = v31 .. "\n" .. v32.Username;
            end;
            u10:Open("Launch Game", v31, {
                { "Yes", function() --[[ Line: 100 ]]
                        -- upvalues: l__MatchmakingQueueData__4 (ref), u25 (ref), u10 (ref), u3 (ref)
                        l__MatchmakingQueueData__4.JoiningSession = true;
                        u25:setState({});
                        u10:Close();
                        u3:FireServer("PrivateServerJoin", u25.JoinCode:getValue());
                    end },
                { "No", function() --[[ Line: 106 ]]
                        -- upvalues: u10 (ref)
                        u10:Close();
                    end }
            });
        end;
    end;
    local v33, v34 = u2.createBinding(os.difftime(l__PrivateServerData__5.PrivateServerDays, os.time()));
    u25.Expiry = v33;
    u25.UpdateExpiry = v34;
    u25.Update = l__RunService__2.Heartbeat:Connect(function() --[[ Line: 114 ]]
        -- upvalues: u25 (copy), l__PrivateServerData__5 (copy)
        u25.UpdateExpiry(os.difftime(l__PrivateServerData__5.PrivateServerDays, os.time()));
    end);
    u25.Landing = u9.new(0);
    u25.Input = l__UserInputService__3.InputBegan:Connect(function(p35) --[[ Line: 119 ]]
        -- upvalues: u26 (copy)
        if p35.KeyCode == Enum.KeyCode.ButtonB then
            u26.Return();
        end;
    end);
    u25.Landing:SetGoal(1);
    u25:setState({
        Purchasing = false,
        Page = 1
    });
end;
function v11.willUnmount(p36) --[[ Line: 132 ]]
    p36.Update:Disconnect();
    p36.Input:Disconnect();
end;
function v11.render(u37) --[[ Line: 137 ]]
    -- upvalues: u15 (copy), u2 (copy), u7 (copy), u24 (copy), u5 (copy), u14 (copy), u8 (copy), u10 (copy), u3 (copy), u13 (copy), u21 (copy), u12 (copy), u4 (copy), u6 (copy)
    local l__props__6 = u37.props;
    local l__state__7 = u37.state;
    local l__Landing__8 = u37.Landing;
    local l__PopupActive__9 = l__props__6.PopupActive;
    local l__MatchmakingQueueData__10 = l__props__6.MatchmakingQueueData;
    local l__PrivateServerData__11 = l__props__6.PrivateServerData;
    local v38 = l__PrivateServerData__11.UpdatingPrivateServerCode and "________-____-____-____-____________" or l__PrivateServerData__11.PrivateServerCode;
    u37.ServerCodeUpdate(v38);
    local v39 = math.max(8, #u15);
    local v40 = 1 / v39;
    local v41 = {
        Grid = u2.createElement("UIGridLayout", {
            CellPadding = UDim2.fromScale(0, v40 * 0.2),
            CellSize = UDim2.fromScale(1, v40 * 0.8),
            FillDirection = Enum.FillDirection.Vertical,
            HorizontalAlignment = Enum.HorizontalAlignment.Left,
            SortOrder = Enum.SortOrder.LayoutOrder,
            StartCorner = Enum.StartCorner.TopLeft,
            VerticalAlignment = Enum.VerticalAlignment.Top
        })
    };
    for u42, v43 in u15 do
        v41[v43[2]] = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            LayoutOrder = u42
        }, { u2.createElement(u7, {
                Ignore = l__PopupActive__9,
                Size = UDim2.new(0.95, -1, 1, -1),
                Position = UDim2.fromOffset(1, 1),
                Name = v43[1],
                Activated = l__state__7.Page == u42,
                Callback = function() --[[ Name: Callback, Line 176 ]]
                    -- upvalues: u37 (copy), u42 (copy)
                    u37:setState({
                        Page = u42
                    });
                end
            }) });
    end;
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        AnchorPoint = Vector2.new(0.5, 0),
        Size = UDim2.fromScale(0, 0.85),
        Position = UDim2.fromScale(0.5, 0.05)
    }, {
        Aspect = u2.createElement("UIAspectRatioConstraint", {
            AspectRatio = 2,
            AspectType = Enum.AspectType.ScaleWithParentSize,
            DominantAxis = Enum.DominantAxis.Height
        }),
        JoinHeader = u24({
            Name = "JOIN SERVER BY CODE",
            Width = 0.495,
            LineWidth = 0.755,
            Position = UDim2.fromScale(0, 0),
            Landing = l__Landing__8
        }),
        JoinBody = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.5,
            BackgroundColor3 = Color3.new(),
            Size = UDim2.fromScale(0.495, 0.1),
            Position = UDim2.fromScale(0, 0.035)
        }, {
            u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }),
            Code = u2.createElement(u5, {
                PlaceholderText = "ENTER PRIVATE SERVER CODE HERE",
                ClearTextOnFocus = true,
                BackgroundColor3 = Color3.new(),
                Position = UDim2.fromScale(0.02, 0.2),
                Size = UDim2.fromScale(0.7, 0.6),
                FontFace = u14,
                TextXAlignment = Enum.TextXAlignment.Center,
                TextBind = u37.JoinCode,
                TextBindUpdate = u37.JoinCodeUpdate,
                EnterPressed = u37.JoinPressed,
                Ignore = l__PopupActive__9,
                Content = { u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0, 4)
                    }) }
            }),
            Join = u2.createElement(u7, {
                Name = "Join",
                Size = UDim2.fromScale(0.23, 0.6),
                Position = UDim2.fromScale(0.75, 0.2),
                Ignore = l__PopupActive__9,
                Callback = u37.JoinPressed
            })
        }),
        HostHeader = u24({
            Name = "HOST PERSONAL SERVER (MAX 5 PLAYERS)",
            Width = 0.495,
            LineWidth = 0.55,
            Position = UDim2.fromScale(0.505, 0),
            Landing = l__Landing__8
        }),
        HostBody = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.5,
            BackgroundColor3 = Color3.new(),
            Size = UDim2.fromScale(0.495, 0.1),
            Position = UDim2.fromScale(0.505, 0.035)
        }, {
            u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }),
            Lobby = u2.createElement(u8, {
                MatchmakingQueueData = l__MatchmakingQueueData__10,
                PopupActive = l__PopupActive__9,
                AnchorPoint = Vector2.new(0, 0),
                Size = UDim2.fromScale(0, 0.6),
                Position = UDim2.fromScale(0.02, 0.2)
            }),
            Launch = u2.createElement(u7, {
                Name = "Launch",
                Size = UDim2.fromScale(0.28, 0.6),
                Position = UDim2.fromScale(0.7, 0.2),
                Ignore = l__PopupActive__9,
                Callback = function() --[[ Name: Callback, Line 271 ]]
                    -- upvalues: l__MatchmakingQueueData__10 (copy), u10 (ref), u37 (copy), u3 (ref)
                    if l__MatchmakingQueueData__10.JoiningSession or l__MatchmakingQueueData__10.IsMatchmaking then
                    else
                        local v44 = "Are you sure you want to launch game with:";
                        for _, v45 in l__MatchmakingQueueData__10.CurrentLobby do
                            v44 = v44 .. "\n" .. v45.Username;
                        end;
                        u10:Open("Launch Game", v44, {
                            { "Yes", function() --[[ Line: 282 ]]
                                    -- upvalues: l__MatchmakingQueueData__10 (ref), u37 (ref), u10 (ref), u3 (ref)
                                    l__MatchmakingQueueData__10.JoiningSession = true;
                                    u37:setState({});
                                    u10:Close();
                                    u3:FireServer("PrivateServerHost");
                                end },
                            { "No", function() --[[ Line: 288 ]]
                                    -- upvalues: u10 (ref)
                                    u10:Close();
                                end }
                        });
                    end;
                end
            })
        }),
        YourHeader = u24({
            Name = "YOUR SERVER",
            Width = 1,
            LineWidth = 0.92,
            Position = UDim2.fromScale(0, 0.145),
            Landing = l__Landing__8
        }),
        YourBody = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.5,
            BackgroundColor3 = Color3.new(),
            Size = UDim2.fromScale(1, 0.1),
            Position = UDim2.fromScale(0, 0.18)
        }, {
            u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }),
            Code = u2.createElement(u5, {
                ClearTextOnFocus = false,
                FreezeText = true,
                BackgroundColor3 = Color3.new(),
                Position = UDim2.fromScale(0.01, 0.2),
                Size = UDim2.fromScale(0.346, 0.6),
                FontFace = u14,
                PlaceholderText = v38,
                Disabled = l__PrivateServerData__11.UpdatingPrivateServerCode,
                TextXAlignment = Enum.TextXAlignment.Center,
                Ignore = l__PopupActive__9,
                TextBind = u37.ServerCode,
                TextBindUpdate = u37.ServerCodeUpdate,
                Content = { u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0, 4)
                    }) }
            }),
            Refresh = u2.createElement(u7, {
                Name = "Refresh",
                Size = UDim2.fromScale(0.115, 0.6),
                Position = UDim2.fromScale(0.37, 0.2),
                Loading = l__PrivateServerData__11.UpdatingPrivateServerCode,
                Ignore = l__PopupActive__9,
                Callback = function() --[[ Name: Callback, Line 339 ]]
                    -- upvalues: l__PrivateServerData__11 (copy), u37 (copy), u3 (ref)
                    if l__PrivateServerData__11.UpdatingPrivateServerCode or l__PrivateServerData__11.UpdatingPrivateServerConfig then
                    else
                        l__PrivateServerData__11.UpdatingPrivateServerCode = true;
                        u37:setState({});
                        u3:FireServer("PrivateServerCodeUpdate");
                    end;
                end
            }),
            Extend = u2.createElement(u7, {
                Name = "Renew (+30 Days)",
                Size = UDim2.fromScale(0.2, 0.6),
                Position = UDim2.fromScale(0.79, 0.2),
                Loading = l__state__7.Purchasing,
                Ignore = l__PopupActive__9,
                Callback = function() --[[ Name: Callback, Line 355 ]]
                    -- upvalues: l__state__7 (copy), u3 (ref), u37 (copy)
                    if l__state__7.Purchasing then
                    else
                        u3:FireServer("PrivateServerExtend");
                        u37:setState({
                            Purchasing = true
                        });
                        task.delay(2, u37.setState, u37, {
                            Purchasing = false
                        });
                    end;
                end
            }),
            Status = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "STATUS:",
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.4),
                Position = UDim2.fromScale(0.519, 0.3),
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u13,
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            Active = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.4),
                Position = UDim2.fromScale(0.58, 0.3),
                Text = u37.Expiry:map(function(p46) --[[ Line: 382 ]]
                    return p46 > 0 and "ACTIVE" or "EXPIRED";
                end),
                TextColor3 = u37.Expiry:map(function(p47) --[[ Line: 385 ]]
                    return p47 > 0 and Color3.fromRGB(107, 213, 95) or Color3.fromRGB(213, 92, 92);
                end),
                FontFace = u13,
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            Expiry = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                AnchorPoint = Vector2.new(1, 0),
                Size = UDim2.fromScale(1, 0.4),
                Position = UDim2.fromScale(0.78, 0.3),
                Text = u37.Expiry:map(function(p48) --[[ Line: 397 ]]
                    -- upvalues: u21 (ref)
                    return u21(p48);
                end),
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u12,
                TextXAlignment = Enum.TextXAlignment.Right
            })
        }),
        SettingSideBar = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.5,
            BackgroundColor3 = Color3.new(),
            Size = UDim2.fromScale(0.2, 0.63),
            Position = UDim2.fromScale(0, 0.3)
        }, {
            Corner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 4)
            }),
            Scroller = u2.createElement(u4, {
                BackgroundTransparency = 1,
                ScrollingSize = 0.01,
                Size = UDim2.fromScale(0.9, 0.94),
                Position = UDim2.fromScale(0.05, 0.03),
                Ignore = l__PopupActive__9,
                CanvasSize = v39 / 8,
                Content = v41
            })
        }),
        SettingsPage = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(0.79, 0.7),
            Position = UDim2.fromScale(0.21, 0.3)
        }, u2.createElement(u6["MenuPrivateServer" .. u15[l__state__7.Page][2] .. "Component"], {
            PopupActive = l__PopupActive__9,
            MatchmakingQueueData = l__MatchmakingQueueData__10,
            PrivateServerData = l__PrivateServerData__11
        })),
        u2.createElement(u7, {
            Name = "Return",
            Ignore = l__PopupActive__9,
            Size = UDim2.fromScale(0.2, 0.05),
            Position = UDim2.fromScale(0, 0.95),
            Callback = function() --[[ Name: Callback, Line 441 ]]
                -- upvalues: l__props__6 (copy)
                l__props__6.Return();
            end
        })
    });
end;
return v11;