-- Services.InterfaceService.MenuInterface.MenuPlayComponent.MenuPlayerPatchComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "Enum");
local u4 = v1("GameShellProxyButton");
local u5 = v1("PopupInterface");
local u6 = v1("RoactTween");
local v7 = u2.Component:extend("MenuGamemode");
local u8 = Font.fromId(12187375422, u3.FontWeight.Bold, u3.FontStyle.Normal);
local u9 = Font.fromId(12187375422, u3.FontWeight.Regular, u3.FontStyle.Normal);
function v7.init(p10, _) --[[ Line: 13 ]]
    -- upvalues: u6 (copy)
    p10.Hover = u6.new(0);
    p10.Clicked = u6.new(1);
end;
function v7.render(u11) --[[ Line: 18 ]]
    -- upvalues: u2 (copy), u4 (copy), u5 (copy), u3 (copy), u8 (copy), u9 (copy)
    local l__props__1 = u11.props;
    local l__Patch__2 = l__props__1.Patch;
    local v12;
    if l__Patch__2[3] then
        v12 = u2.createFragment({ u2.createElement("Frame", {
                BorderSizePixel = 0,
                Size = UDim2.fromScale(0.5, 0.05),
                Position = UDim2.fromScale(0.5, 0.5),
                AnchorPoint = Vector2.new(0.5, 0.5),
                BackgroundColor3 = Color3.fromRGB(255, 194, 89)
            }), u2.createElement("Frame", {
                BorderSizePixel = 0,
                Size = UDim2.fromScale(0.05, 0.5),
                Position = UDim2.fromScale(0.5, 0.5),
                AnchorPoint = Vector2.new(0.5, 0.5),
                BackgroundColor3 = Color3.fromRGB(255, 194, 89)
            }) });
    else
        v12 = u2.createElement("Frame", {
            BorderSizePixel = 0,
            Size = UDim2.fromScale(0.5, 0.05),
            Position = UDim2.fromScale(0.5, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5),
            BackgroundColor3 = Color3.fromRGB(255, 194, 89)
        });
    end;
    return u2.createElement(u4, {
        SoundKit = "MainMenu",
        Image = "",
        BorderSizePixel = 0,
        BackgroundTransparency = 1,
        LayoutOrder = l__props__1.Order,
        Ignore = l__props__1.Ignore,
        Scroller = l__props__1.Scroller,
        MouseUp = function() --[[ Name: MouseUp, Line 59 ]]
            -- upvalues: u11 (copy), u5 (ref), l__Patch__2 (copy), u3 (ref)
            u11.Clicked:SetValue(0);
            u11.Clicked:SetGoal(1);
            u5:Open("Release " .. l__Patch__2[2], l__Patch__2[2], {
                { "Close", function() --[[ Line: 63 ]]
                        -- upvalues: u5 (ref)
                        u5:Close();
                    end }
            }, u3.PopupType.Patch);
        end,
        MouseEnter = function() --[[ Name: MouseEnter, Line 68 ]]
            -- upvalues: l__props__1 (copy), u11 (copy)
            l__props__1.Hover:SetGoal(1);
            u11.Hover:SetGoal(1);
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 72 ]]
            -- upvalues: l__props__1 (copy), u11 (copy)
            l__props__1.Hover:SetGoal(0);
            u11.Hover:SetGoal(0);
        end
    }, {
        Hover = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.5,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = u11.Hover:Map(function(p13) --[[ Line: 80 ]]
                return UDim2.fromScale(1, p13 * 1.52);
            end),
            BackgroundColor3 = Color3.new()
        }),
        Click = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 3,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = u11.Clicked:Map(function(p14) --[[ Line: 91 ]]
                return UDim2.fromScale(p14, 1.52);
            end),
            BackgroundColor3 = Color3.new(1, 1, 1),
            BackgroundTransparency = u11.Clicked:Map(function(p15) --[[ Line: 96 ]]
                return p15;
            end)
        }),
        Icon = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://15543312915",
            ZIndex = 4,
            Size = UDim2.fromScale(0.4, 0.4),
            Position = UDim2.fromScale(0.5, 0.3),
            AnchorPoint = Vector2.new(0.5, 0),
            SizeConstraint = u3.SizeConstraint.RelativeYY,
            ImageColor3 = Color3.fromRGB(255, 194, 89),
            ImageTransparency = u11.Hover:Map(function(p16) --[[ Line: 110 ]]
                return 1 - p16;
            end)
        }),
        Badge = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Position = UDim2.fromScale(0.05, 0),
            Size = UDim2.fromScale(1, 1),
            SizeConstraint = u3.SizeConstraint.RelativeYY
        }, { v12 }),
        Name = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextStrokeTransparency = 0.8,
            TextScaled = true,
            Size = UDim2.fromScale(0.8, 0.4),
            Position = UDim2.fromScale(0.22, 0.1),
            Text = "Release " .. l__Patch__2[2],
            TextColor3 = Color3.new(1, 1, 1),
            TextStrokeColor3 = Color3.new(),
            FontFace = u8,
            TextXAlignment = u3.TextXAlignment.Left
        }),
        Activity = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            RichText = true,
            TextStrokeTransparency = 0.8,
            TextScaled = true,
            Size = UDim2.fromScale(10, 0.4),
            Position = UDim2.fromScale(0.22, 0.5),
            TextColor3 = Color3.new(1, 1, 1),
            Text = l__Patch__2[4] or (l__Patch__2[3] and "Major Update" or "Minor Patch"),
            TextStrokeColor3 = Color3.new(),
            FontFace = u9,
            TextXAlignment = u3.TextXAlignment.Left
        })
    });
end;
return v7;