-- Services.InterfaceService.MenuInterface.MenuPlayComponent.MenuGamemodeReturnComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

game:GetService("Players");
local v1, u2, _ = shared.import("require", "Roact", "network");
local u3 = v1("GameShellProxyButton");
local u4 = v1("RoactTween");
local u5 = v1("SoundService");
local l__UserInputService__1 = game:GetService("UserInputService");
local v6 = u2.Component:extend("MenuGamemode");
local u7 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
function v6.init(p8, u9) --[[ Line: 15 ]]
    -- upvalues: u4 (copy), l__UserInputService__1 (copy), u5 (copy)
    p8.Hover = u4.new(0);
    p8:setState({
        Hovering = false
    });
    p8.Input = l__UserInputService__1.InputBegan:Connect(function(p10) --[[ Line: 21 ]]
        -- upvalues: u5 (ref), u9 (copy)
        if p10.KeyCode == Enum.KeyCode.ButtonB then
            u5:CreateSound("Button", nil, true, "UIButtons", "MainMenuBigReturn", "Click").Destroy(2);
            u9.Callback();
        end;
    end);
    p8.Hover:SetGoal(1);
end;
function v6.willUnmount(p11) --[[ Line: 33 ]]
    p11.Input:Disconnect();
end;
function v6.render(u12) --[[ Line: 37 ]]
    -- upvalues: u2 (copy), u3 (copy), u7 (copy)
    local l__props__2 = u12.props;
    local l__Hovering__3 = u12.state.Hovering;
    local v13 = l__Hovering__3 and Color3.fromRGB(255, 194, 89) or Color3.new(1, 1, 1);
    return u2.createElement(u3, {
        SoundKit = "MainMenuBigReturn",
        Image = "",
        BorderSizePixel = 0,
        ClipsDescendants = true,
        LayoutOrder = 1,
        BackgroundColor3 = Color3.new(),
        Ignore = l__props__2.Ignore,
        Size = u12.Hover:Map(function(p14) --[[ Line: 53 ]]
            return UDim2.fromScale(p14 / 10 + 0.05, 1);
        end),
        MouseUp = function() --[[ Name: MouseUp, Line 57 ]]
            -- upvalues: l__props__2 (copy)
            l__props__2.Callback();
        end,
        MouseEnter = function() --[[ Name: MouseEnter, Line 60 ]]
            -- upvalues: u12 (copy)
            u12:setState({
                Hovering = true
            });
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 65 ]]
            -- upvalues: u12 (copy)
            u12:setState({
                Hovering = false
            });
        end
    }, {
        Gradient = u2.createElement("UIGradient", {
            Rotation = 0,
            Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
        }),
        Corner = u2.createElement("UICorner", {
            CornerRadius = UDim.new(0, 1)
        }),
        Stroke = u2.createElement("UIStroke", {
            Thickness = 1,
            ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
            Color = l__Hovering__3 and Color3.fromRGB(255, 194, 89) or Color3.fromRGB(71, 71, 71),
            LineJoinMode = Enum.LineJoinMode.Round
        }, {
            Gradient = u2.createElement("UIGradient", {
                Rotation = 0,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
            })
        }),
        Name = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "←",
            TextScaled = true,
            ZIndex = 3,
            Size = UDim2.fromScale(0.6, 0.3),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            TextColor3 = v13,
            FontFace = u7
        })
    });
end;
return v6;