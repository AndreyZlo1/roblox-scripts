-- Services.InterfaceService.MenuInterface.MenuInteractiveMapComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "server");
local l__RunService__1 = game:GetService("RunService");
local l__UserInputService__2 = game:GetService("UserInputService");
local u4 = v1("ReplicatorService");
local u5 = v1("ClientService");
local u6 = v1("RoactTween");
local u7 = v1("POI");
local u8 = v1("MenuInteractiveMapDeployComponent");
local l__CurrentCamera__3 = workspace.CurrentCamera;
local u9 = {
    "rbxassetid://15604514064",
    "rbxassetid://15604513794",
    "rbxassetid://15604514167",
    "rbxassetid://15604513938",
    "rbxassetid://15604513686",
    "rbxassetid://15604514259"
};
local u10 = { "rbxassetid://75558153952655" };
local u11 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u12 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local v13 = u2.Component:extend("MenuMap");
local function u26(p14) --[[ Line: 36 ]]
    -- upvalues: u2 (copy), u11 (copy)
    local l__Grid__4 = p14.Grid;
    local l__Axis__5 = p14.Axis;
    local l__Transition__6 = p14.Transition;
    local u15 = math.floor(l__Grid__4 / 10) % 10 == 0;
    local u16;
    if math.floor(l__Grid__4 / 100) % 10 == 0 then
        u16 = u15;
    else
        u16 = false;
    end;
    local v17 = u16 and 3 or (u15 and 2 or 1);
    return u2.createElement("Frame", {
        BorderSizePixel = 0,
        BackgroundTransparency = u2.joinBindings({ p14.Zoom:Map(function(p18) --[[ Line: 47 ]]
                -- upvalues: u16 (copy), u15 (copy)
                if u16 then
                    return 0.4;
                elseif u15 then
                    return (1 - (math.clamp(p18, 0.2, 0.4) - 0.2) * 5) * 0.4 + 0.6;
                else
                    return (1 - (math.clamp(p18, 1.6, 1.8) - 1.6) * 5) * 0.2 + 0.8;
                end;
            end), l__Transition__6:Map(function(p19) --[[ Line: 56 ]]
                return p19;
            end) }):map(function(p20) --[[ Line: 59 ]]
            return math.lerp(p20[1], 1, p20[2]);
        end),
        BackgroundColor3 = Color3.new(1, 1, 1),
        AnchorPoint = Vector2.new(0.5, 0.5),
        Size = l__Axis__5 == "Y" and UDim2.new(10, 0, 0, v17) or UDim2.new(0, v17, 10, 0),
        Position = l__Axis__5 == "X" and UDim2.fromScale(p14.Position, 0.5) or UDim2.fromScale(0.5, 1 - p14.Position)
    }), u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        AnchorPoint = Vector2.new(0.5, 0.5),
        Size = UDim2.fromScale(0.55, 0.55),
        SizeConstraint = l__Axis__5 == "X" and Enum.SizeConstraint.RelativeYY or Enum.SizeConstraint.RelativeXX,
        Position = l__Axis__5 == "X" and UDim2.fromScale(p14.Position, 0.5) or UDim2.fromScale(0.5, 1 - p14.Position),
        Text = p14.Zoom:Map(function(p21) --[[ Line: 74 ]]
            -- upvalues: l__Grid__4 (copy)
            return string.format("%05i", l__Grid__4):sub(1, p21 > 1.7 and 4 or (p21 > 0.3 and 3 or 2));
        end),
        TextColor3 = Color3.fromRGB(255, 194, 89),
        TextStrokeColor3 = Color3.new(),
        TextStrokeTransparency = l__Transition__6:Map(function(p22) --[[ Line: 80 ]]
            return p22 / 2 + 0.5;
        end),
        TextTransparency = u2.joinBindings({ p14.Zoom:Map(function(p23) --[[ Line: 84 ]]
                -- upvalues: u16 (copy), u15 (copy)
                if u16 then
                    return 0;
                elseif u15 then
                    return 1 - (math.clamp(p23, 0.2, 0.4) - 0.2) * 5;
                else
                    return 1 - (math.clamp(p23, 1.6, 1.8) - 1.6) * 5;
                end;
            end), l__Transition__6:Map(function(p24) --[[ Line: 93 ]]
                return p24;
            end) }):map(function(p25) --[[ Line: 96 ]]
            return math.lerp(p25[1], 1, p25[2]);
        end),
        TextXAlignment = Enum.TextXAlignment.Center,
        FontFace = u11
    });
end;
local u27 = nil;
local u28 = nil;
function v13.init(u29, p30) --[[ Line: 110 ]]
    -- upvalues: u2 (copy), u3 (copy), l__CurrentCamera__3 (copy), u5 (copy), u6 (copy), u27 (ref), u28 (ref), l__UserInputService__2 (copy), l__RunService__1 (copy), u4 (copy)
    local l__Position__7 = p30.Position;
    local v31, u32 = u2.createBinding(0);
    u29._flash = v31;
    local l__Map__8 = u3.Map;
    local v33 = #l__Map__8.Tiles * 1024 * (l__Map__8.StudsToPixels or 1);
    local u34 = l__CurrentCamera__3.ViewportSize.Y * 0.85 / v33;
    local u35 = 0.1;
    local u36 = Vector2.new(0.5, 0.5);
    local l__LocalClient__9 = u5.LocalClient;
    local u37;
    if l__LocalClient__9 and l__LocalClient__9.Actor then
        local l__Position__10 = l__LocalClient__9.Actor.Position;
        u36 = u36 + Vector2.new(l__Position__10.X / v33, l__Position__10.Z / v33);
        u37 = true;
    else
        u37 = false;
    end;
    u29._zoomLevel = u6.new(u35);
    local v38 = u6.new(u36.X);
    local v39 = u6.new(u36.Y);
    u29._posXTween = v38;
    u29._posYTween = v39;
    u29._positionBinding = u2.joinBindings({ u29._posXTween.Binding, u29._posYTween.Binding }):map(function(p40) --[[ Line: 133 ]]
        return Vector2.new(p40[1], p40[2]);
    end);
    local function u43(p41, p42) --[[ Line: 154 ]]
        -- upvalues: u29 (copy), u36 (ref), u37 (ref), u28 (ref)
        if u29.props.Transition and u29.props.Transition:IsGoal(1) then
        else
            u36 = p41;
            if p42 then
                u29._posXTween:SetGoal(p41.X);
                u29._posYTween:SetGoal(p41.Y);
            else
                u29._posXTween:SetValue(p41.X);
                u29._posYTween:SetValue(p41.Y);
            end;
            if u37 then
                u28 = u36;
            end;
        end;
    end;
    local v44 = u37 and (u27 or 4) or u34;
    if not (u29.props.Transition and u29.props.Transition:IsGoal(1)) then
        local v45 = math.min(4, u34);
        local v46 = math.clamp(v44, v45, 4);
        u29._zoomLevel:SetGoal(v46);
        if u37 then
            u27 = v46;
            u35 = v46;
        else
            u35 = v46;
        end;
    end;
    if not u37 then
        local v47 = u36;
        if not (u29.props.Transition and u29.props.Transition:IsGoal(1)) then
            u36 = v47;
            u29._posXTween:SetGoal(v47.X);
            u29._posYTween:SetGoal(v47.Y);
            if u37 then
                u28 = u36;
            end;
        end;
    end;
    local v48, v49 = u2.createBinding(UDim2.fromScale(5, 1));
    u29._grainBinding = v48;
    u29._updateGrain = v49;
    local u50 = false;
    local u51 = Vector3.new();
    u29._began = l__UserInputService__2.InputBegan:Connect(function(p52) --[[ Line: 185 ]]
        -- upvalues: u50 (ref)
        if p52.UserInputType == Enum.UserInputType.MouseButton1 then
            u50 = true;
        end;
    end);
    u29._ended = l__UserInputService__2.InputEnded:Connect(function(p53) --[[ Line: 190 ]]
        -- upvalues: u50 (ref)
        if p53.UserInputType == Enum.UserInputType.MouseButton1 then
            u50 = false;
        end;
    end);
    u29._moved = l__UserInputService__2.TouchMoved:Connect(function(p54) --[[ Line: 195 ]]
        -- upvalues: u29 (copy), u3 (ref), u43 (copy), u35 (ref)
        local l__Delta__11 = p54.Delta;
        local v55 = u29._positionBinding:getValue();
        local l__Map__12 = u3.Map;
        local v56 = #l__Map__12.Tiles * 1024 * (l__Map__12.StudsToPixels or 1);
        u43(Vector2.new(math.clamp(v55.X - l__Delta__11.X / v56 / u35, 0, 1), (math.clamp(v55.Y - l__Delta__11.Y / v56 / u35, 0, 1))));
    end);
    u29._pinch = l__UserInputService__2.TouchPinch:Connect(function(_, _, p57) --[[ Line: 208 ]]
        -- upvalues: u29 (copy)
        u29._zoomTouch = p57 / 5;
    end);
    u29._changed = l__UserInputService__2.InputChanged:Connect(function(p58) --[[ Line: 211 ]]
        -- upvalues: u50 (ref), u51 (ref), u29 (copy), u3 (ref), u43 (copy), u35 (ref), u34 (copy), u37 (ref), u27 (ref)
        if p58.UserInputType == Enum.UserInputType.MouseMovement then
            local l__Position__13 = p58.Position;
            if u50 then
                local v59 = l__Position__13 - u51;
                local v60 = u29._positionBinding:getValue();
                local l__Map__14 = u3.Map;
                local v61 = #l__Map__14.Tiles * 1024 * (l__Map__14.StudsToPixels or 1);
                u43(Vector2.new(math.clamp(v60.X - v59.X / v61 / u35, 0, 1), (math.clamp(v60.Y - v59.Y / v61 / u35, 0, 1))));
            end;
            u51 = l__Position__13;
        else
            if p58.UserInputType.Name:sub(1, 7) == "Gamepad" then
                if p58.KeyCode == Enum.KeyCode.Thumbstick1 then
                    u29._thumbStick = p58.Position;
                    return;
                end;
                if p58.KeyCode == Enum.KeyCode.Thumbstick2 then
                    u29._zoomStick = p58.Position;
                end;
            elseif p58.UserInputType == Enum.UserInputType.MouseWheel then
                local v62 = u35 + p58.Position.Z * u35 / 5;
                if u29.props.Transition and u29.props.Transition:IsGoal(1) then
                    return;
                end;
                local v63 = math.min(4, u34);
                u35 = math.clamp(v62, v63, 4);
                u29._zoomLevel:SetGoal(u35);
                if u37 then
                    u27 = u35;
                end;
            end;
        end;
    end);
    local u64 = {};
    local u65 = {};
    local u66 = {};
    local u67 = tick();
    u29._update = l__RunService__1.Heartbeat:Connect(function(p68) --[[ Line: 244 ]]
        -- upvalues: l__LocalClient__9 (copy), u5 (ref), u65 (copy), u2 (ref), u64 (copy), u4 (ref), u66 (copy), u29 (copy), u43 (copy), u35 (ref), u34 (copy), u37 (ref), u27 (ref), l__CurrentCamera__3 (ref), u3 (ref), l__Position__7 (copy), u67 (copy), u32 (copy)
        local l__Squad__15 = l__LocalClient__9.Squad;
        local v69 = {};
        local v70 = false;
        for _, v71 in u5:GetClients() do
            local v72 = v71 == l__LocalClient__9;
            local l__Squad__16 = v71.Squad;
            if l__Squad__16 then
                l__Squad__16 = v71.Squad == l__Squad__15;
            end;
            if v72 or l__Squad__16 then
                v69[v71] = true;
                if not u65[v71] then
                    local v73, v74 = u2.createBinding(0);
                    local v75, v76 = u2.createBinding(Vector3.new(-inf, 0, -inf));
                    u65[v71] = {
                        Name = v72 and "(You)" or v71.Owner.DisplayName,
                        PositionBinding = v75,
                        SetPosition = v76,
                        OrientationBinding = v73,
                        SetOrientation = v74
                    };
                    v70 = true;
                end;
                local l__Marker__17 = v71.Marker;
                if l__Marker__17 then
                    local v77 = u64[v71];
                    if not v77 or (v77.X ~= l__Marker__17.X or (v77.Z ~= l__Marker__17.Z or v77.Icon ~= l__Marker__17.Icon)) then
                        u64[v71] = l__Marker__17;
                        v70 = true;
                    end;
                elseif u64[v71] then
                    u64[v71] = nil;
                    v70 = true;
                end;
                local v78 = u65[v71];
                local l__Actor__18 = v71.Actor;
                local v79 = not l__Actor__18 and Vector3.new(-inf, 0, -inf) or (l__Actor__18.UseClient and l__Actor__18.Position or l__Actor__18.ServerPosition);
                v78.SetOrientation(l__Actor__18 and l__Actor__18.Orientation or 0);
                v78.SetPosition(v79);
            end;
        end;
        for v80 in u65 do
            if not v69[v80] then
                u65[v80] = nil;
                u64[v80] = nil;
                v70 = true;
            end;
        end;
        local v81 = {};
        for _, v82 in u4:GetActors() do
            if v82.Known and v82.Alive then
                if not u66[v82] then
                    local v83, v84 = u2.createBinding(Vector3.new(-inf, -inf, 0));
                    u66[v82] = {
                        Icon = v82.Known,
                        PositionBinding = v83,
                        SetPosition = v84
                    };
                    v70 = true;
                end;
                v81[v82] = true;
                u66[v82].SetPosition(v82.ServerPosition);
            end;
        end;
        for v85 in u66 do
            if not v81[v85] then
                u66[v85] = nil;
                v70 = true;
            end;
        end;
        local v86 = u29._zoomLevel:GetValue();
        local l___thumbStick__19 = u29._thumbStick;
        if l___thumbStick__19 and l___thumbStick__19.Magnitude > 0.1 then
            local v87 = l___thumbStick__19 * p68 / 2 / v86;
            local v88 = u29._positionBinding:getValue();
            u43(Vector2.new(math.clamp(v88.X + v87.X, 0, 1), (math.clamp(v88.Y - v87.Y, 0, 1))));
        end;
        local l___zoomStick__20 = u29._zoomStick;
        if l___zoomStick__20 and l___zoomStick__20.Magnitude > 0.1 then
            local v89 = u35 + l___zoomStick__20.Y * p68 * v86;
            if not (u29.props.Transition and u29.props.Transition:IsGoal(1)) then
                local v90 = math.min(4, u34);
                u35 = math.clamp(v89, v90, 4);
                u29._zoomLevel:SetValue(u35);
                if u37 then
                    u27 = u35;
                end;
            end;
            v86 = u35;
        end;
        local l___zoomTouch__21 = u29._zoomTouch;
        if l___zoomTouch__21 then
            local v91 = u35 + l___zoomTouch__21 * p68 * v86 * 4;
            if not (u29.props.Transition and u29.props.Transition:IsGoal(1)) then
                local v92 = math.min(4, u34);
                u35 = math.clamp(v91, v92, 4);
                u29._zoomLevel:SetValue(u35);
                if u37 then
                    u27 = u35;
                end;
            end;
            v86 = u35;
            u29._zoomTouch = 0;
        end;
        local l__ViewportSize__22 = l__CurrentCamera__3.ViewportSize;
        local l__Map__23 = u3.Map;
        local v93 = l__Map__23.StudsToPixels or 1;
        local v94 = #l__Map__23.Tiles * 1024 * v93;
        local v95 = math.ceil(v94 / 3.28084 / 2);
        local v96 = (u29._positionBinding:getValue() - Vector2.new(0.5, 0.5)) * v94;
        local v97 = Vector2.new(l__ViewportSize__22.X, l__ViewportSize__22.Y * 0.85) * v93 / v86;
        local v98 = Vector2.new(v97.X, -v97.Y) / 2;
        local v99 = v96 - v98;
        local v100 = v96 + v98;
        if l__Position__7 then
            l__Position__7(v96);
        end;
        local v101 = v86 >= 1.6 and 10 or (v86 >= 0.2 and 100 or 1000);
        local v102 = Vector2.new(math.floor((v99.X / 3.28084 + v95) / v101), (math.floor((v100.X / 3.28084 + v95) / v101)));
        local v103 = Vector2.new(math.floor((-v99.Y / 3.28084 + v95) / v101), (math.floor((-v100.Y / 3.28084 + v95) / v101)));
        local l__state__24 = u29.state;
        if (l__state__24.X ~= v102 or l__state__24.Y ~= v103) and true or v70 then
            u29:setState({
                X = v102,
                Y = v103,
                Resolution = v101,
                KnownEnemies = u66,
                SquadClients = u65,
                SquadMarkers = u64
            });
        end;
        u29._updateGrain(UDim2.fromScale((tick() * 100 - u67) % 1 + 1, 1));
        u32(tick() / 10);
    end);
    u29:setState({
        Resolution = 10,
        X = Vector2.new(),
        Y = Vector2.new(),
        KnownEnemies = {},
        SquadClients = {},
        SquadMarkers = {}
    });
end;
function v13.willUnmount(p104) --[[ Line: 405 ]]
    p104._update:Disconnect();
    p104._began:Disconnect();
    p104._ended:Disconnect();
    p104._changed:Disconnect();
    p104._pinch:Disconnect();
    p104._moved:Disconnect();
end;
function v13.render(p105) --[[ Line: 414 ]]
    -- upvalues: u3 (copy), u6 (copy), u2 (copy), u26 (copy), u5 (copy), u9 (copy), u11 (copy), u12 (copy), u10 (copy), u8 (copy), u7 (copy)
    local l__state__25 = p105.state;
    local l__props__26 = p105.props;
    local l__Map__27 = u3.Map;
    local v106 = #l__Map__27.Tiles;
    local v107 = l__Map__27.StudsToPixels or 1;
    local u108 = v106 * 1024 * v107;
    local l__PopupActive__28 = l__props__26.PopupActive;
    local v109 = l__props__26.Transition or u6.new(0);
    local v110 = {};
    for v111 = 1, v106 do
        for v112 = 1, v106 do
            local v113 = l__Map__27.Tiles[v111][v112];
            if v113 ~= "" then
                v110[v111 .. "-" .. v112] = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Size = UDim2.fromScale(1 / v106, 1 / v106),
                    Position = UDim2.fromScale(1 / v106 * (v112 - 1), 1 / v106 * (v111 - 1)),
                    Image = v113,
                    ImageColor3 = Color3.fromRGB(206, 206, 206),
                    ResampleMode = Enum.ResamplerMode.Pixelated,
                    ImageTransparency = v109:Map(function(p114) --[[ Line: 439 ]]
                        return p114 / 2;
                    end)
                });
            end;
        end;
    end;
    local _ = v106 * v107;
    local l__Resolution__29 = l__state__25.Resolution;
    local v115 = 3.28084 / u108;
    local u116 = math.ceil(u108 / 3.28084 / 2);
    local v117 = {};
    local v118 = {};
    for v119 = math.max(l__state__25.X.X, 0), l__state__25.X.Y do
        local v120, v121 = u26({
            Axis = "X",
            Grid = v119 * l__Resolution__29,
            Zoom = p105._zoomLevel,
            Position = v119 * l__Resolution__29 * v115,
            Transition = v109
        });
        local v122 = #v117 + 1;
        v117[v122] = v121;
        v118[string.format("x%s", v122)] = v120;
    end;
    local v123 = {};
    for v124 = math.max(l__state__25.Y.X, 0), l__state__25.Y.Y do
        local v125, v126 = u26({
            Axis = "Y",
            Grid = v124 * l__Resolution__29,
            Zoom = p105._zoomLevel,
            Position = v124 * l__Resolution__29 * v115,
            Transition = v109
        });
        local v127 = #v123 + 1;
        v123[v127] = v126;
        v118[string.format("y%s", v127)] = v125;
    end;
    local l__LocalClient__30 = u5.LocalClient;
    local v128 = {};
    for v129, v130 in l__state__25.SquadMarkers do
        local v131 = string.format("%05i", (math.floor(v130.X / 3.28084 + u116)));
        local v132 = string.format("%05i", (math.floor(-v130.Z / 3.28084 + u116)));
        local v133 = v129 == l__LocalClient__30 and "(Your Marker)" or v129.Owner.Name .. "\'s Marker";
        v128[v129] = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5 + v130.X / u108, 0.5 + v130.Z / u108),
            Size = p105._zoomLevel:Map(function(p134) --[[ Line: 496 ]]
                -- upvalues: u108 (copy)
                return UDim2.fromScale(30 / u108 / p134, 30 / u108 / p134);
            end),
            ImageColor3 = Color3.new(0, 1, 0),
            Image = u9[v130.Icon]
        }, { u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ClipsDescendants = true,
                Position = UDim2.fromScale(1.3, 0.5),
                Size = UDim2.fromScale(10, 1),
                AnchorPoint = Vector2.new(0, 0.5)
            }, { u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Position = p105._zoomLevel:Map(function(p135) --[[ Line: 512 ]]
                        return UDim2.fromScale((math.clamp(p135, 0.5, 0.7) - 0.5) * 5 + -1, 0);
                    end),
                    Size = UDim2.fromScale(1, 1)
                }, { u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        Size = p105._zoomLevel:Map(function(p136) --[[ Line: 519 ]]
                            return UDim2.fromScale(1, 1 - (math.clamp(p136, 1.6, 1.8) - 1.6) * 5 / 2);
                        end),
                        Position = UDim2.fromScale(0, 0),
                        Text = v133,
                        TextColor3 = Color3.new(0, 1, 0),
                        TextXAlignment = Enum.TextXAlignment.Left,
                        FontFace = u11
                    }), u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        Size = UDim2.fromScale(1, 0.5),
                        Position = p105._zoomLevel:Map(function(p137) --[[ Line: 532 ]]
                            return UDim2.fromScale((math.clamp(p137, 1.6, 1.8) - 1.6) * 5 + -1, 0.5);
                        end),
                        Text = v131 .. " " .. v132,
                        TextColor3 = Color3.new(0, 1, 0),
                        TextXAlignment = Enum.TextXAlignment.Left,
                        FontFace = u12
                    }) }) }) });
    end;
    local v138 = {};
    for v139, v140 in l__state__25.KnownEnemies do
        if v140.Icon > 0 then
            v138[v139] = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = v140.PositionBinding:map(function(p141) --[[ Line: 551 ]]
                    -- upvalues: u108 (copy)
                    return UDim2.fromScale(p141.X / u108 + 0.5, p141.Z / u108 + 0.5);
                end),
                Size = p105._zoomLevel:Map(function(p142) --[[ Line: 554 ]]
                    -- upvalues: u108 (copy)
                    return UDim2.fromScale(25 / u108 / p142, 25 / u108 / p142);
                end),
                Image = u10[v140.Icon],
                ImageColor3 = p105._flash:map(function(p143) --[[ Line: 560 ]]
                    return Color3.fromRGB(223, 51, 51):Lerp(Color3.fromRGB(230, 124, 124), math.sin(p143 * 100) / 2 + 0.5);
                end)
            }, { u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    ClipsDescendants = true,
                    Position = UDim2.fromScale(1.6, 0.5),
                    Size = UDim2.fromScale(10, 2),
                    AnchorPoint = Vector2.new(0, 0.5)
                }, { u2.createElement("Frame", {
                        BackgroundTransparency = 1,
                        Position = p105._zoomLevel:Map(function(p144) --[[ Line: 573 ]]
                            return UDim2.fromScale((math.clamp(p144, 0.5, 0.7) - 0.5) * 5 + -1, 0);
                        end),
                        Size = UDim2.fromScale(1, 1)
                    }, { u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            Text = "Kill Target",
                            TextScaled = true,
                            Size = UDim2.fromScale(1, 0.5),
                            Position = UDim2.fromScale(0, 0.25),
                            TextColor3 = p105._flash:map(function(p145) --[[ Line: 583 ]]
                                return Color3.fromRGB(223, 51, 51):Lerp(Color3.fromRGB(230, 124, 124), math.sin(p145 * 100) / 2 + 0.5);
                            end),
                            TextXAlignment = Enum.TextXAlignment.Left,
                            FontFace = u11
                        }) }) }) });
        else
            v138[v139] = u2.createElement("Frame", {
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = v140.PositionBinding:map(function(p146) --[[ Line: 596 ]]
                    -- upvalues: u108 (copy)
                    return UDim2.fromScale(p146.X / u108 + 0.5, p146.Z / u108 + 0.5);
                end),
                Size = p105._zoomLevel:Map(function(p147) --[[ Line: 599 ]]
                    -- upvalues: u108 (copy)
                    return UDim2.fromScale(8 / u108 / p147, 8 / u108 / p147);
                end),
                BackgroundColor3 = p105._flash:map(function(p148) --[[ Line: 604 ]]
                    return Color3.fromRGB(223, 51, 51):Lerp(Color3.fromRGB(230, 124, 124), math.sin(p148 * 100) / 2 + 0.5);
                end)
            }, {
                Corner = u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.5, 0)
                })
            });
        end;
    end;
    local v149 = {};
    for v150, v151 in l__state__25.SquadClients do
        v149[v150] = u2.createElement("Frame", {
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = v151.PositionBinding:map(function(p152) --[[ Line: 619 ]]
                -- upvalues: u108 (copy)
                return UDim2.fromScale(p152.X / u108 + 0.5, p152.Z / u108 + 0.5);
            end),
            Size = p105._zoomLevel:Map(function(p153) --[[ Line: 622 ]]
                -- upvalues: u108 (copy)
                return UDim2.fromScale(15 / u108 / p153, 15 / u108 / p153);
            end),
            BackgroundColor3 = Color3.new(0, 1, 0)
        }, {
            Corner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0.5, 0)
            }),
            Stroke = u2.createElement("UIStroke", {
                Transparency = 0.5,
                Thickness = 1,
                ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                Color = Color3.new(),
                LineJoinMode = Enum.LineJoinMode.Round
            }),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.5),
                Size = UDim2.fromScale(1, 1),
                Rotation = v151.OrientationBinding:map(function(p154) --[[ Line: 644 ]]
                    return -math.deg(p154);
                end)
            }, { u2.createElement("ImageLabel", {
                    Image = "rbxassetid://119094063693789",
                    BackgroundTransparency = 1,
                    Size = UDim2.fromScale(1, 1),
                    Position = UDim2.fromScale(0, -1),
                    ImageColor3 = Color3.new(0, 1, 0)
                }) }),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ClipsDescendants = true,
                Position = UDim2.fromScale(1.6, 0.5),
                Size = UDim2.fromScale(10, 2),
                AnchorPoint = Vector2.new(0, 0.5)
            }, { u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Position = p105._zoomLevel:Map(function(p155) --[[ Line: 665 ]]
                        return UDim2.fromScale((math.clamp(p155, 0.5, 0.7) - 0.5) * 5 + -1, 0);
                    end),
                    Size = UDim2.fromScale(1, 1)
                }, { u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        Size = p105._zoomLevel:Map(function(p156) --[[ Line: 672 ]]
                            return UDim2.fromScale(1, 1 - (math.clamp(p156, 1.6, 1.8) - 1.6) * 5 / 2);
                        end),
                        Position = UDim2.fromScale(0, 0),
                        Text = v151.Name,
                        TextColor3 = Color3.new(0, 1, 0),
                        TextXAlignment = Enum.TextXAlignment.Left,
                        FontFace = u11
                    }), u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        Size = UDim2.fromScale(1, 0.5),
                        Position = p105._zoomLevel:Map(function(p157) --[[ Line: 685 ]]
                            return UDim2.fromScale((math.clamp(p157, 1.6, 1.8) - 1.6) * 5 + -1, 0.5);
                        end),
                        Text = v151.PositionBinding:map(function(p158) --[[ Line: 688 ]]
                            -- upvalues: u116 (copy)
                            return string.format("%05i", (math.floor(p158.X / 3.28084 + u116))) .. " " .. string.format("%05i", (math.floor(-p158.Z / 3.28084 + u116)));
                        end),
                        TextColor3 = Color3.new(0, 1, 0),
                        TextXAlignment = Enum.TextXAlignment.Left,
                        FontFace = u12
                    }) }) })
        });
    end;
    local v159 = {};
    local v160 = {};
    if l__props__26.Deploys and u3.Spawns then
        for v161, v162 in u3.Spawns do
            local l__Position__31 = v162.Position;
            v160[#v160 + 1] = u2.createElement(u8, {
                Position = UDim2.fromScale(0.5 + l__Position__31[1] / u108, 0.5 + l__Position__31[2] / u108),
                Size = p105._zoomLevel:Map(function(p163) --[[ Line: 710 ]]
                    -- upvalues: u108 (copy)
                    return UDim2.fromScale(50 / u108 / p163, 50 / u108 / p163);
                end),
                Level = v162.Level,
                Name = v162.Name,
                Location = v161,
                PopupActive = l__PopupActive__28
            });
            if v161:sub(1, 8) == "Compound" then
                v159[v161:sub(9)] = true;
            end;
        end;
    end;
    local v164 = {};
    if u3.Compounds then
        for v165, v166 in u3.Compounds do
            if not v159[v165] then
                local l__Position__32 = v166.Position;
                v164[v165] = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    BorderSizePixel = 0,
                    Image = "rbxassetid://119359500180421",
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Position = UDim2.fromScale(0.5 + l__Position__32[1] / u108, 0.5 + l__Position__32[2] / u108),
                    Size = p105._zoomLevel:Map(function(p167) --[[ Line: 735 ]]
                        -- upvalues: u108 (copy)
                        return UDim2.fromScale(25 / u108 / p167, 25 / u108 / p167);
                    end),
                    ImageColor3 = v166.Defeated and Color3.new(0, 1, 0) or Color3.new(1, 0, 0)
                }, { u2.createElement("Frame", {
                        BackgroundTransparency = 1,
                        ClipsDescendants = true,
                        Position = UDim2.fromScale(1.6, 0.5),
                        Size = UDim2.fromScale(10, 2),
                        AnchorPoint = Vector2.new(0, 0.5)
                    }, { u2.createElement("Frame", {
                            BackgroundTransparency = 1,
                            Position = p105._zoomLevel:Map(function(p168) --[[ Line: 752 ]]
                                return UDim2.fromScale((math.clamp(p168, 0.5, 0.7) - 0.5) * 5 + -1, 0);
                            end),
                            Size = UDim2.fromScale(1, 1)
                        }, { u2.createElement("TextLabel", {
                                BackgroundTransparency = 1,
                                TextScaled = true,
                                Size = UDim2.fromScale(1, 0.5),
                                Position = UDim2.fromScale(0, 0.25),
                                Text = v165,
                                TextColor3 = v166.Defeated and Color3.new(0, 1, 0) or Color3.new(1, 0, 0),
                                TextXAlignment = Enum.TextXAlignment.Left,
                                FontFace = u11
                            }) }) }) });
            end;
        end;
    end;
    local v169 = {};
    for v170, v171 in u7 do
        if not v171.Range then
            local l__WorldPosition__33 = v170.WorldPosition;
            v169[v170] = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                BorderSizePixel = 0,
                Image = "rbxassetid://124178668657896",
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(l__WorldPosition__33.X / u108 + 0.5, l__WorldPosition__33.Z / u108 + 0.5),
                Size = p105._zoomLevel:Map(function(p172) --[[ Line: 783 ]]
                    -- upvalues: u108 (copy)
                    return UDim2.fromScale(25 / u108 / p172, 25 / u108 / p172);
                end),
                ImageColor3 = p105._flash:map(function(p173) --[[ Line: 789 ]]
                    return Color3.fromRGB(223, 149, 51):Lerp(Color3.fromRGB(230, 184, 124), math.sin(p173 * 100) / 2 + 0.5);
                end)
            }, { u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    ClipsDescendants = true,
                    Position = UDim2.fromScale(1.6, 0.5),
                    Size = UDim2.fromScale(10, 2),
                    AnchorPoint = Vector2.new(0, 0.5)
                }, { u2.createElement("Frame", {
                        BackgroundTransparency = 1,
                        Position = p105._zoomLevel:Map(function(p174) --[[ Line: 802 ]]
                            return UDim2.fromScale((math.clamp(p174, 0.5, 0.7) - 0.5) * 5 + -1, 0);
                        end),
                        Size = UDim2.fromScale(1, 1)
                    }, { u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            TextScaled = true,
                            Size = UDim2.fromScale(1, 0.5),
                            Position = UDim2.fromScale(0, 0.25),
                            Text = v171.Title,
                            TextColor3 = p105._flash:map(function(p175) --[[ Line: 812 ]]
                                return Color3.fromRGB(223, 149, 51):Lerp(Color3.fromRGB(230, 184, 124), math.sin(p175 * 100) / 2 + 0.5);
                            end),
                            TextXAlignment = Enum.TextXAlignment.Left,
                            FontFace = u11
                        }) }) }) });
        end;
    end;
    return u2.createElement("Frame", {
        ZIndex = 1,
        BackgroundColor3 = v109:Map(function(p176) --[[ Line: 825 ]]
            return Color3.fromRGB(0, 19, 36):Lerp(Color3.fromRGB(0, 8, 15), p176);
        end),
        Size = UDim2.fromScale(1, 1)
    }, {
        Grain = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://3045438863",
            ImageTransparency = 0.85,
            ZIndex = 3,
            AnchorPoint = Vector2.new(1, 0),
            Position = UDim2.fromScale(1, 0),
            Size = p105._grainBinding,
            ScaleType = Enum.ScaleType.Tile,
            TileSize = UDim2.new(0, 2048, 0, 2048),
            ImageColor3 = Color3.fromRGB(91, 91, 91)
        }),
        Map = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ZIndex = 1,
            Size = p105._zoomLevel:Map(function(p177) --[[ Line: 845 ]]
                -- upvalues: u108 (copy)
                return UDim2.fromOffset(u108 * p177, u108 * p177);
            end),
            Position = UDim2.fromScale(0.5, 0.5),
            AnchorPoint = p105._positionBinding
        }, {
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(1, 1)
            }, v110),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ZIndex = 2,
                Size = UDim2.fromScale(1, 1)
            }, v118),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ZIndex = 3,
                Size = UDim2.fromScale(1, 1)
            }, v149),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ZIndex = 4,
                Size = UDim2.fromScale(1, 1)
            }, v128),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ZIndex = 5,
                Size = UDim2.fromScale(1, 1)
            }, v160),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ZIndex = 6,
                Size = UDim2.fromScale(1, 1)
            }, v138),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ZIndex = 7,
                Size = UDim2.fromScale(1, 1)
            }, v164),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ZIndex = 8,
                Size = UDim2.fromScale(1, 1)
            }, v169)
        }),
        XGlow = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 2,
            Size = UDim2.fromScale(1, 0.08),
            Position = UDim2.fromScale(0, 0),
            BackgroundTransparency = v109:Map(function(p178) --[[ Line: 896 ]]
                return p178 * 0.15 + 0.85;
            end),
            BackgroundColor3 = Color3.fromRGB(255, 194, 89)
        }, {
            Gradient = u2.createElement("UIGradient", {
                Rotation = 90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
            }),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = p105._zoomLevel:Map(function(p179) --[[ Line: 911 ]]
                    -- upvalues: u108 (copy)
                    return UDim2.new(0, u108 * p179, 1, 0);
                end),
                AnchorPoint = p105._positionBinding:map(function(p180) --[[ Line: 914 ]]
                    return Vector2.new(p180.X, 0);
                end),
                Position = UDim2.fromScale(0.5, 0)
            }, v117)
        }),
        YGlow = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 2,
            Size = UDim2.fromScale(0.08, 1),
            Position = UDim2.fromScale(0, 0),
            AnchorPoint = Vector2.new(0, 0),
            BackgroundTransparency = v109:Map(function(p181) --[[ Line: 925 ]]
                return p181 * 0.15 + 0.85;
            end),
            BackgroundColor3 = Color3.fromRGB(255, 194, 89),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }, {
            Gradient = u2.createElement("UIGradient", {
                Rotation = 0,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
            }),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = p105._zoomLevel:Map(function(p182) --[[ Line: 941 ]]
                    -- upvalues: u108 (copy)
                    return UDim2.new(1, 0, 0, u108 * p182);
                end),
                Position = UDim2.fromScale(0, 0.5),
                AnchorPoint = p105._positionBinding:map(function(p183) --[[ Line: 945 ]]
                    return Vector2.new(0, p183.Y);
                end)
            }, v123)
        }),
        Compass = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://15604768771",
            AnchorPoint = Vector2.new(0.5, 1),
            Position = UDim2.fromScale(0.9, 0.92),
            Size = UDim2.fromScale(0.1, 0.1),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            ImageColor3 = Color3.fromRGB(255, 194, 89),
            ImageTransparency = v109:Map(function(p184) --[[ Line: 958 ]]
                return p184;
            end)
        }, {
            Gradient = u2.createElement("UIGradient", {
                Rotation = 90,
                Transparency = NumberSequence.new({
                    NumberSequenceKeypoint.new(0, 0),
                    NumberSequenceKeypoint.new(0.3, 0),
                    NumberSequenceKeypoint.new(0.5, 0.5),
                    NumberSequenceKeypoint.new(1, 0.5)
                })
            }),
            N = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "N",
                TextScaled = true,
                AnchorPoint = Vector2.new(0.5, 1),
                Size = UDim2.fromScale(0.3, 0.3),
                Position = UDim2.fromScale(0.5, 0),
                TextColor3 = Color3.fromRGB(255, 194, 89),
                TextTransparency = v109:Map(function(p185) --[[ Line: 979 ]]
                    return p185;
                end),
                TextXAlignment = Enum.TextXAlignment.Center,
                FontFace = u11
            }),
            S = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "S",
                TextScaled = true,
                AnchorPoint = Vector2.new(0.5, 0),
                Size = UDim2.fromScale(0.3, 0.3),
                Position = UDim2.fromScale(0.5, 1),
                TextColor3 = Color3.fromRGB(255, 194, 89),
                TextTransparency = v109:Map(function(p186) --[[ Line: 993 ]]
                    return p186 / 2 + 0.5;
                end),
                TextXAlignment = Enum.TextXAlignment.Center,
                FontFace = u12
            }),
            E = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "E",
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0.5),
                Size = UDim2.fromScale(0.3, 0.3),
                Position = UDim2.fromScale(1, 0.5),
                TextColor3 = Color3.fromRGB(255, 194, 89),
                TextTransparency = v109:Map(function(p187) --[[ Line: 1007 ]]
                    return p187 / 2 + 0.5;
                end),
                TextXAlignment = Enum.TextXAlignment.Center,
                FontFace = u12
            }),
            W = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "W",
                TextScaled = true,
                AnchorPoint = Vector2.new(1, 0.5),
                Size = UDim2.fromScale(0.3, 0.3),
                Position = UDim2.fromScale(0, 0.5),
                TextColor3 = Color3.fromRGB(255, 194, 89),
                TextTransparency = v109:Map(function(p188) --[[ Line: 1021 ]]
                    return p188 / 2 + 0.5;
                end),
                TextXAlignment = Enum.TextXAlignment.Center,
                FontFace = u12
            })
        })
    });
end;
return v13;