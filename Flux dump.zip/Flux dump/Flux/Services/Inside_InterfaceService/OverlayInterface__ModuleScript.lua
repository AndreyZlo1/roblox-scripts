-- Services.InterfaceService.OverlayInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, _, _ = shared.import("require", "Enum", "Roact", "network", "signal");
local u4 = v1("GameShellProxyService");
local u5 = {};
u5.__index = u5;
function u5.new() --[[ Line: 19 ]]
    -- upvalues: u4 (copy), u2 (copy), u5 (copy)
    local v6 = {
        _ui = u4:CreateProxy(3, u2.ShellPriority.AlwaysVisible, "OverlayInterface")
    };
    return setmetatable(v6, u5);
end;
function u5.Mount(u7, u8, p9) --[[ Line: 28 ]]
    -- upvalues: u3 (copy)
    if u7.Locked then
    else
        if u7.Handle then
            u3.unmount(u7.Handle);
            u7.Handle = nil;
        end;
        if u8 then
            u7.Handle = u3.mount(u3.createElement(u8, p9), u7._ui);
            return function(p10) --[[ Line: 40 ]]
                -- upvalues: u7 (copy), u3 (ref), u8 (copy)
                u7.Handle = u3.update(u7.Handle, u3.createElement(u8, p10));
            end;
        end;
    end;
end;
return u5.new();