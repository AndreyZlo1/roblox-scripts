-- Services.InterfaceService.TagInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4, u5 = shared.import("require", "Enum", "Roact", "network", "server");
local u6 = v1("GameShellProxyService");
local u7 = v1("ClientService");
local u8 = v1("ReplicatorService");
local u9 = v1("SoundService");
local u10 = v1("VehicleService");
local u11 = v1("TagComponent");
local u12 = v1("sanitizeDisplayName");
local u13 = v1("convertUnit");
local u14 = v1("RoactTween");
local l__LocalPlayer__1 = game:GetService("Players").LocalPlayer;
local u15 = v1("POI");
local l__CurrentCamera__2 = workspace.CurrentCamera;
local u16 = {
    Red = Color3.fromRGB(255, 10, 14),
    Orange = Color3.fromRGB(255, 150, 29),
    Blue = Color3.fromRGB(52, 133, 255),
    Yellow = Color3.fromRGB(255, 216, 57)
};
local u17 = {};
u17.__index = u17;
function u17._update(p18) --[[ Line: 47 ]]
    -- upvalues: u3 (copy), u11 (copy)
    p18._handle = u3.update(p18._handle, u3.createElement(u11, {
        Squad = p18._squadClients,
        SquadColor = p18._squadColor,
        Markers = p18._markers,
        SpottedMarkers = p18._spottedMarkers,
        Spotted = p18._spotted,
        POI = p18._poi
    }));
end;
function u17.new() --[[ Line: 58 ]]
    -- upvalues: u3 (copy), u14 (copy), u2 (copy), u9 (copy), u6 (copy), u11 (copy), u17 (copy), u4 (copy), u8 (copy)
    local v19, v20 = u3.createBinding("");
    local v21, v22 = u3.createBinding(false);
    local v23 = u14.new(1, TweenInfo.new(0.01, u2.EasingStyle.Exponential, u2.EasingDirection.Out, 0, false, 0));
    local v24, v25 = u3.createBinding(0);
    local v26, v27 = u3.createBinding(0);
    local l__Sound__3 = u9:CreateSound("Button", nil, false, "UISounds", "SpottedAlert").Sound;
    local l__Sound__4 = u9:CreateSound("Button", nil, false, "UISounds", "SpotNotif").Sound;
    local l__Sound__5 = u9:CreateSound("Button", nil, false, "UISounds", "SpottingLoop").Sound;
    local v28 = u6:CreateProxy(1, u2.ShellPriority.Default, "TagInterface");
    local v29 = {
        _lastSpottedNotif = 0,
        _lastAlertNotif = 0,
        _timerID = 1,
        _spotted = false,
        _barProgress = 0,
        _progressPerUpdate = 0,
        _squadClients = {},
        _handle = u3.mount(u3.createElement(u11, {
            Spotted = false,
            MedicalBinding = v21,
            NameTagBinding = v19,
            NameTagTween = v23,
            Markers = {},
            Squad = {},
            POI = {},
            SquadColor = Color3.new(),
            SpottedMarkers = {},
            SpottedMeter = v24,
            Flash = v26
        }), v28),
        _poi = {},
        _markers = {},
        _nameTagTween = v23,
        _updateNameTag = v20,
        _updateMedical = v22,
        _updateSpotted = v25,
        _updateFlash = v27,
        _spottedAlert = l__Sound__3,
        _spottedLoop = l__Sound__5,
        _spottedTimers = {},
        _spottedMarkers = {}
    };
    local u30 = setmetatable(v29, u17);
    u4:ConnectEvents({
        SetMarker = function(p31, p32, p33, p34) --[[ Name: SetMarker, Line 112 ]]
            -- upvalues: u30 (copy), u3 (ref)
            local v35 = u30._markers[p31];
            if p32 then
                if v35 then
                    v35.IsBig = p34;
                    v35.Position = p32;
                    v35.Text = p33;
                else
                    local v36, v37 = u3.createBinding(0);
                    local v38, v39 = u3.createBinding(UDim2.fromOffset(0, 0));
                    local v40, v41 = u3.createBinding("0f");
                    u30._markers[p31] = {
                        IsBig = p34,
                        Position = p32,
                        Text = p33,
                        PositionBinding = v38,
                        SetPosition = v39,
                        DistanceBinding = v40,
                        SetDistance = v41,
                        TransparencyBinding = v36,
                        SetTransparency = v37
                    };
                end;
            else
                u30._markers[p31] = nil;
            end;
            u30:_update();
        end,
        BeingSpotted = function(p42, p43, p44, p45) --[[ Name: BeingSpotted, Line 138 ]]
            -- upvalues: u30 (copy), u8 (ref), l__Sound__4 (copy)
            local v46 = u30._spottedTimers[p42];
            if p43 then
                if p45 then
                    local v47 = u8.Actors[p42];
                    if not (v47 and v47.Radioing) then
                        return;
                    end;
                end;
                if v46 then
                    if v46.Radio then
                        return;
                    end;
                else
                    local v48 = tick();
                    if v48 - u30._lastSpottedNotif > 1 and v48 - u30._lastAlertNotif > 5 then
                        u30._lastSpottedNotif = v48;
                        l__Sound__4:Play();
                    end;
                end;
                local v49 = u30;
                v49._timerID = v49._timerID + 1;
                u30._spottedTimers[p42] = {
                    ID = u30._timerID,
                    Start = p43,
                    Finish = p44,
                    Radio = p45
                };
            else
                if v46 and (not v46.Radio or p45) then
                    u30._spottedTimers[p42] = nil;
                end;
            end;
        end,
        BeenSpotted = function(p50) --[[ Name: BeenSpotted, Line 169 ]]
            -- upvalues: u30 (copy), l__Sound__3 (copy)
            local v51 = tick();
            if v51 - u30._lastAlertNotif > 5 then
                u30._lastAlertNotif = v51;
                l__Sound__3:Play();
            end;
            local v52 = u30._spottedTimers[p50];
            if v52 and v52.Radio then
            else
                local v53 = u30;
                v53._timerID = v53._timerID + 1;
                u30._spottedTimers[p50] = nil;
                local v54 = u30._spottedMarkers[p50];
                if v54 then
                    v54.ExpandCircle:SetValue(0);
                    v54.ExpandCircle:SetGoal(1);
                end;
            end;
        end
    });
    return u30;
end;
function u17.Update(p55, p56) --[[ Line: 195 ]]
    -- upvalues: u7 (copy), l__CurrentCamera__2 (copy), u3 (copy), u12 (copy), u13 (copy), u2 (copy), u8 (copy), u5 (copy), u10 (copy), l__LocalPlayer__1 (copy), u14 (copy), u15 (copy), u16 (copy)
    local l__LocalClient__6 = u7.LocalClient;
    if l__LocalClient__6 then
        local v57 = l__CurrentCamera__2.ViewportSize / 2;
        local v58 = v57.Y * 0.2;
        local v59 = false;
        local l___squadClients__7 = p55._squadClients;
        local v60 = {};
        local l__Position__8 = l__CurrentCamera__2.CFrame.Position;
        local l__Actor__9 = l__LocalClient__6.Actor;
        if l__Actor__9 then
            l__Position__8 = l__Actor__9.Position;
        end;
        local l__Squad__10 = l__LocalClient__6.Squad;
        for _, v61 in u7:GetClients() do
            if v61 ~= l__LocalClient__6 then
                local l__Squad__11 = v61.Squad;
                if l__Squad__11 then
                    l__Squad__11 = v61.Squad == l__Squad__10;
                end;
                if l__Squad__11 then
                    v60[v61] = true;
                    if not l___squadClients__7[v61] then
                        local v62, v63 = u3.createBinding(nil);
                        local v64, v65 = u3.createBinding(0);
                        local v66, v67 = u3.createBinding(UDim2.fromOffset(0, 0));
                        local v68, v69 = u3.createBinding("0f");
                        local l__Owner__12 = v61.Owner;
                        l___squadClients__7[v61] = {
                            Name = u12(l__Owner__12.DisplayName, l__Owner__12.Name),
                            PositionBinding = v66,
                            SetPosition = v67,
                            DistanceBinding = v68,
                            SetDistance = v69,
                            TransparencyBinding = v64,
                            SetTransparency = v65,
                            DownedBinding = v62,
                            UpdateDowned = v63
                        };
                        v59 = true;
                    end;
                    local v70 = l___squadClients__7[v61];
                    local v71 = Vector2.new((-1 / 0), (-1 / 0));
                    local l__Actor__13 = v61.Actor;
                    if l__Actor__13 and l__Actor__13.Alive then
                        local v72 = l__Actor__13.UseClient and l__Actor__13.Parts.UpperTorso.Position or l__Actor__13.ServerPosition;
                        local v73, v74 = l__CurrentCamera__2:WorldToViewportPoint(v72);
                        if v74 then
                            v71 = Vector2.new(v73.X, v73.Y);
                        end;
                        if l__Actor__13.Downed then
                            v70.UpdateDowned(tick() % 1 > 0.5 and 1 or 2);
                        elseif v70.DownedBinding:getValue() then
                            v70.UpdateDowned(nil);
                        end;
                        v70.SetDistance(u13((v72 - l__Position__8).Magnitude));
                    end;
                    v70.SetTransparency(1 - math.min(1, (v71 - v57).Magnitude / v58) - 0.2);
                    v70.SetPosition(UDim2.fromOffset(v71.X, v71.Y));
                end;
            end;
        end;
        for v75 in l___squadClients__7 do
            if not v60[v75] then
                l___squadClients__7[v75] = nil;
                v59 = true;
            end;
        end;
        for _, v76 in p55._markers do
            local v77 = Vector2.new((-1 / 0), (-1 / 0));
            local l__Position__14 = v76.Position;
            local v78, v79 = l__CurrentCamera__2:WorldToViewportPoint(l__Position__14);
            if v79 then
                v77 = Vector2.new(v78.X, v78.Y);
                v76.SetTransparency(1 - math.min(1, (v77 - v57).Magnitude / v58) - 0.2);
                v76.SetDistance(u13((l__Position__14 - l__Position__8).Magnitude));
            end;
            v76.SetPosition(UDim2.fromOffset(v77.X, v77.Y));
        end;
        local v80 = RaycastParams.new();
        v80.FilterType = u2.RaycastFilterType.Blacklist;
        v80.IgnoreWater = true;
        if l__Actor__9 then
            v80.FilterDescendantsInstances = { l__Actor__9.Character };
        end;
        local v81 = nil;
        local v82 = false;
        local v83 = workspace:Raycast(l__CurrentCamera__2.CFrame.Position, l__CurrentCamera__2.CFrame.LookVector * 50, v80);
        local v84;
        if v83 then
            local v85;
            v84, v85 = u8:GetClientFromPart(v83.Instance);
            if v84 then
                if u5.IS_PVP and v84.Squad ~= l__Squad__10 then
                    v84 = v81;
                else
                    v82 = true;
                    local l__Owner__15 = v84.Owner;
                    local v86 = u12(l__Owner__15.DisplayName, l__Owner__15.Name);
                    if not v85.Alive then
                        v86 = v86 .. " (Dead)";
                    end;
                    p55._updateNameTag(v86);
                    if l__Actor__9 and v85.Alive then
                        p55._updateMedical((v85.Parts.UpperTorso.Position - l__Position__8).Magnitude < 6);
                    else
                        v84 = v81;
                    end;
                end;
            elseif l__Actor__9 and not l__Actor__9.Seat then
                local v87 = u10:QueryHitbox(v83.Instance);
                if v87 and (v87.Owner and v87.Owner ~= l__LocalPlayer__1) then
                    local l__Owner__16 = v87.Owner;
                    p55._updateNameTag(u12(l__Owner__16.DisplayName, l__Owner__16.Name) .. "\'s Vehicle");
                    p55._updateMedical(false);
                    v84 = v81;
                    v82 = true;
                else
                    v84 = v81;
                end;
            else
                v84 = v81;
            end;
        else
            v84 = v81;
        end;
        p55.HoveringClient = v84;
        local v88 = workspace:GetServerTimeNow();
        local v89 = nil;
        local v90 = {};
        local v91 = nil;
        local v92 = nil;
        for v93, v94 in p55._spottedTimers do
            if v94.Finish < v88 then
                p55._spottedTimers[v93] = nil;
            else
                local v95 = v94.Finish - v88;
                if v94.Radio or v89 ~= nil and v94.Finish >= v89.Finish or v95 <= 0 then
                    v95 = v92;
                else
                    v91 = v94.ID;
                    v89 = v94;
                end;
                v90[v93] = true;
                if p55._spottedMarkers[v93] then
                    v92 = v95;
                else
                    local v96 = u14.new(0);
                    local v97 = u14.new(0);
                    local v98, v99 = u3.createBinding(nil);
                    local v100, v101 = u3.createBinding(UDim2.fromOffset(0, 0));
                    local v102, v103 = u3.createBinding(0);
                    p55._spottedMarkers[v93] = {
                        Text = "?",
                        ExpandCircle = v96,
                        PositionBinding = v100,
                        SetPosition = v101,
                        RadioCircle = v97,
                        ArrowBinding = v98,
                        SetArrow = v99,
                        TransparencyBinding = v102,
                        SetTransparency = v103,
                        Start = v94.Start,
                        Finish = v94.Finish,
                        Radio = v94.Radio
                    };
                    v96:SetGoal(1);
                    v92 = v95;
                    v59 = true;
                end;
            end;
        end;
        local l__X__17 = l__CurrentCamera__2.ViewportSize.X;
        local l__Y__18 = l__CurrentCamera__2.ViewportSize.Y;
        local v104 = l__Y__18 * 0.04 * 1.5;
        local v105 = l__X__17 - v104 * 2;
        local v106 = l__Y__18 - v104 * 2;
        local v107 = math.sqrt((v105 / 2) ^ 2 + (v106 / 2) ^ 2);
        local v108 = workspace:GetServerTimeNow();
        for v109, v110 in p55._spottedMarkers do
            if v90[v109] then
                v110.RadioCircle:SetValue((v108 - v110.Start) / (v110.Finish - v110.Start));
                Vector2.new((-1 / 0), (-1 / 0));
                local v111 = u8:GetActorPosition(v109);
                if v111 then
                    local v112 = v111 + Vector3.new(0, 4, 0);
                    local v113, v114 = l__CurrentCamera__2:WorldToViewportPoint(v112);
                    if v114 then
                        local v115 = Vector2.new(v113.X, v113.Y);
                        v110.SetTransparency(1 - math.min(1, (v115 - v57).Magnitude / v58) - 0.2);
                    end;
                    local v116 = math.clamp(v113.X, v104, l__X__17 - v104);
                    local v117 = math.clamp(v113.Y, v104, l__Y__18 - v104);
                    if v116 == v113.X and (v117 == v113.Y and v114) then
                        v110.SetArrow(nil);
                    else
                        local v118 = l__CurrentCamera__2.CFrame:VectorToObjectSpace(v112 - l__CurrentCamera__2.CFrame.Position);
                        local l__Unit__19 = Vector2.new(v118.X, v118.Y).Unit;
                        local v119 = l__Unit__19 * v107;
                        local v120 = math.atan2(l__Unit__19.X, l__Unit__19.Y);
                        local v121;
                        if math.abs(v119.Y) > v106 / 2 then
                            v121 = l__Unit__19 * math.abs(v106 / 2 / l__Unit__19.Y);
                        else
                            v121 = l__Unit__19 * math.abs(v105 / 2 / l__Unit__19.X);
                        end;
                        v116 = l__X__17 / 2 + v121.X;
                        v117 = l__Y__18 / 2 - v121.Y;
                        v110.SetArrow((math.deg(v120)));
                    end;
                    v110.SetPosition(UDim2.fromOffset(v116, v117));
                else
                    p55._spottedMarkers[v109] = nil;
                    v59 = true;
                end;
            else
                p55._spottedMarkers[v109] = nil;
                v59 = true;
            end;
        end;
        for v122, v123 in u15 do
            if not p55._poi[v122] then
                local v124, v125 = u3.createBinding(UDim2.fromOffset(0, 0));
                local v126, v127 = u3.createBinding("0f");
                local v128, v129 = u3.createBinding(v123.Title);
                local v130, v131 = u3.createBinding(v123.Color or Color3.new(1, 0.5, 0));
                local v132, v133 = u3.createBinding(0);
                p55._poi[v122] = {
                    TextBinding = v128,
                    SetText = v129,
                    Range = v123.Range,
                    PositionBinding = v124,
                    SetPosition = v125,
                    DistanceBinding = v126,
                    SetDistance = v127,
                    TransparencyBinding = v132,
                    SetTransparency = v133,
                    ColorBinding = v130,
                    SetColor = v131
                };
                v59 = true;
            end;
            local v134 = p55._poi[v122];
            local l__WorldPosition__20 = v122.WorldPosition;
            local l__Magnitude__21 = (l__WorldPosition__20 - l__Position__8).Magnitude;
            local v135 = Vector2.new((-1 / 0), (-1 / 0));
            if l__Magnitude__21 > 8 and l__Magnitude__21 < (v134.Range or 500) then
                local v136, v137 = l__CurrentCamera__2:WorldToViewportPoint(l__WorldPosition__20);
                if v137 then
                    v135 = Vector2.new(v136.X, v136.Y);
                    v134.SetDistance(u13(l__Magnitude__21));
                    v134.SetTransparency(1 - math.min(1, (v135 - v57).Magnitude / v58) - 0.2);
                end;
            end;
            v134.SetText(v123.Title);
            v134.SetPosition(UDim2.fromOffset(v135.X, v135.Y));
            if v123.Color then
                v134.SetColor(v123.Color);
            end;
        end;
        for v138 in p55._poi do
            if not u15[v138] then
                p55._poi[v138] = nil;
                v59 = true;
            end;
        end;
        if v91 then
            if not p55._lastUID then
                p55._spottedLoop:Play();
                p55._barProgress = (v88 - v89.Start) / (v89.Finish - v89.Start);
                p55._spotted = true;
                v59 = true;
            end;
            if p55._lastUID ~= v91 then
                p55._progressPerUpdate = (1 - p55._barProgress) / v92;
            end;
            p55._barProgress = p55._barProgress + p55._progressPerUpdate * p56;
            p55._spottedLoop.PlaybackSpeed = 1 + p55._barProgress;
            p55._updateSpotted((math.min(p55._barProgress, 1)));
            p55._lastUID = v91;
        elseif p55._lastUID then
            p55._spottedLoop:Stop();
            p55._lastUID = nil;
            p55._barProgress = 0;
            p55._spotted = false;
            v59 = true;
        end;
        p55._updateFlash(tick() / 10);
        p55._nameTagTween:SetGoal(v82 and 0 or 1);
        p55._squadColor = u16[l__Squad__10] or Color3.fromRGB(134, 255, 58);
        if v59 then
            p55:_update();
        end;
    end;
end;
return u17.new();