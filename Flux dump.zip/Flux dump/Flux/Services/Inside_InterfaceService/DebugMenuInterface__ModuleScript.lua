-- Services.InterfaceService.DebugMenuInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local l__UserInputService__1 = game:GetService("UserInputService");
local v1, _, u2, u3 = shared.import("require", "signal", "Roact", "Enum");
local u4 = v1("DebugService");
local u5 = v1("GameShellProxyService");
local u6 = v1("DebugMenuComponent");
local u7 = v1("InputService");
local u8 = {};
u8.__index = u8;
u4:Toggleable("DebugMenuStatsPaused", false, function(_) --[[ Line: 12 ]] end);
function u8._update(p9, _) --[[ Line: 21 ]]
    -- upvalues: u4 (copy), u7 (copy), u2 (copy), u6 (copy)
    p9._components = u4:GetRegisteredCallbacks();
    local v10 = u7;
    local l___enabled__2 = p9._enabled;
    if l___enabled__2 then
        local v11;
        for _, _ in p9._components do
            v11 = false;
            break;
        end;
        v11 = true;
        l___enabled__2 = not v11;
    end;
    v10.DebugOpen = l___enabled__2;
    p9._handle = u2.update(p9._handle, u2.createElement(u6, {
        Components = p9._components,
        Enabled = p9._enabled
    }));
end;
function u8.new() --[[ Line: 32 ]]
    -- upvalues: u5 (copy), u3 (copy), u4 (copy), u8 (copy), u2 (copy), u6 (copy), l__UserInputService__1 (copy)
    local v12 = u5:CreateProxy(-10, u3.ShellPriority.Default, "DebugMenuInterface");
    local v13 = {
        _enabled = false,
        _components = u4:GetRegisteredCallbacks()
    };
    local u14 = setmetatable(v13, u8);
    if u4:IsEnabled() then
        u14._handle = u2.mount(u2.createElement(u6, {
            Components = u14._components
        }), v12);
        u4.OnRegisteredCallback:Connect(function(p15) --[[ Line: 45 ]]
            -- upvalues: u14 (copy)
            u14:_update(p15);
        end);
        u4.OnUnregisteredCallback:Connect(function() --[[ Line: 48 ]]
            -- upvalues: u14 (copy)
            u14:_update();
        end);
        l__UserInputService__1.InputBegan:Connect(function(p16) --[[ Line: 52 ]]
            -- upvalues: u3 (ref), l__UserInputService__1 (ref), u14 (copy)
            if p16.KeyCode == u3.KeyCode.D and l__UserInputService__1:IsKeyDown(u3.KeyCode.LeftControl) then
                u14._enabled = not u14._enabled;
                u14:_update();
            end;
        end);
    end;
    return u14;
end;
return u8.new();