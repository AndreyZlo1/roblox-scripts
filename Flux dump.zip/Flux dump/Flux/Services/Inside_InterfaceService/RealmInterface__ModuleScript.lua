-- Services.InterfaceService.RealmInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, _, u2, u3 = shared.import("require", "network", "Roact", "Enum");
local u4 = v1("GameShellProxyService");
local u5 = v1("RealmComponent");
local u6 = v1("SoundService");
local u7 = {};
u7.__index = u7;
function u7.new() --[[ Line: 19 ]]
    -- upvalues: u2 (copy), u4 (copy), u3 (copy), u5 (copy), u7 (copy)
    local v8, v9 = u2.createBinding(false);
    local v10 = u4:CreateProxy(9, u3.ShellPriority.AlwaysVisible, "RealmInterface");
    local v11, v12 = u2.createBinding(tick());
    local v13 = {
        Enabled = true,
        CursorEnabled = v8,
        _handle = u2.mount(u2.createElement(u5, {
            UpdateCursorEnabled = v9,
            TickBinding = v11
        }), v10),
        _update = v12
    };
    return setmetatable(v13, u7);
end;
function u7.Display(p14, p15, ...) --[[ Line: 38 ]]
    -- upvalues: u6 (copy), u2 (copy), u5 (copy)
    if p15 then
        p14.Enabled = true;
        u6.DiegeticMix.Realm = 0;
        p14._handle = u2.update(p14._handle, u2.createElement(u5, {
            Display = p15,
            Data = { ... }
        }));
    else
        p14.Enabled = false;
        u6.DiegeticMix.Realm = 1;
        p14._handle = u2.update(p14._handle, u2.createElement(u5, {}));
    end;
end;
function u7.Update(p16, _) --[[ Line: 55 ]]
    if p16.Enabled then
        p16._update(workspace:GetServerTimeNow());
    end;
end;
return u7.new();