-- Services.InterfaceService.TutorialInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4, _ = shared.import("require", "network", "Roact", "Enum", "server");
local u5 = v1("GameShellProxyService");
local u6 = v1("RoactTween");
local u7 = v1("TutorialComponent");
local u8 = v1("InputService");
v1("SoundService");
local u9 = v1({
    "HQTutorial",
    "PVPTutorial",
    "ProneTutorial",
    "WeaponTutorial",
    "FlashlightTutorial",
    "MedicalTutorial",
    "SprintTutorial",
    "ExtractionTutorial",
    "SurvivorTutorial",
    "SurvivorPvPTutorial",
    "SafezonePvPTutorial",
    "ShellLoadingTutorial"
});
local u10 = {};
u10.__index = u10;
function u10._startTutorial(u11, p12) --[[ Line: 37 ]]
    -- upvalues: u3 (copy), u7 (copy), u9 (copy), u4 (copy), u8 (copy), u2 (copy)
    if u11._inTutorial then
    else
        u11._inTutorial = true;
        u11._handle = u3.update(u11._handle, u3.createElement(u7, {}));
        local l___fadeIn__1 = u11._fadeIn;
        local l___bar__2 = u11._bar;
        local _ = u11._text;
        local l___updateText__3 = u11._updateText;
        local l___updateCanSkip__4 = u11._updateCanSkip;
        local l___textTransparency__5 = u11._textTransparency;
        local u13 = false;
        local u14 = u9[p12 .. "Tutorial"];
        local function u26(p15) --[[ Line: 53 ]]
            -- upvalues: u14 (copy), l___updateText__3 (copy), l___textTransparency__5 (copy), l___updateCanSkip__4 (copy), l___bar__2 (copy), u11 (copy), u13 (ref), u4 (ref), u26 (copy)
            local v16 = u14[p15];
            local v17 = typeof(v16);
            if v17 == "string" then
                l___updateText__3("");
                task.wait();
                l___updateText__3(v16);
                l___textTransparency__5:SetGoal(0);
            elseif v17 == "function" then
                l___updateCanSkip__4(false);
                local v18 = true;
                while task.wait() do
                    l___bar__2:SetValue(0);
                    local v19 = v16(u11);
                    if v19 then
                        if typeof(v19) == "string" then
                            l___updateText__3("");
                            task.wait();
                            l___updateText__3(v19);
                            l___textTransparency__5:SetGoal(0);
                            v18 = false;
                        else
                            l___textTransparency__5:SetGoal(1);
                        end;
                        break;
                    end;
                end;
                task.wait(0.3);
                l___updateCanSkip__4(v18);
            else
                local v20 = 2;
                local v21, v22;
                if v17 == "number" then
                    v21 = math.min(v16, v20);
                    v22 = v16;
                else
                    v22 = v16[1];
                    v21 = v16[2];
                end;
                u13 = false;
                l___bar__2:SetGoal(1, TweenInfo.new(v22, u4.EasingStyle.Linear, u4.EasingDirection.Out));
                l___updateCanSkip__4(false);
                local v23 = tick() + v22;
                local v24 = tick() + v21;
                local v25 = false;
                while tick() <= v23 do
                    if (tick() > v23 - 0.3 or u13) and not v25 then
                        v23 = tick() + 0.3;
                        l___textTransparency__5:SetGoal(1);
                        v25 = true;
                    end;
                    if v24 < tick() then
                        l___updateCanSkip__4(true);
                    end;
                    task.wait();
                end;
                l___bar__2:SetValue(0);
                l___bar__2:SetGoal(0);
            end;
            if u14[p15 + 1] then
                u26(p15 + 1);
            end;
        end;
        local v28 = u8:Connect({
            PrimaryActivate = function(p27) --[[ Name: PrimaryActivate, Line 126 ]]
                -- upvalues: u11 (copy), u13 (ref)
                if p27 and u11._canSkip:getValue() then
                    u13 = true;
                end;
            end
        });
        l___fadeIn__1:SetGoal(0);
        u26(1);
        l___fadeIn__1:SetGoal(1);
        l___textTransparency__5:SetGoal(1);
        v28:Disconnect();
        u2:FireServer("FinishTutorial", p12);
        u11._inTutorial = false;
    end;
end;
function u10.new() --[[ Line: 143 ]]
    -- upvalues: u6 (copy), u3 (copy), u5 (copy), u4 (copy), u7 (copy), u10 (copy), u2 (copy)
    local v29 = u6.new(1);
    local v30 = u6.new(0);
    local v31, v32 = u3.createBinding("");
    local v33, v34 = u3.createBinding(true);
    local v35 = u6.new(1);
    local v36, _ = u5:CreateProxy(10, u4.ShellPriority.AlwaysVisible, "TutorialInterface");
    local v37 = {
        Enabled = true,
        UI = v36,
        _handle = u3.mount(u3.createElement(u7, {
            FadeIn = v29,
            Bar = v30,
            Text = v31,
            TextTransparency = v35,
            CanSkip = v33
        }), v36),
        _fadeIn = v29,
        _bar = v30,
        _text = v31,
        _canSkip = v33,
        _updateText = v32,
        _updateCanSkip = v34,
        _textTransparency = v35
    };
    local u38 = setmetatable(v37, u10);
    u2:ConnectEvents({
        InitTutorial = function(p39) --[[ Name: InitTutorial, Line 175 ]]
            -- upvalues: u38 (copy)
            u38:_startTutorial(p39);
        end
    });
    return u38;
end;
return u10.new();