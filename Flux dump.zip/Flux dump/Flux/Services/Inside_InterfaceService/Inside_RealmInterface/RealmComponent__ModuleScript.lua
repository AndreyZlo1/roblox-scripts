-- Services.InterfaceService.RealmInterface.RealmComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u3 = v1({
    "MatchRealmComponent",
    "MissionRealmComponent",
    "MatchFinishRealmComponent",
    "BriefingRealmComponent",
    "MapVoteRealmComponent"
});
local u4 = {
    MapVote = true
};
local v5 = u2.Component:extend("Landing");
function v5.init(p6, p7) --[[ Line: 19 ]]
    p6.UpdateCursorEnabled = p7.UpdateCursorEnabled;
    p6.TickBinding = p7.TickBinding;
end;
function v5.render(p8) --[[ Line: 24 ]]
    -- upvalues: u4 (copy), u2 (copy), u3 (copy)
    local l__props__1 = p8.props;
    local l__Display__2 = l__props__1.Display;
    local l__Data__3 = l__props__1.Data;
    if l__Display__2 then
        if u4[l__Display__2] then
            return u2.createElement(u3[l__Display__2 .. "RealmComponent"], {
                Data = l__Data__3,
                Update = p8.TickBinding,
                UpdateCursorEnabled = p8.UpdateCursorEnabled
            });
        else
            return u2.createElement("VideoFrame", {
                Video = "rbxassetid://17029546675",
                Looped = true,
                Playing = true,
                Size = UDim2.fromScale(1, 1),
                BackgroundColor3 = Color3.new()
            }, u2.createElement(u3[l__Display__2 .. "RealmComponent"], {
                Data = l__Data__3,
                Update = p8.TickBinding,
                UpdateCursorEnabled = p8.UpdateCursorEnabled
            }));
        end;
    else
        p8.UpdateCursorEnabled(false);
    end;
end;
return v5;