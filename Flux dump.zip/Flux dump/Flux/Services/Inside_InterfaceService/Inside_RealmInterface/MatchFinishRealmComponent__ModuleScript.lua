-- Services.InterfaceService.RealmInterface.MatchFinishRealmComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "network");
local u3 = v1("Mathf");
local u4 = v1("RankedIcons");
local u5 = v1("RoactTween");
local u6 = v1("LandingInterface");
local u7 = v1("MatchFinishRankComponent");
local u8 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local v9 = u2.Component:extend("Landing");
function v9.willUnmount(_) --[[ Line: 15 ]] end;
function v9.init(u10, p11) --[[ Line: 19 ]]
    -- upvalues: u6 (copy), u4 (copy), u5 (copy)
    local l__Data__1 = p11.Data;
    u6:Message();
    local v12 = l__Data__1[2];
    local u13 = l__Data__1[3];
    local v14, v15 = u4:GetRankFromElo(v12);
    local v16 = math.floor(v12 / 1000) - 1;
    local u17 = (v16 + 2) * 1000;
    local u18 = v16 * 1000;
    u10._rankIconNew = u4:GetRankFromElo(u13);
    u10._rankIconLower = u4:GetRank(v15 - 1);
    u10._rankIconUpper = u4:GetRank(v15 + 1);
    u10._rankIconCurrent = v14;
    u10.LowerElo = u18;
    u10.UpperElo = u17;
    u10.ExpTween = u5.new((v12 - u18) / (u17 - u18), TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out, 0, false, 0));
    u10.ExpRevealTween = u5.new(0, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out, 0, false, 0));
    u10.Color = l__Data__1[1] and Color3.fromRGB(186, 170, 78) or Color3.fromRGB(186, 78, 78);
    u10.Won = l__Data__1[1];
    u10.MainTween = u5.new(0, TweenInfo.new(5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out, 0, false, 0));
    u10.LeftTween = u5.new(0, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out, 0, false, 0));
    u10.MiddleTween = u5.new(0, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out, 0, false, 0));
    u10.RightTween = u5.new(0, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out, 0, false, 0));
    u10.BarTween = u5.new(0, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out, 0, false, 0));
    u10.EndTween = u5.new(0, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out, 0, false, 0));
    task.delay(1, function() --[[ Line: 55 ]]
        -- upvalues: u10 (copy), u13 (copy), u18 (ref), u17 (copy)
        u10.BarTween:SetGoal(1);
        u10.LeftTween:SetGoal(1);
        task.wait(0.1);
        u10.MiddleTween:SetGoal(1);
        task.wait(0.1);
        u10.RightTween:SetGoal(1);
        task.wait(1);
        u10.ExpRevealTween:SetGoal(1);
        task.wait(1);
        u10.MainTween:SetGoal(1);
        u10.ExpTween:SetGoal((math.min((u13 - u18) / (u17 - u18), 1)));
        task.wait(3);
        u10.ExpRevealTween:SetGoal(0);
        task.wait(1);
        u10.BarTween:SetGoal(0);
        u10.RightTween:SetGoal(0);
        task.wait(0.1);
        u10.MiddleTween:SetGoal(0);
        task.wait(0.1);
        u10.LeftTween:SetGoal(0);
        u10.EndTween:SetGoal(1);
    end);
end;
function v9.render(u19) --[[ Line: 80 ]]
    -- upvalues: u2 (copy), u8 (copy), u3 (copy), u7 (copy)
    local _ = u19.props;
    local l__createFragment__2 = u2.createFragment;
    local v39 = {
        Glow = u2.createElement("Frame", {
            BackgroundTransparency = 0.65,
            BackgroundColor3 = u19.MainTween:Map(function(p20) --[[ Line: 85 ]]
                -- upvalues: u19 (copy)
                return Color3.new(1, 1, 1):Lerp(u19.Color, p20);
            end),
            Position = UDim2.fromScale(0, 0.5),
            Size = UDim2.fromScale(1, 0.5)
        }, { u2.createElement("UIGradient", {
                Rotation = 90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.4, 0.8), NumberSequenceKeypoint.new(1, 0) })
            }) }),
        Result = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextTransparency = 1,
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0.5, 0),
            Position = UDim2.fromScale(0.5, 0.15),
            Size = UDim2.fromScale(0.6, 0.1),
            FontFace = u8,
            Text = "MATCH " .. (u19.Won and "WON" or "LOST"),
            TextXAlignment = Enum.TextXAlignment.Center
        }, { u2.createElement("UIStroke", {
                Thickness = 1,
                ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                Transparency = u19.MainTween:Map(function(p21) --[[ Line: 115 ]]
                    return 1 - p21;
                end),
                Color = u19.MainTween:Map(function(p22) --[[ Line: 118 ]]
                    -- upvalues: u19 (copy)
                    return Color3.new(1, 1, 1):Lerp(u19.Color, p22);
                end)
            }) }),
        Bar = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 2,
            BackgroundColor3 = Color3.new(0, 0, 0),
            BackgroundTransparency = u19.BarTween:Map(function(p23) --[[ Line: 127 ]]
                return 1 - p23;
            end),
            AnchorPoint = Vector2.new(0, 0.5),
            Position = UDim2.fromScale(0.1, 0.8),
            Size = u19.BarTween:Map(function(p24) --[[ Line: 133 ]]
                return UDim2.fromScale(p24 * 0.8, 0.01);
            end)
        }, {
            u2.createElement("UIGradient", {
                Rotation = 0,
                Transparency = u19.BarTween:Map(function(p25) --[[ Line: 139 ]]
                    if p25 <= 0.01 then
                        return NumberSequence.new(1);
                    elseif p25 >= 0.99 then
                        return NumberSequence.new(0);
                    else
                        return NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(p25, (math.clamp(1 - p25, 0.01, 0.99))), NumberSequenceKeypoint.new(1, 1) });
                    end;
                end)
            }),
            ExpBar = u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundTransparency = u19.ExpRevealTween:Map(function(p26) --[[ Line: 155 ]]
                    return 1 - p26;
                end),
                BackgroundColor3 = u19.MainTween:Map(function(p27) --[[ Line: 158 ]]
                    -- upvalues: u19 (copy)
                    return Color3.new(1, 1, 1):Lerp(u19.Color, p27);
                end),
                Position = UDim2.fromScale(0, 0),
                Size = u19.ExpTween:Map(function(p28) --[[ Line: 162 ]]
                    return UDim2.fromScale(p28, 1);
                end)
            }, { u2.createElement("UIGradient", {
                    Rotation = 90,
                    Color = ColorSequence.new(Color3.new(1, 1, 1), Color3.fromRGB(189, 189, 189))
                }) }),
            Exp = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0.5, 1),
                Position = u19.ExpTween:Map(function(p29) --[[ Line: 174 ]]
                    return UDim2.fromScale(p29, -1);
                end),
                Size = UDim2.fromScale(0.3, 2.5),
                FontFace = u8,
                Text = u19.ExpTween:Map(function(p30) --[[ Line: 179 ]]
                    -- upvalues: u3 (ref), u19 (copy)
                    local v31 = u3.Lerp(u19.LowerElo, u19.UpperElo, p30);
                    return math.floor(v31) .. " ELO";
                end),
                TextTransparency = u19.ExpRevealTween:Map(function(p32) --[[ Line: 182 ]]
                    return 1 - p32;
                end),
                TextColor3 = u19.MainTween:Map(function(p33) --[[ Line: 185 ]]
                    -- upvalues: u19 (copy)
                    return Color3.new(1, 1, 1):Lerp(u19.Color, p33);
                end),
                TextXAlignment = Enum.TextXAlignment.Center
            })
        }),
        Left = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 3,
            BackgroundColor3 = Color3.new(1, 1, 1),
            AnchorPoint = Vector2.new(0, 0.5),
            Position = u19.LeftTween:Map(function(p34) --[[ Line: 198 ]]
                return UDim2.fromScale(0.1, 1.1 - p34 * 0.3);
            end),
            Size = UDim2.fromScale(0.003, 0.05)
        }, { u2.createElement("UICorner", {
                CornerRadius = UDim.new(0.5, 0)
            }) }),
        Middle = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 3,
            BackgroundColor3 = u19.ExpTween:Map(function(p35) --[[ Line: 209 ]]
                if p35 >= 0.495 then
                    return Color3.new(1, 1, 1);
                else
                    return Color3.new(0, 0, 0);
                end;
            end),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = u19.MiddleTween:Map(function(p36) --[[ Line: 217 ]]
                return UDim2.fromScale(0.5, 1.1 - p36 * 0.3);
            end),
            Size = UDim2.fromScale(0.003, 0.08)
        }, { u2.createElement("UICorner", {
                CornerRadius = UDim.new(0.5, 0)
            }) }),
        Right = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 3,
            BackgroundColor3 = u19.ExpTween:Map(function(p37) --[[ Line: 228 ]]
                if p37 >= 0.995 then
                    return Color3.new(1, 1, 1);
                else
                    return Color3.new(0, 0, 0);
                end;
            end),
            AnchorPoint = Vector2.new(1, 0.5),
            Position = u19.RightTween:Map(function(p38) --[[ Line: 236 ]]
                return UDim2.fromScale(0.9, 1.1 - p38 * 0.3);
            end),
            Size = UDim2.fromScale(0.003, 0.05)
        }, { u2.createElement("UICorner", {
                CornerRadius = UDim.new(0.5, 0)
            }) }),
        CurrentIcon = u2.createElement(u7, {
            Position = UDim2.fromScale(0.5, 0.5),
            Size = UDim2.fromScale(0.25, 0.25),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Rank = u19._rankIconCurrent,
            Tween = u19.BarTween
        }),
        NewIcon = u2.createElement(u7, {
            Position = UDim2.fromScale(0.5, 0.5),
            Size = UDim2.fromScale(0.4, 0.4),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Rank = u19._rankIconNew,
            Tween = u19.EndTween
        })
    };
    local l___rankIconLower__3 = u19._rankIconLower;
    if l___rankIconLower__3 then
        l___rankIconLower__3 = u2.createElement(u7, {
            Position = UDim2.fromScale(0.1, 0.6),
            Size = UDim2.fromScale(0.15, 0.15),
            AnchorPoint = Vector2.new(0, 0.5),
            Rank = u19._rankIconLower,
            Tween = u19.BarTween
        });
    end;
    v39.LowerIcon = l___rankIconLower__3;
    local l___rankIconUpper__4 = u19._rankIconUpper;
    if l___rankIconUpper__4 then
        l___rankIconUpper__4 = u2.createElement(u7, {
            Position = UDim2.fromScale(0.9, 0.6),
            Size = UDim2.fromScale(0.15, 0.15),
            AnchorPoint = Vector2.new(1, 0.5),
            Rank = u19._rankIconUpper,
            Tween = u19.BarTween
        });
    end;
    v39.UpperIcon = l___rankIconUpper__4;
    return l__createFragment__2(v39);
end;
return v9;