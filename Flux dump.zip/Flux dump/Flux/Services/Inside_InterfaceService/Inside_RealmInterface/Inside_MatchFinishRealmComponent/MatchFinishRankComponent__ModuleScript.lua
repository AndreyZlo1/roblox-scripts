-- Services.InterfaceService.RealmInterface.MatchFinishRealmComponent.MatchFinishRankComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "asset");
v1("Mathf");
v1("RankedIcons");
v1("SoundService");
v1("RoactTween");
v1("LandingInterface");
game:GetService("ContentProvider");
Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local v4 = u2.Component:extend("Landing");
function v4.willUnmount(_) --[[ Line: 17 ]] end;
function v4.init(p5, p6) --[[ Line: 21 ]]
    -- upvalues: u2 (copy), u3 (copy)
    local v7 = Instance.new("Camera");
    v7.FieldOfView = 15;
    v7.CFrame = CFrame.new();
    p5._ref = u2.createRef();
    local v8 = u3:Get("Shared", "Models", "Environment", "Badge").Asset:Clone();
    v8.TextureID = p6.Rank.Icon;
    p5._badge = v8;
    p5._camera = v7;
end;
function v4.didMount(p9) --[[ Line: 34 ]]
    p9._badge.Parent = p9._ref:getValue();
end;
function v4.render(u10) --[[ Line: 38 ]]
    -- upvalues: u2 (copy)
    local l__props__1 = u10.props;
    return u2.createElement("ViewportFrame", {
        Ambient = Color3.new(1, 1, 1),
        LightColor = Color3.new(1, 1, 1),
        LightDirection = Vector3.new(0.5, -1, 0.5),
        ImageTransparency = l__props__1.Tween:Map(function(p11) --[[ Line: 45 ]]
            -- upvalues: u10 (copy)
            u10._badge.CFrame = CFrame.new(0, 0, -15) * CFrame.Angles(-1.5707963267948966, 0, 0) * CFrame.Angles(0, 0, 4 * (1.5707963267948966 * (1 - p11)));
            return 1 - p11;
        end),
        AnchorPoint = l__props__1.AnchorPoint,
        Position = l__props__1.Position,
        Size = l__props__1.Size,
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
        ImageColor3 = Color3.new(1, 1, 1),
        CurrentCamera = u10._camera,
        [u2.Ref] = u10._ref
    });
end;
return v4;