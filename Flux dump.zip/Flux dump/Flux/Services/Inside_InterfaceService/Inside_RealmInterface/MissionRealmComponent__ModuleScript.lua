-- Services.InterfaceService.RealmInterface.MissionRealmComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "network");
local u3 = v1("SoundService");
v1("MenuButtonComponent");
local l__ContentProvider__1 = game:GetService("ContentProvider");
local u4 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u5 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local v6 = u2.Component:extend("Landing");
local function u10(p7, p8) --[[ Line: 13 ]]
    -- upvalues: u2 (copy), u4 (copy), u5 (copy)
    local v9 = p7[4];
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 0.2),
        LayoutOrder = p8
    }, {
        u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Size = UDim2.new(1, 0, 1, 0),
            Position = UDim2.new(0, 0, 0, 0),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            Image = "rbxthumb://type=AvatarHeadShot&id=" .. p7[1] .. "&w=150&h=150",
            AnchorPoint = Vector2.new(0, 0),
            ImageColor3 = v9 == 0 and Color3.new(0, 0, 0) or Color3.new(1, 1, 1),
            ImageTransparency = (v9 == 1 or v9 == 2) and 0.5 or 0
        }),
        u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            Size = UDim2.fromScale(1, 0.4),
            Position = UDim2.fromScale(0.25, 0.15),
            AnchorPoint = Vector2.new(0, 0),
            Text = p7[2],
            TextColor3 = v9 == 0 and Color3.new(0, 0, 0) or Color3.new(1, 1, 1),
            TextTransparency = (v9 == 1 or v9 == 2) and 0.5 or 0,
            TextXAlignment = Enum.TextXAlignment.Left,
            FontFace = u4
        }),
        u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            Size = UDim2.fromScale(1, 0.3),
            Position = UDim2.fromScale(0.25, 0.55),
            AnchorPoint = Vector2.new(0, 0),
            Text = p7[3],
            TextColor3 = v9 == 0 and Color3.new(0, 0, 0) or Color3.new(1, 1, 1),
            TextTransparency = (v9 == 1 or v9 == 2) and 0.5 or 0,
            TextXAlignment = Enum.TextXAlignment.Left,
            FontFace = u5
        }),
        u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextTransparency = 0,
            TextScaled = true,
            Size = UDim2.fromScale(1, 0.3),
            Position = UDim2.fromScale(-0.1, 0.5),
            AnchorPoint = Vector2.new(1, 0.5),
            Text = v9 == 0 and "DISCONNECTED" or (v9 == 1 and "CONNECTING TO SERVER" or (v9 == 2 and "DOWNLOADING ASSETS" or "")),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = Enum.TextXAlignment.Right,
            FontFace = u5
        })
    });
end;
function v6.willUnmount(p11) --[[ Line: 69 ]]
    p11._music.FadeOut();
    p11._click:Destroy();
end;
function v6.init(p12, _) --[[ Line: 74 ]]
    -- upvalues: u3 (copy), l__ContentProvider__1 (copy)
    p12._click = u3:CreateSound("Button", nil, false, "UISounds", "MatchCounter").Sound;
    p12._music = u3:CreateSound("Music", nil, true, "Music", "MatchRealm");
    local v13 = Instance.new("Decal");
    v13.Texture = "rbxassetid://17029819151";
    task.spawn(l__ContentProvider__1.PreloadAsync, l__ContentProvider__1, { v13 });
end;
function v6.render(u14) --[[ Line: 85 ]]
    -- upvalues: u10 (copy), u2 (copy), u4 (copy), u5 (copy)
    local l__props__2 = u14.props;
    local l__Update__3 = l__props__2.Update;
    local v15, u16 = unpack(l__props__2.Data);
    local v17 = {};
    if v15 then
        for v18, v19 in v15 do
            v17[v18] = u10(v19, v18);
        end;
    end;
    local l__createFragment__4 = u2.createFragment;
    local v20 = {};
    local v21 = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextTransparency = 0.5,
        TextScaled = true,
        Size = UDim2.fromScale(1, 0.025),
        Position = UDim2.fromScale(0, 0.17),
        AnchorPoint = Vector2.new(0, 0),
        Text = u16 and "MISSION STARTING" or (v15 and "WAITING FOR PLAYERS" or "WAITING FOR HOST TO START MATCH"),
        TextColor3 = Color3.new(1, 1, 1),
        FontFace = u4
    });
    if u16 then
        u16 = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            Size = UDim2.fromScale(1, 0.05),
            Position = UDim2.fromScale(0, 0.26),
            AnchorPoint = Vector2.new(0, 0),
            Text = l__Update__3:map(function(p22) --[[ Line: 114 ]]
                -- upvalues: u16 (copy), u14 (copy)
                local v23 = math.floor(u16 - p22);
                local v24 = math.max(0, v23);
                if u14._lastCounter == nil then
                    u14._lastCounter = v24;
                    return v24;
                else
                    if u14._lastCounter ~= v24 then
                        u14._lastCounter = v24;
                        u14._click:Play();
                    end;
                    return v24;
                end;
            end),
            TextColor3 = Color3.new(1, 1, 1),
            FontFace = u5
        }, { u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://17029819151",
                Size = UDim2.new(1.8, 0, 1.8, 0),
                Position = UDim2.new(0.5, 0, 0.5, 0),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Rotation = l__Update__3:map(function(p25) --[[ Line: 135 ]]
                    -- upvalues: u16 (copy)
                    return u16 < p25 and 0 or math.sin(p25 * 3.141592653589793 % 3.141592653589793 / 2) * 360;
                end)
            }) });
    end;
    v20[1], v20[2], v20[3] = v21, u16, u2.createElement("Frame", {
    BackgroundTransparency = 1,
    Size = UDim2.fromScale(0.3, 0.3),
    Position = UDim2.fromScale(0.5, 0.35),
    AnchorPoint = Vector2.new(0.5, 0),
    SizeConstraint = Enum.SizeConstraint.RelativeYY
}, { u2.createElement("UIListLayout", {
        FillDirection = Enum.FillDirection.Vertical,
        Padding = UDim.new(0.05, 0)
    }), u2.createFragment(v17) });
    return l__createFragment__4(v20);
end;
return v6;