-- Services.InterfaceService.RealmInterface.MatchRealmComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Roact", "network", "server");
local u5 = v1("SoundService");
local u6 = v1("MenuButtonComponent");
local l__ContentProvider__1 = game:GetService("ContentProvider");
game:GetService("HttpService");
local l__RunService__2 = game:GetService("RunService");
local u7 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u8 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local v9 = u2.Component:extend("Landing");
local function u24(u10, p11, u12, p13, u14) --[[ Line: 15 ]]
    -- upvalues: u2 (copy), u7 (copy), u8 (copy), u6 (copy), u3 (copy)
    local v15 = u10[4];
    local l__createElement__3 = u2.createElement;
    local v16 = "Frame";
    local v17 = {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 0.2),
        LayoutOrder = p11
    };
    local v18 = {};
    local v19 = u2.createElement("ImageLabel", {
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 1, 0),
        Position = UDim2.new(u12 and 1 or 0, 0, 0, 0),
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        Image = "rbxthumb://type=AvatarHeadShot&id=" .. u10[1] .. "&w=150&h=150",
        AnchorPoint = Vector2.new(u12 and 1 or 0, 0),
        ImageColor3 = v15 == 0 and Color3.new(0, 0, 0) or Color3.new(1, 1, 1),
        ImageTransparency = (v15 == 1 or v15 == 2) and 0.5 or 0
    });
    local v20 = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        Size = UDim2.fromScale(1, 0.4),
        Position = UDim2.fromScale(u12 and 0.75 or 0.25, 0.15),
        AnchorPoint = Vector2.new(u12 and 1 or 0, 0),
        Text = u10[2],
        TextColor3 = v15 == 0 and Color3.new(0, 0, 0) or Color3.new(1, 1, 1),
        TextTransparency = (v15 == 1 or v15 == 2) and 0.5 or 0,
        TextXAlignment = u12 and Enum.TextXAlignment.Right or Enum.TextXAlignment.Left,
        FontFace = u7
    });
    local v21 = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        Size = UDim2.fromScale(1, 0.3),
        Position = UDim2.fromScale(u12 and 0.75 or 0.25, 0.55),
        AnchorPoint = Vector2.new(u12 and 1 or 0, 0),
        Text = u10[3],
        TextColor3 = v15 == 0 and Color3.new(0, 0, 0) or Color3.new(1, 1, 1),
        TextTransparency = (v15 == 1 or v15 == 2) and 0.5 or 0,
        TextXAlignment = u12 and Enum.TextXAlignment.Right or Enum.TextXAlignment.Left,
        FontFace = u8
    });
    local v22 = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextTransparency = 0,
        TextScaled = true,
        Size = UDim2.fromScale(1, 0.3),
        Position = UDim2.fromScale(u12 and 1.1 or -0.1, 0.5),
        AnchorPoint = Vector2.new(u12 and 0 or 1, 0.5),
        Text = v15 == 0 and "DISCONNECTED" or (v15 == 1 and "CONNECTING TO SERVER" or (v15 == 2 and "DOWNLOADING ASSETS" or "")),
        TextColor3 = Color3.new(1, 1, 1),
        TextXAlignment = u12 and Enum.TextXAlignment.Left or Enum.TextXAlignment.Right,
        FontFace = u8
    });
    local v23;
    if p13 then
        v23 = u2.createElement(u6, {
            Ignore = false,
            Activated = false,
            Name = u14 and "ADD" or "SWITCH",
            Size = UDim2.fromScale(0.2, 0.4),
            Position = UDim2.fromScale(u12 and 0.1 or 0.9, 0.05),
            AnchorPoint = Vector2.new(u12 and 1, 0),
            Callback = function() --[[ Name: Callback, Line 75 ]]
                -- upvalues: u3 (ref), u10 (copy), u14 (copy), u12 (copy)
                u3:FireServer("SwitchTeam", u10[1], (u14 or u12) and 1 or 2);
            end
        });
    else
        v23 = p13;
    end;
    if p13 then
        p13 = u2.createElement(u6, {
            Ignore = false,
            Activated = false,
            Name = u14 and "KICK" or "SPECTATE",
            Size = UDim2.fromScale(0.2, 0.4),
            Position = UDim2.fromScale(u12 and 0.1 or 0.9, 0.55),
            AnchorPoint = Vector2.new(u12 and 1, 0),
            Callback = function() --[[ Name: Callback, Line 86 ]]
                -- upvalues: u3 (ref), u10 (copy), u14 (copy)
                u3:FireServer("SwitchTeam", u10[1], u14 and 4 or 3);
            end
        });
    end;
    v18[1], v18[2], v18[3], v18[4], v18[5], v18[6] = v19, v20, v21, v22, v23, p13;
    return l__createElement__3(v16, v17, v18);
end;
function v9.willUnmount(p25) --[[ Line: 93 ]]
    p25._music.FadeOut();
    p25._click:Destroy();
    p25._conn:Disconnect();
end;
function v9.init(u26, _) --[[ Line: 99 ]]
    -- upvalues: u5 (copy), l__ContentProvider__1 (copy), u2 (copy), l__RunService__2 (copy), u4 (copy)
    u26._click = u5:CreateSound("Button", nil, false, "UISounds", "MatchCounter").Sound;
    u26._music = u5:CreateSound("Music", nil, true, "Music", "MatchRealm");
    local v27 = Instance.new("Decal");
    v27.Texture = "rbxassetid://17029819151";
    task.spawn(l__ContentProvider__1.PreloadAsync, l__ContentProvider__1, { v27 });
    local v28, u29 = u2.createBinding(0);
    u26._conn = l__RunService__2.Heartbeat:Connect(function() --[[ Line: 110 ]]
        -- upvalues: u4 (ref), u26 (copy), u29 (copy)
        if u4.WORLD_LOADING or not u26.state.Loading then
            if u4.WORLD_LOADING and not u26.state.Loading then
                u26:setState({
                    Loading = true
                });
            end;
        else
            u26:setState({
                Loading = false
            });
        end;
        if u4.WORLD_LOADING then
            u29(u4.WORLD_LOADING);
        end;
    end);
    u26._loading = v28;
    u26:setState({
        Loading = u4.WORLD_LOADING
    });
end;
function v9.render(u30) --[[ Line: 132 ]]
    -- upvalues: u24 (copy), u2 (copy), u7 (copy), u8 (copy), u6 (copy), u3 (copy)
    local l__props__4 = u30.props;
    local u31, v32, v33, v34 = unpack(l__props__4.Data);
    local l__Update__5 = l__props__4.Update;
    local l__Loading__6 = u30.state.Loading;
    if u31 ~= nil then
        v33 = false;
    end;
    l__props__4.UpdateCursorEnabled(v33);
    local v35 = {};
    for v36, v37 in v32[1] do
        v35[v36] = u24(v37, v36, false, v33);
    end;
    local v38 = {};
    for v39, v40 in v32[2] do
        v38[v39] = u24(v40, v39, true, v33);
    end;
    local v41 = {};
    for v42, v43 in v32[3] do
        v41[v42] = u24(v43, v42, false, v33, true);
    end;
    if not u31 then
        u30._lastCounter = nil;
    end;
    local l__createFragment__7 = u2.createFragment;
    local v44 = {};
    if v34 then
        v34 = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.fromRGB(231, 202, 60),
            AnchorPoint = Vector2.new(0.5, 0),
            Size = UDim2.fromScale(0.3, 0.06),
            Position = UDim2.fromScale(0.5, 0.05),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }, {
            Corner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 1)
            }),
            Gradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(234, 234, 234)), ColorSequenceKeypoint.new(1, Color3.fromRGB(206, 206, 206)) })
            }),
            Stroke = u2.createElement("UIStroke", {
                Thickness = 1,
                ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                Color = Color3.fromRGB(118, 101, 40),
                LineJoinMode = Enum.LineJoinMode.Round
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "THIS IS A RANKED MATCH",
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.45),
                Position = UDim2.fromScale(0, 0.1),
                TextColor3 = Color3.new(),
                FontFace = u7
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "LEAVING WILL RESULT IN A SUSPENSION",
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.3),
                Position = UDim2.fromScale(0, 0.6),
                TextColor3 = Color3.new(),
                FontFace = u7
            })
        });
    end;
    local v45;
    if l__Loading__6 then
        v45 = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.fromRGB(231, 202, 60),
            AnchorPoint = Vector2.new(0.5, 0),
            Size = UDim2.fromScale(0.3, 0.06),
            Position = UDim2.fromScale(0.5, 0.05),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }, {
            Corner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0, 1)
            }),
            Gradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(234, 234, 234)), ColorSequenceKeypoint.new(1, Color3.fromRGB(206, 206, 206)) })
            }),
            Stroke = u2.createElement("UIStroke", {
                Thickness = 1,
                ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                Color = Color3.fromRGB(118, 101, 40),
                LineJoinMode = Enum.LineJoinMode.Round
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "MAP IS CURRENTLY LOADING",
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.45),
                Position = UDim2.fromScale(0, 0.1),
                TextColor3 = Color3.new(),
                FontFace = u7
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.3),
                Position = UDim2.fromScale(0, 0.6),
                Text = u30._loading:map(function(p46) --[[ Line: 240 ]]
                    return "THIS MAY TAKE A FEW MINUTES (" .. math.floor(p46 * 100) .. "%)";
                end),
                TextColor3 = Color3.new(),
                FontFace = u7
            })
        });
    else
        v45 = l__Loading__6;
    end;
    local v47 = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextTransparency = 0.5,
        TextScaled = true,
        Size = UDim2.fromScale(1, 0.025),
        Position = UDim2.fromScale(0, 0.17),
        AnchorPoint = Vector2.new(0, 0),
        Text = u31 and "MATCH WILL AUTOMATICALLY START IN" or "WAITING FOR HOST TO START MATCH",
        TextColor3 = Color3.new(1, 1, 1),
        FontFace = u7
    });
    local v48;
    if #v32[3] > 0 then
        v48 = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "SPECTATING",
            TextTransparency = 0.5,
            TextScaled = true,
            Size = UDim2.fromScale(0.3, 0.025),
            Position = UDim2.fromScale(0.05, 0.3),
            AnchorPoint = Vector2.new(0, 0),
            TextColor3 = Color3.new(1, 1, 1),
            FontFace = u7,
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        });
    else
        v48 = false;
    end;
    local v49 = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        Text = "DEFENDING FIRST",
        TextTransparency = 0.5,
        TextScaled = true,
        Size = UDim2.fromScale(0.3, 0.025),
        Position = UDim2.fromScale(0.45, 0.3),
        AnchorPoint = Vector2.new(1, 0),
        TextColor3 = Color3.new(1, 1, 1),
        FontFace = u7,
        SizeConstraint = Enum.SizeConstraint.RelativeYY
    });
    local v50 = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        Text = "ATTACKING FIRST",
        TextTransparency = 0.5,
        TextScaled = true,
        Size = UDim2.fromScale(0.3, 0.025),
        Position = UDim2.fromScale(0.55, 0.3),
        AnchorPoint = Vector2.new(0, 0),
        TextColor3 = Color3.new(1, 1, 1),
        FontFace = u7,
        SizeConstraint = Enum.SizeConstraint.RelativeYY
    });
    local v51 = u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(0.3, 0.3),
        Position = UDim2.fromScale(0.05, 0.35),
        AnchorPoint = Vector2.new(0, 0),
        SizeConstraint = Enum.SizeConstraint.RelativeYY
    }, { u2.createElement("UIListLayout", {
            FillDirection = Enum.FillDirection.Vertical,
            Padding = UDim.new(0.05, 0)
        }), u2.createFragment(v41) });
    local v52 = u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(0.3, 0.3),
        Position = UDim2.fromScale(0.45, 0.35),
        AnchorPoint = Vector2.new(1, 0),
        SizeConstraint = Enum.SizeConstraint.RelativeYY
    }, { u2.createElement("UIListLayout", {
            FillDirection = Enum.FillDirection.Vertical,
            Padding = UDim.new(0.05, 0)
        }), u2.createFragment(v35) });
    local v53 = u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(0.3, 0.3),
        Position = UDim2.fromScale(0.55, 0.35),
        AnchorPoint = Vector2.new(0, 0),
        SizeConstraint = Enum.SizeConstraint.RelativeYY
    }, { u2.createElement("UIListLayout", {
            FillDirection = Enum.FillDirection.Vertical,
            Padding = UDim.new(0.05, 0)
        }), u2.createFragment(v38) });
    if u31 then
        u31 = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            Size = UDim2.fromScale(1, 0.05),
            Position = UDim2.fromScale(0, 0.26),
            AnchorPoint = Vector2.new(0, 0),
            Text = l__Update__5:map(function(p54) --[[ Line: 339 ]]
                -- upvalues: u31 (copy), u30 (copy)
                local v55 = math.floor(u31 - p54);
                local v56 = math.max(0, v55);
                if u30._lastCounter == nil then
                    u30._lastCounter = v56;
                    return v56;
                else
                    if u30._lastCounter ~= v56 then
                        u30._lastCounter = v56;
                        u30._click:Play();
                    end;
                    return v56;
                end;
            end),
            TextColor3 = Color3.new(1, 1, 1),
            FontFace = u8
        }, { u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://17029819151",
                Size = UDim2.new(1.8, 0, 1.8, 0),
                Position = UDim2.new(0.5, 0, 0.5, 0),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Rotation = l__Update__5:map(function(p57) --[[ Line: 360 ]]
                    -- upvalues: u31 (copy)
                    return u31 < p57 and 0 or math.sin(p57 * 3.141592653589793 % 3.141592653589793 / 2) * 360;
                end)
            }) });
    end;
    local v58 = v33 and not l__Loading__6;
    if v58 then
        v58 = u2.createElement(u6, {
            Name = "START MATCH",
            Ignore = false,
            Activated = false,
            Size = UDim2.fromScale(0.3, 0.03),
            Position = UDim2.fromScale(0.5, 0.21),
            AnchorPoint = Vector2.new(0.5, 0),
            Callback = function() --[[ Name: Callback, Line 375 ]]
                -- upvalues: u3 (ref)
                u3:FireServer("StartMatch");
            end,
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        });
    end;
    v44[1], v44[2], v44[3], v44[4], v44[5], v44[6], v44[7], v44[8], v44[9], v44[10], v44[11] = v34, v45, v47, v48, v49, v50, v51, v52, v53, u31, v58;
    return l__createFragment__7(v44);
end;
return v9;