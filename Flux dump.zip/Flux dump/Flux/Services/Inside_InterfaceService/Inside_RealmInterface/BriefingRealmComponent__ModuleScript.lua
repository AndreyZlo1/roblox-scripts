-- Services.InterfaceService.RealmInterface.BriefingRealmComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _ = shared.import("require", "Roact", "network");
local u3 = v1("RoactTween");
local u4 = v1("SoundService");
v1("MenuButtonComponent");
game:GetService("ContentProvider");
Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u5 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local v6 = u2.Component:extend("Landing");
function v6.willUnmount(p7) --[[ Line: 15 ]]
    if p7._nextEvent then
        task.cancel(p7._nextEvent);
        p7._nextEvent = nil;
    end;
end;
function v6.init(u8, p9) --[[ Line: 22 ]]
    -- upvalues: u4 (copy), u3 (copy)
    local v10, u11 = unpack(p9.Data);
    u8._music = u4:CreateSound("Music", nil, true, unpack(v10));
    local function u21(u12) --[[ Line: 26 ]]
        -- upvalues: u11 (copy), u3 (ref), u8 (copy), u21 (copy)
        local u13 = {};
        for v14, v15 in u11[u12] do
            u13[v14] = { v15[1], v15[2], u3.new(1) };
        end;
        u8:setState({
            Lines = u13
        });
        local function u18(u16) --[[ Line: 39 ]]
            -- upvalues: u13 (copy), u8 (ref), u18 (copy), u11 (ref), u12 (copy), u21 (ref)
            u13[u16][3]:SetGoal(0);
            u8._nextEvent = task.delay(u13[u16][2] - 0.5, function() --[[ Line: 41 ]]
                -- upvalues: u13 (ref), u16 (copy), u8 (ref), u18 (ref), u11 (ref), u12 (ref), u21 (ref)
                if u13[u16 + 1] then
                    u8._nextEvent = task.delay(0.5, u18, u16 + 1);
                else
                    if u11[u12 + 1] then
                        u8._nextEvent = task.delay(0.5, u21, u12 + 1);
                    end;
                    for _, v17 in u13 do
                        v17[3]:SetGoal(1);
                    end;
                end;
            end);
        end;
        u13[1][3]:SetGoal(0);
        local u19 = 1;
        u8._nextEvent = task.delay(u13[1][2] - 0.5, function() --[[ Line: 41 ]]
            -- upvalues: u13 (copy), u19 (copy), u8 (ref), u18 (copy), u11 (ref), u12 (copy), u21 (ref)
            if u13[u19 + 1] then
                u8._nextEvent = task.delay(0.5, u18, u19 + 1);
            else
                if u11[u12 + 1] then
                    u8._nextEvent = task.delay(0.5, u21, u12 + 1);
                end;
                for _, v20 in u13 do
                    v20[3]:SetGoal(1);
                end;
            end;
        end);
    end;
    u21(1);
end;
function v6.render(p22) --[[ Line: 60 ]]
    -- upvalues: u2 (copy), u5 (copy)
    local v23 = {};
    for v24, v25 in p22.state.Lines do
        v23[v24] = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            RichText = true,
            Size = UDim2.fromScale(1, 0.025),
            LayoutOrder = v24,
            TextColor3 = Color3.new(1, 1, 1),
            FontFace = u5,
            Text = v25[1],
            TextTransparency = v25[3]:Map(function(p26) --[[ Line: 72 ]]
                return p26;
            end)
        });
    end;
    return u2.createElement("Frame", {
        Size = UDim2.fromScale(1, 1),
        BackgroundColor3 = Color3.new()
    }, { u2.createElement("UIListLayout", {
            Padding = UDim.new(0, 0),
            FillDirection = Enum.FillDirection.Vertical,
            HorizontalAlignment = Enum.HorizontalAlignment.Center,
            SortOrder = Enum.SortOrder.LayoutOrder,
            VerticalAlignment = Enum.VerticalAlignment.Center
        }), u2.createFragment(v23) });
end;
return v6;