-- Services.InterfaceService.RealmInterface.MapVoteRealmComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Roact", "network", "server");
local u5 = v1("MenuGamemodeCardComponent");
local u6 = v1("SandboxMaps");
Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local v7 = u2.Component:extend("Landing");
function v7.init(u8, p9) --[[ Line: 11 ]]
    -- upvalues: u4 (copy)
    p9.UpdateCursorEnabled(true);
    u8._serverChanged = u4.Changed:Connect(function() --[[ Line: 14 ]]
        -- upvalues: u8 (copy)
        u8:setState({});
    end);
    u8:setState({
        Voted = false
    });
end;
function v7.willUnmount(p10) --[[ Line: 23 ]]
    p10._serverChanged:Disconnect();
end;
function v7.render(u11) --[[ Line: 27 ]]
    -- upvalues: u4 (copy), u6 (copy), u2 (copy), u5 (copy), u3 (copy)
    local v12 = unpack(u11.props.Data);
    local l__VOTE_OPTIONS__1 = u4.VOTE_OPTIONS;
    local v13 = {};
    for u14, v15 in v12 do
        local v16 = u6.Maps[v15[1]];
        v13[u14] = u2.createElement(u5, {
            ButtonText = "VOTE",
            Ignore = u11.state.Voted,
            Name = v16.Name .. " (" .. l__VOTE_OPTIONS__1[u14] .. ")",
            Image = v16.Image,
            HoverImage = v16.Image,
            Players = v15[2],
            Banner = u11.state.Voted == u14 and "VOTED" or false,
            Callback = function() --[[ Name: Callback, Line 44 ]]
                -- upvalues: u3 (ref), u14 (copy), u11 (copy)
                u3:FireServer("MapVote", u14);
                u11:setState({
                    Voted = u14
                });
            end,
            LayoutOrder = u14
        });
    end;
    return u2.createFragment({ u2.createElement("Frame", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = UDim2.fromScale(0, 0.5)
        }, {
            Aspect = u2.createElement("UIAspectRatioConstraint", {
                AspectRatio = 2,
                AspectType = Enum.AspectType.ScaleWithParentSize,
                DominantAxis = Enum.DominantAxis.Height
            }),
            List = u2.createElement("UIListLayout", {
                Padding = UDim.new(0.01, 0),
                FillDirection = Enum.FillDirection.Horizontal,
                HorizontalAlignment = Enum.HorizontalAlignment.Center,
                SortOrder = Enum.SortOrder.LayoutOrder,
                VerticalAlignment = Enum.VerticalAlignment.Top
            }),
            u2.createFragment(v13)
        }) });
end;
return v7;