-- Services.InterfaceService.ControlInterface.KeyComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local u1, _ = shared.import("Roact", "require");
local l__TextService__1 = game:GetService("TextService");
local l__UserInputService__2 = game:GetService("UserInputService");
local u2 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u3 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u4 = {
    Slash = "/",
    RightBracket = "]",
    LeftBracket = "[",
    BackSlash = "\\",
    MouseButton1 = "Left Click",
    MouseButton2 = "Right Click"
};
local v5 = u1.PureComponent:extend("Key");
function v5.init(u6) --[[ Line: 21 ]]
    -- upvalues: l__TextService__1 (copy)
    local u7 = {};
    function u6.getTextBounds(u8, u9) --[[ Line: 24 ]]
        -- upvalues: u7 (copy), l__TextService__1 (ref), u6 (copy)
        if u7[u8] == u9.Text then
        else
            u7[u8] = u9.Text;
            task.defer(function() --[[ Line: 30 ]]
                -- upvalues: l__TextService__1 (ref), u9 (copy), u6 (ref), u8 (copy)
                u6:setState({
                    [u8] = l__TextService__1:GetTextBoundsAsync(u9)
                });
            end);
        end;
    end;
end;
function v5.render(p10) --[[ Line: 39 ]]
    -- upvalues: u3 (copy), l__UserInputService__2 (copy), u1 (copy), u4 (copy), u2 (copy)
    local l__state__3 = p10.state;
    local l__props__4 = p10.props;
    local l__UsingGamepad__5 = l__props__4.UsingGamepad;
    local l__Gamepad__6 = l__props__4.Gamepad;
    local l__Key__7 = l__props__4.Key;
    local v11 = l__props__4.Description:upper();
    local l__ViewPort__8 = l__props__4.ViewPort;
    local l__Order__9 = l__props__4.Order;
    local l__Binding__10 = l__props__4.Binding;
    local v12 = l__ViewPort__8.Y * 0.01;
    if l__Key__7 then
        local v13 = Instance.new("GetTextBoundsParams");
        v13.Text = v11;
        v13.Font = u3;
        v13.Size = math.floor(l__ViewPort__8.Y * 0.02);
        v13.Width = (1 / 0);
        p10.getTextBounds("Description", v13);
        local v14 = v12 + (l__state__3.Description or Vector2.new()).X;
        local v15, v16;
        if l__UsingGamepad__5 then
            if not (l__Gamepad__6 and p10.props.VisibleOnGamepad) then
                return;
            end;
            local v17 = l__UserInputService__2:GetImageForKeyCode(l__Gamepad__6);
            v15 = u1.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Size = UDim2.new(1, 0, 1, 0),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                Image = v17,
                ScaleType = Enum.ScaleType.Fit,
                ImageColor3 = (p10.props.Down and Color3.fromRGB(255, 194, 89) or Color3.new(1, 1, 1)):Lerp(Color3.new(), 0.2)
            });
            v16 = v14 + l__ViewPort__8.Y * 0.02;
        else
            if not p10.props.VisibleOnKeyboard then
                return;
            end;
            local v18 = (u4[l__Key__7.Name] or l__Key__7.Name):upper();
            local v19 = Instance.new("GetTextBoundsParams");
            v19.Text = v18;
            v19.Font = u2;
            v19.Size = math.floor(l__ViewPort__8.Y * 0.02 * 0.8);
            v19.Width = (1 / 0);
            p10.getTextBounds("Key", v19);
            local v20 = (l__state__3.Key or Vector2.new()).X + l__ViewPort__8.Y * 0.02 * 0.6;
            v16 = v14 + v20;
            local v21 = p10.props.Down and Color3.new(1, 1, 1) or Color3.fromRGB(105, 105, 105);
            local l__createElement__11 = u1.createElement;
            local v22 = "ImageLabel";
            local v24 = {
                Image = "rbxassetid://13867926930",
                BorderSizePixel = 0,
                TileSize = UDim2.fromOffset(64, 64),
                ScaleType = Enum.ScaleType.Tile,
                Size = UDim2.new(v20 / v16, 0, 1, 0),
                ImageColor3 = l__Binding__10 and l__Binding__10:map(function(p23) --[[ Line: 103 ]]
                    return (p23 and Color3.fromRGB(107, 213, 95) or Color3.fromRGB(213, 92, 92)):Lerp(Color3.new(), 0.2);
                end) or v21:Lerp(Color3.new(), 0.2)
            };
            local v25 = {
                Corner = u1.createElement("UICorner", {
                    CornerRadius = UDim.new(0, 1)
                }),
                Gradient = u1.createElement("UIGradient", {
                    Rotation = -90,
                    Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(112, 112, 112)), ColorSequenceKeypoint.new(1, Color3.fromRGB(54, 54, 54)) })
                })
            };
            local l__createElement__12 = u1.createElement;
            local v26 = "UIStroke";
            local v27 = {
                Thickness = 1,
                ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual
            };
            local v28;
            if l__Binding__10 then
                v28 = l__Binding__10:map(function(p29) --[[ Line: 119 ]]
                    return p29 and Color3.fromRGB(107, 213, 95) or Color3.fromRGB(213, 92, 92);
                end) or v21;
            else
                v28 = v21;
            end;
            v27.Color = v28;
            v27.LineJoinMode = Enum.LineJoinMode.Round;
            v25.Stroke = l__createElement__12(v26, v27);
            local l__createElement__13 = u1.createElement;
            local v30 = "TextLabel";
            local v31 = {
                BackgroundTransparency = 1,
                TextScaled = true,
                Size = UDim2.fromScale(1, 0.8),
                Position = UDim2.fromScale(0, 0.18),
                Text = v18
            };
            if l__Binding__10 then
                v21 = l__Binding__10:map(function(p32) --[[ Line: 130 ]]
                    return p32 and Color3.fromRGB(107, 213, 95) or Color3.fromRGB(213, 92, 92);
                end) or v21;
            end;
            v31.TextColor3 = v21;
            v31.FontFace = u2;
            v25.Label = l__createElement__13(v30, v31);
            v15 = l__createElement__11(v22, v24, v25);
        end;
        return u1.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.new(v16 / (l__ViewPort__8.Y * 1.778), 0, 1, 0),
            Position = p10.props.Position,
            AnchorPoint = p10.props.AnchorPoint,
            LayoutOrder = -l__Order__9
        }, {
            Name = u1.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextTransparency = 0.7,
                TextScaled = true,
                AutoLocalize = false,
                Size = UDim2.fromScale(1, 1),
                Position = UDim2.fromScale(0, 0.1),
                FontFace = u3,
                Text = v11,
                TextColor3 = Color3.new(0, 0, 0),
                TextXAlignment = Enum.TextXAlignment.Right
            }, {
                White = u1.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextTransparency = 0.5,
                    TextScaled = true,
                    AutoLocalize = false,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.new(0, 0, 0, -1),
                    Size = UDim2.new(1, 0, 1, 0),
                    FontFace = u3,
                    Text = v11,
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = Enum.TextXAlignment.Right
                })
            }),
            Img = v15
        });
    end;
end;
return v5;