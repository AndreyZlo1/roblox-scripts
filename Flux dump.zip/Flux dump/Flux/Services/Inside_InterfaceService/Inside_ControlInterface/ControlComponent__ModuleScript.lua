-- Services.InterfaceService.ControlInterface.ControlComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local l__CurrentCamera__1 = workspace.CurrentCamera;
local u3 = v1("InputService");
local u4 = v1("TouchButtonComponent");
local u5 = v1("KeyComponent");
local v6 = u2.Component:extend("Control");
function v6.render(p7) --[[ Line: 12 ]]
    -- upvalues: l__CurrentCamera__1 (copy), u2 (copy), u4 (copy), u3 (copy), u5 (copy)
    if p7.props.Enabled then
        local l__ViewportSize__2 = l__CurrentCamera__1.ViewportSize;
        local l__Binds__3 = p7.props.Binds;
        local l__Gamepad__4 = p7.props.Gamepad;
        local l__Touch__5 = p7.props.Touch;
        local v8 = {};
        local v9 = {};
        for u10, v11 in l__Binds__3 do
            if l__Touch__5 then
                local l__TouchButton__6 = v11.TouchButton;
                if l__TouchButton__6 then
                    v8[u10] = u2.createElement(u4, {
                        Size = l__TouchButton__6.Size,
                        Position = l__TouchButton__6.Position,
                        AnchorPoint = l__TouchButton__6.AnchorPoint,
                        Image = l__TouchButton__6.Image,
                        Down = function() --[[ Name: Down, Line 36 ]]
                            -- upvalues: u3 (ref), u10 (copy)
                            u3:TouchBind(u10, true);
                        end,
                        Up = function() --[[ Name: Up, Line 39 ]]
                            -- upvalues: u3 (ref), u10 (copy)
                            u3:TouchBind(u10, false);
                        end
                    });
                end;
            else
                v9[u10] = u2.createElement(u5, {
                    UsingGamepad = l__Gamepad__4,
                    Down = v11.Down,
                    Key = v11.Key,
                    Gamepad = v11.Gamepad,
                    Description = v11.Description,
                    Order = v11.Order,
                    VisibleOnKeyboard = v11.VisibleOnKeyboard,
                    VisibleOnGamepad = v11.VisibleOnGamepad,
                    ViewPort = l__ViewportSize__2
                });
            end;
        end;
        return u2.createFragment({ u2.createFragment(v8), u2.createElement("Frame", {
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0.5, 1),
                Position = UDim2.new(0.5, 0, 1, 0),
                Size = UDim2.new(0, 0, 1, 0)
            }, {
                Aspect = u2.createElement("UIAspectRatioConstraint", {
                    AspectRatio = 1.778,
                    AspectType = Enum.AspectType.ScaleWithParentSize,
                    DominantAxis = Enum.DominantAxis.Height
                }),
                Controls = u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(1, 0),
                    Position = UDim2.new(0.955, 0, 0.93, 0),
                    Size = UDim2.new(1, 0, 0.02, 0)
                }, {
                    u2.createFragment(v9),
                    Layout = u2.createElement("UIListLayout", {
                        FillDirection = Enum.FillDirection.Horizontal,
                        HorizontalAlignment = Enum.HorizontalAlignment.Right,
                        SortOrder = Enum.SortOrder.LayoutOrder,
                        VerticalAlignment = Enum.VerticalAlignment.Top,
                        Padding = UDim.new(0.01, 0)
                    })
                })
            }) });
    end;
end;
return v6;