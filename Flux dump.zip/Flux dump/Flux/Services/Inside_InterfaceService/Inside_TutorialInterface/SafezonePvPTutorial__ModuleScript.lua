-- Services.InterfaceService.TutorialInterface.SafezonePvPTutorial
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, _ = shared.import("require", "Enum");
v1("InputService");
v1("ClientService");
local _ = game:GetService("Players").LocalPlayer;
return {
    "Welcome to the <b>Safe Zone</b>.",
    { 6, 3 },
    "Here you can interact with your stash and sell items at the store.",
    { 10, 3 },
    "There is a global leaderboard showing the top performing players on the <b>whiteboards</b>.",
    { 10, 3 },
    "When you are ready to enter the <b>Quarantine Zone</b>, head over to the <b>Enter QZ</b> marker.",
    { 10, 3 }
};