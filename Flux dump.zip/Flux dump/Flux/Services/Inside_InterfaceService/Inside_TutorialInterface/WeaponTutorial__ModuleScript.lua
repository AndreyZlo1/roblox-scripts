-- Services.InterfaceService.TutorialInterface.WeaponTutorial
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local u1 = shared.import("require")("InputService");
return {
    function() --[[ Line: 6 ]]
        -- upvalues: u1 (copy)
        return "To equip your <b>Primary Weapon</b>, press <b>" .. u1:GetBind("CycleOne").Name .. "</b>";
    end,
    function(p2) --[[ Line: 9 ]]
        return p2.InventoryService._subcat == 1 and p2.InventoryService._selected == 1;
    end,
    function() --[[ Line: 15 ]]
        -- upvalues: u1 (copy)
        return u1.Touch and "To reload your weapon, press the <b>three bullets</b> button" or "To reload your weapon, press <b>" .. u1:GetBind("Reload").Name .. "</b>";
    end,
    3
};