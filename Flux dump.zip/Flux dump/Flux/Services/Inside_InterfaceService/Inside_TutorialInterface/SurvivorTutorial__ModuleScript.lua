-- Services.InterfaceService.TutorialInterface.SurvivorTutorial
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, _ = shared.import("require", "Enum");
v1("InputService");
v1("ClientService");
local _ = game:GetService("Players").LocalPlayer;
return {
    "You are a <b>Survivor</b>.",
    { 6, 3 },
    "Your goal is to escape the <i>Quarantine Zone</i> and become an <b>Operator</b>.",
    8,
    "Search police cars and abandoned military checkpoints to find a <b>CSEL</b> device.",
    9,
    "The <b>CSEL</b> device will let you call for a helicopter to rescue you.",
    8,
    "You can also find an <b>Operator</b> who may assist you in escaping the Quarantine Zone.",
    9,
    "<font color=\"rgb(255, 100, 100)\"> Zombies are more active at night and will act in hordes. <b>Do not make sound.</b> <b>Stay away from light sources.</b></font>",
    { 20, 5 },
    "Good luck.",
    5
};