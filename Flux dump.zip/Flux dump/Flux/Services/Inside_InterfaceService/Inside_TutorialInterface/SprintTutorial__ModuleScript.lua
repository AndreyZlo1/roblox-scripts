-- Services.InterfaceService.TutorialInterface.SprintTutorial
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, _, u2 = shared.import("require", "Enum", "server");
local u3 = v1("InputService");
local u4 = v1("ClientService");
local l__LocalPlayer__1 = game:GetService("Players").LocalPlayer;
return { function() --[[ Line: 11 ]]
        -- upvalues: u3 (copy)
        if u3.Touch then
            return "To <b>sprint</b>, press the <b>boots</b> button";
        elseif u3.Gamepad then
            return "To <b>sprint</b>, hold <b>" .. u3:GetBind("Sprint").Name .. "</b>";
        else
            return "To <b>sprint</b>, hold <b>" .. u3:GetBind("Sprint").Name .. "</b>";
        end;
    end, function() --[[ Line: 20 ]]
        -- upvalues: u4 (copy), l__LocalPlayer__1 (copy), u2 (copy)
        local v5 = u4.Clients[l__LocalPlayer__1];
        return (v5 and (v5.Actor and v5.Actor.Sprinting) or u2.NO_SPRINT) and true or false;
    end };