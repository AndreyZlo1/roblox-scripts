-- Services.InterfaceService.TutorialInterface.PVPTutorial
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local u1 = shared.import("require")("InputService");
return { function() --[[ Line: 6 ]]
        -- upvalues: u1 (copy)
        return "To change your <b>loadout</b> and view the <b>leaderboard</b>, press <b>" .. u1:GetBind("PauseMenu").Name .. "</b>";
    end, 6 };