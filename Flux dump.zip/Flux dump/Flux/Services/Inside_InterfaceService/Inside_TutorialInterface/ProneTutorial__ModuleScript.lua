-- Services.InterfaceService.TutorialInterface.ProneTutorial
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Enum");
local u3 = v1("InputService");
local u4 = v1("ClientService");
local l__LocalPlayer__1 = game:GetService("Players").LocalPlayer;
return { function() --[[ Line: 11 ]]
        -- upvalues: u3 (copy)
        if u3.Touch then
            return "To <b>prone</b>, press the <b>arrow pointing down</b> button";
        elseif u3.Gamepad then
            return "To <b>prone</b>, press and hold <b>" .. u3:GetBind("Crouch").Name .. "</b>";
        else
            return "To <b>prone</b>, press <b>" .. u3:GetBind("Prone").Name .. "</b>";
        end;
    end, function() --[[ Line: 20 ]]
        -- upvalues: u4 (copy), l__LocalPlayer__1 (copy), u2 (copy)
        local v5 = u4.Clients[l__LocalPlayer__1];
        return v5 and (v5.Actor and v5.Actor.HeightState == u2.CharacterHeightState.Proning) and true or false;
    end };