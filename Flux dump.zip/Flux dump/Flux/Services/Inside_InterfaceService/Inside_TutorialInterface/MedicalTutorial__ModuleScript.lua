-- Services.InterfaceService.TutorialInterface.MedicalTutorial
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local u1 = shared.import("require")("InputService");
return { function() --[[ Line: 6 ]]
        -- upvalues: u1 (copy)
        if u1.Touch then
            return "To heal yourself, press the <b>circle</b> at the bottom of your screen > click <b>Medical</b> > click <b>Bandage</b>";
        elseif u1.Gamepad then
            return "To heal yourself, press <b>" .. u1:GetBind("ActionMenu").Name .. "</b> > click <b>Medical</b> > click <b>Bandage</b>";
        else
            return "To heal yourself, hold <b>" .. u1:GetBind("ActionMenu").Name .. "</b> > click <b>Medical</b> > click <b>Bandage</b>";
        end;
    end, 10 };