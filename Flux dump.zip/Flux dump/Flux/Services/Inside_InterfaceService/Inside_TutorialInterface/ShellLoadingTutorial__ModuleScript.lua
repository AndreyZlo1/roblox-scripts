-- Services.InterfaceService.TutorialInterface.ShellLoadingTutorial
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, _ = shared.import("require", "Enum");
local v2 = v1("InputService");
v1("ClientService");
local _ = game:GetService("Players").LocalPlayer;
return {
    "To load a specific shell into the weapon, open your <b>inventory</b> and press <b>" .. v2:GetBind("Reload").Name .. "</b> while hovering over the shell.",
    { 10, 5 }
};