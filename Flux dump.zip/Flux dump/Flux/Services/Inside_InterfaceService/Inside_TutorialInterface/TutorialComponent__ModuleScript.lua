-- Services.InterfaceService.TutorialInterface.TutorialComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local u3 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u4 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u5 = v1("InputService");
local v6 = u2.Component:extend("Tutorial");
function v6.init(p7, p8) --[[ Line: 10 ]]
    p7.TextTransparency = p8.TextTransparency;
    p7.Text = p8.Text;
    p7.CanSkip = p8.CanSkip;
    p7.FadeIn = p8.FadeIn;
    p7.Bar = p8.Bar;
end;
function v6.render(p9) --[[ Line: 19 ]]
    -- upvalues: u5 (copy), u2 (copy), u4 (copy), u3 (copy)
    local l__Name__1 = u5:GetBind("PrimaryActivate").Name;
    return u2.createElement("Frame", {
        BorderSizePixel = 0,
        Size = UDim2.fromScale(1, 1),
        BackgroundColor3 = Color3.new(),
        BackgroundTransparency = p9.FadeIn:Map(function(p10) --[[ Line: 24 ]]
            return p10;
        end)
    }, {
        u2.createElement("UIGradient", {
            Rotation = -90,
            Color = ColorSequence.new(Color3.new(1, 1, 1)),
            Offset = Vector2.new(0, 0),
            Transparency = NumberSequence.new({
                NumberSequenceKeypoint.new(0, 0),
                NumberSequenceKeypoint.new(0.25, 0.3),
                NumberSequenceKeypoint.new(0.5, 1),
                NumberSequenceKeypoint.new(1, 1)
            })
        }),
        u2.createElement("Frame", {
            BorderSizePixel = 0,
            Size = p9.Bar:Map(function(p11) --[[ Line: 41 ]]
                return UDim2.fromScale(p11, 0.01);
            end),
            Position = UDim2.fromScale(0, 0.99),
            BackgroundColor3 = Color3.new(1, 1, 1),
            BackgroundTransparency = p9.FadeIn:Map(function(p12) --[[ Line: 46 ]]
                return p12;
            end)
        }, { u2.createElement("UIGradient", {
                Rotation = -90,
                Color = ColorSequence.new(Color3.new(1, 1, 1)),
                Offset = Vector2.new(0, 0),
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
            }) }),
        u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.new(0, 0, 0.95, 0),
            Size = UDim2.new(1, 0, 0.02, 0),
            FontFace = u4,
            Text = "[" .. l__Name__1 .. "] TO SKIP",
            TextTransparency = p9.TextTransparency:Map(function(p13) --[[ Line: 68 ]]
                return p13;
            end),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = Enum.TextXAlignment.Center,
            Visible = p9.CanSkip
        }),
        u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            RichText = true,
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.new(0, 0, 0.8, 0),
            Size = UDim2.new(1, 0, 0.03, 0),
            FontFace = u3,
            Text = p9.Text,
            TextTransparency = p9.TextTransparency:Map(function(p14) --[[ Line: 84 ]]
                return p14;
            end),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = Enum.TextXAlignment.Center
        })
    });
end;
return v6;