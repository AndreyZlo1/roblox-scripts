-- Services.InterfaceService.TutorialInterface.HQTutorial
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

return {
    "Welcome to your HQ",
    5,
    "The HQ system is entirely <i>optional</i> but using it has many benefits",
    8,
    "Hiring operators through your HQ can <b>generate money</b> while hiring mechanics can <b>lower repair costs</b>",
    10,
    "There are many other benefits if you are willing to put in the work",
    6,
    "To begin, enter the <b>Manage HQ</b> station",
    function(p1) --[[ Line: 11 ]]
        return p1.ManageCompany and true or false;
    end,
    "This is where you manage your HQ and company",
    5,
    "Currently you have no resources you can sell for money",
    10,
    "You can acquire resources by stealing them on <b>Ronograd</b> or by hiring employees to <b>do it for you 24/7</b>",
    15,
    "To hire an employee, click on the <b>Command</b> button",
    function(p2) --[[ Line: 24 ]]
        p2.ManageCompany.UpdateGlobalHoverName("Command");
        p2.ManageCompany.GlobalHover:SetGoal(1);
        return p2.ManageCompany and p2.ManageCompany.state.Page == "Command" and true or false;
    end,
    "Employees have grades for each of their skills. Higher skilled employees are more expensive",
    10,
    "The list of potential hires changes every <b>12 hours</b>",
    6,
    "Use the <b>Hire</b> button to hire your first 3 employees for <i>free</i>",
    function(p3) --[[ Line: 38 ]]
        return p3.ManageCompany and #p3.ManageCompany.Company.Employees >= 3 and true or false;
    end,
    "To assign these employees, exit the <b>Command</b> page and navigate to the <b>Barracks</b> page",
    function(p4) --[[ Line: 45 ]]
        return p4.ManageCompany and p4.ManageCompany.state.Page == "Home" and true or false;
    end,
    "Click on the <b>Barracks</b> button",
    function(p5) --[[ Line: 52 ]]
        p5.ManageCompany.UpdateGlobalHoverName("Barracks");
        p5.ManageCompany.GlobalHover:SetGoal(1);
        return p5.ManageCompany and p5.ManageCompany.state.Page == "Barracks" and true or false;
    end,
    "Employees can be assigned and removed (dismissed) on this page",
    6,
    "Assign an employee to <b>Logistics</b> by clicking the <b>Unassigned</b> button",
    function(p6) --[[ Line: 64 ]]
        if p6.ManageCompany then
            for _, v7 in p6.ManageCompany.Company.Employees do
                if v7.Assigned == "Logistics" then
                    return true;
                end;
            end;
        end;
        return false;
    end,
    "This employee\'s job is to store all the resources you acquire",
    6,
    "Assign an employee to <b>Operations</b> > <b>Construction Material</b>",
    function(p8) --[[ Line: 78 ]]
        if p8.ManageCompany then
            for _, v9 in p8.ManageCompany.Company.Employees do
                if v9.Assigned == "Operations" then
                    return true;
                end;
            end;
        end;
        return false;
    end,
    "This employee will now collect <b>Construction Material</b>, it will take a few hours so check back on them tomorrow",
    12,
    "<b>Construction Material</b> does not sell for a lot, but it is needed to upgrade your HQ",
    8,
    "<b>Precious Metal</b> and <b>Equipment</b> sell for the most amount of money but can take up to 24 hours to acquire",
    8,
    "Employees with a high skill level for <b>Combat</b> will acquire resources for you faster",
    6,
    "Assign the last employee to <b>Deliveries</b>",
    function(p10) --[[ Line: 98 ]]
        if p10.ManageCompany then
            for _, v11 in p10.ManageCompany.Company.Employees do
                if v11.Assigned == "Deliveries" then
                    return true;
                end;
            end;
        end;
        return false;
    end,
    "To sell resources, exit the <b>Barracks</b> page and navigate to the <b>Deliveries</b> page",
    function(p12) --[[ Line: 110 ]]
        return p12.ManageCompany and p12.ManageCompany.state.Page == "Home" and true or false;
    end,
    "Click on the <b>Deliveries</b> button",
    function(p13) --[[ Line: 117 ]]
        p13.ManageCompany.UpdateGlobalHoverName("Deliveries");
        p13.ManageCompany.GlobalHover:SetGoal(1);
        return p13.ManageCompany and p13.ManageCompany.state.Page == "Deliveries" and true or false;
    end,
    "Once you have acquired resources, you can sell them here for <b>money</b>",
    6,
    "To upgrade each part of your HQ, click on the <b>Upgrades</b> tab",
    function(p14) --[[ Line: 129 ]]
        p14.ManageCompany.UpdateGlobalHoverName("");
        p14.ManageCompany.GlobalHover:SetGoal(0);
        return p14.ManageCompany and p14.ManageCompany.state.Subpage == 3 and true or false;
    end,
    "Upgrades require money and resources, made sure to read the description of upgrades before purchasing",
    8,
    "This concludes the tutorial for your HQ",
    6,
    "There are help buttons on most pages to provide explanations of most core mechanics",
    6,
    "There are <b>Vehicle Request Portals</b> in your HQ if you wish to explore the island",
    6,
    "It is recommended that you travel to <b>Ronograd</b> to gather resources to speed up the progress of your company",
    10
};