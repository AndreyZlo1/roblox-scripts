-- Services.InterfaceService.TutorialInterface.ExtractionTutorial
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, _ = shared.import("require", "Enum");
local u2 = v1("InputService");
local u3 = v1("ClientService");
local l__LocalPlayer__1 = game:GetService("Players").LocalPlayer;
return {
    "Congratulations, you\'ve successfully escaped as a <b>Survivor</b>.",
    10,
    "Go to the <b>Your Gear</b> marker to collect your gear.",
    function(_) --[[ Line: 14 ]]
        -- upvalues: u3 (copy), l__LocalPlayer__1 (copy)
        local v4 = u3.Clients[l__LocalPlayer__1];
        local v5 = workspace.Terrain:FindFirstChild("Gear");
        return not v5 and true or (v4 and (v4.Actor and (v4.Actor.CFrame.Position - v5.WorldPosition).Magnitude < 20) and true or false);
    end,
    "Interact with the <b>Your Gear</b> marker.",
    function(_) --[[ Line: 27 ]]
        -- upvalues: u2 (copy)
        return u2.InventoryOpen and true or false;
    end,
    "Equip the gear that you need, old gear can be dropped on the ground.",
    function(_) --[[ Line: 34 ]]
        -- upvalues: u2 (copy)
        return not u2.InventoryOpen;
    end,
    "You can complete missions at the <b>Missions</b> tablet to earn money and <b>Operator Tokens</b>.",
    10,
    "<b>Operator Tokens</b> let you deploy on this ship with your gear at any time.",
    8
};