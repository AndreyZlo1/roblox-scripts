-- Services.InterfaceService.TutorialInterface.SurvivorPvPTutorial
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, _ = shared.import("require", "Enum");
v1("InputService");
v1("ClientService");
local _ = game:GetService("Players").LocalPlayer;
return {
    "Welcome to the <b>Quarantine Zone</b>.",
    { 6, 3 },
    "Zombies are not your only threat, other players *will* try to kill you and take your loot.",
    { 10, 3 },
    "Every night there is an <b>extraction</b>. Search the sky for a <b>red flare</b> to find the extraction point.",
    { 10, 3 },
    "Extracting is optional, it is for players who wish to visit the <b>safe zone</b> and sell items.",
    { 10, 3 },
    "<font color=\"rgb(255, 100, 100)\"> Zombies are more active at night and will act in hordes. <b>Do not make sound.</b> <b>Stay away from light sources.</b></font>",
    { 20, 5 },
    "Good luck.",
    5
};