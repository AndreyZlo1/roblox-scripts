-- Services.InterfaceService.TutorialInterface.FlashlightTutorial
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local u1 = shared.import("require")("InputService");
return {
    function() --[[ Line: 6 ]]
        -- upvalues: u1 (copy)
        return "To equip your <b>Secondary Weapon</b>, press <b>" .. u1:GetBind("CycleTwo").Name .. "</b>";
    end,
    function(p2) --[[ Line: 9 ]]
        return p2.InventoryService._subcat == 2 and p2.InventoryService._selected == 1;
    end,
    function() --[[ Line: 15 ]]
        -- upvalues: u1 (copy)
        if u1.Touch then
            return "To use your <b>Flashlight</b>, press the <b>circle</b> at the bottom of your screen > click <b>Character</b> > click <b>Weapon</b> > click <b>Set Flashlight mode</b>";
        elseif u1.Gamepad then
            return "To use your <b>Flashlight</b>, press <b>" .. u1:GetBind("ActionMenu").Name .. "</b> > click <b>Character</b> > click <b>Weapon</b> > click <b>Set Flashlight mode</b>";
        else
            return "To use your <b>Flashlight</b>, press <b>" .. u1:GetBind("WeaponFunction4").Name .. "</b>";
        end;
    end,
    6
};