-- Services.InterfaceService.PopupInterface.PopupComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, _ = shared.import("require", "Roact", "Enum", "server");
local l__GuiService__1 = game:GetService("GuiService");
local l__RunService__2 = game:GetService("RunService");
local u4 = v1("GameShellProxyScroller");
local u5 = v1("GameShellProxyButton");
local u6 = v1("InputService");
local u7 = v1("StatsService");
local u8 = v1("MenuButtonComponent");
local u9 = v1("PopupShopButtonComponent");
local u10 = v1("CreditPurchaseOptions");
local u11 = v1("Patchnotes");
local u12 = v1("formatNumber");
local l__CurrentCamera__3 = workspace.CurrentCamera;
local v13 = u2.Component:extend("Landing");
local u14 = Font.fromId(12187375422, u3.FontWeight.Bold, u3.FontStyle.Normal);
local u15 = Font.fromId(12187375422, u3.FontWeight.Regular, u3.FontStyle.Normal);
function v13.init(p16, p17) --[[ Line: 27 ]]
    -- upvalues: u2 (copy)
    p16.OpenTween = p17.OpenTween;
    p16.FocusTween = p17.FocusTween;
    p16.LoadingTween = p17.LoadingTween;
    p16.CircleTween = p17.CircleTween;
    local v18, v19 = u2.createBinding(0);
    p16.TopDownSize = v18;
    p16.UpdTopDownSize = v19;
    local v20, v21 = u2.createBinding(0);
    p16.BottomUpSize = v20;
    p16.UpdBottomUpSize = v21;
    local v22, v23 = u2.createBinding(0);
    p16.LeftRightSize = v22;
    p16.UpdLeftRightSize = v23;
    local v24, v25 = u2.createBinding(0);
    p16.RightLeftSize = v24;
    p16.UpdRightLeftSize = v25;
    local v26, v27 = u2.createBinding(0);
    p16.HorizontalCenter = v26;
    p16.UpdHorizontalCenter = v27;
    local v28, v29 = u2.createBinding(0);
    p16.VerticalCenter = v28;
    p16.UpdVerticalCenter = v29;
end;
function v13.didMount(u30) --[[ Line: 42 ]]
    -- upvalues: l__RunService__2 (copy), l__GuiService__1 (copy), l__CurrentCamera__3 (copy)
    u30.SteppedConnection = l__RunService__2.RenderStepped:Connect(function() --[[ Line: 43 ]]
        -- upvalues: u30 (copy), l__GuiService__1 (ref), l__CurrentCamera__3 (ref)
        local l__FocusRef__4 = u30.props.FocusRef;
        if l__FocusRef__4 then
            l__FocusRef__4 = u30.props.FocusRef:getValue();
        end;
        if l__FocusRef__4 and l__FocusRef__4.Parent then
            local v31 = l__FocusRef__4.AbsolutePosition + l__GuiService__1:GetGuiInset();
            local l__AbsoluteSize__5 = l__FocusRef__4.AbsoluteSize;
            local v32 = v31 + l__AbsoluteSize__5;
            local v33 = v31 + l__AbsoluteSize__5 / 2;
            local l__ViewportSize__6 = l__CurrentCamera__3.ViewportSize;
            u30.UpdTopDownSize(v31.Y / l__ViewportSize__6.Y);
            u30.UpdBottomUpSize(1 - v32.Y / l__ViewportSize__6.Y);
            u30.UpdLeftRightSize(v31.X / l__ViewportSize__6.X);
            u30.UpdRightLeftSize(1 - v32.X / l__ViewportSize__6.X);
            u30.UpdVerticalCenter(v33.Y / l__ViewportSize__6.Y);
            u30.UpdHorizontalCenter(v33.X / l__ViewportSize__6.X);
        end;
    end);
end;
function v13.willUnmount(p34) --[[ Line: 62 ]]
    p34.SteppedConnection:Disconnect();
end;
local function u38(p35) --[[ Line: 66 ]]
    -- upvalues: u2 (copy), u5 (copy)
    return u2.createElement(u5, {
        BorderSizePixel = 0,
        Selectable = false,
        BackgroundColor3 = Color3.new(),
        Position = p35.Position,
        AnchorPoint = p35.AnchorPoint,
        Size = p35.Size,
        Ignore = p35.FocusTween:Map(function(p36) --[[ Line: 75 ]]
            return p36 < 0.5;
        end),
        BackgroundTransparency = p35.FocusTween:Map(function(p37) --[[ Line: 79 ]]
            return 1 - p37 * 0.5;
        end),
        MouseDown = p35.Cancel
    });
end;
function v13.render(p39) --[[ Line: 88 ]]
    -- upvalues: u2 (copy), u8 (copy), u3 (copy), u14 (copy), u15 (copy), u5 (copy), u38 (copy), u10 (copy), u9 (copy), u7 (copy), u11 (copy), u4 (copy), u6 (copy), l__CurrentCamera__3 (copy), u12 (copy)
    local l__OpenTween__7 = p39.OpenTween;
    local l__FocusTween__8 = p39.FocusTween;
    local l__props__9 = p39.props;
    local v40 = {};
    for v41, v42 in l__props__9.Options do
        v40[v41] = u2.createElement(u8, {
            Layout = v41,
            Disabled = v42[3],
            Name = v42[1],
            Callback = v42[2]
        });
    end;
    local v43 = {};
    for v44, u45 in l__props__9.Slides do
        local v46 = {};
        for v47, u48 in u45.Options do
            v46[u48[1]] = u2.createElement(u8, {
                Layout = v47,
                Name = u48[1],
                Callback = function() --[[ Name: Callback, Line 110 ]]
                    -- upvalues: u45 (copy), u48 (copy)
                    u45.Close();
                    u48[2]();
                end
            });
        end;
        v43[v44] = u2.createElement("Frame", {
            BorderSizePixel = 0,
            LayoutOrder = v44,
            BackgroundColor3 = Color3.fromRGB(24, 24, 24),
            Position = UDim2.fromScale(1, 0.5),
            AnchorPoint = Vector2.new(1, 0.5),
            Size = u45.Tween:Map(function(p49) --[[ Line: 123 ]]
                return UDim2.fromScale(p49, 0.1);
            end),
            Visible = u45.Tween:Map(function(p50) --[[ Line: 126 ]]
                return p50 > 0.05;
            end)
        }, {
            Dots = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://13867939464",
                Size = UDim2.fromScale(1, 1),
                ImageColor3 = Color3.fromRGB(144, 144, 144),
                TileSize = UDim2.fromOffset(6, 6),
                ScaleType = u3.ScaleType.Tile
            }, {
                Title = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    Size = UDim2.fromScale(0.9, 0.25),
                    Position = UDim2.fromScale(0.05, 0.1),
                    Text = u45.Title:upper(),
                    TextColor3 = Color3.new(1, 1, 1),
                    FontFace = u14,
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                Description = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    Size = UDim2.fromScale(0.9, 0.2),
                    Position = UDim2.fromScale(0.05, 0.35),
                    Text = u45.Description,
                    TextColor3 = Color3.new(1, 1, 1),
                    FontFace = u15,
                    TextXAlignment = u3.TextXAlignment.Left,
                    TextYAlignment = u3.TextYAlignment.Top
                }),
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 90,
                    Transparency = NumberSequence.new({
                        NumberSequenceKeypoint.new(0, 0.7),
                        NumberSequenceKeypoint.new(0.45, 1),
                        NumberSequenceKeypoint.new(0.56, 1),
                        NumberSequenceKeypoint.new(1, 0)
                    })
                }),
                Buttons = u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Position = UDim2.fromScale(0.05, 0.65),
                    Size = UDim2.fromScale(0.9, 0.25)
                }, {
                    Grid = u2.createElement("UIGridLayout", {
                        CellPadding = UDim2.fromScale(0.02, 0),
                        CellSize = UDim2.fromScale(1 / #u45.Options - 0.02, 1),
                        FillDirection = u3.FillDirection.Horizontal,
                        HorizontalAlignment = u3.HorizontalAlignment.Center,
                        SortOrder = u3.SortOrder.LayoutOrder
                    }),
                    u2.createFragment(v46)
                }),
                Close = u2.createElement(u5, {
                    Image = "rbxassetid://264596039",
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(1, 0),
                    Position = UDim2.fromScale(0.95, 0.15),
                    Size = UDim2.fromScale(0.15, 0.15),
                    SizeConstraint = u3.SizeConstraint.RelativeYY,
                    ImageColor3 = u45.Binding:map(function(p51) --[[ Line: 189 ]]
                        return p51 and Color3.fromRGB(255, 194, 89) or Color3.new(1, 1, 1);
                    end),
                    MouseUp = u45.Close,
                    MouseEnter = function() --[[ Name: MouseEnter, Line 194 ]]
                        -- upvalues: u45 (copy)
                        u45.UpdateBinding(true);
                    end,
                    MouseLeave = function() --[[ Name: MouseLeave, Line 197 ]]
                        -- upvalues: u45 (copy)
                        u45.UpdateBinding(false);
                    end
                })
            }),
            White = u2.createElement("Frame", {
                BorderSizePixel = 0,
                ZIndex = 2,
                Size = UDim2.fromScale(1, 1),
                BackgroundColor3 = Color3.new(1, 1, 1),
                BackgroundTransparency = u45.Tween:Map(function(p52) --[[ Line: 206 ]]
                    return (math.clamp(p52, 0.5, 1) - 0.5) * 2;
                end)
            })
        });
    end;
    local v65 = u2.createFragment({
        u2.createElement(u38, {
            Position = UDim2.fromScale(0, 0),
            AnchorPoint = Vector2.new(0, 0),
            Size = u2.joinBindings({ l__FocusTween__8.Binding, p39.TopDownSize, p39.LeftRightSize }):map(function(p53) --[[ Line: 219 ]]
                return UDim2.fromScale(p53[3] * p53[1], p53[2] * p53[1]);
            end),
            FocusTween = l__FocusTween__8,
            Cancel = l__props__9.CancelFocus
        }),
        u2.createElement(u38, {
            Position = p39.HorizontalCenter:map(function(p54) --[[ Line: 226 ]]
                return UDim2.fromScale(p54, 0);
            end),
            AnchorPoint = Vector2.new(0.5, 0),
            Size = u2.joinBindings({
                l__FocusTween__8.Binding,
                p39.TopDownSize,
                p39.LeftRightSize,
                p39.RightLeftSize
            }):map(function(p55) --[[ Line: 230 ]]
                return UDim2.fromScale((1 - p55[3] - p55[4]) * p55[1], p55[2] * p55[1]);
            end),
            FocusTween = l__FocusTween__8,
            Cancel = l__props__9.CancelFocus
        }),
        u2.createElement(u38, {
            Position = UDim2.fromScale(1, 0),
            AnchorPoint = Vector2.new(1, 0),
            Size = u2.joinBindings({ l__FocusTween__8.Binding, p39.TopDownSize, p39.RightLeftSize }):map(function(p56) --[[ Line: 239 ]]
                return UDim2.fromScale(p56[3] * p56[1], p56[2] * p56[1]);
            end),
            FocusTween = l__FocusTween__8,
            Cancel = l__props__9.CancelFocus
        }),
        u2.createElement(u38, {
            Position = p39.VerticalCenter:map(function(p57) --[[ Line: 246 ]]
                return UDim2.fromScale(1, p57);
            end),
            AnchorPoint = Vector2.new(1, 0.5),
            Size = u2.joinBindings({
                l__FocusTween__8.Binding,
                p39.TopDownSize,
                p39.BottomUpSize,
                p39.RightLeftSize
            }):map(function(p58) --[[ Line: 250 ]]
                return UDim2.fromScale(p58[4] * p58[1], (1 - p58[2] - p58[3]) * p58[1]);
            end),
            FocusTween = l__FocusTween__8,
            Cancel = l__props__9.CancelFocus
        }),
        u2.createElement(u38, {
            Position = UDim2.fromScale(1, 1),
            AnchorPoint = Vector2.new(1, 1),
            Size = u2.joinBindings({ l__FocusTween__8.Binding, p39.BottomUpSize, p39.RightLeftSize }):map(function(p59) --[[ Line: 259 ]]
                return UDim2.fromScale(p59[3] * p59[1], p59[2] * p59[1]);
            end),
            FocusTween = l__FocusTween__8,
            Cancel = l__props__9.CancelFocus
        }),
        u2.createElement(u38, {
            Position = p39.HorizontalCenter:map(function(p60) --[[ Line: 266 ]]
                return UDim2.fromScale(p60, 1);
            end),
            AnchorPoint = Vector2.new(0.5, 1),
            Size = u2.joinBindings({
                l__FocusTween__8.Binding,
                p39.BottomUpSize,
                p39.LeftRightSize,
                p39.RightLeftSize
            }):map(function(p61) --[[ Line: 270 ]]
                return UDim2.fromScale((1 - p61[3] - p61[4]) * p61[1], p61[2] * p61[1]);
            end),
            FocusTween = l__FocusTween__8,
            Cancel = l__props__9.CancelFocus
        }),
        u2.createElement(u38, {
            Position = UDim2.fromScale(0, 1),
            AnchorPoint = Vector2.new(0, 1),
            Size = u2.joinBindings({ l__FocusTween__8.Binding, p39.BottomUpSize, p39.LeftRightSize }):map(function(p62) --[[ Line: 279 ]]
                return UDim2.fromScale(p62[3] * p62[1], p62[2] * p62[1]);
            end),
            FocusTween = l__FocusTween__8,
            Cancel = l__props__9.CancelFocus
        }),
        u2.createElement(u38, {
            Position = p39.VerticalCenter:map(function(p63) --[[ Line: 286 ]]
                return UDim2.fromScale(0, p63);
            end),
            AnchorPoint = Vector2.new(0, 0.5),
            Size = u2.joinBindings({
                l__FocusTween__8.Binding,
                p39.TopDownSize,
                p39.BottomUpSize,
                p39.LeftRightSize
            }):map(function(p64) --[[ Line: 290 ]]
                return UDim2.fromScale(p64[4] * p64[1], (1 - p64[2] - p64[3]) * p64[1]);
            end),
            FocusTween = l__FocusTween__8,
            Cancel = l__props__9.CancelFocus
        })
    });
    local u66 = l__props__9.Type == u3.PopupType.Patch;
    local v67 = l__props__9.Type == u3.PopupType.Vertical;
    local u68 = l__props__9.Type == u3.PopupType.Shop;
    local u69 = not v67 and 0 or #l__props__9.Options * 0.022;
    local v70;
    if u68 then
        local u71 = 1;
        local v72 = {};
        for v73, u74 in u10 do
            local v75, u76 = u2.createBinding(u71);
            v72[v73] = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ZIndex = v75,
                LayoutOrder = v73
            }, {
                Inner = u2.createElement(u9, {
                    Option = u74,
                    Callback = function() --[[ Name: Callback, Line 320 ]]
                        -- upvalues: u7 (ref), u74 (copy)
                        u7:PromptProduct(u74.Product, true);
                    end,
                    IncreaseZIndex = function() --[[ Name: IncreaseZIndex, Line 323 ]]
                        -- upvalues: u71 (ref), u76 (copy)
                        u71 = u71 + 1;
                        u76(u71);
                    end,
                    SoundKit = u74.Big and "ShopCreditsBig" or "ShopCredits"
                })
            });
        end;
        v70 = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Position = UDim2.fromScale(0.05, 0.2),
            Size = UDim2.fromScale(0.9, 0.55)
        }, {
            u2.createFragment(v72),
            UIGridLayout = u2.createElement("UIGridLayout", {
                CellPadding = UDim2.new(),
                CellSize = UDim2.fromScale(0.25, 0.5),
                SortOrder = u3.SortOrder.LayoutOrder
            })
        });
    else
        v70 = nil;
    end;
    if u66 and l__props__9.Description then
        local v77 = {};
        local v78 = {};
        local v79 = u11[l__props__9.Description];
        if v79.Sub then
            l__props__9.Title = l__props__9.Title .. " (" .. v79.Sub .. ")";
        end;
        for v80 in v79.Content:gmatch("[^\r\n]+") do
            local v81 = #v78 + 1;
            local v82 = {};
            if #v80 > 2 then
                local v83 = v80:sub(1, 1);
                local v84 = v83 == "#";
                local v85 = v80:sub(3);
                if v83 == "+" or v83 == "-" then
                    v82.Add = u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        Text = ">",
                        Position = UDim2.fromScale(0, 0.1),
                        Size = UDim2.fromScale(0.1, 0.8),
                        FontFace = u15,
                        TextColor3 = Color3.new(0.705882, 0.705882, 0.705882),
                        TextXAlignment = u3.TextXAlignment.Left
                    });
                end;
                v82.Text = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    Position = UDim2.fromScale(v84 and 0 or 0.02, v84 and 0 or 0.1),
                    Size = UDim2.fromScale(10000, v84 and 1 or 0.8),
                    FontFace = v84 and u14 or u15,
                    TextColor3 = v84 and Color3.fromRGB(255, 194, 89) or Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Left,
                    Text = v85
                });
            end;
            v77["Line_" .. v81] = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                LayoutOrder = v81
            }, v82);
            v78[v81] = v80;
        end;
        local v86, v87;
        if v79.Image then
            v86 = u2.createElement("ImageLabel", {
                BorderSizePixel = 0,
                Size = UDim2.fromScale(0.9, 0.13),
                Position = UDim2.fromScale(0.05, 0.1),
                BackgroundColor3 = Color3.new(),
                Image = v79.Image
            });
            v87 = 29;
        else
            v87 = 36;
            v86 = nil;
        end;
        local v88 = math.max(v87, #v78);
        local v89 = math.ceil(v88);
        local v90 = 1 / v89;
        v77.Grid = u2.createElement("UIGridLayout", {
            CellPadding = UDim2.fromScale(0, 0),
            CellSize = UDim2.fromScale(1, v90),
            FillDirection = u3.FillDirection.Horizontal,
            HorizontalAlignment = u3.HorizontalAlignment.Left,
            SortOrder = u3.SortOrder.LayoutOrder,
            StartCorner = u3.StartCorner.TopLeft,
            VerticalAlignment = u3.VerticalAlignment.Top
        });
        v70 = u2.createFragment({ u2.createElement(u4, {
                BackgroundTransparency = 1,
                BorderSizePixel = 0,
                Size = UDim2.fromScale(0.9, v86 and 0.6 or 0.75),
                Position = UDim2.fromScale(0.05, v86 and 0.25 or 0.1),
                AnchorPoint = Vector2.new(0, 0),
                CanvasSize = v89 / v87,
                Content = v77
            }), v86 });
    end;
    local l__createElement__10 = u2.createElement;
    local v91 = "Frame";
    local v93 = {
        BorderSizePixel = 0,
        Position = UDim2.fromScale(0.5, 0),
        Size = UDim2.fromScale(2, 1),
        AnchorPoint = Vector2.new(0.5, 0),
        BackgroundColor3 = Color3.new(),
        BackgroundTransparency = l__OpenTween__7:Map(function(p92) --[[ Line: 441 ]]
            return 1 - p92 * 0.5;
        end)
    };
    local v98 = {
        Focus = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(0.5, 1),
            Position = UDim2.fromScale(0.5, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5)
        }, { v65 }),
        Loading = u2.createElement("Frame", {
            BorderSizePixel = 0,
            Size = UDim2.fromScale(1, 1),
            BackgroundColor3 = Color3.new(),
            BackgroundTransparency = p39.LoadingTween:Map(function(p94) --[[ Line: 457 ]]
                return 1 - p94 / 2;
            end)
        }, { u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://93026081002023",
                Position = UDim2.fromScale(0.5, 0.5),
                Size = p39.LoadingTween:Map(function(p95) --[[ Line: 463 ]]
                    local v96 = 0.2 - p95 / 10;
                    return UDim2.fromScale(v96, v96);
                end),
                AnchorPoint = Vector2.new(0.5, 0.5),
                ImageTransparency = p39.LoadingTween:Map(function(p97) --[[ Line: 469 ]]
                    return 1 - p97;
                end),
                SizeConstraint = u3.SizeConstraint.RelativeYY,
                Rotation = p39.CircleTween
            }) }),
        Slides = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(1, 1),
            Position = UDim2.fromScale(0.75, 0.9),
            Size = UDim2.fromScale(0.4, 1),
            SizeConstraint = u3.SizeConstraint.RelativeYY
        }, { u2.createElement("UIListLayout", {
                SortOrder = u3.SortOrder.LayoutOrder,
                FillDirection = u3.FillDirection.Vertical,
                VerticalAlignment = u3.VerticalAlignment.Bottom,
                HorizontalAlignment = u3.HorizontalAlignment.Right,
                Padding = UDim.new(0.01, 0)
            }), u2.createFragment(v43) })
    };
    local l__createElement__11 = u2.createElement;
    local v99 = "Frame";
    local v104 = {
        BorderSizePixel = 0,
        ClipsDescendants = true,
        BackgroundColor3 = Color3.fromRGB(24, 24, 24),
        Position = UDim2.fromScale(0.5, 0.5),
        AnchorPoint = Vector2.new(0.5, 0.5),
        Size = l__OpenTween__7:Map(function(p100) --[[ Line: 498 ]]
            -- upvalues: u6 (ref), u66 (copy), u68 (copy), u69 (ref)
            local v101 = math.clamp(p100, 0, 0.5) * 2;
            local v102 = (math.clamp(p100, 0.5, 1) - 0.5) * 2;
            local l__Touch__12 = u6.Touch;
            return UDim2.fromScale(v101 * ((u66 or l__Touch__12) and 0.9 or 0.5), 0.05 + v102 * (u66 and 0.9 or (l__Touch__12 and 0.7 or (u68 and 0.3 or u69 + 0.25))));
        end),
        Visible = l__OpenTween__7:Map(function(p103) --[[ Line: 505 ]]
            return p103 > 0.05;
        end),
        SizeConstraint = u3.SizeConstraint.RelativeYY
    };
    local v105 = { (u2.createElement("UIGradient", {
            Rotation = 90,
            Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(0.65, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(108, 108, 108)) })
        })) };
    local l__createElement__13 = u2.createElement;
    local v106 = "ImageLabel";
    local v107 = {
        BackgroundTransparency = 1,
        Image = "rbxassetid://13867939464",
        ImageTransparency = 1,
        Size = UDim2.fromScale(1, 1),
        ImageColor3 = Color3.fromRGB(144, 144, 144),
        TileSize = UDim2.fromOffset(6, 6),
        ScaleType = u3.ScaleType.Tile
    };
    local v108 = {};
    local l__createElement__14 = u2.createElement;
    local v109 = "Frame";
    local v110 = {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 0.1),
        SizeConstraint = u3.SizeConstraint.RelativeXX
    };
    local v111 = {};
    local l__Title__15 = l__props__9.Title;
    if l__Title__15 then
        l__Title__15 = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
            Position = UDim2.fromScale(u66 and 0.05 or 0.1, u66 and 0.4 or 0.6),
            Size = UDim2.fromScale(0.8, u66 and 0.4 or 0.6),
            Text = l__props__9.Title:upper(),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = u3.TextXAlignment.Left
        });
    end;
    local v112 = l__props__9.Description and not u66;
    if v112 then
        v112 = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            RichText = true,
            TextWrapped = true,
            FontFace = Font.new("rbxassetid://12187375422"),
            Position = UDim2.fromScale(0.1, 1.5),
            Size = UDim2.fromScale(0.8, 4),
            Text = l__props__9.Description,
            TextColor3 = Color3.new(1, 1, 1),
            TextSize = l__CurrentCamera__3.ViewportSize.Y * 0.3 * (u6.Touch and 0.12 or 0.06),
            TextTransparency = l__OpenTween__7:Map(function(p113) --[[ Line: 556 ]]
                return 1 - (math.clamp(p113, 0.5, 1) - 0.5) * 2;
            end),
            TextXAlignment = u3.TextXAlignment.Left,
            TextYAlignment = u3.TextYAlignment.Top
        });
    end;
    if u68 then
        u68 = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            FontFace = Font.new("rbxassetid://12187375422", u3.FontWeight.Bold, u3.FontStyle.Normal),
            Position = UDim2.fromScale(0.1, 0.9),
            Size = UDim2.fromScale(0.8, 0.3),
            Text = u7.MoneyBinding:map(function(p114) --[[ Line: 573 ]]
                -- upvalues: u12 (ref)
                return "CURRENT BALANCE: " .. u12(p114);
            end),
            TextColor3 = Color3.fromRGB(255, 205, 122),
            TextXAlignment = u3.TextXAlignment.Right
        });
    end;
    v111[1], v111[2], v111[3] = l__Title__15, v112, u68;
    v108[1] = l__createElement__14(v109, v110, v111);
    v108.Gradient = u2.createElement("UIGradient", {
        Rotation = 90,
        Transparency = NumberSequence.new({
            NumberSequenceKeypoint.new(0, 0.7),
            NumberSequenceKeypoint.new(0.45, 1),
            NumberSequenceKeypoint.new(0.56, 1),
            NumberSequenceKeypoint.new(1, 0)
        })
    });
    v108[2], v108[3] = u2.createElement("Frame", {
    BackgroundTransparency = 1,
    AnchorPoint = Vector2.new(0.5, 1),
    Position = UDim2.fromScale(0.5, 1),
    Size = UDim2.fromScale(u66 and 0.3 or 1, u66 and 0.06 or 0.1),
    SizeConstraint = u3.SizeConstraint.RelativeXX
}, {
    Buttons = u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Position = UDim2.fromScale(0.1, -0.45),
        Size = UDim2.fromScale(0.8, 0.6)
    }, {
        Grid = u2.createElement("UIGridLayout", {
            CellPadding = UDim2.fromScale(v67 and 0 or 0.02, v67 and 0.2 or 0),
            CellSize = UDim2.fromScale(v67 and 1 or 1 / #l__props__9.Options - 0.02, 1),
            FillDirection = u3.FillDirection.Horizontal,
            HorizontalAlignment = u3.HorizontalAlignment.Center,
            VerticalAlignment = u3.VerticalAlignment.Bottom,
            SortOrder = u3.SortOrder.LayoutOrder
        }),
        u2.createFragment(v40)
    })
}), v70;
    v105.Dots = l__createElement__13(v106, v107, v108);
    v105.White = u2.createElement("Frame", {
        BorderSizePixel = 0,
        ZIndex = 2,
        Size = UDim2.fromScale(1, 1),
        BackgroundColor3 = Color3.new(1, 1, 1),
        BackgroundTransparency = l__OpenTween__7:Map(function(p115) --[[ Line: 619 ]]
            return (math.clamp(p115, 0.5, 1) - 0.5) * 2;
        end)
    });
    v98.Modal = l__createElement__11(v99, v104, v105);
    return l__createElement__10(v91, v93, v98);
end;
return v13;