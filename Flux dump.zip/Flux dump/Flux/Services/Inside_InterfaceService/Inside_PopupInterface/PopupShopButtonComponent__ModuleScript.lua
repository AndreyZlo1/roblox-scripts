-- Services.InterfaceService.PopupInterface.PopupShopButtonComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _, _ = shared.import("require", "Roact", "network", "server");
local l__RunService__1 = game:GetService("RunService");
local u3 = v1("GameShellProxyButton");
local u4 = v1("RoactTween");
local u5 = v1("formatNumber");
local v6 = u2.Component:extend("PopupShopButton");
function v6.init(u7, _) --[[ Line: 11 ]]
    -- upvalues: u4 (copy), u2 (copy), l__RunService__1 (copy)
    u7.Hover = u4.new(1, TweenInfo.new(0.8, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out, 0, false, 0));
    u7.HoverLinear = u4.new(0, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out, 0, false, 0));
    local v8, u9 = u2.createBinding(1);
    u7.Loop = l__RunService__1.Heartbeat:Connect(function(p10) --[[ Line: 16 ]]
        -- upvalues: u7 (copy), u9 (copy)
        if u7.Hovering then
            u9((math.cos(u7.Hovering + 1.0471975511965976) + 1) / 2);
            local v11 = u7;
            v11.Hovering = v11.Hovering + p10 * 2;
        else
            u9(1);
        end;
    end);
    u7.Hover:SetGoal(0);
    u7.Glow = v8;
end;
function v6.willUnmount(p12) --[[ Line: 29 ]]
    p12.Loop:Disconnect();
end;
function v6.render(u13) --[[ Line: 33 ]]
    -- upvalues: u2 (copy), u5 (copy), u3 (copy)
    local l__Option__2 = u13.props.Option;
    local v15 = u13.HoverLinear:Map(function(p14) --[[ Line: 35 ]]
        return 1 - p14;
    end);
    local v16 = {
        Glow = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = v15,
            BackgroundColor3 = Color3.new(1, 1, 1),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(1, -0.05),
            Size = UDim2.fromScale(0.1, 1.1)
        }, {
            UIGradient = u2.createElement("UIGradient", {
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
            })
        }),
        Glow2 = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = v15,
            AnchorPoint = Vector2.new(1, 0),
            BackgroundColor3 = Color3.new(1, 1, 1),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0, -0.05),
            Size = UDim2.fromScale(0.1, 1.1)
        }, {
            UIGradient = u2.createElement("UIGradient", {
                Rotation = 180,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
            })
        }),
        Glow3 = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = v15,
            BackgroundColor3 = Color3.new(1, 1, 1),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(-0.05, -0.1),
            Size = UDim2.fromScale(1.1, 0.1)
        }, {
            UIGradient = u2.createElement("UIGradient", {
                Rotation = -90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
            })
        }),
        Glow4 = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = v15,
            BackgroundColor3 = Color3.new(1, 1, 1),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(-0.05, 1),
            Size = UDim2.fromScale(1.1, 0.1)
        }, {
            UIGradient = u2.createElement("UIGradient", {
                Rotation = 90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
            })
        })
    };
    local v17 = nil;
    local v18 = nil;
    if l__Option__2.Credits then
        v17 = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            Position = UDim2.fromScale(0.05, 0.05),
            Size = UDim2.fromScale(0.32, 0.32),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }, {
            Title = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
                Position = UDim2.fromScale(1.1, 0.5),
                Size = UDim2.fromScale(10, 0.8),
                Text = u5(l__Option__2.Credits):sub(2),
                TextColor3 = u13.Glow:map(function(p19) --[[ Line: 127 ]]
                    return Color3.new(1, 1, 1):Lerp(Color3.fromRGB(255, 205, 122), p19);
                end),
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            Icon = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.5),
                Size = UDim2.fromScale(0.7, 0.7)
            }, {
                Top = u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(1, 0),
                    Position = UDim2.fromScale(1, 0),
                    Size = UDim2.fromScale(0.65, 0.65),
                    BackgroundColor3 = u13.Glow:map(function(p20) --[[ Line: 145 ]]
                        return Color3.new(1, 1, 1):Lerp(Color3.fromRGB(255, 205, 122), p20);
                    end)
                }, {
                    UIStroke = u2.createElement("UIStroke", {
                        Thickness = 0.05,
                        Color = u13.Glow:map(function(p21) --[[ Line: 150 ]]
                            return Color3.new(1, 1, 1):Lerp(Color3.fromRGB(255, 205, 122), p21);
                        end),
                        LineJoinMode = Enum.LineJoinMode.Miter,
                        StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
                    })
                }),
                Bottom = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    AnchorPoint = Vector2.new(0, 1),
                    BackgroundColor3 = u13.Glow:map(function(p22) --[[ Line: 160 ]]
                        return Color3.new(1, 1, 1):Lerp(Color3.fromRGB(255, 205, 122), p22);
                    end),
                    BorderColor3 = Color3.new(),
                    Position = UDim2.fromScale(0, 1),
                    Size = UDim2.fromScale(0.65, 0.65)
                }, {
                    UIGradient = u2.createElement("UIGradient", {
                        Rotation = -45,
                        Transparency = NumberSequence.new({
                            NumberSequenceKeypoint.new(0, 0),
                            NumberSequenceKeypoint.new(0.49536, 0),
                            NumberSequenceKeypoint.new(0.50464, 1),
                            NumberSequenceKeypoint.new(1, 1)
                        })
                    }),
                    UIStroke = u2.createElement("UIStroke", {
                        Thickness = 0.05,
                        Color = u13.Glow:map(function(p23) --[[ Line: 178 ]]
                            return Color3.new(1, 1, 1):Lerp(Color3.fromRGB(255, 205, 122), p23);
                        end),
                        LineJoinMode = Enum.LineJoinMode.Miter,
                        StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
                    })
                })
            })
        });
        local v24 = l__Option__2.Credits - (l__Option__2.Robux + 1) * 10;
        if v24 > 0 then
            local v25 = l__Option__2.Credits - v24;
            local v26 = v25 < 10000 and 2.8 or 3.2;
            v18 = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ZIndex = 2,
                Position = UDim2.fromScale(0.05, 0.35),
                Size = UDim2.fromScale(0.2, 0.2),
                SizeConstraint = Enum.SizeConstraint.RelativeYY
            }, {
                Title = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    TextTransparency = 0.2,
                    ZIndex = 2,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
                    Position = UDim2.fromScale(1.1, 0.5),
                    Size = UDim2.fromScale(10, 0.8),
                    Text = u5(v25):sub(2),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = Enum.TextXAlignment.Left
                }),
                Icon = u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Position = UDim2.fromScale(0.5, 0.5),
                    Size = UDim2.fromScale(0.7, 0.7)
                }, {
                    Top = u2.createElement("Frame", {
                        BackgroundTransparency = 1,
                        AnchorPoint = Vector2.new(1, 0),
                        Position = UDim2.fromScale(1, 0),
                        Size = UDim2.fromScale(0.65, 0.65)
                    }, {
                        UIStroke = u2.createElement("UIStroke", {
                            Thickness = 0.05,
                            Transparency = 0.2,
                            Color = Color3.new(1, 1, 1),
                            LineJoinMode = Enum.LineJoinMode.Miter,
                            StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
                        })
                    }),
                    Bottom = u2.createElement("Frame", {
                        BackgroundTransparency = 0.2,
                        BorderSizePixel = 0,
                        AnchorPoint = Vector2.new(0, 1),
                        BackgroundColor3 = Color3.new(1, 1, 1),
                        BorderColor3 = Color3.new(),
                        Position = UDim2.fromScale(0, 1),
                        Size = UDim2.fromScale(0.65, 0.65)
                    }, {
                        UIGradient = u2.createElement("UIGradient", {
                            Rotation = -45,
                            Transparency = NumberSequence.new({
                                NumberSequenceKeypoint.new(0, 0),
                                NumberSequenceKeypoint.new(0.49536, 0),
                                NumberSequenceKeypoint.new(0.50464, 1),
                                NumberSequenceKeypoint.new(1, 1)
                            })
                        }),
                        UIStroke = u2.createElement("UIStroke", {
                            Thickness = 0.05,
                            Transparency = 0.2,
                            Color = Color3.new(1, 1, 1),
                            LineJoinMode = Enum.LineJoinMode.Miter,
                            StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
                        })
                    })
                }),
                Strike = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    ZIndex = 2,
                    AnchorPoint = Vector2.new(0, 0.5),
                    BackgroundColor3 = Color3.new(1, 1, 1),
                    BorderColor3 = Color3.new(),
                    Position = UDim2.fromScale(-0.1, 0.5),
                    Size = UDim2.fromScale(v26, 0.04)
                })
            });
        end;
    elseif l__Option__2.Length then
        local l__createElement__3 = u2.createElement;
        local v27 = "Frame";
        local v28 = {
            BackgroundTransparency = 1,
            ZIndex = 2,
            Position = UDim2.fromScale(0.05, 0.05),
            Size = UDim2.fromScale(0.32, 0.32),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        };
        local v31 = {
            Icon = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://4520264138",
                Position = UDim2.fromScale(0.5, 0.5),
                Size = UDim2.fromScale(0.7, 0.7),
                AnchorPoint = Vector2.new(0.5, 0.5),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                ImageColor3 = u13.Glow:map(function(p29) --[[ Line: 294 ]]
                    return Color3.fromRGB(254, 155, 35):Lerp(Color3.new(1, 1, 1), p29);
                end)
            }),
            Title = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
                Position = UDim2.fromScale(0.875, 0.5),
                Size = UDim2.fromScale(10, 0.8),
                Text = l__Option__2.Length,
                TextColor3 = u13.Glow:map(function(p30) --[[ Line: 309 ]]
                    return Color3.fromRGB(254, 155, 35):Lerp(Color3.new(1, 1, 1), p30);
                end),
                TextXAlignment = Enum.TextXAlignment.Left
            })
        };
        local l__Extra__4 = l__Option__2.Extra;
        if l__Extra__4 then
            l__Extra__4 = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                ZIndex = 2,
                FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Regular, Enum.FontStyle.Italic),
                Position = UDim2.fromScale(0.25, 0.95),
                Size = UDim2.fromScale(10, 0.45),
                Text = l__Option__2.Extra,
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = Enum.TextXAlignment.Left
            });
        end;
        v31[1] = l__Extra__4;
        v17 = l__createElement__3(v27, v28, v31);
    end;
    return u2.createElement(u3, {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 1),
        Ignore = u13.props.Ignore,
        Scroller = u13.props.Scroller,
        SoundKit = u13.props.SoundKit,
        MouseEnter = function() --[[ Name: MouseEnter, Line 341 ]]
            -- upvalues: u13 (copy)
            u13.props.IncreaseZIndex();
            u13.Hover:SetGoal(1);
            u13.HoverLinear:SetGoal(1);
            u13.Hovering = 0;
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 347 ]]
            -- upvalues: u13 (copy)
            u13.Hover:SetGoal(0);
            u13.HoverLinear:SetGoal(0);
            u13.Hovering = nil;
        end,
        MouseUp = function() --[[ Name: MouseUp, Line 352 ]]
            -- upvalues: u13 (copy)
            u13.Hover:SetGoal(1);
            u13.props.Callback();
        end,
        MouseDown = function() --[[ Name: MouseDown, Line 356 ]]
            -- upvalues: u13 (copy)
            u13.Hover:SetGoal(0);
        end
    }, { u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.fromRGB(253, 255, 255),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0.5, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Size = u13.Hover:Map(function(p32) --[[ Line: 366 ]]
                local v33 = p32 * 0.2;
                return UDim2.fromScale(v33 + 0.9, v33 + 0.9);
            end)
        }, {
            Stroke = u2.createElement("UIStroke", {
                Color = u13.HoverLinear:Map(function(p34) --[[ Line: 372 ]]
                    return Color3.fromRGB(71, 71, 71):Lerp(Color3.new(1, 1, 1), p34);
                end)
            }),
            UIGradient = u2.createElement("UIGradient", {
                Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.new()), ColorSequenceKeypoint.new(1, l__Option__2.Color) }),
                Rotation = u13.HoverLinear:Map(function(p35) --[[ Line: 382 ]]
                    return 45 - p35 * 90;
                end)
            }),
            Robux = u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxasset://textures/ui/common/robux.png",
                ZIndex = 2,
                AnchorPoint = Vector2.new(0, 1),
                Position = UDim2.fromScale(0.08, 0.9),
                Size = UDim2.fromScale(0.15, 0.15),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                ImageTransparency = u13.HoverLinear:Map(function(p36) --[[ Line: 394 ]]
                    return p36 / 2;
                end)
            }, {
                Title = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    ZIndex = 2,
                    AnchorPoint = Vector2.new(0, 0.5),
                    FontFace = Font.new("rbxassetid://12187375422"),
                    Position = UDim2.fromScale(1.2, 0.5),
                    Size = UDim2.fromScale(10, 1.5),
                    Text = l__Option__2.Robux,
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = Enum.TextXAlignment.Left,
                    TextTransparency = u13.HoverLinear:Map(function(p37) --[[ Line: 411 ]]
                        return p37 / 2;
                    end)
                })
            }),
            Value = v17,
            IconContainer = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ClipsDescendants = true,
                Size = UDim2.fromScale(1, 1)
            }, {
                Icon = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Image = l__Option__2.Image,
                    Position = UDim2.fromScale(0.75, 0.55),
                    Size = u13.HoverLinear:Map(function(p38) --[[ Line: 430 ]]
                        local v39 = p38 / 2 + 1.4;
                        return UDim2.fromScale(v39, v39);
                    end),
                    SizeConstraint = Enum.SizeConstraint.RelativeYY
                }, {
                    UIGradient = u2.createElement("UIGradient", {
                        Rotation = 90,
                        Transparency = NumberSequence.new({
                            NumberSequenceKeypoint.new(0, 1),
                            NumberSequenceKeypoint.new(0.198376, 0.84375),
                            NumberSequenceKeypoint.new(0.50116, 0),
                            NumberSequenceKeypoint.new(0.726218, 0.48125),
                            NumberSequenceKeypoint.new(1, 1)
                        })
                    })
                })
            }),
            u2.createFragment(v16),
            v18
        }) });
end;
return v6;