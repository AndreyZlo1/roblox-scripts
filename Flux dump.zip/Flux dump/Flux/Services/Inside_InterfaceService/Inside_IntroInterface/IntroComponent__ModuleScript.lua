-- Services.InterfaceService.IntroInterface.IntroComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local _, u1 = shared.import("require", "Roact");
local u2 = Font.new("rbxasset://fonts/families/RobotoCondensed.json");
local u3 = Font.new("rbxasset://fonts/families/Oswald.json");
local v4 = u1.Component:extend("Intro");
function v4.init(p5, p6) --[[ Line: 8 ]]
    p5.Transparency = p6.Transparency;
    p5.StartFlash = p6.StartFlash;
    p5.Button = p6.Button;
end;
function v4.render(p7) --[[ Line: 14 ]]
    -- upvalues: u1 (copy), u3 (copy), u2 (copy)
    return u1.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 1),
        BackgroundColor3 = Color3.new(0, 0, 0)
    }, { u1.createElement("Frame", {
            BorderSizePixel = 0,
            Position = UDim2.fromScale(0.5, 0),
            AnchorPoint = Vector2.new(0.5, 0),
            Size = UDim2.fromScale(10, 0.15),
            BackgroundColor3 = Color3.new(0, 0, 0)
        }), u1.createElement("Frame", {
            BorderSizePixel = 0,
            Position = UDim2.fromScale(0.5, 1),
            AnchorPoint = Vector2.new(0.5, 1),
            Size = UDim2.fromScale(10, 0.15),
            BackgroundColor3 = Color3.new(0, 0, 0)
        }, { u1.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextTransparency = 0.5,
                TextScaled = true,
                TextXAlignment = Enum.TextXAlignment.Center,
                Size = UDim2.fromScale(1, 0.2),
                Position = UDim2.fromScale(0.5, -0.1),
                AnchorPoint = Vector2.new(0.5, 1),
                Text = "© " .. os.date("%Y") .. " GameLoaded Entertainment\nDeveloped by the PLATINUM FIVE team. All Rights Reserved.",
                TextColor3 = Color3.new(1, 1, 1),
                FontFace = u3
            }) }), u1.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://13866506142",
            Size = UDim2.fromScale(0.4, 0.1),
            Position = UDim2.fromScale(0.25, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            ImageColor3 = Color3.new(1, 1, 1),
            ImageTransparency = p7.Transparency
        }, { u1.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                TextXAlignment = Enum.TextXAlignment.Left,
                Size = UDim2.fromScale(1, 0.25),
                Position = UDim2.fromScale(0.01, 1),
                Text = p7.Button:upper(),
                TextColor3 = Color3.new(1, 1, 1),
                TextTransparency = p7.Transparency,
                Visible = p7.StartFlash,
                FontFace = u2
            }) }) });
end;
return v4;