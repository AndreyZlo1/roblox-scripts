-- Services.InterfaceService.NotifyInterface.NotifyComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local _, u1 = shared.import("require", "Roact");
local v2 = u1.Component:extend("Radial");
function v2.init(p3, p4) --[[ Line: 6 ]]
    p3.Container = p4.Container;
end;
function v2.render(p5) --[[ Line: 10 ]]
    -- upvalues: u1 (copy)
    return u1.createElement("Frame", {
        AnchorPoint = Vector2.new(0.5, 0),
        Position = UDim2.new(0.5, 0, 0, 0),
        Size = UDim2.new(0, 0, 1, 0),
        BackgroundTransparency = 1,
        [u1.Ref] = p5.Container
    }, {
        u1.createElement("UIAspectRatioConstraint", {
            AspectRatio = 1.778,
            AspectType = Enum.AspectType.ScaleWithParentSize,
            DominantAxis = Enum.DominantAxis.Height
        }),
        Notifications = u1.createElement("Frame", {
            BackgroundTransparency = 1,
            Position = UDim2.new(0, 0, 0.65, 0),
            Size = UDim2.new(1, 0, 1, 0)
        }, {
            List = u1.createElement("UIListLayout", {
                Padding = UDim.new(0.01, 0),
                FillDirection = Enum.FillDirection.Vertical,
                HorizontalAlignment = Enum.HorizontalAlignment.Center,
                SortOrder = Enum.SortOrder.LayoutOrder,
                VerticalAlignment = Enum.VerticalAlignment.Top
            }),
            u1.createFragment(p5.props.Notifications)
        })
    });
end;
return v2;