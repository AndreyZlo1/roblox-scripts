-- Services.InterfaceService.InteractionInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4, u5 = shared.import("require", "network", "Roact", "Enum", "server");
local l__ProximityPromptService__1 = game:GetService("ProximityPromptService");
local l__HttpService__2 = game:GetService("HttpService");
local l__Players__3 = game:GetService("Players");
local u6 = v1("GameShellProxyService");
local u7 = v1("InputService");
local u8 = v1("NotifyInterface");
local u9 = v1("RoactTween");
local u10 = v1("ReplicatorService");
local u11 = v1("InteractionComponent");
local l__LocalPlayer__4 = l__Players__3.LocalPlayer;
local l__CurrentCamera__5 = workspace.CurrentCamera;
local u12 = {};
u12.__index = u12;
function u12._update(p13) --[[ Line: 32 ]]
    -- upvalues: u3 (copy), u11 (copy)
    local v14;
    if p13._toggleControls then
        v14 = p13._visible or false;
    else
        v14 = false;
    end;
    p13._handle = u3.update(p13._handle, u3.createElement(u11, {
        ActionText = p13._actionText,
        Visible = v14,
        Gamepad = p13._gamepad,
        Touch = p13._touch,
        Key = p13._key,
        Icon = p13._icon
    }));
end;
function u12._getInput(p15) --[[ Line: 44 ]]
    -- upvalues: u7 (copy)
    local v16, v17 = u7:GetBind("Interact");
    p15._key = v16;
    p15._gamepad = v17;
    p15._touch = u7.Touch;
    p15:_update();
end;
function u12._showPrompt(p18, p19) --[[ Line: 52 ]]
    -- upvalues: l__HttpService__2 (copy), l__LocalPlayer__4 (copy), u7 (copy)
    local v20 = p19:GetAttribute("Whitelist");
    if v20 then
        local v21 = l__HttpService__2:JSONDecode(v20);
        if v21 and not table.find(v21, l__LocalPlayer__4.UserId) then
            p19:Destroy();
            return;
        end;
    end;
    p18._prompt = p19;
    p18._visible = true;
    if p18._breachToolEquipped and p19:GetAttribute("BreachTool") then
        p18._actionText = "Breach Door";
    else
        p18._actionText = p19.ActionText;
    end;
    p18._icon = #p19.ObjectText > 0 and p19.ObjectText or "rbxassetid://15216745928";
    p18:_update();
    u7.PromptOpen = true;
    p18._showTween:SetValue(0);
    p18._showTween:SetGoal(1);
end;
function u12.new() --[[ Line: 76 ]]
    -- upvalues: u9 (copy), u4 (copy), u3 (copy), u6 (copy), u7 (copy), u11 (copy), u12 (copy), l__ProximityPromptService__1 (copy)
    local v22 = u9.new(0);
    local v23 = u9.new(0, TweenInfo.new(1, u4.EasingStyle.Exponential, u4.EasingDirection.Out, 0, false, 0));
    local v24, v25 = u3.createBinding(UDim2.fromScale(0, 0));
    local v26 = u6:CreateProxy(1, u4.ShellPriority.AlwaysVisible, "InteractionInterface");
    local v27, v28 = u7:GetBind("Interact");
    local l__Touch__6 = u7.Touch;
    local v29 = {
        _icon = "",
        _visible = false,
        _actionText = "",
        _handle = u3.mount(u3.createElement(u11, {
            Visible = false,
            ActionText = "",
            Icon = "",
            PromptProgress = v22,
            PositionBinding = v24,
            ShowTween = v23,
            Gamepad = v28,
            Touch = l__Touch__6,
            Key = v27
        }), v26),
        _promptProgress = v22,
        _showTween = v23,
        _touch = l__Touch__6,
        _gamepad = v28,
        _key = v27,
        _updatePosition = v25
    };
    local u30 = setmetatable(v29, u12);
    u7.BindingsChanged:Connect(function() --[[ Line: 110 ]]
        -- upvalues: u30 (copy)
        u30:_getInput();
    end);
    u7.GamepadInput:Connect(function() --[[ Line: 114 ]]
        -- upvalues: u30 (copy)
        u30:_getInput();
    end);
    u7.TouchInput:Connect(function() --[[ Line: 118 ]]
        -- upvalues: u30 (copy)
        u30:_getInput();
    end);
    l__ProximityPromptService__1.PromptShown:Connect(function(p31) --[[ Line: 122 ]]
        -- upvalues: u30 (copy)
        u30:_showPrompt(p31);
    end);
    l__ProximityPromptService__1.PromptHidden:Connect(function(p32) --[[ Line: 126 ]]
        -- upvalues: u30 (copy), u7 (ref)
        if u30._prompt == p32 then
            u30._prompt = nil;
            u30._visible = false;
            u30:_update();
            u7.PromptOpen = false;
        end;
    end);
    return u30;
end;
function u12._processPrompt(p33, p34, p35, p36, p37) --[[ Line: 139 ]]
    -- upvalues: u4 (copy), u8 (copy), u5 (copy), u2 (copy)
    local l__Name__7 = p34.Name;
    local v38 = p34:GetAttribute("BreachTool");
    if v38 then
        if not p33._breachToolEquipped then
            v38 = l__Name__7;
        end;
    else
        v38 = l__Name__7;
    end;
    if v38 == "Ladder" then
        if p35 then
            if p35.Ladder then
                p35.Ladder = nil;
            elseif p35.HeightState == u4.CharacterHeightState.Standing and p35.CurrentState.Emote == nil then
                p35.Ladder = p34.Parent.Parent;
            else
                u8:Notify({
                    { "Alert", "You must be standing to perform this action", Color3.new(1, 0.866666, 0.505882) }
                });
            end;
        end;
    elseif v38 == "Bipod" then
        if p35 and not u5.IS_PVP then
            p35:Action(u4.ActionType.Inventory, "BipodUse");
        end;
    else
        if v38 == "PickUp" then
            u2:FireServer("InventoryPickUp", p34.Parent.Name);
            return;
        end;
        if v38 == "BodyBag" then
            u2:FireServer("BodyBag", p34:GetAttribute("Body"), p36);
            return;
        end;
        if v38 == "TakeDown" then
            u2:FireServer("TakeDown", p34:GetAttribute("Body"));
            return;
        end;
        if v38 == "DragDowned" then
            u2:FireServer("DragDowned", p34:GetAttribute("Body"));
            return;
        end;
        if v38 == "Drone" then
            u2:FireServer("InventoryAction", "Retrieve");
            return;
        end;
        u2:FireServer("Interact", v38, p37 or -1, p36);
    end;
end;
function u12.Enable(u39) --[[ Line: 181 ]]
    -- upvalues: u7 (copy), u10 (copy), u4 (copy)
    if u39._toggleControls then
    else
        u39._toggleControls = u7:Connect({
            Interact = function(p40) --[[ Name: Interact, Line 187 ]]
                -- upvalues: u39 (copy), u7 (ref), u10 (ref), u4 (ref)
                if not p40 then
                    u39:_cancelTask(true);
                end;
                if p40 and (u39._prompt and not u7.PauseOpen) then
                    local l__LocalActor__8 = u10.LocalActor;
                    if l__LocalActor__8 and l__LocalActor__8.Downed then
                        return;
                    end;
                    local l___prompt__9 = u39._prompt;
                    local v41 = l___prompt__9:GetAttribute("Timer");
                    if v41 then
                        local v42 = l___prompt__9:GetAttribute("Analogue");
                        local v43 = tick();
                        u39.PromptTask = {
                            Prompt = l___prompt__9,
                            Started = v43,
                            Finish = v43 + v41,
                            Last = v43,
                            Analogue = v42
                        };
                        u39:_processPrompt(l___prompt__9, l__LocalActor__8, u4.InteractionState.Started);
                    else
                        u39:_processPrompt(l___prompt__9, l__LocalActor__8);
                    end;
                    local l___showTween__10 = u39._showTween;
                    l___showTween__10:SetValue(0.5);
                    l___showTween__10:SetGoal(1);
                end;
            end
        });
        u39:_update();
    end;
end;
function u12._cancelTask(p44, p45) --[[ Line: 224 ]]
    -- upvalues: u4 (copy), u10 (copy)
    local l__PromptTask__11 = p44.PromptTask;
    if l__PromptTask__11 then
        p44.PromptTask = nil;
        if not l__PromptTask__11.Finished then
            local l__Failed__12 = u4.InteractionState.Failed;
            if p45 and (l__PromptTask__11.Analogue and tick() <= l__PromptTask__11.Started + 0.2) then
                l__Failed__12 = u4.InteractionState.Finished;
            end;
            p44:_processPrompt(l__PromptTask__11.Prompt, u10.LocalActor, l__Failed__12);
        end;
    end;
end;
function u12.Disable(p46) --[[ Line: 239 ]]
    p46:_cancelTask();
    if p46._toggleControls then
        p46._toggleControls:Disconnect();
        p46._toggleControls = nil;
        p46._isPressed = false;
        p46:_update();
    end;
end;
function u12.Update(p47, _) --[[ Line: 252 ]]
    -- upvalues: u10 (copy), l__LocalPlayer__4 (copy), u4 (copy), l__CurrentCamera__5 (copy)
    local v48 = tick();
    local l__LocalActor__13 = u10.LocalActor;
    local l___prompt__14 = p47._prompt;
    if l__LocalActor__13 and l__LocalActor__13.BreachToolEquipped ~= p47._breachToolEquipped then
        p47._breachToolEquipped = l__LocalActor__13.BreachToolEquipped;
        if l___prompt__14 and l___prompt__14:GetAttribute("BreachTool") then
            p47:_showPrompt(l___prompt__14);
        end;
    end;
    local l__PromptTask__15 = p47.PromptTask;
    local v49 = 0;
    if l__PromptTask__15 then
        if p47._toggleControls and l___prompt__14 == l__PromptTask__15.Prompt then
            v49 = math.min(1, (v48 - l__PromptTask__15.Started) / (l__PromptTask__15.Finish - l__PromptTask__15.Started));
            if not l__PromptTask__15.Finished then
                if l__PromptTask__15.Finish - l__LocalPlayer__4:GetNetworkPing() < v48 then
                    l__PromptTask__15.Finished = true;
                    p47:_processPrompt(l__PromptTask__15.Prompt, l__LocalActor__13, u4.InteractionState.Finished, l__PromptTask__15.Analogue and 1 or nil);
                elseif l__PromptTask__15.Analogue and (l__PromptTask__15.Started + 0.2 < v48 and l__PromptTask__15.Last + 0.05 < v48) then
                    l__PromptTask__15.Last = v48;
                    p47:_processPrompt(l__PromptTask__15.Prompt, l__LocalActor__13, u4.InteractionState.InProgress, v49);
                end;
            end;
        else
            p47:_cancelTask();
        end;
    end;
    if l___prompt__14 then
        local v50 = l__CurrentCamera__5:WorldToViewportPoint(l___prompt__14.Parent.WorldPosition);
        p47._updatePosition(UDim2.fromOffset(v50.X, v50.Y));
        p47._promptProgress:SetValue(v49);
    end;
end;
return u12.new();