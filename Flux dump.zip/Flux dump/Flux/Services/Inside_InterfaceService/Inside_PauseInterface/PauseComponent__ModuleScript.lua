-- Services.InterfaceService.PauseInterface.PauseComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "server");
local u4 = v1("RoactTween");
local u5 = v1("SoundService");
local u6 = v1("MenuHeaderComponent");
local u7 = v1({
    "MenuMapComponent",
    "MenuPlayersComponent",
    "MenuStoreComponent",
    "MenuLoadoutPvPComponent",
    "MenuOptionsComponent"
});
local v8 = u2.Component:extend("Pause");
function v8.init(p9, p10) --[[ Line: 17 ]]
    -- upvalues: u4 (copy), u3 (copy)
    p9._logoTween = p10.LogoTween;
    p9._moneyBinding = p10.MoneyBinding;
    p9._expBinding = p10.ExpBinding;
    p9.ExpandedTween = u4.new(1);
    local v11 = u3.IS_PVP and {
        "Players",
        "LoadoutPvP",
        "Store",
        "Options"
    } or {
        "Map",
        "Players",
        "Store",
        "Options"
    };
    p9:setState({
        Page = v11[1],
        Pages = v11
    });
end;
function v8.willUnmount(_) --[[ Line: 46 ]]
    -- upvalues: u5 (copy)
    u5.DiegeticMix.Pause = 1;
end;
function v8.render(u12) --[[ Line: 50 ]]
    -- upvalues: u5 (copy), u2 (copy), u7 (copy), u6 (copy)
    local l__props__1 = u12.props;
    local l__state__2 = u12.state;
    local l__PopupActive__3 = l__props__1.PopupActive;
    u5.DiegeticMix.Pause = l__props__1.Enabled and 0.5 or 1;
    local l__Enabled__4 = l__props__1.Enabled;
    if l__Enabled__4 then
        l__Enabled__4 = u2.createFragment({
            Page = u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundTransparency = 0.15,
                Size = UDim2.fromScale(1, 0.85),
                Position = UDim2.fromScale(0, 0.15),
                BackgroundColor3 = Color3.new(0, 0, 0)
            }, u2.createElement(u7["Menu" .. l__state__2.Page .. "Component"], {
                PopupActive = l__PopupActive__3
            })),
            Header = u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundTransparency = 0.15,
                ZIndex = 2,
                Size = UDim2.fromScale(1, 0.15),
                BackgroundColor3 = Color3.new(0, 0, 0)
            }, u2.createElement(u6, {
                LogoTween = u12._logoTween,
                MoneyBinding = u12._moneyBinding,
                ExpBinding = u12._expBinding,
                PopupActive = l__PopupActive__3,
                ExpandedTween = u12.ExpandedTween,
                Page = l__state__2.Page,
                Pages = l__state__2.Pages,
                ChangePage = function(p13) --[[ Name: ChangePage, Line 82 ]]
                    -- upvalues: u12 (copy)
                    u12:setState({
                        Page = p13
                    });
                end
            }))
        });
    end;
    return l__Enabled__4;
end;
return v8;