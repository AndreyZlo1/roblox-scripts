-- Services.InterfaceService.OverlayInterface.BinocularsOverlay
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
v1("PostProcessingService");
game:GetService("RunService");
local v3 = u2.Component:extend("Overlay");
Color3.new(1, 0, 0);
function v3.init(p4, p5) --[[ Line: 12 ]]
    p4.lerp = p5.Lerp;
    p4.zoom = p5.Zoom;
    p4.magnify = p5.Magnify;
end;
function v3.willUnmount(_) --[[ Line: 18 ]] end;
function v3.render(p6) --[[ Line: 22 ]]
    -- upvalues: u2 (copy)
    local _ = p6.props;
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 1)
    }, { u2.createElement("ImageLabel", {
            BorderSizePixel = 0,
            BackgroundTransparency = 1,
            Image = "rbxassetid://136858141195126",
            ZIndex = 2,
            Size = UDim2.fromScale(2, 2),
            Position = UDim2.fromScale(0.5, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            ImageTransparency = p6.lerp:Map(function(p7) --[[ Line: 35 ]]
                return 1 - p7;
            end),
            ImageColor3 = Color3.new(0, 0, 0)
        }, { u2.createElement("ImageLabel", {
                BorderSizePixel = 0,
                BackgroundTransparency = 1,
                Image = "rbxassetid://104025870446839",
                Size = p6.zoom:Map(function(_) --[[ Line: 44 ]]
                    local v8 = 0.05 / (workspace.CurrentCamera.FieldOfView / 70);
                    return UDim2.fromScale(v8, v8);
                end),
                Position = UDim2.fromScale(0.5, 0.5),
                AnchorPoint = Vector2.new(0.5, 0.5),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                ImageColor3 = Color3.new(0, 0, 0)
            }), u2.createElement("Frame", {
                BorderSizePixel = 0,
                Size = UDim2.fromScale(10, 1),
                Position = UDim2.fromScale(1, 0),
                BackgroundColor3 = Color3.new(),
                BackgroundTransparency = p6.lerp:Map(function(p9) --[[ Line: 61 ]]
                    return 1 - p9;
                end)
            }), u2.createElement("Frame", {
                BorderSizePixel = 0,
                Size = UDim2.fromScale(10, 1),
                Position = UDim2.fromScale(0, 0),
                AnchorPoint = Vector2.new(1, 0),
                BackgroundColor3 = Color3.new(),
                BackgroundTransparency = p6.lerp:Map(function(p10) --[[ Line: 71 ]]
                    return 1 - p10;
                end)
            }) }) });
end;
return v3;