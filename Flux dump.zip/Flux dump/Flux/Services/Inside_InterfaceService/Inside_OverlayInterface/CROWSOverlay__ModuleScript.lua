-- Services.InterfaceService.OverlayInterface.CROWSOverlay
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local u3 = v1("PostProcessingService");
local l__RunService__1 = game:GetService("RunService");
local u4 = v1("convertUnit");
local v5 = u2.Component:extend("Overlay");
local u6 = Color3.new(1, 0, 0);
function v5.init(p7, p8) --[[ Line: 14 ]]
    -- upvalues: u2 (copy), l__RunService__1 (copy), u3 (copy)
    local v9, u10 = u2.createBinding(Vector2.new());
    p7.offset = v9;
    p7.ballistic = p8.Ballistic;
    p7.elev = p8.Elev;
    p7.fov = p8.FOV;
    p7.lowAmmo = p8.LowAmmo;
    p7.armed = p8.Armed;
    p7.compass = p8.Compass;
    p7.update = l__RunService__1.Heartbeat:Connect(function() --[[ Line: 23 ]]
        -- upvalues: u10 (copy)
        u10(Vector2.new(math.random(), math.random()));
    end);
    p7.blur = u3:AddBlur({
        Size = p8.Blur:Map(function(p11) --[[ Line: 27 ]]
            return p11 * 15;
        end)
    }, nil, true);
end;
function v5.willUnmount(p12) --[[ Line: 33 ]]
    p12.blur.Destroy();
    p12.update:Disconnect();
end;
function v5.render(p13) --[[ Line: 38 ]]
    -- upvalues: u2 (copy), u6 (copy), u4 (copy)
    local _ = p13.props;
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 1)
    }, { u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://73577146256840",
            ImageTransparency = 0.7,
            ScaleType = Enum.ScaleType.Tile,
            ImageColor3 = Color3.fromRGB(109, 109, 109),
            TileSize = UDim2.fromOffset(1024, 1024),
            Size = UDim2.fromScale(10, 10),
            Position = p13.offset:map(function(p14) --[[ Line: 53 ]]
                return UDim2.fromScale(p14.X * 5, p14.Y * 5);
            end),
            AnchorPoint = p13.offset:map(function(p15) --[[ Line: 56 ]]
                return p15;
            end)
        }), u2.createElement("ImageLabel", {
            BorderSizePixel = 0,
            BackgroundTransparency = 1,
            Image = "rbxassetid://17630669039",
            ZIndex = 2,
            Size = UDim2.fromScale(1, 1),
            Position = UDim2.fromScale(0.5, 0),
            AnchorPoint = Vector2.new(0.5, 0),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            ImageColor3 = Color3.new(0, 0, 0)
        }, {
            u2.createElement("Frame", {
                BorderSizePixel = 0,
                Size = UDim2.fromScale(10, 1),
                Position = UDim2.fromScale(1, 0),
                BackgroundColor3 = Color3.new()
            }),
            u2.createElement("Frame", {
                BorderSizePixel = 0,
                Size = UDim2.fromScale(10, 1),
                Position = UDim2.fromScale(0, 0),
                AnchorPoint = Vector2.new(1, 0),
                BackgroundColor3 = Color3.new()
            }),
            u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://118732957236033",
                ImageTransparency = 0.5,
                ImageColor3 = u6,
                AnchorPoint = Vector2.new(0.5, 0.5),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                Size = UDim2.fromScale(0.42, 0.42),
                Position = UDim2.fromScale(0.5, 0.5)
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "ARMED",
                TextTransparency = 0.5,
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.fromScale(0.75, 0.45),
                Size = UDim2.fromScale(1, 0.03),
                Font = Enum.Font.Arial,
                TextColor3 = u6,
                Visible = p13.armed,
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "Low Ammo",
                TextTransparency = 0.5,
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.fromScale(0.75, 0.65),
                Size = UDim2.fromScale(1, 0.03),
                Font = Enum.Font.Arial,
                TextColor3 = u6,
                Visible = p13.lowAmmo,
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextTransparency = 0.5,
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.fromScale(0.03, 0.62),
                Size = UDim2.fromScale(1, 0.03),
                Font = Enum.Font.Arial,
                Text = p13.ballistic:map(function(p16) --[[ Line: 126 ]]
                    -- upvalues: u4 (ref)
                    return "Ballistic: " .. u4(p16);
                end),
                TextColor3 = u6,
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextTransparency = 0.5,
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.fromScale(0.03, 0.65),
                Size = UDim2.fromScale(1, 0.03),
                Font = Enum.Font.Arial,
                Text = p13.fov:map(function(p17) --[[ Line: 140 ]]
                    return "FOV " .. string.format("%.1f", p17);
                end),
                TextColor3 = u6,
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextTransparency = 0.5,
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.fromScale(0.03, 0.68),
                Size = UDim2.fromScale(1, 0.03),
                Font = Enum.Font.Arial,
                Text = p13.elev:map(function(p18) --[[ Line: 154 ]]
                    return "Elev: " .. math.round(p18) .. "(0)    ";
                end),
                TextColor3 = u6,
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://130961358437573",
                ImageTransparency = 0.5,
                ImageColor3 = u6,
                AnchorPoint = Vector2.new(0, 1),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                Size = UDim2.fromScale(0.13, 0.13),
                Position = UDim2.fromScale(0.03, 0.85)
            }, { u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Size = UDim2.fromScale(0.03, 0.03),
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Position = UDim2.fromScale(0.5, 0.5),
                    Rotation = p13.compass:map(function(p19) --[[ Line: 177 ]]
                        return p19 - 90;
                    end)
                }, { u2.createElement("Frame", {
                        BackgroundTransparency = 0.5,
                        BorderSizePixel = 0,
                        BackgroundColor3 = u6,
                        Size = UDim2.fromScale(16.5, 1)
                    }) }) })
        }) });
end;
return v5;