-- Services.InterfaceService.OverlayInterface.ExtractionOverlay
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "asset");
local u4 = v1("VehicleService");
local u5 = v1("ClientService");
local u6 = v1("InputService");
local u7 = v1("RoactTween");
local u8 = v1("formatNumber");
local u9 = v1("convertUnit");
local u10 = v1("SoundService");
local u11 = v1("Quests");
local u12 = v1("ExtractionGrades");
local l__Players__1 = game:GetService("Players");
local l__RunService__2 = game:GetService("RunService");
local l__UserInputService__3 = game:GetService("UserInputService");
local l__CurrentCamera__4 = workspace.CurrentCamera;
local l__LocalPlayer__5 = l__Players__1.LocalPlayer;
local v13 = u2.Component:extend("Extraction");
local u14 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Italic);
local u15 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Italic);
local u16 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u17 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u18 = {
    CFrame.new(0, 50, -12.367) * CFrame.Angles(-1.5707963267948966, 0, 0),
    CFrame.new(7.65, 2.076, 5.483),
    CFrame.new(20.196, -2.024, -12.017) * CFrame.Angles(0, 1.5707963267948966, 0),
    CFrame.new(-0.004, 0.126, -20.217) * CFrame.Angles(0.3490658503988659, 3.141592653589793, 0),
    CFrame.new(9.959, -1.073, -19.461) * CFrame.Angles(-0.08726646259971647, 1.9198621771937625, 0)
};
local u19 = {
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "#",
    "$",
    "%",
    "&",
    "@"
};
local function u25(p20, p21) --[[ Line: 36 ]]
    -- upvalues: u19 (copy)
    if p21 > 1 then
        return p20;
    end;
    local v22 = math.floor(#p20 * (1 - p21));
    local v23 = "";
    for v24 = 1, #p20 do
        if v22 < v24 then
            v23 = v23 .. p20:sub(v24, v24);
        else
            v23 = v23 .. u19[math.random(1, #u19)];
        end;
    end;
    return v23;
end;
function v13.init(u26, u27) --[[ Line: 53 ]]
    -- upvalues: u7 (copy), u10 (copy), u5 (copy), u4 (copy), u18 (copy), u12 (copy), u3 (copy), u2 (copy), l__RunService__2 (copy), l__UserInputService__3 (copy)
    u26.lerp = u7.new(0, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0));
    u26.lerp:SetGoal(1);
    u10:CreateSound("GameMusic", nil, true, "Scorecard", "Intro", "Whoosh").Destroy(10);
    u26.scorecard = u7.new(0, TweenInfo.new(6, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0));
    local u28 = {};
    for v29, v30 in u27.Pages do
        u28[v29] = {
            Open = u7.new(0, TweenInfo.new(1.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0)),
            Tween = u7.new(0, TweenInfo.new(1.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0)),
            Type = v30[1],
            Data = v30[2]
        };
    end;
    u26.Pages = u28;
    local u31 = tick() + 2;
    local u32 = tick() + 1;
    local u33 = 0;
    local u34 = false;
    local u35 = false;
    local l__Actor__6 = u5.LocalClient.Actor;
    local v36;
    if l__Actor__6 then
        v36 = l__Actor__6.Seat;
    else
        v36 = l__Actor__6;
    end;
    local v37;
    if v36 then
        v37 = u4:GetVehicle(v36.UID);
    else
        v37 = nil;
    end;
    local u38 = {};
    for v39 = 2, #u18 do
        u38[#u38 + 1] = u18[v39];
    end;
    if v37 then
        local v40 = Instance.new("Attachment");
        v40.Parent = v37.Hitbox;
        v40.CFrame = u18[1];
        u26.attachment = v40;
    end;
    local v41 = 0;
    local u42 = "Normal";
    local u43 = "F";
    for _, v44 in u28[1].Data[1] do
        v41 = v41 + v44[3];
    end;
    for v45, v46 in u12 do
        local v47 = v46[4];
        if v47 and v47 <= v41 then
            u42 = (v41 - v47) / ((u12[v45 - 1] and u12[v45 - 1][4] or v47 + 500) - v47) > 0.66 and "Plus" or u42;
            u43 = v46[1];
            break;
        end;
    end;
    u3:Get("Sound", "Scorecard", "Grades", u43, u42):Preload();
    local v48, v49 = u2.createBinding(0);
    u26.timer = v48;
    u26.updateTimer = v49;
    local v50, v51 = u2.createBinding(false);
    u26.skip = v50;
    u26.updateSkip = v51;
    u26.conn = l__RunService__2.RenderStepped:Connect(function(_) --[[ Line: 121 ]]
        -- upvalues: u10 (ref), u26 (copy), l__UserInputService__3 (ref), u35 (ref), u27 (copy), u32 (ref), u34 (ref), u28 (copy), u33 (ref), u38 (copy), u43 (ref), u42 (ref), u31 (ref), l__Actor__6 (copy)
        u10.DiegeticMix.Extraction = 1 - u26.lerp:GetValue() * 0.8;
        local v52 = tick();
        local v53 = l__UserInputService__3:IsKeyDown(Enum.KeyCode.Space) or l__UserInputService__3:IsKeyDown(Enum.KeyCode.ButtonA);
        if u35 then
            if u26.lerp:GetValue() < 1e-6 then
                u26.conn:Disconnect();
                u27.Ended:Fire();
            end;
        elseif u32 < v52 or u34 and v53 then
            if v53 and u26.track then
                u26.track.FadeOut(4);
            end;
            u34 = false;
            local u54 = u28[u33];
            if u54 then
                u54.Tween:SetGoal(0);
            end;
            local u55 = u28[u33 + 1];
            if u55 then
                if u26.attachment and u54 then
                    local v56 = math.random(1, #u38);
                    u26.attachment.CFrame = u38[v56];
                    table.remove(u38, v56);
                end;
                task.delay(1, function() --[[ Line: 152 ]]
                    -- upvalues: u54 (copy), u26 (ref), u55 (copy), u34 (ref)
                    if not u54 then
                        u26.scorecard:SetGoal(1);
                    end;
                    u55.Open:SetGoal(1);
                    u55.Tween:SetGoal(1);
                    u34 = true;
                end);
                if not u54 then
                    u26.track = u10:CreateSound("GameMusic", nil, true, "Scorecard", "Grades", u43, u42);
                end;
                u31 = v52 + 1;
                u32 = v52 + 20;
                u33 = u33 + 1;
            else
                u35 = true;
                u26.lerp:SetGoal(0);
            end;
        end;
        if u35 or (u31 >= u32 or u31 >= v52) then
            u26.updateTimer(0);
        else
            u26.updateTimer((v52 - u31) / (u32 - u31));
        end;
        u26.updateSkip(u34);
        if u26.attachment then
            l__Actor__6.Camera = u26.attachment;
            l__Actor__6.CameraLerp = u26.lerp:GetValue();
        end;
    end);
end;
function v13.willUnmount(p57) --[[ Line: 187 ]]
    -- upvalues: u5 (copy), u10 (copy)
    if p57.track then
        p57.track.Destroy();
    end;
    local l__Actor__7 = u5.LocalClient.Actor;
    if l__Actor__7 then
        l__Actor__7.CameraLerp = nil;
    end;
    if p57.attachment then
        p57.attachment:Destroy();
    end;
    p57.conn:Disconnect();
    u10.DiegeticMix.Extraction = nil;
end;
function v13.render(p58) --[[ Line: 202 ]]
    -- upvalues: u11 (copy), u2 (copy), u17 (copy), u16 (copy), l__LocalPlayer__5 (copy), u14 (copy), u15 (copy), l__CurrentCamera__4 (copy), u9 (copy), u12 (copy), u25 (copy), u8 (copy), u6 (copy)
    local v59 = {};
    for v60, u61 in p58.Pages do
        local v62 = {};
        if u61.Type == "Mission" then
            local v63 = u11.QuestData[u61.Data[3][1]];
            local v64 = u11.QuestGivers[u61.Data[3][2]];
            v62.Header = u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundTransparency = u61.Tween:Map(function(p65) --[[ Line: 210 ]]
                    return 1 - p65;
                end),
                BackgroundColor3 = Color3.fromRGB(190, 190, 190),
                Size = UDim2.fromScale(1, 0.125)
            }, { u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AutoLocalize = false,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.fromScale(0, 0.15),
                    Size = UDim2.fromScale(1, 0.5),
                    FontFace = u17,
                    Text = "MISSION (" .. u61.Data[1] .. "/" .. u61.Data[2] .. ")",
                    TextColor3 = Color3.new(1, 1, 1),
                    TextTransparency = u61.Tween:Map(function(p66) --[[ Line: 226 ]]
                        return 1 - p66;
                    end),
                    TextXAlignment = Enum.TextXAlignment.Center
                }), u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AutoLocalize = false,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.fromScale(0, 0.6),
                    Size = UDim2.fromScale(1, 0.25),
                    FontFace = u16,
                    Text = v63.Name:upper(),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextTransparency = u61.Tween:Map(function(p67) --[[ Line: 241 ]]
                        return 1 - p67;
                    end),
                    TextXAlignment = Enum.TextXAlignment.Center
                }), u2.createElement("UIGradient", {
                    Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(0, 174, 255)), ColorSequenceKeypoint.new(0.62, Color3.fromRGB(54, 67, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(25, 25, 25)) }),
                    Transparency = NumberSequence.new({
                        NumberSequenceKeypoint.new(0, 1),
                        NumberSequenceKeypoint.new(0.1, 0.73),
                        NumberSequenceKeypoint.new(0.43, 0.225),
                        NumberSequenceKeypoint.new(0.885, 0.73),
                        NumberSequenceKeypoint.new(1, 1)
                    }),
                    Rotation = u61.Open:Map(function(p68) --[[ Line: 260 ]]
                        return 90 - 83 * p68;
                    end)
                }) });
            local u69 = false;
            local v70 = 0.13;
            local v71 = {
                { "Status", u61.Data[4] },
                { "", u61.Data[5] }
            };
            if u61.Data[4] == 1 then
                local v72 = u61.Data[6][tostring(l__LocalPlayer__5.UserId)];
                if v72 then
                    v71[3] = { "Rewards", "" };
                    for v73, v74 in v72 do
                        v71[#v71 + 1] = { v74[1], v74[2], v73 > 2 };
                    end;
                end;
            end;
            for v75, v76 in v71 do
                local v77 = v76[1] == "Status";
                local v78 = v76[2];
                local v79 = u14;
                local v80 = Color3.new(1, 1, 1);
                if v77 then
                    v79 = u15;
                    v80 = v78 == 1 and Color3.new(0.415686, 0.960784, 0.415686) or (v78 == 2 and Color3.new(1, 0.694117, 0.384313) or Color3.new(0.988235, 0.290196, 0.290196));
                    v78 = v78 == 1 and "SUCCESS" or (v78 == 2 and "SKIPPED" or "FAILED");
                end;
                v62["List" .. v75] = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundTransparency = 1,
                    Position = UDim2.fromScale(0, v70),
                    Size = UDim2.fromScale(1, 0.05)
                }, { u2.createElement("Frame", {
                        BorderSizePixel = 0,
                        BackgroundColor3 = Color3.fromRGB(30, 30, 30),
                        Position = UDim2.fromScale(u69 and 1 or 0, 0),
                        AnchorPoint = Vector2.new(u69 and 1 or 0, 0),
                        BackgroundTransparency = u61.Tween:Map(function(p81) --[[ Line: 306 ]]
                            -- upvalues: u69 (copy)
                            return math.lerp(1, u69 and 0.25 or 0.5, p81);
                        end),
                        Size = u61.Open:Map(function(p82) --[[ Line: 309 ]]
                            return UDim2.fromScale(p82, 1);
                        end)
                    }), u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        ZIndex = 2,
                        AutoLocalize = false,
                        AnchorPoint = Vector2.new(0, 0),
                        Position = UDim2.fromScale(0.05, 0.1),
                        Size = UDim2.fromScale(0.9, 0.8),
                        FontFace = (v77 or v76[1] == "Rewards") and u16 or (v76[3] and u14 or u17),
                        Text = v76[1]:upper(),
                        TextColor3 = Color3.new(1, 1, 1),
                        TextTransparency = u61.Tween:Map(function(p83) --[[ Line: 323 ]]
                            return 1 - p83;
                        end),
                        TextXAlignment = Enum.TextXAlignment.Left
                    }), u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        ZIndex = 2,
                        AutoLocalize = false,
                        AnchorPoint = Vector2.new(0, 0),
                        Position = UDim2.fromScale(0.05, 0.1),
                        Size = UDim2.fromScale(0.9, 0.8),
                        FontFace = v79,
                        Text = v78,
                        TextColor3 = v80,
                        TextTransparency = u61.Tween:Map(function(p84) --[[ Line: 339 ]]
                            return 1 - p84;
                        end),
                        TextXAlignment = Enum.TextXAlignment.Right
                    }) });
                v70 = v70 + 0.055;
                u69 = not u69;
            end;
            if u61.Data[4] == 1 and v63.Debriefing then
                v62.Grade = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundTransparency = u61.Tween:Map(function(p85) --[[ Line: 354 ]]
                        return 1 - p85 * 0.5;
                    end),
                    BackgroundColor3 = Color3.fromRGB(30, 30, 30),
                    Position = UDim2.fromScale(0, v70),
                    Size = UDim2.fromScale(1, 0.38)
                }, { u2.createElement("UIGradient", {
                        Rotation = 90,
                        Transparency = u61.Tween:Map(function(p86) --[[ Line: 362 ]]
                            return NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(p86 * 0.65 + 0.05, 0), NumberSequenceKeypoint.new(1, 1) });
                        end)
                    }), u2.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        Position = UDim2.fromScale(0.05, 0.05),
                        Size = UDim2.fromScale(0.15, 0.15),
                        SizeConstraint = Enum.SizeConstraint.RelativeYY,
                        Image = v64.Icon or "rbxthumb://type=AvatarHeadShot&id=1&w=150&h=150",
                        ImageTransparency = u61.Tween:Map(function(p87) --[[ Line: 377 ]]
                            return 1 - p87;
                        end)
                    }, { u2.createElement("UIStroke", {
                            Thickness = 1,
                            LineJoinMode = Enum.LineJoinMode.Round,
                            Color = Color3.new(1, 1, 1),
                            Transparency = u61.Tween:Map(function(p88) --[[ Line: 384 ]]
                                return 1 - p88;
                            end)
                        }), u2.createElement("TextLabel", {
                            TextScaled = true,
                            BackgroundTransparency = 1,
                            FontFace = u16,
                            Size = UDim2.new(10, 0, 0.5, 0),
                            TextTransparency = u61.Tween:Map(function(p89) --[[ Line: 393 ]]
                                return 1 - p89;
                            end),
                            TextColor3 = Color3.new(1, 1, 1),
                            Text = v63.Name .. " (Debriefing)",
                            Position = UDim2.fromScale(1.25, 0),
                            TextXAlignment = Enum.TextXAlignment.Left
                        }), u2.createElement("TextLabel", {
                            TextScaled = true,
                            BackgroundTransparency = 1,
                            FontFace = u17,
                            Size = UDim2.new(10, 0, 0.5, 0),
                            TextTransparency = u61.Tween:Map(function(p90) --[[ Line: 406 ]]
                                return 1 - p90;
                            end),
                            TextColor3 = Color3.new(1, 1, 1),
                            Text = v64.Name,
                            Position = UDim2.fromScale(1.25, 0.5),
                            TextXAlignment = Enum.TextXAlignment.Left
                        }) }), u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextWrapped = true,
                        RichText = true,
                        AutoLocalize = false,
                        AnchorPoint = Vector2.new(0, 0),
                        Position = UDim2.fromScale(0.05, 0.25),
                        Size = UDim2.fromScale(0.9, 0.8),
                        FontFace = u17,
                        Text = v63.Debriefing,
                        TextColor3 = Color3.new(1, 1, 1),
                        TextSize = l__CurrentCamera__4.ViewportSize.Y * 0.016,
                        TextTransparency = u61.Tween:Map(function(p91) --[[ Line: 426 ]]
                            return 1 - p91;
                        end),
                        TextYAlignment = Enum.TextYAlignment.Top,
                        TextXAlignment = Enum.TextXAlignment.Left
                    }) });
            end;
        elseif u61.Type == "Scorecard" then
            v62.Header = u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundTransparency = u61.Tween:Map(function(p92) --[[ Line: 438 ]]
                    return 1 - p92;
                end),
                BackgroundColor3 = Color3.fromRGB(190, 190, 190),
                Size = UDim2.fromScale(1, 0.125)
            }, { u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "EXFIL",
                    TextScaled = true,
                    AutoLocalize = false,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.fromScale(0, 0.15),
                    Size = UDim2.fromScale(1, 0.5),
                    FontFace = u17,
                    TextColor3 = Color3.new(1, 1, 1),
                    TextTransparency = u61.Tween:Map(function(p93) --[[ Line: 454 ]]
                        return 1 - p93;
                    end),
                    TextXAlignment = Enum.TextXAlignment.Center
                }), u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "SCORE CARD",
                    TextScaled = true,
                    AutoLocalize = false,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.fromScale(0, 0.6),
                    Size = UDim2.fromScale(1, 0.25),
                    FontFace = u16,
                    TextColor3 = Color3.new(1, 1, 1),
                    TextTransparency = u61.Tween:Map(function(p94) --[[ Line: 469 ]]
                        return 1 - p94;
                    end),
                    TextXAlignment = Enum.TextXAlignment.Center
                }), u2.createElement("UIGradient", {
                    Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 170, 0)), ColorSequenceKeypoint.new(0.62, Color3.fromRGB(255, 85, 54)), ColorSequenceKeypoint.new(1, Color3.fromRGB(25, 25, 25)) }),
                    Transparency = NumberSequence.new({
                        NumberSequenceKeypoint.new(0, 1),
                        NumberSequenceKeypoint.new(0.1, 0.73),
                        NumberSequenceKeypoint.new(0.43, 0.225),
                        NumberSequenceKeypoint.new(0.885, 0.73),
                        NumberSequenceKeypoint.new(1, 1)
                    }),
                    Rotation = u61.Open:Map(function(p95) --[[ Line: 488 ]]
                        return 90 - 83 * p95;
                    end)
                }) });
            local u96 = 0;
            local u97 = false;
            local v98 = 0.13;
            for v99, v100 in u61.Data[1] do
                if v100[1] == "Distance Travelled" then
                    v100[2] = u9((tonumber(v100[2])));
                end;
                v62["List" .. v99] = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundTransparency = 1,
                    Position = UDim2.fromScale(0, v98),
                    Size = UDim2.fromScale(1, 0.05)
                }, {
                    u2.createElement("Frame", {
                        BorderSizePixel = 0,
                        BackgroundColor3 = Color3.fromRGB(30, 30, 30),
                        Position = UDim2.fromScale(u97 and 1 or 0, 0),
                        AnchorPoint = Vector2.new(u97 and 1 or 0, 0),
                        BackgroundTransparency = u61.Tween:Map(function(p101) --[[ Line: 514 ]]
                            -- upvalues: u97 (copy)
                            return math.lerp(1, u97 and 0.25 or 0.5, p101);
                        end),
                        Size = u61.Open:Map(function(p102) --[[ Line: 517 ]]
                            return UDim2.fromScale(p102, 1);
                        end)
                    }),
                    u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        ZIndex = 2,
                        AutoLocalize = false,
                        AnchorPoint = Vector2.new(0, 0),
                        Position = UDim2.fromScale(0.05, 0.1),
                        Size = UDim2.fromScale(0.9, 0.8),
                        FontFace = u17,
                        Text = v100[1]:upper(),
                        TextColor3 = Color3.new(1, 1, 1),
                        TextTransparency = u61.Tween:Map(function(p103) --[[ Line: 531 ]]
                            return 1 - p103;
                        end),
                        TextXAlignment = Enum.TextXAlignment.Left
                    }),
                    u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        ZIndex = 2,
                        AutoLocalize = false,
                        AnchorPoint = Vector2.new(0, 0),
                        Position = UDim2.fromScale(0.05, 0.1),
                        Size = UDim2.fromScale(0.9, 0.8),
                        FontFace = u14,
                        Text = v100[3],
                        TextColor3 = Color3.new(1, 1, 1),
                        TextTransparency = u61.Tween:Map(function(p104) --[[ Line: 547 ]]
                            return 1 - p104;
                        end),
                        TextXAlignment = Enum.TextXAlignment.Right
                    }),
                    u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextScaled = true,
                        ZIndex = 2,
                        AutoLocalize = false,
                        AnchorPoint = Vector2.new(0, 0),
                        Position = UDim2.fromScale(0.05, 0.1),
                        Size = UDim2.fromScale(0.7, 0.8),
                        FontFace = u14,
                        Text = v100[2],
                        TextColor3 = Color3.new(1, 1, 1),
                        TextTransparency = u61.Tween:Map(function(p105) --[[ Line: 563 ]]
                            return 1 - p105;
                        end),
                        TextXAlignment = Enum.TextXAlignment.Right
                    })
                });
                u96 = u96 + v100[3];
                v98 = v98 + 0.055;
                u97 = not u97;
            end;
            local v106 = Color3.new(1, 1, 1);
            local v107 = 0;
            local v108 = "";
            for v109, v110 in u12 do
                local v111 = v110[4];
                if v111 then
                    if v111 <= u96 then
                        local v112 = (u96 - v111) / ((u12[v109 - 1] and u12[v109 - 1][4] or v111 + 500) - v111);
                        v107 = v112 < 0.33 and 1 or (v112 > 0.66 and 2 or v107);
                        v106 = v110[3];
                        v108 = v110[2];
                        break;
                    end;
                else
                    v108 = v110[2];
                end;
            end;
            v62.Summary = u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundTransparency = u61.Tween:Map(function(p113) --[[ Line: 600 ]]
                    return 1 - p113;
                end),
                BackgroundColor3 = Color3.fromRGB(30, 30, 30),
                Position = UDim2.fromScale(0, v98),
                Size = UDim2.fromScale(1, 0.1)
            }, {
                u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "TOTAL SCORE",
                    TextScaled = true,
                    AutoLocalize = false,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.fromScale(0.05, 0.1),
                    Size = UDim2.fromScale(0.9, 0.4),
                    FontFace = u15,
                    TextColor3 = Color3.new(1, 1, 1),
                    TextTransparency = u61.Tween:Map(function(p114) --[[ Line: 616 ]]
                        return 1 - p114;
                    end),
                    TextXAlignment = Enum.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AutoLocalize = false,
                    AnchorPoint = Vector2.new(0, 0.5),
                    Position = UDim2.fromScale(0.05, 0.3),
                    Size = p58.scorecard:Map(function(p115) --[[ Line: 626 ]]
                        local v116 = (math.clamp(p115, 0.55, 0.65) - 0.55) * 10 * 3.141592653589793;
                        local v117 = math.sin(v116);
                        return UDim2.fromScale(0.9, 0.4 + v117 / 10);
                    end),
                    FontFace = u15,
                    Text = p58.scorecard:Map(function(p118) --[[ Line: 631 ]]
                        -- upvalues: u25 (ref), u96 (ref)
                        return u25(tostring(u96), (math.clamp(p118, 0.4, 0.6) - 0.4) * 5);
                    end),
                    TextColor3 = Color3.new(1, 1, 1),
                    TextTransparency = u61.Tween:Map(function(p119) --[[ Line: 636 ]]
                        return 1 - p119;
                    end),
                    TextXAlignment = Enum.TextXAlignment.Right
                }),
                u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "CASH EARNED",
                    TextScaled = true,
                    AutoLocalize = false,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.fromScale(0.05, 0.5),
                    Size = UDim2.fromScale(0.9, 0.4),
                    FontFace = u15,
                    TextColor3 = Color3.new(1, 1, 1),
                    TextTransparency = u61.Tween:Map(function(p120) --[[ Line: 651 ]]
                        return 1 - p120;
                    end),
                    TextXAlignment = Enum.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AutoLocalize = false,
                    AnchorPoint = Vector2.new(0, 0.5),
                    Position = UDim2.fromScale(0.05, 0.7),
                    Size = p58.scorecard:Map(function(p121) --[[ Line: 661 ]]
                        local v122 = (math.clamp(p121, 0.35, 0.45) - 0.35) * 10 * 3.141592653589793;
                        local v123 = math.sin(v122);
                        return UDim2.fromScale(0.9, 0.4 + v123 / 10);
                    end),
                    FontFace = u15,
                    Text = p58.scorecard:Map(function(p124) --[[ Line: 666 ]]
                        -- upvalues: u25 (ref), u8 (ref), u61 (copy)
                        return u25(u8(u61.Data[3]), (math.clamp(p124, 0.2, 0.4) - 0.2) * 5);
                    end),
                    TextColor3 = Color3.fromRGB(171, 255, 126),
                    TextTransparency = u61.Tween:Map(function(p125) --[[ Line: 671 ]]
                        return 1 - p125;
                    end),
                    TextXAlignment = Enum.TextXAlignment.Right
                })
            });
            local l__createElement__8 = u2.createElement;
            local v126 = "Frame";
            local v128 = {
                BorderSizePixel = 0,
                BackgroundTransparency = u61.Tween:Map(function(p127) --[[ Line: 681 ]]
                    return 1 - p127 * 0.5;
                end),
                BackgroundColor3 = Color3.fromRGB(30, 30, 30),
                Position = UDim2.fromScale(0, v98 + 0.105),
                Size = UDim2.fromScale(1, 0.38)
            };
            local v129 = {};
            local v131 = u2.createElement("UIGradient", {
                Rotation = 90,
                Transparency = u61.Tween:Map(function(p130) --[[ Line: 689 ]]
                    return NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(p130 * 0.65 + 0.05, 0), NumberSequenceKeypoint.new(1, 1) });
                end)
            });
            local l__createElement__9 = u2.createElement;
            local v132 = "ImageLabel";
            local v136 = {
                BackgroundTransparency = 1,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.68, 0.44),
                Size = p58.scorecard:Map(function(p133) --[[ Line: 702 ]]
                    local v134 = (math.clamp(p133, 0.7, 1) - 0.7) * 3.333;
                    return UDim2.fromScale(0.7 - v134 / 10, 0.7 - v134 / 10);
                end),
                ImageTransparency = u61.Tween:Map(function(p135) --[[ Line: 706 ]]
                    return 1 - p135;
                end),
                Image = v108,
                ImageColor3 = v106,
                SizeConstraint = Enum.SizeConstraint.RelativeYY
            };
            local v137 = {};
            local v140 = u2.createElement("UIGradient", {
                Rotation = 90,
                Transparency = p58.scorecard:Map(function(p138) --[[ Line: 715 ]]
                    local v139 = (math.clamp(p138, 0.7, 0.8) - 0.7) * 10;
                    return NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.01 + v139 * 0.98, 1 - v139), NumberSequenceKeypoint.new(1, 1) });
                end)
            });
            local v141;
            if v107 > 0 then
                local l__createElement__10 = u2.createElement;
                local v142 = "Frame";
                local v146 = {
                    BorderSizePixel = 0,
                    BackgroundColor3 = v106,
                    BackgroundTransparency = u61.Tween:Map(function(p143) --[[ Line: 727 ]]
                        return 1 - p143;
                    end),
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Position = UDim2.fromScale(1.25, 0.5),
                    Size = p58.scorecard:Map(function(p144) --[[ Line: 733 ]]
                        local v145 = (math.clamp(p144, 0.8, 0.9) - 0.8) * 10;
                        return UDim2.fromScale(0.3 * v145, 0.1);
                    end)
                };
                local v147 = {};
                local v148;
                if v107 > 1 then
                    v148 = u2.createElement("Frame", {
                        BorderSizePixel = 0,
                        BackgroundColor3 = v106,
                        BackgroundTransparency = u61.Tween:Map(function(p149) --[[ Line: 740 ]]
                            return 1 - p149;
                        end),
                        AnchorPoint = Vector2.new(0.5, 0.5),
                        Position = UDim2.fromScale(0.5, 0.5),
                        Size = p58.scorecard:Map(function(p150) --[[ Line: 746 ]]
                            local v151 = (math.clamp(p150, 0.9, 1) - 0.9) * 10;
                            return UDim2.fromScale(0.33, 3 * v151);
                        end)
                    });
                else
                    v148 = false;
                end;
                v147[1] = v148;
                v141 = l__createElement__10(v142, v146, v147);
            else
                v141 = false;
            end;
            v137[1], v137[2] = v140, v141;
            v129[1], v129[2], v129[3], v129[4] = v131, l__createElement__9(v132, v136, v137), u2.createElement("TextLabel", {
    BackgroundTransparency = 1,
    Text = "GRADE",
    TextScaled = true,
    RichText = true,
    AutoLocalize = false,
    AnchorPoint = Vector2.new(0, 0),
    Position = UDim2.fromScale(0.15, 0.2),
    Size = UDim2.fromScale(0.9, 0.3),
    FontFace = u15,
    TextColor3 = Color3.new(1, 1, 1),
    TextTransparency = u61.Tween:Map(function(p152) --[[ Line: 762 ]]
        return 1 - p152;
    end),
    TextXAlignment = Enum.TextXAlignment.Left
}), u2.createElement("TextLabel", {
    BackgroundTransparency = 1,
    TextScaled = true,
    RichText = true,
    AutoLocalize = false,
    AnchorPoint = Vector2.new(0, 0),
    Position = UDim2.fromScale(0.15, 0.42),
    Size = UDim2.fromScale(0.9, 0.2),
    FontFace = u15,
    Text = u96 >= 0 and "PASS" or "FAIL",
    TextColor3 = Color3.new(1, 1, 1),
    TextTransparency = u61.Tween:Map(function(p153) --[[ Line: 778 ]]
        return 1 - p153;
    end),
    TextXAlignment = Enum.TextXAlignment.Left
});
            v62.Grade = l__createElement__8(v126, v128, v129);
        end;
        v59["Page" .. v60] = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(1, 1)
        }, v62);
    end;
    v59.Loader = u2.createElement("Frame", {
        BorderSizePixel = 0,
        AnchorPoint = Vector2.new(0.5, 1),
        Position = UDim2.fromScale(0.5, 0),
        Size = p58.timer:map(function(p154) --[[ Line: 797 ]]
            return UDim2.fromScale(p154, 0.01);
        end),
        BackgroundColor3 = Color3.new(1, 1, 1),
        BackgroundTransparency = p58.timer:map(function(p155) --[[ Line: 802 ]]
            return p155 <= 0.9 and 0 or (p155 - 0.9) / 0.1;
        end)
    });
    local l__Name__11 = u6:GetBind("Bleed").Name;
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 1)
    }, {
        u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Position = UDim2.fromScale(0.5, 0.8),
            AnchorPoint = Vector2.new(0.5, 0),
            Size = UDim2.fromScale(0.25, 0.06),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            Visible = p58.skip
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextTransparency = 0.2,
                TextScaled = true,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(-0.5, 0, 0.6, 0),
                Size = UDim2.new(2, 0, 0.3, 0),
                FontFace = u16,
                Text = "PRESS [" .. l__Name__11 .. "] TO SKIP",
                TextColor3 = Color3.new(0, 0, 0),
                TextXAlignment = Enum.TextXAlignment.Center
            }, { u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextTransparency = 0.1,
                    TextScaled = true,
                    AutoLocalize = false,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.new(0, 0, 0, -1),
                    Size = UDim2.new(1, 0, 1, 0),
                    FontFace = u16,
                    Text = "PRESS [" .. l__Name__11 .. "] TO SKIP",
                    TextColor3 = Color3.fromRGB(255, 255, 255),
                    TextXAlignment = Enum.TextXAlignment.Center
                }) }) }),
        u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(0, 0, 0),
            Size = p58.lerp:Map(function(p156) --[[ Line: 854 ]]
                return UDim2.fromScale(1, p156 * 0.1);
            end)
        }),
        u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(0, 0, 0),
            Position = UDim2.fromScale(0, 1),
            AnchorPoint = Vector2.new(0, 1),
            Size = p58.lerp:Map(function(p157) --[[ Line: 863 ]]
                return UDim2.fromScale(1, p157 * 0.1);
            end)
        }),
        u2.createElement("Frame", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = UDim2.fromScale(0.6, 0.6),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }, v59)
    });
end;
return v13;