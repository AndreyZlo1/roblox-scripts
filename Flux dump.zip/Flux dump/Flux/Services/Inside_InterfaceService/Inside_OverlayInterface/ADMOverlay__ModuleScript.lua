-- Services.InterfaceService.OverlayInterface.ADMOverlay
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local u3 = v1("PostProcessingService");
local l__RunService__1 = game:GetService("RunService");
local v4 = u2.Component:extend("Overlay");
local u5 = Color3.new(1, 0, 0);
function v4.init(p6, p7) --[[ Line: 12 ]]
    -- upvalues: u2 (copy), l__RunService__1 (copy), u3 (copy)
    local v8, u9 = u2.createBinding(Vector2.new());
    p6.offset = v8;
    p6.ballistic = p7.Ballistic;
    p6.elev = p7.Elev;
    p6.fov = p7.FOV;
    p6.lowAmmo = p7.LowAmmo;
    p6.armed = p7.Armed;
    p6.compass = p7.Compass;
    p6.update = l__RunService__1.Heartbeat:Connect(function() --[[ Line: 21 ]]
        -- upvalues: u9 (copy)
        u9(Vector2.new(math.random(), math.random()));
    end);
    p6.blur = u3:AddBlur({
        Size = p7.Blur:Map(function(p10) --[[ Line: 25 ]]
            return p10 * 15;
        end)
    }, nil, true);
end;
function v4.willUnmount(p11) --[[ Line: 31 ]]
    p11.blur.Destroy();
    p11.update:Disconnect();
end;
function v4.render(p12) --[[ Line: 36 ]]
    -- upvalues: u2 (copy), u5 (copy)
    local _ = p12.props;
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 1)
    }, { u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://73577146256840",
            ImageTransparency = 0.7,
            ScaleType = Enum.ScaleType.Tile,
            ImageColor3 = Color3.fromRGB(109, 109, 109),
            TileSize = UDim2.fromOffset(1024, 1024),
            Size = UDim2.fromScale(10, 10),
            Position = p12.offset:map(function(p13) --[[ Line: 51 ]]
                return UDim2.fromScale(p13.X * 5, p13.Y * 5);
            end),
            AnchorPoint = p12.offset:map(function(p14) --[[ Line: 54 ]]
                return p14;
            end)
        }), u2.createElement("ImageLabel", {
            BorderSizePixel = 0,
            BackgroundTransparency = 1,
            Image = "rbxassetid://17630669039",
            ZIndex = 2,
            Size = UDim2.fromScale(1, 1),
            Position = UDim2.fromScale(0.5, 0),
            AnchorPoint = Vector2.new(0.5, 0),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            ImageColor3 = Color3.new(0, 0, 0)
        }, {
            u2.createElement("Frame", {
                BorderSizePixel = 0,
                Size = UDim2.fromScale(10, 1),
                Position = UDim2.fromScale(1, 0),
                BackgroundColor3 = Color3.new()
            }),
            u2.createElement("Frame", {
                BorderSizePixel = 0,
                Size = UDim2.fromScale(10, 1),
                Position = UDim2.fromScale(0, 0),
                AnchorPoint = Vector2.new(1, 0),
                BackgroundColor3 = Color3.new()
            }),
            u2.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://70456087337557",
                ImageTransparency = 0.5,
                ImageColor3 = u5,
                AnchorPoint = Vector2.new(0.5, 0.5),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                Size = UDim2.fromScale(0.32, 0.25),
                Position = UDim2.fromScale(0.5, 0.5)
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "ОГОНЬ РАЗРЕШЕН",
                TextTransparency = 0.5,
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.fromScale(0, 0.15),
                Size = UDim2.fromScale(1, 0.025),
                Font = Enum.Font.Arial,
                TextColor3 = u5,
                Visible = p12.armed,
                TextXAlignment = Enum.TextXAlignment.Center
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "СТАБ ВЫКЛ",
                TextTransparency = 0.5,
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.fromScale(0.03, 0.3),
                Size = UDim2.fromScale(1, 0.025),
                Font = Enum.Font.Arial,
                TextColor3 = u5,
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "КАМЕРА: ТЕЛЕ | АВТОМАТ | ПАТРОНЫ",
                TextTransparency = 0.5,
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.fromScale(0.1, 0.82),
                Size = UDim2.fromScale(1, 0.025),
                Font = Enum.Font.Arial,
                TextColor3 = u5,
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "<b>1</b> | 2 | 3",
                RichText = true,
                TextTransparency = 0.5,
                TextScaled = true,
                AnchorPoint = Vector2.new(1, 0),
                Position = UDim2.fromScale(0.9, 0.82),
                Size = UDim2.fromScale(1, 0.025),
                Font = Enum.Font.Arial,
                TextColor3 = u5,
                TextXAlignment = Enum.TextXAlignment.Right
            })
        }) });
end;
return v4;