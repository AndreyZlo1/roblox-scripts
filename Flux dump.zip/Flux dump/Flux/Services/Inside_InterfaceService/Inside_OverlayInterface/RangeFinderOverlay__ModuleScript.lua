-- Services.InterfaceService.OverlayInterface.RangeFinderOverlay
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local u3 = v1("convertUnit");
local v4 = u2.Component:extend("Overlay");
local u5 = Font.fromName("Michroma", Enum.FontWeight.Bold, Enum.FontStyle.Normal);
function v4.init(p6, p7) --[[ Line: 9 ]]
    p6.lerp = p7.Lerp;
    p6.range = p7.Range;
    p6.ranging = p7.Ranging;
end;
function v4.willUnmount(_) --[[ Line: 15 ]] end;
function v4.render(p8) --[[ Line: 19 ]]
    -- upvalues: u2 (copy), u5 (copy), u3 (copy)
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 1)
    }, { u2.createElement("ImageLabel", {
            BorderSizePixel = 0,
            BackgroundTransparency = 1,
            Image = "rbxassetid://136858141195126",
            ZIndex = 2,
            Size = UDim2.fromScale(1.2, 1.2),
            Position = UDim2.fromScale(0.5, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            ImageTransparency = p8.lerp:Map(function(p9) --[[ Line: 31 ]]
                return 1 - p9;
            end),
            ImageColor3 = Color3.new(0, 0, 0)
        }, { u2.createElement("Frame", {
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.5),
                Size = UDim2.fromScale(0.01, 0.01),
                SizeConstraint = Enum.SizeConstraint.RelativeYY
            }, { u2.createElement("UIStroke", {
                    Thickness = 4,
                    Color = Color3.new(1, 0, 0),
                    LineJoinMode = Enum.LineJoinMode.Bevel,
                    Transparency = p8.ranging:map(function(p10) --[[ Line: 49 ]]
                        return p10 and 0 or 1;
                    end)
                }), u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextTransparency = 0,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0.5, 0),
                    Position = UDim2.fromScale(0.5, 2),
                    Size = UDim2.fromScale(100, 3),
                    FontFace = u5,
                    Text = p8.range:map(function(p11) --[[ Line: 59 ]]
                        -- upvalues: u3 (ref)
                        if not p11 then
                            return "";
                        end;
                        local v12 = u3(p11);
                        local v13 = v12:sub(1, 1);
                        for v14 = 2, #v12 do
                            v13 = v13 .. " " .. v12:sub(v14, v14);
                        end;
                        return v13;
                    end),
                    TextColor3 = Color3.new(1, 0, 0),
                    TextXAlignment = Enum.TextXAlignment.Center
                }) }), u2.createElement("Frame", {
                BorderSizePixel = 0,
                Size = UDim2.fromScale(10, 1),
                Position = UDim2.fromScale(1, 0),
                BackgroundColor3 = Color3.new(),
                BackgroundTransparency = p8.lerp:Map(function(p15) --[[ Line: 82 ]]
                    return 1 - p15;
                end)
            }), u2.createElement("Frame", {
                BorderSizePixel = 0,
                Size = UDim2.fromScale(10, 1),
                Position = UDim2.fromScale(0, 0),
                AnchorPoint = Vector2.new(1, 0),
                BackgroundColor3 = Color3.new(),
                BackgroundTransparency = p8.lerp:Map(function(p16) --[[ Line: 92 ]]
                    return 1 - p16;
                end)
            }) }) });
end;
return v4;