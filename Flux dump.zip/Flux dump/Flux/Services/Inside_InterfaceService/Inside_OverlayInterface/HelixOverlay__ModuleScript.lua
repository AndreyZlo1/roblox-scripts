-- Services.InterfaceService.OverlayInterface.HelixOverlay
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local l__RunService__1 = game:GetService("RunService");
local u3 = v1("convertUnit");
local v4 = u2.Component:extend("Overlay");
local l__CurrentCamera__2 = workspace.CurrentCamera;
local u5 = Font.fromName("Michroma", Enum.FontWeight.Bold, Enum.FontStyle.Normal);
function v4.init(u6, p7) --[[ Line: 13 ]]
    -- upvalues: u2 (copy), l__RunService__1 (copy), l__CurrentCamera__2 (copy)
    u6.lerp = p7.Lerp;
    u6.range = p7.Range;
    u6.ranging = p7.Ranging;
    local v8, v9 = u2.createBinding(0);
    u6.angle = v8;
    u6.updateAngle = v9;
    u6.connection = l__RunService__1.RenderStepped:Connect(function() --[[ Line: 19 ]]
        -- upvalues: l__CurrentCamera__2 (ref), u6 (copy)
        local v10 = l__CurrentCamera__2.CFrame:ToOrientation();
        u6.updateAngle(v10);
    end);
end;
function v4.willUnmount(p11) --[[ Line: 25 ]]
    p11.connection:Disconnect();
end;
function v4.render(p12) --[[ Line: 29 ]]
    -- upvalues: u2 (copy), u5 (copy), u3 (copy)
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 1)
    }, { u2.createElement("ImageLabel", {
            BorderSizePixel = 0,
            BackgroundTransparency = 1,
            Image = "rbxassetid://136858141195126",
            ZIndex = 2,
            Size = UDim2.fromScale(1.2, 1.2),
            Position = UDim2.fromScale(0.5, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            ImageTransparency = p12.lerp:Map(function(p13) --[[ Line: 41 ]]
                return 1 - p13;
            end),
            ImageColor3 = Color3.new(0, 0, 0)
        }, { u2.createElement("Frame", {
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.5),
                Size = UDim2.fromScale(0.01, 0.01),
                SizeConstraint = Enum.SizeConstraint.RelativeYY
            }, {
                u2.createElement("UIStroke", {
                    Thickness = 0.3,
                    Transparency = 0,
                    Color = Color3.new(1, 0, 0),
                    StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
                }),
                u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.5, 0)
                }),
                u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    AnchorPoint = Vector2.new(0, 0.5),
                    BackgroundColor3 = Color3.fromRGB(255, 0, 0),
                    BorderColor3 = Color3.new(),
                    Position = UDim2.fromScale(0.95, 0.5),
                    Size = UDim2.fromScale(0.8, 0.5)
                }),
                u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    AnchorPoint = Vector2.new(1, 0.5),
                    BackgroundColor3 = Color3.fromRGB(255, 0, 0),
                    BorderColor3 = Color3.new(),
                    Position = UDim2.fromScale(0.05, 0.5),
                    Size = UDim2.fromScale(0.8, 0.5)
                }),
                u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    AnchorPoint = Vector2.new(0.5, 1),
                    BackgroundColor3 = Color3.fromRGB(255, 0, 0),
                    BorderColor3 = Color3.new(),
                    Position = UDim2.fromScale(0.5, 0.05),
                    Size = UDim2.fromScale(0.5, 0.8)
                }),
                u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    AnchorPoint = Vector2.new(0.5, 0),
                    BackgroundColor3 = Color3.fromRGB(255, 0, 0),
                    BorderColor3 = Color3.new(),
                    Position = UDim2.fromScale(0.5, 0.95),
                    Size = UDim2.fromScale(0.5, 0.8)
                }),
                u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextTransparency = 0,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0.5, 0),
                    Position = UDim2.fromScale(0.5, 2),
                    Size = UDim2.fromScale(100, 3),
                    FontFace = u5,
                    Text = p12.range:map(function(p14) --[[ Line: 102 ]]
                        -- upvalues: u3 (ref)
                        if not p14 then
                            return "";
                        end;
                        local v15 = u3(p14);
                        local v16 = v15:sub(1, 1);
                        for v17 = 2, #v15 do
                            v16 = v16 .. " " .. v15:sub(v17, v17);
                        end;
                        return v16;
                    end),
                    TextColor3 = Color3.new(1, 0, 0),
                    TextXAlignment = Enum.TextXAlignment.Center
                }),
                u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextTransparency = 0,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0.5, 1),
                    Position = UDim2.fromScale(0.5, -2),
                    Size = UDim2.fromScale(100, 3),
                    FontFace = u5,
                    Text = p12.angle:map(function(p18) --[[ Line: 125 ]]
                        local v19 = math.deg(p18);
                        return math.floor(v19) .. "°";
                    end),
                    TextColor3 = Color3.new(1, 0, 0),
                    TextXAlignment = Enum.TextXAlignment.Center
                })
            }), u2.createElement("Frame", {
                BorderSizePixel = 0,
                Size = UDim2.fromScale(10, 1),
                Position = UDim2.fromScale(1, 0),
                BackgroundColor3 = Color3.new(),
                BackgroundTransparency = p12.lerp:Map(function(p20) --[[ Line: 139 ]]
                    return 1 - p20;
                end)
            }), u2.createElement("Frame", {
                BorderSizePixel = 0,
                Size = UDim2.fromScale(10, 1),
                Position = UDim2.fromScale(0, 0),
                AnchorPoint = Vector2.new(1, 0),
                BackgroundColor3 = Color3.new(),
                BackgroundTransparency = p12.lerp:Map(function(p21) --[[ Line: 149 ]]
                    return 1 - p21;
                end)
            }) }) });
end;
return v4;