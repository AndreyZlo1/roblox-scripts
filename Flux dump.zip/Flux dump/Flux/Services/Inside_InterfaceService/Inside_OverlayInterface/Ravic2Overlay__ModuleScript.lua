-- Services.InterfaceService.OverlayInterface.Ravic2Overlay
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
v1("PostProcessingService");
local l__RunService__1 = game:GetService("RunService");
local v3 = u2.Component:extend("Overlay");
function v3.init(p4, _) --[[ Line: 9 ]]
    -- upvalues: u2 (copy), l__RunService__1 (copy)
    local v5, u6 = u2.createBinding(Vector2.new());
    p4.offset = v5;
    p4.update = l__RunService__1.Heartbeat:Connect(function() --[[ Line: 12 ]]
        -- upvalues: u6 (copy)
        u6(Vector2.new(math.random(), math.random()));
    end);
end;
function v3.willUnmount(p7) --[[ Line: 17 ]]
    p7.update:Disconnect();
end;
function v3.render(p8) --[[ Line: 21 ]]
    -- upvalues: u2 (copy)
    local l__props__2 = p8.props;
    local l__Range__3 = l__props__2.Range;
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 1)
    }, {
        u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://73577146256840",
            ImageTransparency = l__Range__3:map(function(p9) --[[ Line: 31 ]]
                return math.lerp(0, 0.8, p9);
            end),
            ScaleType = Enum.ScaleType.Tile,
            ImageColor3 = Color3.fromRGB(109, 109, 109),
            TileSize = UDim2.fromOffset(1024, 1024),
            Size = UDim2.fromScale(10, 10),
            Position = p8.offset:map(function(p10) --[[ Line: 38 ]]
                return UDim2.fromScale(p10.X * 5, p10.Y * 5);
            end),
            AnchorPoint = p8.offset:map(function(p11) --[[ Line: 41 ]]
                return p11;
            end)
        }),
        Left = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 2,
            BackgroundColor3 = Color3.fromRGB(24, 24, 24),
            BorderColor3 = Color3.new(),
            Size = UDim2.fromScale(0.1, 1)
        }, {
            Res = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "HD",
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187372847"),
                Position = UDim2.fromScale(0, 0.4),
                Size = UDim2.fromScale(1, 0.05),
                TextColor3 = Color3.new(1, 1, 1)
            }),
            Bat = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187372847"),
                Position = UDim2.fromScale(0, 0.2),
                Size = UDim2.fromScale(1, 0.05),
                Text = l__props__2.Battery:map(function(p12) --[[ Line: 66 ]]
                    return math.floor(p12 * 100) .. "%";
                end),
                TextColor3 = Color3.new(1, 1, 1)
            }),
            Signal = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Position = UDim2.fromScale(0.1, 0.3),
                Size = UDim2.fromScale(0.8, 0.05)
            }, {
                Var_1 = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    AnchorPoint = Vector2.new(0.5, 1),
                    BackgroundColor3 = l__Range__3:map(function(p13) --[[ Line: 79 ]]
                        return p13 > 0.6 and Color3.new(0, 1, 0) or (p13 > 0.4 and Color3.new(1, 1, 0) or Color3.new(1, 0, 0));
                    end),
                    BorderColor3 = Color3.new(),
                    Position = UDim2.fromScale(0.166, 1),
                    Size = UDim2.fromScale(0.1, 0.2)
                }),
                Var_2 = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    AnchorPoint = Vector2.new(0.5, 1),
                    BackgroundColor3 = l__Range__3:map(function(p14) --[[ Line: 89 ]]
                        return p14 > 0.6 and Color3.new(0, 1, 0) or p14 > 0.4 and Color3.new(1, 1, 0) or (p14 > 0.2 and Color3.new(1, 0, 0) or Color3.fromRGB(114, 114, 114));
                    end),
                    BorderColor3 = Color3.new(),
                    Position = UDim2.fromScale(0.332, 1),
                    Size = UDim2.fromScale(0.1, 0.4)
                }),
                Var_3 = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    AnchorPoint = Vector2.new(0.5, 1),
                    BackgroundColor3 = l__Range__3:map(function(p15) --[[ Line: 99 ]]
                        return p15 > 0.6 and Color3.new(0, 1, 0) or (p15 > 0.4 and Color3.new(1, 1, 0) or Color3.fromRGB(114, 114, 114));
                    end),
                    BorderColor3 = Color3.new(),
                    Position = UDim2.fromScale(0.498, 1),
                    Size = UDim2.fromScale(0.1, 0.6)
                }),
                Var_4 = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    AnchorPoint = Vector2.new(0.5, 1),
                    BackgroundColor3 = l__Range__3:map(function(p16) --[[ Line: 109 ]]
                        return p16 > 0.6 and Color3.new(0, 1, 0) or Color3.fromRGB(114, 114, 114);
                    end),
                    BorderColor3 = Color3.new(),
                    Position = UDim2.fromScale(0.664, 1),
                    Size = UDim2.fromScale(0.1, 0.8)
                }),
                Var_5 = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    AnchorPoint = Vector2.new(0.5, 1),
                    BackgroundColor3 = l__Range__3:map(function(p17) --[[ Line: 119 ]]
                        return p17 > 0.8 and Color3.new(0, 1, 0) or Color3.fromRGB(114, 114, 114);
                    end),
                    BorderColor3 = Color3.new(),
                    Position = UDim2.fromScale(0.83, 1),
                    Size = UDim2.fromScale(0.1, 1)
                })
            }),
            Bar = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Position = UDim2.fromScale(0.1, 0.15),
                Size = UDim2.fromScale(0.8, 0.05)
            }, {
                UIStroke = u2.createElement("UIStroke", {
                    Thickness = 0.04,
                    Color = Color3.new(1, 1, 1),
                    StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
                }),
                Pec = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundColor3 = l__props__2.Battery:map(function(p18) --[[ Line: 139 ]]
                        return Color3.new(1, 0, 0):Lerp(Color3.new(0, 1, 0), p18);
                    end),
                    BorderColor3 = Color3.new(),
                    Size = l__props__2.Battery:map(function(p19) --[[ Line: 144 ]]
                        return UDim2.fromScale(p19, 1);
                    end)
                })
            })
        }),
        Right = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 2,
            AnchorPoint = Vector2.new(1, 0),
            BackgroundColor3 = Color3.fromRGB(24, 24, 24),
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(1, 0),
            Size = UDim2.fromScale(0.1, 1)
        }, {
            Settings = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0.5, 0),
                Position = UDim2.fromScale(0.5, 0.1),
                Size = UDim2.fromScale(0.6, 0.5),
                SizeConstraint = Enum.SizeConstraint.RelativeXX
            }, {
                Line = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    AnchorPoint = Vector2.new(0, 0.5),
                    BackgroundColor3 = Color3.new(1, 1, 1),
                    Position = UDim2.fromScale(0, 0.1),
                    Size = UDim2.fromScale(1, 0.05),
                    SizeConstraint = Enum.SizeConstraint.RelativeXX
                }, {
                    Dot = u2.createElement("Frame", {
                        AnchorPoint = Vector2.new(0.5, 0.5),
                        BackgroundColor3 = Color3.fromRGB(19, 19, 19),
                        Position = UDim2.fromScale(0.25, 0.5),
                        Size = UDim2.fromScale(5, 5),
                        SizeConstraint = Enum.SizeConstraint.RelativeYY
                    }, {
                        UICorner = u2.createElement("UICorner", {
                            CornerRadius = UDim.new(0.5, 0)
                        }),
                        UIStroke = u2.createElement("UIStroke", {
                            Thickness = 0.1,
                            Color = Color3.new(1, 1, 1),
                            StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
                        })
                    })
                }),
                Line2 = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    AnchorPoint = Vector2.new(0, 0.5),
                    BackgroundColor3 = Color3.new(1, 1, 1),
                    Position = UDim2.fromScale(0, 0.9),
                    Size = UDim2.fromScale(1, 0.05),
                    SizeConstraint = Enum.SizeConstraint.RelativeXX
                }, {
                    Dot = u2.createElement("Frame", {
                        AnchorPoint = Vector2.new(0.5, 0.5),
                        BackgroundColor3 = Color3.fromRGB(19, 19, 19),
                        Position = UDim2.fromScale(0.5, 0.5),
                        Size = UDim2.fromScale(5, 5),
                        SizeConstraint = Enum.SizeConstraint.RelativeYY
                    }, {
                        UICorner = u2.createElement("UICorner", {
                            CornerRadius = UDim.new(0.5, 0)
                        }),
                        UIStroke = u2.createElement("UIStroke", {
                            Thickness = 0.1,
                            Color = Color3.new(1, 1, 1),
                            StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
                        })
                    })
                }),
                Line3 = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    AnchorPoint = Vector2.new(0, 0.5),
                    BackgroundColor3 = Color3.new(1, 1, 1),
                    Position = UDim2.fromScale(0, 0.5),
                    Size = UDim2.fromScale(1, 0.05),
                    SizeConstraint = Enum.SizeConstraint.RelativeXX
                }, {
                    Dot = u2.createElement("Frame", {
                        AnchorPoint = Vector2.new(0.5, 0.5),
                        BackgroundColor3 = Color3.fromRGB(19, 19, 19),
                        Position = UDim2.fromScale(0.75, 0.5),
                        Size = UDim2.fromScale(5, 5),
                        SizeConstraint = Enum.SizeConstraint.RelativeYY
                    }, {
                        UICorner = u2.createElement("UICorner", {
                            CornerRadius = UDim.new(0.5, 0)
                        }),
                        UIStroke = u2.createElement("UIStroke", {
                            Thickness = 0.1,
                            Color = Color3.new(1, 1, 1),
                            StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
                        })
                    })
                })
            }),
            CameraRoll = u2.createElement("Frame", {
                AnchorPoint = Vector2.new(0.5, 1),
                BackgroundColor3 = Color3.fromRGB(19, 19, 19),
                Position = UDim2.fromScale(0.5, 0.9),
                Size = UDim2.fromScale(0.6, 0.5),
                SizeConstraint = Enum.SizeConstraint.RelativeXX
            }, {
                UIStroke = u2.createElement("UIStroke", {
                    Thickness = 0.05,
                    Color = Color3.new(1, 1, 1),
                    StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
                }),
                ImageLabel = u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Image = "rbxassetid://137191725617352",
                    Rotation = 90,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Position = UDim2.fromScale(0.5, 0.5),
                    Size = UDim2.fromScale(0.5, 0.5),
                    SizeConstraint = Enum.SizeConstraint.RelativeYY
                })
            }),
            Record = u2.createElement("Frame", {
                AnchorPoint = Vector2.new(0, 0.5),
                BackgroundColor3 = Color3.fromRGB(19, 19, 19),
                Position = UDim2.fromScale(0, 0.5),
                Size = UDim2.fromScale(0.9, 0.9),
                SizeConstraint = Enum.SizeConstraint.RelativeXX
            }, {
                UICorner = u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.5, 0)
                }),
                UIStroke = u2.createElement("UIStroke", {
                    Thickness = 0.05,
                    Color = Color3.new(1, 1, 1),
                    StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
                }),
                Red = u2.createElement("Frame", {
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    BackgroundColor3 = Color3.fromRGB(255, 0, 5),
                    Position = UDim2.fromScale(0.5, 0.5),
                    Size = UDim2.fromScale(0.9, 0.9),
                    SizeConstraint = Enum.SizeConstraint.RelativeXX
                }, {
                    UICorner = u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0.5, 0)
                    })
                })
            })
        }),
        Spot = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0.5, 0),
            Position = UDim2.fromScale(0.5, 0.8),
            Size = UDim2.fromScale(0.3, 0.025),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            Visible = l__props__2.Spotting:map(function(p20) --[[ Line: 302 ]]
                return p20 > 0;
            end)
        }, {
            Pec = u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.new(1, 1, 1),
                BorderColor3 = Color3.new(),
                Size = l__props__2.Spotting:map(function(p21) --[[ Line: 310 ]]
                    return UDim2.fromScale(math.min(p21, 1), 1);
                end)
            }),
            Stroke = u2.createElement("UIStroke", {
                Thickness = 0.04,
                Color = Color3.new(1, 1, 1),
                StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
            })
        }),
        Viewport = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ZIndex = 2,
            Position = UDim2.fromScale(0.1, 0),
            Size = UDim2.fromScale(0.8, 1)
        }, {
            Frame = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0.5, 0),
                BackgroundColor3 = Color3.fromRGB(213, 213, 213),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0.666, 0),
                Size = UDim2.fromScale(0.001, 1)
            }),
            Frame2 = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0.5, 0),
                BackgroundColor3 = Color3.fromRGB(213, 213, 213),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0.333, 0),
                Size = UDim2.fromScale(0.001, 1)
            }),
            Frame3 = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 0.550000012),
                BackgroundColor3 = Color3.fromRGB(213, 213, 213),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 0.333),
                Size = UDim2.fromScale(1, 0.001),
                SizeConstraint = Enum.SizeConstraint.RelativeXX
            }),
            Frame4 = u2.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 0.550000012),
                BackgroundColor3 = Color3.fromRGB(213, 213, 213),
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 0.666),
                Size = UDim2.fromScale(1, 0.001),
                SizeConstraint = Enum.SizeConstraint.RelativeXX
            })
        })
    });
end;
return v3;