-- Services.InterfaceService.HUDInterface.ToolSlotComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local u3 = v1("SlotComponent");
local v4 = u2.Component:extend("Inventory");
function v4.render(p5) --[[ Line: 14 ]]
    -- upvalues: u2 (copy), u3 (copy)
    local v6 = {};
    for v7, v8 in p5.props.Inventories do
        v6[v7] = u2.createElement(u3, {
            Tools = v8,
            Index = v7
        });
    end;
    local l__Bumped__1 = p5.props.Bumped;
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        LayoutOrder = 1,
        Size = UDim2.new(1, 0, 0.05, 0),
        Visible = l__Bumped__1
    }, { u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.new(1, 0, 0.8, 0)
        }, { u2.createFragment(v6), u2.createElement("UIListLayout", {
                FillDirection = Enum.FillDirection.Vertical,
                HorizontalAlignment = Enum.HorizontalAlignment.Right,
                SortOrder = Enum.SortOrder.LayoutOrder,
                VerticalAlignment = Enum.VerticalAlignment.Bottom,
                Padding = UDim.new(0.02, 0)
            }) }) });
end;
return v4;