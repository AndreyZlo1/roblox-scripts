-- Services.InterfaceService.HUDInterface.RoundWinComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local u1, v2 = shared.import("Roact", "require");
local u3 = v2("InputService");
local u4 = v2("PostProcessingService");
local u5 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
game:GetService("Lighting");
local u6 = v2("RoactTween");
local u7 = v2("SoundService");
local v8 = u1.Component:extend("Win");
function v8.willUnmount(p9) --[[ Line: 18 ]]
    -- upvalues: u3 (copy)
    p9.BlurEffect.Destroy();
    u3.RoundOpen = false;
end;
function v8.init(u10, _) --[[ Line: 24 ]]
    -- upvalues: u6 (copy), u7 (copy), u4 (copy), u3 (copy)
    local v11 = TweenInfo.new(6, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out, 0, false, 0);
    u10.Tween = u6.new(0, v11);
    u10.Tween:SetGoal(1);
    u10.Blur = u6.new(0, v11);
    u10.Blur:SetGoal(1);
    local u12 = u10.props.RoundWin[3];
    local v13 = u12 and "MissionAcquired" or "PVPWin";
    if u12 or u10.props.RoundWin[4] then
        task.delay(u10.props.RoundWin[4] or 3, function() --[[ Line: 39 ]]
            -- upvalues: u10 (copy), u12 (copy)
            u10.Tween:SetGoal(0);
            if u12 then
                u10.Blur:SetGoal(0);
            end;
        end);
    end;
    u7:CreateSound("Music", nil, true, "Music", v13).Destroy(10);
    u10.BlurEffect = u4:AddBlur({
        Size = u10.Blur:Map(function(p14) --[[ Line: 51 ]]
            return math.clamp(p14 - 0.2, 0, 0.2) * 100;
        end)
    }, nil, true);
    u3.RoundOpen = true;
end;
function v8.render(p15) --[[ Line: 59 ]]
    -- upvalues: u1 (copy), u5 (copy)
    local l__RoundWin__1 = p15.props.RoundWin;
    return u1.createFragment({ u1.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0, 0.5),
            Position = p15.Tween:Map(function(p16) --[[ Line: 65 ]]
                return UDim2.fromScale(0, 0.5 - math.clamp(p16 - 0.65, 0, 0.05));
            end),
            Size = UDim2.new(1, 0, 0.5, 0),
            FontFace = u5,
            Text = l__RoundWin__1[1]:upper(),
            TextTransparency = p15.Tween:Map(function(p17) --[[ Line: 71 ]]
                return 1 - math.clamp(p17 - 0.5, 0, 0.5) * 2;
            end),
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = Enum.TextXAlignment.Center
        }, { u1.createElement("UIGradient", {
                Rotation = 45,
                Color = ColorSequence.new(Color3.new(1, 1, 1)),
                Offset = Vector2.new(0, 0),
                Transparency = p15.Tween:Map(function(p18) --[[ Line: 83 ]]
                    local v19 = math.clamp(p18, 0, 0.5) * 2;
                    return NumberSequence.new({
                        NumberSequenceKeypoint.new(0, 0),
                        NumberSequenceKeypoint.new(math.clamp(v19 - 0.1, 0.001, 0.999), 0),
                        NumberSequenceKeypoint.new(math.clamp(v19 + 0.1, 0.001, 0.999), 1),
                        NumberSequenceKeypoint.new(1, 1)
                    });
                end)
            }), u1.createElement("UIStroke", {
                ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                Color = Color3.new(1, 1, 1),
                LineJoinMode = Enum.LineJoinMode.Round,
                Transparency = p15.Tween:Map(function(p20) --[[ Line: 97 ]]
                    return math.clamp(p20 - 0.5, 0, 0.5) * 2;
                end)
            }) }), u1.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextTransparency = 1,
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0, 0.5),
            Position = UDim2.fromScale(0, 0.5),
            Size = UDim2.new(1, 0, 0.05, 0),
            FontFace = u5,
            Text = l__RoundWin__1[2],
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = Enum.TextXAlignment.Center
        }, { u1.createElement("UIGradient", {
                Rotation = 0,
                Color = ColorSequence.new(Color3.new(1, 1, 1)),
                Offset = Vector2.new(0, 0),
                Transparency = p15.Tween:Map(function(p21) --[[ Line: 119 ]]
                    local v22 = 1 - math.clamp(p21 - 0.65, 0, 0.3) * 3.333;
                    if v22 >= 1 then
                        return NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 1) });
                    end;
                    local v23 = {};
                    for _ = 1, 4 do
                        local v24 = #v23 + 1;
                        local v25 = {};
                        local v26 = math.random();
                        v25[1], v25[2] = math.clamp(v26, 0.001, 0.999), 0;
                        v23[v24] = v25;
                    end;
                    for _ = 1, 4 do
                        local v27 = #v23 + 1;
                        local v28 = {};
                        local v29 = math.random();
                        v28[1], v28[2] = math.clamp(v29, 0.001, 0.999), v22;
                        v23[v27] = v28;
                    end;
                    table.sort(v23, function(p30, p31) --[[ Line: 130 ]]
                        return p30[1] < p31[1];
                    end);
                    local v32 = { NumberSequenceKeypoint.new(0, v22) };
                    for v33 = 1, #v23 do
                        local v34 = v23[v33];
                        v32[#v32 + 1] = NumberSequenceKeypoint.new(v34[1], v34[2]);
                    end;
                    v32[#v32 + 1] = NumberSequenceKeypoint.new(1, v22);
                    return NumberSequence.new(v32);
                end)
            }), u1.createElement("UIStroke", {
                Transparency = 0,
                Thickness = 0.5,
                ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                Color = Color3.new(1, 1, 1),
                LineJoinMode = Enum.LineJoinMode.Round
            }) }) });
end;
return v8;