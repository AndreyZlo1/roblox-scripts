-- Services.InterfaceService.HUDInterface.HealthComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local u1 = shared.import("Roact");
local v2 = u1.Component:extend("Health");
function v2.render(p3) --[[ Line: 5 ]]
    -- upvalues: u1 (copy)
    local l__props__1 = p3.props;
    local l__Health__2 = l__props__1.Health;
    local l__Stamina__3 = l__props__1.Stamina;
    return u1.createElement("Frame", {
        BackgroundTransparency = 1,
        LayoutOrder = 6,
        Size = UDim2.new(0.15, 0, 0.03, 0)
    }, {
        Bar = u1.createElement("Frame", {
            BackgroundTransparency = 0.2,
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(1, 0),
            Position = UDim2.fromScale(1, 0),
            Size = l__Health__2:map(function(p4) --[[ Line: 18 ]]
                return UDim2.new(p4, 0, 0.5, 0);
            end),
            BackgroundColor3 = Color3.new(0, 0, 0)
        }, {
            Color = u1.createElement("Frame", {
                BackgroundTransparency = 0.1,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0),
                BackgroundColor3 = l__Health__2:map(function(p5) --[[ Line: 29 ]]
                    return Color3.fromRGB(213, 92, 92):Lerp(Color3.fromRGB(107, 213, 95), p5);
                end)
            })
        }),
        Stamina = u1.createElement("Frame", {
            BackgroundTransparency = 0.2,
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(1, 0),
            Position = UDim2.fromScale(1, 0.7),
            Size = l__Stamina__3:map(function(p6) --[[ Line: 39 ]]
                return UDim2.new(p6, 0, 0.3, 0);
            end),
            BackgroundColor3 = Color3.new(0, 0, 0)
        }, {
            Color = u1.createElement("Frame", {
                BackgroundTransparency = 0.1,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0),
                BackgroundColor3 = Color3.fromRGB(160, 211, 255)
            })
        })
    });
end;
return v2;