-- Services.InterfaceService.HUDInterface.HUDComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _, u3 = shared.import("require", "Roact", "network", "server");
local l__TweenService__1 = game:GetService("TweenService");
local u4 = v1("ClientService");
local u5 = v1("StatsService");
local u6 = v1("GameSettings");
local u7 = v1("convertUnit");
local u8 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u9 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u10 = Font.new("rbxasset://fonts/families/RobotoMono.json");
local u11 = v1("RoactTween");
local u12 = v1("InputService");
local u13 = v1("ToolSlotComponent");
local u14 = v1("WeaponComponent");
local u15 = v1("HealthComponent");
local u16 = v1("GenericComponent");
local u17 = v1("CompoundComponent");
local u18 = v1("RoundInformationComponent");
local u19 = v1("RoundWinComponent");
local u20 = v1("DeathScreenComponent");
local u21 = v1("convertToHMS");
local v22 = u2.Component:extend("HUD");
function v22.init(u23, p24) --[[ Line: 32 ]]
    -- upvalues: u11 (copy), u2 (copy), u6 (copy), u5 (copy), l__TweenService__1 (copy)
    u23.DeathScreenTween = p24.DeathScreenTween;
    u23.Stamina = p24.Stamina;
    u23.Health = p24.Health;
    u23.Downed = p24.Downed;
    u23.Bleeding = p24.Bleeding;
    u23.CQB = p24.CQB;
    u23.Counter = p24.Counter;
    u23.Zero = p24.Zero;
    u23.Dragged = p24.Dragged;
    u23.Compass = p24.Compass;
    u23.Combat = p24.Combat;
    u23.Smoke = p24.Smoke;
    u23.Immortal = p24.Immortal;
    u23.Capturing = p24.Capturing;
    u23.RoundTimer = p24.RoundTimer;
    u23.RoundScore = p24.RoundScore;
    u23.RoundObjective = p24.RoundObjective;
    u23.EXPBar = u11.new(0, TweenInfo.new(2, Enum.EasingStyle.Sine, Enum.EasingDirection.In, 0));
    u23.BoosterRef = u2.createRef();
    local v25, v26 = u2.createBinding(0);
    u23.CurrentLevel = v25;
    u23._updateLevel = v26;
    local v27, v28 = u2.createBinding(0);
    u23.CurrentEXP = v27;
    u23._updateEXP = v28;
    local u29 = nil;
    u23.Conn = p24.AddEXP:Connect(function(p30, p31) --[[ Line: 58 ]]
        -- upvalues: u6 (ref), u29 (ref), u23 (copy), u5 (ref), l__TweenService__1 (ref)
        if u6.ExpBar == 2 then
        else
            if u29 then
                task.cancel(u29);
            end;
            u29 = task.delay(6, function() --[[ Line: 66 ]]
                -- upvalues: u29 (ref), u23 (ref)
                u29 = nil;
                u23.EXPBar:SetGoal(0);
            end);
            u23._updateLevel(u5.Level);
            u23._updateEXP(u5.EXP / u5.MaxEXP);
            u23.EXPBar:SetGoal(1);
            local v32 = u23.BoosterRef:getValue();
            if v32 then
                local v33 = "+" .. p30 .. " EXP";
                if p31 then
                    v33 = v33 .. " (BOOSTER)";
                end;
                local u34 = Instance.new("Frame");
                u34.BackgroundTransparency = 1;
                u34.Size = UDim2.fromScale(1, 0.07);
                local u35 = Instance.new("TextLabel");
                u35.BackgroundTransparency = 1;
                u35.FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal);
                u35.Position = UDim2.fromScale(-0.5, 0);
                u35.Size = UDim2.fromScale(1, 1);
                u35.Text = v33;
                u35.TextColor3 = Color3.new();
                u35.TextScaled = true;
                u35.TextTransparency = 1;
                u35.TextXAlignment = Enum.TextXAlignment.Left;
                local u36 = Instance.new("TextLabel");
                u36.BackgroundTransparency = 1;
                u36.FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal);
                u36.Position = UDim2.fromOffset(0, -1);
                u36.Size = UDim2.fromScale(1, 1);
                u36.Text = v33;
                u36.TextColor3 = p31 and Color3.fromRGB(255, 170, 0) or Color3.new(1, 1, 1);
                u36.TextScaled = true;
                u36.TextXAlignment = Enum.TextXAlignment.Left;
                u36.TextTransparency = 1;
                u36.Parent = u35;
                l__TweenService__1:Create(u35, TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.In, 0), {
                    TextTransparency = 0.5,
                    Position = UDim2.fromScale(0, 0)
                }):Play();
                l__TweenService__1:Create(u36, TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.In, 0), {
                    TextTransparency = 0.5
                }):Play();
                u35.Parent = u34;
                u34.Parent = v32;
                task.delay(3.5, function() --[[ Line: 130 ]]
                    -- upvalues: l__TweenService__1 (ref), u35 (copy), u36 (copy), u34 (copy)
                    l__TweenService__1:Create(u35, TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.In, 0), {
                        TextTransparency = 1
                    }):Play();
                    l__TweenService__1:Create(u36, TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.In, 0), {
                        TextTransparency = 1
                    }):Play();
                    task.delay(0.5, function() --[[ Line: 137 ]]
                        -- upvalues: u34 (ref)
                        u34:Destroy();
                    end);
                end);
            end;
        end;
    end);
end;
function v22.willUnmount(p37) --[[ Line: 144 ]]
    p37.Conn:Disconnect();
end;
function v22.render(p38) --[[ Line: 148 ]]
    -- upvalues: u12 (copy), u4 (copy), u3 (copy), u2 (copy), u16 (copy), u20 (copy), u9 (copy), u19 (copy), u18 (copy), u8 (copy), u21 (copy), u7 (copy), u13 (copy), u14 (copy), u15 (copy), u10 (copy), u17 (copy)
    local l__props__2 = p38.props;
    local l__Name__3 = u12:GetBind("Bleed").Name;
    local v39 = {};
    local l__LocalClient__4 = u4.LocalClient;
    if u3.HUMAN_STATS then
        v39 = l__LocalClient__4 and { u2.createElement(u16, {
                Layout = 4,
                Color = Color3.fromRGB(20, 111, 172),
                Value = l__LocalClient__4.Thirst
            }), u2.createElement(u16, {
                Layout = 5,
                Color = Color3.fromRGB(154, 77, 39),
                Value = l__LocalClient__4.Hunger
            }) } or v39;
    end;
    local l__Dragged__5 = p38.Dragged;
    local v41 = p38.EXPBar:Map(function(p40) --[[ Line: 170 ]]
        return 1 - p40 * 0.5;
    end);
    local l__createFragment__6 = u2.createFragment;
    local v42 = {};
    local v46 = u2.createElement("Frame", {
        BackgroundTransparency = 1,
        AnchorPoint = Vector2.new(0, 0.5),
        Position = UDim2.fromScale(0.01, 0.5),
        Size = UDim2.fromScale(0.3, 0.2),
        SizeConstraint = Enum.SizeConstraint.RelativeYY
    }, {
        Bar = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.fromRGB(103, 103, 103),
            BackgroundTransparency = v41,
            BorderColor3 = Color3.new(),
            Position = UDim2.fromScale(0.05, 0.15),
            Size = UDim2.fromScale(0.02, 0.7)
        }, {
            Full = u2.createElement("Frame", {
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 1),
                BackgroundColor3 = Color3.new(1, 1, 1),
                BackgroundTransparency = v41,
                BorderColor3 = Color3.new(),
                Position = UDim2.fromScale(0, 1),
                Size = p38.CurrentEXP:map(function(p43) --[[ Line: 197 ]]
                    return UDim2.fromScale(1, p43);
                end)
            })
        }),
        To = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            AnchorPoint = Vector2.new(0.5, 0),
            FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
            TextTransparency = v41,
            Position = UDim2.fromScale(0.06, 0),
            Size = UDim2.fromScale(0.1, 0.1),
            Text = p38.CurrentLevel:map(function(p44) --[[ Line: 213 ]]
                return p44 + 1;
            end),
            TextColor3 = Color3.new()
        }, {
            White = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
                TextTransparency = v41,
                Position = UDim2.fromOffset(0, -1),
                Size = UDim2.fromScale(1, 1),
                Text = p38.CurrentLevel:map(function(p45) --[[ Line: 229 ]]
                    return p45 + 1;
                end),
                TextColor3 = Color3.new(1, 1, 1)
            })
        }),
        From = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            AnchorPoint = Vector2.new(0.5, 0),
            FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
            TextTransparency = v41,
            Position = UDim2.fromScale(0.06, 0.9),
            Size = UDim2.fromScale(0.1, 0.1),
            Text = p38.CurrentLevel,
            TextColor3 = Color3.new()
        }, {
            White = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12187375422", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
                TextTransparency = v41,
                Position = UDim2.fromOffset(0, -1),
                Size = UDim2.fromScale(1, 1),
                Text = p38.CurrentLevel,
                TextColor3 = Color3.new(1, 1, 1)
            })
        }),
        List = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Position = UDim2.fromScale(0.15, 0),
            Size = UDim2.fromScale(0.85, 1),
            [u2.Ref] = p38.BoosterRef
        }, {
            UIListLayout = u2.createElement("UIListLayout", {
                SortOrder = Enum.SortOrder.LayoutOrder,
                VerticalAlignment = Enum.VerticalAlignment.Center
            })
        })
    });
    local v47 = u2.createElement(u20, {
        DeathScreen = l__props__2.DeathScreen,
        DeathScreenTween = p38.DeathScreenTween
    });
    local v51 = u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Position = UDim2.fromScale(0.5, 0.8),
        AnchorPoint = Vector2.new(0.5, 0),
        Size = UDim2.fromScale(0.25, 0.06),
        Visible = p38.Capturing:map(function(p48) --[[ Line: 287 ]]
            local v49;
            if p48 > 0 then
                v49 = p48 < 1;
            else
                v49 = false;
            end;
            return v49;
        end),
        SizeConstraint = Enum.SizeConstraint.RelativeYY
    }, { u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "CAPTURING POINT",
            TextTransparency = 0.2,
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.new(-0.5, 0, 0.2, 0),
            Size = UDim2.new(2, 0, 0.4, 0),
            FontFace = u9,
            TextColor3 = Color3.new(0, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Center
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "CAPTURING POINT",
                TextTransparency = 0.1,
                TextScaled = true,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0),
                FontFace = u9,
                TextColor3 = Color3.new(1, 0.5, 0),
                TextXAlignment = Enum.TextXAlignment.Center
            }) }), u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.1,
            BackgroundColor3 = Color3.new(),
            Size = UDim2.fromScale(1.5, 0.05),
            Position = UDim2.fromScale(-0.25, 0)
        }, { u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundTransparency = 0.1,
                BackgroundColor3 = Color3.new(1, 0.5, 0),
                Size = p38.Capturing:map(function(p50) --[[ Line: 331 ]]
                    return UDim2.fromScale(p50, 1);
                end),
                Position = UDim2.new(0, 0, 0, -1)
            }) }) });
    local v64 = u2.createElement("Frame", {
        BackgroundTransparency = 1,
        Position = UDim2.fromScale(0.5, 0.8),
        AnchorPoint = Vector2.new(0.5, 0),
        Size = UDim2.fromScale(0.25, 0.06),
        Visible = p38.Downed:map(function(p52) --[[ Line: 342 ]]
            return p52 < 1;
        end),
        SizeConstraint = Enum.SizeConstraint.RelativeYY
    }, {
        u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "BLEEDING OUT",
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.new(-0.5, 0, 0.2, 0),
            Size = UDim2.new(2, 0, 0.4, 0),
            FontFace = u9,
            TextTransparency = l__Dragged__5:map(function(p53) --[[ Line: 355 ]]
                return p53 and 0.8 or 0.2;
            end),
            TextColor3 = Color3.new(0, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Center
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "BLEEDING OUT",
                TextScaled = true,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0),
                FontFace = u9,
                TextTransparency = l__Dragged__5:map(function(p54) --[[ Line: 370 ]]
                    return p54 and 0.7 or 0.1;
                end),
                TextColor3 = Color3.fromRGB(253, 89, 89),
                TextXAlignment = Enum.TextXAlignment.Center
            }) }),
        u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextTransparency = 0.2,
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.new(-0.5, 0, -0.6, 0),
            Size = UDim2.new(2, 0, 0.4, 0),
            FontFace = u9,
            Text = l__Dragged__5:map(function(p55) --[[ Line: 385 ]]
                return (p55 and p55:upper() or "") .. " IS DRAGGING YOU";
            end),
            Visible = l__Dragged__5:map(function(p56) --[[ Line: 388 ]]
                return p56 and true or false;
            end),
            TextColor3 = Color3.new(0, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Center
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextTransparency = 0.1,
                TextScaled = true,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0),
                FontFace = u9,
                Text = l__Dragged__5:map(function(p57) --[[ Line: 403 ]]
                    return (p57 and p57:upper() or "") .. " IS DRAGGING YOU";
                end),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = Enum.TextXAlignment.Center
            }) }),
        u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.new(-0.5, 0, 0.6, 0),
            Size = UDim2.new(2, 0, 0.3, 0),
            FontFace = u9,
            Text = "HOLD [" .. l__Name__3 .. "] TO SLOW BLEEDING",
            TextTransparency = l__Dragged__5:map(function(p58) --[[ Line: 420 ]]
                return p58 and 0.8 or 0.2;
            end),
            TextColor3 = Color3.new(0, 0, 0),
            Visible = p38.Bleeding:map(function(p59) --[[ Line: 425 ]]
                return not p59;
            end),
            TextXAlignment = Enum.TextXAlignment.Center
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0),
                FontFace = u9,
                Text = "HOLD [" .. l__Name__3 .. "] TO SLOW BLEEDING",
                TextTransparency = l__Dragged__5:map(function(p60) --[[ Line: 438 ]]
                    return p60 and 0.7 or 0.1;
                end),
                TextColor3 = Color3.fromRGB(255, 255, 255),
                TextXAlignment = Enum.TextXAlignment.Center
            }) }),
        u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = l__Dragged__5:map(function(p61) --[[ Line: 449 ]]
                return p61 and 0.7 or 0.1;
            end),
            BackgroundColor3 = Color3.new(),
            Size = UDim2.fromScale(1.5, 0.05),
            Position = UDim2.fromScale(-0.25, 0)
        }, { u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundTransparency = l__Dragged__5:map(function(p62) --[[ Line: 458 ]]
                    return p62 and 0.7 or 0.1;
                end),
                BackgroundColor3 = Color3.fromRGB(253, 89, 89),
                Size = p38.Downed:map(function(p63) --[[ Line: 462 ]]
                    return UDim2.fromScale(p63, 1);
                end),
                Position = UDim2.new(0, 0, 0, -1)
            }) })
    });
    local l__Spectating__7 = l__props__2.Spectating;
    if l__Spectating__7 then
        l__Spectating__7 = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(),
            Size = UDim2.fromScale(1, 1)
        }, { u2.createElement("UIGradient", {
                Rotation = -90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.25), NumberSequenceKeypoint.new(0.2, 0.75), NumberSequenceKeypoint.new(1, 1) })
            }), u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "SPECTATING",
                TextTransparency = 1,
                TextScaled = true,
                AutoLocalize = false,
                Position = UDim2.fromScale(0, 0.8),
                Size = UDim2.new(1, 0, 0.1, 0),
                FontFace = u9,
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = Enum.TextXAlignment.Center
            }, { u2.createElement("UIStroke", {
                    Transparency = 0.5,
                    Thickness = 1,
                    ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                    Color = Color3.new(1, 1, 1),
                    LineJoinMode = Enum.LineJoinMode.Round
                }) }) });
    end;
    local l__RoundWin__8 = l__props__2.RoundWin;
    if l__RoundWin__8 then
        l__RoundWin__8 = u2.createElement(u19, {
            RoundWin = l__props__2.RoundWin
        });
    end;
    local l__Round__9 = l__props__2.Round;
    if l__Round__9 then
        l__Round__9 = u2.createElement(u18, {
            Location = l__props__2.Round,
            Counter = p38.Counter,
            RoundTimer = p38.RoundTimer,
            RoundScore = p38.RoundScore,
            RoundObjective = p38.RoundObjective,
            Objective = l__props__2.Objective
        });
    end;
    local v71 = u2.createElement("Frame", {
        BackgroundTransparency = 1,
        AnchorPoint = Vector2.new(0.5, 0),
        Position = UDim2.new(0.5, 0, 0, 0),
        Size = UDim2.new(0, 0, 1, 0)
    }, { u2.createElement("UIAspectRatioConstraint", {
            AspectRatio = 1.778,
            AspectType = Enum.AspectType.ScaleWithParentSize,
            DominantAxis = Enum.DominantAxis.Height
        }), u2.createElement("Frame", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(1, 0),
            Position = UDim2.new(0.955, 0, 0.03, 0),
            Size = UDim2.new(1, 0, 1, 0)
        }, {
            u2.createElement("UIListLayout", {
                FillDirection = Enum.FillDirection.Vertical,
                HorizontalAlignment = Enum.HorizontalAlignment.Right,
                SortOrder = Enum.SortOrder.LayoutOrder,
                VerticalAlignment = Enum.VerticalAlignment.Top,
                Padding = UDim.new(0.005, 0)
            }),
            u2.createElement("Frame", {
                LayoutOrder = 0,
                BorderSizePixel = 0,
                BackgroundTransparency = 0.85,
                Visible = p38.Immortal:map(function(p65) --[[ Line: 540 ]]
                    return p65 == true and true or p65 > 0;
                end),
                BackgroundColor3 = Color3.fromRGB(25, 129, 255),
                Size = p38.Immortal:map(function(p66) --[[ Line: 545 ]]
                    if p66 == true then
                        return UDim2.fromScale(0.115, 0.04);
                    else
                        return UDim2.fromScale(0.14, 0.04);
                    end;
                end)
            }, { u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Position = UDim2.fromScale(1, 0),
                    AnchorPoint = Vector2.new(1, 0),
                    Size = UDim2.fromScale(1, 1),
                    SizeConstraint = Enum.SizeConstraint.RelativeYY
                }, { u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        RichText = true,
                        TextScaled = true,
                        AutoLocalize = false,
                        AnchorPoint = Vector2.new(1, 0.5),
                        Position = UDim2.fromScale(0.5, 0.5),
                        Size = UDim2.fromScale(20, 0.5),
                        FontFace = u8,
                        Text = p38.Immortal:map(function(p67) --[[ Line: 566 ]]
                            -- upvalues: u21 (ref)
                            return p67 == true and "YOU ARE PROTECTED" or "PROTECTION EXPIRING <b>" .. u21(p67) .. "</b>";
                        end),
                        TextColor3 = Color3.new(1, 1, 1),
                        TextXAlignment = Enum.TextXAlignment.Right
                    }) }), u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Position = UDim2.fromScale(0, 0),
                    AnchorPoint = Vector2.new(0, 0),
                    Size = UDim2.fromScale(1, 1),
                    SizeConstraint = Enum.SizeConstraint.RelativeYY
                }, { u2.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        Image = "rbxassetid://138462348915773",
                        Size = UDim2.fromScale(0.6, 0.6),
                        SizeConstraint = Enum.SizeConstraint.RelativeYY,
                        AnchorPoint = Vector2.new(0, 0.5),
                        Position = UDim2.fromScale(0.5, 0.5),
                        ImageColor3 = Color3.new(1, 1, 1)
                    }) }) }),
            u2.createElement("Frame", {
                LayoutOrder = 0,
                BorderSizePixel = 0,
                BackgroundTransparency = 0.85,
                Visible = p38.Combat:map(function(p68) --[[ Line: 599 ]]
                    return p68 > 0;
                end),
                BackgroundColor3 = Color3.fromRGB(255, 0, 4),
                Size = UDim2.fromScale(0.1, 0.04)
            }, { u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Position = UDim2.fromScale(1, 0),
                    AnchorPoint = Vector2.new(1, 0),
                    Size = UDim2.fromScale(1, 1),
                    SizeConstraint = Enum.SizeConstraint.RelativeYY
                }, { u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        RichText = true,
                        TextScaled = true,
                        AutoLocalize = false,
                        AnchorPoint = Vector2.new(1, 0.5),
                        Position = UDim2.fromScale(0.5, 0.5),
                        Size = UDim2.fromScale(20, 0.5),
                        FontFace = u8,
                        Text = p38.Combat:map(function(p69) --[[ Line: 620 ]]
                            -- upvalues: u21 (ref)
                            return "IN COMBAT <b>" .. u21(p69) .. "</b>";
                        end),
                        TextColor3 = Color3.new(1, 1, 1),
                        TextXAlignment = Enum.TextXAlignment.Right
                    }) }), u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Position = UDim2.fromScale(0, 0),
                    AnchorPoint = Vector2.new(0, 0),
                    Size = UDim2.fromScale(1, 1),
                    SizeConstraint = Enum.SizeConstraint.RelativeYY
                }, { u2.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        Image = "rbxassetid://80619550813478",
                        Size = UDim2.fromScale(0.6, 0.6),
                        SizeConstraint = Enum.SizeConstraint.RelativeYY,
                        AnchorPoint = Vector2.new(0, 0.5),
                        Position = UDim2.fromScale(0.5, 0.5),
                        ImageColor3 = Color3.new(1, 1, 1)
                    }) }) }),
            u2.createElement("Frame", {
                LayoutOrder = 0,
                BorderSizePixel = 0,
                BackgroundTransparency = 0.85,
                Visible = p38.Smoke:map(function(p70) --[[ Line: 650 ]]
                    return #p70 > 0;
                end),
                BackgroundColor3 = Color3.fromRGB(255, 136, 0),
                Size = UDim2.fromScale(0.105, 0.04)
            }, { u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Position = UDim2.fromScale(1, 0),
                    AnchorPoint = Vector2.new(1, 0),
                    Size = UDim2.fromScale(1, 1),
                    SizeConstraint = Enum.SizeConstraint.RelativeYY
                }, { u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        RichText = true,
                        TextScaled = true,
                        AutoLocalize = false,
                        AnchorPoint = Vector2.new(1, 0.5),
                        Position = UDim2.fromScale(0.5, 0.5),
                        Size = UDim2.fromScale(20, 0.5),
                        FontFace = u8,
                        Text = p38.Smoke,
                        TextColor3 = Color3.new(1, 1, 1),
                        TextXAlignment = Enum.TextXAlignment.Right
                    }) }), u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Position = UDim2.fromScale(0, 0),
                    AnchorPoint = Vector2.new(0, 0),
                    Size = UDim2.fromScale(1, 1),
                    SizeConstraint = Enum.SizeConstraint.RelativeYY
                }, { u2.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        Image = "rbxassetid://121458453818954",
                        Size = UDim2.fromScale(0.6, 0.6),
                        SizeConstraint = Enum.SizeConstraint.RelativeYY,
                        AnchorPoint = Vector2.new(0, 0.5),
                        Position = UDim2.fromScale(0.5, 0.5),
                        ImageColor3 = Color3.new(1, 1, 1)
                    }) }) })
        }), u2.createElement("Frame", {
            BackgroundTransparency = 1,
            ClipsDescendants = true,
            AnchorPoint = Vector2.new(1, 0),
            Position = UDim2.new(0.955, 0, 0.05, 0),
            Size = UDim2.new(1, 0, 0.2, 0)
        }, { u2.createElement("Frame", {
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(1, 0),
                Position = UDim2.new(1, -1, 0, 1),
                Size = UDim2.new(1, 0, 1, 0)
            }, { u2.createElement("UIListLayout", {
                    Padding = UDim.new(0.05, 0),
                    FillDirection = Enum.FillDirection.Vertical,
                    HorizontalAlignment = Enum.HorizontalAlignment.Right,
                    SortOrder = Enum.SortOrder.LayoutOrder,
                    VerticalAlignment = Enum.VerticalAlignment.Top
                }), u2.createFragment(l__props__2.Killfeed) }) }) });
    local v77 = u2.createElement("Frame", {
        BackgroundTransparency = 1,
        AnchorPoint = Vector2.new(0.5, 1),
        Position = UDim2.new(0.5, 0, 1, 0),
        Size = UDim2.new(0, 0, 1, 0),
        Visible = l__props__2.PlayerInfoVisible
    }, {
        u2.createElement("UIAspectRatioConstraint", {
            AspectRatio = 1.778,
            AspectType = Enum.AspectType.ScaleWithParentSize,
            DominantAxis = Enum.DominantAxis.Height
        }),
        u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextTransparency = 0.2,
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.new(0, 0, 0.55, 0),
            Size = UDim2.new(1, 0, 0.02, 0),
            FontFace = u9,
            Text = p38.Zero:map(function(p72) --[[ Line: 740 ]]
                -- upvalues: u7 (ref)
                return not p72 and "" or "ZEROING DISTANCE: " .. u7(p72):upper();
            end),
            TextColor3 = Color3.new(0, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Center
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextTransparency = 0.24,
                TextScaled = true,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0),
                FontFace = u9,
                Text = p38.Zero:map(function(p73) --[[ Line: 758 ]]
                    -- upvalues: u7 (ref)
                    return not p73 and "" or "ZEROING DISTANCE: " .. u7(p73):upper();
                end),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = Enum.TextXAlignment.Center
            }) }),
        u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextTransparency = 0.2,
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.new(0, 0, 0.41, 0),
            Size = UDim2.new(1, 0, 0.04, 0),
            FontFace = u9,
            Text = p38.Compass:map(function(p74) --[[ Line: 777 ]]
                return p74 or "";
            end),
            TextColor3 = Color3.new(0, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Center
        }, { u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextTransparency = 0.24,
                TextScaled = true,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0),
                FontFace = u9,
                Text = p38.Compass:map(function(p75) --[[ Line: 792 ]]
                    return p75 or "";
                end),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = Enum.TextXAlignment.Center
            }) }),
        u2.createElement("Frame", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(1, 1),
            Position = UDim2.new(0.955, 0, 0.9, 0),
            Size = UDim2.new(1, 0, 1, 0)
        }, {
            u2.createElement("UIListLayout", {
                FillDirection = Enum.FillDirection.Vertical,
                HorizontalAlignment = Enum.HorizontalAlignment.Right,
                SortOrder = Enum.SortOrder.LayoutOrder,
                VerticalAlignment = Enum.VerticalAlignment.Bottom,
                Padding = UDim.new(0.005, 0)
            }),
            u2.createElement(u13, {
                Inventories = l__props__2.Inventories,
                Bumped = l__props__2.Bumped
            }),
            u2.createElement(u14, {
                CQB = p38.CQB,
                Weapon = l__props__2.Weapon
            }),
            u2.createElement(u15, {
                Health = p38.Health,
                Stamina = p38.Stamina
            }),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                LayoutOrder = 2,
                Size = UDim2.fromScale(0.05, 0.04),
                Visible = l__props__2.Watch:map(function(p76) --[[ Line: 831 ]]
                    return p76 and true or false;
                end)
            }, { u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Size = UDim2.fromScale(1, 0.7)
                }, { u2.createElement("UIStroke", {
                        Thickness = 1,
                        ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                        BorderStrokePosition = Enum.BorderStrokePosition.Inner,
                        Color = Color3.new(1, 1, 1)
                    }), u2.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        Text = "00:00",
                        TextTransparency = 0.8,
                        TextScaled = true,
                        AutoLocalize = false,
                        Position = UDim2.fromScale(0, 0.1),
                        Size = UDim2.fromScale(1, 0.8),
                        FontFace = u10,
                        TextColor3 = Color3.new(1, 1, 1),
                        TextXAlignment = Enum.TextXAlignment.Center
                    }, { u2.createElement("TextLabel", {
                            BackgroundTransparency = 1,
                            TextTransparency = 0,
                            TextScaled = true,
                            AutoLocalize = false,
                            Position = UDim2.fromScale(0, 0),
                            Size = UDim2.fromScale(1, 1),
                            FontFace = u10,
                            Text = l__props__2.Watch,
                            TextColor3 = Color3.new(1, 1, 1),
                            TextXAlignment = Enum.TextXAlignment.Center
                        }) }) }) }),
            u2.createFragment(v39)
        })
    });
    local l__Compound__10 = l__props__2.Compound;
    if l__Compound__10 then
        l__Compound__10 = u2.createElement(u17, {
            Compound = l__props__2.Compound
        });
    end;
    local l__Quest__11 = l__props__2.Quest;
    if l__Quest__11 then
        l__Quest__11 = u2.createElement(u17, {
            IsQuest = true,
            Compound = l__props__2.Quest,
            HasCompound = l__props__2.Compound
        });
    end;
    v42[1], v42[2], v42[3], v42[4], v42[5], v42[6], v42[7], v42[8], v42[9], v42[10], v42[11] = v46, v47, v51, v64, l__Spectating__7, l__RoundWin__8, l__Round__9, v71, v77, l__Compound__10, l__Quest__11;
    return l__createFragment__6(v42);
end;
return v22;