-- Services.InterfaceService.HUDInterface.RoundInformationComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local u1, v2 = shared.import("Roact", "require");
local u3 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u4 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u5 = v2("PostProcessingService");
local u6 = v2("SoundService");
local u7 = v2("ClientService");
local u8 = v2("Mathf");
local l__Debris__1 = game:GetService("Debris");
game:GetService("Lighting");
local l__RunService__2 = game:GetService("RunService");
local v9 = u1.Component:extend("Health");
local function u20(p10, p11) --[[ Line: 27 ]]
    -- upvalues: u1 (copy)
    local v12 = p10 and Color3.fromRGB(255, 10, 14) or Color3.fromRGB(52, 133, 255);
    local v13 = p11.Actor and p11.Actor.Alive and true or false;
    local l__createElement__3 = u1.createElement;
    local v14 = "ImageLabel";
    local v15 = {
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 1),
        Image = "rbxthumb://type=AvatarHeadShot&id=" .. p11.Owner.UserId .. "&w=150&h=150",
        ImageColor3 = v13 and Color3.new(1, 1, 1) or Color3.new(0, 0, 0),
        LayoutOrder = p11.Order
    };
    local v16 = {};
    local v17 = u1.createElement("UICorner", {
        CornerRadius = UDim.new(0.1, 0)
    });
    local v18 = u1.createElement("UIStroke", {
        Thickness = 1,
        ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
        Color = v12,
        LineJoinMode = Enum.LineJoinMode.Round
    });
    local v19 = p11.Actor and p11.Actor.ViewModel;
    if v19 then
        v19 = u1.createElement("Frame", {
            BorderSizePixel = 0,
            Size = UDim2.fromScale(1, 0.1),
            Position = UDim2.fromScale(0, 1.1),
            BackgroundColor3 = Color3.new(1, 1, 1)
        });
    end;
    v16[1], v16[2], v16[3] = v17, v18, v19;
    return l__createElement__3(v14, v15, v16);
end;
function v9.willUnmount(p21) --[[ Line: 59 ]]
    p21._click:Destroy();
    p21._conn:Disconnect();
    p21._alarm:Destroy();
    p21.CCEffect.Destroy();
    for _, v22 in p21._dynamicMusicInstances do
        v22.Bass:Destroy();
        v22.Synth:Destroy();
    end;
end;
function v9.init(u23, u24) --[[ Line: 72 ]]
    -- upvalues: u6 (copy), u5 (copy), l__RunService__2 (copy), u8 (copy), l__Debris__1 (copy), u7 (copy)
    u23.Counter = u24.Counter;
    u23.RoundTimer = u24.RoundTimer;
    u23.RoundScore = u24.RoundScore;
    u23.IsSmall = typeof(u24.Location) == "Vector3";
    u23._click = u6:CreateSound("Button", nil, false, "UISounds", "MatchCounter").Sound;
    if u23.IsSmall then
        local v25 = Instance.new("Attachment");
        v25.Parent = workspace.Terrain:FindFirstChild("Objective");
        u23._alarm = v25;
        u23._objectiveAlarm = u6:CreateSound("Ambience", v25, false, "Environment", "PVPObjective").Sound;
    end;
    u23.CCEffect = u5:AddColorCorrection({
        Saturation = u23.Counter:map(function(p26) --[[ Line: 90 ]]
            return -p26 / 5;
        end)
    }, nil, true);
    u23:setState({
        Red = {},
        Blue = {}
    });
    local function u29() --[[ Line: 100 ]]
        -- upvalues: u6 (ref), u23 (copy)
        local v27 = u6:CreateSound("Music", nil, false, "Music", "ObjectiveBass");
        local v28 = u6:CreateSound("Music", nil, false, "Music", "ObjectiveSynth");
        v27.Sound.Volume = 0;
        v28.Sound.Volume = 0;
        u23._dynamicMusicInstances[tick()] = {
            FadeIn = true,
            Bass = v27.Sound,
            Synth = v28.Sound
        };
    end;
    u23._dynamicMusicInstances = {};
    local u30 = 0;
    u23._conn = l__RunService__2.Heartbeat:Connect(function(p31) --[[ Line: 114 ]]
        -- upvalues: u24 (copy), u30 (ref), u23 (copy), u8 (ref), u29 (copy), l__Debris__1 (ref), u7 (ref)
        local v32 = u24.RoundObjective:getValue();
        if v32 == u30 then
            if u23._objectiveAlarm then
                u23._objectiveAlarm.Looping = false;
            end;
            if v32 < 1 then
                for _, v33 in u23._dynamicMusicInstances do
                    v33.FadeIn = false;
                end;
            else
                for v34, v35 in u23._dynamicMusicInstances do
                    u23._dynamicMusicInstances[v34] = nil;
                    l__Debris__1:AddItem(v35.Bass, 4);
                    l__Debris__1:AddItem(v35.Synth, 4);
                end;
            end;
        else
            u30 = v32;
            if u23._objectiveAlarm then
                u23._objectiveAlarm.Looping = true;
                if not u23._objectiveAlarm.IsPlaying then
                    u23._objectiveAlarm:Play();
                end;
            end;
            local v36 = false;
            for _, v37 in u23._dynamicMusicInstances do
                if v37.FadeIn then
                    if not v37.Played and (v37.Bass.TimeLength > 0 and v37.Synth.TimeLength > 0) then
                        v37.Played = true;
                        v37.Bass.TimePosition = v32 * 10;
                        v37.Synth.TimePosition = v32 * 10;
                        v37.Bass:Play();
                        v37.Synth:Play();
                    end;
                    if v37.Played then
                        v37.Bass.Volume = u8.Lerp(v37.Bass.Volume, 1, p31 * 2);
                        v37.Synth.Volume = u8.Lerp(v37.Synth.Volume, 1, p31 * 2);
                        v36 = true;
                    else
                        v36 = true;
                    end;
                    break;
                end;
            end;
            if not v36 then
                u29();
            end;
        end;
        for v38, v39 in u23._dynamicMusicInstances do
            if not v39.FadeIn then
                v39.Bass.Volume = u8.Lerp(v39.Bass.Volume, 0, p31 * 0.8);
                v39.Synth.Volume = u8.Lerp(v39.Synth.Volume, 0, p31 * 2);
                if v39.Bass.Volume < 0.02 then
                    v39.Synth:Destroy();
                    v39.Bass:Destroy();
                    u23._dynamicMusicInstances[v38] = nil;
                end;
            end;
        end;
        if u23.IsSmall then
            local v40 = {};
            local v41 = {};
            for _, v42 in u7:GetClients() do
                if v42.Squad == "Red" then
                    v41[#v41 + 1] = v42;
                elseif v42.Squad == "Blue" then
                    v40[#v40 + 1] = v42;
                end;
            end;
            u23:setState({
                Red = v41,
                Blue = v40
            });
        end;
    end);
end;
function v9.render(u43) --[[ Line: 197 ]]
    -- upvalues: u20 (copy), u1 (copy), u4 (copy), u3 (copy)
    local l__props__4 = u43.props;
    local v44 = {};
    for v45, v46 in u43.state.Red do
        v44[v45] = u20(true, v46);
    end;
    local v47 = {};
    for v48, v49 in u43.state.Blue do
        v47[v48] = u20(false, v49);
    end;
    local l__createFragment__5 = u1.createFragment;
    local v50 = {};
    local v62 = u1.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextTransparency = 0.2,
        TextScaled = true,
        Size = UDim2.fromScale(1, 0.05),
        Position = UDim2.fromScale(0, 0.26),
        AnchorPoint = Vector2.new(0, 0),
        Text = u43.Counter:map(function(p51) --[[ Line: 215 ]]
            -- upvalues: u43 (copy)
            local v52 = math.floor(p51);
            local v53 = math.max(0, v52);
            if u43._lastCounter == nil then
                u43._lastCounter = v53;
            elseif u43._lastCounter ~= v53 then
                u43._lastCounter = v53;
                if v53 <= 4 then
                    u43._click:Play();
                end;
            end;
            local v54 = math.floor(p51);
            return math.max(0, v54) + 1;
        end),
        Visible = u43.Counter:map(function(p55) --[[ Line: 227 ]]
            -- upvalues: u43 (copy)
            if p55 > 0 then
                return true;
            end;
            u43._lastCounter = nil;
            return false;
        end),
        TextColor3 = Color3.new(),
        FontFace = u4
    }, { u1.createElement("TextLabel", {
            TextTransparency = 0.1,
            BackgroundTransparency = 1,
            TextScaled = true,
            Size = UDim2.fromScale(1, 1),
            Position = UDim2.new(0, 0, 0, -1),
            AnchorPoint = Vector2.new(0, 0),
            Text = u43.Counter:map(function(p56) --[[ Line: 246 ]]
                local v57 = math.floor(p56);
                return math.max(0, v57) + 1;
            end),
            TextColor3 = u43.Counter:map(function(p58) --[[ Line: 249 ]]
                return p58 < 3 and Color3.new(0.952941, 0.447058, 0.447058) or Color3.new(1, 1, 1);
            end),
            FontFace = u4
        }), u1.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://17029819151",
            ImageTransparency = 0.1,
            ZIndex = 2,
            Size = UDim2.new(1.8, 0, 1.8, 0),
            Position = UDim2.new(0.5, 0, 0.5, 0),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            AnchorPoint = Vector2.new(0.5, 0.5),
            Rotation = u43.Counter:map(function() --[[ Line: 262 ]]
                local v59 = workspace:GetServerTimeNow() * 3.141592653589793 % 3.141592653589793 / 2;
                return math.sin(v59) * 360;
            end),
            ImageColor3 = u43.Counter:map(function(p60) --[[ Line: 265 ]]
                return p60 < 3 and Color3.new(0.952941, 0.447058, 0.447058) or Color3.new(1, 1, 1);
            end)
        }), u1.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://17029819151",
            ImageTransparency = 0.2,
            Size = UDim2.new(1.8, 0, 1.8, 0),
            Position = UDim2.new(0.5, 0, 0.5, 0),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            ImageColor3 = Color3.new(),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Rotation = u43.Counter:map(function() --[[ Line: 279 ]]
                local v61 = workspace:GetServerTimeNow() * 3.141592653589793 % 3.141592653589793 / 2;
                return math.sin(v61) * 360;
            end)
        }) });
    local l__createElement__6 = u1.createElement;
    local v63 = "Frame";
    local v64 = {
        BackgroundTransparency = 1,
        Position = UDim2.fromScale(0.5, 0.04),
        AnchorPoint = Vector2.new(0.5, 0),
        Size = UDim2.fromScale(0.25, 0.06),
        SizeConstraint = Enum.SizeConstraint.RelativeYY
    };
    local v65 = {};
    local l__IsSmall__7 = u43.IsSmall;
    if l__IsSmall__7 then
        l__IsSmall__7 = u1.createElement("Frame", {
            BackgroundTransparency = 0.6,
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(0, 0, 0),
            Position = UDim2.fromScale(0.7, 0.25),
            Size = UDim2.new(0, 1, 0.5, 0)
        }, { u1.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.new(1, 1, 1),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0)
            }) });
    end;
    local l__IsSmall__8 = u43.IsSmall;
    if l__IsSmall__8 then
        l__IsSmall__8 = u1.createElement("Frame", {
            BackgroundTransparency = 0.6,
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.new(0, 0, 0),
            Position = UDim2.fromScale(0.3, 0.25),
            Size = UDim2.new(0, 1, 0.5, 0)
        }, { u1.createElement("Frame", {
                BackgroundTransparency = 0.5,
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.new(1, 1, 1),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0)
            }) });
    end;
    v65[1], v65[2], v65[3], v65[4], v65[5], v65[6], v65[7], v65[8] = l__IsSmall__7, l__IsSmall__8, u1.createElement("TextLabel", {
    BackgroundTransparency = 1,
    TextTransparency = 0.2,
    TextScaled = true,
    AutoLocalize = false,
    AnchorPoint = Vector2.new(0, 0),
    Position = UDim2.new(0, 0, 0, 0),
    Size = UDim2.new(1, 0, 0.5, 0),
    FontFace = u3,
    Text = u43.RoundTimer:map(function(p66) --[[ Line: 328 ]]
        local v67 = (p66 - p66 % 60) / 60;
        return v67 - 0 .. ":" .. string.format("%02i", p66 - v67 * 60);
    end),
    TextColor3 = Color3.new(0, 0, 0),
    TextXAlignment = Enum.TextXAlignment.Center
}, { u1.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextTransparency = 0.1,
        TextScaled = true,
        AutoLocalize = false,
        AnchorPoint = Vector2.new(0, 0),
        Position = UDim2.new(0, 0, 0, -1),
        Size = UDim2.new(1, 0, 1, 0),
        FontFace = u3,
        Text = u43.RoundTimer:map(function(p68) --[[ Line: 343 ]]
            local v69 = (p68 - p68 % 60) / 60;
            return v69 - 0 .. ":" .. string.format("%02i", p68 - v69 * 60);
        end),
        TextColor3 = Color3.new(1, 1, 1),
        TextXAlignment = Enum.TextXAlignment.Center
    }) }), u1.createElement("TextLabel", {
    BackgroundTransparency = 1,
    TextTransparency = 0,
    TextScaled = true,
    AutoLocalize = false,
    AnchorPoint = Vector2.new(0, 0),
    Position = UDim2.new(0, 0, 0.5, 0),
    Size = UDim2.new(1, 0, 0.5, 0),
    FontFace = u4,
    Text = u43.RoundScore:map(function(p70) --[[ Line: 359 ]]
        return p70;
    end),
    RichText = not u43.IsSmall,
    TextColor3 = Color3.new(1, 1, 1),
    TextXAlignment = Enum.TextXAlignment.Center
}), u1.createElement("Frame", {
    BackgroundTransparency = 1,
    AnchorPoint = Vector2.new(1, 0),
    Size = UDim2.fromScale(0.6, 0.6),
    Position = UDim2.fromScale(1, 0.2),
    SizeConstraint = Enum.SizeConstraint.RelativeYY
}, { u1.createElement("UIListLayout", {
        HorizontalAlignment = Enum.HorizontalAlignment.Left,
        FillDirection = Enum.FillDirection.Horizontal,
        SortOrder = Enum.SortOrder.LayoutOrder,
        Padding = UDim.new(0.2, 0)
    }), u1.createFragment(v44) }), u1.createElement("Frame", {
    BackgroundTransparency = 1,
    AnchorPoint = Vector2.new(0, 0),
    Size = UDim2.fromScale(0.6, 0.6),
    Position = UDim2.fromScale(0, 0.2),
    SizeConstraint = Enum.SizeConstraint.RelativeYY
}, { u1.createElement("UIListLayout", {
        HorizontalAlignment = Enum.HorizontalAlignment.Right,
        FillDirection = Enum.FillDirection.Horizontal,
        SortOrder = Enum.SortOrder.LayoutOrder,
        Padding = UDim.new(0.2, 0)
    }), u1.createFragment(v47) }), u1.createElement("TextLabel", {
    BackgroundTransparency = 1,
    Text = "THE OBJECTIVE IS BEING SECURED",
    TextTransparency = 0.2,
    TextScaled = true,
    AutoLocalize = false,
    AnchorPoint = Vector2.new(0, 0),
    Position = UDim2.new(-0.5, 0, 1.6, 0),
    Size = UDim2.new(2, 0, 0.4, 0),
    FontFace = u3,
    Visible = l__props__4.Objective,
    TextColor3 = Color3.new(0, 0, 0),
    TextXAlignment = Enum.TextXAlignment.Center
}, { u1.createElement("TextLabel", {
        BackgroundTransparency = 1,
        Text = "THE OBJECTIVE IS BEING SECURED",
        TextTransparency = 0.1,
        TextScaled = true,
        AutoLocalize = false,
        AnchorPoint = Vector2.new(0, 0),
        Position = UDim2.new(0, 0, 0, -1),
        Size = UDim2.new(1, 0, 1, 0),
        FontFace = u3,
        TextColor3 = l__props__4.RoundObjective:map(function(p71) --[[ Line: 421 ]]
            return Color3.fromRGB(223, 149, 51):Lerp(Color3.fromRGB(230, 184, 124), math.sin(p71 * 100) / 2 + 0.5);
        end),
        TextXAlignment = Enum.TextXAlignment.Center
    }) }), u1.createElement("Frame", {
    BorderSizePixel = 0,
    BackgroundTransparency = 0.1,
    Visible = l__props__4.Objective,
    BackgroundColor3 = Color3.new(),
    Size = UDim2.fromScale(1.5, 0.05),
    Position = UDim2.fromScale(-0.25, 1.4)
}, { u1.createElement("Frame", {
        BorderSizePixel = 0,
        BackgroundTransparency = 0.1,
        BackgroundColor3 = l__props__4.RoundObjective:map(function(p72) --[[ Line: 440 ]]
            return Color3.fromRGB(223, 149, 51):Lerp(Color3.fromRGB(230, 184, 124), math.sin(p72 * 100) / 2 + 0.5);
        end),
        Size = l__props__4.RoundObjective:map(function(p73) --[[ Line: 443 ]]
            return UDim2.fromScale(p73, 1);
        end),
        Position = UDim2.new(0, 0, 0, -1)
    }) });
    v50[1], v50[2] = v62, l__createElement__6(v63, v64, v65);
    return l__createFragment__5(v50);
end;
return v9;