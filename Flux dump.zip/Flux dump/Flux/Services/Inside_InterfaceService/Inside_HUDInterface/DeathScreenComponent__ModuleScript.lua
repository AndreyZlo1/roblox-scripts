-- Services.InterfaceService.HUDInterface.DeathScreenComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local u1, v2 = shared.import("Roact", "require");
v2("PostProcessingService");
local u3 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
game:GetService("Lighting");
v2("RoactTween");
v2("SoundService");
local v4 = u1.Component:extend("Win");
function v4.willUnmount(_) --[[ Line: 19 ]] end;
function v4.init(p5, p6) --[[ Line: 22 ]]
    p5.Tween = p6.DeathScreenTween;
end;
function v4.render(p7) --[[ Line: 26 ]]
    -- upvalues: u1 (copy), u3 (copy)
    local l__DeathScreen__1 = p7.props.DeathScreen;
    return u1.createElement("Frame", {
        ZIndex = 2,
        BackgroundTransparency = p7.Tween:Map(function(p8) --[[ Line: 29 ]]
            return 1 - p8;
        end),
        BackgroundColor3 = Color3.new(),
        Size = UDim2.fromScale(1, 1),
        Position = UDim2.fromScale(0, 0)
    }, { u1.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "YOU DIED",
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0, 0.5),
            Position = UDim2.fromScale(0, 0.5),
            Size = UDim2.new(1, 0, 0.5, 0),
            FontFace = u3,
            Visible = p7.Tween:Map(function(p9) --[[ Line: 44 ]]
                return p9 > 0.01;
            end),
            TextTransparency = p7.Tween:Map(function(p10) --[[ Line: 47 ]]
                return 1 - math.clamp(p10 - 0.5, 0, 0.5) * 2;
            end),
            TextColor3 = Color3.fromRGB(253, 89, 89),
            TextXAlignment = Enum.TextXAlignment.Center
        }, { u1.createElement("UIGradient", {
                Rotation = 45,
                Color = ColorSequence.new(Color3.fromRGB(253, 89, 89)),
                Offset = Vector2.new(0, 0),
                Transparency = p7.Tween:Map(function(p11) --[[ Line: 59 ]]
                    local v12 = math.clamp(p11, 0, 0.5) * 2;
                    return NumberSequence.new({
                        NumberSequenceKeypoint.new(0, 0),
                        NumberSequenceKeypoint.new(math.clamp(v12 - 0.1, 0.001, 0.999), 0),
                        NumberSequenceKeypoint.new(math.clamp(v12 + 0.1, 0.001, 0.999), 1),
                        NumberSequenceKeypoint.new(1, 1)
                    });
                end)
            }), u1.createElement("UIStroke", {
                ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
                Color = Color3.new(1, 1, 1),
                LineJoinMode = Enum.LineJoinMode.Round,
                Transparency = p7.Tween:Map(function(p13) --[[ Line: 73 ]]
                    return math.clamp(p13 - 0.5, 0, 0.5) * 2;
                end)
            }) }), u1.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextTransparency = 0,
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0, 0.5),
            Position = p7.Tween:Map(function(p14) --[[ Line: 81 ]]
                return UDim2.fromScale(0, math.clamp(p14 - 0.65, 0, 0.05) + 0.5);
            end),
            Size = UDim2.new(1, 0, 0.03, 0),
            FontFace = u3,
            Text = l__DeathScreen__1,
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = Enum.TextXAlignment.Center
        }, { u1.createElement("UIGradient", {
                Rotation = 0,
                Color = ColorSequence.new(Color3.new(1, 1, 1)),
                Offset = Vector2.new(0, 0),
                Transparency = p7.Tween:Map(function(p15) --[[ Line: 97 ]]
                    local v16 = 1 - math.clamp(p15 - 0.65, 0, 0.3) * 3.333;
                    if v16 >= 1 then
                        return NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 1) });
                    end;
                    local v17 = {};
                    for _ = 1, 4 do
                        local v18 = #v17 + 1;
                        local v19 = {};
                        local v20 = math.random();
                        v19[1], v19[2] = math.clamp(v20, 0.001, 0.999), 0;
                        v17[v18] = v19;
                    end;
                    for _ = 1, 4 do
                        local v21 = #v17 + 1;
                        local v22 = {};
                        local v23 = math.random();
                        v22[1], v22[2] = math.clamp(v23, 0.001, 0.999), v16;
                        v17[v21] = v22;
                    end;
                    table.sort(v17, function(p24, p25) --[[ Line: 108 ]]
                        return p24[1] < p25[1];
                    end);
                    local v26 = { NumberSequenceKeypoint.new(0, v16) };
                    for v27 = 1, #v17 do
                        local v28 = v17[v27];
                        v26[#v26 + 1] = NumberSequenceKeypoint.new(v28[1], v28[2]);
                    end;
                    v26[#v26 + 1] = NumberSequenceKeypoint.new(1, v16);
                    return NumberSequence.new(v26);
                end)
            }) }) });
end;
return v4;