-- Services.InterfaceService.HUDInterface.ToolSlotComponent.ToolComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local u1 = shared.import("Roact");
local l__TextService__1 = game:GetService("TextService");
local v2 = u1.PureComponent:extend("Tool");
local l__CurrentCamera__2 = workspace.CurrentCamera;
local u3 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local u4 = Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
function v2.render(p5) --[[ Line: 12 ]]
    -- upvalues: l__CurrentCamera__2 (copy), u3 (copy), l__TextService__1 (copy), u1 (copy), u4 (copy)
    local l__props__3 = p5.props;
    local l__Name__4 = l__props__3.Name;
    local l__Order__5 = l__props__3.Order;
    local l__Selected__6 = l__props__3.Selected;
    local l__ViewportSize__7 = l__CurrentCamera__2.ViewportSize;
    local v6 = math.floor(l__ViewportSize__7.Y * 0.04 * 0.8);
    local v7 = Instance.new("GetTextBoundsParams");
    v7.Text = l__Name__4:upper();
    v7.Font = u3;
    v7.Size = v6;
    v7.Width = (1 / 0);
    local v8 = l__TextService__1:GetTextBoundsAsync(v7);
    return u1.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.new(v8.X / (l__ViewportSize__7.Y * 1.778), 0, 1, 0),
        LayoutOrder = l__Order__5
    }, {
        Name = u1.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextTransparency = 0.2,
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0.5, 0),
            Position = UDim2.new(0.5, 0, 0.1, 0),
            Size = UDim2.new(2, 0, 0.8, 0),
            FontFace = l__Selected__6 and u3 or u4,
            Text = l__Name__4:upper(),
            TextColor3 = Color3.new(0, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Center
        }, {
            White = u1.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextTransparency = 0.1,
                TextScaled = true,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0),
                FontFace = l__Selected__6 and u3 or u4,
                Text = l__Name__4:upper(),
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = Enum.TextXAlignment.Center
            })
        })
    });
end;
return v2;