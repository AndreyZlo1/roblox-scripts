-- Services.InterfaceService.HUDInterface.ToolSlotComponent.SlotComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2 = shared.import("require", "Roact");
local u3 = v1("RoactTween");
local u4 = v1("ToolComponent");
local v5 = u2.Component:extend("Slot");
local u6 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
function v5.init(p7, _) --[[ Line: 10 ]]
    -- upvalues: u3 (copy)
    p7.Switch = u3.new(0, TweenInfo.new(0.15, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out, 0, false, 0));
    p7.Selected = false;
end;
function v5.render(p8) --[[ Line: 15 ]]
    -- upvalues: u2 (copy), u4 (copy), u6 (copy)
    local l__props__1 = p8.props;
    local l__Index__2 = l__props__1.Index;
    local l__Tools__3 = l__props__1.Tools;
    local v9 = {};
    local v10 = false;
    for v11, v12 in l__Tools__3 do
        v9[v12.UID] = u2.createElement(u4, {
            Name = v12.Name,
            Selected = v12.Selected,
            Order = v11
        });
        if v12.Selected then
            v10 = true;
        end;
    end;
    if v10 ~= p8.Selected then
        p8.Selected = v10;
        p8.Switch:SetGoal(v10 and -0.02 or 0);
    end;
    return u2.createElement("Frame", {
        BackgroundTransparency = 1,
        ClipsDescendants = true,
        Size = UDim2.new(1, 0, 1, 0),
        Visible = #l__Tools__3 > 0,
        LayoutOrder = l__Index__2
    }, {
        Drawer = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.new(1, 0, 1, 0),
            Position = p8.Switch:Map(function(p13) --[[ Line: 48 ]]
                return UDim2.fromScale(p13, 0);
            end)
        }, {
            List = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.new(1, 0, 1, 0),
                Position = UDim2.new(-0.02, 0, 0, 0)
            }, { u2.createElement("UIListLayout", {
                    Padding = UDim.new(0.01, 0),
                    FillDirection = Enum.FillDirection.Horizontal,
                    HorizontalAlignment = Enum.HorizontalAlignment.Right,
                    SortOrder = Enum.SortOrder.LayoutOrder,
                    VerticalAlignment = Enum.VerticalAlignment.Center
                }), u2.createFragment(v9) }),
            Arrow = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "←",
                TextTransparency = 0.2,
                TextScaled = true,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(1.01, 0, 0.1, 0),
                Size = UDim2.new(0.1, 0, 0.8, 0),
                FontFace = u6,
                TextColor3 = Color3.new(0, 0, 0),
                TextXAlignment = Enum.TextXAlignment.Left
            }, {
                White = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "←",
                    TextTransparency = 0.1,
                    TextScaled = true,
                    AutoLocalize = false,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.new(0, 0, 0, -1),
                    Size = UDim2.new(1, 0, 1, 0),
                    FontFace = u6,
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = Enum.TextXAlignment.Left
                })
            }),
            Key = u2.createElement("Frame", {
                Position = UDim2.new(1, 0, 0.25, 0),
                Size = UDim2.new(0.5, 0, 0.5, 0),
                AnchorPoint = Vector2.new(1, 0),
                BackgroundColor3 = Color3.new(0, 0, 0),
                SizeConstraint = Enum.SizeConstraint.RelativeYY
            }, {
                Corner = u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.15, 0)
                }),
                Num = u2.createElement("TextLabel", {
                    TextScaled = true,
                    AutoLocalize = false,
                    BorderSizePixel = 0,
                    BackgroundTransparency = 1,
                    Text = tostring(l__Index__2),
                    TextColor3 = Color3.new(1, 1, 1),
                    FontFace = u6,
                    Size = UDim2.new(1, 0, 0.8, 0),
                    Position = UDim2.new(0, 0, 0.1, 0)
                })
            })
        })
    });
end;
return v5;