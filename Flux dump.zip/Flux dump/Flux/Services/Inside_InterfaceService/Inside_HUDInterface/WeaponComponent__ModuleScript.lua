-- Services.InterfaceService.HUDInterface.WeaponComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local u1, v2 = shared.import("Roact", "require");
local u3 = v2("RoactTween");
local u4 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local v5 = u1.Component:extend("Weapon");
function v5.init(p6) --[[ Line: 12 ]]
    -- upvalues: u3 (copy)
    p6.Switch = u3.new(0);
    p6.Icon = "";
end;
function v5.render(p7) --[[ Line: 17 ]]
    -- upvalues: u1 (copy), u4 (copy)
    local l__Weapon__1 = p7.props.Weapon;
    if l__Weapon__1 then
        local l__CQB__2 = p7.props.CQB;
        local l__Mode__3 = l__Weapon__1.Mode;
        local l__Max__4 = l__Weapon__1.Max;
        local l__Mag__5 = l__Weapon__1.Mag;
        local l__Mags__6 = l__Weapon__1.Mags;
        local v8 = {};
        for v9 = 1, #l__Mags__6 + 1 do
            local v10 = Color3.new(1, 1, 1);
            local v11 = nil;
            local v12, v13;
            if v9 == 1 then
                v12 = l__Mag__5 / l__Max__4;
                v10 = Color3.fromRGB(255, 222, 88);
                v13 = l__Max__4 >= 100;
                v11 = l__Weapon__1.Chamber;
                if v11 then
                    v11 = u1.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        ImageTransparency = 0.4,
                        Image = "rbxassetid://12972060036",
                        AnchorPoint = Vector2.new(1, 1),
                        Position = UDim2.fromScale(1, -0.2),
                        Size = UDim2.new(v13 and 0.396 or 1.7, 0, 0.15, 0),
                        ImageColor3 = Color3.new(0, 0, 0)
                    }, { u1.createElement("ImageLabel", {
                            BackgroundTransparency = 1,
                            ImageTransparency = 0.1,
                            Image = "rbxassetid://12972060036",
                            Size = UDim2.new(1, 0, 1, 0),
                            Position = UDim2.new(0, 0, 0, -1),
                            ImageColor3 = Color3.fromRGB(255, 222, 88)
                        }) });
                end;
            else
                local v14 = l__Mags__6[v9 - 1];
                v12 = v14.Capacity / v14.Max;
                if v14.Max >= 100 then
                    v13 = true;
                else
                    v13 = false;
                end;
            end;
            v8[v9] = u1.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(v13 and 1.5 or 0.35, 1),
                LayoutOrder = -v9
            }, {
                u1.createElement("UICorner", {
                    CornerRadius = UDim.new(0.2, 0)
                }),
                u1.createElement("UIStroke", {
                    Thickness = 1,
                    Transparency = 0.1,
                    Color = v10
                }),
                u1.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundTransparency = 0.1,
                    BackgroundColor3 = v10,
                    Size = UDim2.fromScale(1, v12),
                    AnchorPoint = Vector2.new(0, 1),
                    Position = UDim2.fromScale(0, 1)
                }),
                v11
            });
        end;
        local v15 = l__Mag__5 + (l__Weapon__1.Chamber and 1 or 0);
        return u1.createElement("Frame", {
            BackgroundTransparency = 1,
            LayoutOrder = 3,
            Size = UDim2.new(0.2, 0, 0.06, 0)
        }, { u1.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.new(1, 0, 0.8, 0)
            }, {
                u1.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Position = UDim2.fromScale(1.15, 0),
                    Size = UDim2.fromScale(0.02, 1),
                    AnchorPoint = Vector2.new(0, 0),
                    Visible = l__CQB__2:map(function(p16) --[[ Line: 102 ]]
                        return p16 and true or false;
                    end)
                }, {
                    u1.createElement("Frame", {
                        BorderSizePixel = 0,
                        BackgroundTransparency = 0.5,
                        AnchorPoint = Vector2.new(0.5, 0),
                        Position = UDim2.fromScale(0.5, 0),
                        Size = UDim2.new(0, 1, 1, 0),
                        BackgroundColor3 = Color3.new(1, 1, 1)
                    }),
                    u1.createElement("Frame", {
                        ZIndex = 2,
                        BorderSizePixel = 0,
                        AnchorPoint = Vector2.new(0.5, 0),
                        Position = UDim2.fromScale(0.5, 0),
                        Size = UDim2.fromScale(1, 1),
                        SizeConstraint = Enum.SizeConstraint.RelativeXX,
                        BackgroundColor3 = Color3.new(1, 1, 1),
                        BackgroundTransparency = l__CQB__2:map(function(p17) --[[ Line: 125 ]]
                            return p17 == 2 and 0 or 0.5;
                        end)
                    }, { u1.createElement("UICorner", {
                            CornerRadius = UDim.new(0.5, 0)
                        }) }),
                    u1.createElement("Frame", {
                        ZIndex = 2,
                        BorderSizePixel = 0,
                        AnchorPoint = Vector2.new(0.5, 0.25),
                        Position = UDim2.fromScale(0.5, 0.25),
                        Size = UDim2.fromScale(1, 1),
                        SizeConstraint = Enum.SizeConstraint.RelativeXX,
                        BackgroundColor3 = Color3.new(1, 1, 1),
                        BackgroundTransparency = l__CQB__2:map(function(p18) --[[ Line: 141 ]]
                            return p18 == 1 and 0 or 0.5;
                        end)
                    }, { u1.createElement("UICorner", {
                            CornerRadius = UDim.new(0.5, 0)
                        }) }),
                    u1.createElement("Frame", {
                        ZIndex = 2,
                        BorderSizePixel = 0,
                        AnchorPoint = Vector2.new(0.5, 0.5),
                        Position = UDim2.fromScale(0.5, 0.5),
                        Size = UDim2.fromScale(0.7, 0.7),
                        SizeConstraint = Enum.SizeConstraint.RelativeXX,
                        BackgroundColor3 = Color3.new(1, 1, 1),
                        BackgroundTransparency = l__CQB__2:map(function(p19) --[[ Line: 157 ]]
                            return p19 == 0 and 0 or 0.5;
                        end)
                    }, { u1.createElement("UICorner", {
                            CornerRadius = UDim.new(0.5, 0)
                        }) }),
                    u1.createElement("Frame", {
                        ZIndex = 2,
                        BorderSizePixel = 0,
                        AnchorPoint = Vector2.new(0.5, 0.75),
                        Position = UDim2.fromScale(0.5, 0.75),
                        Size = UDim2.fromScale(1, 1),
                        SizeConstraint = Enum.SizeConstraint.RelativeXX,
                        BackgroundColor3 = Color3.new(1, 1, 1),
                        BackgroundTransparency = l__CQB__2:map(function(p20) --[[ Line: 173 ]]
                            return p20 == -1 and 0 or 0.5;
                        end)
                    }, { u1.createElement("UICorner", {
                            CornerRadius = UDim.new(0.5, 0)
                        }) }),
                    u1.createElement("Frame", {
                        ZIndex = 2,
                        BorderSizePixel = 0,
                        AnchorPoint = Vector2.new(0.5, 1),
                        Position = UDim2.fromScale(0.5, 1),
                        Size = UDim2.fromScale(1, 1),
                        SizeConstraint = Enum.SizeConstraint.RelativeXX,
                        BackgroundColor3 = Color3.new(1, 1, 1),
                        BackgroundTransparency = l__CQB__2:map(function(p21) --[[ Line: 189 ]]
                            return p21 == -2 and 0 or 0.5;
                        end)
                    }, { u1.createElement("UICorner", {
                            CornerRadius = UDim.new(0.5, 0)
                        }) })
                }),
                u1.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Size = UDim2.fromScale(0.4, 0.4),
                    Position = UDim2.fromScale(1.05, 0.3),
                    SizeConstraint = Enum.SizeConstraint.RelativeYY
                }, { u1.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        Image = "rbxassetid://12972060036",
                        AnchorPoint = Vector2.new(0, 0),
                        Position = UDim2.fromScale(0, 0),
                        Size = UDim2.new(1, 0, 0.25, 0),
                        ImageColor3 = Color3.new(0, 0, 0),
                        ImageTransparency = (l__Mode__3 == 0 or l__Mode__3 > 2) and 0.4 or 0.6
                    }, { u1.createElement("ImageLabel", {
                            BackgroundTransparency = 1,
                            Image = "rbxassetid://12972060036",
                            Size = UDim2.new(1, 0, 1, 0),
                            Position = UDim2.new(0, 0, 0, -1),
                            ImageColor3 = l__Mode__3 == 0 and Color3.new(1, 0, 0) or Color3.new(1, 1, 1),
                            ImageTransparency = (l__Mode__3 == 0 or l__Mode__3 > 2) and 0.1 or 0.5
                        }) }), u1.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        Image = "rbxassetid://12972060036",
                        AnchorPoint = Vector2.new(0, 0.5),
                        Position = UDim2.fromScale(0, 0.5),
                        Size = UDim2.new(1, 0, 0.25, 0),
                        ImageColor3 = Color3.new(0, 0, 0),
                        ImageTransparency = (l__Mode__3 == 0 or l__Mode__3 > 1) and 0.4 or 0.6
                    }, { u1.createElement("ImageLabel", {
                            BackgroundTransparency = 1,
                            Image = "rbxassetid://12972060036",
                            Size = UDim2.new(1, 0, 1, 0),
                            Position = UDim2.new(0, 0, 0, -1),
                            ImageColor3 = l__Mode__3 == 0 and Color3.new(1, 0, 0) or Color3.new(1, 1, 1),
                            ImageTransparency = (l__Mode__3 == 0 or l__Mode__3 > 1) and 0.1 or 0.5
                        }) }), u1.createElement("ImageLabel", {
                        BackgroundTransparency = 1,
                        ImageTransparency = 0.4,
                        Image = "rbxassetid://12972060036",
                        AnchorPoint = Vector2.new(0, 1),
                        Position = UDim2.fromScale(0, 1),
                        Size = UDim2.new(1, 0, 0.25, 0),
                        ImageColor3 = Color3.new(0, 0, 0)
                    }, { u1.createElement("ImageLabel", {
                            BackgroundTransparency = 1,
                            ImageTransparency = 0.1,
                            Image = "rbxassetid://12972060036",
                            Size = UDim2.new(1, 0, 1, 0),
                            Position = UDim2.new(0, 0, 0, -1),
                            ImageColor3 = l__Mode__3 == 0 and Color3.new(1, 0, 0) or Color3.new(1, 1, 1)
                        }) }) }),
                u1.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextTransparency = 0.2,
                    TextScaled = true,
                    AutoLocalize = false,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.new(0, 0, 0, 0),
                    Size = UDim2.new(1, 0, 1, 0),
                    FontFace = u4,
                    Text = v15,
                    TextColor3 = Color3.new(0, 0, 0),
                    TextXAlignment = Enum.TextXAlignment.Right
                }, { u1.createElement("TextLabel", {
                        BackgroundTransparency = 1,
                        TextTransparency = 0.1,
                        TextScaled = true,
                        AutoLocalize = false,
                        AnchorPoint = Vector2.new(0, 0),
                        Position = UDim2.new(0, 0, 0, -1),
                        Size = UDim2.new(1, 0, 1, 0),
                        FontFace = u4,
                        Text = v15,
                        TextColor3 = Color3.new(1, 1, 1),
                        TextXAlignment = Enum.TextXAlignment.Right
                    }) }),
                u1.createElement("Frame", {
                    BackgroundTransparency = 0.6,
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.new(0, 0, 0),
                    Position = UDim2.fromScale(0.8, 0.25),
                    Size = UDim2.new(0, 1, 0.5, 0)
                }, { u1.createElement("Frame", {
                        BackgroundTransparency = 0.5,
                        BorderSizePixel = 0,
                        BackgroundColor3 = Color3.new(1, 1, 1),
                        Position = UDim2.new(0, 0, 0, -1),
                        Size = UDim2.new(1, 0, 1, 0)
                    }) }),
                u1.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Size = UDim2.fromScale(0.7, 0.7),
                    Position = UDim2.fromScale(0.72, 0.15),
                    AnchorPoint = Vector2.new(1, 0),
                    SizeConstraint = Enum.SizeConstraint.RelativeYY
                }, { u1.createElement("UIListLayout", {
                        FillDirection = Enum.FillDirection.Horizontal,
                        HorizontalAlignment = Enum.HorizontalAlignment.Right,
                        SortOrder = Enum.SortOrder.LayoutOrder,
                        VerticalAlignment = Enum.VerticalAlignment.Bottom,
                        Padding = UDim.new(0.2, 0)
                    }), u1.createFragment(v8) })
            }) });
    end;
end;
return v5;