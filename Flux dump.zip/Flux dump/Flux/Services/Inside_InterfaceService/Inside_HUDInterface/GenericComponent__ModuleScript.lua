-- Services.InterfaceService.HUDInterface.GenericComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local u1 = shared.import("Roact");
local v2 = u1.Component:extend("Generic");
function v2.render(p3) --[[ Line: 5 ]]
    -- upvalues: u1 (copy)
    local l__props__1 = p3.props;
    return u1.createElement("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.new(0.15, 0, 0.015, 0),
        LayoutOrder = l__props__1.Layout
    }, {
        Bar = u1.createElement("Frame", {
            BackgroundTransparency = 0.2,
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(1, 0),
            Position = UDim2.fromScale(1, 0),
            Size = l__props__1.Value:map(function(p4) --[[ Line: 16 ]]
                return UDim2.new(p4, 0, 1, 0);
            end),
            BackgroundColor3 = Color3.new(0, 0, 0)
        }, {
            Color = u1.createElement("Frame", {
                BackgroundTransparency = 0.1,
                BorderSizePixel = 0,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0),
                BackgroundColor3 = l__props__1.Color
            })
        })
    });
end;
return v2;