-- Services.InterfaceService.HUDInterface.CompoundComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local u1, v2 = shared.import("Roact", "require");
local l__RunService__1 = game:GetService("RunService");
local l__TextService__2 = game:GetService("TextService");
local u3 = v2("InputService");
Font.fromId(12187375422, Enum.FontWeight.Regular, Enum.FontStyle.Normal);
local u4 = Font.fromId(12187375422, Enum.FontWeight.Bold, Enum.FontStyle.Normal);
local l__CurrentCamera__3 = workspace.CurrentCamera;
local v5 = u1.Component:extend("Compound");
function v5.init(u6) --[[ Line: 14 ]]
    -- upvalues: u1 (copy), l__RunService__1 (copy), u4 (copy), l__CurrentCamera__3 (copy), l__TextService__2 (copy)
    local v7, u8 = u1.createBinding(0);
    local u9, u10 = u1.createBinding(0);
    u6._fear = 0;
    u6._conn = l__RunService__1.Heartbeat:Connect(function(p11) --[[ Line: 19 ]]
        -- upvalues: u9 (copy), u6 (copy), u10 (copy), u8 (copy)
        local v12 = u9:getValue();
        local v13;
        if v12 < u6._fear then
            v13 = u6._fear;
        else
            local l___fear__4 = u6._fear;
            local v14 = math.min(p11 * 5, 1);
            v13 = math.lerp(v12, l___fear__4, v14);
        end;
        u10(v13);
        u8(tick() / 10);
    end);
    u6.Flash = v7;
    u6.Fear = u9;
    u6.TextSizeCache = {};
    function u6.GetTextSize(u15) --[[ Line: 33 ]]
        -- upvalues: u6 (copy), u4 (ref), l__CurrentCamera__3 (ref), l__TextService__2 (ref)
        u6.TextSizeCache[u15] = 0;
        task.spawn(function() --[[ Line: 36 ]]
            -- upvalues: u15 (copy), u4 (ref), l__CurrentCamera__3 (ref), l__TextService__2 (ref), u6 (ref)
            local v16 = Instance.new("GetTextBoundsParams");
            v16.Text = u15;
            v16.Font = u4;
            v16.Size = math.floor(l__CurrentCamera__3.ViewportSize.Y * 0.06 * 0.3);
            v16.Width = (1 / 0);
            local v17 = l__TextService__2:GetTextBoundsAsync(v16);
            u6.TextSizeCache[u15] = v17.X / (l__CurrentCamera__3.ViewportSize.Y * 0.25);
        end);
    end;
end;
function v5.willUnmount(p18) --[[ Line: 49 ]]
    p18._conn:Disconnect();
end;
function v5.render(p19) --[[ Line: 53 ]]
    -- upvalues: u1 (copy), u4 (copy), u3 (copy)
    local l__props__5 = p19.props;
    local l__Compound__6 = l__props__5.Compound;
    local l__IsQuest__7 = l__props__5.IsQuest;
    local l__HasCompound__8 = l__props__5.HasCompound;
    local l__Progress__9 = l__Compound__6.Progress;
    local l__Objectives__10 = l__Compound__6.Objectives;
    local v20 = {};
    local u21 = not l__Compound__6.Loud;
    local l__Defeated__11 = l__Compound__6.Defeated;
    if l__Compound__6.Fear then
        p19._fear = l__Compound__6.Fear;
    end;
    if not u21 then
        for v22 = 1, l__Compound__6.Waves do
            local v23 = v22 / l__Compound__6.Waves;
            v20[v22] = u1.createElement("Frame", {
                ZIndex = 2,
                BorderSizePixel = 0,
                Size = UDim2.new(0, 1, 5, 0),
                Position = UDim2.fromScale(v23, -2),
                BackgroundColor3 = v23 < l__Progress__9 and Color3.new(1, 1, 1) or Color3.new(0, 0, 0)
            });
        end;
    end;
    local v24 = l__Defeated__11 and "ADVANCE TO THE NEXT ENEMY COMPOUND" or l__Compound__6.Sub;
    local v25 = {};
    local v26 = {};
    for v27, v28 in l__Objectives__10 do
        local l__Active__12 = v28.Active;
        local v29 = v28.Title:upper();
        local v30 = nil;
        if not l__Active__12 then
            if p19.TextSizeCache[v29] then
                v30 = p19.TextSizeCache[v29];
            else
                p19.GetTextSize(v29);
            end;
        end;
        if l__IsQuest__7 then
            if l__HasCompound__8 and #l__HasCompound__8.Objectives > 0 then
                v26.Div = u1.createElement("Frame", {
                    BackgroundTransparency = 0.5,
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.new(1, 1, 1),
                    BorderColor3 = Color3.new(),
                    Size = UDim2.fromScale(0.5, 0.025)
                });
            end;
        else
            v26[v27] = u1.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundTransparency = 0.1,
                BackgroundColor3 = Color3.new(),
                Size = UDim2.fromScale(0.1, 0.05),
                Position = UDim2.fromScale((v27 - 1) * 0.15, 0)
            }, { u1.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundTransparency = 0.1,
                    BackgroundColor3 = p19.Flash:map(function(p31) --[[ Line: 120 ]]
                        -- upvalues: l__Defeated__11 (copy), u21 (copy)
                        if l__Defeated__11 then
                            return Color3.fromRGB(116, 255, 116);
                        elseif u21 then
                            return Color3.fromRGB(51, 131, 223):Lerp(Color3.fromRGB(124, 188, 230), math.sin(p31 * 100) / 2 + 0.5);
                        else
                            return Color3.fromRGB(223, 149, 51):Lerp(Color3.fromRGB(230, 184, 124), math.sin(p31 * 100) / 2 + 0.5);
                        end;
                    end),
                    Size = UDim2.fromScale(v28.Progress, 1),
                    Position = UDim2.new(0, 0, 0, -1)
                }) });
        end;
        local l__createElement__13 = u1.createElement;
        local v32 = "TextLabel";
        local v33 = {
            BackgroundTransparency = 1,
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.new(0.05, 0, (v27 - 1) * 0.3 + 0.6, 0),
            Size = UDim2.new(1, 0, 0.3, 0),
            FontFace = u4,
            Text = v29,
            TextTransparency = l__Active__12 and 0.2 or 0.6,
            TextColor3 = Color3.new(0, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Left
        };
        local v34 = {};
        local v35 = u1.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.new(0, 0, 0, -1),
            Size = UDim2.new(1, 0, 1, 0),
            FontFace = u4,
            Text = v29,
            TextTransparency = l__Active__12 and 0.1 or 0.5,
            TextColor3 = Color3.new(1, 1, 1),
            TextXAlignment = Enum.TextXAlignment.Left
        });
        local v36 = u1.createElement("Frame", {
            BorderSizePixel = 0,
            Size = UDim2.fromScale(0.2, 0.2),
            Position = UDim2.fromScale(-0.05, 0.5),
            AnchorPoint = Vector2.new(0, 0.5),
            BackgroundTransparency = l__Active__12 and 0.2 or 0.6,
            BackgroundColor3 = Color3.new(),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }, { u1.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundTransparency = l__Active__12 and 0.1 or 0.5,
                BackgroundColor3 = Color3.new(1, 1, 1),
                Size = UDim2.fromScale(1, 1),
                Position = UDim2.new(0, 0, 0, -1)
            }) });
        if v30 then
            v30 = u1.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundTransparency = 0.1,
                BackgroundColor3 = p19.Flash:map(function(p37) --[[ Line: 181 ]]
                    -- upvalues: l__Defeated__11 (copy), u21 (copy)
                    if l__Defeated__11 then
                        return Color3.fromRGB(116, 255, 116);
                    elseif u21 then
                        return Color3.fromRGB(51, 131, 223):Lerp(Color3.fromRGB(124, 188, 230), math.sin(p37 * 100) / 2 + 0.5);
                    else
                        return Color3.fromRGB(223, 149, 51):Lerp(Color3.fromRGB(230, 184, 124), math.sin(p37 * 100) / 2 + 0.5);
                    end;
                end),
                AnchorPoint = Vector2.new(0, 0.5),
                Size = UDim2.fromScale(v30 + 0.05, 0.1),
                Position = UDim2.new(-0.05, 0, 0.5, 0)
            });
        end;
        v34[1], v34[2], v34[3] = v35, v36, v30;
        v25[v27] = l__createElement__13(v32, v33, v34);
    end;
    local v38 = l__Compound__6.Title:upper();
    local v39;
    if l__IsQuest__7 then
        v39 = "◆ " .. v38 .. "<font color=\"#ffffff\"> • " .. v24 .. "</font>";
        v38 = "◆ " .. v38 .. " • " .. v24;
    else
        v39 = v38;
    end;
    local v40 = 0.04;
    if l__IsQuest__7 and (l__HasCompound__8 and #l__HasCompound__8.Objectives > 0) then
        v40 = v40 + 0.05;
        if l__HasCompound__8.Objectives then
            v40 = v40 + #l__HasCompound__8.Objectives * 0.018;
        end;
    end;
    local v41, _ = u3:GetBind("PauseMenu");
    local l__createFragment__14 = u1.createFragment;
    local v42 = {};
    local l__createElement__15 = u1.createElement;
    local v43 = "Frame";
    local v44 = {
        BackgroundTransparency = 1,
        Position = UDim2.fromScale(0.5, l__HasCompound__8 and 0.09 or 0.02),
        AnchorPoint = Vector2.new(0.5, 0),
        Size = UDim2.fromScale(0.25, 0.06),
        SizeConstraint = Enum.SizeConstraint.RelativeYY
    };
    local v45 = {};
    local v47 = u1.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextTransparency = 0.2,
        TextScaled = true,
        AutoLocalize = false,
        ZIndex = 2,
        AnchorPoint = Vector2.new(0.5, 0),
        Position = UDim2.new(0.5, 0, l__IsQuest__7 and 0.1 or 0, 0),
        Size = UDim2.new(5, 0, l__IsQuest__7 and 0.3 or 0.4, 0),
        FontFace = u4,
        Text = v38,
        TextColor3 = Color3.new(0, 0, 0),
        TextXAlignment = Enum.TextXAlignment.Center
    }, { u1.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextTransparency = 0.1,
            TextScaled = true,
            AutoLocalize = false,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.new(0, 0, 0, -1),
            Size = UDim2.new(1, 0, 1, 0),
            FontFace = u4,
            Text = v39,
            RichText = l__IsQuest__7,
            TextColor3 = p19.Flash:map(function(p46) --[[ Line: 245 ]]
                -- upvalues: l__Defeated__11 (copy), u21 (copy)
                if l__Defeated__11 then
                    return Color3.fromRGB(116, 255, 116);
                elseif u21 then
                    return Color3.fromRGB(51, 131, 223):Lerp(Color3.fromRGB(124, 188, 230), math.sin(p46 * 100) / 2 + 0.5);
                else
                    return Color3.fromRGB(223, 149, 51):Lerp(Color3.fromRGB(230, 184, 124), math.sin(p46 * 100) / 2 + 0.5);
                end;
            end),
            TextXAlignment = Enum.TextXAlignment.Center
        }) });
    local v48 = not l__IsQuest__7;
    if v48 then
        v48 = u1.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextTransparency = 0.2,
            TextScaled = true,
            AutoLocalize = false,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0.5, 0),
            Position = UDim2.new(0.5, 0, 0.4, 0),
            Size = UDim2.new(4, 0, 0.3, 0),
            FontFace = u4,
            Text = v24,
            TextColor3 = Color3.new(0, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Center
        }, { u1.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextTransparency = 0.1,
                TextScaled = true,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0),
                FontFace = u4,
                Text = v24,
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = Enum.TextXAlignment.Center
            }) });
    end;
    local v50 = u1.createElement("Frame", {
        BorderSizePixel = 0,
        BackgroundTransparency = 0.1,
        ZIndex = 2,
        BackgroundColor3 = Color3.new(),
        Size = UDim2.fromScale(1.5, 0.05),
        Position = UDim2.fromScale(-0.25, l__IsQuest__7 and 0.55 or 0.9)
    }, { u1.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0.1,
            BackgroundColor3 = p19.Flash:map(function(p49) --[[ Line: 299 ]]
                -- upvalues: l__Defeated__11 (copy), u21 (copy)
                if l__Defeated__11 then
                    return Color3.fromRGB(116, 255, 116);
                elseif u21 then
                    return Color3.fromRGB(51, 131, 223):Lerp(Color3.fromRGB(124, 188, 230), math.sin(p49 * 100) / 2 + 0.5);
                else
                    return Color3.fromRGB(223, 149, 51):Lerp(Color3.fromRGB(230, 184, 124), math.sin(p49 * 100) / 2 + 0.5);
                end;
            end),
            Size = UDim2.fromScale(l__Progress__9, 1),
            Position = UDim2.new(0, 0, 0, -1)
        }), u1.createFragment(v20) });
    local v51 = u21 and (not l__Defeated__11 and l__Compound__6.Fear);
    if v51 then
        v51 = u1.createFragment({ u1.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundTransparency = 0.1,
                ZIndex = 2,
                BackgroundColor3 = Color3.new(),
                Size = UDim2.fromScale(1.5, 0.05),
                Position = UDim2.fromScale(-0.25, 0.82)
            }, { u1.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundTransparency = 0.1,
                    BackgroundColor3 = p19.Flash:map(function(p52) --[[ Line: 326 ]]
                        return Color3.fromRGB(223, 51, 51):Lerp(Color3.fromRGB(230, 124, 124), math.sin(p52 * 100) / 2 + 0.5);
                    end),
                    Size = p19.Fear:map(function(p53) --[[ Line: 329 ]]
                        return UDim2.fromScale(p53, 1);
                    end),
                    Position = UDim2.new(0, 0, 0, -1)
                }) }), u1.createElement("ImageLabel", {
                BackgroundTransparency = 1,
                Image = "rbxassetid://96053932124447",
                Size = UDim2.fromScale(5, 2),
                AnchorPoint = Vector2.new(0.5, 0),
                Position = UDim2.fromScale(0.5, -0.8),
                ImageColor3 = Color3.fromRGB(255, 48, 51),
                ImageTransparency = p19.Fear:map(function(p54) --[[ Line: 342 ]]
                    return 1 - p54;
                end)
            }) });
    end;
    local l__MakeKnown__16 = l__Compound__6.MakeKnown;
    if l__MakeKnown__16 then
        l__MakeKnown__16 = u1.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextTransparency = 0.2,
            TextScaled = true,
            AutoLocalize = false,
            ZIndex = 2,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.new(-0.5, 0, 1, 0),
            Size = UDim2.new(2, 0, 0.3, 0),
            FontFace = u4,
            Text = "REMAINING ENEMIES VISIBLE ON MAP (" .. v41.Name .. ")",
            TextColor3 = Color3.new(0, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Center
        }, { u1.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextTransparency = 0.1,
                TextScaled = true,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(0, 0, 0, -1),
                Size = UDim2.new(1, 0, 1, 0),
                FontFace = u4,
                Text = "REMAINING ENEMIES VISIBLE ON MAP (" .. v41.Name .. ")",
                TextColor3 = p19.Flash:map(function(p55) --[[ Line: 369 ]]
                    return Color3.fromRGB(223, 51, 51):Lerp(Color3.fromRGB(230, 124, 124), math.sin(p55 * 100) / 2 + 0.5);
                end),
                TextXAlignment = Enum.TextXAlignment.Center
            }) });
    end;
    v45[1], v45[2], v45[3], v45[4], v45[5] = v47, v48, v50, v51, l__MakeKnown__16;
    local v56 = l__createElement__15(v43, v44, v45);
    local v57;
    if #l__Objectives__10 > 0 then
        v57 = u1.createElement("Frame", {
            BackgroundTransparency = 1,
            Position = UDim2.fromScale(0.025, v40),
            AnchorPoint = Vector2.new(0, 0),
            Size = UDim2.fromScale(0.25, 0.06),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }, { u1.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextTransparency = 0.2,
                TextScaled = true,
                AutoLocalize = false,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.new(0, 0, 0.2, 0),
                Size = UDim2.new(1, 0, 0.4, 0),
                FontFace = u4,
                Text = l__IsQuest__7 and "MISSION" or "OBJECTIVES",
                TextColor3 = Color3.new(0, 0, 0),
                TextXAlignment = Enum.TextXAlignment.Left
            }, { u1.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextTransparency = 0.1,
                    TextScaled = true,
                    AutoLocalize = false,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.new(0, 0, 0, -1),
                    Size = UDim2.new(1, 0, 1, 0),
                    FontFace = u4,
                    Text = l__IsQuest__7 and "MISSION" or "OBJECTIVES",
                    TextColor3 = p19.Flash:map(function(p58) --[[ Line: 406 ]]
                        -- upvalues: l__Defeated__11 (copy), u21 (copy)
                        if l__Defeated__11 then
                            return Color3.fromRGB(116, 255, 116);
                        elseif u21 then
                            return Color3.fromRGB(51, 131, 223):Lerp(Color3.fromRGB(124, 188, 230), math.sin(p58 * 100) / 2 + 0.5);
                        else
                            return Color3.fromRGB(223, 149, 51):Lerp(Color3.fromRGB(230, 184, 124), math.sin(p58 * 100) / 2 + 0.5);
                        end;
                    end),
                    TextXAlignment = Enum.TextXAlignment.Left
                }) }), u1.createFragment(v26), u1.createFragment(v25) });
    else
        v57 = false;
    end;
    v42[1], v42[2] = v56, v57;
    return l__createFragment__14(v42);
end;
return v5;