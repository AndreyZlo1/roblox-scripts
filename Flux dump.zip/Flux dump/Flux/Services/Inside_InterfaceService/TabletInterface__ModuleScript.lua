-- Services.InterfaceService.TabletInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3 = shared.import("require", "Roact", "signal");
local l__Players__1 = game:GetService("Players");
local u4 = v1("InputService");
local u5 = v1("RoactTween");
local l__PlayerGui__2 = l__Players__1.LocalPlayer:WaitForChild("PlayerGui");
local l__CurrentCamera__3 = workspace.CurrentCamera;
local u6 = v1({ "VehicleSpawnerComponent", "ManageCompanyComponent", "QuestComponent" });
local u7 = {};
u7.__index = u7;
function u7.new() --[[ Line: 22 ]]
    -- upvalues: u2 (copy), u5 (copy), u3 (copy), u7 (copy)
    local v8, v9 = u2.createBinding(Vector2.new());
    local v10, v11 = u2.createBinding(Vector2.new());
    local v12 = u5.new(0);
    local v13 = {
        _enabled = false,
        _update = u3.new(),
        _offsetBinding = v8,
        _sizeBinding = v10,
        _updateOffset = v9,
        _updateSize = v11,
        _loading = v12
    };
    return setmetatable(v13, u7);
end;
function u7.Ping(p14, p15) --[[ Line: 42 ]]
    -- upvalues: u2 (copy)
    if p14._element and p14._handle then
        p14._handle = u2.update(p14._handle, u2.createElement(p14._element, p15));
    end;
end;
function u7.Enable(p16, p17, p18, p19) --[[ Line: 50 ]]
    -- upvalues: u6 (copy), u2 (copy), l__PlayerGui__2 (copy), u4 (copy)
    if p16._enabled then
    else
        p16._enabled = true;
        p16._screenPart = p17;
        p16._loading:SetValue(0);
        p19.Loading = p16._loading;
        p19.Update = p16._update;
        p19.OffsetBinding = p16._offsetBinding;
        p19.SizeBinding = p16._sizeBinding;
        p16._element = u6[p18 .. "Component"];
        p16._handle = u2.mount(u2.createElement(p16._element, p19), l__PlayerGui__2);
        u4.TabletOpen = true;
    end;
end;
function u7.Disable(p20) --[[ Line: 68 ]]
    -- upvalues: u2 (copy), u4 (copy)
    if p20._enabled then
        p20._element = nil;
        p20._enabled = false;
        p20._screenPart = nil;
        if p20._handle then
            u2.unmount(p20._handle);
        end;
        u4.TabletOpen = false;
    end;
end;
function u7.Update(p21, p22) --[[ Line: 83 ]]
    -- upvalues: l__CurrentCamera__3 (copy)
    local l___screenPart__4 = p21._screenPart;
    if l___screenPart__4 then
        local l__CFrame__5 = l___screenPart__4.CFrame;
        local l__Size__6 = l___screenPart__4.Size;
        local v23 = l__CurrentCamera__3:WorldToScreenPoint(l__CFrame__5:PointToWorldSpace((Vector3.new(l__Size__6.X / 2, l__Size__6.Y / 2, -l__Size__6.Z / 2))));
        local v24 = l__CurrentCamera__3:WorldToScreenPoint(l__CFrame__5:PointToWorldSpace((Vector3.new(-l__Size__6.X / 2, -l__Size__6.Y / 2, -l__Size__6.Z / 2))));
        p21._update:Fire(p22);
        p21._updateOffset(Vector2.new(v23.X, v23.Y));
        p21._updateSize(Vector2.new(v24.X, v24.Y) - Vector2.new(v23.X, v23.Y));
    end;
end;
return u7.new();