-- Services.InterfaceService.RadioInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, _, u4 = shared.import("require", "Roact", "Enum", "network", "server");
local u5 = v1("sanitizeDisplayName");
local u6 = v1("GameShellProxyService");
local u7 = v1("InventoryService");
local u8 = v1("RadioComponent");
local u9 = v1("ClientService");
local u10 = v1("SoundService");
local u11 = v1("InputService");
local l__TextChatService__1 = game:GetService("TextChatService");
local l__HttpService__2 = game:GetService("HttpService");
local l__Players__3 = game:GetService("Players");
local l__LocalPlayer__4 = l__Players__3.LocalPlayer;
local u12 = {
    Red = Color3.fromRGB(255, 10, 14),
    Orange = Color3.fromRGB(255, 150, 29),
    Blue = Color3.fromRGB(52, 133, 255),
    Yellow = Color3.fromRGB(255, 216, 57),
    Green = Color3.fromRGB(134, 255, 58)
};
local u13 = {};
u13.__index = u13;
function u13._update(u14) --[[ Line: 36 ]]
    -- upvalues: l__LocalPlayer__4 (copy), u2 (copy), u8 (copy)
    local v15 = l__LocalPlayer__4:FindFirstChildWhichIsA("AudioDeviceInput");
    if u14._handle then
        u14._handle = u2.update(u14._handle, u2.createElement(u8, {
            AudioDeviceInput = v15,
            Touch = u14._touch,
            Visible = u14._visible,
            Transmitting = u14._transmitting,
            NoRadio = u14._noRadio,
            Transmitted = function() --[[ Name: Transmitted, Line 46 ]]
                -- upvalues: u14 (copy)
                u14._lastTransmit = tick();
            end
        }));
    end;
end;
function u13._addRadio(u16, u17, p18, p19, p20, p21, p22) --[[ Line: 53 ]]
    -- upvalues: u9 (copy), u4 (copy), u7 (copy), u12 (copy), u5 (copy)
    local v23 = u9.Clients[p18];
    local v24 = (not u4.IS_PVP and v23 and true or false) and v23.Actor;
    if v24 then
        v24:AddMessage(u17, p19);
    end;
    if u4.RADIO_STRICT and not (u7.HasRadio and p22) then
    else
        local v25 = Color3.new(1, 1, 1);
        if v23 and u12[v23.Squad] then
            v25 = u12[v23.Squad]:Lerp(Color3.new(1, 1, 1), 0.3);
        end;
        if p20 then
            if p21 ~= u16._channel then
                return;
            end;
            local v26 = u16._chats[u17];
            local v27;
            if v26 then
                v27 = v26.order;
            else
                u16._chatCount = u16._chatCount + 1;
                v27 = u16._chatCount;
                task.delay(10, function() --[[ Line: 84 ]]
                    -- upvalues: u16 (copy), u17 (copy)
                    u16._chats[u17] = nil;
                    u16:_update();
                end);
            end;
            u16._chats[u17] = {
                user = u5(p18.DisplayName, p18.Name),
                color = v25,
                message = p19,
                order = v27
            };
            u16:_update();
        end;
    end;
end;
function u13.new() --[[ Line: 100 ]]
    -- upvalues: l__TextChatService__1 (copy), u6 (copy), u3 (copy), u11 (copy), u10 (copy), u13 (copy), u2 (copy), u4 (copy), l__LocalPlayer__4 (copy), u8 (copy), l__Players__3 (copy), l__HttpService__2 (copy)
    local l__Main__5 = l__TextChatService__1:WaitForChild("Main");
    local v28 = u6:CreateProxy(5, u3.ShellPriority.PreferVisible, "RadioInterface");
    local v29 = {
        _lastTransmit = 0,
        _channel = "000",
        _chatCount = 0,
        _visible = true,
        _touch = u11.Touch,
        _chats = {},
        _transmitting = {},
        _endSound = u10:CreateSound("VoiceChat", nil, false, "Foley", "Radio", "End")
    };
    local u30 = setmetatable(v29, u13);
    local v31, v32 = u2.createBinding(false);
    u30._noRadio = v31;
    u30._updateRadio = v32;
    if not u4.MAIN_MENU then
        local v33 = l__LocalPlayer__4:FindFirstChildWhichIsA("AudioDeviceInput");
        u30._handle = u2.mount(u2.createElement(u8, {
            Visible = true,
            AudioDeviceInput = v33,
            Touch = u30._touch,
            Chats = u30._chats,
            UpdateChannel = function(p34) --[[ Name: UpdateChannel, Line 124 ]]
                -- upvalues: u30 (copy)
                u30._channel = p34;
            end,
            NoRadio = u30._noRadio,
            Transmitting = {},
            Transmitted = function() --[[ Name: Transmitted, Line 130 ]]
                -- upvalues: u30 (copy)
                u30._lastTransmit = tick();
            end
        }), v28);
    end;
    u11.TouchInput:Connect(function(p35) --[[ Line: 136 ]]
        -- upvalues: u30 (copy)
        u30._touch = p35;
        u30:_update();
    end);
    local function v42(p36) --[[ Line: 141 ]]
        -- upvalues: l__Players__3 (ref), l__HttpService__2 (ref), u30 (copy)
        local v37 = l__Players__3:GetPlayerByUserId(p36.TextSource.UserId);
        if v37 then
            local v38, v39 = pcall(l__HttpService__2.JSONDecode, l__HttpService__2, p36.Metadata);
            if v38 then
                local v40 = v39.Radio and true or false;
                local v41 = (not v39.Channel or typeof(v39.Channel) ~= "string") and "000" or v39.Channel;
                u30:_addRadio(p36.MessageId, v37, p36.Text, v40, v41, v39.HasRadio and true or false);
            end;
        end;
    end;
    l__TextChatService__1.SendingMessage:Connect(v42);
    l__Main__5.MessageReceived:Connect(v42);
    return u30;
end;
function u13.Update(p43) --[[ Line: 173 ]]
    -- upvalues: u4 (copy), u7 (copy), l__LocalPlayer__4 (copy), u9 (copy), u12 (copy), u5 (copy)
    local v44 = {};
    local v45 = u4.RADIO_STRICT and not u7.HasRadio;
    if v45 then
        v45 = tick() - p43._lastTransmit < 5;
    end;
    p43._updateRadio(v45 and true or false);
    if l__LocalPlayer__4:FindFirstChildWhichIsA("AudioDeviceInput") then
        local l__LocalClient__6 = u9.LocalClient;
        if l__LocalClient__6 then
            local v46 = false;
            if not u4.RADIO_STRICT or u7.HasRadio then
                for v47, v48 in u9.Clients do
                    local v49 = false;
                    local v50;
                    if v48 == l__LocalClient__6 then
                        v50 = v48.ClientTransmitting and true or v49;
                    else
                        v50 = v48.Transmitting and (l__LocalClient__6.Channel == v48.Channel and (l__LocalClient__6.Actor and (l__LocalClient__6.Actor.Alive and (v48.Actor and (v48.Actor.Alive and (not u4.IS_PVP or l__LocalClient__6.Squad == v48.Squad)))))) and true or v49;
                    end;
                    if v50 then
                        v44[v47] = true;
                        if not p43._transmitting[v47] then
                            local v51 = Color3.new(1, 1, 1);
                            if u12[v48.Squad] then
                                v51 = u12[v48.Squad]:Lerp(Color3.new(1, 1, 1), 0.3);
                            end;
                            local v52 = u5(v47.DisplayName, v47.Name);
                            if v47 == l__LocalPlayer__4 then
                                v52 = v52 .. " (You)";
                            end;
                            p43._transmitting[v47] = {
                                Name = v52,
                                Color = v51
                            };
                            v46 = true;
                        end;
                    end;
                end;
            end;
            for v53 in p43._transmitting do
                if not v44[v53] then
                    p43._endSound.Play();
                    p43._transmitting[v53] = nil;
                    v46 = true;
                end;
            end;
            if v46 then
                p43:_update();
            end;
        end;
    end;
end;
function u13.SetVisible(p54, p55) --[[ Line: 249 ]]
    if p54._handle then
        p54._visible = p55;
        p54:_update();
    end;
end;
return u13.new();