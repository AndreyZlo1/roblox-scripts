-- Services.InterfaceService.TabletInterface.VehicleSpawnerComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Roact", "network", "Enum");
local u5 = v1({ "VehicleSpawnerGarageComponent", "VehicleSpawnerEditComponent", "VehicleSpawnerPurchaseComponent" });
local u6 = v1("PopupInterface");
local u7 = v1("RoactTween");
local l__LocalPlayer__1 = game:GetService("Players").LocalPlayer;
local u8 = {
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "#",
    "$",
    "%",
    "&",
    "@"
};
local u9 = Font.fromName("Ubuntu", u4.FontWeight.Regular, u4.FontStyle.Normal);
local u10 = Font.fromName("Ubuntu", u4.FontWeight.Bold, u4.FontStyle.Normal);
local u11 = v1("VehicleSpawnerButtonComponent");
local v12 = u2.Component:extend("VehicleSpawner");
local function u18(p13, p14) --[[ Line: 25 ]]
    -- upvalues: u8 (copy)
    if p14 > 1 then
        return p13;
    end;
    local v15 = math.floor(#p13 * p14);
    local v16 = "";
    for v17 = 1, #p13 do
        if v17 < v15 then
            v16 = v16 .. p13:sub(v17, v17);
        else
            v16 = v16 .. u8[math.random(1, #u8)];
        end;
    end;
    return v16;
end;
function v12.init(u19, p20) --[[ Line: 42 ]]
    -- upvalues: l__LocalPlayer__1 (copy), u2 (copy), u18 (copy), u7 (copy), u4 (copy), u3 (copy), u6 (copy)
    u19.ScreenPart = p20.ScreenPart;
    u19.OffsetBinding = p20.OffsetBinding;
    u19.SizeBinding = p20.SizeBinding;
    u19.VehicleType = p20.VehicleType;
    u19.VehicleData = p20.VehicleData;
    u19.MaxSlots = p20.MaxSlots;
    u19.RepairDiscount = p20.RepairDiscount;
    u19.Update = p20.Update;
    u19.Loading = p20.Loading;
    local u21 = "Welcome back, " .. l__LocalPlayer__1.DisplayName .. "!";
    local v22, u23 = u2.createBinding();
    local u24, u25 = u2.createBinding(0);
    local u26 = tick();
    u19.Connection = u19.Update:Connect(function(p27) --[[ Line: 58 ]]
        -- upvalues: u26 (copy), u23 (copy), u18 (ref), u21 (copy), u25 (copy), u24 (copy)
        u23((u18(u21, (tick() - u26) / 0.5)));
        u25(u24:getValue() + p27 * 1500);
    end);
    u19.NotifyTween = u7.new(0, TweenInfo.new(0.1, u4.EasingStyle.Exponential, u4.EasingDirection.Out, 0, false, 0));
    function u19.Notify(p28, p29, p30, p31) --[[ Line: 66 ]]
        -- upvalues: u19 (copy)
        u19.NotifyTween:SetGoal(1);
        u19:setState({
            Notification = true,
            Title = p28,
            Description = p29,
            Callback = p30 or false,
            SoundKit = p31 or "VehicleTabletBase"
        });
    end;
    function u19.ChangePage(p32, p33) --[[ Line: 77 ]]
        -- upvalues: u19 (copy)
        u19:setState({
            PageId = u19.state.PageId + 1,
            Page = p32,
            Data = p33 or {}
        });
    end;
    u19.circleBinding = u24;
    u19.welcomeBinding = v22;
    if p20.HasVehicle then
        u19.ExitIfCancelled = true;
        u19.NotifyTween:SetGoal(1);
        u19:setState({
            Notification = true,
            Title = "Recall Vehicle",
            Description = "Are you sure you want to recall your current vehicle?",
            SoundKit = "VehicleTabletBase",
            PageId = 1,
            Page = "Garage",
            Callback = function() --[[ Name: Callback, Line 95 ]]
                -- upvalues: u19 (copy), u3 (ref)
                u19.ExitIfCancelled = false;
                u3:FireServer("ActivateInteract", "Recall");
            end,
            Data = {}
        });
    else
        u19:setState({
            PageId = 1,
            Notification = false,
            Page = "Garage",
            Data = {}
        });
    end;
    u19.Popup = u6.PopupChanged:Connect(function() --[[ Line: 113 ]]
        -- upvalues: u19 (copy), u6 (ref)
        u19:setState({
            PopupOpen = u6.PopupOpen
        });
    end);
end;
function v12.willUnmount(p34) --[[ Line: 120 ]]
    p34.Connection:Disconnect();
    p34.Popup:Disconnect();
end;
function v12.render(u35) --[[ Line: 125 ]]
    -- upvalues: u2 (copy), u4 (copy), u10 (copy), u9 (copy), u11 (copy), u3 (copy), u5 (copy)
    local l__state__2 = u35.state;
    local l__createElement__3 = u2.createElement;
    local v36 = "SurfaceGui";
    local v37 = {
        LightInfluence = 0,
        Brightness = 2,
        Face = u4.NormalId.Front,
        Adornee = u35.ScreenPart,
        SizingMode = u4.SurfaceGuiSizingMode.FixedSize,
        ZIndexBehavior = u4.ZIndexBehavior.Sibling,
        CanvasSize = u35.SizeBinding
    };
    local v38 = {
        Scratches = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            ImageTransparency = 0.34,
            Image = "rbxassetid://7801324640",
            ZIndex = 4,
            Size = UDim2.fromScale(1, 1),
            ImageColor3 = Color3.fromRGB(173, 173, 173)
        })
    };
    local l__createElement__4 = u2.createElement;
    local v39 = "Frame";
    local v41 = {
        BorderSizePixel = 0,
        ZIndex = 3,
        BackgroundColor3 = Color3.fromRGB(0, 0, 0),
        Size = UDim2.fromScale(1, 1),
        BackgroundTransparency = u35.NotifyTween:Map(function(p40) --[[ Line: 149 ]]
            return 1 - p40 * 0.6;
        end)
    };
    local v42 = {};
    local l__createElement__5 = u2.createElement;
    local v43 = "CanvasGroup";
    local v46 = {
        BorderSizePixel = 0,
        BackgroundColor3 = Color3.fromRGB(25, 25, 25),
        Size = u35.NotifyTween:Map(function(p44) --[[ Line: 157 ]]
            return UDim2.fromScale(0.45 - p44 / 10, 0.4 - p44 / 10);
        end),
        GroupTransparency = u35.NotifyTween:Map(function(p45) --[[ Line: 160 ]]
            return 1 - p45;
        end),
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.fromScale(0.5, 0.5)
    };
    local v47 = {
        Bar = u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundTransparency = 0,
            BackgroundColor3 = Color3.new(1, 1, 1),
            Position = UDim2.fromScale(0.99, 0),
            Size = UDim2.fromScale(0.01, 1)
        }),
        Title = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.new(0.1, 0, 0.1, 0),
            Size = UDim2.new(0.8, 0, 0.15, 0),
            FontFace = u10,
            TextXAlignment = u4.TextXAlignment.Left,
            Text = l__state__2.Title,
            TextColor3 = Color3.new(1, 1, 1)
        }),
        Description = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            TextWrapped = true,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.new(0.1, 0, 0.3, 0),
            Size = UDim2.new(0.8, 0, 0.2, 0),
            FontFace = u9,
            TextXAlignment = u4.TextXAlignment.Left,
            Text = l__state__2.Description,
            TextColor3 = Color3.new(1, 1, 1)
        })
    };
    local l__Callback__6 = l__state__2.Callback;
    if l__Callback__6 then
        l__Callback__6 = u2.createElement(u11, {
            Title = "Confirm",
            Anchor = Vector2.new(0, 1),
            Position = UDim2.new(0.05, 0, 0.9, 0),
            Size = UDim2.new(0.42, 0, 0.25, 0),
            Offset = u35.OffsetBinding,
            Ignore = not l__state__2.Notification or l__state__2.PopupOpen,
            SoundKit = l__state__2.SoundKit,
            Color = Color3.fromRGB(125, 255, 116),
            Callback = function() --[[ Name: Callback, Line 206 ]]
                -- upvalues: u35 (copy), l__state__2 (copy)
                u35.NotifyTween:SetGoal(0);
                u35:setState({
                    Notification = false
                });
                l__state__2.Callback();
            end
        });
    end;
    v47.Confirm = l__Callback__6;
    v47.Cancel = u2.createElement(u11, {
        SoundKit = "VehicleTabletBase",
        Title = "Cancel",
        Anchor = Vector2.new(1, 1),
        Position = UDim2.new(0.94, 0, 0.9, 0),
        Size = UDim2.new(0.42, 0, 0.25, 0),
        Offset = u35.OffsetBinding,
        Ignore = not l__state__2.Notification or l__state__2.PopupOpen,
        Color = Color3.fromRGB(255, 124, 126),
        Callback = function() --[[ Name: Callback, Line 224 ]]
            -- upvalues: u35 (copy), u3 (ref)
            if u35.ExitIfCancelled then
                u3:FireServer("ActivateInteract", "Exit");
            else
                u35.NotifyTween:SetGoal(0);
                u35:setState({
                    Notification = false
                });
            end;
        end
    });
    v42[1] = l__createElement__5(v43, v46, v47);
    v38[1], v38[2], v38[3] = l__createElement__4(v39, v41, v42), u2.createElement("Frame", {
    BorderSizePixel = 0,
    ZIndex = 2,
    BackgroundColor3 = Color3.fromRGB(0, 0, 0),
    Size = UDim2.fromScale(1, 1),
    BackgroundTransparency = u35.Loading:Map(function(p48) --[[ Line: 241 ]]
        return 1 - p48 * 0.5;
    end)
}, { u2.createElement("ImageLabel", {
        BackgroundTransparency = 1,
        Image = "rbxassetid://14971310215",
        SizeConstraint = u4.SizeConstraint.RelativeYY,
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.fromScale(0.5, 0.5),
        Size = UDim2.fromScale(0.2, 0.2),
        ImageTransparency = u35.Loading:Map(function(p49) --[[ Line: 253 ]]
            return 1 - p49;
        end),
        Rotation = u35.circleBinding
    }) }), u2.createElement("Frame", {
    BorderSizePixel = 0,
    ClipsDescendants = true,
    AnchorPoint = Vector2.new(0.5, 0.5),
    BackgroundColor3 = Color3.fromRGB(61, 61, 61),
    Position = UDim2.new(0.5, 0, 0.5, 0),
    Size = u35.Loading:Map(function(p50) --[[ Line: 264 ]]
        return UDim2.fromScale(1 - p50 / 10, 1 - p50 / 10);
    end)
}, {
    Banner = u2.createElement("Frame", {
        BorderSizePixel = 0,
        ZIndex = 3,
        BackgroundColor3 = Color3.new(1, 1, 1),
        Size = UDim2.new(1, 0, 0.15, 0)
    }, {
        Icon = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Image = "rbxassetid://14771719005",
            AnchorPoint = Vector2.new(0, 0.5),
            Size = UDim2.fromScale(0.75, 0.75),
            SizeConstraint = u4.SizeConstraint.RelativeYY,
            Position = UDim2.fromScale(0.02, 0.5),
            ScaleType = u4.ScaleType.Fit
        }),
        Header = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            Text = "Vehicle Request Portal",
            TextScaled = true,
            AnchorPoint = Vector2.new(0, 0.5),
            Position = UDim2.new(0.1, 0, 0.4, 0),
            Size = UDim2.new(0.9, 0, 0.4, 0),
            FontFace = u10,
            TextXAlignment = u4.TextXAlignment.Left,
            TextColor3 = Color3.new(0, 0, 0)
        }),
        Subheader = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            AnchorPoint = Vector2.new(0, 0.5),
            Position = UDim2.new(0.1, 0, 0.73, 0),
            Size = UDim2.new(0.9, 0, 0.2, 0),
            FontFace = u10,
            TextXAlignment = u4.TextXAlignment.Left,
            Text = u35.welcomeBinding,
            TextColor3 = Color3.new(0, 0, 0)
        }),
        Gradient = u2.createElement("UIGradient", {
            Rotation = 135,
            Color = ColorSequence.new({
                ColorSequenceKeypoint.new(0, Color3.fromRGB(33, 33, 33)),
                ColorSequenceKeypoint.new(0.01, Color3.fromRGB(33, 33, 33)),
                ColorSequenceKeypoint.new(0.02, Color3.fromRGB(255, 148, 17)),
                ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 148, 17))
            }),
            Offset = Vector2.new(0, 0),
            Transparency = NumberSequence.new(0)
        }),
        Purchase = u2.createElement(u11, {
            SoundKit = "VehicleTabletBase",
            Anchor = Vector2.new(1, 0.5),
            Position = UDim2.new(0.95, 0, 0.5, 0),
            Size = UDim2.new(0.25, 0, 0.6, 0),
            Offset = u35.OffsetBinding,
            Ignore = l__state__2.Notification or l__state__2.PopupOpen,
            Title = l__state__2.Page == "Garage" and "Purchase Vehicle" or "Return Home",
            Color = Color3.fromRGB(255, 148, 17),
            Callback = function() --[[ Name: Callback, Line 328 ]]
                -- upvalues: u35 (copy), l__state__2 (copy)
                if u35.Loading:IsGoal(1) then
                else
                    u35.ChangePage(l__state__2.Page == "Garage" and "Purchase" or "Garage");
                end;
            end
        })
    }),
    Page = u2.createElement("Frame", {
        BackgroundTransparency = 1,
        ZIndex = 2,
        Position = UDim2.new(0, 0, 1, 0),
        Size = UDim2.new(1, 0, 0.85, 0),
        AnchorPoint = Vector2.new(0, 1)
    }, {
        [l__state__2.PageId] = u2.createElement(u5["VehicleSpawner" .. l__state__2.Page .. "Component"], {
            OffsetBinding = u35.OffsetBinding,
            VehicleType = u35.VehicleType,
            VehicleData = u35.VehicleData,
            RepairDiscount = u35.RepairDiscount,
            MaxSlots = u35.MaxSlots,
            ChangePage = u35.ChangePage,
            PageData = l__state__2.Data,
            Update = u35.Update,
            Loading = u35.Loading,
            PopupOpen = l__state__2.PopupOpen,
            Notification = l__state__2.Notification,
            Notify = u35.Notify
        })
    })
});
    return l__createElement__3(v36, v37, v38);
end;
return v12;