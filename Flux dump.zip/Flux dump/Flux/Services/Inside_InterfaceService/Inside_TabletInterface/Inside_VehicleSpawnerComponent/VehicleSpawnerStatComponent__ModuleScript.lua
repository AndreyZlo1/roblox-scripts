-- Services.InterfaceService.TabletInterface.VehicleSpawnerComponent.VehicleSpawnerStatComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local _, u1, _, u2 = shared.import("require", "Roact", "network", "Enum");
local u3 = Font.fromName("Ubuntu", u2.FontWeight.Regular, u2.FontStyle.Normal);
Font.fromName("Ubuntu", u2.FontWeight.Bold, u2.FontStyle.Normal);
local v4 = u1.Component:extend("VehicleSpawnerStat");
function v4.render(p5) --[[ Line: 8 ]]
    -- upvalues: u1 (copy), u3 (copy), u2 (copy)
    local l__props__1 = p5.props;
    local l__createElement__2 = u1.createElement;
    local v6 = {
        BackgroundTransparency = 1,
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.fromScale(0.5, l__props__1.Position),
        Size = UDim2.fromScale(0.6, 0.2)
    };
    local v7 = {};
    local v8 = u1.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        AnchorPoint = Vector2.new(0, 0.5),
        Position = UDim2.fromScale(0, 0.5),
        Size = UDim2.new(0.2, 0, 0.7, 0),
        FontFace = u3,
        TextXAlignment = u2.TextXAlignment.Right,
        Text = l__props__1.Title,
        TextColor3 = Color3.new(1, 1, 1)
    });
    local l__createElement__3 = u1.createElement;
    local v9 = {
        BackgroundTransparency = 1,
        TextScaled = true,
        AnchorPoint = Vector2.new(0, 0.5),
        Position = UDim2.fromScale(0.8, 0.5),
        Size = UDim2.new(0.2, 0, 0.7, 0),
        FontFace = u3,
        TextXAlignment = u2.TextXAlignment.Left
    };
    local v10 = math.floor(l__props__1.Value);
    v9.Text = tostring(v10);
    v9.TextColor3 = Color3.new(1, 1, 1);
    v7[1], v7[2], v7[3] = v8, l__createElement__3("TextLabel", v9), u1.createElement("Frame", {
    BorderSizePixel = 0,
    AnchorPoint = Vector2.new(0.5, 0.5),
    Position = UDim2.fromScale(0.5, 0.5),
    Size = UDim2.fromScale(0.5, 0.2),
    BackgroundColor3 = Color3.fromRGB(117, 117, 117)
}, { u1.createElement("Frame", {
        BorderSizePixel = 0,
        BackgroundColor3 = Color3.new(1, 1, 1),
        Size = UDim2.fromScale(l__props__1.Value / l__props__1.Max, 1)
    }) });
    return l__createElement__2("Frame", v6, v7);
end;
return v4;