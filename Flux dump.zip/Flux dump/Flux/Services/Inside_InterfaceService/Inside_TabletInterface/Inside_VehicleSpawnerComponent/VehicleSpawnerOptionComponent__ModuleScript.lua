-- Services.InterfaceService.TabletInterface.VehicleSpawnerComponent.VehicleSpawnerOptionComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _, u3 = shared.import("require", "Roact", "network", "Enum");
local u4 = v1("RoactTween");
local u5 = v1("GameShellProxyButton");
local u6 = Font.fromName("Ubuntu", u3.FontWeight.Regular, u3.FontStyle.Normal);
Font.fromName("Ubuntu", u3.FontWeight.Bold, u3.FontStyle.Normal);
local v7 = u2.Component:extend("VehicleSpawnerGarage");
local u8 = v1("formatNumber");
function v7.init(p9, _) --[[ Line: 14 ]]
    -- upvalues: u4 (copy)
    p9.Hover = u4.new(0);
end;
function v7.render(u10) --[[ Line: 18 ]]
    -- upvalues: u4 (copy), u2 (copy), u5 (copy), u6 (copy), u3 (copy), u8 (copy)
    local l__props__1 = u10.props;
    local l__Flipped__2 = l__props__1.Flipped;
    local l__Open__3 = l__props__1.Open;
    local v11 = 0;
    local v12 = l__Open__3 == l__props__1.Title;
    local v13;
    if #l__Open__3 > 0 then
        v13 = not v12;
    else
        v13 = false;
    end;
    local v14 = l__props__1.Options[l__props__1.Original];
    local v15 = v14 and v14.Price or 0;
    local u16 = {};
    local v17 = {};
    for u18, v19 in l__props__1.Options do
        if l__props__1.Current ~= u18 then
            local u20 = u4.new(0);
            u16[u18] = u20;
            local v21 = v19.Price - v15;
            local u22 = v21 < 0;
            local l__createElement__4 = u2.createElement;
            local v23 = u5;
            local v26 = {
                SoundKit = "VehicleTabletSoft",
                BorderSizePixel = 0,
                Offset = l__props__1.Offset,
                BackgroundColor3 = u20:Map(function(p24) --[[ Line: 45 ]]
                    return Color3.fromRGB(48, 48, 48):Lerp(Color3.fromRGB(255, 148, 17), p24);
                end),
                Position = UDim2.fromScale(0, 0),
                Size = UDim2.fromScale(1, 1),
                MouseEnter = function() --[[ Name: MouseEnter, Line 52 ]]
                    -- upvalues: u20 (copy)
                    u20:SetGoal(1);
                end,
                MouseLeave = function() --[[ Name: MouseLeave, Line 55 ]]
                    -- upvalues: u20 (copy)
                    u20:SetGoal(0);
                end,
                MouseDown = function() --[[ Name: MouseDown, Line 58 ]]
                    -- upvalues: u16 (copy), l__props__1 (copy), u18 (copy)
                    for _, v25 in u16 do
                        v25:SetGoal(0);
                    end;
                    l__props__1.SetOption(u18);
                    l__props__1.Callback:setState({
                        Menu = ""
                    });
                end
            };
            local v27 = {};
            local v29 = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0),
                Position = UDim2.fromScale(0.05, 0.2),
                Size = UDim2.new(0.8, 0, 0.6, 0),
                FontFace = u6,
                TextXAlignment = u3.TextXAlignment.Left,
                Text = v19.Name,
                TextColor3 = u20:Map(function(p28) --[[ Line: 76 ]]
                    return Color3.new(1, 1, 1):Lerp(Color3.new(0, 0, 0), p28);
                end)
            });
            local v30;
            if v21 == 0 then
                v30 = false;
            else
                v30 = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.fromScale(0.05, 0.2),
                    Size = UDim2.new(0.9, 0, 0.6, 0),
                    FontFace = u6,
                    TextXAlignment = u3.TextXAlignment.Right,
                    TextTransparency = v13 and 0.5 or 0,
                    Text = (u22 and "Refund " or "") .. u8((math.abs(v21))),
                    TextColor3 = u20:Map(function(p31) --[[ Line: 90 ]]
                        -- upvalues: u22 (copy)
                        return (u22 and Color3.new(0.603921, 0.972549, 0.568627) or Color3.new(1, 0.529411, 0.529411)):Lerp(Color3.new(0, 0, 0), p31);
                    end)
                });
            end;
            v27[1], v27[2] = v29, v30;
            v17[u18] = l__createElement__4(v23, v26, v27);
            v11 = v11 + 1;
        end;
    end;
    local u32 = v11 == 0 and true or v13;
    local v33 = l__props__1.Options[l__props__1.Current].Price - v15;
    local u34 = v33 < 0;
    local l__createElement__5 = u2.createElement;
    local v35 = "Frame";
    local v36 = {
        BackgroundTransparency = 1,
        ZIndex = v12 and 2 or 1,
        LayoutOrder = l__props__1.Layout
    };
    local v37 = {};
    local v38 = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        AnchorPoint = Vector2.new(0, 0),
        Position = UDim2.fromScale(0.05, 0.2),
        Size = UDim2.new(0.8, 0, 0.2, 0),
        FontFace = u6,
        TextXAlignment = u3.TextXAlignment.Left,
        TextTransparency = u32 and 0.5 or 0,
        Text = l__props__1.Title,
        TextColor3 = Color3.new(1, 1, 1)
    });
    local l__createElement__6 = u2.createElement;
    local v39 = u5;
    local v41 = {
        SoundKit = "VehicleTabletSoft",
        BorderSizePixel = 0,
        Offset = l__props__1.Offset,
        BackgroundColor3 = u10.Hover:Map(function(p40) --[[ Line: 126 ]]
            return Color3.fromRGB(48, 48, 48):Lerp(Color3.fromRGB(255, 148, 17), p40);
        end),
        BackgroundTransparency = u32 and 0.25 or 0,
        Position = UDim2.fromScale(0.05, 0.5),
        Size = UDim2.fromScale(0.9, 0.4),
        Ignore = u32 or l__props__1.Ignore,
        MouseEnter = function() --[[ Name: MouseEnter, Line 135 ]]
            -- upvalues: u32 (ref), u10 (copy)
            if u32 then
            else
                u10.Hover:SetGoal(1);
            end;
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 141 ]]
            -- upvalues: u10 (copy)
            u10.Hover:SetGoal(0);
        end,
        MouseDown = function() --[[ Name: MouseDown, Line 144 ]]
            -- upvalues: u32 (ref), l__props__1 (copy), l__Open__3 (copy)
            if u32 then
            else
                l__props__1.Callback:setState({
                    Menu = l__Open__3 == l__props__1.Title and "" or l__props__1.Title
                });
            end;
        end
    };
    local v42 = {};
    local v44 = u2.createElement("TextLabel", {
        BackgroundTransparency = 1,
        TextScaled = true,
        AnchorPoint = Vector2.new(0, 0),
        Position = UDim2.fromScale(0.05, 0.2),
        Size = UDim2.new(0.9, 0, 0.6, 0),
        FontFace = u6,
        TextXAlignment = u3.TextXAlignment.Left,
        TextTransparency = u32 and 0.5 or 0,
        Text = l__props__1.Options[l__props__1.Current].Name,
        TextColor3 = u10.Hover:Map(function(p43) --[[ Line: 162 ]]
            return Color3.new(1, 1, 1):Lerp(Color3.new(0, 0, 0), p43);
        end)
    });
    local v45;
    if v33 == 0 then
        v45 = false;
    else
        v45 = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            AnchorPoint = Vector2.new(0, 0),
            Position = UDim2.fromScale(0.05, 0.2),
            Size = UDim2.new(0.9, 0, 0.6, 0),
            FontFace = u6,
            TextXAlignment = u3.TextXAlignment.Right,
            TextTransparency = u32 and 0.5 or 0,
            Text = (u34 and "Refund " or "") .. u8((math.abs(v33))),
            TextColor3 = u10.Hover:Map(function(p46) --[[ Line: 176 ]]
                -- upvalues: u34 (copy)
                return (u34 and Color3.new(0.603921, 0.972549, 0.568627) or Color3.new(1, 0.529411, 0.529411)):Lerp(Color3.new(0, 0, 0), p46);
            end)
        });
    end;
    v42[1], v42[2] = v44, v45;
    local v47 = l__createElement__6(v39, v41, v42);
    if v12 then
        v12 = u2.createElement("Frame", {
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0, l__Flipped__2 and 1 or 0),
            Position = UDim2.fromScale(0.05, l__Flipped__2 and 0.5 or 0.9),
            Size = UDim2.fromScale(0.9, 0.4)
        }, { u2.createElement("UIListLayout", {
                FillDirection = u3.FillDirection.Vertical,
                HorizontalAlignment = u3.HorizontalAlignment.Left,
                VerticalAlignment = l__Flipped__2 and u3.VerticalAlignment.Bottom or u3.VerticalAlignment.Top
            }), u2.createFragment(v17) });
    end;
    v37[1], v37[2], v37[3] = v38, v47, v12;
    return l__createElement__5(v35, v36, v37);
end;
return v7;