-- Services.InterfaceService.TabletInterface.VehicleSpawnerComponent.VehicleSpawnerEditComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Roact", "network", "Enum");
local u5 = v1("Mathf");
local u6 = v1("GameShellProxyScroller");
local u7 = v1("StatsService");
local u8 = v1("PopupInterface");
local u9 = v1({ "GroundVehicle", "HelicopterVehicle" });
local l__UserInputService__1 = game:GetService("UserInputService");
local u10 = Font.fromName("Ubuntu", u4.FontWeight.Regular, u4.FontStyle.Normal);
Font.fromName("Ubuntu", u4.FontWeight.Bold, u4.FontStyle.Normal);
local u11 = v1("VehicleSpawnerOptionComponent");
local u12 = v1("VehicleSpawnerStatComponent");
local u13 = v1("VehicleSpawnerButtonComponent");
local v14 = u2.Component:extend("VehicleSpawnerEdit");
local u15 = v1("formatNumber");
function v14.init(u16, p17) --[[ Line: 26 ]]
    -- upvalues: u2 (copy), u5 (copy), l__UserInputService__1 (copy), u4 (copy), u9 (copy)
    u16.VehicleData = p17.VehicleData;
    u16.VehicleType = p17.VehicleType;
    u16.OffsetBinding = p17.OffsetBinding;
    u16.Loading = p17.Loading;
    u16.PageData = p17.PageData;
    u16.ChangePage = p17.ChangePage;
    u16.Notify = p17.Notify;
    local u18 = Instance.new("Camera");
    u18.FieldOfView = 50;
    u16.Camera = u18;
    u16.Viewport = u2.createRef();
    local u19 = 0;
    local u20 = 3.9269908169872414;
    local u21 = 4.71238898038469;
    local u22 = 0;
    p17.Update:Connect(function(p23) --[[ Line: 45 ]]
        -- upvalues: u20 (ref), u19 (ref), u21 (ref), u5 (ref), u16 (copy), u18 (copy), u22 (ref)
        local v24 = p23 * 10;
        u20 = u20 - u19 * p23 * 2;
        u21 = u5.Lerp(u21, u20, v24);
        local v25 = u21;
        local v26 = Vector3.new(0, -1, 0);
        if u16.ModelHitbox then
            v26 = v26 + u16.ModelHitbox.CFrame.Position;
        end;
        local v27 = u18;
        local l__new__2 = CFrame.new;
        local v28 = math.sin(v25) * u22;
        local v29 = math.cos(v25) * u22;
        v27.CFrame = l__new__2(v26 + Vector3.new(v28, 2, v29), v26);
    end);
    u16._input = l__UserInputService__1.InputChanged:Connect(function(p30) --[[ Line: 59 ]]
        -- upvalues: u4 (ref), u20 (ref), u19 (ref)
        if p30.UserInputType == u4.UserInputType.MouseMovement then
            u20 = u20 - p30.Delta.X / 200;
        else
            if p30.UserInputType.Name:sub(1, 7) == "Gamepad" and p30.KeyCode == u4.KeyCode.Thumbstick1 then
                local l__X__3 = p30.Position.X;
                if math.abs(l__X__3) > 0.2 then
                    u19 = l__X__3;
                    return;
                end;
                u19 = 0;
            end;
        end;
    end);
    local v31 = u4.VehicleType[p17.VehicleType];
    local v32;
    if u16.PageData.VehicleIndex > 0 then
        v32 = u16.VehicleData[u16.PageData.VehicleIndex];
    else
        u16.IsPurchasing = true;
        v32 = {
            u16.PageData.VehicleName,
            {}
        };
    end;
    local v33 = u9[p17.VehicleType .. "Vehicle"].new(0, nil, {
        Type = v31,
        Name = v32[1],
        CFrame = CFrame.new(),
        Modifications = v32[2]
    });
    u22 = v33.VehicleModule.Zoom - 10;
    u16.VehicleActor = v33;
    u16.Vehicle = v32;
    u16.Original = {
        Camo = v33.VehicleCamo,
        Armor = v33.VehicleArmor,
        Turrets = v33.VehicleTurrets or v33.VehicleTurret
    };
    u16:setState({
        Menu = ""
    });
end;
function v14.willUnmount(p34) --[[ Line: 108 ]]
    if p34.VehicleActor then
        p34.VehicleActor:Destroy();
    end;
    p34._input:Disconnect();
end;
function v14.didMount(p35) --[[ Line: 115 ]]
    local l__VehicleActor__4 = p35.VehicleActor;
    p35.ModelHitbox = l__VehicleActor__4.Hitbox;
    l__VehicleActor__4.Model.Parent = p35.Viewport:getValue();
end;
function v14.render(u36) --[[ Line: 121 ]]
    -- upvalues: u2 (copy), u4 (copy), u11 (copy), u7 (copy), u6 (copy), u13 (copy), u8 (copy), u3 (copy), u10 (copy), u15 (copy), u12 (copy)
    local l__IsPurchasing__5 = u36.IsPurchasing;
    local l__PopupOpen__6 = u36.props.PopupOpen;
    local l__Notification__7 = u36.props.Notification;
    local l__OffsetBinding__8 = u36.OffsetBinding;
    local l__VehicleActor__9 = u36.VehicleActor;
    local l__VehicleModule__10 = l__VehicleActor__9.VehicleModule;
    local l__Original__11 = u36.Original;
    local l__Menu__12 = u36.state.Menu;
    local v37 = 0;
    if l__IsPurchasing__5 then
        v37 = v37 + l__VehicleModule__10.Price;
    end;
    local v38 = {};
    local l__Camo__13 = l__VehicleModule__10.Camo;
    v38.Camo = {
        Title = "Camouflage",
        Layout = 1,
        SetOption = function(p39) --[[ Name: SetOption, Line 142 ]]
            -- upvalues: l__VehicleActor__9 (copy)
            l__VehicleActor__9:ChangeCamo(p39);
            l__VehicleActor__9:RegenerateModel();
        end,
        Original = l__Original__11.Camo,
        Current = l__VehicleActor__9.VehicleCamo,
        Options = l__Camo__13
    };
    local v40 = v37 + (l__Camo__13[l__VehicleActor__9.VehicleCamo].Price - l__Camo__13[l__Original__11.Camo].Price);
    local l__Armor__14 = l__VehicleModule__10.Armor;
    v38.Config = {
        Title = "Configuration",
        Layout = 2,
        SetOption = function(p41) --[[ Name: SetOption, Line 157 ]]
            -- upvalues: l__VehicleActor__9 (copy)
            l__VehicleActor__9:ChangeArmor(p41);
            l__VehicleActor__9:RegenerateModel();
        end,
        Original = l__Original__11.Armor,
        Current = l__VehicleActor__9.VehicleArmor,
        Options = l__Armor__14
    };
    local u42 = v40 + (l__Armor__14[l__VehicleActor__9.VehicleArmor].Price - l__Armor__14[l__Original__11.Armor].Price);
    local v43 = 2;
    local v44 = 0;
    for u45, v46 in l__VehicleModule__10.Turrets do
        local v47 = 0;
        local v48 = {};
        for v49, v50 in v46 do
            if table.find(v50.Whitelist, l__VehicleActor__9.VehicleArmor) then
                v47 = v47 + 1;
                v48[v49] = v50;
            end;
        end;
        if v47 > 1 then
            v43 = v43 + 1;
            local v51 = l__VehicleActor__9.VehicleTurrets and l__VehicleActor__9.VehicleTurrets[u45] or l__VehicleActor__9.VehicleTurret[u45];
            v38[u45] = {
                Title = u45,
                Layout = v43,
                Original = l__Original__11.Turrets[u45],
                SetOption = function(p52) --[[ Name: SetOption, Line 190 ]]
                    -- upvalues: l__VehicleActor__9 (copy), u45 (copy)
                    l__VehicleActor__9:ChangeTurret(u45, p52);
                    l__VehicleActor__9:RegenerateModel();
                end,
                Current = v51,
                Options = v48
            };
            if v46[v51].Turret then
                v44 = v44 + 1;
            end;
            local v53 = v46[l__Original__11.Turrets[u45]];
            u42 = u42 + (v46[v51].Price - (v53 and v53.Price or 0));
        end;
    end;
    local v54 = {
        Grid = u2.createElement("UIGridLayout", {
            CellPadding = UDim2.fromScale(0, 0),
            CellSize = UDim2.fromScale(1, 1 / v43),
            FillDirection = u4.FillDirection.Vertical,
            HorizontalAlignment = u4.HorizontalAlignment.Left,
            SortOrder = u4.SortOrder.LayoutOrder,
            StartCorner = u4.StartCorner.TopLeft,
            VerticalAlignment = u4.VerticalAlignment.Top
        })
    };
    for v55, v56 in v38 do
        local l__Layout__15 = v56.Layout;
        local l__createElement__16 = u2.createElement;
        local v57 = u11;
        local v58 = {
            Offset = l__OffsetBinding__8
        };
        local v59;
        if l__Layout__15 > 2 then
            v59 = l__Layout__15 == v43 and true or l__Layout__15 == v43 - 1;
        else
            v59 = false;
        end;
        v58.Flipped = v59;
        v58.Open = l__Menu__12;
        v58.Callback = u36;
        v58.Ignore = l__Notification__7 or l__PopupOpen__6;
        v58.Layout = l__Layout__15;
        v58.Title = v56.Title;
        v58.Original = v56.Original;
        v58.SetOption = v56.SetOption;
        v58.Current = v56.Current;
        v58.Options = v56.Options;
        v54[v55] = l__createElement__16(v57, v58);
    end;
    for _, v60 in l__VehicleModule__10.Seats do
        if table.find(v60.Whitelist, l__VehicleActor__9.VehicleArmor) then
            v44 = v44 + 1;
        end;
    end;
    local u61 = u42 < 0;
    local u62 = u7.Level >= l__VehicleModule__10.Level;
    local l__createFragment__17 = u2.createFragment;
    local v63 = {};
    local v64 = u2.createElement(u6, {
        BackgroundTransparency = 0,
        BorderSizePixel = 0,
        BackgroundColor3 = Color3.new(0, 0, 0),
        Size = UDim2.fromScale(0.3, 0.7),
        Position = UDim2.fromScale(0, 0),
        AnchorPoint = Vector2.new(0, 0),
        OffsetBinding = l__OffsetBinding__8,
        CanvasSize = v43 / 4,
        Content = v54
    });
    local v65 = u2.createElement("ViewportFrame", {
        LightDirection = Vector3.new(0.5, -1, 0.5),
        BorderSizePixel = 0,
        BackgroundTransparency = 1,
        Ambient = Color3.new(1, 1, 1),
        LightColor = Color3.new(1, 1, 1),
        BackgroundColor3 = Color3.fromRGB(33, 33, 33),
        Size = UDim2.fromScale(0.7, 1),
        Position = UDim2.fromScale(0.3, 0),
        CurrentCamera = u36.Camera
    }, { u2.createElement("WorldModel", {
            [u2.Ref] = u36.Viewport
        }) });
    local l__createElement__18 = u2.createElement;
    local v66 = "Frame";
    local v67 = {
        BorderSizePixel = 0,
        BackgroundColor3 = Color3.fromRGB(57, 57, 57),
        Position = UDim2.fromScale(0, 0.7),
        Size = UDim2.fromScale(0.3, 0.3)
    };
    local v68 = {};
    local l__createElement__19 = u2.createElement;
    local v69 = u13;
    local v70 = {};
    local v71;
    if u62 then
        v71 = l__IsPurchasing__5 and "Purchase Vehicle" or "Apply Upgrades";
    else
        v71 = "Level " .. l__VehicleModule__10.Level .. " Required";
    end;
    v70.Title = v71;
    v70.Position = UDim2.fromScale(0.05, 0.9);
    v70.Anchor = Vector2.new(0, 1);
    v70.Color = u62 and Color3.fromRGB(125, 255, 116) or Color3.fromRGB(255, 116, 116);
    v70.Size = UDim2.fromScale(0.9, 0.3);
    v70.SoundKit = u62 and "VehicleTabletMain" or "VehicleTabletError";
    v70.Ignore = l__Notification__7 or l__PopupOpen__6;
    v70.Offset = l__OffsetBinding__8;
    function v70.Callback() --[[ Line: 295 ]]
        -- upvalues: u62 (copy), u61 (copy), u7 (ref), u42 (ref), u8 (ref), u4 (ref), u36 (copy), l__IsPurchasing__5 (copy), l__VehicleActor__9 (copy), u3 (ref), l__Armor__14 (copy)
        if u62 then
            if u61 or u42 <= u7.Money then
                if u36.Loading:IsGoal(1) then
                elseif l__IsPurchasing__5 and #u36.VehicleData >= u36.props.MaxSlots then
                    u36.Notify("Max vehicle slots used", "Upgrade your HQ to unlock more vehicle slots");
                else
                    u36.Notify(l__IsPurchasing__5 and "Purchase vehicle?" or "Apply changes?", l__IsPurchasing__5 and "Are you sure you would like to purchase this vehicle?" or "Are you sure you would like to apply these changes?", function() --[[ Line: 321 ]]
                        -- upvalues: u36 (ref), l__VehicleActor__9 (ref), l__IsPurchasing__5 (ref), u3 (ref), l__Armor__14 (ref)
                        u36.Loading:SetGoal(1);
                        local v72 = {
                            Camo = l__VehicleActor__9.VehicleCamo,
                            Armor = l__VehicleActor__9.VehicleArmor,
                            Turrets = l__VehicleActor__9.VehicleTurrets or l__VehicleActor__9.VehicleTurret
                        };
                        local v73;
                        if l__IsPurchasing__5 then
                            local v74;
                            v73, v74 = u3:InvokeServer("BuyVehicle", u36.VehicleType, u36.PageData.VehicleName, v72);
                            if v73 then
                                u36.VehicleData[#u36.VehicleData + 1] = v74;
                            end;
                        else
                            local v75;
                            v73, v75 = u3:InvokeServer("EditVehicle", u36.VehicleType, u36.PageData.VehicleIndex, v72);
                            if v73 then
                                u36.Vehicle[2] = v75;
                                u36.Vehicle[3] = math.min(u36.Vehicle[3], l__Armor__14[v75.Armor].Health);
                            end;
                        end;
                        u36.Loading:SetGoal(0);
                        if v73 then
                            u36.ChangePage("Garage");
                        end;
                    end, "VehicleTabletSell");
                end;
            else
                u8:Open("Insufficient Funds", nil, {
                    { "Close", function() --[[ Line: 303 ]]
                            -- upvalues: u8 (ref)
                            u8:Close();
                        end }
                }, u4.PopupType.Shop);
            end;
        end;
    end;
    v68[1], v68[2], v68[3], v68[4], v68[5], v68[6], v68[7] = l__createElement__19(v69, v70), u2.createElement("TextLabel", {
    BackgroundTransparency = 1,
    Text = "Current Balance: ",
    TextScaled = true,
    AnchorPoint = Vector2.new(0, 0),
    Position = UDim2.fromScale(0.05, 0.1),
    Size = UDim2.new(0.9, 0, 0.13, 0),
    FontFace = u10,
    TextXAlignment = u4.TextXAlignment.Left,
    TextColor3 = Color3.new(1, 1, 1)
}), u2.createElement("TextLabel", {
    BackgroundTransparency = 1,
    TextScaled = true,
    AnchorPoint = Vector2.new(0, 0),
    Position = UDim2.fromScale(0.05, 0.1),
    Size = UDim2.new(0.9, 0, 0.13, 0),
    FontFace = u10,
    TextXAlignment = u4.TextXAlignment.Right,
    Text = u7.MoneyBinding:map(function(p76) --[[ Line: 368 ]]
        -- upvalues: u15 (ref)
        return u15(p76);
    end),
    TextColor3 = Color3.new(1, 1, 1)
}), u2.createElement("TextLabel", {
    BackgroundTransparency = 1,
    Text = "Total Cost: ",
    TextScaled = true,
    AnchorPoint = Vector2.new(0, 0),
    Position = UDim2.fromScale(0.05, 0.25),
    Size = UDim2.new(0.9, 0, 0.13, 0),
    FontFace = u10,
    TextXAlignment = u4.TextXAlignment.Left,
    TextColor3 = Color3.new(1, 1, 1)
}), u2.createElement("TextLabel", {
    BackgroundTransparency = 1,
    TextScaled = true,
    AnchorPoint = Vector2.new(0, 0),
    Position = UDim2.fromScale(0.05, 0.25),
    Size = UDim2.new(0.9, 0, 0.13, 0),
    FontFace = u10,
    TextXAlignment = u4.TextXAlignment.Right,
    Text = (u61 and "Refund " or "") .. u15((math.abs(u42))),
    TextColor3 = u61 and Color3.new(0.603921, 0.972549, 0.568627) or Color3.new(1, 0.529411, 0.529411)
}), u2.createElement("TextLabel", {
    BackgroundTransparency = 1,
    Text = "Balance After: ",
    TextScaled = true,
    AnchorPoint = Vector2.new(0, 0),
    Position = UDim2.fromScale(0.05, 0.4),
    Size = UDim2.new(0.9, 0, 0.13, 0),
    FontFace = u10,
    TextXAlignment = u4.TextXAlignment.Left,
    TextColor3 = Color3.new(1, 1, 1)
}), u2.createElement("TextLabel", {
    BackgroundTransparency = 1,
    TextScaled = true,
    AnchorPoint = Vector2.new(0, 0),
    Position = UDim2.fromScale(0.05, 0.4),
    Size = UDim2.new(0.9, 0, 0.13, 0),
    FontFace = u10,
    TextXAlignment = u4.TextXAlignment.Right,
    Text = u7.MoneyBinding:map(function(p77) --[[ Line: 414 ]]
        -- upvalues: u15 (ref), u42 (ref)
        return u15(p77 - u42);
    end),
    TextColor3 = Color3.new(1, 1, 1)
});
    v63[1], v63[2], v63[3], v63[4] = v64, v65, l__createElement__18(v66, v67, v68), u2.createElement("Frame", {
    BackgroundTransparency = 0.7,
    BorderSizePixel = 0,
    BackgroundColor3 = Color3.new(0, 0, 0),
    Position = UDim2.fromScale(0.3, 0.8),
    Size = UDim2.fromScale(0.7, 0.2)
}, {
    Gradient = u2.createElement("UIGradient", {
        Rotation = 15,
        Transparency = NumberSequence.new({
            NumberSequenceKeypoint.new(0, 1),
            NumberSequenceKeypoint.new(0.005, 0),
            NumberSequenceKeypoint.new(0.995, 0),
            NumberSequenceKeypoint.new(1, 1)
        })
    }),
    Armor = u2.createElement(u12, {
        Position = 0.25,
        Title = "Armor",
        Max = 50000,
        Value = l__Armor__14[l__VehicleActor__9.VehicleArmor].Health
    }),
    Speed = u2.createElement(u12, {
        Position = 0.5,
        Title = "Speed",
        Max = 200,
        Value = l__Armor__14[l__VehicleActor__9.VehicleArmor].Speed
    }),
    Capacity = u2.createElement(u12, {
        Position = 0.75,
        Title = "Capacity",
        Max = 32,
        Value = v44
    })
});
    return l__createFragment__17(v63);
end;
return v14;