-- Services.InterfaceService.TabletInterface.VehicleSpawnerComponent.VehicleSpawnerButtonComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _, u3 = shared.import("require", "Roact", "network", "Enum");
local u4 = v1("RoactTween");
local u5 = v1("GameShellProxyButton");
local u6 = Font.fromName("Ubuntu", u3.FontWeight.Regular, u3.FontStyle.Normal);
local u7 = Font.fromName("Ubuntu", u3.FontWeight.Bold, u3.FontStyle.Normal);
local v8 = u2.Component:extend("VehicleSpawnerGarageAction");
function v8.init(p9, _) --[[ Line: 12 ]]
    -- upvalues: u4 (copy), u3 (copy)
    p9.hover = u4.new(0, TweenInfo.new(0.1, u3.EasingStyle.Exponential, u3.EasingDirection.Out, 0, false, 0));
end;
function v8.render(u10) --[[ Line: 16 ]]
    -- upvalues: u2 (copy), u5 (copy), u7 (copy), u3 (copy), u6 (copy)
    local l__props__1 = u10.props;
    local l__Title__2 = l__props__1.Title;
    local l__Sub__3 = l__props__1.Sub;
    local l__Disabled__4 = l__props__1.Disabled;
    local l__createElement__5 = u2.createElement;
    local v11 = u5;
    local v12 = {
        BorderSizePixel = 0,
        ZIndex = 2,
        Offset = l__props__1.Offset,
        Position = l__props__1.Position,
        AnchorPoint = l__props__1.Anchor,
        SoundKit = l__props__1.SoundKit,
        BackgroundColor3 = Color3.new(),
        Size = l__props__1.Size,
        Ignore = l__props__1.Ignore or l__Disabled__4,
        MouseEnter = function() --[[ Name: MouseEnter, Line 33 ]]
            -- upvalues: u10 (copy)
            u10.hover:SetGoal(1);
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 36 ]]
            -- upvalues: u10 (copy)
            u10.hover:SetGoal(0);
        end,
        MouseUp = function() --[[ Name: MouseUp, Line 39 ]]
            -- upvalues: l__props__1 (copy)
            l__props__1.Callback();
        end
    };
    local v15 = {
        Banner = u2.createElement("Frame", {
            BorderSizePixel = 0,
            AnchorPoint = Vector2.new(1, 0),
            Position = UDim2.fromScale(1, 0),
            BackgroundColor3 = l__props__1.Color,
            Size = u10.hover:Map(function(p13) --[[ Line: 48 ]]
                return UDim2.fromScale(0.02, 1):Lerp(UDim2.fromScale(1, 1), p13);
            end)
        }),
        Title = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            TextWrapped = true,
            ZIndex = 2,
            Position = UDim2.new(0.1, 0, l__Sub__3 and 0.1 or 0.3, 0),
            Size = UDim2.new(0.8, 0, 0.4, 0),
            FontFace = u7,
            Text = l__Title__2:upper(),
            TextColor3 = u10.hover:Map(function(p14) --[[ Line: 58 ]]
                return Color3.new(1, 1, 1):Lerp(Color3.new(0, 0, 0), p14);
            end),
            TextTransparency = l__Disabled__4 and 0.5 or 0,
            TextXAlignment = u3.TextXAlignment.Left
        })
    };
    if l__Sub__3 then
        l__Sub__3 = u2.createElement("TextLabel", {
            BackgroundTransparency = 1,
            TextScaled = true,
            TextWrapped = true,
            ZIndex = 2,
            Position = UDim2.new(0.1, 0, 0.9, 0),
            AnchorPoint = Vector2.new(0, 1),
            Size = UDim2.new(0.8, 0, 0.4, 0),
            FontFace = u6,
            Text = l__Sub__3:upper(),
            TextColor3 = u10.hover:Map(function(p16) --[[ Line: 74 ]]
                return Color3.new(1, 1, 1):Lerp(Color3.new(0, 0, 0), p16);
            end),
            TextTransparency = l__Disabled__4 and 0.5 or 0,
            TextXAlignment = u3.TextXAlignment.Left
        });
    end;
    v15.Sub = l__Sub__3;
    return l__createElement__5(v11, v12, v15);
end;
return v8;