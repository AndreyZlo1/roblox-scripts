-- Services.InterfaceService.TabletInterface.VehicleSpawnerComponent.VehicleSpawnerPurchaseComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _, u3 = shared.import("require", "Roact", "network", "Enum");
local u4 = v1("Mathf");
v1("StatsService");
local u5 = v1("GameShellProxyButton");
local u6 = v1("GameShellProxyScroller");
local u7 = v1({ "GroundVehicle", "HelicopterVehicle" });
local u8 = v1("RoactTween");
game:GetService("DataStoreService");
local l__UserInputService__1 = game:GetService("UserInputService");
local u9 = v1("Vehicle");
local u10 = Font.fromName("Ubuntu", u3.FontWeight.Regular, u3.FontStyle.Normal);
local u11 = Font.fromName("Ubuntu", u3.FontWeight.Bold, u3.FontStyle.Normal);
local u12 = v1("VehicleSpawnerButtonComponent");
local v13 = u2.Component:extend("VehicleSpawnerGarage");
local u14 = v1("formatNumber");
function v13.init(u15, u16) --[[ Line: 30 ]]
    -- upvalues: u3 (copy), u2 (copy), u7 (copy), u9 (copy), u8 (copy), u4 (copy), l__UserInputService__1 (copy)
    local u17 = {};
    local u18 = u3.VehicleType[u16.VehicleType];
    function u15.UpdateVehicles() --[[ Line: 33 ]]
        -- upvalues: u15 (copy), u17 (copy), u2 (ref), u7 (ref), u16 (copy), u18 (copy)
        if u15.Viewports then
            for _, v19 in u15.Viewports do
                v19.Model.Model:Destroy();
            end;
        end;
        local v20 = {};
        for v21, v22 in u17 do
            if v22.Enabled then
                v20[#v20 + 1] = v21;
            end;
        end;
        local v23 = {};
        for v24, v25 in u15.VehicleData do
            if #v20 <= 0 or table.find(v20, v25[3]) then
                local v26 = u2.createRef();
                local v27 = Instance.new("Camera");
                v27.FieldOfView = 35;
                local v28 = u7[u16.VehicleType .. "Vehicle"].new(0, nil, {
                    Type = u18,
                    Name = v24,
                    CFrame = CFrame.new(),
                    Modifications = {}
                });
                v23[v24] = {
                    Zoom = v28.VehicleModule.Zoom,
                    Viewport = v26,
                    Camera = v27,
                    Model = v28
                };
            end;
        end;
        u15.Viewports = v23;
        u15:setState({});
    end;
    local v29 = {};
    for v30, v31 in u9[u16.VehicleType] do
        if v31.ForSale then
            if not u17[v31.Category] then
                u17[v31.Category] = {
                    Enabled = false,
                    Tween = u8.new(0)
                };
            end;
            v29[v30] = {
                v31.Name,
                v31.Price,
                v31.Category,
                v31.Gamepass,
                v31.Level or 0
            };
        end;
    end;
    u15.VehicleTags = u17;
    u15.VehicleData = v29;
    u15.OffsetBinding = u16.OffsetBinding;
    u15.ChangePage = u16.ChangePage;
    u15.Notify = u16.Notify;
    u15.Loading = u16.Loading;
    u15.Viewports = {};
    local u32 = 0;
    local u33 = 3.9269908169872414;
    local u34 = 4.71238898038469;
    u15._connection = u16.Update:Connect(function(p35) --[[ Line: 108 ]]
        -- upvalues: u33 (ref), u32 (ref), u34 (ref), u4 (ref), u15 (copy)
        local v36 = p35 * 10;
        u33 = u33 - u32 * p35 * 2;
        u34 = u4.Lerp(u34, u33, v36);
        local v37 = u34;
        for _, v38 in u15.Viewports do
            local v39 = Vector3.new(0, -1, 0) + v38.Model.Hitbox.Position;
            local l__Camera__2 = v38.Camera;
            local l__new__3 = CFrame.new;
            local v40 = math.sin(v37) * v38.Zoom;
            local v41 = math.cos(v37) * v38.Zoom;
            l__Camera__2.CFrame = l__new__3(v39 + Vector3.new(v40, 2, v41), v39);
        end;
    end);
    u15._input = l__UserInputService__1.InputChanged:Connect(function(p42) --[[ Line: 120 ]]
        -- upvalues: u3 (ref), u33 (ref), u32 (ref)
        if p42.UserInputType == u3.UserInputType.MouseMovement then
            u33 = u33 - p42.Delta.X / 200;
        else
            if p42.UserInputType.Name:sub(1, 7) == "Gamepad" and p42.KeyCode == u3.KeyCode.Thumbstick1 then
                local l__X__4 = p42.Position.X;
                if math.abs(l__X__4) > 0.2 then
                    u32 = l__X__4;
                    return;
                end;
                u32 = 0;
            end;
        end;
    end);
    u15.UpdateVehicles();
end;
function v13.willUnmount(p43) --[[ Line: 138 ]]
    for _, v44 in p43.Viewports do
        v44.Model:Destroy();
    end;
    p43._connection:Disconnect();
    p43._input:Disconnect();
end;
function v13.didMount(p45) --[[ Line: 146 ]]
    for _, v46 in p45.Viewports do
        v46.Model.Model.Parent = v46.Viewport:getValue();
    end;
end;
function v13.didUpdate(p47) --[[ Line: 152 ]]
    for _, v48 in p47.Viewports do
        v48.Model.Model.Parent = v48.Viewport:getValue();
    end;
end;
function v13.render(u49) --[[ Line: 158 ]]
    -- upvalues: u2 (copy), u11 (copy), u3 (copy), u10 (copy), u12 (copy), u14 (copy), u5 (copy), u6 (copy)
    local l__VehicleData__5 = u49.VehicleData;
    local l__OffsetBinding__6 = u49.OffsetBinding;
    local l__PopupOpen__7 = u49.props.PopupOpen;
    local l__Notification__8 = u49.props.Notification;
    local v50 = 0;
    local v51 = {};
    for u52, v53 in l__VehicleData__5 do
        local v54 = u49.Viewports[u52];
        if v54 then
            v50 = v50 + 1;
            local l__VehicleModule__9 = v54.Model.VehicleModule;
            local l__VehicleArmor__10 = v54.Model.VehicleArmor;
            local l__Health__11 = l__VehicleModule__9.Armor[l__VehicleArmor__10].Health;
            local l__Speed__12 = l__VehicleModule__9.Armor[l__VehicleArmor__10].Speed;
            local v55 = 0;
            for _, v56 in l__VehicleModule__9.Seats do
                if table.find(v56.Whitelist, l__VehicleArmor__10) then
                    v55 = v55 + 1;
                end;
            end;
            v51[u52] = u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.new(1, 1, 1)
            }, {
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 0,
                    Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(29, 29, 29)), ColorSequenceKeypoint.new(0.7, Color3.fromRGB(47, 47, 47)), ColorSequenceKeypoint.new(1, Color3.fromRGB(47, 47, 47)) })
                }),
                Name = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.fromScale(0.1, 0.15),
                    Size = UDim2.new(0.8, 0, 0.1, 0),
                    FontFace = u11,
                    TextXAlignment = u3.TextXAlignment.Left,
                    Text = v53[1],
                    TextColor3 = Color3.new(1, 1, 1)
                }),
                Armor = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    RichText = true,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.fromScale(0.1, 0.28),
                    Size = UDim2.new(0.8, 0, 0.06, 0),
                    FontFace = u10,
                    TextXAlignment = u3.TextXAlignment.Left,
                    Text = "<b>Armor: </b>" .. tostring(l__Health__11),
                    TextColor3 = Color3.new(1, 1, 1)
                }),
                Seats = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    RichText = true,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.fromScale(0.1, 0.34),
                    Size = UDim2.new(0.8, 0, 0.06, 0),
                    FontFace = u10,
                    TextXAlignment = u3.TextXAlignment.Left,
                    Text = "<b>Seats: </b>" .. tostring(v55),
                    TextColor3 = Color3.new(1, 1, 1)
                }),
                Speed = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    RichText = true,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.fromScale(0.1, 0.4),
                    Size = UDim2.new(0.8, 0, 0.06, 0),
                    FontFace = u10,
                    TextXAlignment = u3.TextXAlignment.Left,
                    Text = "<b>Speed: </b>" .. tostring(l__Speed__12),
                    TextColor3 = Color3.new(1, 1, 1)
                }),
                Request = u2.createElement(u12, {
                    Title = "Order",
                    Position = UDim2.fromScale(0.65, 1),
                    Anchor = Vector2.new(0.5, 1),
                    Color = Color3.fromRGB(125, 255, 116),
                    Size = UDim2.fromScale(0.44, 0.25),
                    Ignore = l__Notification__8 or l__PopupOpen__7,
                    Offset = l__OffsetBinding__6,
                    Callback = function() --[[ Name: Callback, Line 253 ]]
                        -- upvalues: u49 (copy), u52 (copy)
                        u49.ChangePage("Edit", {
                            VehicleIndex = -1,
                            VehicleName = u52
                        });
                    end
                }),
                Price = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.fromScale(0.1, 0.75),
                    Size = UDim2.new(0.8, 0, 0.1, 0),
                    FontFace = u11,
                    TextXAlignment = u3.TextXAlignment.Left,
                    Text = v53[4] > 0 and "Gamepass" or u14(v53[2]),
                    TextColor3 = Color3.fromRGB(255, 164, 84)
                }),
                Level = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    AnchorPoint = Vector2.new(0, 0),
                    Position = UDim2.fromScale(0.1, 0.65),
                    Size = UDim2.new(0.8, 0, 0.1, 0),
                    FontFace = u11,
                    TextXAlignment = u3.TextXAlignment.Left,
                    Text = "Level " .. tostring(v53[5]) .. "+",
                    TextColor3 = Color3.fromRGB(255, 255, 255)
                }),
                Preview = u2.createElement("ViewportFrame", {
                    LightDirection = Vector3.new(0.5, -1, 0.5),
                    BackgroundTransparency = 1,
                    BorderSizePixel = 0,
                    Ambient = Color3.new(1, 1, 1),
                    LightColor = Color3.new(1, 1, 1),
                    AnchorPoint = Vector2.new(0.5, 0),
                    Position = UDim2.fromScale(0.65, 0.1),
                    Size = UDim2.fromScale(0.5, 0.7),
                    BackgroundColor3 = Color3.fromRGB(61, 61, 61),
                    CurrentCamera = v54.Camera
                }, { u2.createElement("WorldModel", {
                        [u2.Ref] = v54.Viewport
                    }) })
            });
        end;
    end;
    local v57 = math.max(4, v50) / 2;
    local v58 = math.ceil(v57);
    local v59 = 1 / v58;
    v51.Grid = u2.createElement("UIGridLayout", {
        CellPadding = UDim2.fromScale(0.02, v59 * 0.1),
        CellSize = UDim2.fromScale(0.45, v59 * 0.9),
        FillDirection = u3.FillDirection.Horizontal,
        HorizontalAlignment = u3.HorizontalAlignment.Left,
        SortOrder = u3.SortOrder.LayoutOrder,
        StartCorner = u3.StartCorner.TopLeft,
        VerticalAlignment = u3.VerticalAlignment.Top
    });
    local v60 = { u2.createElement("UIListLayout", {
            FillDirection = u3.FillDirection.Horizontal,
            HorizontalAlignment = u3.HorizontalAlignment.Left,
            SortOrder = u3.SortOrder.LayoutOrder,
            VerticalAlignment = u3.VerticalAlignment.Top
        }) };
    for v61, u62 in u49.VehicleTags do
        v60[v61] = u2.createElement(u5, {
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            ZIndex = 2,
            Offset = l__OffsetBinding__6,
            Size = UDim2.fromScale(0.2, 1),
            Ignore = l__Notification__8,
            MouseEnter = function() --[[ Name: MouseEnter, Line 331 ]]
                -- upvalues: u62 (copy)
                u62.Tween:SetGoal(1);
            end,
            MouseLeave = function() --[[ Name: MouseLeave, Line 334 ]]
                -- upvalues: u62 (copy)
                u62.Tween:SetGoal(0);
            end,
            MouseUp = function() --[[ Name: MouseUp, Line 337 ]]
                -- upvalues: u62 (copy), u49 (copy)
                u62.Enabled = not u62.Enabled;
                u49.UpdateVehicles();
            end
        }, {
            Title = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                TextWrapped = true,
                Position = UDim2.new(0.25, 0, 0.26, 0),
                Size = UDim2.new(0.75, 0, 0.5, 0),
                FontFace = u11,
                Text = v61,
                TextColor3 = u62.Tween:Map(function(p63) --[[ Line: 348 ]]
                    return Color3.new(1, 1, 1):Lerp(Color3.fromRGB(255, 148, 17), p63);
                end),
                TextXAlignment = u3.TextXAlignment.Left
            }),
            Box = u2.createElement("Frame", {
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                BackgroundColor3 = u62.Tween:Map(function(p64) --[[ Line: 358 ]]
                    return Color3.new(1, 1, 1):Lerp(Color3.fromRGB(255, 148, 17), p64);
                end),
                AnchorPoint = Vector2.new(0.5, 0.5),
                Size = UDim2.fromScale(0.5, 0.5),
                Position = UDim2.fromScale(0.1, 0.5),
                SizeConstraint = u3.SizeConstraint.RelativeYY
            }, {
                Inner = u2.createElement("Frame", {
                    BackgroundTransparency = 0,
                    BorderSizePixel = 0,
                    BackgroundColor3 = u62.Enabled and u62.Tween:Map(function(p65) --[[ Line: 369 ]]
                        return Color3.new(1, 1, 1):Lerp(Color3.fromRGB(255, 148, 17), p65);
                    end) or Color3.fromRGB(27, 27, 27),
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Size = UDim2.fromScale(0.4, 0.4),
                    Position = UDim2.fromScale(0.5, 0.5),
                    SizeConstraint = u3.SizeConstraint.RelativeYY
                }, {
                    Stroke = u2.createElement("UIStroke", {
                        Thickness = 2,
                        Color = Color3.fromRGB(27, 27, 27),
                        LineJoinMode = u3.LineJoinMode.Miter
                    })
                })
            })
        });
    end;
    return u2.createFragment({
        Banner = u2.createElement("Frame", {
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.fromRGB(27, 27, 27),
            Size = UDim2.new(1, 0, 0.08, 0)
        }, {
            Tags = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                BorderSizePixel = 0,
                Size = UDim2.new(0.9, 0, 1, 0),
                Position = UDim2.fromScale(0.05, 0)
            }, v60)
        }),
        Content = u2.createElement(u6, {
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            Size = UDim2.fromScale(0.9, 0.92),
            Position = UDim2.fromScale(0.5, 0.08),
            AnchorPoint = Vector2.new(0.5, 0),
            OffsetBinding = l__OffsetBinding__6,
            CanvasSize = v58 * 0.5,
            Content = v51
        })
    });
end;
return v13;