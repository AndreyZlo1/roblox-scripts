-- Services.InterfaceService.TabletInterface.VehicleSpawnerComponent.VehicleSpawnerGarageComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Roact", "network", "Enum");
local u5 = v1("Mathf");
local u6 = v1("StatsService");
local u7 = v1("PopupInterface");
local u8 = v1("GameShellProxyScroller");
local u9 = v1({ "GroundVehicle", "HelicopterVehicle" });
game:GetService("DataStoreService");
local l__UserInputService__1 = game:GetService("UserInputService");
local u10 = Font.fromName("Ubuntu", u4.FontWeight.Regular, u4.FontStyle.Normal);
local u11 = Font.fromName("Ubuntu", u4.FontWeight.Bold, u4.FontStyle.Normal);
local u12 = v1("VehicleSpawnerButtonComponent");
local v13 = u2.Component:extend("VehicleSpawnerGarage");
local u14 = v1("formatNumber");
function v13.init(u15, p16) --[[ Line: 26 ]]
    -- upvalues: u5 (copy), l__UserInputService__1 (copy), u4 (copy), u2 (copy), u9 (copy)
    u15.VehicleType = p16.VehicleType;
    u15.VehicleData = p16.VehicleData;
    u15.OffsetBinding = p16.OffsetBinding;
    u15.ChangePage = p16.ChangePage;
    u15.Notify = p16.Notify;
    u15.Loading = p16.Loading;
    u15.Viewports = {};
    local u17 = 0;
    local u18 = 3.9269908169872414;
    local u19 = 4.71238898038469;
    u15._connection = p16.Update:Connect(function(p20) --[[ Line: 39 ]]
        -- upvalues: u18 (ref), u17 (ref), u19 (ref), u5 (ref), u15 (copy)
        local v21 = p20 * 10;
        u18 = u18 - u17 * p20 * 2;
        u19 = u5.Lerp(u19, u18, v21);
        local v22 = u19;
        for _, v23 in u15.Viewports do
            local v24 = Vector3.new(0, -1, 0) + v23.Model.Hitbox.Position;
            local l__Camera__2 = v23.Camera;
            local l__new__3 = CFrame.new;
            local v25 = math.sin(v22) * v23.Zoom;
            local v26 = math.cos(v22) * v23.Zoom;
            l__Camera__2.CFrame = l__new__3(v24 + Vector3.new(v25, 2, v26), v24);
        end;
    end);
    u15._input = l__UserInputService__1.InputChanged:Connect(function(p27) --[[ Line: 52 ]]
        -- upvalues: u4 (ref), u18 (ref), u17 (ref)
        if p27.UserInputType == u4.UserInputType.MouseMovement then
            u18 = u18 - p27.Delta.X / 200;
        else
            if p27.UserInputType.Name:sub(1, 7) == "Gamepad" and p27.KeyCode == u4.KeyCode.Thumbstick1 then
                local l__X__4 = p27.Position.X;
                if math.abs(l__X__4) > 0.2 then
                    u17 = l__X__4;
                    return;
                end;
                u17 = 0;
            end;
        end;
    end);
    local v28 = u4.VehicleType[u15.VehicleType];
    for v29, v30 in u15.VehicleData do
        local v31 = u2.createRef();
        local v32 = Instance.new("Camera");
        v32.FieldOfView = 35;
        local v33 = u9[p16.VehicleType .. "Vehicle"].new(0, nil, {
            Type = v28,
            Name = v30[1],
            CFrame = CFrame.new(),
            Modifications = v30[2]
        });
        u15.Viewports[v29] = {
            Zoom = v33.VehicleModule.Zoom,
            Viewport = v31,
            Camera = v32,
            Model = v33
        };
    end;
    if #u15.VehicleData == 0 then
        u15.Notify("Empty Garage", "Would you like to purchase your first vehicle?", function() --[[ Line: 88 ]]
            -- upvalues: u15 (copy)
            u15.ChangePage("Purchase");
        end);
    end;
end;
function v13.willUnmount(p34) --[[ Line: 94 ]]
    for _, v35 in p34.Viewports do
        v35.Model:Destroy();
    end;
    p34._connection:Disconnect();
    p34._input:Disconnect();
end;
function v13.didMount(p36) --[[ Line: 102 ]]
    for _, v37 in p36.Viewports do
        v37.Model.Model.Parent = v37.Viewport:getValue();
    end;
end;
function v13.render(u38) --[[ Line: 108 ]]
    -- upvalues: u2 (copy), u4 (copy), u10 (copy), u12 (copy), u3 (copy), u14 (copy), u6 (copy), u7 (copy), u11 (copy), u8 (copy)
    local l__VehicleData__5 = u38.VehicleData;
    local l__OffsetBinding__6 = u38.OffsetBinding;
    local l__PopupOpen__7 = u38.props.PopupOpen;
    local v39 = #l__VehicleData__5;
    local l__Notification__8 = u38.props.Notification;
    local v40;
    if v39 > 0 then
        local v41 = math.max(4, v39) / 2;
        local v42 = math.ceil(v41);
        local v43 = 1 / v42;
        local v44 = {
            Grid = u2.createElement("UIGridLayout", {
                CellPadding = UDim2.fromScale(0.02, v43 * 0.1),
                CellSize = UDim2.fromScale(0.45, v43 * 0.9),
                FillDirection = u4.FillDirection.Horizontal,
                HorizontalAlignment = u4.HorizontalAlignment.Left,
                SortOrder = u4.SortOrder.LayoutOrder,
                StartCorner = u4.StartCorner.TopLeft,
                VerticalAlignment = u4.VerticalAlignment.Top
            })
        };
        for u45, u46 in l__VehicleData__5 do
            local v47 = u38.Viewports[u45];
            local l__Model__9 = v47.Model;
            local l__VehicleModule__10 = l__Model__9.VehicleModule;
            local v48 = u46[3];
            local l__Health__11 = l__VehicleModule__10.Armor[l__Model__9.VehicleArmor].Health;
            local v49 = v48 / l__Health__11;
            local l__Price__12 = l__Model__9.VehicleModule.Price;
            local v50 = math.ceil(l__Price__12 / 16 * (1 - v49));
            local v51 = math.ceil(l__Price__12 / 2 - v50);
            local v52 = v48 <= 0;
            local v53 = v49 == 1;
            local u54 = math.ceil(v50 * (1 - u38.props.RepairDiscount));
            local u55 = v51 + l__VehicleModule__10.Armor[l__Model__9.VehicleArmor].Price + l__VehicleModule__10.Camo[l__Model__9.VehicleCamo].Price;
            for v56, v57 in l__Model__9.VehicleTurrets or l__Model__9.VehicleTurret do
                u55 = u55 + l__VehicleModule__10.Turrets[v56][v57].Price;
            end;
            local l__createElement__13 = u2.createElement;
            local v58 = "Frame";
            local v59 = {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(39, 39, 39)
            };
            local v60 = {};
            local v61 = not v52;
            if v61 then
                v61 = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    TextWrapped = true,
                    ZIndex = 2,
                    Position = UDim2.new(0.07, 0, 0.12, 0),
                    Size = UDim2.new(0.8, 0, 0.1, 0),
                    FontFace = u10,
                    Text = math.floor(v49 * 100) .. "%",
                    TextColor3 = Color3.new(1, 0.305882, 0.305882):Lerp(Color3.new(0, 1, 0), v49),
                    TextXAlignment = u4.TextXAlignment.Left
                });
            end;
            v60.Health = v61;
            v60.Request = u2.createElement(u12, {
                Title = "Request",
                SoundKit = "VehicleTabletBase",
                Position = UDim2.fromScale(0.95, 0.1),
                Anchor = Vector2.new(1, 0),
                Color = Color3.fromRGB(125, 255, 116),
                Size = UDim2.fromScale(0.44, 0.25),
                Ignore = l__Notification__8 or l__PopupOpen__7,
                Disabled = v52,
                Offset = l__OffsetBinding__6,
                Callback = function() --[[ Name: Callback, Line 181 ]]
                    -- upvalues: u38 (copy), u3 (ref), u45 (copy)
                    u38.Loading:SetGoal(1);
                    u3:FireServer("ActivateInteract", "Spawn", u45);
                end
            });
            v60.Repair = u2.createElement(u12, {
                Title = "Repair",
                SoundKit = "VehicleTabletBase",
                Sub = u14(u54),
                Position = UDim2.fromScale(0.95, 0.5),
                Anchor = Vector2.new(1, 0.5),
                Color = Color3.fromRGB(102, 181, 255),
                Size = UDim2.fromScale(0.44, 0.25),
                Ignore = l__Notification__8 or l__PopupOpen__7,
                Disabled = v53,
                Offset = l__OffsetBinding__6,
                Callback = function() --[[ Name: Callback, Line 198 ]]
                    -- upvalues: u38 (copy), u6 (ref), u54 (ref), u14 (ref), u3 (ref), u45 (copy), u46 (copy), l__Health__11 (copy), u7 (ref), u4 (ref)
                    if u38.Loading:IsGoal(1) then
                    elseif u54 <= u6.Money then
                        u38.Notify("Repair Vehicle?", "Are you sure you would like to repair this vehicle for " .. u14(u54) .. "?", function() --[[ Line: 204 ]]
                            -- upvalues: u38 (ref), u3 (ref), u45 (ref), u46 (ref), l__Health__11 (ref)
                            u38.Loading:SetGoal(1);
                            if u3:InvokeServer("RepairVehicle", u38.VehicleType, u45) then
                                u46[3] = l__Health__11;
                            end;
                            u38.Loading:SetGoal(0);
                            u38.ChangePage("Garage");
                        end, "VehicleTabletRepair");
                    else
                        u7:Open("Insufficient Funds", nil, {
                            { "Close", function() --[[ Line: 217 ]]
                                    -- upvalues: u7 (ref)
                                    u7:Close();
                                end }
                        }, u4.PopupType.Shop);
                    end;
                end
            });
            v60.Sell = u2.createElement(u12, {
                Title = "Sell",
                SoundKit = "VehicleTabletBase",
                Sub = u14(u55),
                Position = UDim2.fromScale(0.95, 0.9),
                Anchor = Vector2.new(1, 1),
                Color = Color3.fromRGB(255, 124, 126),
                Size = UDim2.fromScale(0.44, 0.25),
                Ignore = l__Notification__8 or l__PopupOpen__7,
                Offset = l__OffsetBinding__6,
                Callback = function() --[[ Name: Callback, Line 237 ]]
                    -- upvalues: u38 (copy), u14 (ref), u55 (ref), u3 (ref), u45 (copy), l__VehicleData__5 (copy)
                    if u38.Loading:IsGoal(1) then
                    else
                        u38.Notify("Sell Vehicle?", "Are you sure you would like to sell this vehicle for " .. u14(u55) .. "?", function() --[[ Line: 242 ]]
                            -- upvalues: u38 (ref), u3 (ref), u45 (ref), l__VehicleData__5 (ref)
                            u38.Loading:SetGoal(1);
                            if u3:InvokeServer("SellVehicle", u38.VehicleType, u45) then
                                table.remove(l__VehicleData__5, u45);
                            end;
                            u38.Loading:SetGoal(0);
                            u38.ChangePage("Garage");
                        end, "VehicleTabletSell");
                    end;
                end
            });
            v60.Edit = u2.createElement(u12, {
                Title = "Edit",
                SoundKit = "VehicleTabletBase",
                Position = UDim2.fromScale(0.05, 0.9),
                Anchor = Vector2.new(0, 1),
                Color = Color3.fromRGB(255, 201, 107),
                Size = UDim2.fromScale(0.44, 0.25),
                Ignore = l__Notification__8 or l__PopupOpen__7,
                Offset = l__OffsetBinding__6,
                Callback = function() --[[ Name: Callback, Line 265 ]]
                    -- upvalues: u38 (copy), u45 (copy)
                    u38.ChangePage("Edit", {
                        VehicleIndex = u45
                    });
                end
            });
            local l__createElement__14 = u2.createElement;
            local v62 = "ViewportFrame";
            local v63 = {
                LightDirection = Vector3.new(0.5, -1, 0.5),
                BackgroundTransparency = 0,
                BorderSizePixel = 0,
                Ambient = Color3.new(1, 1, 1),
                LightColor = Color3.new(1, 1, 1),
                Position = UDim2.fromScale(0.05, 0.1),
                Size = UDim2.fromScale(0.44, 0.6),
                BackgroundColor3 = Color3.fromRGB(61, 61, 61),
                ImageColor3 = v52 and Color3.fromRGB(145, 145, 145) or Color3.new(1, 1, 1),
                CurrentCamera = v47.Camera
            };
            local v64 = {};
            if v52 then
                v52 = u2.createElement("TextLabel", {
                    BackgroundTransparency = 0,
                    BorderSizePixel = 0,
                    Text = "[ DESTROYED ]",
                    TextScaled = true,
                    TextWrapped = true,
                    BackgroundColor3 = Color3.new(0, 0, 0),
                    Position = UDim2.fromScale(0.5, 0.5),
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Size = UDim2.fromScale(0.8, 0.15),
                    FontFace = u11,
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u4.TextXAlignment.Center
                });
            end;
            v64[1] = v52;
            v64.Gradient = u2.createElement("UIGradient", {
                Rotation = 90,
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0), NumberSequenceKeypoint.new(1, 1) })
            });
            v64[2] = u2.createElement("WorldModel", {
    [u2.Ref] = v47.Viewport
});
            v60.Preview = l__createElement__14(v62, v63, v64);
            v44[u45] = l__createElement__13(v58, v59, v60);
        end;
        v40 = u2.createElement(u8, {
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            Size = UDim2.fromScale(0.9, 0.92),
            Position = UDim2.fromScale(0.5, 0.08),
            AnchorPoint = Vector2.new(0.5, 0),
            OffsetBinding = l__OffsetBinding__6,
            CanvasSize = v42 * 0.5,
            Content = v44
        });
    else
        v40 = nil;
    end;
    return u2.createFragment({
        Banner = u2.createElement("Frame", {
            BackgroundTransparency = 0,
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.fromRGB(27, 27, 27),
            Size = UDim2.new(1, 0, 0.08, 0)
        }, {
            Header = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                TextWrapped = true,
                AnchorPoint = Vector2.new(0, 0.5),
                Position = UDim2.new(0.1, 0, 0.5, 0),
                Size = UDim2.new(0.8, 0, 0.5, 0),
                FontFace = u11,
                Text = v39 .. "/" .. u38.props.MaxSlots .. " Slots Used",
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u4.TextXAlignment.Right
            })
        }),
        Content = v40
    });
end;
return v13;