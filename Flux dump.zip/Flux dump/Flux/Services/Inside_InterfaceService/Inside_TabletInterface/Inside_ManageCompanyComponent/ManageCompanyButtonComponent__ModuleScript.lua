-- Services.InterfaceService.TabletInterface.ManageCompanyComponent.ManageCompanyButtonComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _, u3 = shared.import("require", "Roact", "network", "Enum");
local u4 = v1("GameShellProxyButton");
local u5 = Font.fromId(12188570269, u3.FontWeight.Bold, u3.FontStyle.Normal);
Font.fromId(12188570269, u3.FontWeight.Regular, u3.FontStyle.Normal);
local v6 = u2.Component:extend("ManageCompanyOverview");
function v6.init(p7, _) --[[ Line: 10 ]]
    p7:setState({
        Hovering = false
    });
end;
function v6.render(u8) --[[ Line: 16 ]]
    -- upvalues: u2 (copy), u4 (copy), u5 (copy), u3 (copy)
    local l__props__1 = u8.props;
    local l__MiniText__2 = l__props__1.MiniText;
    local l__Hovering__3 = u8.state.Hovering;
    local l__Selected__4 = l__props__1.Selected;
    local l__SubText__5 = l__props__1.SubText;
    local v9 = l__Hovering__3 and Color3.fromRGB(183, 211, 255) or (l__Selected__4 and Color3.fromRGB(0, 9, 42) or Color3.fromRGB(57, 75, 141));
    local v10 = l__SubText__5 and true or l__props__1.Ignore;
    local l__createElement__6 = u2.createElement;
    local v11 = u4;
    local v12 = {
        BorderSizePixel = 0,
        Offset = l__props__1.Offset,
        Ignore = v10,
        LayoutOrder = l__props__1.Layout,
        SoundKit = l__props__1.SoundKit or "MissionTab",
        Size = l__props__1.Size,
        Position = l__props__1.Position,
        AnchorPoint = l__props__1.AnchorPoint,
        BackgroundTransparency = v10 and 0.5 or 0,
        BackgroundColor3 = (l__Hovering__3 or l__Selected__4) and Color3.fromRGB(57, 75, 141) or Color3.fromRGB(0, 9, 42),
        MouseEnter = function() --[[ Name: MouseEnter, Line 41 ]]
            -- upvalues: u8 (copy)
            u8:setState({
                Hovering = true
            });
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 46 ]]
            -- upvalues: u8 (copy)
            u8:setState({
                Hovering = false
            });
        end,
        MouseUp = function() --[[ Name: MouseUp, Line 51 ]]
            -- upvalues: l__props__1 (copy)
            l__props__1.Callback();
        end
    };
    local v13 = {};
    local v14 = u2.createElement("TextLabel", {
        TextScaled = true,
        BackgroundTransparency = 1,
        FontFace = u5,
        Size = UDim2.new(1, 0, l__MiniText__2 and 0.6 or 0.8, 0),
        TextColor3 = v9,
        TextTransparency = v10 and 0.5 or 0,
        Text = l__props__1.Text,
        Position = UDim2.new(0, 0, l__MiniText__2 and 0.2 or 0.1, 0),
        TextXAlignment = u3.TextXAlignment.Center
    });
    local v15 = u2.createElement("UICorner", {
        CornerRadius = UDim.new(0.2, 0)
    });
    if l__SubText__5 then
        l__SubText__5 = u2.createElement("TextLabel", {
            TextScaled = true,
            BackgroundTransparency = 1,
            FontFace = u5,
            Size = UDim2.new(1, 0, 0.8, 0),
            TextColor3 = v9,
            Text = l__SubText__5,
            Position = UDim2.new(1.1, 0, 0.1, 0),
            TextXAlignment = u3.TextXAlignment.Left
        });
    end;
    v13[1], v13[2], v13[3] = v14, v15, l__SubText__5;
    return l__createElement__6(v11, v12, v13);
end;
return v6;