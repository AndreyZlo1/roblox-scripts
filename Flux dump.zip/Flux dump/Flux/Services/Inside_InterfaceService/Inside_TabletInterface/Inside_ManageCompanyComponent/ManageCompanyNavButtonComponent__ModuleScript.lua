-- Services.InterfaceService.TabletInterface.ManageCompanyComponent.ManageCompanyNavButtonComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _, u3 = shared.import("require", "Roact", "network", "Enum");
local u4 = v1("GameShellProxyButton");
local u5 = Font.fromId(12188570269, u3.FontWeight.Bold, u3.FontStyle.Normal);
Font.fromId(12188570269, u3.FontWeight.Regular, u3.FontStyle.Normal);
local v6 = u2.Component:extend("ManageCompanyOverview");
function v6.init(p7, _) --[[ Line: 10 ]]
    p7:setState({
        Hovering = false
    });
end;
function v6.render(u8) --[[ Line: 16 ]]
    -- upvalues: u2 (copy), u4 (copy), u5 (copy), u3 (copy)
    local l__props__1 = u8.props;
    local l__Hovering__2 = u8.state.Hovering;
    local l__Selected__3 = l__props__1.Selected;
    local v9 = l__Hovering__2 and Color3.fromRGB(183, 211, 255) or (l__Selected__3 and Color3.fromRGB(0, 9, 42) or Color3.fromRGB(57, 75, 141));
    return u2.createElement(u4, {
        BorderSizePixel = 0,
        Offset = l__props__1.Offset,
        Ignore = l__props__1.Ignore,
        LayoutOrder = l__props__1.Layout,
        Size = l__props__1.Size,
        Position = l__props__1.Position,
        AnchorPoint = l__props__1.AnchorPoint,
        BackgroundColor3 = (l__Hovering__2 or l__Selected__3) and Color3.fromRGB(57, 75, 141) or Color3.fromRGB(0, 9, 42),
        MouseEnter = function() --[[ Name: MouseEnter, Line 32 ]]
            -- upvalues: u8 (copy)
            u8:setState({
                Hovering = true
            });
        end,
        MouseLeave = function() --[[ Name: MouseLeave, Line 37 ]]
            -- upvalues: u8 (copy)
            u8:setState({
                Hovering = false
            });
        end,
        MouseUp = function() --[[ Name: MouseUp, Line 42 ]]
            -- upvalues: l__props__1 (copy)
            l__props__1.Callback();
        end
    }, { u2.createElement("TextLabel", {
            TextScaled = true,
            BackgroundTransparency = 1,
            FontFace = u5,
            Size = UDim2.new(0.8, 0, 0.4, 0),
            TextColor3 = v9,
            Text = l__props__1.Text,
            Position = UDim2.new(0.3, 0, 0.3, 0),
            TextXAlignment = u3.TextXAlignment.Left
        }), u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(0.4, 0.4),
            Position = UDim2.fromScale(0.15, 0.3),
            SizeConstraint = u3.SizeConstraint.RelativeYY,
            ImageColor3 = v9,
            Image = "rbxassetid://" .. l__props__1.Image
        }) });
end;
return v6;