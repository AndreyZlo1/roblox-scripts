-- Services.InterfaceService.TabletInterface.ManageCompanyComponent.ManageCompanyOverviewComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Roact", "network", "Enum");
local u5 = v1("RoactTween");
local u6 = v1("formatNumber");
local u7 = v1("CompanyConfig");
local u8 = v1("ManageCompanyButtonComponent");
local u9 = v1("GameShellProxyScroller");
local u10 = Font.fromId(12188570269, u4.FontWeight.Bold, u4.FontStyle.Normal);
local u11 = Font.fromId(12188570269, u4.FontWeight.Regular, u4.FontStyle.Normal);
local u12 = {
    Material = Color3.fromRGB(255, 170, 0),
    Metal = Color3.fromRGB(0, 170, 255),
    Fuel = Color3.fromRGB(255, 80, 80),
    Equipment = Color3.fromRGB(127, 208, 98)
};
local v13 = u2.Component:extend("ManageCompanyOverview");
local function u18(p14) --[[ Line: 23 ]]
    local v15 = p14 % 60;
    local v16 = math.floor(p14 / 60) % 60;
    local v17 = math.floor(p14 / 3600) % 24;
    if p14 <= 0 then
        v17 = 0;
        v16 = 0;
        v15 = 0;
    end;
    return string.format("%02i", v17) .. ":" .. string.format("%02i", v16) .. ":" .. string.format("%02i", v15);
end;
function v13.init(u19, p20) --[[ Line: 36 ]]
    -- upvalues: u5 (copy), u2 (copy)
    u19.Company = p20.Company;
    u19.Open = u5.new(0);
    u19.Open:SetGoal(1);
    local v21, v22 = u2.createBinding(tick());
    u19.updateBinding = v21;
    u19.updateUpdate = v22;
    u19.Connection = p20.Update:Connect(function(_) --[[ Line: 43 ]]
        -- upvalues: u19 (copy)
        u19.updateUpdate(os.time());
    end);
end;
function v13.willUnmount(p23) --[[ Line: 48 ]]
    p23.Connection:Disconnect();
end;
function v13.render(p24) --[[ Line: 52 ]]
    -- upvalues: u2 (copy), u4 (copy), u11 (copy), u6 (copy), u18 (copy), u9 (copy), u10 (copy), u12 (copy), u7 (copy), u8 (copy), u3 (copy)
    local l__props__1 = p24.props;
    local l__Company__2 = p24.Company;
    local v25;
    if #l__Company__2.Deliveries > 0 then
        local v26 = {};
        local v27 = math.max(9, #l__Company__2.Deliveries);
        local v28 = 1 / v27;
        v26._Grid = u2.createElement("UIGridLayout", {
            CellPadding = UDim2.fromScale(0, 0),
            CellSize = UDim2.fromScale(1, v28),
            FillDirection = u4.FillDirection.Vertical,
            HorizontalAlignment = u4.HorizontalAlignment.Left,
            SortOrder = u4.SortOrder.LayoutOrder,
            StartCorner = u4.StartCorner.TopLeft,
            VerticalAlignment = u4.VerticalAlignment.Top
        });
        for v29, u30 in l__Company__2.Deliveries do
            v26[v29] = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                LayoutOrder = v29
            }, { u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u11,
                    Size = UDim2.fromScale(1, 0.8),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Text = l__Company__2:GetDestinationName(u30.Destination).Name,
                    Position = UDim2.fromScale(0, 0.2),
                    TextXAlignment = u4.TextXAlignment.Left
                }), u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u11,
                    Size = UDim2.fromScale(0.18, 0.8),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Text = u6(u30.Value),
                    Position = UDim2.fromScale(0.39, 0.2),
                    TextXAlignment = u4.TextXAlignment.Center
                }), u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u11,
                    Size = UDim2.fromScale(0.33, 0.8),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Text = p24.updateBinding:map(function(p31) --[[ Line: 101 ]]
                        -- upvalues: u18 (ref), u30 (copy)
                        return u18(u30.End - p31);
                    end),
                    Position = UDim2.fromScale(0.67, 0.2),
                    TextXAlignment = u4.TextXAlignment.Center
                }) });
        end;
        v25 = u2.createElement(u9, {
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            Size = UDim2.fromScale(0.9, 0.7),
            Position = UDim2.new(0.05, 0, 0.25, 1),
            OffsetBinding = l__props__1.OffsetBinding,
            CanvasSize = v27 / 9,
            Content = v26
        });
    else
        v25 = u2.createElement("TextLabel", {
            TextScaled = true,
            Text = "No active deliveries",
            BackgroundTransparency = 1,
            FontFace = u10,
            Size = UDim2.new(1, 0, 0.07, 0),
            TextColor3 = Color3.fromRGB(183, 211, 255),
            Position = UDim2.new(0, 0, 0.5, 0),
            AnchorPoint = Vector2.new(0, 0.5),
            TextXAlignment = u4.TextXAlignment.Center
        });
    end;
    local v32 = 0;
    for _, v33 in l__Company__2.Employees do
        if v33.Assigned == "Logistics" then
            v32 = v32 + l__Company__2:GetAddedCapacity(v33);
        end;
    end;
    local v34 = {};
    local v35 = 0;
    local v36 = {};
    local v37 = 0;
    for v38, v39 in l__Company__2.Resources do
        local v40 = math.max(v32, 1);
        local v41 = u12[v38];
        local v42 = math.ceil(v39 / v40 * 360);
        v35 = v35 + v39;
        v36[v38] = math.ceil(v39 / v40 * 100) .. "% (" .. v39 .. ")";
        for u43 = v37 + 1, v37 + v42 do
            if u43 % 3 == 1 then
                v34[u43] = u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Position = UDim2.fromScale(0.5, 0.5),
                    Size = UDim2.fromScale(0.05, 0.05),
                    Rotation = p24.Open:Map(function(p44) --[[ Line: 162 ]]
                        -- upvalues: u43 (copy)
                        return p44 * u43;
                    end),
                    ZIndex = u43
                }, { u2.createElement("Frame", {
                        BorderSizePixel = 0,
                        Position = UDim2.fromScale(0, 8.5),
                        Size = UDim2.fromScale(1, 4),
                        BackgroundColor3 = v41
                    }) });
            end;
        end;
        v37 = v37 + v42;
    end;
    return u2.createFragment({
        u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.fromRGB(0, 7, 34),
            Position = UDim2.fromScale(0, 0.12),
            Size = UDim2.fromScale(0.49, 0.485)
        }, {
            u2.createElement("UICorner", {
                CornerRadius = UDim.new(0.03, 0)
            }),
            u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(183, 211, 255),
                Position = UDim2.fromScale(0.05, 0.15),
                Size = UDim2.new(0.9, 0, 0, 1)
            }, { u2.createElement("UIGradient", {
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
                }) }),
            u2.createElement("TextLabel", {
                TextScaled = true,
                Text = "Resources",
                BackgroundTransparency = 1,
                FontFace = u10,
                Size = UDim2.new(0.98, 0, 0.07, 0),
                TextColor3 = Color3.fromRGB(183, 211, 255),
                Position = UDim2.new(0.05, 0, 0.05, 0),
                TextXAlignment = u4.TextXAlignment.Left
            }),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0.5, 0),
                Size = UDim2.fromScale(0.5, 0.5),
                Position = UDim2.fromScale(0.65, 0.3),
                SizeConstraint = u4.SizeConstraint.RelativeYY
            }, { u2.createElement("UIStroke", {
                    Thickness = 1,
                    Color = Color3.fromRGB(183, 211, 255)
                }), u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.5, 0)
                }), u2.createFragment(v34) }),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(0.4, 0.1),
                Position = UDim2.fromScale(0.05, 0.2)
            }, { u2.createElement("TextLabel", {
                    TextScaled = true,
                    Text = "Construction Materials",
                    BackgroundTransparency = 1,
                    FontFace = u11,
                    Size = UDim2.new(1, 0, 0.5, 0),
                    TextColor3 = u12.Material,
                    Position = UDim2.new(0, 0, 0, 0),
                    TextXAlignment = u4.TextXAlignment.Left
                }), u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u11,
                    Size = UDim2.new(1, 0, 0.5, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Text = v36.Material,
                    Position = UDim2.new(0, 0, 0.5, 0),
                    TextXAlignment = u4.TextXAlignment.Left
                }) }),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(0.4, 0.1),
                Position = UDim2.fromScale(0.05, 0.35)
            }, { u2.createElement("TextLabel", {
                    TextScaled = true,
                    Text = "Precious Metals",
                    BackgroundTransparency = 1,
                    FontFace = u11,
                    Size = UDim2.new(1, 0, 0.5, 0),
                    TextColor3 = u12.Metal,
                    Position = UDim2.new(0, 0, 0, 0),
                    TextXAlignment = u4.TextXAlignment.Left
                }), u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u11,
                    Size = UDim2.new(1, 0, 0.5, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Text = v36.Metal,
                    Position = UDim2.new(0, 0, 0.5, 0),
                    TextXAlignment = u4.TextXAlignment.Left
                }) }),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(0.4, 0.1),
                Position = UDim2.fromScale(0.05, 0.5)
            }, { u2.createElement("TextLabel", {
                    TextScaled = true,
                    Text = "Fuel",
                    BackgroundTransparency = 1,
                    FontFace = u11,
                    Size = UDim2.new(1, 0, 0.5, 0),
                    TextColor3 = u12.Fuel,
                    Position = UDim2.new(0, 0, 0, 0),
                    TextXAlignment = u4.TextXAlignment.Left
                }), u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u11,
                    Size = UDim2.new(1, 0, 0.5, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Text = v36.Fuel,
                    Position = UDim2.new(0, 0, 0.5, 0),
                    TextXAlignment = u4.TextXAlignment.Left
                }) }),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(0.4, 0.1),
                Position = UDim2.fromScale(0.05, 0.65)
            }, { u2.createElement("TextLabel", {
                    TextScaled = true,
                    Text = "Equipment",
                    BackgroundTransparency = 1,
                    FontFace = u11,
                    Size = UDim2.new(1, 0, 0.5, 0),
                    TextColor3 = u12.Equipment,
                    Position = UDim2.new(0, 0, 0, 0),
                    TextXAlignment = u4.TextXAlignment.Left
                }), u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u11,
                    Size = UDim2.new(1, 0, 0.5, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Text = v36.Equipment,
                    Position = UDim2.new(0, 0, 0.65, 0),
                    TextXAlignment = u4.TextXAlignment.Left
                }) }),
            u2.createElement("Frame", {
                BackgroundTransparency = 1,
                Size = UDim2.fromScale(0.4, 0.1),
                Position = UDim2.fromScale(0.05, 0.8)
            }, { u2.createElement("TextLabel", {
                    TextScaled = true,
                    Text = "Free space",
                    BackgroundTransparency = 1,
                    FontFace = u11,
                    Size = UDim2.new(1, 0, 0.5, 0),
                    TextColor3 = Color3.fromRGB(156, 156, 156),
                    Position = UDim2.new(0, 0, 0, 0),
                    TextXAlignment = u4.TextXAlignment.Left
                }), u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u11,
                    Size = UDim2.new(1, 0, 0.5, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Text = math.ceil((v32 - v35) / v32 * 100) .. "% (" .. v32 - v35 .. ")",
                    Position = UDim2.new(0, 0, 0.65, 0),
                    TextXAlignment = u4.TextXAlignment.Left
                }) })
        }),
        u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.fromRGB(0, 7, 34),
            AnchorPoint = Vector2.new(1, 0),
            Position = UDim2.fromScale(1, 0.12),
            Size = UDim2.fromScale(0.49, 0.485)
        }, {
            u2.createElement("UICorner", {
                CornerRadius = UDim.new(0.03, 0)
            }),
            u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(183, 211, 255),
                Position = UDim2.fromScale(0.05, 0.15),
                Size = UDim2.new(0.9, 0, 0, 1)
            }, { u2.createElement("UIGradient", {
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
                }) }),
            u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(183, 211, 255),
                Position = UDim2.fromScale(0.05, 0.25),
                Size = UDim2.new(0.9, 0, 0, 1)
            }, { u2.createElement("UIGradient", {
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
                }) }),
            u2.createElement("TextLabel", {
                TextScaled = true,
                Text = "Destination",
                BackgroundTransparency = 1,
                FontFace = u10,
                Size = UDim2.new(1, 0, 0.06, 0),
                TextColor3 = Color3.fromRGB(183, 211, 255),
                Position = UDim2.new(0.05, 0, 0.175, 0),
                TextXAlignment = u4.TextXAlignment.Left
            }),
            u2.createElement("TextLabel", {
                TextScaled = true,
                Text = "Value",
                BackgroundTransparency = 1,
                FontFace = u10,
                Size = UDim2.new(0.2, 0, 0.06, 0),
                TextColor3 = Color3.fromRGB(183, 211, 255),
                Position = UDim2.new(0.38, 0, 0.175, 0),
                TextXAlignment = u4.TextXAlignment.Center
            }),
            u2.createElement("TextLabel", {
                TextScaled = true,
                Text = "Time To Delivery",
                BackgroundTransparency = 1,
                FontFace = u10,
                Size = UDim2.new(0.3, 0, 0.06, 0),
                TextColor3 = Color3.fromRGB(183, 211, 255),
                Position = UDim2.new(0.65, 0, 0.175, 0),
                TextXAlignment = u4.TextXAlignment.Center
            }),
            u2.createElement("TextLabel", {
                TextScaled = true,
                Text = "Deliveries",
                BackgroundTransparency = 1,
                FontFace = u10,
                Size = UDim2.new(0.98, 0, 0.07, 0),
                TextColor3 = Color3.fromRGB(183, 211, 255),
                Position = UDim2.new(0.05, 0, 0.05, 0),
                TextXAlignment = u4.TextXAlignment.Left
            }),
            v25
        }),
        u2.createElement("Frame", {
            BackgroundColor3 = Color3.fromRGB(165, 128, 0),
            Size = UDim2.fromScale(1, 0.08)
        }, { u2.createElement("UICorner", {
                CornerRadius = UDim.new(0.06, 0)
            }), u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "You must travel to your HQ to make changes to personnel and departments.",
                TextScaled = true,
                AnchorPoint = Vector2.new(0, 0.5),
                FontFace = Font.new("rbxassetid://12188570269", u4.FontWeight.Bold, u4.FontStyle.Normal),
                Position = UDim2.fromScale(0.05, 0.5),
                Size = UDim2.fromScale(0.9, 0.55),
                TextColor3 = Color3.new()
            }) }),
        u2.createElement("Frame", {
            BackgroundColor3 = Color3.fromRGB(0, 7, 34),
            Position = UDim2.fromScale(0, 0.645),
            Size = UDim2.fromScale(1, 0.355)
        }, {
            Corner = u2.createElement("UICorner", {
                CornerRadius = UDim.new(0.03, 0)
            }),
            LineTop = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                RichText = true,
                Text = "Travelling to HQ will put you in a <b>different server</b>.",
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12188570269"),
                Position = UDim2.fromScale(0.35, 0.275),
                Size = UDim2.fromScale(0.6, 0.125),
                TextColor3 = Color3.fromRGB(183, 211, 255),
                TextXAlignment = u4.TextXAlignment.Left
            }),
            Preview = u2.createElement("ImageLabel", {
                Image = u7.Upgradeables[1].Levels[l__Company__2.Levels.Main].Image,
                Position = UDim2.fromScale(0.025, 0.1),
                ScaleType = u4.ScaleType.Crop,
                Size = UDim2.fromScale(0.3, 0.8)
            }, {
                Corner = u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.1, 0)
                })
            }),
            LineBot = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "You can return to this server at any time.",
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12188570269"),
                Position = UDim2.fromScale(0.35, 0.4),
                Size = UDim2.fromScale(0.6, 0.125),
                TextColor3 = Color3.fromRGB(183, 211, 255),
                TextXAlignment = u4.TextXAlignment.Left
            }),
            Title = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "Travel to HQ?",
                TextScaled = true,
                FontFace = Font.new("rbxassetid://12188570269", u4.FontWeight.Bold, u4.FontStyle.Normal),
                Position = UDim2.fromScale(0.35, 0.1),
                Size = UDim2.fromScale(0.6, 0.15),
                TextColor3 = Color3.fromRGB(183, 211, 255),
                TextXAlignment = u4.TextXAlignment.Left
            }),
            u2.createElement(u8, {
                Text = "Travel to HQ",
                Offset = l__props__1.OffsetBinding,
                Position = UDim2.fromScale(0.35, 0.75),
                Size = UDim2.fromScale(0.3, 0.15),
                Ignore = l__props__1.Ignore,
                Callback = function() --[[ Name: Callback, Line 517 ]]
                    -- upvalues: l__props__1 (copy), u3 (ref)
                    l__props__1.Notify("Are you sure you want to travel?", "This will put you in a different server.", {
                        { "Travel", function() --[[ Line: 519 ]]
                                -- upvalues: u3 (ref)
                                u3:FireServer("ActivateInteract", "Travel");
                            end }
                    });
                end
            })
        })
    });
end;
return v13;