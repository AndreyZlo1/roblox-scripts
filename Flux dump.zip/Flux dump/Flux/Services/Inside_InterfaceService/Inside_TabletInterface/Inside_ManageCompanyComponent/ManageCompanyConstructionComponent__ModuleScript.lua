-- Services.InterfaceService.TabletInterface.ManageCompanyComponent.ManageCompanyConstructionComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Roact", "network", "Enum");
local u5 = v1("StatsService");
local u6 = v1("formatNumber");
local u7 = v1("ManageCompanyButtonComponent");
local u8 = v1("GameShellProxyScroller");
local u9 = Font.fromId(12188570269, u4.FontWeight.Bold, u4.FontStyle.Normal);
local u10 = Font.fromId(12188570269, u4.FontWeight.Regular, u4.FontStyle.Normal);
local v11 = u2.Component:extend("ManageCompanyMechanics");
function v11.init(p12, _) --[[ Line: 17 ]]
    p12:setState({
        Upgrade = 0
    });
end;
function v11.render(u13) --[[ Line: 23 ]]
    -- upvalues: u6 (copy), u2 (copy), u9 (copy), u4 (copy), u10 (copy), u7 (copy), u5 (copy), u3 (copy), u8 (copy)
    local l__props__1 = u13.props;
    local l__Company__2 = l__props__1.Company;
    local u14 = l__Company__2:GetUpgradeables();
    local l__Upgrade__3 = u13.state.Upgrade;
    local v15;
    if l__Upgrade__3 > 0 then
        local u16 = u14[l__Upgrade__3];
        local v17 = l__Company__2.Levels[u16.ID];
        local v18 = u16.Levels[v17];
        local u19 = u16.Levels[v17 + 1];
        local v20 = tostring(u19.Resources.Material);
        local v21 = tostring(u19.Resources.Metal);
        local v22 = tostring(u19.Resources.Fuel);
        local v23 = tostring(u19.Resources.Equipment);
        local v24 = u6(u19.Cost);
        v15 = { u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(0, 7, 34),
                Size = UDim2.fromScale(0.49, 0.76),
                Position = UDim2.fromScale(0, 0),
                AnchorPoint = Vector2.new(0, 0)
            }, {
                u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.01, 0)
                }),
                u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.fromScale(0.05, 0.097),
                    Size = UDim2.new(0.9, 0, 0, 1)
                }, { u2.createElement("UIGradient", {
                        Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
                    }) }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    Text = "Current",
                    BackgroundTransparency = 1,
                    FontFace = u9,
                    Size = UDim2.new(0.98, 0, 0.045, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.new(0.05, 0, 0.03, 0),
                    TextXAlignment = u4.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    TextScaled = false,
                    RichText = true,
                    BackgroundTransparency = 1,
                    TextWrapped = true,
                    FontFace = u10,
                    Size = UDim2.new(0.9, 0, 0.345, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Text = v18.Description,
                    Position = UDim2.new(0.05, 0, 0.6, 0),
                    TextSize = l__props__1.SizeBinding:map(function(p25) --[[ Line: 85 ]]
                        return p25.Y / 30;
                    end),
                    TextXAlignment = u4.TextXAlignment.Left,
                    TextYAlignment = u4.TextYAlignment.Top
                }),
                u2.createElement("ImageLabel", {
                    BorderSizePixel = 0,
                    Position = UDim2.fromScale(0.05, 0.15),
                    Size = UDim2.fromScale(0.9, 0.4),
                    Image = v18.Image
                })
            }), u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(0, 7, 34),
                Size = UDim2.fromScale(0.49, 0.76),
                Position = UDim2.fromScale(1, 0),
                AnchorPoint = Vector2.new(1, 0)
            }, {
                u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.01, 0)
                }),
                u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.fromScale(0.05, 0.097),
                    Size = UDim2.new(0.9, 0, 0, 1)
                }, { u2.createElement("UIGradient", {
                        Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
                    }) }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    Text = "Upgraded",
                    BackgroundTransparency = 1,
                    FontFace = u9,
                    Size = UDim2.new(0.98, 0, 0.045, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.new(0.05, 0, 0.03, 0),
                    TextXAlignment = u4.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    TextScaled = false,
                    RichText = true,
                    BackgroundTransparency = 1,
                    TextWrapped = true,
                    FontFace = u10,
                    Size = UDim2.new(0.9, 0, 0.345, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Text = u19.Description,
                    Position = UDim2.new(0.05, 0, 0.6, 0),
                    TextSize = l__props__1.SizeBinding:map(function(p26) --[[ Line: 141 ]]
                        return p26.Y / 30;
                    end),
                    TextXAlignment = u4.TextXAlignment.Left,
                    TextYAlignment = u4.TextYAlignment.Top
                }),
                u2.createElement("ImageLabel", {
                    BorderSizePixel = 0,
                    Position = UDim2.fromScale(0.05, 0.15),
                    Size = UDim2.fromScale(0.9, 0.4),
                    Image = u19.Image
                })
            }), u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(0, 7, 34),
                Size = UDim2.fromScale(1, 0.2),
                Position = UDim2.fromScale(0, 1),
                AnchorPoint = Vector2.new(0, 1)
            }, {
                u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.03, 0)
                }),
                u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.fromScale(0.025, 0.37),
                    Size = UDim2.new(0.95, 0, 0, 1)
                }, { u2.createElement("UIGradient", {
                        Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
                    }) }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    Text = "Cost",
                    BackgroundTransparency = 1,
                    FontFace = u9,
                    Size = UDim2.new(0.98, 0, 0.17, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.new(0.025, 0, 0.125, 0),
                    TextXAlignment = u4.TextXAlignment.Left
                }),
                u2.createElement(u7, {
                    Text = "Cancel",
                    Offset = l__props__1.OffsetBinding,
                    Size = UDim2.fromScale(0.2, 0.25),
                    Position = UDim2.fromScale(0.98, 0.7),
                    AnchorPoint = Vector2.new(1, 0.5),
                    Ignore = l__props__1.Ignore,
                    Callback = function() --[[ Name: Callback, Line 194 ]]
                        -- upvalues: u13 (copy)
                        u13:setState({
                            Upgrade = 0
                        });
                    end
                }),
                u2.createElement(u7, {
                    Text = "Purchase",
                    Offset = l__props__1.OffsetBinding,
                    Size = UDim2.fromScale(0.2, 0.25),
                    Position = UDim2.fromScale(0.76, 0.7),
                    AnchorPoint = Vector2.new(1, 0.5),
                    Ignore = l__props__1.Ignore,
                    Callback = function() --[[ Name: Callback, Line 207 ]]
                        -- upvalues: u19 (copy), l__Company__2 (copy), u14 (copy), l__props__1 (copy), u16 (copy), u5 (ref), u6 (ref), u3 (ref), l__Upgrade__3 (copy), u13 (copy)
                        if u19.Requires then
                            for v27, v28 in u19.Requires do
                                if l__Company__2.Levels[v27] < v28 then
                                    local v29 = v27;
                                    for _, v30 in u14 do
                                        if v30.ID == v27 then
                                            v29 = v30.Name;
                                            break;
                                        end;
                                    end;
                                    l__props__1.Notify("Prerequisites not met", v29 .. " must be minimum level " .. v28 .. " to upgrade " .. u16.Name, {});
                                    return;
                                end;
                            end;
                        end;
                        if u5.Money < u19.Cost then
                            l__props__1.Notify("Not enough money", "You need " .. u6(u19.Cost - u5.Money) .. " more to upgrade", {});
                        elseif l__Company__2.Resources.Material < u19.Resources.Material then
                            l__props__1.Notify("Not enough resources", "You need more Construction Material to upgrade", {});
                        elseif l__Company__2.Resources.Metal < u19.Resources.Metal then
                            l__props__1.Notify("Not enough resources", "You need more Metal to upgrade", {});
                        elseif l__Company__2.Resources.Fuel < u19.Resources.Fuel then
                            l__props__1.Notify("Not enough resources", "You need more Fuel to upgrade", {});
                        elseif l__Company__2.Resources.Equipment < u19.Resources.Equipment then
                            l__props__1.Notify("Not enough resources", "You need more Equipment to upgrade", {});
                        else
                            l__props__1.Notify("Confirm upgrade", "Are you sure you want to upgrade?", {
                                { "Upgrade", function() --[[ Line: 237 ]]
                                        -- upvalues: u3 (ref), l__Upgrade__3 (ref), l__Company__2 (ref), u19 (ref), u16 (ref), u13 (ref)
                                        u3:FireServer("ActivateInteract", "Upgrade", l__Upgrade__3);
                                        local l__Resources__4 = l__Company__2.Resources;
                                        l__Resources__4.Material = l__Resources__4.Material - u19.Resources.Material;
                                        local l__Resources__5 = l__Company__2.Resources;
                                        l__Resources__5.Metal = l__Resources__5.Metal - u19.Resources.Metal;
                                        local l__Resources__6 = l__Company__2.Resources;
                                        l__Resources__6.Fuel = l__Resources__6.Fuel - u19.Resources.Fuel;
                                        local l__Resources__7 = l__Company__2.Resources;
                                        l__Resources__7.Equipment = l__Resources__7.Equipment - u19.Resources.Equipment;
                                        local l__Levels__8 = l__Company__2.Levels;
                                        local l__ID__9 = u16.ID;
                                        l__Levels__8[l__ID__9] = l__Levels__8[l__ID__9] + 1;
                                        u13:setState({
                                            Upgrade = 0
                                        });
                                    end }
                            });
                        end;
                    end
                }),
                u2.createElement("ImageLabel", {
                    Image = "rbxassetid://16235940598",
                    BackgroundTransparency = 1,
                    SizeConstraint = u4.SizeConstraint.RelativeYY,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Size = UDim2.new(0.2, 0, 0.2, 0),
                    Position = UDim2.new(0.05, 0, 0.7, 0),
                    ImageColor3 = Color3.fromRGB(255, 170, 0)
                }),
                u2.createElement("ImageLabel", {
                    Image = "rbxassetid://16563081759",
                    BackgroundTransparency = 1,
                    SizeConstraint = u4.SizeConstraint.RelativeYY,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Size = UDim2.new(0.2, 0, 0.2, 0),
                    Position = UDim2.new(0.15, 0, 0.7, 0),
                    ImageColor3 = Color3.fromRGB(0, 170, 255)
                }),
                u2.createElement("ImageLabel", {
                    Image = "rbxassetid://16563081369",
                    BackgroundTransparency = 1,
                    SizeConstraint = u4.SizeConstraint.RelativeYY,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Size = UDim2.new(0.2, 0, 0.2, 0),
                    Position = UDim2.new(0.25, 0, 0.7, 0),
                    ImageColor3 = Color3.fromRGB(255, 80, 80)
                }),
                u2.createElement("ImageLabel", {
                    Image = "rbxassetid://16563081240",
                    BackgroundTransparency = 1,
                    SizeConstraint = u4.SizeConstraint.RelativeYY,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Size = UDim2.new(0.2, 0, 0.2, 0),
                    Position = UDim2.new(0.35, 0, 0.7, 0),
                    ImageColor3 = Color3.fromRGB(127, 208, 98)
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    AnchorPoint = Vector2.new(0, 0.5),
                    Size = UDim2.fromScale(1, 0.17),
                    TextColor3 = Color3.fromRGB(255, 170, 0),
                    Text = v20,
                    Position = UDim2.fromScale(0.08, 0.7),
                    TextXAlignment = u4.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    AnchorPoint = Vector2.new(0, 0.5),
                    Size = UDim2.fromScale(1, 0.17),
                    TextColor3 = Color3.fromRGB(0, 170, 255),
                    Text = v21,
                    Position = UDim2.fromScale(0.18, 0.7),
                    TextXAlignment = u4.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    AnchorPoint = Vector2.new(0, 0.5),
                    Size = UDim2.fromScale(1, 0.17),
                    TextColor3 = Color3.fromRGB(255, 80, 80),
                    Text = v22,
                    Position = UDim2.fromScale(0.28, 0.7),
                    TextXAlignment = u4.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    AnchorPoint = Vector2.new(0, 0.5),
                    Size = UDim2.fromScale(1, 0.17),
                    TextColor3 = Color3.fromRGB(127, 208, 98),
                    Text = v23,
                    Position = UDim2.fromScale(0.38, 0.7),
                    TextXAlignment = u4.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    AnchorPoint = Vector2.new(0, 0.5),
                    Size = UDim2.fromScale(1, 0.17),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Text = v24,
                    Position = UDim2.fromScale(0.44, 0.7),
                    TextXAlignment = u4.TextXAlignment.Left
                })
            }) };
    else
        local v31 = {};
        local v32 = math.max(3, #u14);
        local v33 = 1 / v32;
        v31._Grid = u2.createElement("UIGridLayout", {
            CellPadding = UDim2.fromScale(0, v33 * 0.1),
            CellSize = UDim2.fromScale(1, v33 * 0.9),
            FillDirection = u4.FillDirection.Vertical,
            HorizontalAlignment = u4.HorizontalAlignment.Left,
            SortOrder = u4.SortOrder.LayoutOrder,
            StartCorner = u4.StartCorner.TopLeft,
            VerticalAlignment = u4.VerticalAlignment.Top
        });
        for u34, v35 in u14 do
            local v36 = l__Company__2.Levels[v35.ID];
            local v37, v38, v39, v40, v41, v42;
            if v36 < #v35.Levels then
                local v43 = v35.Levels[v36 + 1];
                v37 = tostring(v43.Resources.Material);
                v38 = tostring(v43.Resources.Metal);
                v39 = tostring(v43.Resources.Fuel);
                v40 = tostring(v43.Resources.Equipment);
                v41 = u6(v43.Cost);
                v42 = u2.createElement(u7, {
                    Text = "Preview",
                    Offset = l__props__1.OffsetBinding,
                    Size = UDim2.fromScale(0.2, 0.25),
                    Position = UDim2.fromScale(0.98, 0.5),
                    AnchorPoint = Vector2.new(1, 0.5),
                    Ignore = l__props__1.Ignore,
                    Callback = function() --[[ Name: Callback, Line 381 ]]
                        -- upvalues: u13 (copy), u34 (copy)
                        u13:setState({
                            Upgrade = u34
                        });
                    end
                });
            else
                v39 = "";
                v40 = "";
                v42 = nil;
                v37 = "";
                v38 = "";
                v41 = "Max Level";
            end;
            local v44 = v36 / #v35.Levels;
            local v45 = Color3.new(1, 0, 0):Lerp(Color3.new(0, 1, 0), v44);
            v31[u34] = u2.createElement("Frame", {
                BorderSizePixel = 0,
                LayoutOrder = u34,
                BackgroundColor3 = Color3.fromRGB(9, 18, 48)
            }, {
                u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.1, 0)
                }),
                u2.createElement("ImageLabel", {
                    BorderSizePixel = 0,
                    Position = UDim2.fromScale(0.01, 0.1),
                    Size = UDim2.fromScale(0.2, 0.8),
                    Image = v35.Levels[v36].Image
                }, { u2.createElement("UIGradient", {
                        Rotation = 90,
                        Transparency = NumberSequence.new({
                            NumberSequenceKeypoint.new(0, 0),
                            NumberSequenceKeypoint.new(0.5, 0),
                            NumberSequenceKeypoint.new(0.75, 1),
                            NumberSequenceKeypoint.new(1, 1)
                        })
                    }), u2.createElement("UICorner", {
                        CornerRadius = UDim.new(0.1, 0)
                    }) }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u9,
                    Size = UDim2.fromScale(1, 0.15),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Text = v35.Name,
                    Position = UDim2.fromScale(0.03, 0.75),
                    TextXAlignment = u4.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    Size = UDim2.fromScale(0.12, 0.25),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Text = v36,
                    Position = UDim2.fromScale(0.25, 0.65),
                    TextXAlignment = u4.TextXAlignment.Center
                }),
                u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Image = "rbxassetid://16562831434",
                    Size = UDim2.fromScale(0.12, 0.06),
                    Position = UDim2.fromScale(0.25, 0.15),
                    SizeConstraint = u4.SizeConstraint.RelativeXX
                }, { u2.createElement("UIGradient", {
                        Color = ColorSequence.new({
                            ColorSequenceKeypoint.new(0, v45),
                            ColorSequenceKeypoint.new(v44 - 0.05, v45),
                            ColorSequenceKeypoint.new(v44 - 0.01, Color3.new(1, 1, 1)),
                            ColorSequenceKeypoint.new(1, Color3.new(1, 1, 1))
                        }),
                        Transparency = NumberSequence.new({
                            NumberSequenceKeypoint.new(0, 0),
                            NumberSequenceKeypoint.new(v44 - 0.05, 0),
                            NumberSequenceKeypoint.new(v44 - 0.01, 0.7),
                            NumberSequenceKeypoint.new(1, 0.8)
                        })
                    }) }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    AnchorPoint = Vector2.new(0, 0.5),
                    Size = UDim2.fromScale(0.05, 0.25),
                    TextColor3 = Color3.fromRGB(255, 170, 0),
                    Text = v37,
                    Position = UDim2.fromScale(0.4, 0.5),
                    TextXAlignment = u4.TextXAlignment.Center
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    AnchorPoint = Vector2.new(0, 0.5),
                    Size = UDim2.fromScale(0.05, 0.25),
                    TextColor3 = Color3.fromRGB(0, 170, 255),
                    Text = v38,
                    Position = UDim2.fromScale(0.45, 0.5),
                    TextXAlignment = u4.TextXAlignment.Center
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    AnchorPoint = Vector2.new(0, 0.5),
                    Size = UDim2.fromScale(0.05, 0.25),
                    TextColor3 = Color3.fromRGB(255, 80, 80),
                    Text = v39,
                    Position = UDim2.fromScale(0.5, 0.5),
                    TextXAlignment = u4.TextXAlignment.Center
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    AnchorPoint = Vector2.new(0, 0.5),
                    Size = UDim2.fromScale(0.05, 0.25),
                    TextColor3 = Color3.fromRGB(127, 208, 98),
                    Text = v40,
                    Position = UDim2.fromScale(0.55, 0.5),
                    TextXAlignment = u4.TextXAlignment.Center
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    AnchorPoint = Vector2.new(0, 0.5),
                    Size = UDim2.fromScale(0.2, 0.25),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Text = v41,
                    Position = UDim2.fromScale(0.6, 0.5),
                    TextXAlignment = u4.TextXAlignment.Center
                }),
                v42
            });
        end;
        v15 = { u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(0, 7, 34),
                Size = UDim2.fromScale(0.49, 0.2),
                Position = UDim2.fromScale(0, 0),
                AnchorPoint = Vector2.new(0, 0)
            }, {
                u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.03, 0)
                }),
                u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.fromScale(0.05, 0.37),
                    Size = UDim2.new(0.9, 0, 0, 1)
                }, { u2.createElement("UIGradient", {
                        Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
                    }) }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    Text = "Resources",
                    BackgroundTransparency = 1,
                    FontFace = u9,
                    Size = UDim2.new(0.98, 0, 0.17, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.new(0.05, 0, 0.125, 0),
                    TextXAlignment = u4.TextXAlignment.Left
                }),
                u2.createElement("ImageLabel", {
                    Image = "rbxassetid://16235940598",
                    BackgroundTransparency = 1,
                    SizeConstraint = u4.SizeConstraint.RelativeYY,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Size = UDim2.new(0.2, 0, 0.2, 0),
                    Position = UDim2.new(0.15, 0, 0.7, 0),
                    ImageColor3 = Color3.fromRGB(255, 170, 0)
                }),
                u2.createElement("ImageLabel", {
                    Image = "rbxassetid://16563081759",
                    BackgroundTransparency = 1,
                    SizeConstraint = u4.SizeConstraint.RelativeYY,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Size = UDim2.new(0.2, 0, 0.2, 0),
                    Position = UDim2.new(0.35, 0, 0.7, 0),
                    ImageColor3 = Color3.fromRGB(0, 170, 255)
                }),
                u2.createElement("ImageLabel", {
                    Image = "rbxassetid://16563081369",
                    BackgroundTransparency = 1,
                    SizeConstraint = u4.SizeConstraint.RelativeYY,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Size = UDim2.new(0.2, 0, 0.2, 0),
                    Position = UDim2.new(0.55, 0, 0.7, 0),
                    ImageColor3 = Color3.fromRGB(255, 80, 80)
                }),
                u2.createElement("ImageLabel", {
                    Image = "rbxassetid://16563081240",
                    BackgroundTransparency = 1,
                    SizeConstraint = u4.SizeConstraint.RelativeYY,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Size = UDim2.new(0.2, 0, 0.2, 0),
                    Position = UDim2.new(0.75, 0, 0.7, 0),
                    ImageColor3 = Color3.fromRGB(127, 208, 98)
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    AnchorPoint = Vector2.new(0, 0.5),
                    Size = UDim2.fromScale(1, 0.17),
                    TextColor3 = Color3.fromRGB(255, 170, 0),
                    Text = l__Company__2.Resources.Material,
                    Position = UDim2.fromScale(0.2, 0.7),
                    TextXAlignment = u4.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    AnchorPoint = Vector2.new(0, 0.5),
                    Size = UDim2.fromScale(1, 0.17),
                    TextColor3 = Color3.fromRGB(0, 170, 255),
                    Text = l__Company__2.Resources.Metal,
                    Position = UDim2.fromScale(0.4, 0.7),
                    TextXAlignment = u4.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    AnchorPoint = Vector2.new(0, 0.5),
                    Size = UDim2.fromScale(1, 0.17),
                    TextColor3 = Color3.fromRGB(255, 80, 80),
                    Text = l__Company__2.Resources.Fuel,
                    Position = UDim2.fromScale(0.6, 0.7),
                    TextXAlignment = u4.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    AnchorPoint = Vector2.new(0, 0.5),
                    Size = UDim2.fromScale(1, 0.17),
                    TextColor3 = Color3.fromRGB(127, 208, 98),
                    Text = l__Company__2.Resources.Equipment,
                    Position = UDim2.fromScale(0.8, 0.7),
                    TextXAlignment = u4.TextXAlignment.Left
                })
            }), u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(0, 7, 34),
                Size = UDim2.fromScale(0.49, 0.2),
                Position = UDim2.fromScale(1, 0),
                AnchorPoint = Vector2.new(1, 0)
            }, {
                u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.03, 0)
                }),
                u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.fromScale(0.05, 0.37),
                    Size = UDim2.new(0.9, 0, 0, 1)
                }, { u2.createElement("UIGradient", {
                        Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
                    }) }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    Text = "Help (?)",
                    BackgroundTransparency = 1,
                    FontFace = u9,
                    Size = UDim2.new(0.98, 0, 0.17, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.new(0.05, 0, 0.125, 0),
                    TextXAlignment = u4.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    Text = "Upgrade your base here. Some upgrades increase the capacity of divisions while others are purely cosmetic. Upgrades require money and resources to purchase.",
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    Size = UDim2.new(0.9, 0, 0.4, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.new(0.05, 0, 0.45, 0),
                    TextXAlignment = u4.TextXAlignment.Left
                })
            }), u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(0, 7, 34),
                Size = UDim2.fromScale(1, 0.76),
                Position = UDim2.fromScale(0, 0.24),
                AnchorPoint = Vector2.new(0, 0)
            }, {
                u2.createElement("UICorner", {
                    CornerRadius = UDim.new(0.01, 0)
                }),
                u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.fromScale(0.025, 0.097),
                    Size = UDim2.new(0.95, 0, 0, 1)
                }, { u2.createElement("UIGradient", {
                        Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
                    }) }),
                u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.fromScale(0.025, 0.16),
                    Size = UDim2.new(0.95, 0, 0, 1)
                }, { u2.createElement("UIGradient", {
                        Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
                    }) }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    Text = "Upgrades",
                    BackgroundTransparency = 1,
                    FontFace = u9,
                    Size = UDim2.new(0.98, 0, 0.045, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.new(0.025, 0, 0.03, 0),
                    TextXAlignment = u4.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    Text = "Name",
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    Size = UDim2.new(0.98, 0, 0.038, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.new(0.025, 0, 0.11, 0),
                    TextXAlignment = u4.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    Text = "Level",
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    Size = UDim2.new(0.2, 0, 0.038, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.new(0.22, 0, 0.11, 0),
                    TextXAlignment = u4.TextXAlignment.Center
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    Text = "Upgrade Cost",
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    Size = UDim2.new(0.2, 0, 0.038, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.new(0.59, 0, 0.11, 0),
                    TextXAlignment = u4.TextXAlignment.Center
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    Text = "Upgrade",
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    Size = UDim2.new(0.22, 0, 0.038, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.new(0.75, 0, 0.11, 0),
                    TextXAlignment = u4.TextXAlignment.Center
                }),
                u2.createElement("ImageLabel", {
                    Image = "rbxassetid://16235940598",
                    BackgroundTransparency = 1,
                    SizeConstraint = u4.SizeConstraint.RelativeYY,
                    AnchorPoint = Vector2.new(0.5, 0),
                    Size = UDim2.new(0.038, 0, 0.038, 0),
                    Position = UDim2.new(0.43, 0, 0.11, 0),
                    ImageColor3 = Color3.fromRGB(255, 170, 0)
                }),
                u2.createElement("ImageLabel", {
                    Image = "rbxassetid://16563081759",
                    BackgroundTransparency = 1,
                    SizeConstraint = u4.SizeConstraint.RelativeYY,
                    AnchorPoint = Vector2.new(0.5, 0),
                    Size = UDim2.new(0.038, 0, 0.038, 0),
                    Position = UDim2.new(0.475, 0, 0.11, 0),
                    ImageColor3 = Color3.fromRGB(0, 170, 255)
                }),
                u2.createElement("ImageLabel", {
                    Image = "rbxassetid://16563081369",
                    BackgroundTransparency = 1,
                    SizeConstraint = u4.SizeConstraint.RelativeYY,
                    AnchorPoint = Vector2.new(0.5, 0),
                    Size = UDim2.new(0.038, 0, 0.038, 0),
                    Position = UDim2.new(0.523, 0, 0.11, 0),
                    ImageColor3 = Color3.fromRGB(255, 80, 80)
                }),
                u2.createElement("ImageLabel", {
                    Image = "rbxassetid://16563081240",
                    BackgroundTransparency = 1,
                    SizeConstraint = u4.SizeConstraint.RelativeYY,
                    AnchorPoint = Vector2.new(0.5, 0),
                    Size = UDim2.new(0.038, 0, 0.038, 0),
                    Position = UDim2.new(0.571, 0, 0.11, 0),
                    ImageColor3 = Color3.fromRGB(127, 208, 98)
                }),
                u2.createElement(u8, {
                    BackgroundTransparency = 1,
                    BorderSizePixel = 0,
                    Size = UDim2.fromScale(0.95, 0.8),
                    Position = UDim2.new(0.025, 0, 0.17, 1),
                    Ignore = l__props__1.Ignore,
                    OffsetBinding = l__props__1.OffsetBinding,
                    CanvasSize = v32 / 3,
                    Content = v31
                })
            }) };
    end;
    return u2.createFragment(v15);
end;
return v11;