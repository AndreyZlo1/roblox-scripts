-- Services.InterfaceService.TabletInterface.QuestComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, u3, u4 = shared.import("require", "Roact", "network", "Enum");
local u5 = v1("ClientService");
local u6 = v1("SoundService");
local u7 = v1("GameShellProxyScroller");
local u8 = v1("sanitizeDisplayName");
local u9 = v1("convertUnit");
local u10 = v1("formatNumber");
local u11 = v1("Quests");
local u12 = v1("CompanyInfo");
local u13 = v1("RoactTween");
local u14 = v1("ManageCompanyButtonComponent");
local u15 = Font.fromId(12188570269, u4.FontWeight.Bold, u4.FontStyle.Italic);
Font.fromId(12188570269, u4.FontWeight.Regular, u4.FontStyle.Italic);
local u16 = Font.fromId(12188570269, u4.FontWeight.Bold, u4.FontStyle.Normal);
local u17 = Font.fromId(12188570269, u4.FontWeight.Regular, u4.FontStyle.Normal);
local u18 = {
    {
        Name = "Easy",
        Color = "0,255,0"
    },
    {
        Name = "Medium",
        Color = "255,187,52"
    },
    {
        Name = "Hard",
        Color = "255,0,0"
    },
    {
        Name = "Extreme",
        Color = "117,0,2"
    }
};
local v19 = u2.Component:extend("Quest");
local l__TextService__1 = game:GetService("TextService");
local l__Lighting__2 = game:GetService("Lighting");
local l__Players__3 = game:GetService("Players");
local l__LocalPlayer__4 = l__Players__3.LocalPlayer;
local l__CurrentCamera__5 = workspace.CurrentCamera;
local function u26() --[[ Line: 50 ]]
    -- upvalues: l__LocalPlayer__4 (copy), u5 (copy), l__Players__3 (copy)
    local v20 = l__LocalPlayer__4;
    local l__Squad__6 = u5.LocalClient.Squad;
    if l__Squad__6 and tonumber(l__Squad__6) then
        v20 = l__Players__3:GetPlayerByUserId(l__Squad__6);
    end;
    local v21 = {};
    for v22, v23 in u5.Clients do
        if v22 ~= v20 and v23.Squad == tostring(v20.UserId) then
            v21[#v21 + 1] = v23;
        end;
    end;
    table.sort(v21, function(p24, p25) --[[ Line: 68 ]]
        return p24.Joined < p25.Joined;
    end);
    table.insert(v21, 1, u5.Clients[v20]);
    return v21;
end;
function v19._questComponent(u27, u28, p29, p30, u31) --[[ Line: 76 ]]
    -- upvalues: u11 (copy), u12 (copy), u17 (copy), l__TextService__1 (copy), u5 (copy), u3 (copy), u2 (copy), u15 (copy), u8 (copy), u4 (copy), l__LocalPlayer__4 (copy), u14 (copy), u18 (copy), u10 (copy), u16 (copy)
    local v32 = 0;
    local v33 = u11.QuestGivers[u28.Giver];
    local l__Name__7 = u28.Name;
    if l__Name__7 then
        l__Name__7 = u11.QuestData[u28.Name];
    end;
    local v34 = u28.Completed and 2 or 1;
    local l__Message__8 = u28.Message;
    local v35 = p29 * 0.09;
    local v36 = v32 + v35;
    local v37 = p29 * 0.09 * 0.75;
    local v38 = v36 + v37;
    local l__Debriefing__9 = u28.Debriefing;
    local v39 = Vector2.new();
    local v40;
    if l__Name__7 then
        if l__Debriefing__9 then
            v40 = l__Name__7.Debriefing or "<i>No Debriefing</i>";
        else
            v40 = l__Name__7.Description;
        end;
        if l__Name__7.Gasmask then
            v40 = "<b>A gasmask is required to complete this mission</b>\n\n" .. v40;
        end;
        local v41 = false;
        if l__Name__7.Rewards.Items then
            for _, v42 in l__Name__7.Rewards.Items do
                if v42[2] then
                    if not v41 then
                        v40 = v40 .. "\n\n<b>Rewards:</b>";
                        v41 = true;
                    end;
                    v40 = v40 .. "\n• " .. v42[1];
                end;
            end;
        end;
        if l__Name__7.Rewards.Resources then
            local v43 = l__Name__7.Rewards.Resources[v34];
            if v43 then
                for v44, v45 in v43 do
                    if v45 > 0 then
                        if not v41 then
                            v40 = v40 .. "\n\n<b>Rewards:</b>";
                            v41 = true;
                        end;
                        local v46 = u12.Resources[v44];
                        v40 = v40 .. "\n<font color=\"#" .. v46.Color:ToHex() .. "\" weight=\"bold\">• " .. v46.Name .. ": " .. tostring(v45) .. "</font>";
                    end;
                end;
            end;
        end;
        local v47 = Instance.new("GetTextBoundsParams");
        v47.RichText = true;
        v47.Text = v40;
        v47.Font = u17;
        v47.Size = p29 * 0.03;
        v47.Width = p30;
        v39 = l__TextService__1:GetTextBoundsAsync(v47);
    else
        v40 = nil;
    end;
    local v48 = v38 + v39.Y;
    local v49 = v35 * 0.75 * 0.5;
    local v50 = v48 + v49;
    local v51 = {};
    local v52 = v35 / v50;
    local v53 = v35 / v50 + v37 / 3 * 2 / v50 + v39.Y / v50;
    local v54 = nil;
    local v55 = u27.state.Squad[1] == u5.LocalClient;
    if u28.Requester then
        v54 = v55 and {
            Title = "Remove from queue",
            SoundKit = "MissionTabRemoveQueue",
            Callback = function() --[[ Name: Callback, Line 166 ]]
                -- upvalues: u27 (copy), u31 (copy), u3 (ref)
                table.remove(u27.QuestList, u31);
                u3:FireServer("ActivateInteract", "RemoveQueue", u31);
                u27:setState({});
            end
        } or v54;
        v51.Requester = u2.createElement("TextLabel", {
            TextScaled = true,
            TextTransparency = 0,
            BackgroundTransparency = 1,
            FontFace = u15,
            Size = UDim2.new(10, 0, v49 * 0.8 / v50, 0),
            TextColor3 = Color3.new(1, 1, 1),
            Text = "> " .. u8(u28.Requester.DisplayName, u28.Requester.Name),
            Position = UDim2.fromScale(0.04, v53 + v49 * 0.5 / v50),
            AnchorPoint = Vector2.new(0, 0.5),
            TextXAlignment = u4.TextXAlignment.Left
        });
    else
        if u28.Inviter then
            v51.Outline = u2.createElement("UIStroke", {
                Thickness = 3,
                Color = Color3.fromRGB(255, 110, 7)
            });
            v51.Inviter = u2.createElement("TextLabel", {
                TextScaled = true,
                TextTransparency = 0,
                BackgroundTransparency = 1,
                FontFace = u15,
                Size = UDim2.new(10, 0, v49 * 0.8 / v50, 0),
                TextColor3 = Color3.fromRGB(255, 110, 7),
                Text = "> " .. u8(u28.Inviter.DisplayName, u28.Inviter.Name),
                Position = UDim2.fromScale(0.04, v53 + v49 * 0.5 / v50),
                AnchorPoint = Vector2.new(0, 0.5),
                TextXAlignment = u4.TextXAlignment.Left
            });
        end;
        if l__Name__7 then
            if not l__Message__8 then
                if v55 then
                    v54 = {
                        Title = "Add to queue",
                        SoundKit = "MissionTabAddQueue",
                        Callback = function() --[[ Name: Callback, Line 219 ]]
                            -- upvalues: u27 (copy), u28 (copy), l__LocalPlayer__4 (ref), u3 (ref)
                            for _, v56 in u27.QuestList do
                                if v56.Name == u28.Name then
                                    return;
                                end;
                            end;
                            if #u27.QuestList >= 3 then
                                u27.Notify("Max missions", "You can only do 3 missions at a time.", {});
                            else
                                u27.QuestList[#u27.QuestList + 1] = {
                                    Requester = u28.Inviter or l__LocalPlayer__4,
                                    Completed = u28.Completed,
                                    Giver = u28.Giver,
                                    Name = u28.Name
                                };
                                u3:FireServer("ActivateInteract", "AddQueue", u28.Name);
                                u27:setState({});
                            end;
                        end
                    };
                else
                    v54 = {
                        Title = "Request mission",
                        SoundKit = "MissionTabAddQueue",
                        Callback = function() --[[ Name: Callback, Line 245 ]]
                            -- upvalues: u27 (copy), u3 (ref), u28 (copy)
                            u27.Notify("Requested mission", "The squad leader can now select it from available missions.", {});
                            u3:FireServer("ActivateInteract", "RequestQueue", u28.Name);
                        end
                    };
                end;
            end;
        else
            v54 = {
                Title = "View missions",
                SoundKit = "MissionTabAddQueue",
                Callback = function() --[[ Name: Callback, Line 208 ]]
                    -- upvalues: u27 (copy), u28 (copy)
                    u27:setState({
                        Page = u28.Giver
                    });
                end
            };
        end;
    end;
    if v54 then
        v51.Button = u2.createElement(u14, {
            Offset = u27.OffsetBinding,
            Size = UDim2.fromScale(0.46, v49 / v50),
            Position = UDim2.fromScale(0.5, v53),
            Text = v54.Title,
            SoundKit = v54.SoundKit,
            Ignore = u27.Notification,
            Callback = v54.Callback
        });
    end;
    if u28.ShowOptions then
        v51.Option = u2.createElement(u14, {
            Offset = u27.OffsetBinding,
            Size = UDim2.fromScale(0.44, v49 / v50),
            Position = UDim2.fromScale(0.04, v53),
            Text = l__Debriefing__9 and "Show description" or "Show debriefing",
            SoundKit = v54.SoundKit,
            Ignore = u27.Notification,
            Callback = function() --[[ Name: Callback, Line 275 ]]
                -- upvalues: u27 (copy), l__Debriefing__9 (copy)
                u27:setState({
                    Debriefing = not l__Debriefing__9
                });
            end
        });
    end;
    if l__Name__7 then
        local v57 = (not l__Name__7.Rewards.OperatorTokens or l__Name__7.Rewards.OperatorTokens[v34] <= 0) and "" or "(+" .. tostring(l__Name__7.Rewards.OperatorTokens[v34]) .. " Token) ";
        local v58 = u18[l__Name__7.Difficulty or 1];
        v51.Reward = u2.createElement("TextLabel", {
            TextScaled = true,
            RichText = true,
            TextTransparency = 0,
            BackgroundTransparency = 1,
            FontFace = u17,
            Size = UDim2.new(10, 0, v52 * 0.75 * 0.5, 0),
            TextColor3 = Color3.new(1, 1, 1),
            Text = v57 .. "<font color=\"rgb(251, 175, 60)\" weight=\"bold\">" .. u10(l__Name__7.Rewards.Money[v34]) .. "</font>",
            Position = UDim2.fromScale(0.96, v52 * 0.25),
            AnchorPoint = Vector2.new(1, 0),
            TextXAlignment = u4.TextXAlignment.Right
        });
        v51.EXP = u2.createElement("TextLabel", {
            TextScaled = true,
            TextTransparency = 0,
            BackgroundTransparency = 1,
            FontFace = u16,
            Size = UDim2.new(10, 0, v52 * 0.75 * 0.5, 0),
            TextColor3 = Color3.new(1, 1, 1),
            Text = l__Name__7.Rewards.EXP[v34] .. " EXP",
            Position = UDim2.fromScale(0.96, v52 * 0.25 + v52 * 0.75 / 2),
            AnchorPoint = Vector2.new(1, 0),
            TextXAlignment = u4.TextXAlignment.Right
        });
        v51.Profile = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Position = UDim2.fromScale(0.04, v52 * 0.25),
            Size = UDim2.fromScale(v52 * 0.75, v52 * 0.75),
            SizeConstraint = u4.SizeConstraint.RelativeYY,
            Image = v33.Icon or "rbxthumb://type=AvatarHeadShot&id=1&w=150&h=150"
        }, { u2.createElement("UIStroke", {
                Transparency = 0,
                Thickness = 1,
                LineJoinMode = u4.LineJoinMode.Round,
                Color = Color3.new(1, 1, 1)
            }), u2.createElement("TextLabel", {
                TextScaled = true,
                TextTransparency = 0,
                RichText = true,
                BackgroundTransparency = 1,
                FontFace = u16,
                Size = UDim2.new(10, 0, 0.5, 0),
                TextColor3 = Color3.new(1, 1, 1),
                Text = l__Name__7.Name .. " <font color=\"rgb(" .. v58.Color .. ")\">(" .. v58.Name .. ")</font>",
                Position = UDim2.fromScale(1.25, 0),
                TextXAlignment = u4.TextXAlignment.Left
            }), u2.createElement("TextLabel", {
                TextScaled = true,
                TextTransparency = 0,
                BackgroundTransparency = 1,
                FontFace = u17,
                Size = UDim2.new(10, 0, 0.5, 0),
                TextColor3 = Color3.new(1, 1, 1),
                Text = v33.Name,
                Position = UDim2.fromScale(1.25, 0.5),
                TextXAlignment = u4.TextXAlignment.Left
            }) });
        local l__createElement__10 = u2.createElement;
        local v59 = "TextLabel";
        local v60 = {
            TextScaled = true,
            RichText = true,
            BackgroundTransparency = 1,
            FontFace = u17,
            Size = UDim2.new(0.92, 0, v39.Y / v50, 0),
            TextTransparency = l__Message__8 and 0.75 or 0,
            TextColor3 = Color3.new(1, 1, 1),
            Text = v40,
            Position = UDim2.fromScale(0.04, v35 / v50 + v37 / 3 / v50),
            TextXAlignment = u4.TextXAlignment.Left
        };
        local v61 = {};
        local v62;
        if l__Message__8 then
            v62 = u2.createElement("UIGradient", {
                Rotation = 90,
                Transparency = NumberSequence.new({
                    NumberSequenceKeypoint.new(0, 0),
                    NumberSequenceKeypoint.new(0.4, 1),
                    NumberSequenceKeypoint.new(0.6, 1),
                    NumberSequenceKeypoint.new(1, 0)
                })
            });
        else
            v62 = l__Message__8;
        end;
        v61[1] = v62;
        v51.Description = l__createElement__10(v59, v60, v61);
        if l__Message__8 then
            local v63 = Instance.new("GetTextBoundsParams");
            v63.RichText = true;
            v63.Text = l__Message__8;
            v63.Font = u17;
            v63.Size = p29 * 0.03;
            v63.Width = p30;
            local v64 = l__TextService__1:GetTextBoundsAsync(v63);
            v51.Message = u2.createElement("TextLabel", {
                TextScaled = true,
                TextTransparency = 0,
                RichText = true,
                BackgroundTransparency = 1,
                ZIndex = 2,
                FontFace = u17,
                Size = UDim2.new(0.92, 0, v64.Y / v50, 0),
                TextColor3 = Color3.new(1, 1, 1),
                Text = l__Message__8,
                AnchorPoint = Vector2.new(0, 0.5),
                Position = UDim2.fromScale(0.04, v35 / v50 + v37 / 3 / v50 + v39.Y / v50 / 2),
                TextXAlignment = u4.TextXAlignment.Center
            });
        end;
    else
        v51.Profile = u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            Position = UDim2.fromScale(0.04, v52 * 0.25),
            Size = UDim2.fromScale(v52 * 0.75, v52 * 0.75),
            SizeConstraint = u4.SizeConstraint.RelativeYY,
            Image = v33.Icon or "rbxthumb://type=AvatarHeadShot&id=1&w=150&h=150"
        }, { u2.createElement("UIStroke", {
                Transparency = 0,
                Thickness = 1,
                LineJoinMode = u4.LineJoinMode.Round,
                Color = Color3.new(1, 1, 1)
            }), u2.createElement("TextLabel", {
                TextScaled = true,
                TextTransparency = 0,
                RichText = true,
                BackgroundTransparency = 1,
                FontFace = u16,
                Size = UDim2.new(10, 0, 0.5, 0),
                TextColor3 = Color3.new(1, 1, 1),
                Text = v33.Name,
                Position = UDim2.fromScale(1.25, 0),
                TextXAlignment = u4.TextXAlignment.Left
            }), u2.createElement("TextLabel", {
                TextScaled = true,
                TextTransparency = 0,
                BackgroundTransparency = 1,
                FontFace = u17,
                Size = UDim2.new(10, 0, 0.5, 0),
                TextColor3 = Color3.new(1, 1, 1),
                Text = u28.Count .. " missions completed",
                Position = UDim2.fromScale(1.25, 0.5),
                TextXAlignment = u4.TextXAlignment.Left
            }) });
    end;
    v51.Corner = u2.createElement("UICorner", {
        CornerRadius = UDim.new(p29 * 0.01 / v50, 0)
    });
    if l__Name__7 then
        l__Name__7 = l__Name__7.Rewards;
    end;
    return v51, v50, l__Name__7;
end;
local function u67(p65, p66) --[[ Line: 444 ]]
    -- upvalues: u2 (copy)
    return u2.createElement("Frame", {
        BackgroundColor3 = Color3.fromRGB(9, 18, 48),
        Position = UDim2.fromScale(0.05, p65.Position / p66),
        Size = UDim2.fromScale(0.9, p65.Size / p66)
    }, p65.Elements);
end;
function v19.init(u68, p69) --[[ Line: 452 ]]
    -- upvalues: u6 (copy), u13 (copy), u4 (copy), u2 (copy), l__Lighting__2 (copy), l__CurrentCamera__5 (copy), u5 (copy), u26 (copy), u11 (copy), u3 (copy)
    u6:CreateSound("Button", nil, true, "UISounds", "MissionTabOpen").Destroy(10);
    u68.ScreenPart = p69.ScreenPart;
    u68.OffsetBinding = p69.OffsetBinding;
    u68.SizeBinding = p69.SizeBinding;
    u68.Update = p69.Update;
    u68.InvitedQuests = {};
    u68.Quests = p69.Quests;
    u68.NotifyTween = u13.new(0, TweenInfo.new(0.1, u4.EasingStyle.Exponential, u4.EasingDirection.Out, 0, false, 0));
    function u68.Notify(p70, p71, p72) --[[ Line: 464 ]]
        -- upvalues: u68 (copy)
        u68.NotifyTween:SetGoal(1);
        u68:setState({
            Notification = true,
            Title = p70,
            Description = p71,
            Options = p72
        });
    end;
    local v73, v74 = u2.createBinding("");
    u68.timeBinding = v73;
    u68.updateTime = v74;
    u68.Connection = u68.Update:Connect(function(_) --[[ Line: 475 ]]
        -- upvalues: l__Lighting__2 (ref), u68 (copy)
        local l__ClockTime__11 = l__Lighting__2.ClockTime;
        local v75 = (math.floor(l__ClockTime__11) + 11) % 12 + 1;
        local v76 = math.floor(l__ClockTime__11 % 1 * 60);
        u68.updateTime(tostring(v75) .. ":" .. (v76 < 10 and "0" or "") .. tostring(v76) .. " " .. (l__ClockTime__11 >= 12 and "PM" or "AM"));
    end);
    local l__Position__12 = l__CurrentCamera__5.CFrame.Position;
    local v77 = {};
    for _, v78 in u5.Clients do
        if not v78.IsLocalClient and (v78.Actor and (v78.Actor.Alive and not v78.Survivor)) then
            v78._questDistance = (l__Position__12 - v78.Actor.Position).Magnitude;
            v77[#v77 + 1] = v78;
        end;
    end;
    table.sort(v77, function(p79, p80) --[[ Line: 493 ]]
        return p79._questDistance < p80._questDistance;
    end);
    u68:setState({
        Page = 0,
        Notification = false,
        Squad = u26(),
        NearbyPlayers = v77
    });
    local v81 = {};
    for v82, v83 in p69.QuestsCompleted do
        if not v81[v83] then
            v81[v83] = {};
        end;
        v81[v83][#v81[v83] + 1] = v82;
    end;
    for u84, v85 in v81 do
        table.sort(v85, function(p86, p87) --[[ Line: 514 ]]
            -- upvalues: u11 (ref), u84 (copy)
            return (table.find(u11.QuestGivers[u84].Quests, p86) or (1 / 0)) < (table.find(u11.QuestGivers[u84].Quests, p87) or (1 / 0));
        end);
    end;
    u68.QuestsCompleted = v81;
    u68.QuestList = p69.QuestList;
    u68.SquadSignal = u5.SquadChanged:Connect(function() --[[ Line: 523 ]]
        -- upvalues: u26 (ref), u68 (copy), u6 (ref)
        local v88 = u26();
        if #v88 > #u68.state.Squad then
            u6:CreateSound("Button", nil, true, "UISounds", "MissionTabInviteJoin").Destroy(10);
        end;
        u68:setState({
            Squad = v88
        });
    end);
    if p69.HasQuest then
        u68.Notify("Cancel mission?", "Are you sure you want to cancel your current mission?", {
            {
                "Yes",
                function() --[[ Line: 537 ]]
                    -- upvalues: u3 (ref)
                    u3:FireServer("ActivateInteract", "CancelQuest");
                end,
                nil,
                "MissionTabCancelMission"
            },
            { "Cancel", function() --[[ Line: 540 ]]
                    -- upvalues: u3 (ref)
                    u3:FireServer("ActivateInteract", "Exit");
                end }
        });
    end;
end;
function v19.willUnmount(p89) --[[ Line: 547 ]]
    -- upvalues: u6 (copy)
    u6:CreateSound("Button", nil, true, "UISounds", "MissionTabClose").Destroy(10);
    p89.SquadSignal:Disconnect();
    p89.Connection:Disconnect();
end;
function v19.render(u90) --[[ Line: 555 ]]
    -- upvalues: u2 (copy), u14 (copy), u5 (copy), u4 (copy), u16 (copy), u8 (copy), u3 (copy), u17 (copy), u9 (copy), u7 (copy), l__CurrentCamera__5 (copy), u67 (copy), u10 (copy), u6 (copy)
    local l__state__13 = u90.state;
    local l__props__14 = u90.props;
    if l__props__14.InvitedQuests then
        u90.InvitedQuests = l__props__14.InvitedQuests;
    end;
    if l__props__14.QuestList then
        u90.QuestList = l__props__14.QuestList;
        l__props__14.QuestList = nil;
    end;
    local v91 = {};
    if l__state__13.Notification then
        local v92 = false;
        for v93, u94 in l__state__13.Options do
            v92 = u94[1] == "Cancel" and true or v92;
            v91[v93] = u2.createElement(u14, {
                MiniText = true,
                LayoutOrder = v93,
                Offset = u90.OffsetBinding,
                Size = UDim2.fromScale(1, 0.07),
                Text = u94[1],
                Callback = function() --[[ Name: Callback, Line 579 ]]
                    -- upvalues: u90 (copy), u94 (copy)
                    u90.NotifyTween:SetGoal(0);
                    u90:setState({
                        Notification = false
                    });
                    u94[2]();
                end,
                SoundKit = u94[4],
                SubText = u94[3]
            });
        end;
        if not v92 then
            v91[#l__state__13.Options + 1] = u2.createElement(u14, {
                MiniText = true,
                LayoutOrder = #l__state__13.Options + 1,
                Offset = u90.OffsetBinding,
                Size = UDim2.fromScale(1, 0.07),
                Text = #l__state__13.Options > 0 and "Cancel" or "Dismiss",
                Callback = function() --[[ Name: Callback, Line 598 ]]
                    -- upvalues: u90 (copy)
                    u90.NotifyTween:SetGoal(0);
                    u90:setState({
                        Notification = false
                    });
                end
            });
        end;
    end;
    local l__Squad__15 = l__state__13.Squad;
    local v95 = l__Squad__15[1] == u5.LocalClient;
    local v96 = {};
    for v97 = 1, 5 do
        local u98 = l__Squad__15[v97];
        local u99;
        if u98 then
            u99 = u98.Owner;
        else
            u99 = u98;
        end;
        local l__createElement__16 = u2.createElement;
        local v100 = "ImageLabel";
        local v101 = {
            BackgroundTransparency = 1,
            Position = UDim2.fromScale(0.05, (v97 - 1) * 0.15 + 0.2),
            Size = UDim2.fromScale(0.13, 0.13),
            SizeConstraint = u4.SizeConstraint.RelativeYY,
            Image = u99 and ("rbxthumb://type=AvatarHeadShot&id=" .. u99.UserId .. "&w=150&h=150" or "") or ""
        };
        local v102 = {};
        local v103 = u2.createElement("UIStroke", {
            Thickness = 1,
            LineJoinMode = u4.LineJoinMode.Round,
            Color = Color3.new(1, 1, 1),
            Transparency = u98 and 0 or 0.8
        });
        local v104 = u2.createElement("TextLabel", {
            TextScaled = true,
            BackgroundTransparency = 1,
            FontFace = u16,
            Size = UDim2.new(5, 0, 0.5, 0),
            TextTransparency = u99 and 0 or 0.8,
            TextColor3 = Color3.new(1, 1, 1),
            Text = u99 and (u8(u99.DisplayName, u99.Name) or "EMPTY SLOT") or "EMPTY SLOT",
            Position = UDim2.new(u99 and 1.25 or 1.5, 0, 0.25, 0),
            TextXAlignment = u4.TextXAlignment.Left
        });
        if v95 then
            if u99 then
                if u98 == u5.LocalClient then
                    u99 = false;
                else
                    u99 = u2.createElement(u14, {
                        Text = "Kick",
                        SoundKit = "MissionTabKick",
                        Offset = u90.OffsetBinding,
                        Size = UDim2.fromScale(1, 0.5),
                        Position = UDim2.fromScale(5.5, 0.25),
                        Ignore = u90.Notification,
                        Callback = function() --[[ Name: Callback, Line 645 ]]
                            -- upvalues: u90 (copy), u8 (ref), u99 (copy), u98 (copy), u3 (ref)
                            local v105 = {
                                { "Yes", function() --[[ Line: 647 ]]
                                        -- upvalues: u98 (ref), u3 (ref), u99 (ref)
                                        u98.InvitedToSquad = false;
                                        u3:FireServer("InviteSquad", u99.Name, false);
                                    end }
                            };
                            u90.Notify("Kick squad member", "Are you sure you want to remove " .. u8(u99.DisplayName, u99.Name) .. " from your squad?", v105);
                        end
                    });
                end;
            end;
        else
            u99 = v95;
        end;
        v102[1], v102[2], v102[3] = v103, v104, u99;
        v96[v97] = l__createElement__16(v100, v101, v102);
    end;
    local v106 = u2.createElement("Frame", {
        BorderSizePixel = 0,
        BackgroundColor3 = Color3.fromRGB(0, 7, 34),
        Position = UDim2.fromScale(0.01, 0.01),
        Size = UDim2.fromScale(0.25, 0.485)
    }, {
        u2.createElement("UICorner", {
            CornerRadius = UDim.new(0.03, 0)
        }),
        u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.fromRGB(183, 211, 255),
            Position = UDim2.fromScale(0.05, 0.15),
            Size = UDim2.new(0.9, 0, 0, 1)
        }, { u2.createElement("UIGradient", {
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
            }) }),
        u2.createElement("TextLabel", {
            TextScaled = true,
            Text = "Your Squad",
            BackgroundTransparency = 1,
            FontFace = u16,
            Size = UDim2.new(0.9, 0, 0.07, 0),
            TextColor3 = Color3.fromRGB(183, 211, 255),
            Position = UDim2.new(0.08, 0, 0.05, 0),
            TextXAlignment = u4.TextXAlignment.Left
        }),
        u2.createFragment(v96)
    });
    local v107 = 0;
    local v108 = {};
    for v109, u110 in l__state__13.NearbyPlayers do
        if not u5.LocalClient.Squad or u110.Squad ~= u5.LocalClient.Squad then
            local v111, u112 = u2.createBinding(u110.InvitedToSquad);
            local l__Owner__17 = u110.Owner;
            v107 = v107 + 1;
            v108[v109] = u2.createElement("Frame", {
                BackgroundTransparency = 1
            }, { u2.createElement("ImageLabel", {
                    BackgroundTransparency = 1,
                    Position = UDim2.new(0.05, 2, 0, 2),
                    Size = UDim2.new(1, -4, 1, -4),
                    SizeConstraint = u4.SizeConstraint.RelativeYY,
                    Image = "rbxthumb://type=AvatarHeadShot&id=" .. l__Owner__17.UserId .. "&w=150&h=150"
                }, {
                    u2.createElement("UIStroke", {
                        Thickness = 1,
                        LineJoinMode = u4.LineJoinMode.Round,
                        Color = Color3.new(1, 1, 1)
                    }),
                    u2.createElement("TextLabel", {
                        TextScaled = true,
                        BackgroundTransparency = 1,
                        FontFace = u16,
                        Size = UDim2.new(5, 0, 0.5, 0),
                        TextTransparency = l__Owner__17 and 0 or 0.8,
                        TextColor3 = Color3.new(1, 1, 1),
                        Text = u8(l__Owner__17.DisplayName, l__Owner__17.Name),
                        Position = UDim2.new(1.25, 0, 0, 0),
                        TextXAlignment = u4.TextXAlignment.Left
                    }),
                    u2.createElement("TextLabel", {
                        TextScaled = true,
                        BackgroundTransparency = 1,
                        FontFace = u17,
                        Size = UDim2.new(5, 0, 0.5, 0),
                        TextTransparency = l__Owner__17 and 0 or 0.8,
                        TextColor3 = Color3.new(1, 1, 1),
                        Text = u9(u110._questDistance),
                        Position = UDim2.new(1.25, 0, 0.5, 0),
                        TextXAlignment = u4.TextXAlignment.Left
                    }),
                    u2.createElement(u14, {
                        Offset = u90.OffsetBinding,
                        Size = v111:map(function(p113) --[[ Line: 742 ]]
                            return UDim2.fromScale(p113 and 1.4 or 1.2, 0.5);
                        end),
                        Position = v111:map(function(p114) --[[ Line: 745 ]]
                            return UDim2.fromScale(p114 and 5.1 or 5.3, 0.25);
                        end),
                        Text = v111:map(function(p115) --[[ Line: 748 ]]
                            return p115 and "Uninvite" or "Invite";
                        end),
                        Ignore = u90.Notification,
                        Callback = function() --[[ Name: Callback, Line 752 ]]
                            -- upvalues: u110 (copy), u3 (ref), l__Owner__17 (copy), u112 (copy)
                            u110.InvitedToSquad = not u110.InvitedToSquad;
                            u3:FireServer("InviteSquad", l__Owner__17.Name, u110.InvitedToSquad);
                            u112(u110.InvitedToSquad);
                        end
                    })
                }) });
        end;
    end;
    local v116 = math.max(5, v107);
    local v117 = 1 / v116;
    v108._Grid = u2.createElement("UIGridLayout", {
        CellPadding = UDim2.fromScale(0, v117 * 0.05),
        CellSize = UDim2.fromScale(1, v117 * 0.95),
        FillDirection = u4.FillDirection.Vertical,
        HorizontalAlignment = u4.HorizontalAlignment.Left,
        SortOrder = u4.SortOrder.LayoutOrder,
        StartCorner = u4.StartCorner.TopLeft,
        VerticalAlignment = u4.VerticalAlignment.Top
    });
    local v118 = u2.createElement("Frame", {
        BorderSizePixel = 0,
        BackgroundColor3 = Color3.fromRGB(0, 7, 34),
        Position = UDim2.fromScale(0.01, 0.99),
        AnchorPoint = Vector2.new(0, 1),
        Size = UDim2.fromScale(0.25, 0.485)
    }, {
        u2.createElement("UICorner", {
            CornerRadius = UDim.new(0.03, 0)
        }),
        u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.fromRGB(183, 211, 255),
            Position = UDim2.fromScale(0.05, 0.15),
            Size = UDim2.new(0.9, 0, 0, 1)
        }, { u2.createElement("UIGradient", {
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
            }) }),
        u2.createElement("TextLabel", {
            TextScaled = true,
            Text = "Quick Invite",
            BackgroundTransparency = 1,
            FontFace = u16,
            Size = UDim2.new(0.9, 0, 0.07, 0),
            TextColor3 = Color3.fromRGB(183, 211, 255),
            Position = UDim2.new(0.08, 0, 0.05, 0),
            TextXAlignment = u4.TextXAlignment.Left
        }),
        u2.createElement(u7, {
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            Size = UDim2.fromScale(1, 0.74),
            Position = UDim2.fromScale(0, 0.2),
            Ignore = u90.Notification,
            OffsetBinding = u90.OffsetBinding,
            CanvasSize = v116 / 5,
            Content = v108
        })
    });
    local v119 = l__CurrentCamera__5.ViewportSize.Y / 1.726;
    local v120 = v119 * 1.839 * 0.265 * 0.92;
    local v121 = v119 * 0.827992;
    local v122 = v121 * 0.025;
    local v123 = {};
    local v124 = {};
    local v125 = 0;
    local v126 = 0;
    local v127 = 0;
    local v128 = {};
    for v129, v130 in u90.QuestList do
        local v131, v132, v133 = u90:_questComponent(v130, v121, v120, v129);
        v123[v129] = {
            Elements = v131,
            Position = v125,
            Size = v132
        };
        v125 = v125 + (v132 + v122);
        v124[#v124 + 1] = v130.Name;
        local v134 = v130.Completed and 2 or 1;
        v126 = v126 + v133.Money[v134];
        v127 = v127 + v133.EXP[v134];
    end;
    local v135 = v125 - v122;
    for v136, v137 in v123 do
        v128[v136] = u67(v137, v135);
    end;
    local v138 = u2.createElement("Frame", {
        BorderSizePixel = 0,
        Position = UDim2.fromScale(0.04, 0.77),
        Size = UDim2.fromScale(0.92, 0.2),
        BackgroundColor3 = Color3.fromRGB(9, 18, 48)
    }, {
        u2.createElement("UICorner", {
            CornerRadius = UDim.new(0.04, 0)
        }),
        u2.createElement("TextLabel", {
            TextScaled = true,
            Text = "Missions to complete: ",
            BackgroundTransparency = 1,
            FontFace = u17,
            Size = UDim2.new(1, 0, 0.18, 0),
            TextColor3 = Color3.fromRGB(251, 251, 251),
            Position = UDim2.new(0.05, 0, 0.1, 0),
            TextXAlignment = u4.TextXAlignment.Left
        }),
        u2.createElement("TextLabel", {
            TextScaled = true,
            BackgroundTransparency = 1,
            FontFace = u16,
            Size = UDim2.new(1, 0, 0.18, 0),
            TextColor3 = Color3.fromRGB(251, 251, 251),
            Text = tostring(#v123),
            Position = UDim2.new(0.05, 0, 0.3, 0),
            TextXAlignment = u4.TextXAlignment.Left
        }),
        u2.createElement("TextLabel", {
            TextScaled = true,
            BackgroundTransparency = 1,
            FontFace = u17,
            Size = UDim2.new(0.95, 0, 0.18, 0),
            TextColor3 = Color3.new(0.988235, 0.690196, 0.239215),
            Text = u10(v126),
            Position = UDim2.new(0, 0, 0.1, 0),
            TextXAlignment = u4.TextXAlignment.Right
        }),
        u2.createElement("TextLabel", {
            TextScaled = true,
            BackgroundTransparency = 1,
            FontFace = u17,
            Size = UDim2.new(0.95, 0, 0.18, 0),
            TextColor3 = Color3.fromRGB(251, 251, 251),
            Text = tostring(v127) .. " EXP",
            Position = UDim2.new(0, 0, 0.3, 0),
            TextXAlignment = u4.TextXAlignment.Right
        }),
        u2.createElement(u14, {
            Text = "Start mission",
            MiniText = true,
            Offset = u90.OffsetBinding,
            Size = UDim2.fromScale(0.9, 0.3),
            Position = UDim2.fromScale(0.05, 0.6),
            Ignore = u90.Notification or (#v123 == 0 and true or not v95),
            Callback = function() --[[ Name: Callback, Line 913 ]]
                -- upvalues: u6 (ref), u3 (ref)
                u6:CreateSound("Button", nil, true, "UISounds", "MissionTabStart").Destroy(10);
                u3:FireServer("ActivateInteract", "StartMission");
            end
        })
    });
    local v139 = u2.createElement("Frame", {
        BorderSizePixel = 0,
        BackgroundColor3 = Color3.fromRGB(0, 7, 34),
        Position = UDim2.fromScale(0.265, 0.01),
        AnchorPoint = Vector2.new(0, 0),
        Size = UDim2.fromScale(0.36, 0.97)
    }, {
        u2.createElement("UICorner", {
            CornerRadius = UDim.new(0.02, 0)
        }),
        u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.fromRGB(183, 211, 255),
            Position = UDim2.fromScale(0.05, 0.078),
            Size = UDim2.new(0.9, 0, 0, 1)
        }, { u2.createElement("UIGradient", {
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
            }) }),
        u2.createElement("TextLabel", {
            TextScaled = true,
            Text = "Mission Queue",
            BackgroundTransparency = 1,
            FontFace = u16,
            Size = UDim2.new(0.9, 0, 0.035, 0),
            TextColor3 = Color3.fromRGB(183, 211, 255),
            Position = UDim2.new(0.055, 0, 0.025, 0),
            TextXAlignment = u4.TextXAlignment.Left
        }),
        u2.createElement(u7, {
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
            Size = UDim2.fromScale(1, 0.66),
            Position = UDim2.fromScale(0, 0.1),
            Ignore = u90.Notification,
            OffsetBinding = u90.OffsetBinding,
            CanvasSize = v135 / (v121 * 0.75),
            Content = v128
        }),
        v138
    });
    local l__QuestsCompleted__18 = u90.QuestsCompleted;
    local v140 = 0;
    local v141 = {};
    local v142 = {};
    local l__Page__19 = l__state__13.Page;
    local v143, v144;
    if l__Page__19 == 0 then
        for v145, v146 in u90.Quests do
            local l__Giver__20 = v146.Giver;
            if not table.find(v124, v145) then
                local v147, v148 = u90:_questComponent({
                    Name = v145,
                    Giver = l__Giver__20,
                    Message = v146.Message
                }, v121, v120);
                v141[#v141 + 1] = {
                    Elements = v147,
                    Position = v140,
                    Size = v148
                };
                v140 = v140 + (v148 + v122);
            end;
        end;
        for v149, v150 in u90.InvitedQuests do
            if not table.find(v124, v149) then
                local v151, v152 = u90:_questComponent({
                    Name = v149,
                    Giver = v150.Giver,
                    Inviter = v150.Inviter
                }, v121, v120);
                v141[#v141 + 1] = {
                    Elements = v151,
                    Position = v140,
                    Size = v152
                };
                v140 = v140 + (v152 + v122);
            end;
        end;
        v143 = "Available Missions";
        v144 = "View completed missions";
    elseif l__Page__19 == 1 then
        local v153 = {};
        for v154 in l__QuestsCompleted__18 do
            v153[#v153 + 1] = v154;
        end;
        table.sort(v153, function(p155, p156) --[[ Line: 1019 ]]
            -- upvalues: l__QuestsCompleted__18 (copy)
            return #l__QuestsCompleted__18[p155] > #l__QuestsCompleted__18[p156];
        end);
        for _, v157 in v153 do
            local v158, v159 = u90:_questComponent({
                Giver = v157,
                Count = #l__QuestsCompleted__18[v157]
            }, v121, v120);
            v141[#v141 + 1] = {
                Elements = v158,
                Position = v140,
                Size = v159
            };
            v140 = v140 + (v159 + v122);
        end;
        v143 = "Completed Missions";
        v144 = "View available missions";
    else
        for _, v160 in l__QuestsCompleted__18[l__Page__19] do
            if not table.find(v124, v160) then
                local v161, v162 = u90:_questComponent({
                    ShowOptions = true,
                    Completed = true,
                    Debriefing = l__state__13.Debriefing,
                    Name = v160,
                    Giver = l__Page__19
                }, v121, v120);
                v141[#v141 + 1] = {
                    Elements = v161,
                    Position = v140,
                    Size = v162
                };
                v140 = v140 + (v162 + v122);
            end;
        end;
        v143 = "Mission List";
        v144 = "View completed missions";
    end;
    local v163 = v140 - v122;
    for v164, v165 in v141 do
        v142[v164] = u67(v165, v163);
    end;
    local l__createElement__21 = u2.createElement;
    local v166 = "Frame";
    local v167 = {
        BorderSizePixel = 0,
        BackgroundColor3 = Color3.fromRGB(0, 7, 34),
        Position = UDim2.fromScale(0.99, 0.01),
        AnchorPoint = Vector2.new(1, 0),
        Size = UDim2.fromScale(0.36, 0.97)
    };
    local v168 = { u2.createElement("UICorner", {
            CornerRadius = UDim.new(0.02, 0)
        }), (u2.createElement("Frame", {
            BorderSizePixel = 0,
            BackgroundColor3 = Color3.fromRGB(183, 211, 255),
            Position = UDim2.fromScale(0.05, 0.078),
            Size = UDim2.new(0.9, 0, 0, 1)
        }, { u2.createElement("UIGradient", {
                Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
            }) })) };
    local v169 = next(u90.QuestsCompleted);
    if v169 then
        v169 = u2.createElement(u14, {
            Offset = u90.OffsetBinding,
            Size = UDim2.fromScale(0.5, 0.035),
            Position = UDim2.fromScale(0.46, 0.025),
            Text = v144,
            Ignore = u90.Notification,
            Callback = function() --[[ Name: Callback, Line 1098 ]]
                -- upvalues: u90 (copy), l__Page__19 (copy)
                u90:setState({
                    Debriefing = false,
                    Page = l__Page__19 == 1 and 0 or 1
                });
            end
        });
    end;
    v168.Button = v169;
    v168[3], v168[4] = u2.createElement("TextLabel", {
    TextScaled = true,
    BackgroundTransparency = 1,
    FontFace = u16,
    Size = UDim2.new(0.9, 0, 0.035, 0),
    TextColor3 = Color3.fromRGB(183, 211, 255),
    Text = v143,
    Position = UDim2.new(0.055, 0, 0.025, 0),
    TextXAlignment = u4.TextXAlignment.Left
}), u2.createElement(u7, {
    BackgroundTransparency = 1,
    BorderSizePixel = 0,
    Size = UDim2.fromScale(1, 0.88),
    Position = UDim2.fromScale(0, 0.1),
    Ignore = u90.Notification,
    OffsetBinding = u90.OffsetBinding,
    CanvasSize = v163 / v121,
    Content = v142
});
    local v170 = l__createElement__21(v166, v167, v168);
    return u2.createElement("SurfaceGui", {
        LightInfluence = 0,
        Brightness = 2,
        ClipsDescendants = true,
        Face = u4.NormalId.Front,
        Adornee = u90.ScreenPart,
        SizingMode = u4.SurfaceGuiSizingMode.FixedSize,
        ZIndexBehavior = u4.ZIndexBehavior.Sibling,
        CanvasSize = u90.SizeBinding
    }, {
        u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 3,
            Size = UDim2.fromScale(1, 0.97),
            Position = UDim2.fromScale(0, 0.03),
            BackgroundColor3 = Color3.new(),
            BackgroundTransparency = u90.NotifyTween:Map(function(p171) --[[ Line: 1144 ]]
                return 1 - p171 / 2;
            end)
        }, { u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(0, 6, 29),
                Size = UDim2.fromScale(0.6, 1),
                Position = u90.NotifyTween:Map(function(p172) --[[ Line: 1152 ]]
                    return UDim2.fromScale(1 - p172 * 0.6, 0);
                end)
            }, { u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u16,
                    Size = UDim2.fromScale(0.7, 0.05),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Text = l__state__13.Title,
                    Position = UDim2.fromScale(0.05, 0.2),
                    TextXAlignment = u4.TextXAlignment.Left
                }), u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u17,
                    Size = UDim2.fromScale(0.7, 0.03),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Text = l__state__13.Description,
                    Position = UDim2.fromScale(0.05, 0.25),
                    TextXAlignment = u4.TextXAlignment.Left
                }), u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Size = UDim2.fromScale(0.3, 0.6),
                    Position = UDim2.fromScale(0.05, 0.325)
                }, { u2.createElement("UIListLayout", {
                        FillDirection = u4.FillDirection.Vertical,
                        HorizontalAlignment = u4.HorizontalAlignment.Left,
                        SortOrder = u4.SortOrder.LayoutOrder,
                        VerticalAlignment = u4.VerticalAlignment.Top,
                        Padding = UDim.new(0.02, 0)
                    }), u2.createFragment(v91) }) }) }),
        u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            ImageTransparency = 0.34,
            Image = "rbxassetid://7801324640",
            ZIndex = 4,
            Size = UDim2.fromScale(1, 1),
            ImageColor3 = Color3.fromRGB(173, 173, 173)
        }),
        Background = u2.createElement("Frame", {
            BackgroundColor3 = Color3.fromRGB(0, 12, 56),
            Size = UDim2.fromScale(1, 0.97),
            Position = UDim2.fromScale(0, 0.03)
        }, {
            Gradient = u2.createElement("UIGradient", {
                Rotation = 90,
                Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(161, 161, 161)) })
            }),
            Squad = v106,
            QuickInvite = v118,
            MissionQueue = v139,
            AvailableMission = v170
        }),
        Top = u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 2,
            BackgroundColor3 = Color3.new(0, 0, 0),
            Size = UDim2.fromScale(1, 0.03)
        }, {
            Time = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                TextScaled = true,
                TextWrapped = true,
                Position = UDim2.new(0.02, 0, 0.1, 0),
                Size = UDim2.new(0.98, 0, 0.8, 0),
                FontFace = u16,
                Text = u90.timeBinding,
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u4.TextXAlignment.Left
            }),
            Title = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "Missions",
                TextScaled = true,
                TextWrapped = true,
                Position = UDim2.new(0, 0, 0.1, 0),
                Size = UDim2.new(1, 0, 0.8, 0),
                FontFace = u17,
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u4.TextXAlignment.Center
            }),
            Battery = u2.createElement("TextLabel", {
                BackgroundTransparency = 1,
                Text = "100%",
                TextScaled = true,
                TextWrapped = true,
                Position = UDim2.new(0, 0, 0.1, 0),
                Size = UDim2.new(0.98, 0, 0.8, 0),
                FontFace = u17,
                TextColor3 = Color3.new(1, 1, 1),
                TextXAlignment = u4.TextXAlignment.Right
            }, { u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    AnchorPoint = Vector2.new(1, 0),
                    Size = UDim2.new(0.02, 0, 0.8, 0),
                    Position = UDim2.new(0.96, 0, 0.1, 0),
                    BorderColor3 = Color3.fromRGB(0, 0, 0),
                    BackgroundColor3 = Color3.fromRGB(255, 255, 255)
                }, { u2.createElement("Frame", {
                        BorderSizePixel = 2,
                        AnchorPoint = Vector2.new(0.5, 0.5),
                        Size = UDim2.new(1, -8, 1, -8),
                        Position = UDim2.new(0.5, 0, 0.5, 0),
                        BorderColor3 = Color3.fromRGB(0, 0, 0),
                        BackgroundColor3 = Color3.fromRGB(255, 255, 255)
                    }), u2.createElement("Frame", {
                        BorderSizePixel = 0,
                        AnchorPoint = Vector2.new(0, 0.5),
                        Size = UDim2.new(0.1, 0, 1, -8),
                        Position = UDim2.new(1, 0, 0.5, 0),
                        BorderColor3 = Color3.fromRGB(0, 0, 0),
                        BackgroundColor3 = Color3.fromRGB(255, 255, 255)
                    }) }) })
        })
    });
end;
return v19;