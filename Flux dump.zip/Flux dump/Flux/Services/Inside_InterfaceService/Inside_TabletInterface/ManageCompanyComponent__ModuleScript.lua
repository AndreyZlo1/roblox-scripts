-- Services.InterfaceService.TabletInterface.ManageCompanyComponent
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, u2, _, u3 = shared.import("require", "Roact", "network", "Enum");
v1("TutorialInterface");
local u4 = v1("RoactTween");
local u5 = v1("CompanyComponent");
local u6 = v1("ManageCompanyNavButtonComponent");
local u7 = v1("ManageCompanyButtonComponent");
local u8 = v1({ "ManageCompanyOverviewComponent", "ManageCompanyConstructionComponent" });
local l__Lighting__1 = game:GetService("Lighting");
local u9 = Font.fromId(12188570269, u3.FontWeight.Bold, u3.FontStyle.Normal);
local u10 = Font.fromId(12188570269, u3.FontWeight.Regular, u3.FontStyle.Normal);
local u11 = {
    Overview = { "Overview", 16191609576, 2 },
    Construction = { "Construction", 16235940598, 3 }
};
local v12 = u2.Component:extend("ManageCompany");
function v12.init(u13, u14) --[[ Line: 34 ]]
    -- upvalues: u5 (copy), u2 (copy), u4 (copy), u3 (copy), l__Lighting__1 (copy)
    u13.ScreenPart = u14.ScreenPart;
    u13.OffsetBinding = u14.OffsetBinding;
    u13.SizeBinding = u14.SizeBinding;
    u13.Update = u14.Update;
    u13.Loading = u14.Loading;
    u13.Company = u5.new(u14.CompanyData);
    u13.CameraRef = u2.createRef();
    u13.Landing = u4.new(0);
    u13.Warmup = u4.new(0, TweenInfo.new(2, u3.EasingStyle.Quad, u3.EasingDirection.Out, 0, false, 0));
    u13.Warmup:SetGoal(1);
    local v15, v16 = u2.createBinding("");
    u13.timeBinding = v15;
    u13.updateTime = v16;
    local v17, v18 = u2.createBinding(0);
    u13.spinBinding = v17;
    u13.updateSpin = v18;
    u13.Connection = u13.Update:Connect(function(p19) --[[ Line: 49 ]]
        -- upvalues: l__Lighting__1 (ref), u13 (copy), u14 (copy)
        local l__ClockTime__2 = l__Lighting__1.ClockTime;
        local v20 = (math.floor(l__ClockTime__2) + 11) % 12 + 1;
        local v21 = math.floor(l__ClockTime__2 % 1 * 60);
        u13.updateTime(tostring(v20) .. ":" .. (v21 < 10 and "0" or "") .. tostring(v21) .. " " .. (l__ClockTime__2 >= 12 and "PM" or "AM"));
        u13.updateSpin(u13.spinBinding:getValue() + p19 * 10);
        if u13.Warmup:GetValue() > 0.99 and u13.state.Loading then
            u13.Landing:SetGoal(1);
            u13:setState({
                Loading = false
            });
            if u14.WasRaided then
                u13.Notify("Your HQ was raided", "Travel to your HQ to view the after action report.", {});
            end;
        end;
    end);
    u13.NotifyTween = u4.new(0, TweenInfo.new(0.1, u3.EasingStyle.Exponential, u3.EasingDirection.Out, 0, false, 0));
    function u13.Notify(p22, p23, p24) --[[ Line: 70 ]]
        -- upvalues: u13 (copy)
        u13.NotifyTween:SetGoal(1);
        u13:setState({
            Notification = true,
            Title = p22,
            Description = p23,
            Options = p24
        });
    end;
    u13:setState({
        Notification = false,
        Page = "Overview",
        Loading = true
    });
end;
function v12.willUnmount(p25) --[[ Line: 87 ]]
    p25.Connection:Disconnect();
end;
function v12.render(u26) --[[ Line: 91 ]]
    -- upvalues: u2 (copy), u7 (copy), u3 (copy), u11 (copy), u6 (copy), u8 (copy), u9 (copy), u10 (copy)
    local l__state__3 = u26.state;
    local v27 = {};
    if l__state__3.Notification then
        for v28, u29 in l__state__3.Options do
            v27[v28] = u2.createElement(u7, {
                MiniText = true,
                LayoutOrder = v28,
                Offset = u26.OffsetBinding,
                Size = UDim2.fromScale(1, 0.07),
                Text = u29[1],
                Callback = function() --[[ Name: Callback, Line 103 ]]
                    -- upvalues: u26 (copy), u29 (copy)
                    u26.NotifyTween:SetGoal(0);
                    u26:setState({
                        Notification = false
                    });
                    u29[2]();
                end,
                SubText = u29[3]
            });
        end;
        v27[#l__state__3.Options + 1] = u2.createElement(u7, {
            MiniText = true,
            Text = "Cancel",
            LayoutOrder = #l__state__3.Options + 1,
            Offset = u26.OffsetBinding,
            Size = UDim2.fromScale(1, 0.07),
            Callback = function() --[[ Name: Callback, Line 120 ]]
                -- upvalues: u26 (copy)
                u26.NotifyTween:SetGoal(0);
                u26:setState({
                    Notification = false
                });
            end
        });
    end;
    local v30;
    if l__state__3.Loading then
        v30 = u2.createElement("Frame", {
            BackgroundColor3 = Color3.new(0.105882, 0.105882, 0.105882),
            Size = UDim2.fromScale(1, 1)
        }, {
            Logo = u2.createElement("ViewportFrame", {
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.4),
                Size = UDim2.fromScale(0.3, 0.3),
                SizeConstraint = u3.SizeConstraint.RelativeYY,
                CurrentCamera = u26.CameraRef
            }, { u2.createElement("Camera", {
                    CFrame = CFrame.new(0, 0, 8),
                    FieldOfView = 20,
                    [u2.Ref] = u26.CameraRef
                }), u2.createElement("Part", {
                    Size = Vector3.new(0.15, 2, 2),
                    Color = Color3.fromRGB(25, 54, 84),
                    Material = u3.Material.SmoothPlastic,
                    CFrame = u26.spinBinding:map(function(p31) --[[ Line: 151 ]]
                        return CFrame.new(0, 0, 0) * CFrame.Angles(0, p31, 0);
                    end),
                    Shape = u3.PartType.Cylinder
                }, { u2.createElement("Decal", {
                        Texture = "rbxassetid://16173617463",
                        Face = u3.NormalId.Right
                    }), u2.createElement("Decal", {
                        Texture = "rbxassetid://16173617463",
                        Face = u3.NormalId.Left
                    }) }) }),
            Bar = u2.createElement("Frame", {
                BorderSizePixel = 2,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.fromScale(0.5, 0.7),
                BorderColor3 = Color3.new(1, 1, 1),
                BackgroundColor3 = Color3.new(0.105882, 0.105882, 0.105882),
                Size = UDim2.fromScale(0.3, 0.03)
            }, {
                Progress = u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundColor3 = Color3.new(1, 1, 1),
                    Size = u26.Warmup:Map(function(p32) --[[ Line: 177 ]]
                        return UDim2.fromScale(p32, 1);
                    end)
                })
            })
        });
    else
        local v33 = {};
        for u34, v35 in u11 do
            v33[u34] = u2.createElement(u6, {
                Offset = u26.OffsetBinding,
                Ignore = l__state__3.Notification,
                Selected = l__state__3.Page == u34,
                Text = v35[1],
                Image = v35[2],
                Layout = v35[3],
                Callback = function() --[[ Name: Callback, Line 194 ]]
                    -- upvalues: u26 (copy), u34 (copy)
                    u26:setState({
                        Page = u34
                    });
                end
            });
        end;
        v30 = u2.createFragment({
            Background = u2.createElement("Frame", {
                BackgroundColor3 = Color3.fromRGB(0, 12, 56),
                Size = UDim2.fromScale(1, 1)
            }, {
                Gradient = u2.createElement("UIGradient", {
                    Rotation = 90,
                    Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(161, 161, 161)) })
                })
            }),
            Page = u2.createElement("Frame", {
                BackgroundTransparency = 1,
                ZIndex = 2,
                Position = UDim2.fromScale(0.225, 0.07),
                Size = UDim2.fromScale(0.75, 0.89)
            }, u2.createElement(u8["ManageCompany" .. l__state__3.Page .. "Component"], {
                SizeBinding = u26.SizeBinding,
                OffsetBinding = u26.OffsetBinding,
                Update = u26.Update,
                Loading = u26.Loading,
                Company = u26.Company,
                Ignore = l__state__3.Notification,
                Notify = u26.Notify
            })),
            Sidenav = u2.createElement("Frame", {
                BorderSizePixel = 0,
                ZIndex = 2,
                BackgroundColor3 = Color3.fromRGB(0, 9, 42),
                Position = u26.Landing:Map(function(p36) --[[ Line: 232 ]]
                    return UDim2.fromScale(p36 * 0.2 + -0.2, 0.03);
                end),
                Size = UDim2.fromScale(0.2, 0.97)
            }, {
                u2.createElement("ImageLabel", {
                    BorderSizePixel = 0,
                    Image = "rbxassetid://16173617463",
                    BackgroundTransparency = 1,
                    SizeConstraint = u3.SizeConstraint.RelativeXX,
                    BackgroundColor3 = Color3.fromRGB(255, 255, 255),
                    Size = UDim2.new(0.2, 0, 0.2, 0),
                    BorderColor3 = Color3.fromRGB(0, 0, 0),
                    Position = UDim2.new(0.15, 0, 0.05, 0)
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    Text = "Manage Company",
                    BackgroundTransparency = 1,
                    FontFace = u9,
                    Size = UDim2.new(0.8, 0, 0.03, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.new(0.15, 0, 0.15, 0),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                u2.createElement("TextLabel", {
                    TextScaled = true,
                    Text = "Powered by GDA",
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    Size = UDim2.new(0.8, 0, 0.02, 0),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Position = UDim2.new(0.15, 0, 0.18, 0),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                u2.createElement("Frame", {
                    BorderSizePixel = 0,
                    BackgroundTransparency = 1,
                    Size = UDim2.new(1, 0, 0.75, 0),
                    Position = UDim2.new(0, 0, 0.25, 0),
                    BorderColor3 = Color3.fromRGB(0, 0, 0),
                    BackgroundColor3 = Color3.fromRGB(255, 255, 255)
                }, { u2.createElement("UIGridLayout", {
                        CellPadding = UDim2.new(0, 0, 0.01, 0),
                        SortOrder = u3.SortOrder.LayoutOrder,
                        CellSize = UDim2.new(1, 0, 0.08, 0)
                    }), u2.createFragment(v33) })
            }),
            Top = u2.createElement("Frame", {
                BorderSizePixel = 0,
                ZIndex = 2,
                BackgroundColor3 = Color3.new(0, 0, 0),
                Size = UDim2.fromScale(1, 0.03)
            }, {
                Time = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    TextWrapped = true,
                    Position = UDim2.new(0.02, 0, 0.1, 0),
                    Size = UDim2.new(0.98, 0, 0.8, 0),
                    FontFace = u9,
                    Text = u26.timeBinding,
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Left
                }),
                Title = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    TextWrapped = true,
                    Position = UDim2.new(0, 0, 0.1, 0),
                    Size = UDim2.new(1, 0, 0.8, 0),
                    FontFace = u10,
                    Text = "Manage Company: " .. u11[l__state__3.Page][1],
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Center
                }),
                Battery = u2.createElement("TextLabel", {
                    BackgroundTransparency = 1,
                    Text = "100%",
                    TextScaled = true,
                    TextWrapped = true,
                    Position = UDim2.new(0, 0, 0.1, 0),
                    Size = UDim2.new(0.98, 0, 0.8, 0),
                    FontFace = u10,
                    TextColor3 = Color3.new(1, 1, 1),
                    TextXAlignment = u3.TextXAlignment.Right
                }, { u2.createElement("Frame", {
                        BorderSizePixel = 0,
                        AnchorPoint = Vector2.new(1, 0),
                        Size = UDim2.new(0.02, 0, 0.8, 0),
                        Position = UDim2.new(0.96, 0, 0.1, 0),
                        BorderColor3 = Color3.fromRGB(0, 0, 0),
                        BackgroundColor3 = Color3.fromRGB(255, 255, 255)
                    }, { u2.createElement("Frame", {
                            BorderSizePixel = 2,
                            AnchorPoint = Vector2.new(0.5, 0.5),
                            Size = UDim2.new(1, -8, 1, -8),
                            Position = UDim2.new(0.5, 0, 0.5, 0),
                            BorderColor3 = Color3.fromRGB(0, 0, 0),
                            BackgroundColor3 = Color3.fromRGB(255, 255, 255)
                        }), u2.createElement("Frame", {
                            BorderSizePixel = 0,
                            AnchorPoint = Vector2.new(0, 0.5),
                            Size = UDim2.new(0.1, 0, 1, -8),
                            Position = UDim2.new(1, 0, 0.5, 0),
                            BorderColor3 = Color3.fromRGB(0, 0, 0),
                            BackgroundColor3 = Color3.fromRGB(255, 255, 255)
                        }) }) })
            })
        });
    end;
    return u2.createElement("SurfaceGui", {
        LightInfluence = 0,
        Brightness = 2,
        ClipsDescendants = true,
        Face = u3.NormalId.Front,
        Adornee = u26.ScreenPart,
        SizingMode = u3.SurfaceGuiSizingMode.FixedSize,
        ZIndexBehavior = u3.ZIndexBehavior.Sibling,
        CanvasSize = u26.SizeBinding
    }, { u2.createElement("Frame", {
            BorderSizePixel = 0,
            ZIndex = 3,
            Size = UDim2.fromScale(1, 0.97),
            Position = UDim2.fromScale(0, 0.03),
            BackgroundColor3 = Color3.new(),
            BackgroundTransparency = u26.NotifyTween:Map(function(p37) --[[ Line: 369 ]]
                return 1 - p37 / 2;
            end)
        }, { u2.createElement("Frame", {
                BorderSizePixel = 0,
                BackgroundColor3 = Color3.fromRGB(0, 6, 29),
                Size = UDim2.fromScale(0.6, 1),
                Position = u26.NotifyTween:Map(function(p38) --[[ Line: 377 ]]
                    return UDim2.fromScale(1 - p38 * 0.6, 0);
                end)
            }, { u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u9,
                    Size = UDim2.fromScale(0.7, 0.05),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Text = l__state__3.Title,
                    Position = UDim2.fromScale(0.05, 0.2),
                    TextXAlignment = u3.TextXAlignment.Left
                }), u2.createElement("TextLabel", {
                    TextScaled = true,
                    BackgroundTransparency = 1,
                    FontFace = u10,
                    Size = UDim2.fromScale(0.7, 0.03),
                    TextColor3 = Color3.fromRGB(183, 211, 255),
                    Text = l__state__3.Description,
                    Position = UDim2.fromScale(0.05, 0.25),
                    TextXAlignment = u3.TextXAlignment.Left
                }), u2.createElement("Frame", {
                    BackgroundTransparency = 1,
                    Size = UDim2.fromScale(0.3, 0.6),
                    Position = UDim2.fromScale(0.05, 0.325)
                }, { u2.createElement("UIListLayout", {
                        FillDirection = u3.FillDirection.Vertical,
                        HorizontalAlignment = u3.HorizontalAlignment.Left,
                        SortOrder = u3.SortOrder.LayoutOrder,
                        VerticalAlignment = u3.VerticalAlignment.Top,
                        Padding = UDim.new(0.02, 0)
                    }), u2.createFragment(v27) }) }) }), u2.createElement("ImageLabel", {
            BackgroundTransparency = 1,
            ImageTransparency = 0.34,
            Image = "rbxassetid://7801324640",
            ZIndex = 4,
            Size = UDim2.fromScale(1, 1),
            ImageColor3 = Color3.fromRGB(173, 173, 173)
        }), v30 });
end;
return v12;