-- Services.InterfaceService.HQManagerInterface
-- ModuleScript | dc

-- Decompiled with Potassium's decompiler.

local v1, _, u2, u3, _ = shared.import("require", "network", "Roact", "Enum", "server");
local u4 = v1("GameShellProxyService");
local u5 = v1("HQManagerComponent");
local _ = workspace.CurrentCamera;
local u6 = {};
u6.__index = u6;
function u6.new() --[[ Line: 20 ]]
    -- upvalues: u4 (copy), u3 (copy), u6 (copy)
    local v7 = {
        UI = u4:CreateProxy(1, u3.ShellPriority.AlwaysVisible, "HQManagerInterface")
    };
    return setmetatable(v7, u6);
end;
function u6.Enable(p8, p9, p10, p11, p12) --[[ Line: 29 ]]
    -- upvalues: u2 (copy), u5 (copy)
    p8._hqUpgrades = {};
    p8.Open = true;
    p8._handle = u2.mount(u2.createElement(u5, {
        Company = p9,
        HQUpgrades = p10,
        UpdateCameraFocus = p11,
        RaidResults = p12
    }), p8.UI);
end;
function u6.Disable(p13) --[[ Line: 41 ]]
    -- upvalues: u2 (copy)
    p13._hqUpgrades = nil;
    p13.Open = false;
    u2.unmount(p13._handle);
    p13._handle = nil;
end;
return u6.new();